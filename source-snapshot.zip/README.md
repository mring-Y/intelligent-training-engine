# 智训引擎 · Intelligent Training Engine

**2026-11-15 最新合入：A step7分层回放+B静态+C head-only 2epoch已封装候选镜像。** 严格仅用官方train作梯度后，A全流Macro-F1 `0.5742767490→0.5743703129`，仅改正一条预测，未达预登记0.005实质增益；B持平，C RMSE `106.9741809588→104.8312569644`（下降约2.00%），全流辅助指标在用户确认阈内。宿主717/717、断网Linux716通过/1宿主专用跳过，各54流且预测逐值一致。新镜像`ite-ac-policy:20261115-v1`已导出重载；工程合入完成，效果门槛失败按NR-046归档，原C2镜像保留。SwanLab offline `kffgpsrl`保存698份原始证据，新增费用/平台次数0；尚无官方隐藏平台启动合同，不宣称隐藏验收。[完整结果与Docker tar](docs/ac-policy-integration-results-20261115.md)、[机器索引](docs/validation/2026-11-15-ac-policy-integration.json)。以下为历史轮次。

**2026-11-15 最新：A时点复核已有公开开发增益，B来源均衡回放失败，均已完成断网复现。** A统一step7的全流Macro-F1 `0.5742767490→0.5953430698`、Accuracy `0.6985875706→0.7245762712`，六分区均未退化；因两个漂移train分区只持平，仍仅通过4/6分区、未达全部分区通过的严格门槛，不自动晋级。A eval的279行全为类别5，已释放validation参与梯度，不能当作独立六类泛化或train-only正式候选。B固定step7的48行来源均衡回放使全流RMSE `704.1735234790→708.0775701076`，MAE也增大；部署后258行RMSE `239.643939→406.288781`，按NR-045归档，B继续static。宿主最终711/711、Linux710通过/1宿主专用跳过；A/B各18流在两端逐值复现预测。新增远程费用和平台试运行消耗均0，证据保存为SwanLab offline。详见[A完整结果](docs/official-a-replay-timing-results-20261115.md)、[B完整结果](docs/official-b-source-replay-results-20261115.md)。尚未把A接入新的三包正式组合，以下既有交付镜像保持原样。

**2026-11-15 已有交付候选：A/B静态+C head-only 2epoch组合通过本地开发门槛。** 用户确认的单因素1/2/3/5epoch对照中，2epoch将C三场景复合RMSE从106.974181降至104.831257（约2.00%），高估率增加0.57992个百分点、平均正向高估增加0.14941周期，均在确认阈值内；A/B逐值保留baseline，stable不退。宿主/Linux各完成36流选参与54流组合复核，参数及预测精确一致；宿主696/696，Linux695通过/1宿主专用跳过。原生Docker tar已导出重载。单独未偏移公开验证上的C稳定流最终检查点RMSE52.868573→52.561328，四项指标均改善；漂移检查点迁回原分布存在退化，完整披露而不外推隐藏成绩。详见[最终结果与镜像](docs/heuristic-c-epochs-results-20261115.md)及[机器验证](docs/validation/2026-11-15-heuristic-c-epochs.json)。

**2026-11-15 启发式兜底候选已完成本地验证，但不晋级默认。** `Controller`在有效`DO_NOTHING`、漂移报警和连续Loss恶化时可申请A的48条分层回放或C的普通`head_only`；筛选、独立future gate、预算和B静态保护仍生效。54流三臂对照工程通过，A复合Macro-F1 `0.5742767490→0.5675563662`下降，B持平，C RMSE `106.9741809588→93.7768186959`下降12.34%，但C高估率`29.9145%→35.8295%`和平均正向高估`10.4038→13.7085`周期超出确认阈值，故候选不作为默认或正式提交。宿主与断网Linux预测逐值一致；原生Docker归档见[启发式结果与交付说明](docs/heuristic-override-results-20261115.md)。

**2026-11-14 最新入口：27B真实Harness三包十轮已完成，但没有性能增益。** 4B在NR-040中完成A首轮后，两次工具修正仍无法提出合规第二轮，按用户条件只把本次Harness切换为官方Qwen3.8-27B；提示、数据、CPU训练、筛选、future gate、15秒截止和网络零重试均不变。27B真实A/B/C各10/10轮，36次请求全部成功，A/B/C筛选通过2/5/8、future gate通过2/5/4，但30次选择全部保留incumbent，三包最终checkpoint与官方起点相同，公开末块差值为0。累计保守预留¥10.84/¥29.99，隐藏测试未访问。宿主675/675，断网Linux 674通过/1宿主专用跳过；三包提案断网重放完成。详见[27B续开结果](docs/code-harness-renewal-results-20261114.md)、[运行说明](docs/code-harness-ten-rounds.md)、[NR-041](docs/negative-results.md)。4B仍保留为默认候选；赛题PDF未列4B固定加分，资源效率优势按正式细则确认。 用户明确许可后五份原始归档已公开，SwanLab真实27B为[al0xjnid](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/al0xjnid/chart)，五个run均FINISHED。

**2026-11-13 本轮：官方 C 的动态推理校准已实现，联合安全目标仍未通过。** `CALIBRATE_DOWN` 固定720条head-only训练、48条筛选，另取前一来源的独立48条已释放标签，按残差90分位数动态向下平移。校准后突变/渐变合并RMSE为124.657/121.618周期，低于静态127.569/123.537；高估率17.571%/17.250%仍高于静态16.144%/16.413%。4个漂移分区全部未过联合门槛，按NR-029归档，不晋级默认。最终宿主553/553；断网4核8GiB Linux552通过、1项宿主专用跳过；无真实API或LoRA。当前测试流为公开验证集的时序模拟，不代表官方隐藏测试集的真实表现。[校准结果与原因](docs/official-safety-calibration-results-20261113.md)、[验证索引](docs/validation/2026-11-13-official-safety-calibration.json)。以下保留历史轮次原日期。

**2026-11-14 最新：官方 C 包 2×非对称训练损失对照未通过安全门槛。** 标准化残差为正时将平方损失乘2，仅在C的`head_only`续训可用；18流中RMSE下降，但4个漂移分区的高估率仍高于各自静态值。step7训练的720行初始预测没有正残差，说明本轮惩罚初始梯度不触发。宿主537/537、断网4核8GiB Linux536通过/1宿主专用跳过；无输出校准、API调用或LoRA，默认策略未变。当前测试流为公开验证集的时序模拟，不代表官方隐藏测试集的真实表现。[完整结果、四层诊断](docs/official-asymmetric-loss-results-20261114.md)、[机器验收](docs/validation/2026-11-14-official-asymmetric-loss.json)、[NR-028](docs/negative-results.md)。以下为历史轮次记录。

**2026-11-13 最新：官方MLP冻结输出头已实现，C包联合安全目标未通过。** `RETRAIN_HEAD_ONLY`从当前checkpoint保留底层及其Adam矩，仅更新输出头；A/B/C可更新198/25/33参数。18条固定时点对照中，C突变完整公开模拟RMSE static/full/head为127.569/122.005/123.872周期，但高估率16.144%/18.639%/17.853%；渐变同样RMSE下降而高估增加，按NR-027归档，不晋级默认策略、不调用Teacher或训练LoRA。宿主533/533、4CPU/8GiB断网Linux532通过1宿主专用跳过；207441个预测与12候选数组跨平台一致。当前测试流为公开验证集的时序模拟，不代表官方隐藏测试集的真实表现。[完整三组结果与复现](docs/official-head-only-results-20261113.md)、[机器验收](docs/validation/2026-11-13-official-head-only.json)。以下保留历史轮次。

**2026-11-12 最新：官方MLP锚定SFT试点已完成。** A/B/C均已接入，默认`official_mlp`按profile自动路由，Ridge/Tree保留审计降级。九场景18分区的真实resume离线工程通过；真实27B Teacher **27次、16903服务端Token、7.60–8.87秒/次**，Token费用估算¥0.07638，用户两位小数账目约¥0.07。C突变/渐变train的RMSE各降3.06/3.17周期，但寿命高估增加；因此**train=0、eval=0、review=27**，没有启动4B微调或效果晋级。宿主514/514通过，4CPU/8GiB断网Linux513通过、1项宿主专用测试跳过。当前测试流为公开验证集的时序模拟，不代表官方隐藏测试集的真实表现。详见[完整报告与27条真实Observation/JSON/Reason](docs/official-sft-pilot-20261112.md)、[NR-025/026](docs/negative-results.md)、[验证回执](docs/validation/2026-11-12-official-sft.json)。历史成果已归档[SwanLab ljc6re1q](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/ljc6re1q)；本轮新Teacher产物仅保存在本地。24次补充预算停止未及时生效的缺口已如实记载，单次试点已锁止，不重开。

**2026-11-11 历史：官方CPU A模型已接入开发流程。** 独立NumPy 1.26.4 worker与主运行时NumPy 2.3.5隔离；官方检查点在完整公开验证集Accuracy **87.86%**、Macro-F1 **0.7140**。公开验证集时序模拟中Mock触发一次RETRAIN_SMALL，但候选在115条独立future样本上与当前模型错误率相同，被门控拒绝；0部署，在线静态与Harness均为Accuracy **49.69%**、Macro-F1 **0.3946**。验证集模拟不代表官方隐藏测试表现；A包元数据标注draft。此段为当日历史状态，后续B/C接入、默认切换及Docker验证以上方最新报告为准。详见[结果与证据](docs/official-model-results-20261111.md)、[NR-023](docs/negative-results.md)。

**2026-11-11 前序：真实Qwen防守Demo以Fail-Closed完成。** 固定FD001 step10 Observation发起1次Qwen3.8-27B请求，15.20秒端到端超时；按零重试策略熔断，18/18批仍由v0完成，0次重训/部署。服务端未结算，Token与最终费用未知，账本保留¥0.01374962请求预留；没有真实JSON/Reason，不能宣称大模型已展示战略克制。[完整留存](Qwen_Live_Decision.md)、[最终交付结论](docs/official-submit-delivery.md)、[NR-022补记](docs/negative-results.md)。单次claim已消耗，不重跑。

**2026-11-10 历史结果：C-MAPSS Tree Harness对照。** 固定20台发动机、4493条、18批，静态与Harness RMSE均为**21.0673周期**；唯一192条SMALL候选在隔离筛选上更差，被拒绝，0部署、0收益。预登记正向条件未通过，按用户约定**未调用真实Qwen、0真实Token/费用**。宿主/4CPU·8GiB断网Linux各445/445测试通过，预测与检查点逐值复现。详见[报告、曲线及NR-022](docs/cmapss-tree-harness-results-20261110.md)、[Qwen条件阶段记录](Qwen_Live_Decision.md)；默认与官方镜像未晋级。以下日期相同的内容按历史轮次保留。

**2026-11-10 TreeModel 对照已完成：** 安全 NPZ 单棵 CART（深度6、最多64叶、最小叶5）在固定公开 A 包静态流上取得 Gas Accuracy **43.22% vs Ridge 26.07%**、轴承 RMSE **917.85 vs 3013.33秒**、FD001 RMSE **21.0673 vs 21.3840周期**。Gas Tree Harness 上线后为30.98%，低于同样本静态32.08%，50%目标未通过；这区分了基座收益与一次干预收益。树训练使用独立5秒上限，Ridge默认3秒；断网4 CPU/8 GiB完整437项和三份真实对照复现通过。详见[TreeModel结果](docs/tree-model-results-20261110.md)和NR-020。

**2026-11-10 历史结果：Gas Mock干预与轴承Cap。** Gas原九批闭环触发1次重训并通过独立未来门控上线，全流Accuracy **26.07%→27.29%**；实际新模型预测 **32.65%**，**未过50%目标**。轴承Cap10000截断0条标签，RMSE仍 **3013.33秒**，不能据此认定Ridge上限。宿主/断网Linux各381项、0失败、1项可选跳过；Gas逐值复现，轴承差约8.64e-12秒，0真实Token。见[曲线、重训日志、四层诊断与NR-018/019](docs/gas-harness-cap-results-20261110.md)。实现冻结`774f877`；C-MAPSS干预和树模型仍为后续范围。

**2026-11-10 公开 A 包已跑通首轮静态 Baseline：** 按用户指定接入 UCI Gas 六分类、C-MAPSS FD001 RUL 和 XJTU-SY RUL。固定 alpha=1，测试流结果分别为 Accuracy **26.07%**、RMSE **21.38 周期**、**3013.33 秒**；轴承仅覆盖工况1的三个完整实体。50项新增测试，宿主/断网Linux完整套件均337项、各1项可选跳过；三源原始数据在Linux重做预处理与预测核对通过。[结果、来源与边界](docs/public-a-baseline-results-20261110.md)、[数据准备入口](scripts/data_prep/README.md)。本轮没有调参、Mock干预或真实付费调用；官方SDK与隐藏B评测仍待对齐。

面向“工业制造场景下的模型训练与超参数优化”赛题，开发在漂移数据流上自动运行、控制资源消耗并保留完整实验依据的模型自进化系统。

**官方提交镜像：** [联网构建、断网验收和公开实验链接索引](docs/official-submit-delivery.md)，镜像标签 `ite-final:official-submit`，运行大小约 950 MB。

**2026-11-08 本轮接口补齐：** [官方 CSV/Parquet 数据接口](docs/official-data-provider.md) 已接入 Runner；[三次突变验收结果](docs/three-abrupt-results.md)：宿主/断网Linux各278/278，Mock三条未来门控链成立；唯一真实请求15秒超时，熔断后完成30批，真实三次门控目标失败，已记NR-016，未追加付费。完整CPU镜像约950MB，导出约211MB。[SwanLab公开归档](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/8qr4s306)逐Action展示观测/原因和门控结果；不代表官方三次迭代门槛已验收。

逐决策候选/标签来源明细见[Triple-drift Mock report](docs/triple-drift-mock-report.md)。[README_OFFICIAL.md](README_OFFICIAL.md)列出当前A/B适配入口：需明确路径、字段映射、初始训练/验证数据和标签时延；正式A/B尚未下发，CLI单字段路径配置暂不支持。

**A 包下发后的下一对话入口（2026-11-08）：** 请先阅读 [A 包接入交接文档](docs/handoff-after-A-package.md)，按其中步骤只读核对数据/SDK/标签协议，再提出本轮诊断与策略。此前 Harness 阶段背景见[历史交接文档](docs/handoff-next-session.md)。

已按本轮明确确认实现可选 [Mock Harness 与预算熔断](docs/harness-mock.md)：严格观测/动作契约，白名单重训与未来门控回滚，触线后冻结当前模型并取消待验收候选。入口为 `configs/harness-mock.json`；`harness_mock_mode` 支持 `normal`、`invalid_json`、`token_exhausted`。模拟 Token 与真实用量分列，原默认与旧模式保持。[本轮验收](docs/harness-mock-results.md)：宿主/断网Linux各204/204，六对核心流预测逐值一致；只验收协议链路，尚未接入真实大模型。

**培训纪要补充（2026-11-07 接收）：** 见 [规则补充与项目影响](docs/competition-briefing-notes.md)。纪要明确标签无需申请配额、四核八 G / 无 GPU / 2 G 提交包、至少三次尝试迭代及 SwanLab 公开要求；正式 SDK 和评分细则待发布。此处为当日交接历史状态，后续真实调用/公开归档及其失败边界以 2026-11-08 最新报告和 NR-016 为准。有限标签策略属于模拟模式，不能直接视为官方标签协议。

**真实客户端已验收（2026-11-07）：** 用户确认后完成 [PyTRiO 客户端与持久预算保护](docs/harness-pytrio.md)。唯一真实流为 classification/abrupt/seed7/96批/drift：2次请求、1142服务端Token、预估0.01114030元，2轮训练尝试，1个候选通过独立未来门控上线。宿主/断网Linux各240/240，通过后完成144次纯Mock矩阵；145条流共13920批检查点预测精确重建。详见 [本轮结果与边界](docs/harness-pytrio-results.md)。免费标签模式仍是模拟协议，官方“三次迭代”要求尚未验收，未宣称官方效果晋级。

## 赛题依据与开发边界

赛题原文：[赛题 PDF](c945f17fdaf0636a7a36aca3d4264fd8.pdf)，共 5 页。

- 核心闭环：**漂移监测 → 诊断归因 → 实验优化 → 评估上线 → 回滚**。
- 客观评价关注性能增益及对应的算力、标注配额和大模型 Token 消耗；正式公式尚未公布。
- 进入排名的基础门槛：无人干预完成全部阶段并按时输出、完整记录所有实验、综合性能不低于官方静态基线。
- 官方提供预提取特征，基础任务可使用 CPU；要求 Python 3.10 及以上。
- 使用大模型驱动 Harness 时，须选择通过 PyTRiO 平台训练得到的模型或其 Qwen3.8-27B 模型。
- 正式评测在指定设备的统一离线环境运行。数据、SDK、资源限制及《实验记录规范》以官方后续发布为准。

本项目现阶段使用模拟数据验证工程机制。模拟指标不能视为官方成绩；在未知隐藏流上，部署门控与回滚也不能保证性能绝不退化。

## 技术路线

采用“**轻量预测模型 + 受控调度器 + 可替换的大模型接口**”。首先用 CPU 跑通完整闭环和对照实验，再接入官方数据及获准使用的大模型。

1. 数据与评测层：可复现的流式仿真、标签延迟与标注预算、严格按时间先预测后学习的评测。
2. 模型层：静态基线、定期更新和漂移触发更新，共用相同的初始数据、数据流和预算。
3. 决策层：漂移证据、有限候选搜索、独立验证、模型替换、检查点及回滚。
4. 资源与记录层：训练耗时、标签数、模型版本、更新决策、Token 和完整本地日志；云端通过独立适配器对接。
5. 运行层：统一命令入口、配置、报告、离线运行和容器化准备。
6. 策略层：在限定范围内，根据已揭晓历史结果调整策略；保留固定策略对照，避免无限迭代。

## 分阶段规划

已完成的本地优化见 [无官方数据阶段优化计划](docs/local-optimization-plan.md) 与 [本轮结果](docs/local-optimization-results.md)。独立种子 `211、223、227、229、233` 已使用，后续只作历史对照。

后续每轮必须遵守 [迭代 SOP](docs/iteration-sop.md)：**阴性归档 → 四层诊断 → 提出升级策略 → 用户确认 → 先测试再实现与实验**。确认前只读取/分析已有结果并维护必要文档；旧的实施授权不代替本轮确认。[阴性结果档案](docs/negative-results.md) 已补录历史失败及缺测边界，[日志诊断](docs/negative-diagnosis-20261104.md) 记录残差、复杂度和实际部署时序。启动标注、固定 8 批来源窗口和训练预检的开发结果分别按 NR-009/010/011 归档；最新 [训练预检结果](docs/training-preflight-results.md) 证明不消耗空训练预算的工程要求成立，但效果未晋级，默认不变。

首轮预计 7–10 个开发日；估时用于安排优先级，不是对官方接口适配时间的承诺。

| 阶段 | 工作内容 | 验收标准 | 原预计时间 | 状态 |
| --- | --- | --- | --- | --- |
| 1. 需求与接口 | 明确数据流、模型、标签、预算、日志接口；独立官方数据适配层 | 模型与数据可替换；未知规则单独标明 | 0.5–1 天 | 本地边界已定义，官方适配待 SDK |
| 2. 数据流仿真 | 无漂移、突变、渐变、周期回归、协变量变化及短暂噪声；模拟标签延迟和配额 | 固定种子可复现；不向决策器暴露未来标签 | 1–2 天 | 已实现 |
| 3. 对照基线 | 静态模型、定期更新、漂移触发更新 | 同种子、同数据、同预算比较性能与成本 | 1 天 | 已实现 |
| 4. 自动更新闭环 | 监测、诊断、有限实验、独立评估、模型切换、回滚 | 自动处理变化；拒绝不合格候选；故障可降级 | 2 天 | 已实现；有限历史模型复用 |
| 5. 预算与记录 | 实验日志、训练时间、标注数、Token、版本、SwanLab 适配 | 实验可追溯；耗尽预算后仍继续预测 | 1 天 | 已实现；SwanLab 已验证上传 |
| 6. 离线运行与提交 | 统一入口、依赖、模型存档、容器定义、运行说明 | 一条命令跑完全流程；运行时不下载内容 | 1–2 天 | 本地 CLI 与 Docker 交付已验收；正式配额待官方 |
| 7. 受控策略改进 | 有边界地调整候选历史窗口等策略参数 | 用历史证据说明变化；有固定策略消融 | 后续深化 | 已有受限窗口策略；收益需持续验证 |

**首个里程碑：** 一条命令在模拟漂移流上完成预测、监测、更新、模型切换及回滚能力验证，并自动生成三组基线的性能与成本报告。

## 本地运行

最低本地要求：Python 3.10 及以上、NumPy、Git。仓库开发使用已验证的 Python 3.12 + NumPy 2.3.5；下列 PowerShell 命令无需连接 SwanLab 或运行 PyTRiO：

```powershell
# Set this to any locally available Python 3.10+ executable.
$Python = 'C:\path\to\python.exe'
& $Python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e .
.\.venv\Scripts\python.exe -m ite run --config configs/default.json --output outputs/local
```

打开 `outputs/local/report.html` 查看分策略结果；CSV、JSON、JSONL、逐批预测和模型检查点保存在同一目录。可用 `--task regression`、`--scenario gradual`、`--adapt-strategy` 覆盖配置；参数不变时，请使用新的输出目录，以保留不可覆写的实验记录。离线多场景、多种子和固定策略消融请运行：

```powershell
.\.venv\Scripts\python.exe -m ite matrix --output outputs/matrix --seeds 7 19 43 --ablation
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

矩阵也可以从完整配置文件启动；显式命令行参数覆盖文件中的对应字段：

```powershell
.\.venv\Scripts\python.exe -m ite matrix --config configs/default.json `
  --output outputs/matrix-config --tasks classification regression `
  --scenarios stable abrupt gradual recurring covariate noise `
  --seeds 101 103 107 109 113 --batches 96
```

将 `deployment_validation` 设为 `future` 后，候选会在搜索后冻结，只能使用冻结后产生并按延迟协议释放的标签上线；流结束前未完成验收的候选会被拒绝。`monitor_min_labeled` 可单独设置诊断门槛，`reuse_history` 在 `future` 模式下允许漂移策略优先评估历史模型而不消耗训练时间。旧默认配置保持 `legacy`，以便与历史结果直接比较。

`label_startup_budget` 是仅用于 `label_schedule: "adaptive"` 的实验选项，默认 0；`configs/optimization-startup-144.json` 固定为 144。它提前使用同一标签配额，并受原后段监测储备约束；不会增加总预算或放宽标签延迟、上线验收。

`train_source_window_batches` 默认 0（禁用）。实验配置 `configs/optimization-training-freshness-8.json` 固定为 8：先按原时间批次划分训练与筛选验证，再只保留来源不早于最新已释放来源批次减 7 的训练标签；不改变验证集合，少于既有 16 个训练标签时跳过。来源时间与处理时钟分开记录，不读取漂移真值。开发配对范围与门槛见 [预登记](docs/training-freshness-plan.md)。

`training_preflight` 是严格布尔选项，默认 `false`。已确认的 [训练可行性预检](docs/training-preflight-plan.md) 候选 `configs/optimization-training-preflight.json` 相对固定 8 批配置只打开此开关：训练/验证样本不足时写入 `training_preflight_skipped`，继续当前模型，不消耗训练实验名额或推进冷却；同一未变化来源证据只检查一次，新释放标签允许重试。实际训练后的原记账、冷却和独立未来门控保持原样。`training_attempts` 计已启动的训练实验（不含历史复用），`cooldown_until` 从现有 `last_experiment + cooldown + 1` 导出；预检事件与运行摘要记录这些真实审计状态。关闭时保留历史不足样本仍占名额/冷却的兼容行为。

`training_weighting` 默认 `"none"`，保留原无权重训练；可选 `"exponential"`，按已释放标签的来源批次计算 `w_i = 2 ** (-(latest_released_source_step - source_step_i) / training_half_life_batches)`，再在每个候选样本切片内归一化为均值 1。`training_half_life_batches` 默认 4.0，只接受有限正数（不接受布尔值）；指数权重与正的 `train_source_window_batches` 互斥。特征均值/总体方差、目标均值、不惩罚的截距、quadratic 基函数中心化和岭求解全链路加权；分类仍是原 0/1 岭模型，同权和无权重保留原数值分支。初始模型、筛选错误率/NMSE 与独立 future 门控不加权。

已完成的 [时间衰减计划](docs/time-decay-plan.md) 使用 `configs/optimization-time-decay.json`：相对原预检对照取消固定 8 批训练硬截断，仅在现有最多 768 个已释放标签历史和 192/384/768 样本候选上使用 4 批半衰期，保持 `training_preflight: true`。全链路加权，每候选权重均值为 1；训练下限仍为 16，ESS 仅审计。新增 20 项 TDD 测试，宿主与断网 Linux 各 114/114，通过后完成两组共 144 次开发配对。[结果与四层诊断](docs/time-decay-results.md) 显示：样本不足预检跳过 295→0、实际训练 54→93，突变与周期均值改善，但渐变回归 NMSE .543433→.719121；四项历史门槛失败，归档 NR-012，默认仍为 `training_weighting="none"`、`training_preflight=false`。早期渐变回归候选训练来源仍为 0–9/0–10，最新释放标签被时间切分留在筛选端，不能把更多历史或更高 ESS 当作新概念证据。原始记录保存在 `outputs/time-decay-20261104`；[验证记录](docs/validation/2026-11-04-time-decay.json) 与 [交付校验](docs/validation/2026-11-04-time-decay-delivery.json) 区分冻结源码/镜像和最终结果文档。本轮没有追加策略、调参或独立验收。

SwanLab 项目为 [mring-Y/Intelligent_Training_Engine](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine)。SDK 0.10.3 已在本机项目环境安装并验证云端上传；可复用本机 `swanlab login` 登录，也支持 `SWANLAB_API_KEY`。上传是显式操作，本地实验入口不访问外网。

本轮时间衰减的 144 次运行已归档到 SwanLab [wrool8bf](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/wrool8bf)，实际上传 ZIP 的 1,507 文件与原始输出逐一核验。2026-11-05 切换手动审批后，上传和本地结果文档提交 `c12a2a4` 均成功；此前自动审批失败记录保留。完整回执与校验见 [结果文档](docs/time-decay-results.md) 和运行手册。

[时间衰减交付 ZIP](outputs/ite-time-decay-delivery-20261104.zip) 包含源码 `b47c30b`、冻结镜像、原始实验归档、最终诊断和审查回执，[包内清单](outputs/ite-time-decay-delivery-20261104/SHA256SUMS) 与 [外部 ZIP 校验](docs/validation/2026-11-04-time-decay-delivery.json) 已核验。最终审查通过，效果保留为开发失败 NR-012，云端状态单独记录。

```powershell
# Optional tracking dependency on a new environment.
.\.venv\Scripts\python.exe -m pip install -r requirements-tracking.txt
.\.venv\Scripts\swanlab.exe login
# Replay one policy or archive every experiment under a directory.
.\.venv\Scripts\python.exe -m ite upload-swanlab --run-dir outputs/local/drift
.\.venv\Scripts\python.exe -m ite upload-swanlab --run-dir outputs/matrix --archive
```

多实验归档包含每轮 JSONL、配置、结果、预测和模型检查点，并为每个文件保留 SHA-256 清单；`cloud-upload.json` 保存项目、云端链接和归档校验值，不保存凭证。它是可追溯的开发记录，尚需与官方《实验记录规范》逐项对齐。运行、架构和验证细节见 [运行手册](docs/runbook.md)、[架构](docs/architecture.md) 与 [执行清单](docs/implementation-plan.md)。

## 当前实测结果

2026-11-04 的 [训练样本可行性预检](docs/training-preflight-results.md) 完成 **144 次开发运行**，先写失败测试再实现，宿主机和断网 Linux 各 **94/94 测试通过**。295 次样本不足预检均未增加真实训练尝试、未推进冷却；实际训练轮数 48 → 54，上线 21 → 26，全部 13,824 批预测持续完成并由检查点精确还原。但分类突变 .254196 → .263563、分类渐变 .238751 → .267650、回归渐变 .492508 → .543433，四项历史门槛失败，**NR-011，默认仍关闭**。7 次变化运行提前 3 批上线，首训标签却由 85–86 减至 27–28，不能将更早可行等同于质量充分。

原始输出 `outputs/training-preflight-20261104` 保留全部曲线、预测、事件和来源审计；[验证记录](docs/validation/2026-11-04-training-preflight.json)、[交付记录](docs/validation/2026-11-04-training-preflight-delivery.json) 和 [交付包](outputs/ite-training-preflight-delivery-20261104.zip) 记录冻结源码 `2b6bb4e`、镜像导出重载及 SHA-256 清单。[SwanLab ceuc4nb6](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/ceuc4nb6) 已上传 144 次运行，实际上传的本地归档 1,500 文件逐一核验；未独立下载服务器副本。本轮没有追加策略或独立验收，下一项修改须另行确认。

2026-11-04 的 [固定 8 批训练来源实验](docs/training-freshness-results.md) 完成 **144 次开发运行**，宿主机及断网 Linux 各 **83 项测试通过**。相对 adaptive 无上限，突变分类错误率 .261863 → .254196、回归 NMSE .666351 → .589695；渐变 .271123 → .238751、.741380 → .492508。但对历史 legacy 的四项恢复门槛仍失败，**未晋级，默认不变**；分类突变 seed 7 反而退化，周期分类等于静态是因为没有上线，不能只看均值宣称成功。已先归档 [NR-010](docs/negative-results.md)，再完成四层诊断。

本轮原始目录 `outputs/training-freshness-20261104`；[验证 JSON](docs/validation/2026-11-04-training-freshness.json) 保存 87 次独立门控、198 次来源切分和 144 次检查点恢复审计。SwanLab [yhpzfjkd](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/yhpzfjkd) 的 1,506 个原始文件逐一核验；[交付包](outputs/ite-training-freshness-delivery-20261104.zip) 含镜像、源码 `d88fd71`、原始归档与校验清单，[外部校验](docs/validation/2026-11-04-training-freshness-delivery.json) 纳入 Git。该历史报告形成时预检尚为待确认提案；后续已另获批准并完成实现、容器和开发配对，结论见上方 NR-011。

2026-11-04 已确认的 [启动标注供给实验](docs/startup-label-results.md) 完成 **144 次开发运行**，宿主机及断网 Linux 容器各 **78 项测试通过**。同一 864 标签预算下，启动 144 相对启动 0 的突变分类错误率 .261863 → .308051、回归 NMSE .666351 → .876657；渐变也退化，**未晋级，默认不变**。日志证实提前供给主要增加旧概念标签，首训仍缺新概念样本；已按 [NR-009](docs/negative-results.md) 归档。后续训练时间上限实验已另获确认，按新预登记执行。原始结果保存在 `outputs/startup-labels-20261104`。

[本轮 SwanLab 归档](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/x32h105t) 的 1,524 个原始文件已逐一校验；[验证 JSON](docs/validation/2026-11-04-startup-labels.json) 和 [新镜像交付包](outputs/ite-startup-labels-delivery-20261104.zip) 分别保留诊断证据与断网复现材料，镜像源码提交为 `f73a5f5`。

2026-11-04 新一轮优化完成 **1,088 次运行**：标注/候选治理开发消融 360、扩展模拟与模型 228、新种子独立验收 420、压力测试 80；宿主机与断网 Linux 容器各 **71 项测试通过**。新增均匀/自适应标注、候选容量与等待治理、二次模型、离线 mock 接口，并修正周期首次变化的离线漏计。实现、结果及失败边界见 [本轮优化报告](docs/local-optimization-results.md)。

新种子 `211、223、227、229、233` 中，自适应调度的周期分类/回归损失为 **.481120 / 1.228214**，旧默认为 .497808 / 1.471517；但分类周期仍略高于静态，突变、渐变超过容忍度，**候选未晋级，默认保持不变**。这五个种子此后仅作历史对照。完整来源、配对差值及审计见 [本轮验证记录](docs/validation/2026-11-04-local-optimization.json)，云端为 [1,088 次运行归档](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/wku1evw8)。

本轮 [镜像交付包](outputs/ite-local-optimization-delivery-20261104.zip) 包含冻结镜像、源码、复现脚本和报告；[逐文件 SHA256SUMS](outputs/ite-local-optimization-delivery-20261104/SHA256SUMS) 及 [外部校验记录](docs/validation/2026-11-04-local-optimization-delivery.json) 分别核验包内文件和 ZIP。原始预测/日志保存在上述 SwanLab 归档，已核验 12,410 个原始文件。

2026-11-04，使用提交 `692defc` 的干净 Linux 镜像，在 **4 CPU、4 GiB、CPU 推理、断网**条件下完成 **540 次主矩阵运行和 40 次压力测试**。配置冻结后使用独立种子 `101、103、107、109、113`，流长度 96 批；580 次运行的损失与原 Windows 矩阵完全一致，计时单独记录。宿主机和 Linux 容器各 **42 项测试通过**。完整来源、诊断、成本和晋级判定见 [容器复现验收记录](docs/validation/2026-11-04-container.json)。

未来标签门控在周期回归两类任务均达到同矩阵静态基线，但在突变、渐变场景超过预设退化容忍度，历史复用方案同样未通过。因此 **`legacy` 保持默认，窗口自适应保持关闭**。本轮不修改冻结参数再次调优；后续开发继续使用开发种子。

第一阶段 `d0ed8d2` 的 117 次模拟运行和第二阶段 Windows 归档均保留。下表为第一阶段历史结果（28 批、种子 `7、19、43`），阶段二宿主机每组的实际版本和 dirty 状态见 [历史验收记录](docs/validation/2026-11-03-phase2.json)。

| 分类场景 | 静态错误率↓ | 周期更新错误率↓ | 漂移触发错误率↓ |
| --- | --- | --- | --- |
| 无漂移 | 0.0582 | 0.0625 | 0.0582 |
| 突变 | 0.6250 | 0.4049 | 0.4036 |
| 渐变 | 0.5109 | 0.3831 | 0.4164 |
| 周期回归 | 0.3733 | 0.4315 | 0.4371 |
| 协变量变化 | 0.0711 | 0.0651 | 0.0711 |
| 短暂噪声 | 0.0791 | 0.0831 | 0.0791 |

以上为第一阶段三个种子的均值，流长度 28 批、标签延迟 2 批。漂移触发在无漂移和仅协变量变化场景不做更新；突变、渐变场景相对静态模型有改善，但**周期回归仍劣于静态基线**。分类突变消融中，启用历史窗口自适应的错误率为 0.4624，固定候选搜索为 0.4036，因此策略自适应默认关闭。回归各场景和标准差见 [完整汇总 CSV](docs/validation/2026-11-03-aggregates.csv)，分析见 [第一阶段验证报告](docs/validation.md)。

第一阶段最多申请 672 个流内标签，最多消耗约 1.73 秒增量候选训练墙钟时间，未调用大模型。模拟器中的线性关系翻转有意制造明显退化；结果只验证本地机制，不能推出官方得分或真实工业泛化表现。

- 本地交互报告：[最终矩阵](outputs/validation-final-20261103/report.html)、[默认演示](outputs/demo-final/report.html)。新运行还会写入 `diagnostics.json`，其中的检测延迟、漏检、误报、重复告警和漂移后累计损失只由离线场景真值计算，控制器不会读取这些真值。
- 云端完整记录：[117 次最终矩阵与校验归档](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/vyzmljd3)。
- 阶段二云端记录：[phase2 实验归档](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/mgttpd1y)。归档含 586 个策略运行，SDK 报告上传 587 个对象；ZIP 内原始文件数量及逐文件哈希另见清单。归档 SHA-256 为 `08c2d1888c99a6fcf3fb55b95b4ed777e31890a97877cc5e010e494da5f30ca0`。镜像 tar 与容器交付回执保留在本机交付目录。
- 阶段二结论：future-32/64/96 在周期回归场景均优于同矩阵静态基线，但候选和历史复用策略在突变、渐变场景超过预设退化容忍度，`candidate_passed=false`、`history_reuse_passed=false`。因此 `legacy` 继续作为默认策略；失败原因和压力测试边界见 [阶段二验证报告](docs/validation.md)。
- 干净镜像复现：[580 次 Linux 容器实验归档](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/4hl949mi)，ZIP 内 6,687 个原始文件的哈希全部通过核验，归档 SHA-256 为 `7293612fdf3c32b49fcbb9e08459ad0da0b7bb7daf936c5515c971f4c168b2ce`。
- 本机镜像交付包：[ite-delivery-20261104.zip](outputs/ite-delivery-20261104.zip)，内含镜像 tar、冻结源码、验收记录、复现脚本和 [SHA256SUMS](outputs/ite-delivery-20261104/SHA256SUMS)。实验原始日志/预测从上述 SwanLab 归档获取，交付包不加入 Git。

## 评测与验收原则

- 先对当前批次预测，再允许申请其标签；标签达到约定延迟后才能参与训练和决策。
- 测试流全部标签只供隔离的离线评分器使用，不能传给更新策略。
- 候选训练样本与候选选择样本分离，预处理仅拟合训练部分。默认按时间顺序切分；实验选项 `selection_split=recent_disjoint` 允许来源时间交叠，但标签实体必须互斥，最终上线仍使用冻结后产生的独立标签。
- 同时观察无漂移误触发、漂移后恢复、累计性能、更新次数、标注与训练成本。
- 不设定虚构的官方评分公式；本地报告分别呈现收益与成本。
- 更新失败、候选退化和预算耗尽时保留可预测的已部署模型。
- 所有训练、调参、候选评估与上线决策从开发第一轮开始留痕。

## 外部依赖与实际限制

检查日期：2026-11-04；实验与镜像首次验收日期为 2026-11-03。

| 依赖或限制 | 当前情况 | 处理方式 |
| --- | --- | --- |
| 官方公开数据、SDK、评分脚本 | 尚未提供 | 用模拟适配器开发；取得后再对齐正式协议 |
| 正式资源、标签规则和评分公式 | PDF 未给出具体数值 | 保持配置化；不声称与正式评测一致 |
| SwanLab | SDK 0.10.3 已安装，mring-Y 账号云端上传已成功 | 完整本地日志加显式云端回放/归档；正式格式仍待官方规范 |
| PyTRiO / 获准大模型 | 尚无服务地址、额度、调用规范 | 预留受控接口；本地规则决策不冒充大模型决策 |
| Docker | Docker Desktop 4.98.0 / Engine 29.9.2，Linux 引擎已运行；32 CPU、约 15.3 GiB 内存；Docker Hub 已恢复，`python:3.12-slim` 可解析 | 已按 4 CPU / 4 GiB 构建、断网运行、导出/导入并生成交付校验清单；基础镜像固定为 `python:3.12-slim@sha256:b18b261e1b4974b4f321451ad5251ded85abb22c2b8b262da527dda1d031ab30`；正式配额仍待官方确认 |
| 本机运行时 | 项目 `.venv` 使用 Codex Python 3.12，NumPy 2.3.5；系统另有旧 Python | 核心只依赖 NumPy；明确指定项目解释器，避免误用 Python 2.7/3.9 |
| GPU | RTX 5070 Laptop，约 8GB 显存 | 当前用 CPU；不以本机部署 27B 模型为前提 |
| 训练时间约束 | Windows 进程启动与终止存在系统调度开销 | 默认预留 1.5 秒启动/清理余量，余量不足不启动训练；实际开销完整计入，正式硬限制需评测环境执行 |

## 官方数据到位后的接入顺序

1. 核对任务类型、字段、时间顺序、静态基线与允许使用的信息。
2. 按 SDK 确认标签申请、延迟、标注预算以及阶段切换协议。
3. 实现官方数据适配器，使用官方脚本校验本地回放结果。
4. 依据正式评分公式调节检测、搜索与更新成本，重新进行消融实验。
5. 对齐《实验记录规范》，确认开发期云端记录与正式离线日志的提交方式。
6. 使用获准的 PyTRiO 模型/服务，确认离线评测如何调用及计量 Token。
7. 在正式资源限制下验证镜像、运行超时、输出格式和无人干预全过程。

## 版本管理

使用本地 Git，以需求规划、数据层、实验闭环和运行交付等可验收单元提交。原始赛题 PDF 纳入版本控制，数据生成物、模型输出、环境与密钥不纳入 Git。当前不配置远程仓库或推送。

具体设计及执行记录将保存在 `docs/`。

2026-11-05 近期标签互斥分配已完成，见 [结果与诊断](docs/recent-disjoint-results.md)、[渐变逐种子曲线](outputs/recent-disjoint-20261105/report.html)。宿主/断网Linux各152/152，两组共144次；渐变回归全程NMSE .719121300→.460348595，共同样本首次新预测3批2.673272→.447107。分类局部及周期存在退化，历史4项门槛仍失败，已归档NR-013，默认保持。范围与分配规则见 [预登记](docs/recent-disjoint-plan.md)。

任务级切分实验已完成，[结果与诊断](docs/task-specific-split-results.md)、[逐种子曲线](outputs/task-specific-split-20261105/report.html) 和 [预登记](docs/task-specific-split-plan.md) 保留完整证据。宿主162项测试通过，冻结Linux镜像断网复核162/162；144次开发矩阵中，分类渐变.242694→.224103、周期分类.482024→.477575、周期回归1.160223→1.080383，但分类突变.207935→.223235，历史四项门槛仍失败，已归档NR-014，默认不晋级。分类总训练增加24而最新单批仍12/12，非周期回归逐值不变；矩阵cgroup峰值和完整生命周期回执缺测。配置仍为 `configs/optimization-task-specific-control.json`、`configs/optimization-task-specific-split.json`。SwanLab已归档 [f44h8phy](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/f44h8phy)，镜像交付包为 `outputs/ite-task-specific-delivery-20261107.zip`，校验见 `docs/validation/2026-11-07-task-specific-delivery.json`。

2026-11-07 分类精确平局alpha优先已完成，[预登记](docs/classification-tie-plan.md)、[结果](docs/classification-tie-results.md)、[配对曲线](outputs/classification-tie-alpha-20261107/report.html)和[验收回执](docs/validation/2026-11-07-classification-tie.json)保留证据。宿主/断网Linux各175/175，144次开发矩阵中分类突变错误率.223234954→.224211516，seed19预测不变；回归全量预测保持。四项门槛失败、已归档NR-015，默认 `classification_tie_break=legacy` 保持。候选仅开启 `alpha_desc`，没有硬过滤或新场景路由。

本轮SwanLab [7s5w0kuz](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/7s5w0kuz) 已归档；最终镜像/源码/原始结果包为 `outputs/ite-classification-tie-delivery-20261107.zip`，完整校验见[交付回执](docs/validation/2026-11-07-classification-tie-delivery.json)。
