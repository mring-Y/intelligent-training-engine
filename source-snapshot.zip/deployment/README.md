# Runtime tokenizer assets

The active Harness decision model is `Qwen/Qwen3.5-4B`. Its four tokenizer/config/template files are stored in `deployment/tokenizer-qwen3.5-4b/`, with a copy of `tokenizer-qwen3.5-4b-manifest.json` as `tokenizer-manifest.json` inside that directory. The tracked manifest pins the Qwen ModelScope revision, file sizes and SHA-256 digests. The asset directory is ignored by Git; restore it from the manifest before building. No model weights are needed.

Download each file from `https://modelscope.cn/api/v1/models/Qwen/Qwen3.5-4B/repo?Revision=f09dfc75214c5f2f4940ae6a26c126ce93828a9b&FilePath=<name>`, then verify both its byte length and SHA-256 against the manifest. The live Demo and 4B worker reject a model or hash mismatch before any network request. Token counting uses the same local chat template as the request, with thinking disabled; the frozen FD001 Prompt is 960 tokens, below its 1250-token limit.

The original `Qwen/Qwen3.8-27B` files remain in `deployment/tokenizer/` for historical reproducibility. `tokenizer-manifest.json` at this directory's root still describes those original files; it must not be relabeled as 4B. The original verified files are also preserved in `outputs/pytrio-smoke-20261107/tokenizer/` on the development machine.

The submission package must include these assets, their manifest and their upstream source/license information. The runtime loads them with `local_files_only=True` and `trust_remote_code=False`; no download occurs during inference. Build from a committed source archive, then copy these verified assets into that build context. Do not copy authentication directories into the context or image.

Upstream source: https://modelscope.cn/models/Qwen/Qwen3.8-27B . The manifest records the exact reused files and upstream URL. A verified upstream license copy has not yet been archived; final competition submission still requires license review and attribution. The engineering image/package is not presented as an officially compliant submission.
