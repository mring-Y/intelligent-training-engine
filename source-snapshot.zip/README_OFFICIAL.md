# A/B package data adapter

`ite.providers` reads CSV and Parquet in the existing `OfficialDataProvider` interface. Use `CSVDataProvider` or `ParquetDataProvider`, then pass it to `run_policy(..., provider=provider)`; the regular CLI does **not** yet load a provider from a single `data_path` field.

```python
from ite.config import ExperimentConfig
from ite.providers import ColumnMapping, CSVDataProvider
from ite.runner import run_policy
from ite.training import BoundedTrainer

mapping = ColumnMapping(
    features=("sensor_1", "sensor_2"),  # explicit ordered feature list
    target="label",                     # binary 0/1 for classification
    sample_id="sample_id",              # unique nonnegative int64
    batch="batch_id",                   # dense zero-based batch IDs
)
provider = CSVDataProvider(
    "data/private/A/stream.csv",
    mapping,
    initial_train_path="data/private/A/initial_train.csv",
    initial_validation_path="data/private/A/initial_validation.csv",
    label_delay=2,                       # replace with the official label protocol
    max_labels=None,                     # None means no local request quota
)
config = ExperimentConfig(
    task="classification",
    n_features=len(mapping.features),
    n_batches=len(provider.batch_sizes),
    label_delay=provider.label_delay,
    label_mode="provided",
    harness_enabled=True,
    harness_backend="mock",              # offline development; select approved backend only when authorized
    harness_drift_only=True,
    deployment_validation="future",
    training_preflight=True,
    candidate_feasibility=True,
    max_labels=0,                         # with label_mode="provided", no local label quota
    max_tokens=20000,
    max_llm_calls=5,                      # Mock safety cap; real calls need durable ledger + authorization
)
with BoundedTrainer() as trainer:
    summary = run_policy(config, "drift", "outputs/official-A-run", trainer, provider=provider)
```

For Parquet, install `requirements-data.txt` and substitute `ParquetDataProvider`. Set the real A/B paths, target, feature order, sample ID, batch ID, initial train/validation sources, label delay and task-specific constraints from the official SDK. Preserve the official batch boundaries. The reader will not infer columns or encode multiclass/string labels.

The path by itself is insufficient: the adapter needs explicit field mappings and initial fit/validation data. Online batches expose features only. Runner commits predictions before it requests or releases labels; pending labels retain their source batch and configured delay. File input is validation-scanned and must not change during a run. A whole-stream scorer is optional and remains isolated until online execution ends.

Current support is numeric features, binary classification labels `0/1`, and numeric regression targets. Multiclass encoding, waveform/window extraction, entity or timestamp semantics, and RUL units must be aligned with the official task before use. These SDK/data details are still outstanding; do not claim A or B is fully plug-and-play until a real package is tested.
