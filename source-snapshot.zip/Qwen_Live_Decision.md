# Qwen 真实决策记录

## 2026-11-10 条件式 Demo：未执行

2026-11-10。本文件如实记录条件式Demo的最终状态：**NOT EXECUTED**。

用户已授权在C-MAPSS预登记正向条件全部通过时，自动执行最多3次真实Qwen调用。
本次FD001结果未通过该前置条件，因此没有创建付费请求，也没有绕过条件重试或更换策略。

| 前置条件 | 实际证据 | 判定 |
| --- | --- | --- |
| 有部署及后续实际预测 | 0部署、0上线后样本，预测始终v0 | 未通过 |
| 全流RMSE严格低于静态 | static = Harness = 21.067320724574518周期 | 未通过 |
| 上线后同样本RMSE严格低于静态 | 无上线后样本，RMSE为null | 未通过 |

机器证据：[assessment.json](outputs/cmapss-tree-harness-20261110/host-pair/report/assessment.json)。
原始Mock事件：[events.jsonl](outputs/cmapss-tree-harness-20261110/host-pair/drift/events.jsonl)。
阴性归档：[NR-022](docs/negative-results.md)。

| 真实API审计项 | 本轮状态 |
| --- | --- |
| 模型/客户端执行 | 未调用TrioLLMClient；未请求Qwen/Qwen3.8-27B |
| 请求数 | 0 |
| 真实服务端Token | 0（没有发出请求） |
| 费用 | 0元 |
| 原始响应JSON | 无，未请求 |
| Qwen公开reason | 无，未请求 |
| 端到端请求延迟 | 无，未请求 |
| 超时/重试 | 无真实请求；没有重试 |

本轮唯一的`RETRAIN_SMALL`和理由“Observed degradation; request bounded training.”来自本地Mock，
不能作为Qwen推理、真实Token或保守Prompt有效性的证据。8个Mock Token单独记账。

已确认的条件式安全边界仍记录于[本轮方案](docs/superpowers/plans/2026-11-10-cmapss-tree-harness.md)：
最多3请求、费用<0.05元、15秒硬期限、零重试；网络超时即fail-closed，并以当时已部署模型完成预测。
这些边界**本轮未通过真实请求验证**，不能将历史超时测试或Mock结果包装成新的真实演示。

拟注入的提示句为：

> 当前模型为决策树，对样本规模极度敏感。若观测到的 Loss 波动未伴随剧烈特征漂移，强烈建议输出 DO_NOTHING，避免破坏已有分布。

这句话本轮未发送给Qwen。当前LLM观测契约不包含特征漂移幅度，未来若执行必须如实说明其不可见，
不能假设模型已经取得此证据。本轮没有改动真实API profile白名单或默认配置。

## 2026-11-11：C-MAPSS Tree 防守决策 Demo

本次为在同一公开FD001开发流上重放已冻结配置的Harness决策链路，不做性能调参或晋级；只用当前已释放Loss和历史筛选审计作为决策上下文。

流完成：18/18批。真实请求：1/2；已结算费用¥0；未结算请求预留¥0.01374962，最终扣费未知；熔断状态：`client_timeout`。

### 请求 1

触发step：10；客户端端到端延迟：15.202424999999948秒；状态：`client_timeout`。

Token用量未知（client_timeout；没有服务端结算）；本次费用预留¥0.01374962。

发送的Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 4,
      "loss": 0.23438354955361418,
      "labeled_samples": 256
    },
    {
      "source_step": 5,
      "loss": 0.3209712609445505,
      "labeled_samples": 256
    },
    {
      "source_step": 6,
      "loss": 0.21461934145799855,
      "labeled_samples": 256
    },
    {
      "source_step": 7,
      "loss": 0.2055339892602111,
      "labeled_samples": 256
    },
    {
      "source_step": 8,
      "loss": 0.5449269694844822,
      "labeled_samples": 256
    }
  ],
  "drift_alarm": true,
  "remaining_label_budget": null,
  "remaining_token_budget": 3600,
  "model_age_batches": 11
}
```

原始响应JSON：没有响应JSON。

Reason：未知，未收到可解析的Qwen响应。

15秒超时后触发Fail-Closed；客户端不重试，保留已部署模型完成剩余预测。
本决策流不提供全流RMSE晋级结果；先前NR-022及原始对照保持冻结。
本次历史候选被拒绝属于筛选结果，不能改述为独立未来门控拒绝。

## 2026-11-12：C-MAPSS Tree 防守决策 Demo（Qwen/Qwen3.5-4B）

本次为在同一公开FD001开发流上重放已冻结配置的Harness决策链路，不做性能调参或晋级；只用当前已释放Loss和历史筛选审计作为决策上下文。

本轮费率：Prefill ¥1.49/M，Sample ¥4.54/M。

流完成：18/18批。真实请求：1/2；已结算费用¥0.00158930，无未结算请求；熔断状态：`None`。

预测样本：4493；实际版本：v0: 18批；训练尝试/部署/回滚：0/0/0。

### 请求 1

触发step：10；客户端端到端延迟：9.257662600000003秒；状态：`ok`。

服务端Token：输入 960、输出 35，合计 995；按配置费率估算¥0.00158930（不是服务商扣款回执）。

发送的Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 4,
      "loss": 0.23438354955361418,
      "labeled_samples": 256
    },
    {
      "source_step": 5,
      "loss": 0.3209712609445505,
      "labeled_samples": 256
    },
    {
      "source_step": 6,
      "loss": 0.21461934145799855,
      "labeled_samples": 256
    },
    {
      "source_step": 7,
      "loss": 0.2055339892602111,
      "labeled_samples": 256
    },
    {
      "source_step": 8,
      "loss": 0.5449269694844822,
      "labeled_samples": 256
    }
  ],
  "drift_alarm": true,
  "remaining_label_budget": null,
  "remaining_token_budget": 3600,
  "model_age_batches": 11
}
```

原始响应JSON：

```json
{"action":"DO_NOTHING","reason":"损失波动剧烈且伴随漂移报警，但缺乏明确趋势证据，且预算为null，维持现状风险可控。"}
```

Qwen结构化动作：`DO_NOTHING`。
Qwen Reason：损失波动剧烈且伴随漂移报警，但缺乏明确趋势证据，且预算为null，维持现状风险可控。

本次Qwen选择DO_NOTHING，宿主没有为该决策启动重训；独立未来门控保持可用。这只展示单次保守决策，不证明未运行候选必然更差，也不构成普遍因果结论。

本决策流不提供全流RMSE晋级结果；先前NR-022及原始对照保持冻结。
本次历史候选被拒绝属于筛选结果，不能改述为独立未来门控拒绝。

### 4B 本轮核验与答辩用语

| 核验项目 | 本轮实测 |
| --- | --- |
| 调用模型 | `Qwen/Qwen3.5-4B` |
| 真实请求 / 重试 | 1 / 0（上限2次，不为用满额度追加请求） |
| step10 Loss（source4–8） | 0.23438 → 0.32097 → 0.21462 → 0.20553 → 0.54493 |
| Action | `DO_NOTHING`，JSON一次解析成功，无修复 |
| 客户端端到端延迟 | 9.257662600000003秒，包含worker启动、本地tokenizer和网络；不是纯服务端生成耗时 |
| 服务端用量 | 输入960 / 输出35 / 合计995 Token |
| 配置费率与本地结算估算 | Prefill ¥1.49/M、Sample ¥4.54/M；¥0.00158930，服务商扣款回执未获取 |
| 单次最大预留 / 未结算预留 | ¥0.00244362 / ¥0，未触发¥0.03上限 |
| 运行结果 | 18/18批、4493条、全部v0；续训/部署/回滚0/0/0；初始与最终checkpoint逐字节相同 |
| tokenizer | Qwen官方ModelScope固定revision，四文件SHA-256核验；实际请求离线重建计数960，与服务端一致 |
| Linux回归 | 487/487，断网、4CPU/8GiB、68.129秒、峰值530878464字节、无OOM |
| 历史文件隔离 | 旧27B输出、claim/ledger及tokenizer共21个文件指纹未变 |

答辩可用表述：**本次4B模型在15秒截止内返回DO_NOTHING，Harness据此没有启动本次重训，保持当前树模型继续完成全部预测；候选筛选、独立未来门控和资源保护继续保留。** 这展示了一次成功的保守维护链路，不构成“4B普遍更快、更准确”或“避免的候选必然无效”的证明。

数据范围：本轮沿用NR-022冻结的公开`train_FD001.txt`发动机分区（unit1–60训练、61–80验证、81–100流），不是新下载官方CPU-C包的验证集，也不是官方隐藏测试流。

Reason原文中的“预算为null”不够精确：`remaining_label_budget=null`表示标签由平台协议提供；当时Token预算为3600，续训时间预算20秒，费用上限¥0.03，均未耗尽。因此保留原文而不包装成完全正确的预算推理。此次没有改Prompt，也没有为改善Reason再次请求。

实际Observation与旧27B真实请求逐字段一致。预检文件中的messages来自历史Mock参考（其剩余Token字段为1000），实际请求为本轮配置3600；实际请求的离线重建及本地/服务端960 Token一致性另见`actual-request-evidence.json`，不能把参考messages冒充真实请求字节。

来源记录限制：提权运行中Git读取未成功，原始`provenance.json`和claim中的`source_commit=unavailable`、`source_dirty=null`保留不改写。core SHA-256仍为`95b636f2b4f175a0a8c670695cd46dea7e117fb7ec93d9f180a3a48ac303d670`，与已验证的源码提交`a21a831541a2181ae5e85ceb4f607556994d3590`一致；真实执行前另有本地文档冻结提交`086ec6241f62d0a8b30a44e23b700a3d3158f286`。这属于补充来源链，不能声称原始运行日志已直接记录Git提交。

原始事件与真实用量：[events.jsonl](outputs/cmapss-tree-qwen4b-live-20261112/drift/events.jsonl)、[独立账本](outputs/cmapss-tree-qwen4b-live-20261112/paid-call-ledger.json)。离线核验：[final-verification.json](outputs/cmapss-tree-qwen4b-live-20261112/final-verification.json)、[实际请求重建](outputs/cmapss-tree-qwen4b-live-20261112/actual-request-evidence.json)、[成本审计](outputs/cmapss-tree-qwen4b-live-20261112/cost-audit.json)。这些核验不产生新请求。

## 2026-11-12：官方MLP锚定27B Teacher试点

当前测试流为公开验证集的时序模拟，不代表官方隐藏测试集的真实表现。

本次模型为Qwen/Qwen3.8-27B，控制官方A/B/C CPU MLP。共27次成功JSON响应，服务端15858输入+1045输出=16903 Token；延迟7.596737–8.869293秒；19次DO_NOTHING、3次RETRAIN_SMALL、5次RETRAIN_LARGE。费用按Token及核验费率估算¥0.07638075，服务商实际取整扣费未核验。

全量Observation、原始JSON、Reason、Token/延迟见`docs/official-sft-pilot-20261112.md`及`outputs/official-sft-20261112/teacher/session/teacher-events.jsonl`。C两条大窗口续训降低RMSE约3.06/3.17周期，却增加高估，故全部27条留review，train/eval均0；无4B LoRA训练。

补充24次预算停止未及时生效，27次完成后才落盘熔断；原30次调用上限未超过。Token估算为¥0.07638075。服务商价目页含ceil但实际聚合粒度未知；用户随后反馈界面两位小数账目约¥0.07，支持本轮在¥0.50内，精确扣费回执未提供。按输入/输出分别取整的¥0.54仅是假设、不是实际账单。原始完成manifest与完成后账本状态分开保留。

原始请求23：

```json
{"action":"RETRAIN_LARGE","reason":"漂移告警且Loss持续高位，需大窗口续训以覆盖分布变化并降低RMSE。"}
```

该建议在step7冻结、step9未来门控通过、step10起生效；RMSE改善但高估安全项不合格，不作为训练标签。

补充账目核验：用户随后反馈界面保留两位小数的本轮账目约¥0.07，支持未超过¥0.50预算；精确扣款回执未提供。本地Token计算仍保留为¥0.07638075估算，24次补充停止失效事实保持不变。
