# Triple concept-drift Mock report

**Result:** The frozen Mock flow completed four `RETRAIN_SMALL` attempts. Attempt 1 was rejected by the existing selection filter. The next three consecutive decisions each trained a candidate, froze it, received 96 post-freeze labels from a later source batch, passed the independent gate, and deployed. This is local protocol evidence; `official_eligibility_verified=false` remains the machine result.

The report reads the preserved run at `outputs/three-abrupt-20261108/mock-preflight`. It did not retrain or create a new flow. The run used `make_simulation`, `MockLLMClient`, classification, seed 7, 30 batches of 96, 512 initial training samples, 256 initial validation samples, label delay 2, future validation, and the original 192-batch window / alpha {0.1, 10.0} whitelist. The simulation labels are available according to this local protocol; they are not an A/B package or official evaluation stream.

## Stream

Zero-based batch intervals are `[0,2) A`, `[2,10) B`, `[10,18) A`, `[18,30) B`. The target relationship flips at batches 2, 10 and 18. The controller and Mock receive no regime ID or future change point. The independent offline scorer uses these values only after policy execution.

The initial ridge model has eight feature coefficients plus an intercept, with a fixed linear basis. No GP, model population or feature-family changes were involved. The initial model's error rate by offline regime was A `[0,2)` **0.0885**, B `[2,10)` **0.9284**, A `[10,18)` **0.7096**, B `[18,30)` **0.5859**. Those later-regime averages mix multiple deployed model versions and cannot attribute an improvement to one update. Full regime residuals and score/target correlations are in `outputs/three-abrupt-20261108/offline-audit.json`.

## Decisions and gates

| Decision / attempt | Action batch | Candidate training sources | Selection source | Freeze | Future gate source / batch | Gate loss: incumbent to candidate | Result; model effective |
| --- | ---: | --- | ---: | ---: | --- | ---: | --- |
| decision-1 / attempt-1 | 4 | 0–1 | 2 | none | none | selection .9375 to .9479 | Rejected by selection; no freeze |
| decision-2 / attempt-2 | 8 | 4–5 | 6 | 8 | 9 / batch 11 | .90625 to .09375; gain .81250 | Accepted; v1 from batch 12 |
| decision-3 / attempt-3 | 15 | 11–12 | 13 | 15 | 16 / batch 18 | .93750 to .03125; gain .90625 | Accepted; v2 from batch 19 |
| decision-4 / attempt-4 | 22 | 18–19 | 20 | 22 | 23 / batch 25 | .89583 to .13542; gain .76042 | Accepted; v3 from batch 26 |

Each gate used 96 labels whose source batch was strictly later than its candidate's freeze batch, and the established `min_gain=0.02` rule. Deployments at batches 11, 18 and 25 first affected predictions at 12, 19 and 26 respectively. The gate's evidence window passed the existing rule; it does not promise that the next concept will remain unchanged. In particular, the stream flips again at batch 18 just as the second gate completes, so the second accepted candidate begins predicting under a new regime. This audit does not claim that each deployment improves its entire subsequent regime.

The first decision is retained because it was a real decision and training/selection attempt: it fit both allowed alphas on sources 0–1, selected on source 2, and the candidate's .9479 error exceeded the .9375 incumbent. The controller correctly refused to freeze it. Decisions 2–4 are the three consecutive complete training/freeze/future-gate chains. Across the run: 4 decisions and attempts, 8 candidate fits, 1 selection rejection, 3 candidates frozen, 3 future gates accepted, 3 deployments, 30/30 predictions, 2,880 labels requested, 2,688 released and 192 still pending at stream end. Mock accounting was 4 calls / 32 simulated tokens; real tokens were 0. Run wall time was 2.222 seconds and measured fitting time was 1.380 seconds on this host; these are not official-machine performance benchmarks.

The whole-run classification error rate was **0.6771**. There was no paired static run in this profile, so this is not a measured gain. `stable`, `gradual`, regression and official A/B data were not measured in this run. The gate chain verifies ordering and configured acceptance; it is not proof of competition performance or official iteration eligibility.

## Relation to 144 Mock runs

The separate 144-run matrix completed 13,824 batches with zero real tokens and 138 Mock calls: 72 normal runs, 36 `invalid_json`, and 36 `token_exhausted`. It exercised call limits and Fail-Closed continuation. Of the fault runs, 24 per fault mode actually triggered that fault; 12 per mode had no eligible call and therefore did not test fault handling. This matrix used 96-batch conventional scenarios and did not test the 30-batch triple-change profile. The present run supplies that specific repeated-gate case; the two records are complementary.

## Latency and official environment

The only real request in the separate triple-change paid run hit the hard deadline at **15.0054 seconds**, causing `STATIC_FALLBACK` and completion of all 30 predictions. Its usage and billing remain unknown, with a 2,560-token / ¥0.03017216 reservation retained. No further paid request was sent.

That was a public-network observation. No official in-network endpoint, latency sample, or service timing receipt is available. Internal evaluation may have lower network transit time, but there is no evidence that total latency will be “greatly reduced.” Tokenizer/process startup and service time are also part of the 15-second deadline. The hard deadline remains active; an internal request that exceeds it will fail closed in the same way.

## Reproduce the existing Mock profile

Use a new output directory; this command is free and runs the fixed profile, not an evaluation claim:

```powershell
python -m ite.three_abrupt --backend mock --output outputs/new-triple-mock
```

Inspect `iteration-audit.json` for `future_gate_chains`, `engineering_target_met` and the source IDs. The existing production decision rules and gates are not relaxed by this profile. Source commit `6f03dff1df144aec0b7e0ab8abc5fb35cde673b4`, source SHA-256 `d825a0cfa647b8f72639cddbfcd977649b4c7f3f1eed3a3f8ac79df66dc9de1c`. Machine validation: `docs/validation/2026-11-08-three-abrupt.json`.
