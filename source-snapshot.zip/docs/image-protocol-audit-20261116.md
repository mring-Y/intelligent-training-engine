# 现有镜像与平台续训公告核对（2026-11-16）

【诊断结论】当前可确认Docker-save上传格式、官方CPU模型与真实续训底层能力；不能确认现有默认入口符合平台续训评测协议。默认入口是公开开发对照程序，没有读取平台逐轮父检查点的命令参数，也没有按指定交付目录输出本轮`checkpoint.npz`及配套真实训练历史。模型本身具有可复用的官方格式，接入与交付仍需补齐。

本次仅阅读文件、核验归档并统计已有产物，没有修改生产/测试/实验代码，没有新训练、预测实验、费用、平台上传或试运行。公告不是具体作品的失败回执；没有读取到本队当前平台镜像状态，不能据公告判断平台故障原因。

## 核对对象与证据

对象为当前最新策略候选`ite-ac-policy:20261115-v1`，归档`outputs/ac-policy-integration-20261115/harness-ac-policy-20261115.tar`。旧C2镜像保留，未因本次审查重建或替换。

| 要求 | 本次复核结果 | 判断 |
| --- | --- | --- |
| Docker-save镜像归档 | 317,349,376字节，SHA-256为`c05ee34b6bd1b0dbdd5885d0a3150689cd729318d31d9ce77f87abe59aa3b692`，与原导出回执一致 | 满足归档格式检查 |
| 镜像配置、层与源码存在 | `manifest.json`、配置与43个层引用存在；45个实际SHA-256 blob内容摘要全部匹配；配置为linux/amd64 | 归档可读取，未发现内容损坏 |
| 可导入镜像 | 2026-11-15原始`docker load`日志确认成功，身份一致 | 已有实际验证；本次不重跑Docker |
| 代码、配置、官方baseline | 从实际tar各层读取，最新runner、adapter、worker和三个官方ZIP均与当前冻结本地文件哈希一致 | 已包含实际运行资源 |
| 官方模型真实续训 | A/C检查点包含权重、Adam一二阶矩、标准化及累计步数；已有原始事件和公开开发验收记录 | 底层能力具备 |
| 平台逐轮父检查点 | adapter能接收外部checkpoint，但默认runner构造模型时没有传入；CLI没有父检查点、平台训练集、平台轮次参数 | 默认入口未接通 |
| 独立预测 | 三个官方ZIP内均含`baselines/predict.py`，提供`--checkpoint`与标准输入JSONL推理；既有适配测试验证过一致性 | 模块存在；平台可直接调用的命令/挂载接线未验收 |
| 标准产物 | 默认输出54个分区/对照结果及`selected.npz`；已有Linux完整输出没有名为`checkpoint.npz`的文件，抽检A/B/C均无本轮`training.json/history.jsonl` | 标准交付未接通，现有事件日志需由实际执行生成相应协议记录 |
| 64 MiB产物上限 | 最大selected为132,180字节；全部54个selected合计3,557,304字节；模型类NPZ合计8,253,864字节 | 模型体积足够小；未验证平台单轮产物目录及其总量约束 |
| 平台可用/协议校验/评测 | 本地记录明确`platform_interface_verified=false`，没有本队当前状态或正式评测回执 | 未验证；不能从公告推断失败原因 |

默认命令直接从实际tar配置读取：

```text
python -m scripts.run_heuristic_comparison --a-step7-replay --c-epochs 2 --output /app/outputs/ac-run
```

它加载镜像内的公开A/B/C包并运行54流对照，不是平台传入一个数据集、一份父模型、一轮预算后的续训适配入口。此前真实27B每包十轮是另一组开发记录，不能替代当前镜像在平台本轮实际接收父模型和执行训练的证据。

64 MiB约束与镜像tar大小分开核对：317 MB镜像大小不意味着模型产物超限。当前完整Linux对照输出为80,952,931字节，约77.2 MiB，包含日志、预测和多臂证据，不能整体当作平台模型交付目录；公告对哪些附属文件计入上限尚未给出完整合同。应将正式模型交付与完整实验记录分别存放，并对实际约定交付目录作总量检查。

## 续训真实性抽检

读取已有NPZ的`metadata`和数组，不执行模型或新增训练：

| 已有分区 | 初始Adam steps/epochs | 最终选定steps/epochs | 说明 |
| --- | ---: | ---: | --- |
| A-abrupt-train-heuristic | 80/20 | 90/25 | 真正从官方状态续接，最终哈希不同 |
| B-stable-train-heuristic | 825/15 | 825/15 | 按既定策略保留官方静态，未宣称本流发生B更新 |
| C-abrupt-train-heuristic | 6630/15 | 6648/21 | 保留优化器与标准化，实际续训及多次门控选择 |

这些产物是官方MLP格式，包含`w1/w2/b1/b2`、对应Adam一二阶矩、`mean/scale/metadata`，不是把其他序列化文件改为NPZ后缀。原始训练链见各分区`events.jsonl`与`summary.json`；正式平台轮次的父模型链仍需在对应入口真实建立，不能复制旧摘要冒充。

## 准备采用的升级策略（待本轮确认）

单一改动因素为**平台续训协议与交付适配**，保留A step7回放、B静态、C head-only/2epoch的现有策略、门控及预算。不得在该单元中顺便更改超参、训练来源或放宽效果门槛。

1. 明确平台训练/预测调用参数、挂载与单轮产物目录。优先核对平台实际示例和官方baseline；公告给出了原则，尚未给出完整命令合同，不猜造已适配结论。
2. 新续训入口必须读取平台指定父检查点，校验任务、特征schema、权重、优化器及标准化，并从其真实状态继续。父模型损坏或不兼容则明确失败，不回退到镜像内初始模型冒充父模型续训。平台未选用候选时继续使用平台指定父模型。
3. 在约定目录原子保存真正的`checkpoint.npz`，从真实执行生成训练摘要与历史，绑定输入父模型/训练输入/源码/输出哈希和步数；预测入口仅读取指定模型和无标签输入。不要只修改`selected.npz`的名称或补写历史元数据。
4. 先写有意义的失败测试，覆盖两轮平台父模型续接、实际优化器步数与状态、错误父模型拒绝、平台未选用候选、独立预测JSONL、输出不可覆写和单轮64 MiB总量。公告没有明确要求每轮必须更新参数；B保留父模型时应记录真实的零更新，若完整合同另要求每轮执行训练则再核对，不把零训练记录成续训。
5. 在固定依赖的4CPU/4GiB断网Linux容器验证真实调用和产物；仅在通过后重建版本、`docker save`导出并`docker load`核对，更新交付记录。平台上传/试运行与协议通过分别记录，不重复消耗未修复版本的次数。

本文件是可审阅的诊断与下一单元范围，尚未实施上述修改。仓库[AGENTS.md](../AGENTS.md)要求“每次代码修改、配置调参或新实验前……等待用户对本轮方案明确确认”，本次核对不代替修改授权。

## 证据位置与限制

- [镜像Dockerfile](../scripts/Dockerfile.ac-policy)、[默认runner](../scripts/run_heuristic_comparison.py)、[官方模型适配器](../ite/official_model.py)、[独立worker](../ite/official_worker.py)。
- `outputs/ac-policy-integration-20261115/records/15-image-export-receipt.json`、`14-docker-load.txt`、`09-image-inspect.json`以及未变的镜像tar。
- [原合入结果](ac-policy-integration-results-20261115.md)、[原验收索引](validation/2026-11-15-ac-policy-integration.json)。本轮没有变更原`engineering_passed=true/effect_passed=false`结论。
- 本机当前找不到Docker CLI，原Docker Desktop常用路径也不存在，本次归档审查直接读取tar；不声称在本会话重新执行过容器或平台测试。

## 同日容器补验与环境更正

用户随后取消PPT图像API生成，明确继续检查镜像兼容性。本次使用现有镜像与已有检查点做入口、加载及推理检查，没有新训练、策略实验、源码修改、付费请求或平台试运行。

**更正上一节环境判断**：不能仅凭PATH与`C:/Program Files/Docker/`不存在判断没有Docker。CLI实际在`C:/Users/LENOVO/AppData/Local/Programs/DockerDesktop/resources/bin/docker.exe`；普通沙箱对该路径返回拒绝访问，提升后的只读调用确认版本29.9.2。Linux引擎最初未启动，执行已有CLI的`docker desktop start --timeout 60`后可用，Docker Desktop为4.98.0。没有安装、升级、重配或清理Docker。本次现有镜像的实际容器验证已完成，因此原“本次未执行容器”的说明只适用于最初静态核对阶段。

所有执行检查均使用原`ite-ac-policy:20261115-v1`，4CPU/4GiB、`--network none`、`--read-only`，仅`/tmp`临时可写，公开已有模型目录以只读方式挂载。没有重新运行54流训练对照。

| 实际检查 | 结果 | 含义 |
| --- | --- | --- |
| 重新`docker load -i harness-ac-policy-20261115.tar` | 退出0，导入前后镜像身份均为`03a82fb4…` | 本机当前可导入原Docker-save归档 |
| 当前默认runner `--help` | 退出0，仅有output、official-python、c-epochs、a-step7-replay参数 | 实际仍是公开开发对照入口 |
| 当前runner传入官方续训示例的`--resume/--train/--validation/--stage-id` | 参数解析退出2，明确`unrecognized arguments`，未启动训练 | 默认入口未接收外部父模型和该组逐轮训练参数 |
| 直接`/opt/ite-official-a/bin/python -m baselines.predict --help` | 退出1，`ModuleNotFoundError: No module named 'baselines'` | 官方包在ZIP内，尚未注册为可直接发现的预测模块 |
| 显式设置对应ZIP的`PYTHONPATH`再调用预测CLI | 退出0 | 已有预测实现可用，缺少对外调用接线 |
| 运行5项已有兼容性测试，排除所有fit/续训测试 | 5/5通过，3.664秒 | A概率精确一致、B/C预测差小于1e-6、NumPy环境隔离、checkpoint摘要绑定、错误profile与同环境拒绝均通过 |
| 用各包自己的官方`Model.load`读取全部选定模型 | A/B/C各18份，共54份通过 | 已有NPZ确为官方可读取格式 |
| A/B/C各取7条公开输入，仅发送task和inputs，通过独立预测CLI加载已有abrupt/train选定模型 | 21/21返回标准JSONL；A六类label/score合法且概率和为1，B/C为有限非负outputs.value | 选定模型可独立推理，输入没有标签，挂载检查点哈希未变 |

上述5项已有测试位于`test_official_model_adapter.py`与`test_official_regression_parity.py`，仅选预测、隔离及拒绝不兼容输入的方法，没有运行会训练的resume一致性测试。21条直接预测属于格式/加载检查，不计算新的模型效果或独立验收指标。检查过的C选定sidecar均为margin=0、calibration=null，本次没有将非零校准策略遗漏到预测入口。

再次统计已有默认输出：54个`selected.npz`合计3,557,304字节，最大132,180字节，名为`checkpoint.npz`的默认输出文件数为0。完整多臂日志和预测目录80,952,931字节，不能整体作为64 MiB模型交付目录。正式单轮模型路径、历史记录与总量约束仍需适配。

**补验后的结论**：归档和模型格式已通过本机当前容器验证，独立预测在显式路由官方ZIP后可用；当前默认入口仍未具备平台父模型输入与标准单轮产物交付，实际平台合同与评测结果仍未验证。镜像未重建，策略和原效果判定未变；B保持静态本身不被本次公告直接判为不兼容。

新证据目录：`outputs/image-compatibility-20261116/read-only-v1/`。`compatibility-receipt.json`汇总检查、资源限制、归档与全部证据文件哈希，`01`至`09`记录帮助、预期失败、5项测试、21条预测、54次加载、load回执、镜像身份和引擎版本。原归档SHA-256仍为`c05ee34b6bd1b0dbdd5885d0a3150689cd729318d31d9ce77f87abe59aa3b692`。
