# CPU续训适配补齐完成记录（2026-11-16）

本文件是[实施结果文档](continuation-adapter-results-20261116.md)在容器和镜像交付完成后的最终补记。实施期间的阶段性“仍在执行”记录应以本页结果为准。

用户批准范围内，新增了外部父检查点的CPU续训入口、独立预测入口、真实history及标准checkpoint产物。策略未改：A step7 48条分层回放，B静态并如实保持父检查点，C head-only 2epoch；保留原筛选、独立future gate、5秒候选/20秒流/最多4次预算。没有新增依赖、远程模型调用、隐藏标签访问或平台试运行。

冻结代码提交为`8853fca01e1180adccdd9cc51127334f0f3f4fad`，ITE源码SHA-256为`d6a6d0552b4675c205ca48af5117cc9b03ebc7509b27202d5f4a72d9902400f2`。使用本地已核对父镜像`ite-ac-policy:20261115-v1`（`sha256:03a82fb40332b2e4ae96d3e1c2ee9b4a69ff41e2ee7e05fd2e8aaee91d06cfad`）构建，依赖和基础镜像摘要继承不变。

宿主新增聚焦测试19/19通过，完整测试736/736通过。Docker断网Linux完整测试736项中735通过，另1项为host-only skip，322.382秒，OOM=false，资源限额4 CPU/4 GiB。原全套第一次运行发生的一项旧`.venv-sft`导入15秒超时已保留；没有改动该时限，单项复核通过，第二次完整宿主回归全通过。

Linux断网协议检查使用已见公开数据，非效果验收。A/B/C各完成两轮并使用真实指定父模型与累计history；22项CLI检查、24条独立预测与官方预测器逐条一致。A首轮future gate通过、第二轮候选被拒绝；B两轮真实0训练且检查点哈希不变；C前两轮训练尝试分别为3与2，并均有1次future gate接受。历史缺失和验证数据复用都关闭更新；各模型目录均低于64 MiB。全部receipt、原始stdout/stderr和详细审计位于`outputs/continuation-adapter-20261116/linux-protocol-v1/`及其`records/`。

新镜像标签为`ite-continuation:20261116-v1`，Docker image ID为`sha256:03d09b8b489a9abca2a31af608a3cbc010e150947d365b6523acf5ab0a6c7e7c`。`harness.tar`来自实际`docker save`，大小317,788,672字节，SHA-256为`29c426ff06ebb8a4c8529648dc8114f1673b5b3bc7a789b97f0a0a270b14ae09`；实际`docker load`后ID一致，重新预测也与加载前结果一致。Docker Desktop输出OCI image-layout tar；归档含`oci-layout`、`index.json`和内容寻址blobs。

冻结源码交付包`source-v1.tar`大小40,284,160字节，SHA-256为`8226c2c030321ecd07a775a12dac12f50c69d4edc9af9f017217947830ab49dc`，248个成员哈希全部通过，路径均为相对路径。

### 仍待平台确认

平台没有给出完整的启动参数、挂载/输出合同或10轮调度说明。当前镜像定义的是**每轮一次调用**：首轮用`--from-baseline`，后续每轮传实际平台父模型及累计history。测试了连续两轮，但没有单进程自行循环十轮，也不能确认平台将按此合同重复调用。故本地证明入口、续训和Docker归档可用，不等于平台协议已接受或完成十轮隐藏评测。平台合同到位后应先逐项映射调用与父检查点，再决定是否需要适配调用编排；不得声称本轮已经过官方校验。

此前公开开发效果判定不变：A未达到预登记实质增益，B持平，C的公开流RMSE约下降2%，整体原判`effect_passed=false`。本补齐处理的是协议入口，不宣称三包超越baseline。

交付操作和文件列表：[DELIVERY.md](../outputs/continuation-adapter-20261116/DELIVERY.md)。SwanLab SDK 0.10.3的本地offline run为`e2u1724u`，含164份已校验证据；没有公开上传。
