# Official data provider

评委/队友的最短接入示例和限制见仓库根目录 [README_OFFICIAL.md](../README_OFFICIAL.md)。当前要提供路径和显式列映射；CLI没有单字段 `data_path` 工厂配置。

The public A package and evaluation SDK are not available locally yet. File ingestion is ready for numeric features and binary classification (targets 0/1) or numeric regression; multiclass labels, raw waveforms and RUL unit conversions need an explicit official task adapter. No target encoding or feature guessing happens implicitly.

```python
from ite.providers import ColumnMapping, CSVDataProvider, ParquetDataProvider
from ite.runner import run_policy
from ite.training import BoundedTrainer

mapping = ColumnMapping(
    features=("sensor_1", "sensor_2"),
    target="target", sample_id="sample_id", batch="batch_id",
)
provider = CSVDataProvider(  # choose ParquetDataProvider for .parquet
    "data/private/stream.csv", mapping,
    initial_train_path="data/private/initial_train.csv",
    initial_validation_path="data/private/initial_validation.csv",
    label_delay=2, max_labels=None,
)
# config.n_features/n_batches/label_delay must match the provider metadata.
# config.label_mode="provided" uses the complete observed batch, without an application quota.
with BoundedTrainer() as trainer:
    summary = run_policy(config, "drift", "outputs/official-development", trainer,
                         provider=provider)
```

Both initial files are separate from the evaluation stream. Each requires mapped features and target; optional IDs must be disjoint when supplied. Stream IDs are unique nonnegative int64, batch IDs are dense from zero, rows for a batch contiguous. The selected feature order is stable. Timestamp/entity columns can stay in a source file as metadata, but are never inferred as numeric features. Map actual official batch and entity identifiers explicitly; noninteger IDs require a deterministic SDK adapter.

Runner predicts and calls `commit_predictions` before requesting or releasing labels. Only the current committed batch can be newly requested; already pending older labels release on their original delay. A file containing target values does not make them public to the controller. The provider rejects requests for future/unknown IDs and cannot advance before commit. Official live callbacks can implement the same abstract methods without giving Runner target-bearing batches.

CSV uses standard-library row streaming; Parquet uses pinned PyArrow 22.0.0 record batches with threads disabled. Duplicate checks retain O(samples) ID metadata and O(batches) sizes. Feature/target memory is bounded by `max_batch_rows`, initial split row limits and pending delayed labels; this is not a claim of constant memory for arbitrary infinite streams. A validation pass reads the source before execution; features/targets from future batches are not supplied to policy code. Files must remain immutable after validation.

No simulated change points are assigned to official data. Full-stream Loss/accuracy are null unless an isolated `OfflineScorer` is explicitly supplied. The evaluator is called only after online execution; individual released labels continue to drive existing monitoring and future gates. Exported predictions include numeric sample IDs and batch offsets, including unequal batch sizes, without pickle.

Install `requirements-data.txt` for file Parquet use. The final CPU image uses `requirements-runtime.lock` and includes the real HTTP client, public replay SDK, PyArrow and verified local tokenizer assets; it contains no LLM weights. Official service addresses, label callback timing and task-specific preprocessing still need alignment when the SDK arrives.
