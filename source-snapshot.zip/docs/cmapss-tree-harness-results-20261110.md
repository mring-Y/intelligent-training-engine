# C-MAPSS Tree Harness：无正向收益，保守拒绝有效

2026-11-10，用户明确确认后的单次开发对照。固定公开FD001的20台发动机流全部完成，
**static与Harness RMSE均为21.067320724574518周期**。Mock选择的192条短窗口候选在隔离筛选上更差，
系统拒绝替换并保持v0；没有部署，因此不满足进入真实Qwen Demo的预登记条件。
这证明了不合格候选的保底链路，没有证明本轮重训收益或真实大模型能力。

## 固定协议与判定

训练unit1–60：11942条；验证unit61–80：4196条；stream unit81–100：4493条。
沿用原准备包、18批边界（17×256+141），不重新分批；部分批次跨发动机边界。
按发动机编号及设备内cycle递增运行。24个settings/sensors作为特征，unit/cycle/target/ID仅供审计，
RUL=min(125,max_cycle−cycle)。这属于公开run-to-failure训练轨迹的开发切分，不是NASA原生删失测试集或隐藏B验收。
原NASA下载不可用，本包来自已记录commit/blob的GitHub镜像，官方字节一致性仍未核验；本轮不改变来源声明。

Tree固定深度6、最多64叶、最小叶5、seed7；窗口192/384/768；label_delay=2，标签provided；
recent_disjoint筛选，独立future gate。Tree单次5秒、自适应总20秒，最多12候选、5次Mock。
Mock保持原normal逻辑，不强制LARGE。完整参数见[配置](../configs/cmapss-harness-tree.json)，
预登记见[已确认方案](superpowers/plans/2026-11-10-cmapss-tree-harness.md)。

| 指标 | Static Tree | Mock Tree Harness |
| --- | ---: | ---: |
| 全流样本 | 4493 | 4493 |
| RMSE（周期） | 21.067320724574518 | 21.067320724574518 |
| MAE（周期） | 15.894370029928847 | 15.894370029928847 |
| 残差均值（预测−目标） | -3.2829378952789776 | -3.2829378952789776 |
| 残差方差 | 433.05432128782815 | 433.05432128782815 |
| 实际新版本预测样本 | 0 | 0 |
| 部署 / 回滚 | 0 / 0 | 0 / 0 |

三项正向条件均未通过：没有实际部署与后续预测；全流没有严格下降；无上线后样本，
上线后RMSE为null。判定后先归档[NR-022](negative-results.md)，没有再调参或改用LARGE重跑。
原Ridge静态RMSE21.383980235314738只作历史背景；本轮未运行Ridge Harness。

两条流完成并保存预测后，独立报告器才读取全流目标评分。RMSE使用sqrt(总SSE/总样本数)，
不平均逐批RMSE；实际版本来自prediction事件，不使用curve.csv观察后的版本状态。
本轮所有预测均为v0，因此两条曲线完全重合。逐发动机和RUL阶段仅作事后诊断，不输入调度器。

![FD001 RMSE曲线](../outputs/cmapss-tree-harness-20261110/host-pair/report/curves.png)

## 动作与拒绝证据

| 时点 | 实际事件 |
| --- | --- |
| source8 | 静态逐批RMSE30.7176325291；当时仍不能读取同批标签 |
| step10 | source8标签已按延迟释放；监测loss0.4903077722，feature_distance0.1581865055、feature_shift=false |
| step10 | 唯一Mock动作RETRAIN_SMALL，公开理由“Observed degradation; request bounded training.” |
| step10 | 实际训练192条，全部来自source8；筛选48条也来自source8，与训练隔离 |
| step10 | 候选selection NMSE0.5117230921945172，高于现模型0.46081411809044165 |
| step10 | `not_better_on_selection`拒绝；0冻结，未进入future gate |
| step13 | 第二次损失报警；feature_shift=false，仍处于距上次调用≤3批的既有冷却范围 |
| step14–17 | performance_drop=false，无新Mock动作，继续v0完成流 |

这里selection loss是按初始验证目标方差1731.5585409318967归一化的MSE，不是以周期计的RMSE。
还原后，候选RMSE **29.7670705794**，现模型 **28.2475949766**，均来自同一48条筛选样本。
拒绝发生在候选筛选阶段，不能描述成“future gate拒绝了已冻结模型”，也不能描述成“上线后变差”。

## 四层诊断与结论边界

- **特征/得分**：无GP或因子挖掘，改用冻结Tree预测得分的事后相关。18批得分与目标Pearson均为正，范围0.7441629747–0.9761200738；不能由此保证条件分布不变。两次报警均没有触发feature_shift，损失波动不等于已证实的物理概念漂移。
- **残差**：两策略逐样本残差相同。严重退化段RUL≤30有620条、RMSE15.3214889976；30<RUL<125有1880条、RMSE25.3501162258；Cap125有1993条、RMSE17.9262585156。此流最大误差并非仅集中在最末退化段，不能把生命周期内正常RUL变化自动认定为需要换模型。
- **复杂度**：初始树实际深度6、127节点、64叶；参数上限没有增加。短窗候选被拒绝前没有落盘其拓扑，候选实际节点/叶数缺测；不能凭上限或样本少认定灾难性遗忘，更不能断言LARGE必然有效。
- **时序**：首次动作发生在step10，只看到source≤8；实际训练source8，48条筛选也为source8。由于没有冻结与部署，全部批次仍由v0预测；冷却和随后报警消退解释了没有继续频繁尝试，预算未耗尽。

结论是：**本次SMALL没有形成合格候选，保守保底保住了静态表现**。结合Gas的SMALL/LARGE均弱于DO_NOTHING，
当前公开开发证据不支持推广频繁重训。也不能外推为“所有树任务都应永不更新”；本轮不变更默认策略、
窗口、门槛或官方提交镜像。如需验证真实保守Prompt，应独立立项，不能把本次Mock拒绝当作Qwen的DO_NOTHING。

## Qwen条件阶段

由于前置条件失败，真实请求0、真实Token0、费用0。没有Qwen原始JSON、真实reason或请求延迟；
8个Token仅为本地Mock记账。单独记录见[Qwen_Live_Decision.md](../Qwen_Live_Decision.md)。
用户要求的保守提示句、最多3请求、<0.05元、15秒硬期限和超时零重试在方案中保留，但本轮未发送或实测。
真实API profile白名单也没有放宽；没有把历史超时结果冒充新Demo。

## 实现与验证

新增[scripts/run_cmapss_harness.py](../scripts/run_cmapss_harness.py)和7项测试；先观察7项因能力缺失失败，
再实现配对运行、保存后评分、ID/offset/终止/部署时序校验、正向判定和三类报告。未修改核心调度算法。

- 代码冻结`c14ef34a1ff19f74966305a46fd07f355e32a952`，宿主实验dirty=false；核心SHA256 `00bb7c12f9fc7763aa80b65a2d0934058ff799388c0a850207fff49e539b1259`。
- 宿主完整unittest **445/445通过**；断网Linux同样 **445/445通过**。
- 独立镜像`ite-local:cmapss-tree-harness-20261110`，ID `sha256:9ecc564e8f7b93c0f5af35fce2b859983c0f976a921947ee94d98bf02620a5fd`；固定本地基础镜像ID `4a7a35e5b51a7b85f6f742c9eec6cf753ed901880de81e5bea12fe257cea8978`，依赖仅从原hash锁定wheel安装，build网络none。
- 测试及真实复现容器均核实`--network none --cpus 4 --memory 8g`，退出0、无OOM；宿主/Linux predictions、sample IDs、offsets与全部检查点数组逐值相同。8次重载推理共35944个预测值精确匹配。
- 宿主初始训练4.0434秒、候选0.004268秒；Linux分别1.1848/0.005387秒，保留Tree5秒和总20秒原上限。
- 构建器的cgroup记录为cpu.max=`max 100000`、memory.max=`max`；资源限制核验针对上述运行容器，不声称构建器自身也受4CPU/8GiB限制。
- 本轮镜像仅用于开发复现，未导出为新的正式交付包；官方镜像`ite-final:official-submit`仍为`sha256:242328072a5fdcac5ca98f173fb6eed9dafa32a31e5ab6ff10a69e2aaa0d5234`。

复现命令（使用新输出目录）：

```powershell
.\.venv\Scripts\python.exe -m scripts.run_cmapss_harness --package outputs/a-package-20261110/prepared/cmapss_fd001 --config configs/cmapss-harness-tree.json --output <新的输出目录>
```

## 证据入口

- [机器判定](../outputs/cmapss-tree-harness-20261110/host-pair/report/assessment.json)、[原始事件](../outputs/cmapss-tree-harness-20261110/host-pair/drift/events.jsonl)、[逐批](../outputs/cmapss-tree-harness-20261110/host-pair/report/batch_metrics.csv)、[逐发动机](../outputs/cmapss-tree-harness-20261110/host-pair/report/engine_metrics.csv)、[SVG曲线](../outputs/cmapss-tree-harness-20261110/host-pair/report/curves.svg)。
- [四层诊断JSON](../outputs/cmapss-tree-harness-20261110/records/06-host-diagnostics.json)、[跨平台核对](../outputs/cmapss-tree-harness-20261110/records/13-cross-platform-verification.json)。
- 原始记录保存在`outputs/cmapss-tree-harness-20261110/records/`：01失败测试、02通过、03宿主完整测试、04宿主真实流、05构建日志、07/09资源、08 Linux完整测试、10 Linux真实流、11/12 Docker身份。
- [可跟踪验证索引](validation/2026-11-10-cmapss-tree-harness.json)。本轮无新SwanLab上传，旧结果和默认配置保留。

## 2026-11-11 Qwen Demo补记

用户后续明确授权一次真实Qwen短流；这是决策/鲁棒性演示，不重开FD001性能对照。step10真实Observation包含source4–8已释放Loss（每来源256）；Qwen客户端请求耗时`15.202424999999948`秒后超出15秒硬期限。账本熔断`client_timeout`，没有重试；18批预测全部使用v0完成，0重训/部署。没有服务端响应，故JSON和Reason缺失，服务端Token及最终扣费未知；账本保留一次输入1250/输出128 Token的最大预留`¥0.01374962`，已结算费用`¥0`不代表最终费用为零。

历史192条候选在48条隔离筛选上被拒绝的证据作为Prompt上下文发送，但不证明“极易过拟合”。本次Qwen没有返回决策，不能宣称大模型选择了`DO_NOTHING`，也没有实际演示future gate。本轮没有重算RMSE；NR-022的指标、失败归因和未晋级结论不变。完整事件与持久账本见[Qwen_Live_Decision.md](../Qwen_Live_Decision.md)和`outputs/cmapss-tree-qwen-live-20261111/`。
