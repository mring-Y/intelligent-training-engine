# Official CPU A Model Integration

Updated 2026-11-11. This is a public development replay using the supplied A package, whose metadata marks its label status as `draft`; it is not an official hidden-set result.

## Integration

The supplied model is a 128-32-6 NumPy MLP with 4,326 parameters. `OfficialModelAdapter` runs its package code in a separate Python process pinned to NumPy 1.26.4 while the ITE process keeps NumPy 2.3.5. The worker validates the supplied ZIP digest, reads the checkpoint with the package loader, returns six probabilities in the declared class order, and resumes candidate training from the current gate model checkpoint. Ridge remains the default model type.

The adapter tests verify exact probability equality with `baselines.predict`, byte-for-byte checkpoint equality with the package `--resume` command, preserved Adam step progression, rejection of the main interpreter as the official runtime, and checkpoint digest validation. The 10 focused official adapter/replay tests passed.

The Dockerfile now defines `/opt/ite-official-a` with `numpy==1.26.4` and includes the supplied A ZIP. Docker was not available in this host session, so the image build and disconnected Linux execution remain unverified.

## Results

| Evaluation | Samples | Accuracy | Macro-F1 |
| --- | ---: | ---: | ---: |
| Supplied checkpoint, full public validation | 1,244 | 0.878617 | 0.714030 |
| Static, simulated online stream | 809 | 0.496910 | 0.394619 |
| Mock Harness, same simulated online stream | 809 | 0.496910 | 0.394619 |
| Static, simulated future holdout | 311 | 0.000000 | 0.000000 |
| Harness, simulated future holdout | 311 | 0.000000 | 0.000000 |

The supplied `training.json` records the same full-validation metrics as the adapter run. For the replay, validation rows were kept in source-index order and divided into 124 calibration rows, 809 online rows, and 311 future rows. Starting at online batch 3, the replay added 1.5 checkpoint standard deviations to every feature; labels were not changed. The required notice is embedded in all generated summaries: **当前测试流为公开验证集的时序模拟，不代表官方隐藏测试集的真实表现。** The last 311 source-ordered rows are all class 5, so their zero score is specific to this deliberately shifted public-validation slice.

At step 4, the drift monitor recorded `feature_distance=1.762093` and `feature_shift=true`. Mock Harness requested `RETRAIN_SMALL`. The candidate resumed the deployed checkpoint for five epochs on 96 labels from source steps 2-3 and reached zero error on 32 source-3 screening labels. It was frozen at step 4. At step 6, the independent gate evaluated 115 source-5 labels: candidate and incumbent error rates were both 1.0, so `validation_gain=0` and the candidate was rejected. All 809 online predictions remained version 0; no deployment or rollback occurred. Therefore this run has no deployed-model accuracy to report.

This establishes that the adapter can train and evaluate an official checkpoint through the existing Harness path, while the configured gate keeps the incumbent when the candidate shows no independent gain. The evidence does not establish why the candidate failed to improve or predict hidden-set performance.

## Artifacts

- [Run summary](../outputs/official-a-mock-20261111/summary.json)
- [Detailed comparison](../outputs/official-a-mock-20261111/comparison.json)
- [Drift events](../outputs/official-a-mock-20261111/drift/events.jsonl)
- [Drift curve](../outputs/official-a-mock-20261111/drift/curve.csv)
- [Temporal split and simulated shift](../outputs/official-a-mock-20261111/data/split-and-drift.json)
- [Source ID mapping](../outputs/official-a-mock-20261111/data/source-id-map.jsonl)
- [Negative-result record NR-023](negative-results.md)

The complete host suite ran 465 tests: 461 passed and four Tree worker tests errored on the fixed five-second initial-training deadline. An isolated rerun reproduced those four timeouts. All 10 focused official adapter/replay tests passed. No disconnected Docker validation or hidden-data evaluation was performed.

## B/C Adapter and Delivery Update

Updated 2026-11-11. The supplied B and C packages are preserved unchanged at `third_party/official_baselines/`. Their SHA-256 digests match the supplied archives: B `68db6a72c29bac11a4f86e97d9c1f524d35695464fd5f3f6d131f1431bc69d68`; C `6cb8784e2cab7ee93453e756abf54c168721c667ca0c2c1327f5faae96e4211f`. C metadata remains `label_status=draft`; its results are not an official hidden-set claim.

`OfficialModelAdapter` now strictly routes `profile_type` A/B/C and checks each package digest, `baseline-info.json`, task, feature count, parameter count, class contract, target unit, and checkpoint metadata. It runs all packages in a separate NumPy 1.26.4 process while the ITE image keeps NumPy 2.3.5. Regression predictions are returned in the package's original units. B and C predictions on public validation rows were compared with each package's `baselines.predict`; maximum absolute error was below `1e-6`. One-epoch continuation from each current checkpoint produced checkpoint bytes identical to the corresponding official `baselines.train --resume` run, including optimizer and normalization state. Regression summary RMSE/MAE use raw targets (minutes for B, cycles for C), not the normalized training loss.

The model factory accepts `official_mlp` and retains `official` as a compatibility alias. `configs/default.json` now selects `official_mlp` with `official_profile=auto`. Auto routing uses the provider's explicit `official_profile` provenance, never the drift `scenario`; missing or mismatched identity triggers a failover. Initialization, initial scoring, and stream inference failures try a bounded Tree model first, then Ridge, and append a `model_fallback` event with the failure reason, attempted model types/statuses, and the selected type. The active trainer, timeout budget, controller, checkpoint, and summary follow the selected model.

The four previously slow Tree initial-worker tests use a test-only 10-second allowance for `candidate=False`. Production Tree deadlines remain unchanged. A Docker test image was built with the pinned `python:3.12-slim` base digest, runtime NumPy 2.3.5, copied isolated NumPy 1.26.4 interpreter, and hash-locked scikit-learn 1.7.2/SciPy 1.16.3 Tree dependencies. The final test target passed **478/478 tests** with `--network none`, 4 CPUs, and 4 GiB. The existing 3.1 MiB public prepared FD001 package was mounted read-only for tests that require it. Image tag: `ite-official-bc:20261111`; image ID: `sha256:2e3df72bbea694f89e7ade8f120828be3b262685f7aaae25dded24654a8b26e6`.
