# PyTRiO 客户端、标签协议与预算保护

**后续更新（2026-11-08）：** 以下的HTTP细节、价格和示例属于2026-11-07历史配置（含60秒旧超时）。当前源码使用15秒端到端硬截止，最新超时记录、reserved费用和Mock三门控链见[三突变结果](three-abrupt-results.md)及[逐动作报告](triple-drift-mock-report.md)。官方内网延迟无实测；不要由此前两次8.5秒公网成功推断内网一定会大幅降低。

本轮实施已由用户在 2026-11-07 确认；用户将账号充值到 50 元，但付费实验继续限制为一次分类 abrupt / seed 7 / 96 批 / drift，最多 10 次请求、本地预估费用上限 0.50 元。规则变更依据见 [培训纪要](competition-briefing-notes.md)，实施与测试登记见 [计划](superpowers/plans/2026-11-07-pytrio-smoke.md)。验证结果以本轮最终回执为准。

## 契约与调用边界

`BaseLLMClient.get_decision(observation)` 返回 `LLMReply`；线上动作仅为 `action` 和 `reason`。`RETRAIN_SMALL/LARGE` 只能请求现有白名单规格，`ROLLBACK` 需要快照筛选、冻结及独立未来标签验收。原有 JSON 严格解析继续拒绝额外参数、重复字段、代码围栏及尾随文本。

Observation V2 保留五个字段，将 `remaining_label_budget` 扩为非负整数或 `null`。`null` 明确表示标签按协议提供、无申请额度；`0` 仍表示有限额度耗尽。`OBSERVATION_SCHEMA_V1` 保留旧契约，已有预算模式不变。`label_mode=provided` 在当前模拟器中逐批提供全部样本标签，但仍遵守预测后申请和 `label_delay` 释放；这不是尚未发布的官方 SDK 适配。官方标签的揭晓时点需另行对齐。

真实调用只在漂移报警、新证据、冷却结束、无待验收候选、未来验收容量及训练资源可行时触发。`DO_NOTHING` 同样进入调用冷却。配置和 CLI 拒绝将真实模型用于矩阵、多策略、不同种子/任务/场景或扩大流长。

## 真实传输

`TrioLLMClient` 使用 PyTRiO [官方 OpenAI 兼容接口](https://docs.pytrio.com/en/docs/advanced/openai) 的 `/api/openai/v1/completions`，每次仅一个 POST，不重试、不自动修复格式、不追加模型对话。独立子进程延迟读取 SDK 认证状态，凭证不进入配置、日志或返回数据。

输入先用本地官方 tokenizer / `chat_template.jinja` 渲染 System/User 消息，`enable_thinking=False`，计算完整输入 token 数后再发送。子进程强制 UTF-8、HTTPTransport(retries=0)、连接 10 秒、请求 45 秒，父进程 60 秒硬截止，超时 kill 并回收进程。运行时不下载 tokenizer 或权重。`requirements-pytrio.txt` 是宿主付费联调的可选固定依赖；断网核心镜像不安装它们，测试只替换外部 HTTP/进程边界。

System Prompt 角色为工业模型漂移诊断专家，说明已揭晓 Loss、预算和五字段语义，直接嵌入导出的 Action Schema，要求单行中文理由及唯一 JSON 对象。提示词原文在 `ite/trio_client.py`；未将模拟器场景/漂移真值发送给模型。

## 持久预算保护

2026-11-07 官方公开 [价格表](https://pytrio.com/home/pricing) 核实 Qwen/Qwen3.8-27B 的非缓存输入为 8.41 元/M Token，输出为 25.29 元/M Token；预留不依赖缓存优惠。2048 输入 + 512 输出的单次最大预留为 0.03017216 元，十次为 0.30172160 元。

`CallLedger` 对 JSON 账本使用 OS 文件锁和 fsync + 原子替换；调用之前记录序号、完整输入/输出上限、价格与费用预留。重启继续累计，并逐条核对请求回执与汇总计数。损坏、身份不符、其他未完成请求或持久化失败均停止新请求。真正的全流 Controller 恢复仍不在本轮范围，持久成本账本不等于完整状态续跑。

- 第 11 次请求发送前被阻止，失败/超时同样占一次尝试；不以另建流自动重置账本。
- 预留或已用 Token 达到 80%（含等号），或预留费用会超过 0.50 元，则拒绝发送。
- 有可信服务端用量时先结算再解析 JSON；非法输出也计实际成本。若服务端报告超出预留，保留实际用量并熔断，不能丢弃超额回执。
- 超时、无可信用量时保留全部预留，单列未知调用。终止本地等待不证明服务端已取消计费。
- Guard 在标签、候选拟合和门控执行边界复查共享账本，防止其他进程熔断后继续工作。
- `STATIC_FALLBACK` 永久冻结当前部署，取消 pending，停止新标签申请、训练、切换及 LLM；继续预测，在途标签仅用于最终评分和审计。

## 运行与审计

准备本地 tokenizer（从官方模型仓库只下载配置、分词器和模板），核对 `llm_tokenizer_path` 及 `llm_ledger_path`。以下命令会付费，只属于用户已明确批准的唯一冒烟流程，不可作为自动重试命令：

```powershell
.\.venv\Scripts\python.exe -X utf8 -m ite run --config configs/harness-trio-smoke.json --policies drift --output outputs/pytrio-smoke-20261107/real
```

审计命令不发请求、不训练，拒绝覆写输出：

```powershell
.\.venv\Scripts\python.exe -X utf8 -m ite.llm_audit --ledger outputs/pytrio-smoke-20261107/paid-call-ledger.json --events outputs/pytrio-smoke-20261107/real/drift/events.jsonl --output outputs/pytrio-smoke-20261107/cost-audit.json --batches 100 --drift-calls 100
```

投影以漂移请求机会数 K 为参数，报告实测均值与配置上界，分别计算 K 次和 min(K,10) 次；未知用量保留费用风险，不混入已知 Token。100 批不等于 100 次调用；小样本不证明 P95、官方成本分或隐藏流收益。

真实闭环通过后，使用纯 Mock 压力入口执行两任务×六场景×三开发种子×四条分支共 144 次：正常 static/drift 两条，另有 invalid_json 和 token_exhausted 的 drift 两条。每条 96 批。无合格漂移的故障流会注明故障未被调用，不能冒充已验证故障触发。矩阵按精确事件顺序核对熔断后无工作，包括同批。

```powershell
python -m ite.harness_matrix --output outputs/mock-stress
```

至少三次迭代的官方适用范围仍待明确。日志分别统计调用、训练实验、候选拟合、冻结、验收、上线；次数不足如实披露，不伪造或强制更新。没有官方数据与基线时，不把本轮工程闭环验收写成比赛效果晋级。
