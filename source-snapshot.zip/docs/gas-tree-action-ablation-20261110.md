# Gas Tree Action Ablation: 2026-11-10

本轮只验证一个因素：Tree Harness 是否正确区分 `RETRAIN_SMALL` 与
`RETRAIN_LARGE` 的窗口白名单。用户确认后先写失败测试，再修复路由；数据、树参数、标签延迟、future gate、预算和九批 Gas 流均保持不变。

## 预登记假设

修复 Tree 路由后，小动作只使用最小窗口 192，大动作评估 `[192, 384, 768]`。
如果原始退化来自小窗口，完整窗口候选应改善上线后的同样本 Accuracy；`DO_NOTHING`
使用已有静态 Tree 作为不更新对照。

## 实际配置

- 数据：公开 A 包 UCI Gas，source batch 2--10，共 13,465 条；manifest 和输入文件哈希保持原 A 包。
- Tree：`max_depth=6`、`min_samples_leaf=5`、`max_leaf_nodes=64`、`random_state=7`。
- 初始切分：355 train / 90 validation；`selection_split=recent_disjoint`；future gate；label delay 2。
- 训练窗口：`[192, 384, 768]`；树训练上限 5 秒；总自适应预算 20 秒。
- SMALL 使用本地 Mock 固定返回 `RETRAIN_SMALL`；LARGE 使用隔离驱动固定返回 `RETRAIN_LARGE`；真实 Token 为 0。

## 结果

| 策略 | 实际候选 | 全流 Accuracy | 上线后样本 | 上线后 Accuracy | 同样本静态 Accuracy | 相对静态 |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| `DO_NOTHING` | 无更新 | 43.215745% | 4364 | 32.080660% | 32.080660% | 0 |
| `RETRAIN_SMALL` | 192 条 | 41.099146% | 4364 | **25.549954%** | 32.080660% | -6.530706 个百分点 |
| `RETRAIN_LARGE` | 192/384/720 条候选，最终选 384 条 | 42.859265% | 4364 | **30.980752%** | 32.080660% | -1.099908 个百分点 |

两种动作均在 step 2 冻结候选、step 5 通过独立 future gate，step 6 开始使用 v1。
SMALL 的 gate loss 为 `0.2335025381`，incumbent 为 `0.5685279188`；LARGE 的 gate
loss 为 `0.2741116751`，incumbent 同为 `0.5685279188`。LARGE 的三个候选在 source_step=0
的 48 条筛选集上分别为 7、4、4 个错误，384 与 720 并列时按既有先到规则选择 384。

### 上线后逐批

| step / source batch | 样本 | 静态 Accuracy | SMALL Accuracy | LARGE Accuracy |
| --- | ---: | ---: | ---: | ---: |
| 6 / 8 | 294 | 24.149660% | 12.244898% | 44.217687% |
| 7 / 9 | 470 | 36.808511% | 23.404255% | 45.319149% |
| 8 / 10 | 3600 | 32.111111% | 26.916667% | 28.027778% |

LARGE 相对 SMALL 多保留了前两批的 202 个正确预测，但最后 3600 条大批次仍低于静态，
所以完整窗口候选只能部分缓解退化，不能把更新收益归因为已证实的调度收益。

## 四层归因

- **因子/特征**：本轮没有新增因子系统，128 个原始 Gas 特征和树参数固定。动作改变只影响候选窗口，不能解释为特征改善。
- **预测残差**：SMALL 在三个上线批次都低于静态；LARGE 在前两批优于静态，在最大批次低于静态 3.083333 个百分点。大批次占上线后样本 82.5%，决定了加权结果。
- **复杂度**：没有增加深度、叶节点上限或新特征。既有诊断中初始树为 33 节点/17 叶，v1 为 17 节点/9 叶；本轮没有复杂度增加证据。
- **时序**：SMALL/LARGE 都只用 source_step=0 训练，门控只验收 source_step=3，step 8 的性能下降在部署后才揭晓；因此训练样本时效与验收时点错配仍是支持性假设，尚不能宣称为唯一因果。

## 明确结论

原 `RETRAIN_SMALL` 确实是本次公开 Gas 流上的较差动作。`RETRAIN_LARGE` 明显优于有效 SMALL，
但仍不如 `DO_NOTHING`；当前证据支持“窗口扩大可以减轻、不能消除时序错配”，不支持“应当默认总是大窗口”或“应当默认总是不更新”。
本轮未测稳定/渐变场景、C-MAPSS、真实 API、隐藏数据和默认配置切换。

## 工程变更与验证

`ite/controller.py` 现在保留显式动作窗口：Tree 的 `RETRAIN_SMALL` 只传最小白名单窗口，
`RETRAIN_LARGE` 传完整白名单；无动作窗口的周期 Tree 实验仍使用原窗口策略，并继续拒绝白名单外窗口。
新增回归测试位于 `tests/test_harness_control.py`。

宿主完整 unittest：**438/438 通过**。原始失败启动目录 `outputs/gas-tree-actions-20261110/large/`
保留；正式 LARGE 结果位于 `outputs/gas-tree-actions-20261110/large-retry/`。

本轮随后使用 Docker Desktop 绝对路径构建并运行了当前源码镜像：
`ite-local:safe-tree-route-20261110`，镜像 ID 为
`sha256:703844bcdefe7b9b5347369572de90b79c8692a16c097163201afd0720ad3e4c`。
在 `--network none --cpus 4 --memory 8g` 下完整 unittest 为 **438/438 通过**；
Linux Gas SMALL action pair 的动作、窗口和实际版本序列与宿主一致，static/drift 的
predictions、概率、sample IDs、batch offsets 均逐值相同（最大概率绝对差 0）。

机器报告：

- `outputs/gas-tree-actions-20261110/small-report/assessment.json`
- `outputs/gas-tree-actions-20261110/large-report/assessment.json`
- `outputs/gas-tree-actions-20261110/small-report/batch_metrics.csv`
- `outputs/gas-tree-actions-20261110/large-report/batch_metrics.csv`
- `outputs/gas-tree-actions-20261110/linux-small-report/assessment.json`
- `outputs/gas-tree-actions-20261110/linux-small/`（断网容器原始输出）
