# 4B 决策模型切换：冻结范围与执行边界

用户在本轮明确确认：使用 `Qwen/Qwen3.5-4B`，模型名与 Prefill/Sample 单价由配置透传；输入 ¥1.49/M、输出 ¥4.54/M。沿用 NR-022 的 FD001 公开开发流、树模型、Prompt 和独立未来门控，仅验证真实决策与工程链路，不重新做性能调参或隐藏测试集晋级。

- 配置：`configs/cmapss-tree-qwen-demo.json`。18 批、4493 行、unit81–100、seed7；最大两次请求、¥0.03 总上限；每次输入1250/输出128 Token、15秒总截止、零重试、Fail-Closed。
- 单次最大预留 ¥0.00244362，两次 ¥0.00488724。超时保留预留和未知用量，不写成零消耗；收到服务端用量后按该请求保存的费率结算，不重算旧27B记录。
- 新输出：`outputs/cmapss-tree-qwen4b-live-20261112/`；新声明/账本：`outputs/cmapss-tree-qwen-paid-state-20261112/`。旧27B目录与旧tokenizer保留；旧claim不重置。
- tokenizer：Qwen官方ModelScope固定revision `f09dfc75214c5f2f4940ae6a26c126ce93828a9b`，资产摘要见 `deployment/tokenizer-qwen3.5-4b-manifest.json`。Hugging Face API曾返回revision `851bf6e806efd8d0a36b00ddf55e13ccb7b8cd0a`，但文件TLS传输失败；实际使用的四个资产与ModelScope官方API的大小/SHA-256逐项匹配，不能声称两revision资产完全一致。
- 冻结step10 Observation经4B本地模板得到960输入Token；worker每次在发网前重新计数，并核对4B资产manifest/哈希。原始传感器向量不发送给服务商。
- 截至源码冻结前：宿主完整486/486通过，320.931秒。红灯、聚焦回归及完整记录位于 `outputs/qwen4b-20261112/records/`。原有21个历史文件的摘要已先行保存，运行后再次核对。
- 独立审查发现并关闭旧27B缺少显式费率时误用4B默认价的问题；新增红灯后修复，相关47项宿主回归通过。最终源码`a21a831`的断网Linux完整487/487通过，4CPU/8GiB，68.129秒，峰值530878464字节、无OOM。两次容器准备错误及修正见NR-024，原始日志均保留。

真实结果追加到 `Qwen_Live_Decision.md`，机器回执单独保存。即使返回DO_NOTHING，也只报告本次没有发起重训；不能据单次回答断言普遍因果或宣称RMSE改善。若失败，先追加阴性记录，按本轮边界结束，不追加付费重试或改策略。

## 真实执行结果

2026-11-12唯一真实执行完成：step10返回`DO_NOTHING`，Reason为“损失波动剧烈且伴随漂移报警，但缺乏明确趋势证据，且预算为null，维持现状风险可控。” 端到端9.257662600000003秒；服务端输入960、输出35、合计995 Token，按配置费率估算¥0.00158930。仅1次调用、无重试、无超时，无未结算预留。18/18批、4493条全部v0完成，0次训练/部署/回滚，最终checkpoint与初始逐字节一致，旧21个历史文件指纹均未变。

`null`特指协议提供标签，不能将Reason中的含糊表述解读为费用或Token预算耗尽。实际Observation与旧27B真实请求逐字段相同；计数预检的Mock参考messages预算字段与实际不同，实际请求的离线重建计数与服务端均为960。原始运行的Git提交字段不可用，core哈希与冻结源码匹配；保留原值并在机器回执补充外部来源链。没有重发请求或补造原始元数据。

完整证据见根目录`Qwen_Live_Decision.md`、`outputs/cmapss-tree-qwen4b-live-20261112/`及`docs/validation/2026-11-12-cmapss-qwen4b-defense.json`。NR-022的性能结论与准入门槛保持冻结，本次不宣称RMSE晋级。
