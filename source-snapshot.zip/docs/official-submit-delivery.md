# Official Submit Image and Evidence

最新交付进度（2026-11-15）：已合入 A step7分层回放、B static、C head-only 2epoch 的 train-only 候选镜像 `ite-ac-policy:20261115-v1`，导出文件为 `outputs/ac-policy-integration-20261115/harness-ac-policy-20261115.tar`，SHA-256 `c05ee34b6bd1b0dbdd5885d0a3150689cd729318d31d9ce77f87abe59aa3b692`。宿主/Linux各54流逐值复现预测；A仅微增、C RMSE约降2%，三包主指标未观测到退化，但A未达实质增益门槛，因此不自动替换原已通过C2候选。完整命令、成绩、分段风险和来源见[新策略合入报告](ac-policy-integration-results-20261115.md)和[机器索引](validation/2026-11-15-ac-policy-integration.json)。当前只有公开开发入口，正式隐藏平台启动/挂载/输出合同尚未提供。

以下为2026-11-08历史交付记录，镜像为 `ite-final:official-submit`；这些身份不表示包含11月15日的新策略。

## 防守型演化证据（2026-11-11）

这组公开开发流支持“先证明候选可用，再允许模型替换”的交付原则，但不支持把真实大模型描述为已经展示了战略克制：

| 证据 | 已观察结果 | 边界 |
| --- | --- | --- |
| Gas Tree 本地 Mock 动作对照 | 静态Tree全流Accuracy43.22%；SMALL和LARGE实际上线后的同样本Accuracy分别25.55%和30.98%，静态为32.08% | LARGE缓解了SMALL退化，但本流仍低于不更新 |
| C-MAPSS FD001候选筛选 | 192条候选/48条隔离筛选RMSE29.77周期；现模型28.25，候选被筛选拒绝 | 未冻结、未部署，因此不声称该候选上线后会更差，也不声称future gate拒绝 |
| 真实Qwen27B短流 | step10单次请求15.20秒超时；零重试；18/18批预测完成，全部使用v0；0次重训/部署 | 服务端未结算，Token与最终扣费未知；账本仅有¥0.01374962未结算预留；无真实JSON或Reason |

**在已测公开开发流中，不恰当的重训可能比不重训更危险：Gas的Tree小窗口和大窗口更新在实际上线后的同样本准确率都低于静态模型，FD001的小样本候选则在筛选阶段被拦截。Harness不以重训次数为目标，而以候选筛选、独立未来标签门控和故障时Fail-Closed保住当前模型。** 本轮Qwen没有返回决策，故不将兜底行为归因于大模型判断；观察、Reason缺失、Token不确定性和超时证据见[Qwen_Live_Decision.md](../Qwen_Live_Decision.md)。

Gas动作证据见[Gas Tree动作对照](gas-tree-action-ablation-20261110.md)和NR-021；FD001基线筛选见[C-MAPSS报告](cmapss-tree-harness-results-20261110.md)及NR-022。此次Qwen短流没有评估新RMSE，也不改变默认配置或正式镜像。正式镜像身份仍以本页以下段落为准。

## Image Provenance

- Image ID: `sha256:242328072a5fdcac5ca98f173fb6eed9dafa32a31e5ab6ff10a69e2aaa0d5234`
- Local image size: `950424183` bytes (about 950 MB), below the 2 GB package ceiling.
- Source commit: `3bad96abe3de037a0a452c1c76ef5ea0beaac6b1` (`source_dirty=false`).
- ITE source SHA-256: `7c475f1230b78fb0efe931d0cd25ef35b33f781dec4a72e0e0e5ae29496834b2`.
- Base image: pinned `python:3.12-slim@sha256:b18b261e1b4974b4f321451ad5251ded85abb22c2b8b262da527dda1d031ab30`.
- Python requirements are pinned by `requirements-runtime.lock`; the runtime includes the optional Parquet dependency and local tokenizer, with no model weights.

The image was built from the clean committed tree with Docker's default build network. No `--network none` was supplied to `docker build`; dependency stages were valid cache hits for the same pinned base and lock files. The Dockerfile itself remains unchanged.

```powershell
$docker = "C:\Users\LENOVO\AppData\Local\Programs\DockerDesktop\resources\bin\docker.exe"
& $docker build --target runtime --tag ite-final:official-submit `
  --build-arg ITE_SOURCE_COMMIT=3bad96abe3de037a0a452c1c76ef5ea0beaac6b1 `
  --build-arg ITE_SOURCE_DIRTY=false `
  --build-arg ITE_SOURCE_SHA256=7c475f1230b78fb0efe931d0cd25ef35b33f781dec4a72e0e0e5ae29496834b2 .
```

## Offline Runtime Check

The final image ran the 10-batch Mock A package rehearsal with runtime networking disabled, four CPUs and 8 GiB. The source checkout was mounted read-only only to provide the rehearsal script; the installed `ite` package came from the image. The temporary package and run outputs stayed inside the disposable container.

```powershell
$docker = "C:\Users\LENOVO\AppData\Local\Programs\DockerDesktop\resources\bin\docker.exe"
$workspace = (Get-Location).Path
$mount = "type=bind,source=$workspace,target=/workspace,readonly"
& $docker run --rm --network none --cpus 4 --memory 8g --workdir /app `
  --mount $mount ite-final:official-submit `
  python /workspace/scripts/make_mock_A_package.py `
  --output /tmp/ite-mock-A-official-smoke-20261108
```

Observed result: all four streams completed 10 prediction batches each; 10 Mock calls produced 10 parsed decisions; real LLM tokens were 0. Two training attempts occurred, one candidate froze, and no candidate deployed during this short smoke run. This validates offline runtime and the provider/Runner/Harness path, not model quality or a successful independent deployment.

After cleanup, the same command was run again and passed with the same 4-stream/10-batch result. All old `ite-local:*` image tags were removed; `docker image ls` now shows only `ite-final:official-submit`. The 14 pre-existing stopped test containers were preserved. Docker retains their referenced container snapshots internally, so removing their writable layers would require deleting those containers; no container was deleted in this cleanup.

For the normal application entry point, mount a host output directory and keep runtime networking disabled:

```powershell
$docker = "C:\Users\LENOVO\AppData\Local\Programs\DockerDesktop\resources\bin\docker.exe"
$output = (Resolve-Path .\outputs).Path
& $docker run --rm --network none --cpus 4 --memory 8g `
  --mount "type=bind,source=$output,target=/app/outputs" `
  ite-final:official-submit
```

The image's default command runs `configs/default.json`. For the short Mock A rehearsal above, use the explicit 10-batch command.

## SwanLab Public Records

2026-11-12 milestone: [ljc6re1q](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/ljc6re1q) archives the real Qwen3.5-4B decision, official CPU A/B/C adapter evidence, historical Gas/C-MAPSS runs and the complete offline Linux 487-test receipt. Anonymous project HTTP200/PUBLIC was checked after upload. The 14,359,210-byte ZIP, 157 artifact files and 86 exact-byte attachments passed local hash verification; SDK upload objects are counted separately. See [archive receipt](validation/2026-11-12-swanlab-milestone.json). The server ZIP has not been independently re-downloaded.

The historical runs below all belong to `mring-Y/Intelligent_Training_Engine`. Their earlier anonymous-access receipt reports HTTP 200 and project visibility `PUBLIC` (see [three-abrupt validation](validation/2026-11-08-three-abrupt.json), checked 2026-11-07); the milestone above records the newer check. Project-level visibility applies to the runs in that project. Historical SwanLab records were not deleted or rewritten for this archive.

- [4hl949mi](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/4hl949mi)
- [7s5w0kuz](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/7s5w0kuz)
- [8qr4s306](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/8qr4s306)
- [88k1ttuu](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/88k1ttuu)
- [ceuc4nb6](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/ceuc4nb6)
- [f44h8phy](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/f44h8phy)
- [gwwzl8ej](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/gwwzl8ej)
- [mgttpd1y](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/mgttpd1y)
- [vyzmljd3](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/vyzmljd3)
- [wku1evw8](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/wku1evw8)
- [wrool8bf](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/wrool8bf)
- [x32h105t](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/x32h105t)
- [yhpzfjkd](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/yhpzfjkd)
