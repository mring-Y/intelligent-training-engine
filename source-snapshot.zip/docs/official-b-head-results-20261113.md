# 官方 B 包 full / head-only 对照：2026-11-13

B 的本轮单因素对照已完成宿主与断网 Linux 验证：head-only 仅通过六分区中的两个，full 未通过任一分区。两臂均不晋级，保留静态模型。A 上轮缺失的 Linux 回放也已补齐，其“不晋级”结论不变。当前测试流均为公开验证集的时序模拟，不代表官方隐藏测试集的真实表现。

## 本轮因素与门槛

只比较 B 模型的可训练参数集合。static 不更新；full 通过 `RETRAIN_LARGE` 更新全部 865 参数；head-only 通过 `RETRAIN_HEAD_ONLY` 更新输出层 25 参数。复用已有官方 worker、动作白名单和独立未来标签门控，没有改生产 Harness、训练损失、学习率、窗口或默认配置。

固定 34→24→1 MLP、官方初始检查点、原 Adam 状态、5 epoch、每候选 5 秒/每流 20 秒。train 在 step 3/7 请求候选，eval 在 step 3 请求，最大窗口含筛选共 768 行。标签延迟 1 批；筛选、future gate 和最终评分沿用各自来源。B eval 在 step 3 实际只有 24 行训练和 8 行筛选，之后 future gate 为 10 行，没有扩大样本量。三个场景仍为 stable、step 3 起的 abrupt 和渐变宽 4 批的 gradual，偏移幅度为 0.75 倍 checkpoint scale，标签与分钟单位不变。

stable 的 RMSE/MAE 均须不高于同 ID 静态对照；abrupt/gradual 每个 train/eval 分区须 RMSE 严格更低、MAE 不增加。各包不得互相抵消退化，公开回放不得作为独立隐藏验收。

## 配对效果

下表单位为分钟；Windows/Linux 完整精度评分相同。`train/eval` 是两个独立启动的开发分区，不是对某个已微调模型再做离线盲测。

| 分区 | static RMSE / MAE | full RMSE / MAE | head-only RMSE / MAE | head-only门槛 |
| --- | --- | --- | --- | --- |
| stable train | 704.092356 / 593.470200 | 881.170122 / 814.376930 | 1088.945483 / 1022.288578 | 未通过 |
| stable eval | 241.980799 / 175.586934 | 254.724702 / 166.770435 | 225.781349 / 151.460465 | 通过 |
| abrupt train | 774.656867 / 665.593129 | 795.504684 / 712.661601 | 760.031815 / 643.726721 | 通过 |
| abrupt eval | 242.205220 / 157.426449 | 242.205220 / 157.426449 | 242.205220 / 157.426449 | 未通过，无严格改善 |
| gradual train | 702.301049 / 593.308890 | 751.701910 / 668.569840 | 704.815886 / 608.153869 | 未通过 |
| gradual eval | 274.191985 / 193.801739 | 345.165423 / 236.582975 | 307.948751 / 213.222422 | 未通过 |

full/head-only 各有 9 次实际续训、7 次部署。abrupt/eval 两臂均未部署，持平不能当作候选上线收益。本轮 train 固定在 step 7 再次请求候选，因此 abrupt/gradual full 的结果不能直接冒充 NR-025 中只实际训练一次的重复结果。

## 四层诊断

- 特征/模型得分：34 维官方轴承特征，固定模拟协变量平移。没有训练或选择任何新特征，没有 GP 或因子种群。不能把该变换称为真实故障概念变化。
- 残差：stable/train 中 Bearing3_4 的 static/full/head RMSE 为 `710.813/890.928/1102.017`，残差 bias 为 `-427.393/-72.063/+143.351`，残差标准差为 `567.970/888.008/1092.654`。冻结底层仍可能扩大离散度并使总体偏差转正。abrupt/train head-only 却降低 RMSE/MAE，其 B3 残差标准差从 `492.122` 降至 `435.014`。已有证据不支持“冻结底层会普遍改善 B”的假设，也不能由此证明过拟合/遗忘是唯一原因。
- 复杂度：18 个候选 checkpoint 已逐个核验。head-only 的 w1/b1、底层 Adam 一二阶矩、mean/scale 保持逐字节不变，w2/b2 确有更新；full 更新全部 865 参数。网络大小保持不变。
- 来源/部署时序：train 的 1,557 行来自 Bearing2_4（42）和 Bearing3_4（1,515），eval 的 122 行来自 Bearing1_4。Bearing2_4 的所有预测都发生在部署前，其持平不是适应能力证据。18 个 future gate 的来源时间均在冻结后，且 ID 与相应训练/筛选来源隔离。`prediction` 事件确认 deploy(k) 从 k+1 才生效。

## 验证与成本

宿主全套 **563/563** 通过，330.018 秒；Linux 全套 **562 通过、1 宿主专用检查跳过**，132.091 秒。测试容器和 A/B 效果容器均为 **4 CPU、4 GiB、`--network none`**，退出 0，无 OOM；内存峰值未采集。

B 的 15,111 条 active 预测及 static、targets、source IDs、versions 数组跨平台逐值相同。18 个候选、270 个数组载荷跨平台精确一致；两端共 108 份事件/预测/摘要的存储哈希均匹配各自 manifest。各流的完整 RMSE/MAE、bias/variance 与 per-bearing 数值见 [机器验证索引](validation/2026-11-13-official-b-head.json)。

| 成本（每臂六流累计） | static | full | head-only |
| --- | ---: | ---: | ---: |
| 续训次数 | 0 | 9 | 9 |
| 部署次数 | 0 | 7 | 7 |
| 宿主训练秒 | 0 | 6.148332 | 6.120288 |
| Linux训练秒 | 0 | 2.183932 | 2.221765 |
| 已释放在线标签行次 | 4620 | 4620 | 4620 |
| 真实 LLM Token / API 请求 | 0 / 0 | 0 / 0 | 0 / 0 |

标签数字是多场景累计释放行次，不代表新增 4,620 条唯一标注。主环境 NumPy 2.3.5、官方隔离 worker NumPy 1.26.4 未改变；没有新的依赖、训练actor、Teacher或LoRA调用。本轮未新增SwanLab上传。

## Docker 恢复与 A 轮补验

原先只从 PATH/Program Files 检查得到的“未安装 Docker”结论有误。实际 Docker 是用户级安装：`C:/Users/LENOVO/AppData/Local/Programs/DockerDesktop/resources/bin/docker.exe`。用用户权限的提升调用可连接现有健康 daemon，不需要重装、重启、清空状态或改变全局配置。

基础镜像保持 `ite-qwen4b:20261112`，ID `sha256:76476d088433a4bb20a00d6eed16b136062ffe670a8d7541b727ce6ef8eb5228`。新验证镜像 `ite-official-b-head:20261113`，ID `sha256:11046ffa9738f1b61dcbc385d92485b92bfd1a66e839742fb73894ba178f6c1e`，只复制当前源码/测试，构建步骤网络关闭，未安装依赖。镜像来源为提交 `e74373e831d52ecdecc5aa76d6e62a1ee1f47fdf` 加本轮未提交脚本/测试，dirty=true；core SHA-256 `18e4b79ff2a66cd9845e6291fe6ebc892decca8046fa6cf46fc52075fb6e22ed`，B runner SHA-256 `8f59b7ec8867e2b3390524b09a79635f2792338e8daed38c9504fc3d9e2a1b52`。不把旧提交号或后续文档提交冒充镜像含有干净冻结源码。

A 的原 18 流方案已在同一镜像复跑，10,620 条预测、目标、ID、版本和评分完全重现；replay 仍通过 4/6 分区而不晋级。A 的 18 份 checkpoint 数组载荷存在最大绝对差 `1.1102230246251565e-16`，metadata、mean/scale 一致，不能声称 checkpoint 逐字节一致。此差异未改变本次离散预测和门槛判定；未进一步定位具体数值算子，也未事后调整门槛。

原始目录：[B宿主](../outputs/official-b-head-20261113/host-v1/)、[B Linux](../outputs/official-b-head-20261113/linux-v1/)、[A Linux补验](../outputs/official-a-replay-20261113-linux-v1/)、[日志与容器回执](../outputs/official-b-head-20261113/records/)。阴性记录为 [NR-031](negative-results.md)；路线和待办见 [唯一执行文档](superpowers/plans/2026-11-13-three-package-finetuning.md)。C 本轮未启动新策略，仍需独立诊断和单独确认。
