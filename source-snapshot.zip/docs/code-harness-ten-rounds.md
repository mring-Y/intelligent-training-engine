# 三包十轮受限代码 Harness 运行说明

本入口为 opt-in，不改变原有默认策略。它把 PyTRiO 模型提出的训练代码写入独立轮次目录，先执行白名单语法和训练能力检查，再调用既有 CPU 续训工具，最后把筛选与独立未来门控结果交还模型选定下一轮检查点。

2026-11-14补充：默认Harness仍为`Qwen/Qwen3.5-4B`。NR-040中4B完成A首轮真实CPU实验，但第二轮两次工具修正用尽仍不合规，A1/10、B/C未开始。用户条件授权“实在不行的话就换成27B吧”后，下一单因素会话通过`--model Qwen/Qwen3.8-27B`显式选择官方27B；它只检验协议完成度，不意味着工业性能或总分更高。原赛题PDF未列4B固定加分，培训纪要仅记录资源分优势，具体新加分口径仍按官方细则。

本次累计上限为`29.99`元，六份既有账本合计`9.40`元，包括未知请求预留。最多两次host工具错误修正对应至多108次请求；网络、JSON或服务用量错误不修正、不重试。27B每次最大保守预留`0.04`元，最坏本会话新增`4.32`元、累计`13.72`元。以下为本次唯一批准会话的命令说明，不可作为失败后的重复执行许可：

```powershell
.\.venv-sft\Scripts\python.exe -X utf8 -m scripts.run_code_harness `
  --mode paid --model Qwen/Qwen3.8-27B `
  --output outputs/code-harness-renewal-20261114/paid-host-27b-v1 `
  --official-python .venv-official-a/Scripts/python.exe `
  --llm-python .venv-sft/Scripts/python.exe `
  --previous-ledger outputs/pytrio-decision-sft-paid-state-20261114/request-ledger.json `
  --additional-ledger outputs/code-harness-paid-state-20261114/request-ledger.json `
  --additional-ledger outputs/code-harness-paid-state-20261114-v2/request-ledger.json `
  --additional-ledger outputs/code-harness-renewal-paid-state-20261114/request-ledger.json `
  --additional-ledger outputs/code-harness-feedback-paid-state-20261114/request-ledger.json `
  --additional-ledger outputs/code-harness-stage-feedback-paid-state-20261114/request-ledger.json `
  --renewed-cumulative-budget-cny 29.99 --proposal-corrections 2 `
  --paid-state outputs/code-harness-27b-paid-state-20261114
```

运行前必须完成本次宿主/断网验证和源码冻结，设置可核验的`ITE_SOURCE_COMMIT`、`ITE_SOURCE_SHA256`与`ITE_SOURCE_DIRTY`；不沿用旧镜像来源。27B tokenizer沿用原有逐文件哈希校验，不擅改旧manifest或下载新权重。后文10元/36次命令按历史日期保留。

## 执行契约

- 工业模型使用随包 A/B/C 官方初始检查点，每轮从上一轮实际选定检查点续训，保留标准化与 Adam。未通过门控的候选不能被选定。
- 大模型只读取显式公开任务说明、续训指南、当前训练函数及已完成历史。它不能读取样本目标、隐藏文件、宿主路径、认证或任意 shell。
- 可写代码限定为一个调用注入训练能力的函数，epochs 仅 1–5、trainable_policy 仅 full/head_only。每次恰好改一个因素；结构、损失、学习率、batch 及训练样本组成固定。AST 全树匹配后才执行；不支持自由 Python 或任意文件修改。
- 十轮是十次真实候选训练、评估和显式检查点选择。筛选拒绝仍是一次实验；DO_NOTHING、数据批次、epoch、模型请求次数不能充数。
- 只使用公开 train 做梯度：A 全部 445 行，B/C 各固定等距 720 行。公开 validation 按顺序切成 21 块，各轮筛选和门控互不重叠，最后一块只作最终开发评估。历史开发已看过这些公开数据，因此不称独立或隐藏测试。
- 每候选 5 秒、每包累计 20 秒，模型请求 15 秒硬截止、零重试。失败默认保留已选定模型。最终开发诊断中的 stable/abrupt/gradual 分数不能反向选模型或修改本轮规则。

## 运行入口

默认演习完全不调用模型服务。它仍使用真实官方 CPU 模型和训练工具，产物的 mode/real_llm 会明确注明：

```powershell
.\.venv\Scripts\python.exe -X utf8 -m scripts.run_code_harness `
  --mode rehearsal --output outputs/code-harness-rehearsal-unique
```

真实调用只用于本轮已批准的一次实验。模型固定为 Qwen/Qwen3.5-4B；单独的模型服务 worker 使用锁定 .venv-sft，不向镜像复制宿主凭证。先完成测试、演习和源码冻结后再运行：

```powershell
.\.venv-sft\Scripts\python.exe -X utf8 -m scripts.run_code_harness `
  --mode paid --output outputs/code-harness-ten-rounds-20261114/paid-host-v1 `
  --official-python .venv-official-a/Scripts/python.exe `
  --llm-python .venv-sft/Scripts/python.exe `
  --previous-ledger outputs/pytrio-decision-sft-paid-state-20261114/request-ledger.json `
  --paid-state outputs/code-harness-paid-state-20261114
```

上例会付费，不是失败后自动重试命令。claim、旧账本、新账本和目录不可重置；旧预算保守占用 9.18 元，本轮可用 0.82 元，36 次请求的最大预留为 0.72 元，累计不超过 10 元。若凭证、价格、响应、资源或门控不符合契约，按实际结果停止或保留 incumbent；不会换成 Mock 补齐真实轮次。

首轮真实提案在执行 CPU 前重复父配置而停止，原始目录保留。后续修正会话必须另外传入 `--additional-ledger outputs/code-harness-paid-state-20261114/request-ledger.json`，将已预留的 0.04 元加回累计支出；此时仅剩 0.78 元。使用新的 `paid-host-v2` 和 `code-harness-paid-state-20261114-v2`，不能重置旧 claim 或原账本。该修正只明确首轮单因素约束，不改变候选白名单、数据、门控或 CPU 配额。

断网 Linux 使用锁定镜像和固定真实提案重放，不再调用 PyTRiO：

```sh
python -m scripts.run_code_harness --mode replay \
  --answers /evidence/paid-host-v1/answers.jsonl \
  --official-python /opt/ite-official-a/bin/python \
  --output /results/linux-replay-v1
```

在镜像中运行真实模式时，显式提供平台允许的模型认证、前一预算记录和可写 paid-state 路径；隐藏数据不挂载。该入口目前实现公开包开发协议，正式评测仍需按平台 SDK 接入其批次、检查点提交、模型服务地址和隐藏评分，不能把此公开回放当作正式成绩。

## 证据与复核

每包 manifest 保留全部训练、筛选、门控、最终评估 ID 以及初始检查点；round-01 至 round-10 分别保存 history-before、模型写出的 training.py、代码检查、候选、原始预测、指标、模型选择理由和 selected 检查点。events 保留冻结先于未来标签揭晓、选择从下一轮生效的时序。总 summary 将工程完成、轮数与开发结果分开。

真实传输另外保存每次 messages、原始响应、解析工具、用量、费用预留和错误状态；answers.jsonl 可驱动无网络重放。SwanLab 上传的 evidence.zip 含逐文件 SHA-256，上传请求成功与服务端独立下载核验分别报告。新的镜像、源码和结果均单独命名，不覆盖旧正式提交镜像。
