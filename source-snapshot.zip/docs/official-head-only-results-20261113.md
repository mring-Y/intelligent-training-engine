# 官方MLP冻结输出头：实现与C包三组开发对照

2026-11-13。用户确认[预登记方案](official-head-only-assessment-20261112.md)后完成。**冻结微调能力接通，但full和head_only均未通过RMSE与寿命高估联合门槛，不晋级默认策略。**

**当前测试流为公开验证集的时序模拟，不代表官方隐藏测试集的真实表现。** 数据已在前轮看过，train/eval是按发动机隔离的开发分区，不是新的独立验收。真实API请求、Teacher费用、LoRA训练均为0；没有低学习率或损失函数变更。

## 实现及接口

官方网络为纯NumPy两层tanh MLP，无需PyTorch、新依赖或降级主环境。主进程NumPy2.3.5、工业worker NumPy1.26.4隔离保持。原始包、官方源码和随包checkpoint未修改。

| 包 | 输入/隐藏/输出 | 全量参数 | head_only可更新参数 | 预测单位 |
| --- | --- | ---: | ---: | --- |
| A | 128/32/6 | 4326 | 198 | 六类概率/类别 |
| B | 34/24/1 | 865 | 25 | 分钟 |
| C | 24/32/1 | 833 | 33 | 周期 |

- [official_finetune.py](../ite/official_finetune.py)：按官方shuffle、损失、完整梯度范数裁剪和Adam方程计算，只更新`w2/b2`。`w1/b1`及其Adam一二阶矩全部保留，不是只把底层梯度清零。
- [official_model.py](../ite/official_model.py)、[official_worker.py](../ite/official_worker.py)、[training.py](../ite/training.py)：`fit(..., trainable_policy="full"|"head_only")`从当前checkpoint继续；默认full仍调用原官方`Model.fit`，同平台检查点与官方CLI逐字节一致。标准化和回归目标缩放保持，NPZ仍`allow_pickle=False`。
- 共享Adam `steps`和训练`epochs`前进，头部优化状态继续，底层优化状态冻结。切回full时沿用官方共享时钟，底层没有单独的“暂停计数器”；分段resume及切回full已测试，不改变官方NPZ结构。
- [harness.py](../ite/harness.py)、[budget_guard.py](../ite/budget_guard.py)、[controller.py](../ite/controller.py)：新`official_finetune`动作profile允许`RETRAIN_HEAD_ONLY`。旧V1及Ridge/Tree继续拒绝它。固定768行窗口含48行筛选、最多720行训练、5epoch、原学习率、候选最多5秒/总训练最多20秒；不兼容配置在训练前拒绝，不能由LLM指定层、学习率或轮数。
- [trio_client.py](../ite/trio_client.py)：新增独立Prompt profile，说明冻结范围和风险，明确`model_age_batches`仅是部署年龄。冻结的`official_sft`历史Prompt保持原样。本轮只以假传输测试真实客户端协议，实际实验用固定动作，不代表新Teacher智能已验证。
- 初始化或运行中回退到Tree/Ridge时，解除仅头Mock并恢复旧动作profile；已有`model_fallback`审计保持。回放严格拒绝额外训练参数，只另外允许白名单审计元数据。

实现冻结提交`e6c2b0ccdc764eeabc97210b6c3ce51eb44d27c0`；独立只读审阅发现的三项边界问题均有红绿测试、修正与复审通过，没有借机调效果参数。

## 固定实验

运行入口：[run_official_head_comparison.py](../scripts/run_official_head_comparison.py)。CPU-C随包FD001–FD004公开验证集23049行、24维，单位均为周期。按排序后的`(subset, unit)`每第五台隔离到eval：train18300行、eval4749行，两分区分别从同一个初始checkpoint初始化并允许各自在流内适配，互不共享模型或标签。

三种场景：stable不变；abrupt从step3起全部特征加0.75倍checkpoint标准差；gradual用4批到同幅度，标签不改。每分区12批、标签延迟1。三个组分别为static、全量full、冻结head_only，合计18条物理流。

full/head均固定step7一次请求，不由漂移报警或Teacher选择时点。相同已释放历史中最近768行，720训练、48筛选；同一父checkpoint、学习率0.002、batch256、5epoch。所有候选的Adam steps从6630到6645、epochs15到20。只改变可更新参数集合。static在该时点DO_NOTHING。

筛选通过后冻结，严格只用`source_step > frozen_at`的未来标签门控。漂移组均在step7冻结，用source8在step9验收，**step10才开始预测v1**。没有把最终高估约束偷偷加入既有MSE门控，没有强制部署失败候选。

## 分区结果

以下为最终Linux结果；宿主逐预测、全部指标数值一致。RMSE/MAE越低越好。

| 场景/分区 | 静态RMSE | full RMSE | head RMSE | 静态MAE | full MAE | head MAE |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| stable train | 53.502742 | 53.502742 | 53.502742 | 39.498344 | 39.498344 | 39.498344 |
| stable eval | 50.350199 | 50.350199 | 50.350199 | 36.593490 | 36.593490 | 36.593490 |
| abrupt train | 128.372756 | 125.309991 | 125.244491 | 98.896085 | 95.669773 | 95.760359 |
| abrupt eval | 124.423732 | 108.331410 | 118.433553 | 95.561219 | 82.330487 | 90.894662 |
| gradual train | 124.304549 | 121.138971 | 121.071214 | 94.379095 | 91.152782 | 91.243369 |
| gradual eval | 120.535091 | 104.241510 | 114.407897 | 91.825120 | 78.820776 | 87.212208 |

高估率为`mean(prediction > target)`；平均正向高估为`mean(max(prediction-target,0))`，分母为所有行，不是仅高估行。

| 场景/分区 | 静态高估率 | full高估率 | head高估率 | 静态平均高估 | full平均高估 | head平均高估 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| stable train | 58.038251% | 58.038251% | 58.038251% | 20.948641 | 20.948641 | 20.948641 |
| stable eval | 53.906085% | 53.906085% | 53.906085% | 16.291311 | 16.291311 | 16.291311 |
| abrupt train | 16.519126% | 18.071038% | 18.229508% | 6.085502 | 6.498474 | 6.765233 |
| abrupt eval | 14.697831% | 20.825437% | 16.403453% | 3.719146 | 5.759287 | 4.479299 |
| gradual train | 16.830601% | 18.382514% | 18.540984% | 6.117819 | 6.530791 | 6.797550 |
| gradual eval | 14.803116% | 20.025269% | 16.487682% | 3.723615 | 5.387094 | 4.480020 |

每个训练策略的stable两分区候选均在筛选阶段拒绝，0部署，故“持平”是未上线。abrupt/gradual四分区分别各1次部署，head的RMSE都低于静态，但两个高估指标全部增加：**full/head各自均为4/4漂移分区安全失败**。共12次真实续训、8次部署，无超时或训练错误。

## 全验证集按原ID合并

将两个实体分区的逐行预测合并后重新计算，未对RMSE简单平均。两个分区经历各自12批，合并只作公开开发汇总，不是一条统一发动机长流。

| 场景 | 模型 | RMSE | MAE | 高估率 | 平均正向高估 |
| --- | --- | ---: | ---: | ---: | ---: |
| stable | static/full/head | 52.868573 | 38.899830 | 57.186863% | 19.989048 |
| abrupt | static | 127.569101 | 98.208972 | 16.143867% | 5.597939 |
| abrupt | full | 122.005150 | 92.921355 | 18.638553% | 6.346172 |
| abrupt | head | 123.871805 | 94.757834 | 17.853269% | 6.294240 |
| gradual | static | 123.537301 | 93.852876 | 16.412860% | 5.624519 |
| gradual | full | 117.855754 | 88.611904 | 18.720986% | 6.295144 |
| gradual | head | 119.728645 | 90.412791 | 18.117923% | 6.320048 |

原始stable完整验证RMSE52.868573与官方约52.87一致。注入漂移后的127.57/123.54是对应模拟流静态对照，不能拿它们与未漂移52.87直接相减来宣称收益。

## 四层诊断及可支持结论

1. **特征/表示**：已验证head候选底层权重、偏置及Adam矩逐字节冻结。相同输入的底层函数未变，但偏移后的输入仍会改变tanh表示。此实验是模拟协变量漂移，不证明观察到物理概念变化。
2. **残差**：突变train上线后共同3050行，静态/full/head偏差分别−116.936431/−92.622893/−89.965304，残差方差6428.575640/6861.880309/7248.656527。head减轻严重低估并降低MSE，但新产生10.262295%高估（静态0%），平均正向高估4.078386周期（静态0）。单看RMSE会漏掉该风险。eval同样：上线后790行head高估10.253165%、平均正向高估4.569576，静态均0。
3. **复杂度**：网络始终24→32→1、833参数，head只更新33参数。冻结不保证头部偏置/权重不会把RUL推高；本轮证据不能把之前full的失败确定归因为灾难性遗忘。head在train略低于full RMSE却更多高估；eval的head比full保守，但RMSE改善也更小，没有全面优胜。
4. **漂移/部署时序**：新模型只在step10–11预测。train的突变与渐变候选各自相同，head对应同一权重、full亦相同，因为最近768行已完全处于相同偏移；不能把这两条结果视为两次独立模型成功。全部原始prediction、筛选、冻结、future gate和版本记录保留。

**结论**：已实质更新官方MLP的权重，RMSE确能改善；冻结底层仍不足以满足寿命高估约束。MSE门控通过不等同于最终安全目标通过。按[NR-027](negative-results.md)归档，不更改默认策略、不输出合格Teacher标签、不继续自动尝试低LR或安全损失。后续若研究不对称损失/安全门控，须另行预登记确认。

## 测试、断网验证和来源

- TDD红测：`records/01-head-red.txt`、`03-actions-red.txt`、`05-comparison-red.txt`；审阅回归红测`10–12`。包括真实非零底层Adam动量、手算一步头部更新、分段resume、原官方预测/全量CLI精度、非法动作和超参拒绝、独立未来标签、部署下一批生效、初始化及运行中降级。
- 最终宿主**533/533**，142.935秒，`records/14-host-final-full.txt`。首批广测的Teacher环境冷导入15秒超时原样保留在`04-actions-green.txt`；没有网络请求或延长截止，随后原代码完整回归通过。
- 最终Linux**532通过、1项宿主专用环境测试跳过**，54.194秒，内存峰值767463424字节（约731.91MiB）。测试及效果两个容器均核实4CPU、8GiB、`network=none`、退出0、OOM=false。
- Linux18条效果流全部工程通过；每流候选训练累计0.115537–0.169893秒，宿主0.337314–0.450537秒。每流仅一次候选，均远低于5秒/20秒，未放宽超时。
- 跨平台18条流共207441个active预测，与static、target、source_id、version数组均逐值完全一致；12份候选的全部参数、Adam矩、标准化和metadata数组也完全一致。
- 候选NPZ**文件字节不相同**：每份15个ZIP中央目录条目只有`create_system`平台字节Windows0/Linux3不同，所有`.npy`载荷字节相同。未修改官方序列化来强行统一文件哈希。初始checkpoint文件字节相同。详见`records/cross-platform-audit.json`。

镜像`ite-official-head:20261113`完整ID：
`sha256:390c433967ed3c789546868eb688c8505d895af12afda1e273ff2b7bcecd6e44`。
固定本地基础`ite-official-sft:20261112`完整ID：
`sha256:f50a9ed1cdd3536effd4438aa8d9996572506e4b9e6740efc1cbfba0a7a6bfe0`。
以`--pull=false --network none`构建，无新依赖下载；这是本轮验证镜像，未更新官方提交标签。

最终镜像源码`e6c2b0c`、dirty=false，core SHA-256
`825aa132330dd964e0345600702e6d33e20e4b9d0b9381b07ce9e49096ce944f`，runner SHA-256
`9929aa40b22deb0f06b06556eb1f60d2e4e244c545f639db7161b96b97c2d158`。
宿主首次效果运行的来源为`a8d2b35`+dirty，core SHA-256
`97c7cf711e9e775ecf38ef076f6dc152388e2e6cc58262c53f9d29ecebd2b958`；之后只收紧动作/降级边界，训练数学与固定实验参数不变，最终Linux重新执行了全部18条流，数值完全复现。两份原始freeze来源不重写为同一版本。

Docker绝对路径CLI可用，但首次启动因旧Secrets Engine socket失效而失败；停止该失败实例后，把仅含零字节socket的目录原位重命名备份，再启动成功，没有重置镜像、数据或账户。构建与运行回执保存在`records/09、15–17`及容器inspect JSON。

## 复现及证据位置

```powershell
.\.venv\Scripts\python.exe -X utf8 -m scripts.run_official_head_comparison --output outputs/official-head-only-new
```

必须使用新输出目录。工业运行时通过`--official-python`或`ITE_OFFICIAL_RUNTIME_PYTHON`指定；不安装或降级主环境NumPy。

原始输出根`outputs/official-head-only-20261113/`：宿主`host-v1/`、最终Linux`container-output/linux-v1/`，均含冻结清单、初始checkpoint、三组逐批事件/预测/候选、`comparison.json`。后处理证据为`records/cross-platform-audit.json`、`residual-audit.json`、`linux-image.json`、两份container inspect及测试日志。[机器验收索引](validation/2026-11-13-official-head-only.json)汇总哈希与状态。只做本地Git归档，未推远程、未新增SwanLab上传。
