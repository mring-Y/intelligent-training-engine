# 安全 TreeModel：2026-11-10 Ridge 对照结果

本轮按已确认方案接入单棵 CART，并在三份已准备公开 A 数据上做固定静态对照；Gas 另外跑了原九批 Mock Harness。源码冻结提交 `5a9da0a`，核心 ITE SHA-256 `7cb52a9d43bc05092e49d266bde67a308945b673bc2c1384d95fb58a53cf4f8c`。树参数固定 `max_depth=6`、`min_samples_leaf=5`、`max_leaf_nodes=64`、`random_state=7`，无深度搜索、类别重加权、重采样或新特征。

## 静态对照

| 数据集 | Ridge | Tree | 变化 | 结论 |
| --- | ---: | ---: | ---: | --- |
| UCI Gas 流 Accuracy，13465条 | 26.067583% | **43.215745%** | +17.148162个百分点 | 静态显著改善 |
| XJTU-SY 流 RMSE，52条，秒 | 3013.330070 | **917.851798** | -2095.478272秒，-69.5403% | 低于1500秒参考 |
| C-MAPSS FD001 流 RMSE，4493条，周期 | 21.383980 | **21.067321** | -0.316660，-1.4808% | 小幅改善 |

Gas Tree 保存了 `(13465, 6)` 概率矩阵，列顺序固定为类别1–6；每行概率和误差为0，预测为六列最大值对应类别。Tree NPZ 加载/遍历不依赖 sklearn、SciPy、joblib 或 threadpoolctl。

## Gas Tree Harness

Tree 静态基线为43.215745%。原有 Mock Harness 仍只按 `drift_alarm` 返回动作，不读取 Prompt；树 Prompt 只完成条件透传。Tree Harness 完成1次 `RETRAIN_SMALL`、3个白名单窗口候选、1次冻结和1次独立 future 门控上线：

| 指标 | Ridge Harness | Tree Harness |
| --- | ---: | ---: |
| 全流 Accuracy | 27.285555% | 42.859265% |
| 实际 v1 后续样本数 | 4364 | 4364 |
| 实际 v1 Accuracy | 32.653529% | 30.980752% |
| 同样本静态 Accuracy | 28.895509% | 32.080660% |
| 严格超过50% | 未通过 | 未通过 |

Tree 候选在 step2 用 192/384/720 条训练数据分别评估，最终冻结窗口384；step5 用 source_step3 的197条独立未来标签验收，step6 开始 v1。Tree v1 后三批 Accuracy 为44.217687%、45.319149%、28.027778%；最后一批低于同批 Tree 静态32.111111%。因此本轮证实的是树基座的静态表达能力提升，不能把 Tree Harness 的上线后结果宣称为调度收益。

完整逐批曲线、事件和实际版本见 `outputs/tree-model-20261110/gas-tree-report/`；Ridge Harness 原报告在 `outputs/gas-harness-cap-20261110/gas-report/`。机器对照见 `outputs/tree-model-20261110/records/experiments/tree-results.json` 和 `linux-tree-comparison.json`。

## 安全与资源

树训练在 bounded spawn worker 中执行，初始训练和候选都不在主进程拟合。NPZ 使用固定数值字段、`allow_pickle=False`、文件/ZIP/NPY header 配额、拓扑校验、float32 语义遍历和原子替换；模型工厂的路径校验和加载共用一个打开的二进制句柄，已修复 TOCTOU 复现。

三份初始训练各测3次冷启动和3次同 worker warm。冷启动 Gas4.3104–4.6102秒、FD0014.3298–4.4506秒、轴承4.2441–4.3209秒；因此树专用上限固定5秒，Ridge仍3秒，总自适应预算20秒。最终镜像 `ite-local:safe-tree-20261110` 使用本地 hash 锁定的 sklearn1.7.2/SciPy1.16.3/joblib1.5.2/threadpoolctl3.6.0 wheel；断网4 CPU/8 GiB完整测试437/437通过，实际三份 Tree 对照和 Gas Harness 逐值复现，峰值内存516866048字节。

本轮没有调用真实 API、没有 LightGBM、没有改变旧 Ridge 默认、没有覆盖旧输出或官方提交镜像。Gas Tree Harness 未通过50%开发目标，已作为 NR-020 归档；静态 Tree 的改善仍是已见公开 A 开发证据，不是隐藏 B 或正式晋级。
