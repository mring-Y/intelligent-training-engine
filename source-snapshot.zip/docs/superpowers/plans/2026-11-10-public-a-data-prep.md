# Public A Data Preparation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Prepare the three user-designated public A datasets and obtain reproducible static baseline results.

**Architecture:** Independent source parsers feed a common immutable package exporter. A standalone static runner consumes the existing Provider and uses the original Ridge or a six-class OVR wrapper. Production defaults and the binary Ridge implementation remain intact.

**Tech Stack:** Python 3.12, NumPy 2.3.5, PyArrow 22.0.0, standard-library HTTP/ZIP/CSV/unittest; no dependency upgrades.

**Spec:** `docs/data-prep-design-20261110.md` (the user's approved 2026-11-10 brief).

## Global Constraints

- No paid API calls; raw data and outputs are immutable and excluded from Git/build context.
- No train/validation/stream entity leakage; fit imputation on train only; never impute targets.
- Keep original Ridge/binary production behavior and independent future gates unchanged.
- Report actual data coverage, target units and acquisition failures. Never substitute Mock data.
- Full required host and offline Linux checks; document any missing evidence.

## Task 1: Common package exporter and UCI Gas

**Files:** Create `scripts/data_prep/{__init__,common,gas}.py`, `tests/test_data_prep_common.py`, `tests/test_data_prep_gas.py`.

**Interfaces:** `export_dataset(output_dir, *, dataset, task, features, train_rows, val_rows, stream_rows, metadata, batch_size=256) -> dict`; `prepare_gas(source, output_dir, *, seed=7, validation_fraction=0.2) -> dict`.

- [x] Write failure tests for train-only medians, missing-label handling, source/ID separation, archive traversal, overwrite refusal and six-class temporal gas splitting. For example a training feature `[1, 3, NaN, 5]` must impute to `3` even when validation contains `1000`.
- [x] Run `.venv/Scripts/python.exe -m unittest discover -s tests -p 'test_data_prep_*.py' -v` and save the missing-feature failures.
- [x] Implement CSV/Parquet output, source receipts and a strict SVMlight parser for 128 indexed features; preserve source batch boundaries and six class IDs.
- [x] Re-run focused tests, download the original UCI archive, prepare the actual Gas package and inspect the manifest.

## Task 2: C-MAPSS FD001

**Files:** Create `scripts/data_prep/cmapss.py`, `tests/test_data_prep_cmapss.py`.

**Interfaces:** `prepare_cmapss(source, output_dir, *, subset='FD001', rul_cap=125.0, train_units=None, val_units=None, stream_units=None, batch_size=256) -> dict`; consumes Task 1 exporter.

- [x] Write and observe failing tests for literal per-unit RUL `[2, 1, 0]`, capping, duplicate/gapped unit handling and complete engine separation.
- [x] Parse the exact 26-column whitespace format, require full run-to-failure source and explicit partitions, preserve within-unit cycles and exclude ID/cycle from predictors.
- [x] Acquire authentic FD001 source with a source/hash receipt; reserve censored official test files. Prepare and validate the Provider-compatible package.
- [x] Run focused tests and record exactly which units and rows were used.

## Task 3: XJTU-SY feature extraction

**Files:** Create `scripts/data_prep/{features,bearing}.py`, `tests/test_data_prep_features.py`, `tests/test_data_prep_bearing.py`.

**Interfaces:** `prepare_bearing(source, output_dir, **options) -> dict`; consumes Task 1 exporter. Feature extraction receives one waveform window plus explicit sampling parameters and returns finite named numeric features.

- [x] Write and observe failing tests: constant-signal RMS/peak-to-peak, a hand-defined envelope-modulated sinusoid's frequency, anti-aliased resampling, dropped tails, whole-bearing splits and seconds-to-end arithmetic.
- [x] Implement NumPy-only analytic envelope/resampling and bounded per-file window processing; audit invalid samples rather than inventing labels.
- [x] Acquire authentic complete bearing trajectories from the author's linked hosts, preserving source receipts; use the documented sample rate and interval.
- [x] Export and inspect the feature package; report exact conditions/bearings and any unavailable downloads.

## Task 4: OVR and static real-data baselines

**Files:** Create `scripts/data_prep/{models,baseline}.py`, `tests/test_data_prep_baseline.py`, dataset usage/results docs; update README with a concise new entry.

**Interfaces:** `OneVsRestRidge` wraps six binary `RidgeModel` instances; `run_baseline(package_dir, output_dir, *, alpha=1.0) -> dict` consumes immutable prepared manifests via `ParquetDataProvider`.

- [x] Write and observe failing tests for six-class score argmax, immutable classes, checkpoint round trip, binary compatibility, Provider prediction commit order and hand-computed RMSE/accuracy.
- [x] Implement the wrapper and static runner; score test targets only after all stream predictions have been committed, save predictions/model/events/metrics/source hashes.
- [x] Run focused tests and the complete existing test suite. Freeze code, record local Git provenance and run one fixed-alpha baseline per actual prepared dataset.
- [x] Validate offline Linux using the fixed image at four CPUs/8 GiB with read-only source/data mounts, without replacing the final submit tag.
- [x] Record metrics, sample/split counts, costs and limitations; update handoff/README. Commit only reviewed source/tests/docs explicitly, leaving all datasets and raw evidence ignored.
