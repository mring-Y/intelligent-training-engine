# Three abrupt changes and official data readiness

Approved by the user on 2026-11-08: execute the four-part design in the preceding conversation, step by step. This document records that scope, not a new approval request.

## Binding design and constraints

- Exactly one paid stream: classification, seed 7, 30 batches, drift policy, regime changes at zero-based steps 2, 10, 18. Initial data and steps 0–1 use A; 2–9 B; 10–17 A; 18–29 B. A/B flip the conditional target relationship.
- At most 5 attempted paid calls across restarts, no automatic retry; CNY 0.16 estimated cap, 20000 token budget, per-call input/output limits 2048/512, inclusive 80% guard. Unknown billing retains its reservation. Paid profile must be an explicit second whitelist, not removal of the earlier smoke restriction.
- 15 second total client deadline; kill/reap the worker. Timeout latches STATIC_FALLBACK, cancels pending and freezes deployment, allowing remaining predictions and audit-only label releases.
- Preserve window/alpha whitelist, preflight, chronological selection, cooldown, label delay 2 and independent future-label gate. No prompt forcing, seed shopping, threshold relaxation or follow-up paid stream to manufacture three iterations.
- Three complete decision/freeze/future-gate chains are a local engineering target, not proof of official eligibility. Keep selection rejects distinct from gate rejects and retain DO_NOTHING/errors.
- OfficialDataProvider exposes initial_data, iter_batches, commit_predictions, request_labels and release_labels. CSV and optional pinned PyArrow Parquet implementations stream explicit column mappings, preserve batch boundaries, never expose labels in PublicBatch, and release labels only after committed predictions. Synthetic defaults remain backward compatible; scorer/truth remain offline.
- SwanLab destination is mring-Y/Intelligent_Training_Engine. Verify PUBLIC and anonymous access; public=True alone does not change an existing project. Record every Action separately with observation/reason/IDs and linked gate outcomes in both upload modes. Only explicit post-run cloud replay; exclude credentials.
- Host and network-none Linux tests; core stable/abrupt/gradual and new profile only, no 144-run matrix. Container limits 4 CPU/8 GiB with peak-memory receipt. Fixed base digest, pinned dependencies, no weights. Full client/Parquet runtime and export/submission each under 2000000000 bytes.
- Keep old raw outputs and the user's existing negative-results.md edit; local Git only.

## Task 1: Data provider and Runner injection

Files: new ite/providers.py, tests/test_providers.py; modify ite/runner.py. Optional dependency requirements-data.txt.

- [x] Red: assert CSV/Parquet parity, streaming boundaries, strict mapping, duplicate IDs, delayed release before/after prediction commit, injected Runner completing batches without simulation truth.
- [x] Green: abstract provider, bounded file reader and label protocol; initial split validation; adapt simulation to same Runner boundary while retaining legacy results.
- [x] Review: ensure labels/metadata do not reach features, delay/ordering and preflight capacity agree, source and batch size are validated.

## Task 2: Hard deadline, fixed triple profile and decision evidence

Files: ite/config.py, ite/data.py, ite/trio_client.py, ite/trio_worker.py, ite/controller.py, new ite/iteration_audit.py, scripts/run_three_abrupt.py, tests/test_three_abrupt.py; extend trio and timeout integration tests.

- [x] Red: reject deadline >15/nonfinite; worker killed and no surviving child; Runner finishes after timeout with no later model work. Triple profile has three changes, 30 batches and cannot expand paid scope.
- [x] Green: end-to-end remaining deadline, fixed profile and script, IDs propagated through experiment/freeze/gate; audit reports exact selection versus future outcomes and prediction-version timing.
- [x] Mock: run fixed triple profile once; require three future chains before authorizing the one paid execution; if insufficient record failure without changing algorithm/schedule.

## Task 3: Public SwanLab and per-Action replay

Files: ite/tracking.py, tests/test_tracking.py; documentation of project-public verification and explicit upload.

- [x] Red: private/unknown project cannot claim public success, single and archive modes each emit one complete Text per Action and linked gate result, no credential files in archive.
- [x] Green: explicit public project settings, verified visibility/anonymous access receipt, event replay including full decision records and selected cost/ledger audit files.
- [x] Review SDK behavior and actual project settings; change only the approved destination when needed, then anonymous verification.

## Task 4: Container, frozen paid run and delivery

Files: Dockerfile, pinned optional runtime lock, README/runbook, result and validation documents.

- [x] Pin and install Parquet dependency; build full runtime without weights and preserve tokenizer hashes.
- [x] Full host suite, independent code review, network-none Linux suite/core integrations at 4 CPU/8 GiB; record lifecycle, peak memory, timeout cancellation and image/export sizes.
- [x] Freeze source/config/hash. Run the one real profile with durable ledger and <=5 calls, 15 s deadline and CNY 0.16 cap. Do not repeat if it fails its three-chain target.
- [x] Audit raw decisions, gate source ordering, deployed-version prediction reproduction, latency and server usage/cost. Append an honest negative record if the target fails before any further strategy work.
- [x] Upload approved sanitized records and verify public receipt; export/reload image and package, hash all evidence, local commits. Report engineering versus official eligibility separately.

## Final disposition

All implementation and validation steps executed. The only paid run timed out on its first request at15.0053992s; three-real-gate target FAILED, NR-016 archived. No repeat or threshold change. Host/Linux278/278; mock3future gates. Public archive8qr4s306 verified. Full results docs/three-abrupt-results.md.
