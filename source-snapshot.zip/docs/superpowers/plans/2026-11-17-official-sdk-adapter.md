# 官方 SDK 模型网关与续训协议适配计划

> 执行方式：在用户已指定的当前 checkout 中按 TDD 顺序执行；每个可验收单元本地留痕。不另开任务、不改变训练策略。

**目标**：修复当前镜像的 `model_calls_required` 与官方 workspace v2 协议不兼容，在真实外部父模型续训上接入平台绑定的模型，并上传修正镜像、保存新版本。

**授权**：2026-11-17 用户在展示【诊断结论】和【准备采用的升级策略】后回复“确认，按上述方案实施”。本轮因素仅为协议和模型网关适配。上传新镜像、保存新版本已授权；本轮不启动正式评测。

**依据**：用户提供的 `contest-harness-sdk-1.0.2.txt` 和同名 tar.gz；后者 SHA-256 `c676c8beeef69cece9cbec5a633d05dbb9832eb22b6f761913f2315bd1f85133`。诊断为 NR-047。

**架构**：官方 template 的 `/app/harness.py` 加 `contest_submission.py`。每轮用 `rnd.model()` 的真实回执决定保留或尝试既有策略；尝试时复用 `ite.continuation.run_round` 的官方 CPU 续训和独立 future gate。候选提交后再让模型阅读真实实验和平台验证摘要，在安全规则内选择候选或父产物。历史、状态、预测均走 SDK。

**固定约束**：NumPy 1.26.4 CPU worker、官方 A/B/C 模型和优化器状态、A step7/48 行回放/full5epoch、B retain、C head-only2epoch、候选5秒/流20秒/最多4次、梯度 train-only、原独立 future gate 均保留。不调用私有模型端点、不读取密钥、不改固定 tokenizer/本地价格表来绕过平台；正式入口不导入这些模块。不伪造调用、历史、父摘要和平台指标。所有新输出独占目录，产物合计不超过64MiB。

## 单元 1：官方源码与失败测试

- [x] 保存原 SDK 包、安装说明和成员 SHA 清单；安全解包到 `third_party/contest-harness-sdk-1.0.2/`，不修改官方源码；宿主安装到现有 `.venv`，不联网解决依赖。
- [x] 在 `tests/test_contest_submission.py` 写真实 SDK Round + 假宿主测试；当前缺失 `/app/harness.py` / `contest_submission.py` 必须使入口可用性测试失败，保留红灯日志。
- [x] 覆盖模型回复改变是否尝试、实际回执引用、官方提示只由宿主附加一次、平台当前绑定模型、父文件摘要不符拒绝、真实外部父、B retain、无模型回执不完成。

## 单元 2：实际适配

涉及文件：`harness.py`（官方 template 原字节）、`contest_submission.py`（薄导出）、`ite/contest_submission.py`（SDK 编排/状态/决策）、`ite/continuation.py`（可选只保留模式，默认旧行为不变）、`configs/contest-contract.json`。

- [x] 用 `rnd.parent.path()` 逐项核对声明文件，选择唯一 NPZ；验证 profile/task，禁止从镜像搜索备用权重。保持真实父元数据，精确保留父 checkpoint；C sidecar 亦需声明校验。
- [x] 读取 `rnd.history()` 和公开投影。向 `rnd.model()` 提供已读历史、真实父状态、公开指标及冻结策略；严格解析 retain/experiment 决策，非法回复保留父模型并记录原因。模型调用失败直接失败，不制造回执。
- [x] `experiment` 才允许运行已冻结 A/C 路线；`retain` 或 B 不训练。复用 CPU `run_round`，保留本地筛选/future gate/资源配额；SDK 原生状态补足跨轮验证 ID 记账，平台指定父永远优先。
- [x] 只有真实候选与本地门控通过才 `submit_candidate`。用平台返回摘要和实际 CPU 报告请求选择决策，指标缺失或保护条件未过时保留父模型，不上报另造的平台成绩。
- [x] 原生状态先 `rnd.state_workspace()` 复制再写，保存真实模型回执、原始回复、候选原因、历史和 ID 记账；`rnd.finish()` 引用实际历史和调用并等待 ack。
- [x] 独立预测按 SDK `Sample` 和 `/model`、`CONTEST_ARTIFACT_PATH` 读取真实 checkpoint，使用固定 CPU worker。逐行 flush、分类唯一最高分、回归非负、task/profile 不匹配拒绝，不接触训练标签。

## 单元 3：宿主与断网 Linux 检查

- [ ] 运行新聚焦测试与完整既有测试；运行 SDK 自带 `test_sdk`、`test_contract_regressions`、`test_transport_regressions`，不运行付费 live 测试。
- [ ] 新增 `scripts/verify_contest_protocol.py`，用假宿主通过真实 stdin/stdout RPC，运行 A/B/C 各10轮接线检查；数据仅用已见公开开发投影，不作独立效果验收，不制造新标签。将所选真实父用于下一轮，验证 state/history 与回执传播。至少分别覆盖 A/C 真训练及 B retain。
- [ ] 对照同一 checkpoint 与官方预测器，验证多行立即应答及 task/context；坏父摘要、模型错误、缺回执应失败，不能悄悄走零调用 fallback。
- [ ] Docker 使用固定已核对父 image ID；仅本地 SDK 安装，无依赖升级。Linux `--read-only --network none --cpus 4 --memory 4g`，只写 `/workspace` 和 `/tmp`；检查 `/previous` `/state` `/model` 和代码只读。
- [ ] 全部原始 stdout/stderr、RPC 记录、检查点/源摘要、资源限制、退出码保存在 `outputs/contest-sdk-adapter-20261117/` 新子目录。阴性/故障如实归档；不把假宿主调用说成真实平台付费调用。

## 单元 4：交付和平台

- [ ] 本地 Git 冻结实现，记录 ITE 源哈希及入口/SDK/配置全文件清单；修改 `scripts/Dockerfile.platform` 为官方入口，保持固定基础和 CPU 环境。
- [ ] 构建新标签、`describe`/训练/预测检查通过后，用真正的 `docker save -o harness.tar <tag>` 导出；校验 tar SHA、大小，实际 load 后 image ID 一致。
- [ ] 上传新 tar，核对平台具体状态；镜像可用后选择用于新版本，保存新提交，不重复运行已拒绝旧版。保留现有模型身份与凭据字段，不泄露密钥。
- [ ] 记录新镜像/版本身份及最后状态。平台协议接受与本地模拟通过分别报告；不承诺隐藏分数，不扩大到新超参或新效果矩阵。

验收门槛：新协议真实进程闭环、逐轮非空有效回执、指定父字节/优化器连续性、真实 CPU 候选、原未来门控未绕过、只读容器和64MiB产物约束通过。修复的目标是官方接入，不改变 NR-046 的 `effect_passed=false` 效果结论。
