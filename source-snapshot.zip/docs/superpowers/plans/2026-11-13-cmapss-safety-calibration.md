# C-MAPSS Safety Calibration Implementation Plan

> **For agentic workers:** Execute inline in the confirmed workspace; repository iteration SOP and the user's confirmation govern scope.

**Goal:** Add an opt-in C-profile downward calibration action and compare static, head-only, and calibrated head-only predictions on the frozen public development flows.

**Architecture:** Keep vendor checkpoint bytes unchanged. `OfficialModelAdapter` owns a validated runtime margin and calibration metadata, persists them in a digest-bound policy sidecar, and applies the margin only to C regression predictions. The controller derives risk only from released labels, obtains 48 calibration rows from the immediately preceding source batch outside the 720+48 candidate window, calibrates before screening, and leaves the existing future-label deployment gate intact.

**Tech Stack:** Python 3.12, NumPy 2.3.5 host, isolated official NumPy 1.26.4 worker, unittest, Docker Linux runtime.

**Spec:** `docs/official-asymmetric-loss-results-20261114.md`, NR-028, and the user-confirmed safety-calibration protocol.

## Global Constraints

- Preserve fixed dependencies, official package/checkpoint digests, and the isolated NumPy 1.26.4 worker.
- Keep training at 720 rows, screening at 48, calibration at 48, candidate timeout at 5 seconds, and total training budget at 20 seconds.
- Use `max(0, empirical_p90(raw_prediction-target))` over all 48 prior-source validation rows; prediction is `max(0, raw - margin)`.
- Calibrated predictions must pass the existing 48-row selection and later independent future-label gate; deployment begins on the next batch.
- Do not expose unreleased labels to observations or change default actions/configuration.
- Preserve all outputs in a new directory and run host plus 4-CPU/8-GiB network-isolated Linux verification.

---

### Task 1: Safety-margin adapter contract

**Files:**
- Modify: `ite/official_model.py`
- Modify: `ite/model_factory.py`
- Test: `tests/test_official_model_adapter.py`

**Interfaces:**
- `OfficialModelAdapter.predict_raw(features)` returns uncalibrated output.
- `calibrate_down(features, targets, quantile=0.9)` sets a C-only runtime policy and returns its audit values.
- `save` writes vendor-compatible NPZ bytes plus a checkpoint-digest-bound JSON policy sidecar; `load_model` restores that policy.

- [x] Test quantile calculation, nonnegative output clamping, C-only enforcement, sidecar integrity, and checkpoint round trip.
- [x] Run the focused tests and verify they fail because the behavior is missing.
- [x] Implement the adapter and sidecar behavior without changing vendor NPZ serialization.
- [x] Re-run adapter/parity tests.

### Task 2: Action and observation contract

**Files:**
- Modify: `ite/harness.py`
- Modify: `ite/config.py`
- Modify: `ite/trio_client.py`
- Test: `tests/test_official_finetune_actions.py`

**Interfaces:**
- `CALIBRATE_DOWN` is accepted only by the C-specific official action profile.
- C observations may carry the validated optional pair `overestimate_rate` and `mean_overestimate`.
- Mock mode `calibrate_down` emits the new action only for official C.

- [x] Test action whitelisting, C prompt/schema, risk-field validation, and default/A/B rejection.
- [x] Run focused tests and verify red failures.
- [x] Implement the opt-in C contract and prompt.
- [x] Re-run action/config/prompt tests.

### Task 3: Disjoint calibration in the controller and replay

**Files:**
- Modify: `ite/controller.py`
- Modify: `ite/official_sft_replay.py`
- Test: `tests/test_official_finetune_actions.py`
- Test: `tests/test_official_sft_replay.py`

**Interfaces:**
- The controller retains at most 48 features/targets per recent labeled source batch for C calibration.
- `CALIBRATE_DOWN` runs the fixed 720/48 head-only candidate, calibrates on 48 labels from the immediately preceding source, then screens and future-gates the calibrated candidate.
- Ineligible, missing, or overlapping calibration evidence rejects closed without training/deployment.

- [x] Test calibration row counts/source IDs, fit ordering, observation risk statistics, next-batch deployment, and missing-window rejection.
- [x] Run focused tests and verify red failures.
- [x] Implement bounded source retention and calibration flow.
- [x] Re-run action/replay/controller tests.

### Task 4: Frozen C comparison and evidence

**Files:**
- Modify: `scripts/run_official_head_comparison.py`
- Create: `scripts/run_official_calibration_comparison.py` only if the existing runner cannot express the registered third arm.
- Modify: `docs/negative-results.md`
- Create: `docs/official-safety-calibration-results-20261113.md`
- Create: `docs/validation/2026-11-13-official-safety-calibration.json`

**Interfaces:**
- Three arms: `static`, `head_only`, `head_calibrated` over stable/abrupt/gradual × train/eval.
- Report RMSE, MAE, overestimate rate, mean positive overestimate, calibration source IDs/margin, deployments, budgets, and verification evidence.
- Freeze/report actual results; if registered safety thresholds fail, append NR-029 before any new strategy.

- [x] Test plan coverage and paired-score criteria.
- [x] Run a new immutable output directory on host.
- [x] Build/use a source-pinned 4-CPU/8-GiB network-none image; run the frozen matrix and full tests.
- [x] Compare host/Linux predictions, labels, margins, checkpoints, and outputs; record exact discrepancies.
- [x] Record the outcome in report and validation index without promoting defaults.

## Completion evidence

Final implementation `d95bc72`, host553/553, Linux552passed+1host-onlyskip, final18-flow paired audit exact; NR-029 records that the joint RMSE/overestimation goal failed. See `docs/official-safety-calibration-results-20261113.md` and its validation index. No strategy/default promotion, paid requests, or LoRA.
