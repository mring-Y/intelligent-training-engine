# C-MAPSS Tree Harness 与条件式真实 Qwen Demo

用户已明确确认本轮方案及补充边界，无需再次确认已批准范围。

## 固定对照

- FD001 原准备包，训练11942、验证4196；stream为unit81–100，共4493条、18批（最后141条）。不重新切分或预处理。
- static Tree vs 修复动作窗口后的正常Mock Harness；Mock仍可按既有逻辑选择SMALL，不强制LARGE。
- 深度6、最小叶5、最多64叶、seed7；窗口192/384/768，标签延迟2；recent_disjoint筛选与独立future gate。
- Tree单候选最多5秒，总自适应训练20秒；最多12候选、5次Mock调用。完整配置见configs/cmapss-harness-tree.json。
- 两条流均完成并保存预测后才做隔离评分；全流RMSE按总SSE/总样本数计算，实际预测版本来自prediction事件，deploy(k)从k+1生效。
- 先失败测试、再实现；宿主全测；冻结Git及配置后单次真实数据运行；断网Linux 4 CPU/8 GiB复现。

## 预登记正向条件（三项全部满足）

1. 至少一次真实模型部署，并有上线后的实际预测。
2. 全流Harness样本加权RMSE严格低于static。
3. 实际上线后样本的Harness RMSE严格低于完全相同样本的static。

未通过则先归档NR-022，保持默认与官方镜像，不调参或重跑策略，不调用付费API。

## 仅当正向时执行的真实Qwen

使用TrioLLMClient及Qwen/Qwen3.8-27B，Gas原短流，最多3请求，单次输入1536/输出128 Token上限，预算不超过0.049元（按锁定单价三次最坏0.04846464元）。15秒端到端硬期限、零重试；超时立即fail-closed，保留当前部署模型完成流，不更换账本绕过熔断。

System Prompt必须包含：

> 当前模型为决策树，对样本规模极度敏感。若观测到的 Loss 波动未伴随剧烈特征漂移，强烈建议输出 DO_NOTHING，避免破坏已有分布。

说明小窗口过拟合与保守决策，不强制某个动作。当前观测没有特征漂移幅度，不虚构此证据。只窄化开放本次Gas Tree付费profile；保留其它付费限制。

真实原始JSON、公开reason、服务端Token与端到端延迟写入Qwen_Live_Decision.md；失败/未调用如实记录，未知Token不能填0。未通过C-MAPSS门槛时，此报告只记录跳过原因，不伪造调用结果。
