# B Source-Balanced Replay Plan

User authorization: “做A的单因素复核，再单独做B的来源均衡实验”. A is closed in local commit `6eaad62`, with NR-044 and its full host/Linux report. Execute this B round inline in the current checkout.

## Diagnosis and fixed factor

NR-031 head-only passed only 2/6 partitions. Official train has 7,032 rows across nine bearings; Bearing3_1 and Bearing3_2 account for about 71.6%. Public validation has 122/42/1515 rows for Bearing1_4/Bearing2_4/Bearing3_4. This motivates a source-coverage hypothesis; it does not establish overfitting or a causal explanation.

Only factor: add 48 original official-training rows to ordinary head-only continuation, replacing exactly the oldest 48 fit rows. Choose five rows from each training bearing, plus one additional row from one deterministically hashed bearing in each operating condition. Each bearing has 5–6 rows and each condition has 16. Rank rows by a separate fixed SHA-256 namespace; do not rank by target, residual, future outcome or validation data. All nine train bearings and row IDs must be disjoint from validation.

## Protocol

- Arms: static / ordinary head-only / head-only with balanced replay.
- stable/abrupt/gradual × train/eval × three arms = 18 flows per platform.
- Every arm uses the same official B checkpoint and existing source split. Both head arms make one decision at step7.
- Keep 5 epochs, 25 trainable head parameters, original Adam/LR/batch size and normalization; preserve all 840 bottom-layer parameters and their Adam moments.
- Existing released-public-validation development replay: train fit/screen is 720/48, eval is 54/18; both head arms use the same counts. Original historical replay features are unshifted. No hidden data, new official evaluation, paid model call or default Harness change.
- Keep existing simulated covariate shifts, independent future gate, deploy(k) effective from prediction(k+1), 5-second candidate limit, 20-second flow limit and maximum four attempts.
- Stable requires RMSE and MAE no worse than paired static. Every drift partition requires strictly lower RMSE and nonincreasing MAE. Pooled scores and per-bearing bias/dispersion are additional disclosures; do not replace the registered partition gate.
- Do not mix A timing into this experiment, reweight loss, increase replay rows, change screening, or select a different strategy after seeing scores.

## Test-first implementation

- [x] Add failing tests for deterministic, target-independent 5–6-per-bearing/16-per-condition sampling, exact original row provenance, invalid metadata/features/labels and ID/entity overlap rejection.
- [x] Add failing integration tests for 48-oldest replacement, unchanged fit/screen sizes, head-only routing, future independence, next-batch deployment, and insufficient-history refusal without padding.
- [x] Add failing comparison tests for pairing, six-partition thresholds, fixed step7 and per-bearing residual metrics.
- [x] Implement the minimal opt-in selector/replay branch and dedicated B comparison runner; default replay remains none.
- [x] Run focused tests and preserve the red/green evidence.

## Experiment, audit and closeout

- [x] Freeze source/configuration/checkpoint/reserve hashes into new outputs under `outputs/official-b-source-replay-20261115/`.
- [x] Run the host 18-flow matrix. Audit gradients, reserve provenance, screen/future IDs, checkpoints, actual prediction versions, per-bearing residuals, deployment segments and budgets.
- [x] Archive failed pre-registered outcomes in `docs/negative-results.md` before considering another factor.
- [x] Complete required host regression tests using the unchanged offline/single-thread environment.
- [x] Build a new validation layer over base `sha256:76476d088433a4bb20a00d6eed16b136062ffe670a8d7541b727ce6ef8eb5228` with `--pull=false --network none`, no dependency installation.
- [x] Run tests and the same 18-flow matrix in Linux, 4 CPU/4 GiB/network none. Record exit/OOM/resource receipts and compare predictions/checkpoint array payloads.
- [x] Save SwanLab offline metrics/evidence, write report and machine index, and commit this B unit locally without pushing. Do not change the previously delivered default image or claim hidden acceptance.

## Closeout

Host/Linux matrices, tests, source/residual/timing/checkpoint audits and offline SwanLab evidence completed. Head-only passed 1/6 and replay passed 2/6 strict partitions; both pooled primary metrics regressed. NR-045 is archived. Retain B static and the prior delivery image; no next strategy is authorized by the failed result.
