# Official A Replay Timing Review Plan

> **For agentic workers:** Execute inline in this session with test-first checkpoints; the user explicitly authorized A followed by a separate B experiment. Steps use checkbox syntax for tracking.

**Goal:** Test whether delaying the existing class-balanced A replay candidate from step 3 to step 7, with all other policy and safety controls fixed, gives eval candidates a larger screening set and improves paired Macro-F1 without reducing Accuracy.

**Architecture:** Add a dedicated comparison runner using the existing `replay_partition` implementation. Run static, replay-at-step-3, and replay-at-step-7 as three arms across stable/abrupt/gradual and train/eval, then report per-partition metrics, decision/sample timing, deployments, and residual post-deploy segments. The experiment does not change the production controller or default policy.

**Tech Stack:** Existing Python 3.12.14, NumPy 2.3.5 main runtime, isolated `.venv-official-a` worker, `unittest`, existing official CPU package and Docker base image.

**Spec:** User-approved sequential A timing review followed by B source balancing; [NR-030](../../negative-results.md), [iteration SOP](../../iteration-sop.md), and [official A replay runner](../../../scripts/run_official_a_replay_comparison.py).

## Global Constraints

- Keep the 48-row class-balanced official A training reserve and 5-epoch full-resume behavior fixed.
- Keep the current screening rule, independent future-label gate, 5-second candidate limit, 20-second per-flow training limit, and maximum four attempts.
- Change only the candidate decision schedule: step 3 versus step 7; static is the paired baseline.
- Use the same official checkpoint, public package, source partitions, scenarios, transforms, and paired source IDs.
- Stable requires Macro-F1 and Accuracy no worse than static; abrupt/gradual require Macro-F1 strictly higher and Accuracy no worse in every train/eval partition.
- Do not force deployment, use hidden labels, make paid model calls, or rewrite existing raw outputs.
- Record all three scenarios, per-partition and post-deployment segments, source IDs, costs, hashes, and container receipt.
- Do not start the B experiment until A's outcome is fully recorded; if A misses its gate, append the four-field negative entry first.

---

### Task 1: Add the decision-time comparison contract

**Files:**
- Create: `scripts/run_official_a_replay_timing_comparison.py`
- Test: `tests/test_official_a_replay_timing_comparison.py`

**Interfaces:**
- `case_plan()` returns 18 cases with `scenario`, `split`, `arm`, `decision_steps`, and `expected_screening_samples`; arms are `static`, `replay_step3`, and `replay_step7`.
- `summarize_a_timing_paired(predictions, scenario)` validates same IDs/targets/static outputs and returns scores plus the NR-030 pass status for both timing arms.
- `_engineering_ok(arm, summary, events, expected_screening_samples)` validates the registered step, schedule-derived screening count, one candidate, budget, prediction count, source disjointness, and future-gate evidence.
- `run_comparison(output, runtime_python=None)` creates a new output directory and writes `initial.npz`, `freeze.json`, per-flow artifacts, and `comparison.json`.

- [x] **Step 1: Write the failing tests**

Add tests that assert:

```python
cases = module.case_plan()
assert len(cases) == 18
assert {case["arm"] for case in cases} == {"static", "replay_step3", "replay_step7"}
assert module._case_for("abrupt", "eval", "replay_step3")["decision_steps"] == (3,)
assert module._case_for("abrupt", "eval", "replay_step7")["decision_steps"] == (7,)
assert module._case_for("abrupt", "eval", "replay_step3")["expected_screening_samples"] == 18
assert module._case_for("abrupt", "eval", "replay_step7")["expected_screening_samples"] == 41
assert module._case_for("abrupt", "train", "replay_step7")["expected_screening_samples"] == 48
```

Also assert that candidates match the unchanged screening-rule sample count, candidate data and screen IDs are disjoint, future IDs are disjoint from both, and a Macro-F1 increase cannot pass when Accuracy falls below static. At eval step 7, 164 released rows yield 41 screening rows under the existing `released_rows // 4` rule. Reaching 48 at step 9 leaves no post-deployment predictions after the independent future gate.

- [x] **Step 2: Run tests and verify the expected failure**

Run: `.\.venv\Scripts\python.exe -m unittest tests.test_official_a_replay_timing_comparison -v`

Expected: the new module import fails because the dedicated runner does not exist yet.

- [x] **Step 3: Implement the minimal runner**

Reuse `load_public_package`, `split_sources`, `OfficialModelAdapter`, `replay_partition`, `source_metadata`, and `write_json`. The static callback always returns DO_NOTHING and creates no candidate (the existing replay core uses its default NO observation times when passed an empty schedule). Both replay arms use `RETRAIN_LARGE`, the same 48-row class-balanced reserve, and exactly one decision at their named step. Keep the current `replay_partition` screen and future-gate logic unchanged. Freeze the package/checkpoint/source hashes, exact arm schedule, thresholds, and all resource limits before running the matrix.

- [x] **Step 4: Run focused tests**

Run: `.\.venv\Scripts\python.exe -m unittest tests.test_official_a_replay_timing_comparison tests.test_official_a_replay_comparison tests.test_official_sft_replay -v`

Expected: all focused tests pass; the existing A comparison tests remain unchanged and pass.

### Task 2: Run and audit the A matrix

**Files:**
- Output: `outputs/official-a-replay-timing-20261115/host-v1/`
- Receipt: `outputs/official-a-replay-timing-20261115/records/`
- Report: `docs/official-a-replay-timing-results-20261115.md`
- Negative entry on failure: `docs/negative-results.md`

- [x] **Step 1: Run the new 18-flow public development matrix**

Run: `.\.venv\Scripts\python.exe -m scripts.run_official_a_replay_timing_comparison --output outputs/official-a-replay-timing-20261115/host-v1 --official-python .venv-official-a/Scripts/python.exe`

Expected: 18 complete flows; step-3 screening has 48 train/18 eval rows and step-7 screening has 48 train/41 eval rows under the unchanged rule; no source overlap; candidate/future evidence remains in events; no flow exceeds 20 seconds and no candidate exceeds 5 seconds.

- [x] **Step 2: Verify the pre-registered outcome**

Read `comparison.json`, `events.jsonl`, `predictions.npz`, and checkpoints. Report all static/early/late scores by scenario and split, classes represented in each screening set, deploy step and effective prediction step, same-ID post-deploy metrics, training time, and evidence hashes. Apply the stable/drift criteria without retuning.

- [x] **Step 3: Complete fresh focused and full host tests**

Run the focused command above and the repository full suite in the project's documented offline/single-thread environment. Preserve any failed attempt log and the unchanged timeout/dependency contract.

- [x] **Step 4: Verify the frozen result in a network-disabled Linux container**

Build from the current frozen source and fixed base image without pulling or installing dependencies. Run tests and the same 18-flow matrix with 4 CPU, 4 GiB, and `network=none`; compare predictions, event/source bindings, and checkpoint arrays with host output. Do not report container success if Docker is unavailable.

- [x] **Step 5: Record and close A before starting B**

Write the complete result and machine verification record. If no arm meets the pre-registered rule, append the four required fields to `docs/negative-results.md`. Commit only the A code/tests/docs and evidence index locally; do not push. Only after this closeout begin the separately confirmed B source-balance round.

## Closeout

Host and disconnected Linux evidence completed. Both timing arms pass 4/6 strict partitions. Step7 improves pooled Macro-F1 and Accuracy with no observed partition regression; no default promotion. See NR-044 and docs/official-a-replay-timing-results-20261115.md. The separate B source-balance round is next.

## User-confirmed integration into the C2 image

The user subsequently instructed “那就合入新的策略”. B's source-balanced experiment has closed in NR-045 and local commit `fada509`, with B retained static. This current authorization integrates the A step7 replay schedule with C2 in the existing delivery entrypoint; it does not authorize new hyperparameter searches or copying NR-044's validation-gradient score into the train-only image.

Official `public/train` remains the sole gradient source. A excludes its 48 class-balanced reserve from the clocked train stream and replaces exactly the oldest 48 released fit rows with the original reserve, makes one full/5-epoch attempt at step7, and retains the existing screen and independent future gate. C keeps the prior loss-triggered head-only/2-epoch route, while B stays static. The historical validation-gradient timing result remains separately archived.

The new image flag is `--a-step7-replay --c-epochs 2`. Old C-only and original override entrypoints remain available. The default new image must run the comparison rather than unit tests. No real Sampler requests, new platform trials, dependency upgrades, gate changes or budget increases are included.

Pre-registered integration criteria use the existing whole-flow contract: A composite Macro-F1 gain at least .005, each merged scenario primary nonworse and Accuracy drop at most .005; C composite RMSE improvement at least 1%, existing MAE/rate/positive-overestimate tolerances and scenario guards unchanged; B remains paired static. All partitions and deployed same-ID segments are still disclosed. This integration criterion does not rewrite NR-044's historical all-partitions-strict gate. Failed engineering/effect checks do not promote a default image, and must be archived before another factor.

- [x] Fail six new routing/data-isolation/future-rejection/acceptance tests, then implement the minimal entrypoint option and new image recipe.
- [x] Pass 20 focused tests, including old C2 routes and actual CPU integration tests.
- [x] Freeze source, run full host regression and the 54-flow paired combination, audit gradients, models, source clock, predictions, selected checkpoint and sidecar bindings.
- [x] Complete pinned 4CPU/4GiB/network-none Linux tests and default-entrypoint 54-flow replay; compare with host and prior C2/B controls.
- [x] Record any failure first; save SwanLab offline evidence, build/export/reload the appropriate candidate image, publish exact image/source/evidence checksums and an honest delivery status.
- [x] Commit the accepted unit and result documents locally without pushing; leave the old tar and all raw results intact.

Runtime committed locally as `10d0fda`. Host full regression passed 717/717 in 403.966 seconds; Linux 716 passed/1 host-only skip in 114.795 seconds. Both platforms completed all 54 flows with exactly matching predictions; checkpoint maximum array difference is 5.55e-17. B/C match prior C2 payloads. The A audit shows no observed partition regression, but pooled Macro-F1 gain is only 0.0000935638469296, below the frozen 0.005 criterion. NR-046 records the effect failure before packaging; new image `ite-ac-policy:20261115-v1` was exported/reloaded as a reproducible integration candidate, without automatic replacement of the previously accepted C2 image. SwanLab offline `kffgpsrl` archives 698 verified evidence files. Result report, machine index and delivery checksums complete the local closeout without further training or strategy changes; final local Git receipt is `outputs/ac-policy-integration-20261115/records/20-final-local-git.json`.
