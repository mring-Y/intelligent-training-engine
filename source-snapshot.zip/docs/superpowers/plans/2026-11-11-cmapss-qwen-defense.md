# C-MAPSS Qwen 防守决策演示

2026-11-11。用户明确授权对冻结FD001配置进行一次真实PyTRiO/Qwen决策流，并提交结果；本演示不做指标调参或晋级。

## 固定输入与提示

- 原A包FD001，训练11942、验证4196，在线流4493样本/18批；沿用label_delay=2和所有固定批次边界。
- 漂移决策在step10触发，发送已释放source4–8的Loss及各来源样本数（每来源256），不发送未揭晓标签或原始传感器向量。
- System Prompt引用同流既往192行候选/48行独立筛选证据：候选RMSE29.77、incumbent28.25、`not_better_on_selection`。明确这只是一个被拒候选，不足以证明普遍过拟合；此前`feature_shift=false`是历史诊断，不伪装成当前Observation字段。
- Qwen自行选择白名单动作；未来标签门控、训练候选筛选和当前模型保底均保持原逻辑。

## 实时与费用边界

- 只准Qwen/Qwen3.8-27B、最多2次请求；输入<=1250、输出<=128，超时15秒，真实账本费用<=¥0.03。
- 锁定单价8.41/25.29元/百万Token，两次最大预留¥0.02749924。
- `HTTPTransport(retries=0)`和单次worker POST；超时即fail-closed，不重试，剩余预测由当前部署模型完成。
- 固定单次run-claim及durable ledger，启动前检查数据manifest、既有step10证据、tokenizer和配置。claim被使用后不另建预算重跑。

## 训练时限说明

当前宿主上的15秒冷启动诊断为6.19秒，其中spawn启动0.72秒、sklearn导入4.77秒、fit0.13秒、IPC5.46秒。5秒旧上限不足以让这台机器到达step10。仅为该固定付费profile增加`tree_initial_timeout_seconds=8`；普通配置默认仍5秒，候选`tree_timeout_seconds`仍5秒，candidate startup reserve及总自适应20秒不变。

## 交付证据

原始真实响应和实际token/费用来自事件与CallLedger，不从Mock事件推断。报告按run claim、事件和ledger写入`Qwen_Live_Decision.md`。网络超时则记录原始响应和token为未知、已预留费用、熔断时点以及最终预测完成批数。结束后更新NR-022补记及最终交付文档；原始FD001 RMSE对照保持冻结。
