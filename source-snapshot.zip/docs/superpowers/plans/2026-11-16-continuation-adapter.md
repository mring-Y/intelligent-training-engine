# 官方CPU续训与预测适配实施计划

> **For agentic workers:** Use superpowers:executing-plans to implement this plan task-by-task in the current checkout. No subagents are needed.

**Goal:** 让新镜像接收真实外部父检查点及显式数据，交付可独立预测的官方NPZ和真实历史。

**Architecture:** 新增CLI适配层，复用现有OfficialModelAdapter、12批时序释放、A step7回放/B静态/C head-only2epoch策略与future gate；不注入模拟漂移。模型交付与详细审计目录分开。预测以单独NumPy1.26.4进程常驻读取JSONL，避免每条请求启动解释器。

**Tech Stack:** 已冻结Python/NumPy双环境、unittest、Docker Desktop，新增依赖0。

**Spec:** [本轮诊断及用户确认范围](../../image-protocol-audit-20261116.md)。用户2026-11-16明确要求“那你进行补齐操作”。

## Global Constraints

- 仅改协议适配；A/B/C规则、训练轮数、学习率、独立门控及5秒候选/20秒流/最多4次配额不变。
- 训练仅来自显式传入train，validation只作监测、筛选及晚于冻结批次的future验收。数据原始顺序保留，无合成偏移。
- 必须提供外部父模型；不从头训练，不在父模型无效时回退到镜像内官方起点。
- 产物为真正官方checkpoint.npz、training.json、history.jsonl、C绑定策略（如适用），总计不超过64 MiB；不可覆写。
- 传入父历史须与实际父模型绑定；已有标签不可包装为新的future证据。历史缺失与数据不足明示，保留父模型。
- 未知平台调用约定不假称官方认可，提供本镜像明确命令与环境变量合同并本地验证。
- 断网4CPU/4GiB容器验证，固定父镜像身份/依赖、导出load核验，本地Git留痕，不上传平台。

## Task 1: 失败测试与严格输入边界

**Files:** `tests/test_platform_adapter.py`, `ite/platform_data.py`。

**Interfaces:** `read_dataset(path, profile, expected_paths)`返回显式数据的x/y/ids/schema/hash；`checkpoint_metadata(path)`在16MiB及官方格式边界内读取元信息。

- [x] 先编写失败测试：外部父模型必填、重名输出拒绝、JSON重复键/标签派生特征/未知类别/非有限目标拒绝、schema不匹配拒绝。
- [x] 运行`python -m unittest discover -s tests -p test_platform_adapter.py -v`，记录因入口未实现失败的真实输出。
- [x] 实现严格JSONL读取和checkpoint元信息边界，保留官方类别顺序与归一化状态。

## Task 2: 单轮续训及真实历史

**Files:** `ite/continuation.py`, `train.py`, `tests/test_platform_adapter.py`。避免用`platform.py`遮蔽标准库，隔离worker从ite目录启动时必须仍能导入NumPy。

**Interfaces:** `run_round(profile, train, validation, parent, output, stage_id, runtime_python, parent_history=None, audit_output=None)`；`main(argv=None)`接受官方参数拼写和本镜像ITE_*环境变量。

- [x] 先测试B的零更新真实交付、A固定时点/C规则路由、门控拒绝保留传入父模型、未知父历史不宣称独立未来、审计与产物目录隔离。
- [x] 复用`replay_partition(..., scenario='stable', training_stream=explicit_train)`，其中stable仅表示不注入人为偏移；仍监测真实特征距离和已释放损失。
- [x] 所有产物来自本轮实际执行。报告绑定父/输入/源码/输出摘要、初始/最终steps/epochs和实际训练次数；history保留实际事件，不补造逐epoch记录。
- [x] 输出在新目录临时准备、大小检查后发布；并发/重入不能覆盖现有结果。详细审计不混入64MiB交付目录。
- [x] 使用已有真实检查点和训练样本做两轮续接测试，验证第二轮读取指定父模型而非初始模型；若平台拒绝前候选仍按指定父模型开始。

## Task 3: 独立预测

**Files:** `ite/platform_predict_worker.py`, `predict.py`, `tests/test_platform_adapter.py`。

**Interfaces:** `predict.py --checkpoint ... [--profile A|B|C]`读取stdin JSONL，仅允许task/inputs，输出官方outputs结构。

- [x] 先测试A/B/C输出与官方CLI一致、显式checkpoint加载、输入含answer拒绝、schema变化拒绝、C绑定策略保留。
- [x] 由包装器验证官方包及checkpoint后启动固定隔离Python；worker使用同一Model常驻，不逐条创建进程。
- [x] 无联网安装、隐藏标签访问或预测时训练。

## Task 4: 镜像与交付验证

**Files:** `scripts/Dockerfile.platform`, `configs/continuation-contract.json`, `docs/continuation-adapter-results-20261116.md`。

- [x] 新镜像入口为本轮适配器；旧54流对照仍可显式运行。训练/预测命令、输入挂载、产物和历史契约写入文件并测试。
- [x] 宿主聚焦19/19及完整736/736通过后冻结提交`8853fca`与源码摘要，从已核对身份的本地父镜像构建，不新增依赖。
- [x] 断网Linux完整测试736项中735通过、1项宿主专用跳过；A/B/C双轮实际命令、父模型链、预测、拒绝路径及64MiB限制通过；不把接口验证当新效果验收。
- [x] `docker save`导出新`harness.tar`，`docker load`后镜像身份相同且独立预测相同；旧镜像和原始输出保留，本地交付索引与Git记录完成。

## 验证边界

本轮验证续训/预测合同与来源真实性，不重新选择策略、不调参，不把已有公开数据重新称为独立验收；正式平台启动合同和试运行仍需平台回执。B零更新如实记录，不伪装发生续训。涉及父模型链的训练仅为已授权协议测试，不增加远程费用或试运行次数。

## 已完成的审查与当前状态

19项本轮聚焦测试全部通过（202.705秒）。独立只读代码审查发现并经失败测试修复：跨轮缺失历史重置、训练/验证角色互换、平台拒绝候选后父模型绑定、历史前缀截断、缺失祖先状态传播和官方初始训练ID锚定。复核未发现新实质问题。宿主完整测试第二轮736/736通过（691.986秒）；首轮旧SFT环境15秒导入超时及单项复核通过日志保留，未修改时限。Task 4断网Linux、A/B/C真实双轮、save/load与预测复核均已完成，回执和交付路径见结果文档与`outputs/continuation-adapter-20261116/DELIVERY.md`。仍未取得平台实际调用合同、十轮调度说明或正式兼容回执，因此不宣称平台接受。
