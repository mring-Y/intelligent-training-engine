# PyTRiO 真实冒烟与成本保护实施计划

> **For agentic workers:** Use superpowers:executing-plans inline, task by task; retain the red/green receipts. User approval to implement and run the bounded paid smoke was received in this conversation on 2026-11-07.

**Goal:** 实现受限真实客户端、明确免费标签协议、持久成本保护与审计，完成唯一真实闭环，通过后执行 144 次 Mock 压力验证。

**Architecture:** Controller 只在漂移、新证据、冷却及验收可行时调用；BudgetGuard 在发送前持久预留，返回后先结算再解析。可终止子进程通过官方 OpenAI 兼容 completions 端点只发送一次 HTTP 请求，无重试。模型自带模板本地渲染并关闭 thinking；SDK 复用既有认证状态，不创建训练/采样服务会话。此传输选择使用原设计已列出的官方兼容方案，避免原生运行时隐藏重提与额外生命周期。

**Tech Stack:** Python 3.12 / 标准库 / NumPy 2.3.5；真实调用可选 PyTRiO 0.2.9 和 tokenizer。离线核心依赖、基础镜像摘要保持。

**Spec:** 本次用户确认的客户端方案及 [培训规则对照](../../competition-briefing-notes.md)。

## Global Constraints

- 仅 classification / abrupt / seed 7 / 96 批 / drift 发起真实调用；至多 10 次、本地预估费用上限 0.50 CNY。充值 50 元不扩大本轮实验预算。
- 2026-11-07 从官方公开价格页 https://pytrio.com/home/pricing 核实 Qwen/Qwen3.8-27B：prefill 8.41 CNY/M token，sample 25.29 CNY/M token；不预先抵扣缓存折扣。
- 输入最多 2048、输出最多 512 token，单请求总等待 60 秒，并发 1；HTTPTransport(retries=0)，单次 POST，禁用隐式代理。
- label_mode=budgeted 保留历史；provided 是明确的模拟协议（每批完整标签、仍延迟释放），不冒充未发布 SDK。Observation V2 用 null 明示无标签申请额度。
- future 独立标签门控、候选白名单、预检、训练超时与资源上限始终保留。熔断取消 pending，禁止训练/切换/LLM，继续预测。
- 原始输出不覆写；不改用户已有阴性文档；不自动上传、改公开设置或推远程；三次迭代要求单独如实审计。

## Task 1: 标签供给契约

Files: `ite/config.py`, `ite/data.py`, `ite/labeling.py`, `ite/budget.py`, `ite/harness.py`, `ite/budget_guard.py`, `ite/controller.py`, `ite/runner.py`; tests `tests/test_label_protocol.py`。

Interfaces: `ExperimentConfig(label_mode="budgeted"|"provided")`；`ResourceBudget.remaining_label_budget` 返回 int 或 None；`LabelAvailability.remaining` 接受 None；Observation 保持五字段，V2 接受 null。

- [x] 写失败测试：provided 超过旧零额度仍释放已预测标签；未来样本不可申请；None 容量与时序；Guard 不因免费标签熔断；预算模式继续耗尽。
- [x] 运行 `python -m unittest discover -s tests -p test_label_protocol.py -v`，保存失败日志。
- [x] 最小实现：provided 逐批申请全部样本，oracle limit=None，资源仅统计标签量；guard 仅检查真实存在的配额。
- [x] 同命令转绿，再跑原 Harness / 标签测试。

## Task 2: 真实客户端与平台传输边界

Files: `ite/trio_client.py`, `ite/trio_worker.py`, `ite/harness.py`, `ite/config.py`, `requirements-pytrio.txt`; tests `tests/test_trio_client.py`。

Interfaces: `TrioLLMClient.get_decision(observation)->LLMReply`；reply 扩展 input_tokens/output_tokens/stop_reason；`ite.trio_worker.sample_chat(request)->dict` 只执行一次 HTTP 生成请求，函数名沿用角色消息输入。

- [x] 失败测试覆盖 System/User 隔离、合法消息、生成硬上限、单结果、次数限制、非法用量、超时终止及无重试错误。
- [x] SDK 认证状态及 HTTP 仅在工作进程中延迟导入；tokenizer 使用预先准备的本地目录；输出只传受限响应和计量，错误不传凭证或完整异常。
- [x] 严格原始 JSON 解析在 Guard；不得剥除推理文本、修复 JSON 或追加模型调用。
- [x] 单测转绿，完全断网不要求安装可选 SDK。

## Task 3: 持久调用/成本账本与 Guard

Files: `ite/llm_ledger.py`, `ite/budget_guard.py`; tests `tests/test_real_budget_guard.py`。

Interfaces: `CallLedger(path, identity)` 获取 OS 文件锁，原子持久化 reserve/settle/trip；Guard 从账本恢复累计调用/已知用量/未知预留，使用 Decimal 计算费用。

- [x] 先失败：第 11 次不发送、重启不清零、未结算请求失败关闭、第二写者不能重开额度、账本身份不匹配拒绝、逐请求价格与总计校验、金额边界、80% 预留边界。
- [x] 先结算真实用量后解析；非法 JSON 有用量照计；异常/缺用量保留最大预留；账本写失败先熔断，不能先发送再补账。
- [x] 增补 inclusive 边界与冻结回归后转绿；保留旧 Mock 固定 8 计量语义。

## Task 4: Controller / Runner 接线

Files: `ite/controller.py`, `ite/runner.py`, `ite/config.py`, `ite/cli.py`, `configs/harness-trio-smoke.json`; tests `tests/test_real_harness_integration.py`。

- [x] 失败测试：真实模式不因 stable 新证据发请求；DO_NOTHING 也进入调用冷却；无未来验收容量不付费；真用量摘要不冒充 Mock；熔断先于同批验收。
- [x] 显式 backend=mock/pytrio；默认旧行为兼容，新的 drift_only 调用策略与 provided 模式通过配置启用。
- [x] CLI 必须阻止真实客户端用于 matrix 或多策略 run，避免付费配置误进全量矩阵；close 在成功/失败退出均执行。
- [x] 宿主完整测试转绿。

## Task 5: 成本投影与 Mock 矩阵脚本

Files: `ite/llm_audit.py`, `scripts/audit_llm_cost.py`, `scripts/run_harness_matrix.py`; tests `tests/test_llm_audit.py`, `tests/test_harness_matrix.py`。

- [x] 手算夹具：100 输入 + 20 输出费用 0.0013468 CNY；缺用量保留未知额；100 批投影以漂移次数 K 为参数，分别输出无上限与 min(K,10)，不把批次当调用。
- [x] 144 次 = 正常两任务×六场景×三种子×static/drift 的 72，加 drift 的 invalid_json/token_exhausted 72；全部 96 批、纯 Mock、费用零。
- [x] 脚本拒绝真实 backend、已有输出目录；审计模型/候选/门控/熔断事件与完整预测，不把稳定流无调用称作故障已触发。
- [x] 单测转绿，准备固定配置和不可覆写记录目录。

## Task 6: 验证、付费门槛与交付

- [x] 本地提交精确代码/测试/配置文件，不纳入用户既有 `docs/negative-results.md` 改动。
- [x] 从冻结源码构建，宿主与 4CPU / 4GiB / network=none Linux 完整测试；另记录培训资源要求 4核8G，不能把历史回执改称新配额验证。
- [x] 官方价格、SDK版本、tokenizer文件哈希、模型可用性核验后，在获准网络执行唯一真实配置；过程逐次输出已知 Token/费用/延迟。
- [x] 付费通过须有服务端用量、合法 JSON、重训/冻结/独立未来验收实际覆盖；DO_NOTHING 全程则明确缺测，不强制部署、不追加付费场景。
- [x] 通过后断网 Linux 跑上述 144 Mock 次矩阵；保留所有原始产物、审计结果、检查点和来源，生成成本投影。
- [x] 如失败，先追加本轮阴性事实记录（保留用户原有字节内容），不得用失败自动授权新策略或额外付费。
- [x] 完成独立审查、必要修复回归、镜像/来源校验和结果文档；不把工程通过写成官方效果晋级。

## 实施回执（2026-11-07）

冻结源码 b7713af。宿主与断网 Linux 各240/240，唯一真实流2次请求/1142Token/预估0.01114030元，重训与未来门控覆盖；144次Mock矩阵完成。全部13920批预测可精确重建，导出重载一致。详见 [结果](../../harness-pytrio-results.md) 和 [机器回执](../../validation/2026-11-07-pytrio-smoke.json)。保持 development 分支，仅本地提交，无新工作树、推送或云端上传。
