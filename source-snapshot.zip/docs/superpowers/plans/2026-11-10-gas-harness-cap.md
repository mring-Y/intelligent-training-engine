# Gas Harness and RUL Cap Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Run the specifically approved Gas Mock intervention and bearing Cap baseline, preserving independent future-label deployment evidence.

**Architecture:** Add an explicit OVR model factory bridge to the current Runner/worker; reuse Controller, Guard and gates. Prepare Cap labels independently and render post-run comparisons from immutable outputs.

**Tech Stack:** Existing pinned Python3.12/NumPy2.3.5/PyArrow22.0; standard-library SVG/HTML; no new dependency.

**Spec:** `docs/gas-harness-cap-design-20261110.md`, reflecting the user's current concrete instruction to execute items1and2.

## Global Constraints

- Nine original Gas boundaries, same initial split/features; Mock only, no paid API.
- Candidate fit/selection entities disjoint; deployment evidence source strictly later than freeze; deploy(k) takes effect at k+1.
- Fixed alpha1 and configured budgets/thresholds; no outcome-driven reconfiguration.
- Cap10000 seconds defaultNone; keep exact same bearing entities/features; count clipping honestly.
- No C-MAPSS experiment, tree code/tests, dependency upgrade or default strategy change in this round.
- New immutable outputs; preserve old raw/evidence and record failures before another strategy.

## Task 1: OVR model and worker bridge

**Files:** `ite/multiclass.py`, `ite/model_factory.py`, `ite/config.py`, `ite/training.py`, `scripts/data_prep/models.py`, `tests/test_multiclass_harness.py`.

- [ ] Write and observe failing tests: fixed six classes, allow absent classes only for candidate fitting, weighted head agreement, numeric old/new checkpoint compatibility, invalid states, original binary factory equality, real spawn worker round trip and timeout.
- [ ] Add optional ovr_ridge only for explicit classification; reject paid OVR. Use factory in the worker and state restoration without changing original binary numerical branches.
- [ ] Run focused tests; save red/green and return interface/source audit.

## Task 2: RUL Cap

**Files:** `scripts/data_prep/bearing.py`, `tests/test_bearing_rul_cap.py`.

- [ ] Write and observe tests for None identity, cap arithmetic on a small independently known lifecycle, invalid cap, per-split clipped counts, immutable prior exports and CLI option.
- [ ] Add max_rul optional positive finite numeric seconds; apply min to derived target only. Record raw target maxima and clipped counts in metadata.
- [ ] Reprepare exact original three bearings with max_rul10000 and batch16, run original alpha1 static baseline; compare targets/features/predictions to old output. Preserve old bytes and report no-op if observed.

## Task 3: Runner and real Gas paired experiment

**Files:** `ite/runner.py`, `scripts/run_gas_harness.py`, `configs/gas-harness-mock.json`, `tests/test_gas_harness_experiment.py`.

- [ ] Write and observe tests for explicit multiclass labels, invalid/unknown targets, injected-provider requirement, isolated scorer access only after stream, future gate/source audit, predictor-version timing and exact weighted target calculation.
- [ ] Switch initial construction to the factory, preserve binary confusion reports, add multiclass counts. Run fixed configuration through existing Controller/Guard/worker on independent fresh static/drift providers.
- [ ] Run host complete suite and independent review before actual experiment. Freeze source/config and run the single approved pair, preserving config/hash/prediction/checkpoint/event artifacts.

## Task 4: Curves, diagnosis and offline verification

**Files:** `scripts/gas_harness_report.py`, `tests/test_gas_harness_report.py`, dated results/validation docs, Docker delivery recipe.

- [ ] Test literal curve/weighted aggregation and causal event rendering, then implement static/Mock per-batch loss curves, actual-version cumulative accuracy and retraining log. Do not run decisions during report creation.
- [ ] Assess 50% post-deployment and 1500-second Cap targets using exact values; archive any failure before considering another strategy. Perform four-layer analysis on existing predictions/checkpoints only.
- [ ] Build correctly sourced pinned image and run full tests plus same frozen real-data pair/Cap in offline4CPU8GiB. Check effective config/source IDs, prediction tolerance, budgets and gate audit.
- [ ] Export/reload image if delivering it, write machine receipts/usage/results, preserve source and raw hashes, commit reviewed local work; no upload or remote push.
