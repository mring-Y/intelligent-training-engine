# PyTRiO 动作 SFT 小试实施计划

> **For agentic workers:** 用户已于本对话 2026-11-14 回复“确认”。按 `superpowers:executing-plans` 在用户指定当前 checkout 逐项执行；确认覆盖本文一次 SFT、既定评估、SwanLab记录、测试及必要修复，不扩大矩阵或调参。

**Goal:** 用已有交叉拟合动作数据，对 `Qwen/Qwen3.5-4B` 做一次预算不超过人民币 10 元的动作 SFT，比较基模、固定最终 LoRA 与恒选 DO_NOTHING，并完整记录局限。

**Architecture:** 采用 Decision Model 的单 token 稀疏交叉熵监督。输入只取已审核记录的 messages，动作标签只进入监督 target；训练、推理共用模板和动作映射。独立脚本执行远程训练和采样，本地读取已有反事实产物复核单次决策的 CPU 结果，不改变生产 Harness 或重新生成 CPU 训练数据。

**Tech Stack:** PyTRiO 0.2.9、既有本地 4B tokenizer、固定 NumPy/Transformers 环境、SwanLab 0.10.3、持久预算账本和现有断网 Linux 验证环境。保持依赖版本与基础镜像摘要。

**Spec:** 本文是本轮自包含的诊断和待确认规格；来源见 [迭代 SOP](../../iteration-sop.md)、[NR-033](../../negative-results.md)、[交叉拟合结果](../../pytrio-crossfit-results-20261114.md) 和只读回执 `outputs/pytrio-decision-sft-20261114/preflight-v1/assessment.json`。

## 【诊断结论】

- 已有数据是实际 CPU 反事实结果形成的动作标签，不是可直接监督自由文本理由的对话。旧 27 条 Teacher 记录仍全部在 review，不并入本轮数据。
- 宿主/Linux 已完成各 210 状态、630 动作臂；去重后 train 137、eval 70。train 动作计数为 NO 114 / LARGE 15 / HEAD 8，eval 为 NO 56 / LARGE 10 / HEAD 4。
- A train/eval 只有 5/5 条，eval 全 NO；B 为 36/17 条、6/3 轴承；C 为 96/48 条、16/8 发动机。NR-033 的 `A_eval_single_action` 限制保留。本次可研究有限的动作模仿，不能据此证明 A 的干预泛化或三包普遍超越。
- 恒选 NO 已有 train 83.211679%、eval 80% 动作一致率。必须同时报告少数动作召回、macro-F1 与实际 CPU 后果，不能用高 accuracy 或 loss 下降替代收益。
- 特征/得分、残差、复杂度、时序诊断沿用已审计交叉拟合证据：固定公开协变量平移；MLP 4326/865/833 参数、HEAD 198/25/33 参数；step3/7 冻结、step5/9 门控、step6/10 首次预测。候选门控通过不保证后续 CPU 收益，C 高估保护仍需单列。
- 嵌套探针的 `qualified=false` / `offline_mock_not_teacher` 是旧 Teacher 自然语言审核契约；本轮只使用由 `choose_counterfactual_action()` 独立评判且经完整原始数组复核的顶层 `target_action`，不训练探针 reason 或把嵌套标记改为合格。
- 本机 PyTRiO 认证和模型目录只读查询成功，4B 训练/采样均可用；SwanLab 验证账号为 `mring-Y`。未创建 ServiceClient/session、训练或采样客户端，未发生本轮训练、推理或上传。

## 【准备采用的升级策略】

单因素：在相同基模、消息内容、模板、候选映射和评估记录上，比较有无这一次 LoRA SFT。固定一次训练，不做超参数搜索、重采样、类别加权、理由蒸馏、温度校准或 eval 选 checkpoint。

| 项目 | 固定值 |
| --- | --- |
| 模型 | `Qwen/Qwen3.5-4B`，执行时复核目录仍可用 |
| 训练数据 | 完整 137 条 train，每 epoch 每条恰好一次 |
| 对照数据 | 完整 70 条 eval，仅用于冻结后的基模/最终学生比较 |
| 数据哈希 | train `6492440a996f51dd80aa4014666eb3d047b815cf0d3048b69514833d3ad03317`；eval `0f9986e9c1cabb5ce53887701cd7690f712c7f8403da244196699f1c076cdb71` |
| 训练超参数 | rank 8、3 epochs、batch 16、Adam LR `0.0001`、seed 7；LoRA `train_attn=true`、`train_mlp=true`、`train_unembed=false` |
| batch 与 checkpoint | 尾部 9 条也训练；每 epoch 9 次更新，共 27 次；只评价固定 epoch3 最终权重，不据 eval 提前停止或挑权重 |
| 长度与模板 | 上限 512 token；既有模型 chat template，`enable_thinking=False`；assistant 骨架 `{"action":"decision"}` |
| 候选 | `A → DO_NOTHING`，`B → RETRAIN_LARGE`，`C → RETRAIN_HEAD_ONLY`；三符号和 marker 已核验为单 token |
| 监督 | marker 位于完整 ids 的 m；输入 `ids[:-1]`，仅 `target[m-1]` 为正确候选、`weight[m-1]=1`，其他 weight 为 0 |
| 推理 | 同一决策前缀分别对三候选调用 `sample(..., max_tokens=1, include_prompt_logprobs=True)`；读取候选自身位置的实际 prompt logprob，T=1 归一化；额外生成 token 不用于动作 |
| 候选完整性 | 不用全词表 top-k 缺项近似；长度、对齐、用量或候选 logprob 缺失时停止并保留失败回执 |
| 公开记录 | 同一 SwanLab 项目 `mring-Y/Intelligent_Training_Engine`，独立本轮 run |

system message 固定追加以下映射说明，其他 messages 原文不改：

```text
Decision code map: A=DO_NOTHING; B=RETRAIN_LARGE; C=RETRAIN_HEAD_ONLY. Return the code in the action field.
```

不得把 `target_action`、costs、evidence、source IDs、反事实未来结果或整个导出 JSON 行序列化为模型输入。`reason` 不监督；将来若桥接业务 JSON，须明确标注固定适配器文本，不冒充模型生成解释。本轮不接管生产路径。

## 费用核验与停止条件

用户所说“10以内”按本轮人民币总费用上限 ¥10 执行，覆盖基模评估、训练、学生评估及失败/未结算请求。不是每次请求或每个包各 ¥10。

2026-11-14 读取官方价格端点 `https://pytrio.cn/api/model-prices`，数据版本 `2026-08-21`：4B prefill 149、sample/train 454。官方网页展示函数 `pD` 明确除以 100，即 prefill **¥1.49/M**、sample/train **¥4.54/M**。原始 JSON、网页函数原文与网页资源哈希存于只读回执目录。先前把 454 当成元并估算一轮 ¥19.43 的口头判断已更正；不依据这个错误抽样。

含映射说明和最终 skeleton 的本地计数：train 每 epoch 47,040 个 model-input token，eval 全 prompt 23,883 token，最长 387，均不截断。每条每 epoch 只有一个监督位置，但计费按完整输入预留。

| 项目 | token 费率估算 |
| --- | ---: |
| 完整 train × 3 epochs | ¥0.64068480 |
| 基模 + 最终学生，eval 三候选全量 prefill | ¥0.21351402 |
| 最多 420 个额外生成 token | ¥0.00190680 |
| 上述合计 | ¥0.85610562 |

以上不是服务商扣款回执。单次上取整粒度仍须保守计入：每个采样调用对输入和输出分别向上预留到分；420 次最多按 ¥8.40 预留。按每条 512-token 上限、27 个 batch 分别上取整，训练预留为 ¥1.05，整轮 token 预留为 **¥9.45**，另留 ¥0.55。若实际计费规则或额外服务费用使完整计划连同预留超过 ¥10，则在任何付费操作前停止并报告，不静默抽样或缩减评估。先完成这个确定性整轮预算检查，再创建远程客户端。

持久账本须在请求前原子记录请求用途、完整 token 上界、价格与已占用额度；使用单实例 claim，防止重启重置 ¥10。只能扣除已确认为无需结算的预留；超时或缺少有效用量的请求保留预留并停止本轮，不自动重试或创建第二个训练 actor。不得把杀掉本地进程称作取消远端任务。SDK 自动重试须显式关闭/限为一次，使用有界等待。当前余额未通过结算接口核实，不把历史充值额当成本轮可用余额；余额不足按服务端错误停止，不索取密钥或自行充值。

## 评价与解释边界

1. 完整记录三类混淆矩阵、全局及各包 accuracy、三类 macro-F1、每类召回、NLL、10-bin ECE、Brier 和动作分布。全局 macro-F1 固定三类；A 缺类项写未覆盖，不把只含 NO 的 5 条当作三类检验。
2. 用同一模板、动作映射和 eval 顺序比较原始 4B、最终 LoRA；恒 NO 概率为 `(1,0,0)`，准确率为 56/70。训练 loss 按真实监督 token 数归一化，并记录实际 model-input token 数、每 batch 数量和 411 个总监督位置。
3. 动作模仿改善预登记为：最终学生的 eval 三类 macro-F1 严格高于基模及恒 NO；同时公开 accuracy 和每个包的差值。未达到即归档阴性，不能换指标宣称通过。
4. 对三策略所选动作，读取既有对应臂的原始 prediction/static/target/version 数组、事件和来源审计，复算单决策窗口 CPU 指标：A Macro-F1/Accuracy，B 分钟 RMSE/MAE，C 周期 RMSE/高估率/平均正向高估，以及已实际发生的候选训练成本。保留筛选拒绝及门控拒绝造成的 static fallback，不能把“建议干预”等同于已部署。
5. 按包、stable/abrupt/gradual 和来源组给出同 ID 配对原值、差值；不跨单位相加发明官方综合分。重复变体不增加独立实体数；同输入合并的重复来源只用于定位原始臂，不增加动作样本量。
6. CPU 保护条件继续沿用 A accuracy、B MAE、C 两项高估不恶化。任何失败先写 NR；动作模仿通过和 CPU 保护失败必须分别报告。
7. 这只是固定决策状态的一步反事实评估。没有重新运行多步自主学习策略，不据此宣称闭环收益、隐藏成绩或三包全面超过 baseline。全部 70 条是已看过的公开开发证据；A 只能检查 NO 行为，统计与来源局限不变。生产默认及交付镜像不自动晋级。

## Task 1：数据编码、精确候选评分与预算契约

**Files:** 新增 `ite/decision_sft.py`、`tests/test_decision_sft.py`。

**Interfaces:** `encode_decision(record, tokenizer) -> dict` 返回 ids、marker index、target_tokens、weights；`candidate_inputs(encoded) -> list` 保持相同决策前缀；`score_candidates(responses, encoded) -> dict` 返回三个完整 logprob、概率和动作；预算辅助函数返回 Decimal 预留、拒绝超限或不确定结算。

- [x] 先写失败测试：完整 JSON 行中的 future/target/reason 不进入 prompt；相同 messages、不同 target 的 ids 完全相同，只有监督 target 不同。
- [x] 先写失败测试：正文或 key 中出现 decision 不得误定位；候选非单 token、marker 多个、超长输入、NaN/None logprob、usage/长度错位均拒绝。
- [x] 先写失败测试：恰好一个右移监督位；零监督位置不得除零；三候选上下文前缀逐 token 相同，不用 top-k 缺项填补。
- [x] 先写失败测试：价格按分转元、完整输入计费、逐请求上取整、恰好到 ¥10、超限、未知费用保留、claim 重启和重复请求不可绕过限额。
- [x] 运行 `.\.venv\Scripts\python.exe -m unittest tests.test_decision_sft -v`，确认失败来自未实现的本轮契约，再实现并转绿，保存原始红/绿回执。

## Task 2：固定训练与基模/学生评估驱动

**Files:** 新增 `scripts/train_decision_sft.py`、`tests/test_decision_sft_runner.py`；新增本轮显式配置，原生产配置不改。

**Interfaces:** 读取两个固定 JSONL 和数据哈希；使用 Task 1 返回的输入构造 PyTRiO Datum；输出不可覆写的 freeze、request-ledger、逐请求用量/延迟、train-metrics、base/student-predictions、checkpoint paths 与 status。

- [x] 用 fake SDK 先测试：未确认或预算/数据哈希不符时零远程客户端；27 次更新包含每 epoch 的尾部 9 条；完成每次 forward/backward 后再等 optimizer；只保存/评价固定最终权重。
- [x] 用 fake SDK 先测试：返回 future 的边界、服务端失败、超时、缺少 usage、未知结算均停止且不重试；不更改原始 train/eval、不加载旧 Teacher review、不把 eval 送入训练。
- [x] 用 fake SDK 先测试：三个候选分别读取 prompt 自身概率；基模/学生共用输入；420 次采样生成 token 不参与决策；缺项时不产出完整通过状态。
- [x] 运行 focused 测试确认红，再实现最小同步驱动；固定 SDK 0.2.9，不添加不存在的 client close 方法。
- [x] 保存推理权重和可续训 state 的真实服务端路径；任何未完成或无权重结果如实记录，不能造 checkpoint。

## Task 3：已有 CPU 产物复核与 SwanLab 记录

**Files:** 新增 `scripts/report_decision_sft.py`、`tests/test_decision_sft_report.py`。复用已有 tracking/archive 能力；SwanLab 在已有 `.venv` 中执行，远程训练使用 `.venv-sft`，不为接日志升级依赖。

- [x] 先以同一输入不同动作、门控拒绝、A 缺类、C 高估退化、重复来源、非有限用量的固定 fixture 写有意义的失败测试。
- [x] 从所选既有 arm 的原始数组复算 CPU 分数、配对差值和训练耗时；不调用 fit、不生成新标签、不用 oracle action 替换学生预测。
- [x] SwanLab 记录配置/源数据哈希、单监督位置 loss、411 个监督位置、input tokens、27 steps、基模/最终学生/恒 NO 指标、CPU 后果、预算及失败状态。只发布本轮已授权的实验信息，不记录密钥。
- [x] 保留本地精确 JSONL/JSON，输出本轮独立 SwanLab 链接；云端异常保留上传状态，不将其伪装成成功。

## Task 4：验证、唯一训练与归档

- [x] 在当前 checkout 依次完成 focused 和必需宿主全套测试，保存日志；所有新增代码有上述测试。
- [x] 从固定基础镜像 `sha256:76476d088433a4bb20a00d6eed16b136062ffe670a8d7541b727ce6ef8eb5228` 验证本轮纯本地编码、预算、fake-SDK 驱动及 CPU 复算，4 CPU / 4 GiB / `network=none`，记录退出状态、OOM 与镜像/源码哈希。
- [x] 断网验证不得连接 PyTRiO；真实 GPU LoRA 在联网宿主通过远端服务执行，两个验证范围在报告中区分。
- [x] 冻结干净源码与配置后，重新核对报价并完成整轮 ¥10 最坏预留检查，运行唯一一次已确认 SFT；失败按本轮范围停止，保留原始输出，不擅自改变 epochs、batch、数据、loss 或预算。
- [x] 比较固定基模/最终学生/恒 NO，复核 CPU 后果。任一预登记条件失败先追加 `docs/negative-results.md` 的四字段记录；不自动启动下一轮。
- [x] 完成本轮报告、机器索引、SwanLab 状态复核及本地 Git 留痕；不推送远程或晋级默认。

## 当前状态

- [x] 阅读 SOP、NR-033 和最新交叉拟合/官方微调诊断。
- [x] 只读核验 PyTRiO 0.2.9、4B 认证/目录、SwanLab 账号、候选单 token 和真实全输入 token 数。
- [x] 更正价格单位，保存官方价格/展示函数与只读计数回执。
- [x] 用户确认以上本轮单因素方案。
- [x] 确认后先写失败测试，再实施 Task 1–4。

## 实施冻结前记录

2026-11-14：单 token 稀疏编码、精确三候选评分、持久预算账本、同步训练/评估与反事实CPU复核已实现。每个模块先保留导入缺失/契约失败的红灯回执，再转绿。宿主全套634/634通过（380.094秒）；最后只补充已批准的SwanLab记录覆盖，包含该补充的最终focused30/30通过。断网Linux最终30/30通过（0.394秒），4CPU/4GiB、network=none、退出0、无OOM；原固定基础镜像未改。容器内另只读复算72个CPU状态及648份证据哈希，静态fallback与宿主一致，未调用fit。新完整测试总数为635，旧全套回执634与最终focused30的覆盖边界分别保留，不冒充同一版本全套635回执。

真实4B tokenizer和PyTRiO Datum预检符合原方案：137/70行、最长387 token、每轮47040个model-input token、总411个监督位置，整轮最坏预留9.45元。SDK训练响应没有独立usage字段，训练账本明确记为本地精确提交token数与完整预留，不伪装成服务端用量或扣款回执；采样必须有有效的服务端input/output token回执。原先无UTF-8参数的基线4项GBK读取错误、误重复启动后停止的测试日志也保留。

SwanLab0.10.3的local模式缺少可选swanboard回调，未安装新依赖；offline模式已实测落盘并保存5份精确fixture附件（run1mxt6osr）。该fixture明确标注LOCAL-INFRASTRUCTURE-FIXTURE-NOT-MODEL，不上传或作为真实基模/学生结果。本轮真实执行完成后单独online记录。固定基模评估先进行，再训练一次并评价固定epoch3权重；所有超参数和范围不变。

到此仍无本轮付费API、训练actor或LoRA权重。原始回执位于`outputs/pytrio-decision-sft-20261114/records/`；下一步冻结本地提交后执行唯一paid-v1，保持单用claim和10元总上限。

## 最终执行状态 — 2026-11-14

Task1–4已完成，实际远程运行来源是干净冻结提交`3cc0a92f19a937275ebc76086e60ebd9bfa06373`。训练前的历史记录保留，不追写原始freeze。唯一paid-v1完成27次训练更新、411监督位置、141120个提交输入token；基模/学生各70条×三候选，共420次采样，服务端输入143298、输出420。原始响应全部保留，没有重试或未知请求。

预登记动作模仿条件未通过：学生70/70都为DO_NOTHING，accuracy80%、三类macro-F1为0.2962962963，与恒NO相同；两个干预类召回0。原始4B为accuracy30%、macro-F1为0.2922931442。学生NLL/Brier改善不能替代干预收益。存档CPU复算的72状态全部保持static，stable/abrupt/gradual各包的分数差值均0，保护通过但没有CPU收益。多步自主/隐藏集/官方总分未测，不晋级默认。

最终采样权重`trio://run_mphtvnjpqb3d/sampler_weights/action-sft-final-epoch3`；完整state`trio://run_mphtvnjpqb3d/weights/action-sft-final-state-epoch3`。SwanLab[6w6q826b](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/6w6q826b)由CLI确认FINISHED、PUBLIC，训练/三策略动作/CPU指标键齐全，并有七份精确本地文件的save记录。未独立下载服务器附件核验字节。

完整token费率估算0.85610562元，按各请求分别向上取整的保守账本占用9.18元，低于10元；均不是精确扣费回执。单用claim和447条持久预算账本保持占用，不重置、不创建第二个actor、不追加训练。SDK创建训练client时自动缓存了模型tokenizer文件，未升级依赖或修改仓库固定tokenizer；实际请求始终使用预检后的显式token IDs。

结论已先追加NR-034。最终原始产物在`outputs/pytrio-decision-sft-20261114/paid-v1/`；完成审计为`records/25-completed-output-audit.json`，逐token对齐、loss复算、源哈希、648份CPU证据哈希及账本一致性全部通过。[结果报告](../../pytrio-decision-sft-results-20261114.md)、[机器索引](../../validation/2026-11-14-pytrio-decision-sft.json)保留验证覆盖、费用口径和来源局限。本地Git归档文档，不推送远程；保持用户指定当前checkout。

独立审阅后补充的报告护栏修复要求总体及stable/abrupt/gradual逐场景逐包通过CPU保护，回归测试覆盖“单场景退化不能被总体改善抵消”。该修复只影响后处理判定，不重写paid-v1报告或重新训练；宿主focused31/31、断网Linuxfocused31/31通过。原paid-v1报告哈希和全NO阴性结论保持不变。
