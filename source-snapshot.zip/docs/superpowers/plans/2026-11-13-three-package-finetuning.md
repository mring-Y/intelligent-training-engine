# 三包任务模型微调实施计划

> **For agentic workers:** This is the single route and execution record for the A/B/C task-model work. Do not start a code change, configuration change, training run, or new strategy experiment until the user has confirmed that round's displayed diagnosis and single-factor strategy.

**Goal:** Develop separate task-model updates for official packages A, B, and C that improve each package's primary metric over its paired static checkpoint on held-out evaluation while preserving each task's secondary and safety requirements.

**Architecture:** Keep the completed Harness as the execution and audit layer. Treat each official predictor as its own workstream with its own metric, data grouping, candidate update, and promotion evidence. Preserve the supplied static checkpoint as the fallback and compare every candidate on the same source IDs and time protocol.

**Tech Stack:** Supplied NumPy MLP packages; existing `OfficialModelAdapter`, isolated NumPy 1.26.4 worker, bounded training worker, JSONL event logs, and offline Linux containers. Do not add dependencies unless a later confirmed strategy requires them.

**Spec:** `c945f17fdaf0636a7a36aca3d4264fd8.pdf`; metric and package details in `docs/official-sft-assessment-20261112.md`; iteration constraints in `AGENTS.md` and `docs/iteration-sop.md`.

## Global Constraints

- The official gate is autonomous completion, complete experiment records, and comprehensive performance no lower than the static model. The project target in this plan is stricter: each of A, B, and C must independently beat its own static reference.
- The official objective score considers performance gain against compute, annotation quota, and LLM Token consumption. Keep those costs as separate measured quantities; do not invent an aggregate formula.
- Use task-specific metrics: A Macro-F1 with Accuracy as a guard; B RMSE and MAE in minutes; C RMSE in cycles with overestimate rate and mean positive overestimate as safety guards.
- For stable data, candidates must not regress. For abrupt and gradual drift, require a primary-metric improvement without violating secondary or safety guards. Report per-task results; one task cannot offset another task's regression.
- Keep the official ZIPs and checkpoints immutable. Use the same checkpoint, source IDs, transforms, label timing, and resource allowance for each paired comparison.
- Split by meaningful source groups: A by ordered time/source batch, B by bearing, and C by `(source_subset, unit)`. Keep overlapping windows and derived variants in the same group.
- Training, screening, the independent future gate, and final scoring must use disjoint label evidence. A deployment at step `k` first affects prediction `k+1`.
- Public validation and the previously used 0.75-standard-deviation drift streams are development evidence, not blind final acceptance. Do not claim hidden-test success without the official evaluation.
- Preserve the existing resource limits, dependency pins, model fallback, and independent future-label gate. Keep Harness work out of scope unless the diagnosis later proves a task-metric mismatch requires a separately confirmed change.
- Before each code edit, parameter change, or experiment, present **【诊断结论】** and **【准备采用的升级策略】** with the exact factor, tests, comparison, thresholds, and costs; wait for explicit confirmation. After a failed threshold, append the negative record before another strategy.
- Do not use the 27 real Teacher decisions as training labels: the recorded SFT `train` and `eval` sets are empty and all 27 decisions remain under review.

## Frozen References

| Package | Archive SHA-256 | Task | Primary acceptance metric | Static package reference |
|---|---|---|---|---|
| A | `7a992b92d92c807869c3eccf25b3bf82dcdeba9174e161d6e8b61d82c3ec8851` | Six-class classification | Macro-F1 higher | Macro-F1 `0.7140297221`; Accuracy `0.8786173633` |
| B | `68db6a72c29bac11a4f86e97d9c1f524d35695464fd5f3f6d131f1431bc69d68` | Bearing RUL regression | RMSE and MAE lower, minutes | RMSE `681.1598326`; MAE `563.1058415` |
| C | `6cb8784e2cab7ee93453e756abf54c168721c667ca0c2c1327f5faae96e4211f` | Engine RUL regression | RMSE lower, cycles | RMSE `52.8685726`; MAE `38.8998298` |

These are supplied-checkpoint scores on the public validation packages, not hidden evaluation results. The package fingerprints match `docs/validation/2026-11-12-official-sft.json`. The archives contain the supplied checkpoint plus public train and validation JSONL files.

## Current Diagnosis

The official PDF permits a Harness route or a traditional fine-tuning route. It does not require an independent strict win on each task; the per-package requirement above is the user's stronger project target. The PDF also separates automatic objective scoring from expert subjective scoring.

| Package | Evidence already measured | What it says | Remaining limit |
|---|---|---|---|
| A | Official train has 445 rows with class counts from 30 to 98; public validation has 1,244 rows, including only 5 Toluene examples. In a fixed-action/mock replay, stable-train Macro-F1 changed `0.730866 -> 0.702689`, abrupt-train `0.643369 -> 0.511085`, and gradual-train `0.646388 -> 0.514061`; eval candidates did not deploy. The real Teacher run also made no A update. The largest class-index F1 changes were `-0.169231` in stable train and `-0.769231` in abrupt/gradual train, while accuracy changed little. | The observed issue is not proven to be simple training-set class imbalance. A read-only counterfactual on all six saved A future gates found the candidate-vs-static direction for Macro-F1 matched the existing accuracy gate direction in all six cases; changing the gate alone is not supported by this evidence. | Five validation examples for Toluene make class-specific conclusions unstable. Accepted candidates still lost Macro-F1 over the whole development stream, so the source of the sustained loss remains unresolved.
| B | Official train has 7,032 rows across 9 bearings. Public validation has 1,679 rows, but 1,515 are from Bearing3_4, 122 from Bearing1_4, and 42 from Bearing2_4. In fixed-action/mock replay, stable-train RMSE worsened `704.09 -> 881.17`, stable-eval `241.98 -> 254.72`, abrupt-train improved only `774.66 -> 772.32`, and gradual-eval worsened `274.19 -> 345.17`. The real Teacher run made no B update. | A pooled score can hide entity-specific regression. Current generic updates are not robust across bearings or scenarios. | Only three validation bearings are available; there is no untouched bearing-level blind set in the local package.
| C | Full and head-only updates reduced drift RMSE but increased high-estimation risk. A 2x positive-residual loss did not pass safety checks; a P90 downward calibration reduced high estimates but all four drift partitions remained above their paired static safety values. | The measured tradeoff is RMSE improvement versus new RUL overestimation. More loss weight or a larger calibration quantile is not supported by evidence. | Repeated public drift streams have been used for development; they cannot serve as independent final acceptance.

The current predictors are separate 128-32-6, 34-24-1, and 24-32-1 MLPs with 4,326, 865, and 833 parameters. Do not force one loss or update rule across all three.

## Execution Checklist

### Task 1: Freeze the scoring contract and package baselines

**Status:** Complete, read-only.

**Files and evidence:** `c945f17fdaf0636a7a36aca3d4264fd8.pdf`, the three archives under `third_party/official_baselines/`, `docs/official-sft-assessment-20261112.md`, and `docs/validation/2026-11-12-official-sft.json`.

- [x] Verify archive SHA-256 values against the machine validation record.
- [x] Confirm train, validation, and checkpoint entries exist in each archive.
- [x] Record the static reference metrics and the stronger per-package project acceptance above.

### Task 2: Audit existing paired outcomes and evidence gaps

**Status:** Complete, read-only. No new model fit or policy simulation was run.

**Evidence:** `docs/official-model-results-20261111.md`, `docs/official-sft-pilot-20261112.md`, `outputs/official-sft-20261112/records/offline-results-audit.json`, `outputs/official-sft-20261112/records/teacher-results-audit.json`, NR-027 through NR-029 in `docs/negative-results.md`, and their result reports.

- [x] Separate actual Teacher decisions from fixed-action/mock candidate runs.
- [x] Compare A Macro-F1 and Accuracy per split, B RMSE/MAE and bias per bearing-grouped split, and C RMSE plus overestimation metrics.
- [x] Record that no current task candidate has passed a fresh independent hidden evaluation.
- [x] Preserve the current static checkpoints as the default fallback.

### Task 3: Select and run the first task-specific fine-tuning round

**Status:** Host implementation and 18-flow A comparison complete; offline Linux reproduction is also complete. Replay passed 4/6 partition gates, so no promotion; see NR-030 and its environment/checkpoint addendum.

**Decision rule:** Choose A, B, or C only after the task's feature/score, residual, complexity, and source/deployment timing evidence identifies a testable factor. The first approved round changes one factor only, writes a failing test first, and adds no Harness change unless separately approved.

**Current direction:** A's saved candidate gate decisions do not show an observed Macro-F1/accuracy direction conflict, but its accepted candidates lost Macro-F1 over the remainder of the stream. The first proposed A factor is a bounded replay reserve: deterministically take 8 labeled training rows per class (48 total) from the official A train split and replace the 48 oldest rows in each candidate's current training window. Keep the total candidate row count, candidate action, optimizer, epochs, 48-row screen, independent future gate, and resource limits unchanged. This tests whether retaining class coverage in each continuation preserves long-horizon Macro-F1; it is a hypothesis, not a confirmed fix. B needs per-bearing residual analysis before choosing an update rule. C needs source-level residual analysis before considering replay or a different update constraint.

**Proposed A files if confirmed:** `ite/official_sft_data.py` to expose deterministic, ID-tagged training replay rows; `ite/official_sft_replay.py` to replace the 48 oldest current rows while preserving screen/future disjointness; `tests/test_official_sft_data.py` and `tests/test_official_sft_replay.py` for class coverage, determinism, source disjointness, unchanged row count, and no future-label access. No production Harness or gate change is in this proposal.

**Result:** Added the deterministic 8-per-class reserve and an explicit opt-in A replay policy; default replay remains `none`. The comparison runner records static, full-no-replay, and full-with-replay arms over stable/abrupt/gradual × train/eval. Replay passed 4/6 partition gates: stable train Macro-F1/Accuracy `0.730866/0.834628 → 0.731388/0.835738`, abrupt train `0.643369/0.690344 → 0.647100/0.710322`, gradual train `0.646388/0.697003 → 0.650217/0.716981`; drift/eval remained static because each 18-row screen rejected its candidate. No promotion. See NR-030 and immutable raw outputs in `outputs/official-a-replay-20261113-r2/`.

- [x] Write failing data/replay/source-pairing tests, then implement the ID-tagged reserve and candidate-source audit.
- [x] Run the paired 18-flow host comparison with unchanged action, optimizer, row count, screening rule, future gate, and budgets.
- [x] Verify all flow evidence hashes and archive the failed all-partition gate result in NR-030.
- [x] Run fixed, disconnected Linux validation at 4 CPU/4 GiB; all 10,620 predictions, IDs, targets and versions matched host results. Checkpoint numeric differences were measured separately (maximum absolute difference `1.11e-16`), not described as byte-identical.

The existing screening rule caps the screen at 48 rows; at A eval step 3 it yields 18 rows, leaving 54 candidate training rows. Changing the decision time to obtain 48 eval-screen rows would be a new factor and needs a separately confirmed diagnosis.

### Task 4: Repeat separately for the other packages

**Status:** B's approved 18-flow host and offline Linux comparisons are complete and archived in NR-031. Full passed 0/6 partition gates, head-only passed 2/6; neither promotes. A's pending Linux reproduction is also complete. The subsequently confirmed C source-balanced replay round below is complete and archived in NR-032; both C arms passed 2/6, neither promotes.

**B read-only diagnosis:** The public validation package has 1,679 rows: Bearing3_4 contributes 1,515, Bearing1_4 contributes 122, and Bearing2_4 contributes 42. In the existing stable/train run, the candidate used 342 training rows (42 Bearing2_4 + 300 Bearing3_4), screened 48 Bearing3_4 rows, and passed a 130-row Bearing3_4 future gate. After deployment, Bearing3_4 RMSE rose `710.813 → 890.928` minutes while residual bias moved `-427.393 → -72.063` and residual standard deviation rose `567.970 → 888.008`; the 42 Bearing2_4 rows had no post-deployment predictions. This is measured bias/dispersion movement, not proof of overfitting.

For the held-out Bearing1_4 partition, stable/eval fit on 24 rows, screened 8, and passed a 10-row future gate. Full-flow RMSE changed `241.981 → 254.725` and MAE `175.587 → 166.770` minutes; residual bias moved `166.541 → 146.220` while residual standard deviation rose `175.553 → 208.577`. In gradual/eval, the same 24/8/10-row pattern passed the gate but RMSE worsened `274.192 → 345.165` and MAE `193.802 → 236.583`; abrupt/eval was rejected and remained static. The train partition is dominated by Bearing3_4, so pooled train gains in abrupt/gradual do not establish transfer to Bearing1_4. The existing candidates updated all 865 parameters in the 34→24→1 MLP; there is no GP population. Source: NR-025 frozen runs under `outputs/official-sft-20261112/container-output/offline-v1/runs/`.

**Confirmed B round:** Compare static, full fine-tuning, and output-head-only fine-tuning while changing only the trainable parameter set (865 versus 25 parameters). Use fixed step 3/7 decisions for train and step 3 for eval; full uses `RETRAIN_LARGE`, head-only uses `RETRAIN_HEAD_ONLY`, both mapped to the same maximum 768-row window, optimizer, five epochs, screen rule, independent future gate, and budgets. Keep the same source splits and checkpoint. At B eval step 3 the existing rule yields 24 training rows and 8 screening rows; preserve and report those sizes. Report RMSE/MAE and residual bias/dispersion per bearing as well as pooled. The hypothesis that limiting parameter updates reduces residual spread was not universally supported: stable/train Bearing3_4 RMSE static/full/head was `710.813/890.928/1102.017` minutes, while head-only improved stable/eval and abrupt/train. The full six-partition host results and costs are in NR-031 and `outputs/official-b-head-20261113/host-v1/`.

- [x] Add failing tests, then implement the isolated B comparison runner and per-bearing/checkpoint audits.
- [x] Run the paired 18-flow host matrix, verify all 54 evidence-file hashes and 18 candidate checkpoint audits, and archive failed promotion in NR-031.
- [x] Complete host tests: 563/563 passed in 330.018 seconds.
- [x] Locate the existing per-user Docker CLI; verify the healthy daemon and frozen base ID without reinstalling or upgrading.
- [x] Complete 4 CPU/4 GiB, `--network none` Linux tests (562 passed/1 host-only skip) and B/A comparison reproductions. B's 15,111 predictions and 18 candidate checkpoint payloads matched exactly; A's 10,620 predictions/scores matched exactly, with checkpoint numeric differences disclosed separately.

- [x] Apply the same metric and source-isolation discipline to C; the confirmed historical replay factor retained ordinary head-only squared loss and independent gates.
- [x] Complete the approved host tests and fixed, disconnected Linux validation for the A and B changes (563 host tests passed).
- [x] Keep A/B checkpoint, metric, cost, failure and promotion evidence separately auditable; B report: `docs/official-b-head-results-20261113.md`, machine index: `docs/validation/2026-11-13-official-b-head.json`.
- [x] Complete the next C source/residual/complexity/timing diagnosis using existing evidence; prior C head/asymmetric/calibration failures remain in NR-027 through NR-029.
- [x] Obtain confirmation for the specific C factor below before new code, reserve selection, training or strategy experiments (user confirmed on 2026-11-14).

### C round: source coverage diagnosis and confirmed replay

**Status:** User explicitly confirmed this single factor on 2026-11-14. Implementation and host/Linux three-arm matrices are complete; ordinary head-only and replay both passed only the two stable partitions (2/6) and neither promotes. The four drift partitions reduced RMSE versus static but increased both overestimation metrics. Failure is archived in NR-032. Source/test implementation is committed as `f858420`; raw image/run provenance retains its actual earlier commit plus approved dirty edits.

**【诊断结论】** NR-027 through NR-029 show RMSE improvement together with increased RUL overestimation. The new source audit maps saved candidate IDs and actual prediction versions to the unchanged package metadata:

| Evidence phase | C train partition | C eval partition |
| --- | --- | --- |
| Step-7 fit window, 720 rows | FD003: 720 rows, 4 engines | FD002: 238 + FD003: 482 rows, 4 engines |
| Screening, 48 rows | FD003 only, 2 engines | FD003 only, 2 engines |
| Independent future gate, source 8 | FD004: 1,525 rows, 7 engines | FD004: 396 rows, 4 engines |
| Deployed predictions, steps 10–11 | FD004: 3,050 rows, 14 engines | FD004: 790 rows, 4 engines |

The 24 official features and fixed 0.75-standard-deviation simulated input shift are unchanged. The local fit window and screen omit the FD004 source subsequently evaluated by the future gate and deployed model. The supplied historical train split has 113,089 rows from 496 engines, including 43,396 FD004 rows from 174 engines; none of its IDs or `(subset, unit)` groups overlap public validation. This establishes an available historical source, not proof that replay will improve transfer.

On the same deployed FD004 IDs in abrupt/train, ordinary head-only changes RMSE `141.784006 → 123.864492` cycles, residual bias `-116.936431 → -89.965304`, and residual SD `80.178399 → 85.139042`, while overestimates increase `0 → 313`. Abrupt/eval changes RMSE `175.072220 → 148.003908` and overestimates `0 → 81`. The corresponding calibrated counts remain 310/19; gradual calibrated counts are 184/9. Thus the aggregate safety failures also appear in the deployed source. The existing asymmetric-loss audit found 717 negative, 3 zero and no positive initial fit residuals in each drift window. These observations do not prove overfitting, forgetting, or a causal effect of source coverage.

Complexity stays at 833 parameters with 33 trainable head parameters. All deployed predictions first occur at step 10 after the step-7 freeze and source-8 future MSE gate at step 9. The source gate is independent, but it does not guarantee the final overestimation constraints. Evidence, full-precision source metrics and 28 input hashes are in `docs/validation/2026-11-13-official-c-source-diagnosis.json`; raw outputs remain under `outputs/official-safety-calibration-20261113/host-v2/`.

**【准备采用的升级策略】** Test one factor: a bounded, source-balanced historical replay reserve in ordinary C head-only training. Select 12 distinct engines per FD001/FD002/FD003/FD004 subset from the supplied train split by deterministic SHA-256 ranking, then one row per selected engine by a separate deterministic SHA-256 ranking. Do not rank by target, residual, future metric, or validation examples. The 48 original, unshifted historical rows replace the oldest 48 of the 720 online fit rows; training size remains 720. This tests whether retaining historical source coverage helps reduce transfer-related safety regression. It does not assume a positive result.

- Proposed comparison: static / ordinary head-only / head-only with replay; stable/abrupt/gradual × train/eval, 18 flows per platform. Both training arms use the same initial checkpoint, step-7 decision, squared loss, original Adam/LR 0.002, batch 256 and five epochs. Calibration is not part of either training arm.
- Preserve the existing 48-row screen, independent future gate and deployment timing; the reserve must be disjoint from every validation entity/ID and all screen/gate evidence. Keep the candidate's 5-second and stream's 20-second limits. Reusing supplied training labels adds no annotation requests or LLM Tokens.
- Proposed modules: C reserve selection in `ite/official_sft_data.py`, an explicit opt-in C replay branch in `ite/official_sft_replay.py`, and a dedicated C comparison runner. Do not change the production Harness, gate, optimizer, model architecture or default policy.
- Before implementation, write failing tests for deterministic 12-per-subset coverage, 48 distinct engines, immutable label/feature provenance, entity and ID disjointness, unchanged 720-row fit size, replacement of only the oldest 48 rows, and refusal of future-label or cross-profile use. Add paired-metric and checkpoint audits to the comparison tests.
- Validation after confirmation: focused tests, the required host suite, then the same 18-flow comparison in the host and pinned disconnected Linux image at 4 CPU/4 GiB. Keep existing dependency versions and frozen base ID `sha256:76476d088433a4bb20a00d6eed16b136062ffe670a8d7541b727ce6ef8eb5228`; use new output directories and record source/runner hashes, resource receipts, prediction versions and per-subset/engine residuals.
- Acceptance: for each stable partition, RMSE and both safety metrics must not worsen; for each abrupt/gradual partition, RMSE must strictly decrease and neither overestimate rate nor mean positive overestimate may increase versus same-ID static. No partition can compensate for another. A failed gate is archived before another strategy; public development results remain distinct from untouched or official hidden acceptance.

**Completed C result:** Replay RMSE for abrupt train/eval was `125.247918/118.618065` versus static `128.372756/124.423732`; gradual was `121.074760/114.609164` versus static `124.304549/120.535091`. Replay high-estimation rates were `18.224044%/16.382396%/18.535519%/16.466625%`, all above their paired static values. Compared with ordinary head-only, replay removed only one overestimate in each drift partition and slightly increased RMSE. Stable candidates were rejected before deployment. Each training arm performed six continuations and four deployments; no automatic increase of reserve size or change of sampling, loss, gate or defaults is authorized by these results.

- [x] Observe failing tests before implementing deterministic source/engine selection, original row provenance, 720-row replacement and disjoint future gates.
- [x] Complete focused tests (50 passed) and full host tests (578 passed, 342.174 seconds).
- [x] Run and audit 18 host flows; retain static and no-replay controls identical to the saved prior comparison.
- [x] Build from the same frozen base and validate 4 CPU/4 GiB disconnected Linux: 577 tests passed, one host-only skip; 18 flows, both containers exit 0, no OOM.
- [x] Verify 207,441 active predictions and all other arrays across platforms; 12 candidate checkpoints/180 array payloads exact; 108 evidence hashes match.
- [x] Archive NR-032 before any further strategy; preserve source, package/reserve hashes, costs and raw outputs. Report: `docs/official-c-replay-results-20261114.md`; machine index: `docs/validation/2026-11-14-official-c-replay.json`.

### Task 5: Cross-package acceptance

**Status:** Pending task-level development results and access to an untouched evaluation source.

- [ ] Require a per-package win against the paired static checkpoint; do not average away a losing task.
- [ ] Keep stable, abrupt, and gradual results separate and report paired source/entity results.
- [ ] Record compute/training time, released labels, and LLM Tokens as separate cost measures.
- [ ] Use the official hidden evaluation only through the prescribed closed offline platform; do not treat local public-validation replay as hidden acceptance.
- [ ] Promote no model by default until all three task gates and the official evaluation requirements pass.

## Current Checkpoint

Tasks 1 and 2 are complete. A replay (NR-030), B full/head-only (NR-031) and C source-balanced replay (NR-032) now all have host and disconnected Linux evidence, but no package candidate meets every partition's performance gate. Static remains the default; the user's three-package superiority goal is not achieved. Outputs remain under `outputs/official-a-replay-20261113-{r2,linux-v1}/`, `outputs/official-b-head-20261113/{host-v1,linux-v1}/`, and `outputs/official-c-replay-20261114/{host-v1,linux-v1}/`. Docker works via its existing user-level CLI with elevated execution. A checkpoint arrays differ by at most `1.11e-16`; all A predictions/scores match, and B/C candidate payloads match exactly. C implementation is committed as `f858420`, with raw image/run provenance separately preserved. No new factor is proposed or run after this failure, and no untouched/hidden acceptance has been run. Continue with read-only diagnosis; another code/configuration/strategy experiment requires its own displayed diagnosis, single-factor proposal and explicit round confirmation.
