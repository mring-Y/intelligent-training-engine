# PyTRiO Cross-Fit Counterfactual Dataset Plan

This round is authorized by the user's 2026-11-14 confirmation to continue the cross-fit counterfactual data-generation strategy. It builds and audits local action labels only. It does not train a PyTRiO model, call the PyTRiO service, upload to SwanLab, or change production defaults.

## Goal

Produce an auditable A/B/C dataset whose action labels come from matched counterfactual replays on public official training sources. Starting CPU checkpoints must exclude the source time block, bearing, or engine being replayed. Prompts contain only decision-time-visible context; outcome evidence and the single action label remain separate.

## Fixed Design

- Read only the immutable `public/train.jsonl` members from the three pinned official ZIP packages. Verify each package digest, train-file digest, row count, target contract, and source metadata against `training.json`.
- A: one chronological source. Build two forward blocks with at least 64 rows purged between the fitting prefix and each replay block. The earlier replay block is `train`; the later block is `eval` and its initial CPU model may use only the earlier chronological prefix.
- B: hash-rank bearings into three deterministic folds. Two folds supply action-training examples; the third is held out for action evaluation. Each fold's CPU initial model excludes every row from its held-out bearings. Replay each bearing as its own time stream.
- C: assign engines round-robin by SHA-256 rank within each FD subset to six folds. Folds 0-3 supply action-training examples; folds 4-5 are action evaluation. Fit each CPU initial model without all engines in its fold. Select one engine per subset and fold for the bounded replay audit.
- Globally exclude every action-evaluation fold from all CPU initialization fits, including action-training folds. A train-fold initialization uses only the earlier prefix; B train-fold initialization excludes its own held-out fold and fold 2; C train-fold initialization excludes its own held-out fold and folds 4-5. B/C action-evaluation initial models use only the action-training folds. This prevents evaluation labels from entering action-training outcomes through the initial predictor.
- Cover `stable`, `abrupt`, and `gradual` public-development transforms and decision steps 3 and 7. Each decision compares `DO_NOTHING`, `RETRAIN_LARGE`, and `RETRAIN_HEAD_ONLY` from identical fold checkpoint, state, source stream, screen, gate, and budget. Exclude other actions that cannot be distinguished or completed in the bounded source windows.
- Reuse the pinned NumPy 1.26.4 baseline implementation and existing official adapter, screening, future gate, and per-candidate/flow resource limits. Each counterfactual arm gets a fresh replay from the same state.
- An intervention is label-eligible only if the existing future gate accepts and post-deployment outcomes improve the package primary metric while satisfying guards: A Macro-F1 improves and accuracy does not fall; B RMSE improves and MAE does not worsen; C RMSE improves and neither overestimate rate nor mean positive overestimate worsens. If neither intervention qualifies, label `DO_NOTHING` only as best among these tested legal actions and this finite horizon. Resolve qualifying ties by the primary metric, then lower measured training time.
- Export no generated natural-language rationale. Store `target_action` separately from visible `messages` and outcome evidence. Keep variants from the same source fold in one action-data split and count unique temporal blocks/bearings/engines separately from scenario variants.
- Stop before remote training. Report per-package source-group, qualified train/eval, action coverage, candidate gate, safety, and cost counts. A small or one-class dataset is a data-readiness failure, not permission to duplicate samples.

## Tasks

1. Add failing tests for official training-source hash/metadata validation, leakage-safe fold generation, and outcome-derived label eligibility. Implement the minimum data/fold and label-rule helpers.
2. Add failing tests for same-state counterfactual replay and action-only export with evidence isolated from prompt text. Implement the local cross-fit runner using existing replay/gate primitives and immutable output directories.
3. Run the bounded public-training-source generation, audit all manifests/source IDs/metrics/costs, and archive readiness results. Do not start PyTRiO LoRA/Decision Model training in this round.

## Verification

- Watch focused tests fail before implementation, then pass.
- Run relevant official SFT/data/replay tests and the full host suite.
- Run a fixed 4-CPU/4-GiB disconnected Linux validation with the existing verified base image and pinned dependencies; preserve receipts and do not rebuild or mutate the base image.
- Validate output hashes, cross-fit source exclusion, train/eval fold isolation, identical state hashes across action arms, future-gate ordering, per-package label metrics, and finite resource budgets.
- Because the labels are generated from public development data, do not describe them as hidden-test or independent official acceptance.

## Execution record before effects

Task 1 implementation is committed as `4b1b23e`; Task 2 as `1dfc2e0`. Both received independent read-only task review with no actionable defect. Task 1 focused9 plus prior data9 passed; Task 2 focused18, related SFT39 and adapter13 passed. The full host suite on these source bytes passed605/605 in230.171 seconds (`outputs/pytrio-crossfit-20261114/records/03-host-full-tests.txt`). Original red/failure and subsequent green receipts are retained in the task-scoped ledger area and will be copied into the experiment records.

The actual bounded matrix and disconnected Linux checks have not yet run at this freeze. A-prefix initialization preserves the source limitation: the120-row prefix contains only Ethanol/Ethylene and the250-row prefix only Ethanol/Ethylene/Ammonia. No source shuffle, future-class supplementation, action or threshold change is allowed after outcomes are observed.

## Final execution status — 2026-11-14

Tasks1–3 are complete for the approved local construction/audit scope. The earlier pre-effects record above is retained as history. Source was frozen clean at `88a10c8d9f1ef99fa0ec72d720a17ac0ae0eb608`; all151 build-source hashes match. Host605/605 tests passed in230.171s; fixed4CPU/4GiB/network-none Linux604 passed/1host-only skipped in104.361s. The test/matrix containers exited0 withoutOOM, using image `sha256:06cb2277ab24041c153a745b9a01ba6c121f6f7b082730cb5f4faf4cace60e28`.

Each side completed210 states/630 arms and11 fresh cross-fit initializations,420 adaptation fits. Both2868-file manifests, source IDs/exclusions, raw state/event/gate/versions, independent metrics/labels, candidate optimizer/freeze policies and dataset dedup provenance were audited. Each side contains234360 row pairs, with234360 static and234360 active predictions; uncached NumPy1.26.4 inference matches both vectors exactly. All3150 cross-platform prediction/target/ID/version arrays match; gate and action labels do not differ. Checkpoints contain small weight/Adam differences (initial maximum1.1102230246251565e-16; candidate4.926614671774132e-16), disclosed without claiming ZIP byte identity or adjusting thresholds.

The export is137 train/70 eval/0 review,207 rows after merging3 identical-input/same-label pairs. Raw210 state labels areNO173/LARGE25/HEAD12. `A_eval_single_action` is the sole structural coverage issue; NR-033 records that local data-readiness limitation, not an official disqualification or a claim that B/C gains cannot improve a combined score. Small separately authorized action-imitation/format studies could use these records, but autonomous learned-policy CPU gains, safety, resource performance and hidden scores remain unmeasured. ConstantNO action agreement is83.211679% train/80% eval.

Actual host/Linux bootstrap fit totals13.903750500/8.008323452s and adaptation251.556275900/88.992188198s are separate; each side released215136 existing-label row-times. No paid/API requests, LLM Tokens, new label requests, PyTRiO training or SwanLab upload occurred. No production default, dependency, action, gate or threshold changed after outcomes.

Results: [Chinese report](../../pytrio-crossfit-results-20261114.md), [validation index](../../validation/2026-11-14-pytrio-crossfit.json), [NR-033](../../negative-results.md). Immutable raw evidence is `outputs/pytrio-crossfit-20261114/{host-v1,linux-v1,records}/`; comprehensive audit is `records/13-output-audit.json`, with separate host/Linux uncached audits. Documentation review/local Git recording is controller-owned; no remote training is authorized by this completion.
