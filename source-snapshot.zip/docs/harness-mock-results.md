# Mock Harness：接口、熔断与核心链路验收

2026-11-07。依据用户明确确认的 [设计及实施范围](harness-mock-plan.md)，完成TDD、独立审查、宿主/断网Linux测试及六条核心流验证。**本轮为架构/协议验收通过，不是效果晋级；未跑大效果矩阵，未接真实大模型。**

## 实现与约束

- `ite/harness.py`：两份JSON Schema、严格验证、动作解析、BaseLLMClient/MockLLMClient。拒绝额外参数、重复键、尾随文本、非法Unicode，只允许四种动作。
- `ite/budget_guard.py`：Token80%含等号/调用预留、标签耗尽、非法响应/用量及客户端故障失败关闭。进入STATIC_FALLBACK后冻结当前模型，取消pending（含在途标签），停止新标签、训练、LLM和所有模型切换，继续预测。
- Controller/Runner共用Guard；SMALL/LARGE只使用配置白名单。ROLLBACK筛选上一部署快照、冻结，再经独立未来门控。预检、有限候选、训练超时与原配额保持。
- 独立配置 `configs/harness-mock.json`，原默认与旧模式保持。`harness_mock_mode=normal/invalid_json/token_exhausted`可复现正常/故障路径。见 [接口与使用文档](harness-mock.md)。

## TDD与审查

新增29项测试，完整测试175→204；原始日志位于 `outputs/harness-mock-20261107/records`，未覆盖首次失败：

| 单元 | 失败证据 | 通过证据 |
| --- | --- | --- |
| 契约/Mock | 01缺模块 | 02：6项 |
| Guard | 03缺模块；04日志关键字重复 | 05：7项 |
| Controller | 06缺配置；07复现DO_NOTHING仍训练、SMALL/ROLLBACK未接入 | 08：8项 |
| Runner | 09夹具缺close；10修正后复现摘要缺字段 | 11：5项 |
| 审查及演示回归 | 13模型年龄/Unicode；14报告未标模拟成本 | 15专项22项；16最终完整204项 |

独立只读审查发现两处P2：筛选预测误增模型年龄；孤立代理字符可能使UTF-8日志失败。均先复现失败，再修复，复核无剩余具体缺陷。最终全测包含Guard的非法Unicode熔断分支。

## 验证结果

| 验证 | 结果 |
| --- | --- |
| 宿主Python3.12.14、NumPy2.3.5 | 204/204，60.717秒 |
| Linux Python3.12.16、NumPy2.3.5 | 204/204，16.039秒 |
| Linux限制 | 4CPU、4GiB、network=none，退出0，OOMKilled=false |
| 核心流 | 两任务×stable/abrupt/gradual×seed7，各36批；每环境6次，共12次、432批 |
| 检查点重建最大差 | 0.0 |
| 宿主/Linux六对预测最大差 | 0.0 |
| 重载镜像只读核验 | 216批预测逐值一致，来源校验通过，不重训 |

旧生命周期/标签门控/默认兼容测试包含在204项中。新增集成证明：错误JSON或Mock额度耗尽后保守计8模拟Token，停止支出并完成36批；低Token预算首次调用前熔断；标签耗尽后在途标签仍释放审计，不再部署。定向测试另覆盖同批验收前取消pending、无快照拒绝、回滚未来门控和差候选未来拒绝。

核心配置保留32条未来验收标签、延迟2、配额864、alpha .1/10、窗口192/384/768。无降低门槛或按场景在线路由。每个环境的协议计数完全一致：

| 任务 | 场景 | 实际训练轮次 | 上线数 | Mock调用 | 模拟Token |
| --- | --- | ---: | ---: | ---: | ---: |
| 分类 | stable | 0 | 0 | 30 | 240 |
| 分类 | abrupt | 3 | 2 | 13 | 104 |
| 分类 | gradual | 3 | 2 | 16 | 128 |
| 回归 | stable | 0 | 0 | 30 | 240 |
| 回归 | abrupt | 2 | 2 | 16 | 128 |
| 回归 | gradual | 2 | 2 | 16 | 128 |

所有核心流沿用frontloaded调度，在第35批申请后耗尽标签并进入STATIC_FALLBACK；批次从0起，当批预测此前已完成。stable在新证据满足调用条件后仍询问Mock并返回DO_NOTHING，这不是调用成本最优方案；本轮不调整调用频率。真实LLM Token均为0，模拟Token和轻量训练墙钟不证明真实服务成本优势。Loss原值见机器回执，未作效果门槛判定或默认晋级。

## 来源、构建及交付

实现冻结提交 `20f288acfd6299f4480c2380dc68355e63854a7f`；源码SHA256 `817866e655593655dd574d2745614a72b2aab8527c35484f221f3ea5684fe3d9`。容器从Git archive构建，源码dirty=false；宿主有用户原有文档改动，不能称全局clean。后续报告提交不改变冻结镜像代码。

基础镜像摘要和依赖保持。测试/运行目标首次network=none构建因依赖层缓存缺失失败（17/22日志）；构建阶段改default网络后固定依赖缓存命中（19/24日志）。**实际测试、核心流、重载核验全部network=none**，不把联网构建说成全程离线。

- 运行镜像 `ite-local:harness-mock-20261107`，ID `sha256:427186bd7356844283f85452665c3e3f3ad8c5378f9b5fdf87379885bd94a46c`。
- 测试镜像 `ite-local:harness-mock-20261107-test`，ID `sha256:7a48e78e0fadb3ae98cfb12b5215c8c4a20fcd549ec3c933a797f7edf63e39e0`。
- 导出tar `outputs/harness-mock-20261107/ite-harness-mock-image.tar`，SHA256 `95c65ba0c32364c102d697ec217bcaa18c79e03359a082b0087363468b127f09`，重载ID一致。
- 源码ZIP、原始host-core/linux-core、检查点、报告、红绿日志及容器inspect保留于同轮独占目录。
- [机器验收回执](validation/2026-11-07-harness-mock.json)；只读协议重建为 `records/core-audit.json`。

本轮退出/OOM/资源配置回执齐全，cgroup峰值内存未测，不借历史数值。官方SDK/PyTRiO、真实调用取消/计费、完整状态续跑、长流故障与独立性能晋级均未验收。不新增NR效果失败编号、不改写历史阴性记录、不上传云端、不推送远程。

用户原有 `docs/negative-results.md` SHA256保持 `0176f7dcb42502e3ea9b5f43629ff5ff4e8b4db63f19a767ad12c00c91bd203a`，未纳入本轮提交。
