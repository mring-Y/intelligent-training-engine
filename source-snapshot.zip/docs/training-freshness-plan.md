# 训练标签时效：已确认的单因素开发实验

预登记日期：2026-11-04。用户回复“确认进入下一轮实验”，授权执行上一轮报告末尾的固定 8 批方案。本轮不调整启动额度或其他因素。

## 诊断与假设

依据 [NR-009](negative-results.md) 与 [上一轮四层诊断](startup-label-results.md)，启动 144 增加的主要是旧概念标签，分类突变三个种子首训全部为 120 旧、0 新。最新标签进入筛选验证，不代表用于训练。启动 0 也有训练来源偏旧问题。

假设：仅排除过旧的训练标签，能减轻跨概念混合并改善恢复。较少样本也可能增加方差或使候选无法训练，须保留失败边界；不预先认定过拟合或替换过急。

## 冻结的改动范围

- 新增 `train_source_window_batches`，非负整数，默认 0 禁用；候选固定 8。
- 先执行原完整来源批次的训练/筛选验证切分，再过滤训练集合，保留 `source_step >= latest_released_source_step - 7`；含端点，以最新已释放来源批次而非处理时钟为准。
- 原筛选验证集合完全不变。过滤后不足既有 16 个训练标签，或验证不足既有下限，则按原路径跳过并继续当前模型；不改变实验记账。
- 保持 adaptive 启动 0、monitor 32、训练触发下限、ridge、alpha/样本窗口、预算、调度、候选等待、future 独立上线门控和默认配置不变。在线不读取漂移真值/周期。
- 先失败测试再最小实现；覆盖端点/处理时钟、稀疏标签与 16 下限、验证不变、冻结后标签来源、0 兼容、延迟/短流及检查点恢复；必要的来源审计字段附测试。

## 开发矩阵与判定

对照 `configs/optimization-candidate.json`，候选 `configs/optimization-training-freshness-8.json` 只增加时间窗口 8。两任务 × 六场景 stable/abrupt/gradual/recurring/covariate/noise × 种子 7/19/43 × static/drift，每组 72，总 144。流长 96、延迟 2、比例 .25、总预算 864、周期宽度 8。禁止本轮试其他窗口、叠加策略或使用新的独立种子。

使用同一干净源码镜像 `ite-local:training-freshness-8-20261104`，先宿主机和 Linux 全套测试，再导出/重载镜像，随后以 4 CPU、4 GiB、CPU、`--network none` 顺序运行两组，输出新目录 `outputs/training-freshness-20261104/{adaptive-0,freshness-8}`。

```powershell
& $Docker run --name ite-freshness-control --network none --cpus 4 --memory 4g `
  --mount "type=bind,source=$Output,target=/results" ite-local:training-freshness-8-20261104 `
  ite matrix --config /app/configs/optimization-candidate.json --output /results/adaptive-0 `
  --tasks classification regression --scenarios stable abrupt gradual recurring covariate noise `
  --seeds 7 19 43 --policies static drift
& $Docker run --name ite-freshness-candidate --network none --cpus 4 --memory 4g `
  --mount "type=bind,source=$Output,target=/results" ite-local:training-freshness-8-20261104 `
  ite matrix --config /app/configs/optimization-training-freshness-8.json --output /results/freshness-8 `
  --tasks classification regression --scenarios stable abrupt gradual recurring covariate noise `
  --seeds 7 19 43 --policies static drift
```

`$Docker` 为 Docker CLI；`$Output` 为新输出根目录绝对路径。保存 inspect 的真实资源限制、退出码/OOM/时间及日志，再移除已停止容器；配额不冒充峰值内存。

1. 对照 36 次 drift 预测与上一轮 adaptive-0 逐值相同，两组 static 逐值相同；计时独立报告。
2. 审计全部输出、配额/释放延迟、训练来源下限和原时间切分、冻结后门控、实际 prediction 版本与检查点恢复。旧输入加指纹，禁止覆盖。
3. 比较逐种子损失、检测/训练/冻结/上线、漂移后损失和资源成本，完成特征/得分、残差、复杂度、时序四层诊断；真值只用于离线评分。
4. 开发门槛沿用：周期两任务 drift 均值不高于同组 static；其余五场景相对历史 legacy 的退化不超过分类 .005、回归 NMSE .01。legacy 为 `outputs/local-optimization-20261104/development/legacy/summary.csv`；不以舍入改变结论。
5. 失败先追加 NR-010 四字段，再做诊断和提出下一轮方案等待确认；不继续调时间上限，不替换默认。通过也仅表示开发候选，不等于独立验收或官方成绩。
6. 代码/测试/配置/预登记先本地提交；结果另提交。沿用现有 SwanLab 项目，核验原始归档及逐文件 SHA-256，生成新镜像交付包 `outputs/ite-training-freshness-delivery-20261104`。

官方数据、SDK、评分、配额及 PyTRiO 服务仍待提供；本轮仅验证本地模拟环境。
