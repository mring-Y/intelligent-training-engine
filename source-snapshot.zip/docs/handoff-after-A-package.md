# 下一对话窗口交接：官方 A 包接入与首轮验收

**当前交接（2026-11-14，优先于全部历史记录）：** 用户另行确认后，已加入 PyTRiO 受限代码工具、A/B/C CPU 十轮计数器、官方训练 split、筛选/未来门控与独立审计。工程演习由确定性测试 Actor 驱动，三包各10轮，宿主659/659、断网Linux657项中656通过/1宿主专用跳过；断网预测和父检查点链一致，NPZ浮点最大差5.55e-17。此工程实现不等于真实LLM轮次或效果晋级。真实Qwen4B第一会话因首提案重复官方父配置被安全拒绝；修正提示后第二会话首次read在15.0076秒超时并零重试，累计保守reserved¥9.24，A/B/C真实轮数均0/10，账本stopped，不重置、不继续调用。NR-035/036/037完整记录。四个SwanLab公开run均FINISHED：s4v3m4zw、u8hwkgrk、68gyv5k7、gulhfg2t。结果与正式交接见[受限代码Harness运行报告](code-harness-ten-rounds-results-20261114.md)、[机器回执](validation/2026-11-14-code-harness-ten-rounds.json)、[执行计划](superpowers/plans/2026-11-14-code-harness-ten-rounds.md)。真实十轮、三包普遍优于baseline和隐藏成绩均未验证；后续若继续真实调用须先对超时、成本及首轮动作重新诊断并取得新确认。此前C来源均衡48行replay NR-032与其他历史记录保留在下方，仍未晋级默认策略。

**当前交接（2026-11-13，优先于下方历史记录）：** A类均衡replay与B full/head-only单因素对照均已完成宿主和4CPU/4GiB断网Linux验证。A replay通过4/6分区，B head-only通过2/6、full通过0/6，均不晋级，static默认不变。A的10620条预测和全部评分跨平台一致；checkpoint浮点数组最大差1.11e-16，不能称字节一致。B的15111条预测及18份候选270个数组载荷精确一致。宿主563/563；Linux562通过、1宿主专用跳过，三个容器均退出0且无OOM。Docker实际位于用户目录，提升调用可连接现有daemon，不需重装。详见[唯一执行路线](superpowers/plans/2026-11-13-three-package-finetuning.md)、[B完整报告及A补验](official-b-head-results-20261113.md)、[机器索引](validation/2026-11-13-official-b-head.json)、NR-030/031。C本轮没有新训练，下一因素仍须独立诊断并单独确认；不重开已用Teacher paid claim。

**下一步C（只读诊断已完成，方案待确认）：** 本地提交`8aed58b`保存B轮及A补验。现有C的720行续训窗在train只覆盖FD003、eval覆盖FD002/FD003，筛选均为FD003；独立future gate与部署后评分均为FD004。已核对官方历史训练集与验证实体/ID无交集。建议仅验证“每个FD子集12台历史训练发动机各取1行，共48行，替换最旧48行”的来源均衡replay；总训练行数、普通head-only损失、筛选和future gate不变。完整证据、测试范围、成本和门槛见[唯一执行路线](superpowers/plans/2026-11-13-three-package-finetuning.md)及[只读来源索引](validation/2026-11-13-official-c-source-diagnosis.json)。尚未选取reserve、写C代码或运行新策略，须先取得对此因素的明确确认。

**2026-11-14 最新：** C包官方MLP head_only仅对正残差乘2的非对称平方损失已TDD接入并完成18流对照。RMSE在漂移流下降，但4个train/eval分区高估率仍超静态，NR-028归档；step7用于训练的720行初始残差全非正，所以惩罚初始梯度不触发。宿主537/537，断网4核8GiB Linux536过/1宿主专用跳过；预测与checkpoint数组逐值复现。没有输出校准、3×扩展、API、LoRA或默认变更。详读[本轮报告](official-asymmetric-loss-results-20261114.md)、[机器回执](validation/2026-11-14-official-asymmetric-loss.json)、[NR-028](negative-results.md)。后续策略须先重新诊断并取得确认。

**2026-11-13 最新：** 用户确认后完成官方`full/head_only`续训策略、官方专用`RETRAIN_HEAD_ONLY`、独立微调Prompt及边界/降级测试。C包3组×3场景×2分区=18流，固定step7、720+48、原LR0.002/5epoch/5秒/总20秒，12次续训8次部署；full/head均降低漂移RMSE但增加高估，NR-027归档，不晋级默认策略。宿主533/533；最终源码`e6c2b0c`固定镜像4CPU/8GiB断网Linux532通过1宿主专用跳过，18流数值复现。207441个预测、12候选全部数组一致，NPZ仅ZIP系统标记导致文件哈希不同。真实API/LoRA0，不重开旧paid claim；不要把冻结视为已解决遗忘或高估。详读[完整报告](official-head-only-results-20261113.md)、[机器索引](validation/2026-11-13-official-head-only.json)、[NR-027](negative-results.md)。新策略仍先诊断、预登记并单独确认。

交接日期：2026-11-08。项目根目录：`C:\Users\LENOVO\Desktop\Intelligent Training Engine`。

**2026-11-12 最新交接：** 官方A/B/C均已接入，当前默认`official_mlp`/auto路由，隔离工业worker NumPy1.26.4、主环境2.3.5，Tree/Ridge降级与审计保留。历史487项与4B真实日志已归档[SwanLab ljc6re1q](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/ljc6re1q)。新SFT生成器完成九场景18分区、23次本地resume工程预检，源码`a769043`，宿主514/514、断网4CPU/8GiB Linux513通过1项宿主专用测试跳过。随后真实27B Teacher完成27次，输入15858/输出1045 Token，延迟7.60–8.87秒；费用估算¥0.07638075、用户界面账目约¥0.07。A/B实际预测保持静态；C两项RMSE改善却增加高估，最终train0/eval0/review27，无4B微调。原始输出`outputs/official-sft-20261112/`、[完整结果](official-sft-pilot-20261112.md)、[机器回执](validation/2026-11-12-official-sft.json)、NR-025/026；当前测试流为公开验证集的时序模拟，不代表官方隐藏测试集的真实表现。真实run的Git字段unavailable但core哈希匹配冻结源码；补充24次停止未及时生效，实际27次及完成后锁止均有原始回执。不要清除`outputs/official-sft-27b-paid-state-20261112/run-claim.json`重置额度；任何新Teacher、Prompt、窗口或LoRA方案须另确认。

以下按历史轮次保留，“最新”等称谓仅指各段形成当日；当前状态以上方2026-11-12报告为准。

**2026-11-11 最新补记：** 用户提供官方CPU A ZIP后，完成A专用`OfficialModelAdapter`、隔离NumPy1.26.4 worker、配置和Mock回放。官方checkpoint完整公开验证集Accuracy87.8617%、Macro-F1 0.714030。公开验证集时序模拟中step4触发RETRAIN_SMALL，96条候选在source3筛选集loss0，但115条独立source5 gate上candidate/incumbent错误率均1.0，validation_gain=0，step6被拒绝；0部署，全部在线预测v0。公开验证集模拟不代表隐藏集，A包元数据状态为draft；Docker尚未验证。[详细结果](official-model-results-20261111.md)、[NR-023](negative-results.md)、[原始输出](../outputs/official-a-mock-20261111/)。

**2026-11-11 最新补记：** 按用户新授权，对既有FD001 step10 Observation执行一次真实Qwen Tree防守短流。源码先冻结在`506660b`；请求于15.20秒端到端超时，Fail-Closed、零重试，18批由当前v0完成，0次训练/部署。服务端Token及最终费用未知，未结算预留¥0.01374962；无响应JSON/Reason，不能把该轮称作Qwen理性选择DO_NOTHING。[Qwen记录](../Qwen_Live_Decision.md)、[答辩交付结论](official-submit-delivery.md)、[运行回执](validation/2026-11-11-cmapss-qwen-defense.json)。Paid claim为单次已用，不重新创建预算或重试。

以下2026-11-10状态为此前轮次记录，以以上最新补记为准。

**2026-11-10 最新轮次：** 用户明确批准的FD001 Tree Harness对照已完成，源码冻结`c14ef34`。
20台/4493条/18批全流RMSE static=Harness=21.067320724574518；step10的192条SMALL候选
selection NMSE0.5117230922差于现模型0.4608141181，被拒绝，0冻结/部署，全部预测v0。
三项预登记正向条件失败后先归档NR-022，没有运行付费阶段或再次调参。
真实Qwen请求/Token/费用均0，[Qwen_Live_Decision.md](../Qwen_Live_Decision.md)明确记录未执行及缺测项。
宿主与4CPU/8GiB/断网Linux各445/445测试通过，全部预测/ID/offset/检查点逐值复现；
新开发镜像`ite-local:cmapss-tree-harness-20261110`，原官方镜像和默认保持。
详见[结果与四层诊断](cmapss-tree-harness-results-20261110.md)、[验证索引](validation/2026-11-10-cmapss-tree-harness.json)。
下一轮不能把0收益或Mock拒绝包装成真实大模型保守决策；任何新窗口/Prompt实测/默认策略须重新提出方案。
以下内容按历史轮次保留，以本段和最新报告为准。

**2026-11-10 TreeModel 后续结果：** 用户批准后已完成安全单棵CART接入、TDD、hash锁定依赖与断网镜像验证。固定树静态Gas43.215745%、轴承RMSE917.851798秒、FD001 RMSE21.067321周期，均与宿主逐值复现；Gas Tree Harness一次future上线后的Accuracy30.980752%，未过50%，见[结果与NR-020](tree-model-results-20261110.md)。源码冻结`5a9da0a`，树专用5秒上限由三份初始集冷启动4.24–4.61秒计时确定，Ridge仍3秒，总预算20秒。真实API Prompt Demo尚未运行，C-MAPSS非树Harness及LightGBM仍未实施。

**2026-11-10 最新第二轮：** 用户具体批准先执行Gas Mock干预和轴承Cap10000。已完成并保留原九批/原实体：Gas全流Accuracy26.07%→27.29%，一次SMALL/冻结/独立future门控/上线，实际v1的4364条Accuracy32.65%，50%目标失败；轴承Cap0截断、RMSE3013.33秒不变。详见[本轮曲线和诊断](gas-harness-cap-results-20261110.md)、[机器验证](validation/2026-11-10-gas-harness-cap.json)、NR-018/019。源码`774f877`，新增显式`ovr_ridge`六类Runner/有界worker及可选Cap；默认二分类保持。宿主/断网Linux各381项、1可选跳过，26982条重载检查点预测逐值重现，新镜像`ite-local:gas-harness-cap-20261110`。原A包746文件、原官方提交标签均保留。下一轮不能把未达到目标视为已证实Ridge上限，须先读本轮四层证据；C-MAPSS/树/新Gas策略尚未执行，须按SOP提出具体方案确认。

**2026-11-10 后续更新：** 用户指定三个公开数据源作为开发 A 包，并明确批准数据预处理及短流静态 Baseline，轴承目标最终为 RUL 回归。已完成实际 Gas、FD001 和工况1三个完整轴承的准备包与静态结果；详见 [本轮结果](public-a-baseline-results-20261110.md)、[脚本入口](../scripts/data_prep/README.md)、[机器验收](validation/2026-11-10-public-a-baseline.json)。实现/镜像冻结 `5fc8380`，宿主与断网Linux均337项、各1项可选跳过，三源原始数据Linux重建及重载检查点核对通过。新专用验证标签 `ite-local:public-a-prep-20261110-verified`，原 `ite-final:official-submit` 保持。以下“官方 A/B 未到本地”是11月8日历史状态；当前已有用户指定公开开发A，但正式SDK/隐藏B/官方基线仍未提供。Mock干预与多分类生产适配尚未实施，下一轮仍按SOP提出具体策略确认。

## 当前状态

- 交接撰写前 HEAD：`3685c5d docs: record official submit image`；提交 `3bad96a` 是本地 Mock A 包生成器和脏数据演习，`3685c5d` 只增加交付索引。本文之后的交接文档提交仅更新 Markdown/README，不改变镜像源码。开始工作前运行 `git status --short`，保留用户已有改动。
- 官方 A/B 数据和正式 SDK 尚未出现在本地。根目录 `outputs/mock-A-package-20261108` 是合成演习数据，绝非官方样本。
- 最终 runtime 镜像标签为 `ite-final:official-submit`，ID `sha256:242328072a5fdcac5ca98f173fb6eed9dafa32a31e5ab6ff10a69e2aaa0d5234`，大小 `950424183` 字节，源码提交 `3bad96a`、dirty=false。Docker 镜像列表只保留该标签；14 个历史停止容器为保护容器数据而保留。
- `--network none --cpus 4 --memory 8g` 下，最终镜像运行了 Mock A 四流、每流 10 批的演习；10 次 Mock 决策、0 真实 Token、0 次部署。完整命令和 SwanLab 链接索引见[最终镜像交付页](official-submit-delivery.md)。
- SwanLab 项目 `mring-Y/Intelligent_Training_Engine` 的最近保存回执显示匿名访问 HTTP 200、visibility=`PUBLIC`。A 包到手后不删除、覆盖或重传已有 run；若需上传新实验，使用新 run 和显式审批流程。

## 必读材料

1. [AGENTS.md](../AGENTS.md)、[迭代 SOP](iteration-sop.md)、[阴性结果](negative-results.md) 与[最新诊断](negative-diagnosis-20261104.md)。
2. [赛题 PDF](../c945f17fdaf0636a7a36aca3d4264fd8.pdf)、[培训纪要](competition-briefing-notes.md) 和 [README](../README.md)。官方后续通知优先于历史会议纪要。
3. [OfficialDataProvider 接口说明](official-data-provider.md)、[README_OFFICIAL](../README_OFFICIAL.md) 和 [Mock A 演习记录](mock-A-package-rehearsal.md)。
4. [方法论答辩文档](Methodology_Defense.md)、[树模型安全设计](TreeModel_Security_Design.md) 和[最终镜像/SwanLab 证据索引](official-submit-delivery.md)。
5. 最新工程与付费边界：[三突变结果](three-abrupt-results.md)、[PyTRiO 结果](harness-pytrio-results.md)、[NR-016](negative-results.md) 中的真实请求超时记录。

## A 包到手后的第一轮

先只读检查官方交付说明、SDK 版本、许可/保密要求、目录结构、文件格式、字段定义、批次边界、标签可见时序和评分协议。保留原始归档为只读，记录文件清单、字节数和 SHA-256；不要把私有 A/B 文件放进 Git、Docker build context、SwanLab 或聊天记录。推荐保存在被 `.gitignore` 排除的 `data/private/A/` 下。

分别为气体传感器、轴承、发动机 RUL 建立字段映射清单，至少记录：任务类型、特征列及顺序、目标列/单位、样本或设备 ID、批次/周期、初始训练集、初始验证集、在线评测流、时间戳语义、缺失值比例、标签释放协议。不得根据列名自动猜测特征，不能把时间戳、设备 ID、目标或未来统计量泄漏到特征中。

当前 [`ColumnMapping`](../ite/providers.py) / `OfficialDataProvider` 约束：特征顺序必须显式；stream ID 是唯一非负 int64；批次是有序、连续的零基整数，同批行连续；每批先生成并提交预测，之后才能请求/释放标签；Initial train 和 validation 必须与 stream 分开。保留官方批次顺序，不按标签、漂移真值或未来表现重排数据。

| 数据集 | 当前可用路径 | 接入前必须确认 |
| --- | --- | --- |
| 气体传感器 | 数值特征 + 二分类 Ridge/Runner | 官方类别编码是否为 0/1；传感器列顺序、设备/时间字段、批次协议；高维非线性表现需先对照官方 static |
| 轴承退化 | 数值特征 + 回归 Runner | 目标量纲/归一化、设备实体、时间序列边界；不得让同一设备的相邻窗口跨训练与验证造成泄漏 |
| Engine RUL | 当前只能接数值回归接口 | 真实 RUL 单位、设备寿命轨迹、cycle/entity 语义、删失规则和窗口构造均需官方说明。`engine_rul` Mock 流只是代理，不是物理寿命模型 |

首轮只做数据结构审计和最小单流校验：读取一批、核对列和特征维度、校验首批 NaN/Inf/极端值、提交静态预测、按官方协议申请/释放标签，并检查 audit。不要把包含全流标签的离线 CSV/Parquet 当作允许控制器预知未来标签。若官方 SDK 的回调时序与文件 Provider 不同，先设计 Provider 适配层，不绕过 commit/label gate。

随后按任务先跑短流 `static` 对照，保存 predictions/events、数据来源 hash、清洗审计、标签来源与资源消耗；再在独立输出目录跑 Mock Harness 短流。只有字段/标签协议、baseline 与容器行为核验后，再根据用户确认的门槛讨论正式训练/部署验收。不要一开始跑 144 次矩阵，也不要用 A 包反复调参后再把同一数据当独立验收。

## 防御性数据规则

- 特征 NaN/Inf/非法值：由 Provider 使用初始训练集有限值中位数填补并计入 provenance；缺特征列也显式审计。确认官方评测是否允许这种策略，不能静默改清洗规则。
- 缺失标签：不插补、不请求、不用于训练或验收；同批后续有效标签仍须继续处理。已有回归测试覆盖曾发生的提前 `break` 标签漏取缺陷。
- 极端有限值/离群点：记录最大绝对值和 float32 overflow 计数，当前 Provider 不裁剪。确认模型数值尺度可能溢出时，先停止晋级并报告，不临时加裁剪或标准化策略。
- 时间戳不连续/乱序：timestamp 作为 metadata，不代替官方 batch/cycle/entity 映射。按官方定义生成稳定有序批次，不能只靠全局时间排序推断标签释放时间。
- 缺测、转换失败、额外列与单位不明都要留在审计中；不能把异常变成零值或删掉后不计数。

## 实施与验收边界

修改仓库或运行新实验前，遵守 [AGENTS.md](../AGENTS.md) 和 [iteration-sop.md](iteration-sop.md)：先给出**【诊断结论】**及**【准备采用的升级策略】**，取得对本轮具体改动/实验的明确确认；确认后先写失败测试再实现。未过门槛先追加阴性档案。保留独立未来标签门控、预算保护、Mock/真实后端分界和所有原始输出。

当前 Provider 支持 numeric features、binary classification `0/1` 和 numeric regression。多分类标签、波形/窗口特征、RUL 单位转换、实体时间序列切分，以及把数据路径直接写进普通 CLI 配置，均没有自动适配。不要因 README_OFFICIAL 的示例而声称只填路径就可运行。

任何官方流效果需与官方 static 在相同数据边界及评分规则下比较；本地历史阈值不是官方阈值。保留 seed/数据划分作开发还是独立验收的身份，不重复使用已见种子伪装独立结果。真实 PyTRiO 调用需要单独、明确的用户授权和持久预算账本；Mock 通过不等于真实模型通过。

## Docker 与提交

基础镜像摘要和依赖锁不可随意升级。联网构建使用 [最终交付页](official-submit-delivery.md) 中的命令；评测运行必须 `--network none --cpus 4 --memory 8g`，新源码/依赖改变后应构建新的 provenance 镜像并重新做短流测试。不要修改官方最终镜像标签来掩盖源代码变化。

当前 Docker 命名镜像只保留 `ite-final:official-submit`；本地历史停止容器保留，避免清除其容器数据。若未来需要彻底回收这些容器及其 writable layers，必须单独评估其是否有唯一日志/检查点并取得用户明确授权。

完成 A 包首轮后，更新本文件顶部状态或新增日期化结果文档，写明哪些任务可读、哪些适配完成、测试/容器回执、未测项和官方基线差值。下一窗口启动提示：

> A 包已下发，位于 `<官方提供的数据路径>`。请先阅读 `docs/handoff-after-A-package.md` 和其中列出的 SOP/Provider 文档，检查 `git status`，只读核对数据说明、schema、SDK 与协议；先向我报告【诊断结论】和【准备采用的升级策略】，不要直接跑矩阵或真实 API。确认后先写数据 Provider/Runner 的失败测试，再完成单流数据审计与断网容器 smoke。保留官方原始文件和所有 SwanLab 旧记录。
