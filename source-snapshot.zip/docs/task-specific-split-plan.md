# Task-Specific Disjoint Split: Preregistration

2026-11-05. This preregisters one split-policy change against the approved global `recent_disjoint` allocation. It does not change model, label budget, scheduler, monitor, candidate windows, weighting, or independent deployment gate.

## Diagnosis

The global splitter requests 48 selection labels from up to the latest 96 released entities. In the latest 24 entities, this already yields 12 training and 12 selection entities. A nominal 32/48 setting would be a no-op if it only changed a descriptive window field, so the candidate changes the actual partition:

- Classification outside the recurring scenario: use the latest 48 entities as the disjoint pool, with 24 selection entities and the other 24 retained for training. All older released entities remain training-only. The latest source can contribute to both roles, but a label entity cannot occupy both.
- Regression outside the recurring scenario: preserve the current global pool, up to 96 entities with 48 selection labels.
- Both tasks in the recurring scenario: restore whole-source-batch chronological splitting, with the existing 48-label requested selection tail. The 16-label training floor and 32-label chronological validation minimum remain unchanged.

For the classification route, the explicit selection count becomes 24; the existing 48-label selection set is intentionally not retained. This increases the training partition by moving older selected entities to training. Selection and training entity identities remain disjoint. The task and scenario are known configuration fields; targets and drift truth are not consulted by the router.

## Fixed Conditions

- Control: [optimization-task-specific-control.json](../configs/optimization-task-specific-control.json), identical to the previous global `recent_disjoint` configuration. Under that rule, the latest 24 entities happen to contain 12 training and 12 selection entities.
- Candidate: [optimization-task-specific-split.json](../configs/optimization-task-specific-split.json); after validated defaults are expanded, the only configuration difference is `selection_split`.
- Candidate routing is `task_specific`: classification/non-recurring uses pool 48 and validation 24; regression/non-recurring keeps the global 96/48 rule; recurring uses chronological whole-source-batch separation for both tasks.
- Keep 96 batches, delay 2, label fraction .25, label cap 864, adaptive schedule, monitor threshold 32, 192/384/768 candidate windows, preflight enabled, exponential weighting with half-life 4, and future independent gate of at least 32 labels produced after candidate freeze.
- No class balancing, additional sample threshold, schedule change, history reuse, model change, or drift-truth input.

## Tests and Matrix

Before running the matrix, tests must prove: the class route selects exactly 24 unique validation entities from the latest 48 and sends all older entities to training; training/selection identities do not overlap; non-recurring regression reconstructs the global partition exactly; recurring classification and regression use whole-batch chronological separation; future gating remains mandatory; control and candidate differ only by split policy; insufficient supplies still preflight without consuming attempts or cooldown.

After host and offline Linux container suites pass, run 144 paired cells: 2 configs × 2 tasks × 6 scenarios × seeds 7/19/43 × static/drift. Use one frozen source/container, 4 CPU, 4 GiB, CPU-only, and `--network none`; store outputs in a new exclusive directory. Static predictions must match exactly between arms. Preserve all raw events, curves, predictions, checkpoints, and per-run config.

## Endpoints and Decision

Primary diagnostic endpoints are classification loss plus fit/selection counts in non-recurring scenarios, and recurring detection, feasible training, deployments, and loss for both tasks. Also inspect all 12 task/scenario cells, per-seed paired differences, training/selection source counts, gate rejections, label use, and resource cost. Do not infer a recurring false alarm from a detector event alone; align event and prediction versions.

Use the existing 96-batch development gates without relaxing them: both recurring task losses must be no worse than their same-arm static baselines; other scenarios must remain within the existing legacy tolerances (.005 classification error and .01 regression NMSE). This is development evidence only and does not reuse previously seen independent seeds as new acceptance data. If any gate fails, append the four required fields to [negative-results.md](negative-results.md) before proposing another change.

## Status

Completed, with closing audit on 2026-11-07. TDD RED was observed before the config and router existed: five focused tests errored on the unknown pool field and unsupported split mode. TDD GREEN: 48 focused routing/audit tests passed, followed by 162/162 complete host tests. The frozen offline Linux test image also passed 162/162 in the closing verification. The 144-run development matrix is complete: recurring means improved for both tasks and classification gradual improved, while classification abrupt worsened. Four historical legacy gates still fail; NR-014 records the negative result and defaults are unchanged. Full results, temporal/label audits and measurement gaps are in [the result report](task-specific-split-results.md). No new independent acceptance seeds were used. Matrix cgroup peak and full container lifecycle receipts were not retained; they are explicitly missing, not inferred from the demo receipt.
