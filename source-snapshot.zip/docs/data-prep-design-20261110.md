# Public A data preparation: approved MVP

Approved scope: the user's 2026-11-10 instructions, including the latest choice of XJTU-SY **RUL regression**, supersede the earlier fault-classification reply. These public sources are the development A package at the user's request; they do not supply the competition SDK or hidden B evaluation protocol.

## Data and model contracts

- UCI Gas: all six gas classes, 128 supplied features. Preserve the ten source batches. Split only source batch 1 into deterministic class-stratified initial train/validation; batches 2–10 are the chronological stream. Use a One-vs-Rest wrapper around the existing binary `RidgeModel`; do not modify that model or the production binary task.
- C-MAPSS: FD001 run-to-failure **training** trajectories only. Fixed, disjoint engine groups: units 1–60 train, 61–80 validation, 81–100 development stream. Per-unit target is `min(125, max_cycle - cycle)` in cycles. Preserve unit/cycle order. The published censored test split and its endpoint RUL labels remain reserved; never assign zero endpoint RUL to a censored trajectory.
- XJTU-SY: use actual documented sample rate 25,600 Hz, two vibration channels, 32,768 samples per recorded file, nominal 60-second interval. Produce nonoverlapping complete one-second windows; audit dropped tails. Optional resampling must suppress out-of-band frequencies. Per channel compute RMS, peak-to-peak, Pearson kurtosis and the dominant non-DC analytic-envelope spectrum frequency. Raw waveforms never become model features.
- Bearing target is seconds to the last recorded window of each complete run-to-failure bearing, an explicitly documented endpoint proxy. Keep complete bearing entities disjoint. For each available condition, bearings 1–3 train, 4 validation, 5 stream. If only a smaller authentic subset can be acquired, use a documented fixed whole-bearing split and report the exact coverage; no synthetic replacement or row shuffle.
- Every prepared package contains `train.csv`, `val.csv`, `test_stream.parquet`, `manifest.json`; schema contains `sample_id`, `batch_id`, `target`, an explicit ordered feature list and optional metadata. Sample IDs are globally unique across the three splits. Stream batch IDs are dense zero-based integers. Metadata, cycle, entity, source index and targets are excluded from predictors. Prepared file paths used at runtime are package-relative; raw-source audit fingerprints may retain their original absolute locations and are not used to load the package.
- Fit imputation medians on training features only. Never impute labels. Record invalid/missing labels, feature repairs, file hashes, split entities, ordering, window/resampling parameters and target units. Reject an all-missing training feature and nonempty output directories.
- Baseline uses the existing `ParquetDataProvider`, a frozen original Ridge or OVR model, and predict/commit before post-run scoring. Report six-class accuracy/confusion counts or RUL RMSE in original units, plus timings and predictions. No tuning, paid calls or production default changes.

## Shared implementation interface

`scripts.data_prep.common.export_dataset(output_dir, *, dataset, task, features, train_rows, val_rows, stream_rows, metadata, batch_size=256)` returns the saved manifest dictionary. Input rows are dictionaries with named numeric features and `target`; `batch_id` may be supplied for an existing chronological boundary. The exporter assigns globally unique IDs. Initial splits have at least four valid rows. Paths in the manifest are package-relative.

`download_file(url, path, *, expected_sha256=None, max_bytes=2147483648, timeout=30)` stores an immutable raw file plus a source receipt and returns its path. `extract_zip(archive, destination)` rejects traversal and symlinks. `fingerprint(path)` returns path, bytes, SHA-256.

Dataset modules expose `prepare_gas(source, output_dir, **options)`, `prepare_cmapss(source, output_dir, **options)`, and `prepare_bearing(source, output_dir, **options)`, plus `python -m scripts.data_prep.<module>` CLIs supporting local inputs. Dataset-specific CLIs may acquire official raw data using the common download helper.

All data and receipts stay under ignored `outputs/a-package-20261110/`, outside Git and the Docker build context. Failed acquisitions remain explicitly recorded. No cached synthetic A file substitutes for a public raw dataset.

## Verification and scope boundary

Write and observe meaningful failing tests before implementing each unit. Verify train-only imputation, engine/bearing isolation, exact RUL arithmetic, analytic-signal and resampling behavior, gas class coverage, immutable outputs, safe archive extraction and actual Provider round trips. Run the full existing suite, then three real-data static baselines. Use the pinned Linux image with network disabled, four CPUs and 8 GiB for required offline checks; report any actual environmental block without presenting host checks as container evidence.

The immediate deliverable is preprocessing and initial static results. Mock adaptation follows only after the static packages and score boundaries are validated; no fake drift or automatic strategy optimization is included in this MVP. Failed engineering checks are repaired within scope. Failed performance claims must be recorded in the negative-results archive before any optimization.
