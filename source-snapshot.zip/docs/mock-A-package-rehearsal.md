# Mock A 包生成与演习

生成器位于 [`scripts/make_mock_A_package.py`](../scripts/make_mock_A_package.py)，使用仓库 `make_simulation` 生成 Parquet 初始训练/验证数据、完整流、10 批演习流、缺失通道变体和 `manifest.json`。运行前需安装固定可选依赖 `requirements-data.txt` 中的 PyArrow。

```powershell
python scripts/make_mock_A_package.py --output outputs/mock-A-package
```

输出路径必须不存在，以避免覆盖原始演习证据。默认会接着运行 10 批 `OfficialDataProvider` + `Runner` + `MockLLMClient` 演习，结果保存在 `rehearsal/rehearsal.json` 与每条流各自的 `events.jsonl`、`predictions.npz` 中。全程不调用 PyTRiO，真实 LLM Token 消耗为零。

## 数据集代理

- `gas_sensor`：24 个特征的非线性分类流，提供 abrupt 概念变化。
- `bearing`：12 个特征的非线性回归流，提供 gradual 与 abrupt 两条代理流。
- `engine_rul`：8 个特征、96 批渐变漂移的回归代理；演习使用其独立生成的 10 批短流。manifest 固定写入 `"data_type": "proxy_stream_requires_official_mapping"`。它不是逐发动机轨迹或真实物理 RUL 模型；官方数据到位后必须映射特征、目标、设备和周期字段。

每条流含有缺失值、Inf、有限 float32 溢出值、缺失标签、乱序时间戳和一个缺失特征通道版本。特征异常由初始训练集有限值中位数填补并审计；离群值保留、不裁剪；缺失目标不会插补或申请标签。脏值安排在演习流第一批，便于在短流内验证读取和预测的防护路径。

## 结果解释

该演习只验证数据契约、Mock 决策、资源预检、预测输出和审计链路。合成流精度不代表 A 包成绩；Mock Harness 决策不等同真实 LLM 判断；RUL 代理更不代表发动机寿命建模有效性。

## 2026-11-08 本地回执

生成包位于 `outputs/mock-A-package-20261108`，运行摘要为 `rehearsal/rehearsal.json`。四条演习流各处理 10 批、每批 96 行，合计写出 40 条批次 prediction 事件和 3,840 条预测；Mock 客户端共调用 10 次并解析出 10 条 Harness 决策，真实 LLM Token 为 0。

各流结果：gas sensor abrupt 为 1 次 Mock 决策、1 次训练尝试、1 个候选冻结、0 次部署；bearing abrupt 为 1 次决策/训练尝试、0 冻结/部署；bearing gradual 与 engine RUL gradual 各 4 次决策、0 训练尝试/冻结/部署。短流中的独立未来标签不足以保证候选验收，因此这些计数是链路回执，不是性能或部署成功声明。事件、原始预测与模型快照均在各自输出子目录保留。

宿主完整测试通过：287 项、1 项跳过（项目 venv 未安装可选 scikit-learn）。Docker Desktop 的 Linux test 镜像中也运行了同一套 287 项测试，68.146 秒通过、1 项跳过。容器使用只读挂载的当前工作区，资源参数 `--network none --cpus 4 --memory 8g`；同时单独运行 Mock A 专项测试并通过。复用了已有 pinned test 镜像，没有重建镜像；尝试禁网重建时，Docker 因构建网络改变而未命中 pip 依赖层缓存，pip 在断网下无法重新下载 NumPy，因此没有把该次构建失败算作测试失败或联网重试。测试容器使用 `--rm` 清理，用户已有容器未被启动、停止或删除。
