# 本机运行与交付手册

2026-11-08：[三次突变结果与交付](three-abrupt-results.md)、[数据Provider接入](official-data-provider.md)。专用入口`python -m ite.three_abrupt --backend mock --output <新空目录>`只做固定30批工程验证；本轮真实流已耗用唯一执行声明并超时，禁止把换目录、删账本或换容器当成重试授权。后续付费及超时策略变动须按SOP重新确认。公开归档入口`ite upload-swanlab --run-dir <准备好的归档> --project Intelligent_Training_Engine --workspace mring-Y --archive`核验Public和匿名项目身份，上传已有回执/ZIP会拒绝覆盖。

开始任何新的代码修改、调参或策略实验前，先执行 [迭代 SOP](iteration-sop.md)：读取 [阴性结果档案](negative-results.md)，按日志完成诊断，给出【诊断结论】和【准备采用的升级策略】，取得用户对本轮方案的明确确认，再先写测试、实现并运行实验。下列命令是运行/历史复现参考，不代替这一步确认。已看过的独立种子只能用于历史对照。

## 已验证的运行时

项目根目录：`C:\Users\LENOVO\Desktop\Intelligent Training Engine`。本机 `.venv` 以 Codex 自带 Python 3.12.14 创建并使用 NumPy 2.3.5，包已可编辑安装。它引用宿主运行时，不是可复制到其他设备的便携 Python 环境；其他设备按 README 重建环境。

```powershell
.\.venv\Scripts\python.exe -m ite --help
.\.venv\Scripts\python.exe -m ite run --config configs/default.json --output outputs/my-run
.\.venv\Scripts\python.exe -m ite matrix --output outputs/my-matrix --seeds 7 19 43 --ablation
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

使用独立上线验收和较长冻结矩阵时，配置文件可复用全部参数；命令行显式参数优先：

```powershell
.\.venv\Scripts\python.exe -m ite matrix --config configs/default.json `
  --output outputs/frozen-matrix --tasks classification regression `
  --scenarios stable abrupt gradual recurring covariate noise `
  --seeds 101 103 107 109 113 --batches 96
```

配置 `deployment_validation: "future"` 会在候选搜索完成后冻结候选，并只接受冻结后产生且延迟释放的标签。`monitor_min_labeled` 与训练所需的 `min_labeled` 分离；`reuse_history: true` 只允许与 `future` 同时使用，并使漂移策略先评估归档模型。`legacy` 仍是默认值，确保历史报告可重放。

运行结束直接打开输出目录中的 `report.html`。该文件只使用内联 JavaScript，可离线打开，不加载远程脚本。已存在的非空实验目录会被拒绝覆盖。

## 每个实验的文件

- `config.json`：实验配置，策略目录另含策略名。
- `events.jsonl`：预测、标签申请/释放、漂移证据、实验与候选、上线/回滚及完成/失败。
- `summary.json`、`summary.csv`：累计指标和成本；回归损失按初始验证集方差归一化。
- `curve.csv`：逐批事后评分与资源记录，不供决策读取。
- `diagnostics.json`：离线场景真值计算的变化起点、检测延迟、漏检、误报、重复告警和漂移后累计损失；不进入控制器。
- `predictions.npz`：先于标签获得的逐批预测。
- `initial.npz`、`deployed.npz`、`model-v*.npz`：初始、当前及版本模型；加载时禁用 pickle。
- 矩阵额外有 `aggregates.csv`：每种任务/场景/策略的多种子均值和标准差，策略消融独立归组。

静态模型不申请流内标签。两种更新策略使用同一组标签申请随机数及相同资源上限。初始训练时间与初始训练/验证标签单独报告；增量候选时间含工作进程启动和清理开销。候选池不会访问离线评分器的完整标签。

## SwanLab

项目：<https://swanlab.cn/@mring-Y/Intelligent_Training_Engine>。本机 SDK 0.10.3 已安装，使用用户在终端完成的登录；不读取或打印密钥原文。

Windows 终端若仍使用 GBK，请为上传进程先设置 `$env:PYTHONUTF8='1'` 和 `$env:PYTHONIOENCODING='utf-8'`，避免 SDK 输出图标时因编码报错。

```powershell
.\.venv\Scripts\swanlab.exe login
.\.venv\Scripts\python.exe -m ite upload-swanlab --run-dir outputs/my-run/drift
.\.venv\Scripts\python.exe -m ite upload-swanlab --run-dir outputs --archive
```

归档模式将指定目录内所有已落盘实验的配置、JSONL、结果、预测和检查点打包，并嵌入文件哈希清单。SwanLab 中会显示归档文件与每个实验的摘要，原始每轮决策可从归档内查看。SDK 登录信息只由 SDK 保管，`.env`、`.swanlab` 和其他非白名单文件不会进入归档。

上传成功后本地写入 `cloud-upload.json`，记录 URL、项目、实验数量及归档哈希。正式实验记录字段、离线评测期间的日志同步和链接提交形式尚需官方规范确认。

## 容器

本机 Docker Desktop 4.98.0 的 Linux 引擎已经验证可用（Engine 29.9.2，32 CPU，约 15.3 GiB 内存）。2026-11-04 的 Docker Hub 实际拉取成功；本阶段的本地验收固定使用 4 CPU、4 GiB 内存和 CPU 推理，这不是官方正式配额。交付脚本使用 PowerShell 7，请以 `pwsh` 执行；Docker Desktop 需要先启动。脚本会将 CLI 所在目录加入本次进程 `PATH`，以便同时找到凭证助手。

```powershell
pwsh -ExecutionPolicy Bypass -File scripts/container_delivery.ps1 `
  -ExportArchive outputs/phase2/ite-image.tar
```

该脚本会拉取 Python 基础镜像并解析固定 RepoDigest，先构建并断网运行测试阶段，再构建运行镜像；运行时使用 4 CPU / 4 GiB、断网和挂载输出目录。指定 `-ExportArchive` 后会导出/导入镜像，核对镜像 ID、归档 SHA-256 和检查点预测一致性，并写入 `outputs/phase2/container-receipt.json`。本轮已完成验收，镜像 ID 为 `sha256:3b8ad414c30bc36a642062b8b40bcfee3ab4b5b637e77035dea8dc73dd8d1bbc`，归档 SHA-256 为 `e4f040c40d3d9cbc92a0cdb587860b24810348091a66b06a142c52e5f0e8d0ab`。正式提交的挂载路径、入口、资源配额和输出协议均以官方 SDK 为准。

在该镜像中复现冻结矩阵和压力测试，须指定新的输出目录；五组主配置共 540 次、四组压力条件共 40 次：

```powershell
pwsh -File scripts/run-phase2-validation.ps1 -Image ite-local:verification `
  -Output outputs/my-container-validation
```

脚本显式调用 `ite matrix` 和 `ite assess`。验收未通过时保留 `legacy` 并给出警告；运行或评估发生错误时抛出失败，不将执行异常当成策略拒绝。配置和独立种子已冻结，复现用于核对同一配置；后续策略开发继续使用开发种子，新的最终验收需另留未参与调参的数据。

2026-11-04 交付包为 `outputs/ite-delivery-20261104.zip`，外部校验文件为同名 `.zip.sha256`；目录内另有每文件 `SHA256SUMS`。包内包括固定镜像 tar、源码提交 `692defc` 的 ZIP、两个阶段的验收 JSON、资源/部署/云端回执、42 项宿主机/容器测试日志及聚合 CSV。实验原始日志、预测和模型从 SwanLab 实验归档取得。加载镜像后按包内 `DELIVERY.md` 的断网命令运行；目标机器仍须安装可用的 Docker Linux 引擎。

## 新一轮本地优化

规划及验收边界见 `docs/local-optimization-plan.md` 和 `docs/optimization-freeze.md`。旧验收种子已用过；新候选仅在冻结后使用 211/223/227/229/233，开发继续使用 7/19/43。

```powershell
.\.venv\Scripts\python.exe scripts/run-local-optimization.py --stage development --output outputs/my-development
.\.venv\Scripts\python.exe scripts/run-local-optimization.py --stage acceptance --variant adaptive --output outputs/my-acceptance
.\.venv\Scripts\python.exe scripts/run-local-optimization.py --stage stress --variant adaptive --output outputs/my-stress
.\.venv\Scripts\python.exe scripts/run-robustness.py --config configs/optimization-candidate.json --output outputs/my-robustness
```

容器内执行同一脚本时，将脚本目录只读挂载至 `/scripts`、新输出目录挂载至 `/results`，明确 `--network none --cpus 4 --memory 4g`；镜像的默认 CMD 是演示程序，运行脚本须显式写 `python /scripts/run-local-optimization.py ...`。镜像来源必须与运行记录中嵌入的代码哈希一致。

新增配置：`label_schedule` 为 frontloaded/uniform/adaptive；后两者在末批能释放标签的时段内分配同一总预算，延迟不小于流长时不申请无用标签。`candidate_feasibility` 和 `candidate_max_wait_batches` 仅用于 future 模式。可行性使用公开协议容量上界，不保证调度一定及时收齐；超时可另行约束。

启动供给开发实验见 [预登记](startup-label-plan.md)。`label_startup_budget` 默认 0，非零值只允许 adaptive；当前已确认配置 `configs/optimization-startup-144.json` 固定 144，随后恢复原监测/退化脉冲调度。启动额度受总配额、每批上限、后段监测储备和可释放时段限制；它既不额外增加标签，也不改变 future 门控。与 `configs/optimization-candidate.json` 使用同一镜像、开发种子和预算配对，失败保留默认，不在同一轮继续调参。

该实验已完成 144 次开发运行，结论为未通过，见 [结果与四层诊断](startup-label-results.md) 和 NR-009。新镜像为 `ite-local:startup-144-20261104`、源码 `f73a5f5`；原始输出在 `outputs/startup-labels-20261104`，与旧 1,088 次运行分别归档。新交付目录 `outputs/ite-startup-labels-delivery-20261104` 保留镜像导出、源码 ZIP、回执及 SHA-256；78 项宿主机/容器测试和逐批预测恢复已验证。候选仅保留为实验配置，不代替默认；下一轮训练时效方案已另获用户确认。

训练时效开发实验按 [新预登记](training-freshness-plan.md) 执行。`train_source_window_batches=0` 保留原行为；本轮仅使用 `configs/optimization-training-freshness-8.json` 的固定 8 批来源上限，与启动 0 对照。先原时间切分，再过滤训练，不改筛选验证；不足 16 个训练标签沿用原跳过路径与预算记账。事件记录过滤前后样本数、来源最小/最大值、来源下限及验证量。两组各 72 次，镜像 `ite-local:training-freshness-8-20261104`，新输出 `outputs/training-freshness-20261104`；导出重载、断网 4 CPU/4 GiB、开发门槛及 NR-010 失败归档规则见预登记，不扩大到独立验收。

已完成的 [训练可行性预检](training-preflight-plan.md) 使用 `configs/optimization-training-preflight.json`，相对固定 8 批对照只增加 `training_preflight: true`。该参数只接受布尔值且默认 `false`；启用后按原来源过滤和时间切分预检，训练不足 16 或验证不足原门槛时记录 `training_preflight_skipped`，不增加 `experiments`/`training_attempts`，不修改 `last_experiment`/`cooldown_until`，继续预测。未变化证据不会重复记录；同一最新来源的新释放标签也允许重新预检。已实际训练后的预算耗尽、冷却、候选冻结及独立未来门控仍按原规则执行。

预检事件保留来源切分、样本量、释放修订号及真实资源状态；`summary.json` 增加 `training_preflight`、`training_preflight_skips`、`training_attempts`、`last_experiment`、`cooldown_until`。`training_attempts` 是已启动训练实验数，不是候选拟合数，历史复用只计入 `experiments`；开关关闭时历史样本不足的训练实验仍按原记账计入。有效冷却最早批次为 `max(0, last_experiment + cooldown + 1)`，并不豁免新标签、触发或剩余额度条件。Task 1 红/绿测试记录在 `outputs/training-preflight-20261104/records/task-1-20261104-implementation`。

预检开发结果见 [完整报告](training-preflight-results.md)：144 次配对、宿主/断网 Linux 各 94/94，通过 295 次不消耗预检和 13,824 批预测恢复审计；四项历史门槛失败，先归档 NR-011，默认不变。7 次变化运行提前 3 批上线，训练样本由 85–86 减至 27–28，后期精度变差。原始输出 `outputs/training-preflight-20261104`，镜像 `ite-local:training-preflight-20261104`、干净源码 `2b6bb4e`；新 [交付包](../outputs/ite-training-preflight-delivery-20261104.zip) 的 `DELIVERY.md` 给出新空目录断网复现和逐文件校验命令。验证与外部包校验在 `docs/validation/2026-11-04-training-preflight*.json`。生成结果文档不改变冻结源码，不因文档变化重跑效果矩阵。

已确认的 [指数时间衰减开发计划](time-decay-plan.md) 以原 `configs/optimization-training-preflight.json` 为对照，新候选 `configs/optimization-time-decay.json` 仅将固定 8 批训练来源硬截断改为有界历史指数权重：`training_weighting="exponential"`、`train_source_window_batches=0`、`training_half_life_batches=4.0`，仍启用预检并使用原 192/384/768 样本候选。权重按最新已释放来源批次而非当前处理时钟衰减，只在时间切分后的训练候选内部归一化为均值 1；实现减去每个候选的最大对数权重，等价消去公共参考以避免旧来源下溢。历史仍受最大 768 标签窗口约束，不回灌初始训练标签。

`training_weighting` 默认 `"none"`，只接受 `"none"`/`"exponential"`；半衰期只接受有限正数且拒绝 bool，指数模式与正硬来源窗口不能同时开启。`RidgeModel.fit(..., sample_weight=None)` 和 `BoundedTrainer.fit(..., sample_weight=None)` 保持旧调用兼容，校验权重为匹配的非负有限一维向量且总和为正，允许个别零权重，内部统一均值 1；同权走旧数值路径。加权涵盖特征均值、总体方差、目标均值/不惩罚截距、quadratic 基函数中心化和 sqrt(w) 行缩放后的岭求解；初始模型、候选筛选和未来上线门控沿用无权重错误率/NMSE。

`experiment_started` 的权重审计描述完整可用训练集，`candidate_evaluated` 描述实际候选切片，保留 `train_samples`、`train_min_step`/`train_max_step`、`window`（候选事件）、`training_weighting`、`training_half_life_batches`、`weight_reference_source_step`、`weight_min`/`weight_max`/`weight_sum`、`effective_sample_size`；未加权时权重为 1，半衰期和参考字段为 null。ESS 始终仅审计，不能改变 16 个原始标签下限、预检、冷却、资源预算、选择或门控。`summary.json` 的 `training_ess_audit_count` 与 `training_ess_min`/`training_ess_mean`/`training_ess_max` 聚合每次实际候选拟合（包括失败或超时的尝试）；没有拟合时计数为 0、三个统计量为 null。新增模式和半衰期也写入配置与摘要。

本轮已完成：新增 20 项 TDD，宿主及断网 Linux 各 114/114；同一导出重载镜像按 4 CPU/4 GiB/断网顺序完成 72+72=144 次开发运行。原始 RED/GREEN、退出码、cgroup 峰值、预测/门控/来源审计在 `outputs/time-decay-20261104/records`。训练轮数 54→93，样本不足预检跳过 295→0；但渐变回归 NMSE .543433→.719121，四项原历史门槛失败，已先归档 NR-012 再完成四层诊断，默认不晋级。详见 [结果](time-decay-results.md)、[验证 JSON](validation/2026-11-04-time-decay.json) 与 [交付校验](validation/2026-11-04-time-decay-delivery.json)。镜像源码冻结为 `b47c30b`，最终诊断文档单独提交；复现必须使用交付包 `DELIVERY.md` 中的新空输出目录命令，不覆盖原始结果。未运行新的独立验收，不追加动态窗口、半衰期搜索、训练下限或其他门槛。

Windows 终端上传 SwanLab 若报 GBK 无法编码 SDK 图标，可仅在该终端进程设置 `$env:PYTHONUTF8='1'`、`$env:PYTHONIOENCODING='utf-8'` 后使用原上传命令；不要将凭证写入仓库。保留首次失败日志，重试归档回执与实验运行数分开核验。

时间衰减本轮已上传到 SwanLab [wrool8bf](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/wrool8bf)：2026-11-05 切换手动审批后成功，SDK 短暂502自动恢复。`outputs/time-decay-20261104/swanlab-audit.zip` 的144次运行、1,507文件逐一核验，实际上传 ZIP SHA-256 为 `03759d5dddb66e7da4b37093cda4f845d9476309c75899182aa5a55fb94d1d19`；详见 `cloud-upload.json` 和 `records/archive-verification-uploaded.json`。此前自动审批失败及旧准备包保留。以下是已有上传命令，仅在确需重新上传时使用；命令重新打包会改变时间元数据和ZIP哈希，必须保存新的回执，不能沿用旧包哈希。

```powershell
$env:PYTHONUTF8='1'
$env:PYTHONIOENCODING='utf-8'
.\.venv\Scripts\python.exe -X utf8 -m ite upload-swanlab --run-dir outputs/time-decay-20261104 --project Intelligent_Training_Engine --workspace mring-Y --archive
```

源码实现已在本地提交为 `b47c30b`；原定6份结果文档已成功提交为 `c12a2a4`，此前两次自动审批拒绝记录保留在 `records/git-commit-blocked.json`，成功回执为 `records/git-results-commit.json`。手动审批恢复说明和新交付校验另作本地文档提交，最新提交可用下列命令查看。冻结镜像仍对应 `b47c30b`，没有因文档变化重训或重建。

```powershell
git log -3 --oneline
```

此前固定 8 批实验已完成，见 [结果与诊断](training-freshness-results.md)：144 次开发运行，宿主机/断网 Linux 各 83 项测试通过；四项门槛失败，已归档 NR-010、保留默认。来源为干净源码 `d88fd71`，镜像 ID `sha256:26c707d5c22d727e84b88bb9d1c4defa34ad5c13217a714738e80e0b80de813b`；[历史交付 ZIP](../outputs/ite-training-freshness-delivery-20261104.zip) 内的 `DELIVERY.md` 和 `SHA256SUMS` 给出逐文件验证与新目录断网复现命令。原始归档也附包内，不依赖云端下载；SwanLab [yhpzfjkd](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/yhpzfjkd) 已记录该轮结果。完整验证及外部 ZIP 校验在 `docs/validation/2026-11-04-training-freshness*.json`。该历史轮次的 60 次样本不足跳过仍沿用旧预算/冷却规则；随后另获确认的可行性预检已完成，见上方 NR-011。

云端回执为 [x32h105t](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/x32h105t)，本机交付 ZIP 为 `outputs/ite-startup-labels-delivery-20261104.zip`，对应外部 `.zip.sha256`、包内 `SHA256SUMS` 及 `docs/validation/2026-11-04-startup-labels-delivery.json`。按包内 `DELIVERY.md` 先校验、加载镜像，再使用新空目录断网复现；原始预测和日志也随 `experiments-audit.zip` 附在包内，不依赖云端下载。

`relationship=nonlinear`、`class_threshold=1.25`、`outlier_fraction=.05`、`drift_magnitude=.5` 和 `scenario=mixed` 用于模拟因素研究。`model_family=quadratic` 启用二次基函数岭回归；原始特征的缩放量保留供监测使用，初始训练及子进程候选均遵循同一模型配置。旧模型文件仍可加载，损坏或非有限系数会明确报错。

`decision_backend=mock` 配合 `max_tokens` 验证候选建议接口；默认 rules、Token 上限 0。建议必须在允许的窗口和 alpha 内；格式或服务错误回退规则，未知用量保守计入本次预留额度。mock 没有真实模型调用，也不代表 PyTRiO 接通；将来外部适配器必须自行实现调用超时及真实 Token 限额。

在线预测索引仅保留已申请且未释放的样本，已释放即删除；训练历史受最大窗口约束。离线模拟器和预测归档仍按流长度占用空间，这轮没有实现整个仿真进程的常量内存，也没有实现训练流中途崩溃的完整续跑。检查点恢复指预测模型保存/加载；正式 SDK 明确状态协议后再设计完整流恢复。

本轮结果位于 `outputs/local-optimization-20261104`，已完成 1,088 次运行。可运行 `python scripts/analyze-local-optimization.py --root outputs/local-optimization-20261104` 重新审计该完整目录，生成配对结果与修正后的开发诊断；不会重跑或修改策略。结果见 `docs/local-optimization-results.md`。新镜像为 `ite-local:optimization-validated`，源码 `c58f2ae`；从交付包加载后可直接断网复现，包内 `DELIVERY.md` 和 `SHA256SUMS` 给出步骤和每文件校验值。SwanLab 归档有 1,088 次策略运行、12,410 个原始文件，已逐文件核验；SDK 对象数与 ZIP 内文件数分别计数。

## 近期标签互斥分配实验（2026-11-05）

已确认范围见 [预登记](recent-disjoint-plan.md)。`selection_split` 默认 `chronological` 保持原严格时间切分；`recent_disjoint` 仅允许 future 独立门控，在最近至多96条已释放标签中确定性留出48条筛选、其余训练，最新标签留给训练。这里放宽的是训练/筛选的来源先后顺序，标签实体仍互斥；每轮可重新分配历史角色。最终门控仍要求候选冻结后产生并随后释放的至少32条标签，不能借用筛选或训练标签。

对照 `configs/optimization-time-decay.json`；候选 `configs/optimization-recent-disjoint.json` 只增加分配模式。保持 h4、训练16、筛选目标48、预算、调度和冷却，ESS仅审计。用全新 `outputs/recent-disjoint-20261105` 保存两组各72次结果，旧实验不得覆写。完整144次保留常规/突变/渐变等场景防退化证据，重点分析渐变首次实际新版本预测起的3批；不能使用 curve.csv 的观察后版本代替 prediction 事件，也不能把不同上线时间的窗口当作相同样本。

本轮使用 `scripts/analyze_recent_disjoint.py` 做标签实体级审计。旧 `scripts/container_check.py` 及 `scripts/analyze-local-optimization.py` 针对历史严格时间切分，不能用于判定新模式的训练/筛选互斥性。新脚本在同一Linux镜像中读取已完成产物，不重新训练，并逐批核对真实prediction版本、检查点、资源、未来门控和分配索引。

144次已经完成，宿主/断网Linux各152/152；[结果](recent-disjoint-results.md) 与 [逐种子曲线](../outputs/recent-disjoint-20261105/report.html) 保留共同样本和各自上线窗口。历史4项门槛失败，先归档NR-013，默认chronological保持。原目录不可重跑覆盖；另获确认的复现应使用新的空挂载目录：

```powershell
docker load -i outputs/recent-disjoint-20261105/delivery/ite-recent-disjoint-20261105.tar
docker run --network none --cpus 4 --memory 4g --mount "type=bind,source=绝对路径的新空目录,target=/results" ite-local:recent-disjoint-20261105 ite matrix --config /app/configs/optimization-recent-disjoint.json --output /results/recent-disjoint --tasks classification regression --scenarios stable abrupt gradual recurring covariate noise --seeds 7 19 43 --batches 96 --policies static drift
```

对照替换为 `/app/configs/optimization-time-decay.json`、输出 `/results/control`。本轮审计脚本在冻结源码ZIP的scripts目录，runtime镜像不含scripts；解压后只读挂载该目录到 `/audit`，以 `python /audit/analyze_recent_disjoint.py --root /results --legacy /legacy/summary.csv --historical-control /history` 运行，另只读挂载对应历史输入。审计输出独占新建，不能原目录重复生成。原始预测/模型不依赖SwanLab下载即可核查，云端完成状态和交付校验见结果文档及验证JSON。

## 任务级互斥切分实验（2026-11-05）

本轮候选使用 `configs/optimization-task-specific-split.json`，与控制 `configs/optimization-task-specific-control.json` 比较。分类非周期场景在最近48条标签中互斥划分24条训练和24条筛选，其余历史只进入训练；非周期回归保留最近96条中的48条筛选；周期两任务均按整批来源时间切分。控制保持上一轮全局 recent-disjoint 规则。h=4、训练下限16、future独立上线门控32、预算和调度不变，完整规则及晋级标准见 [预登记](task-specific-split-plan.md)。

宿主162项测试通过，冻结Linux测试镜像已断网复核162/162，144次矩阵完成并做只读审计，见 [结果](task-specific-split-results.md) 与 [曲线](../outputs/task-specific-split-20261105/report.html)。周期两任务均值改善，分类突变退化；历史四项门槛失败，已归档NR-014，默认保持。矩阵cgroup峰值和完整生命周期回执缺测，不从演示或旧轮借用。

离线审计器使用 `--control-arm control --candidate-arm task-specific --control-selection-split recent_disjoint --candidate-selection-split task_specific`，历史control应指向上一轮 `recent-disjoint` 组，而非上一轮同名 `control`。它逐次重建路由、池宽、实体互斥、future门控和检查点预测；拒绝覆写已存在的审计文件。现有目录仅供读取，不能重跑覆盖。另获本轮确认的复现须使用新空目录和固定镜像：

```powershell
docker load -i outputs/task-specific-split-20261105/delivery/ite-task-specific-split-20261105.tar
docker run --network none --cpus 4 --memory 4g --mount "type=bind,source=绝对路径的新空目录,target=/results" ite-local:task-specific-split-20261105 ite matrix --config /app/configs/optimization-task-specific-split.json --output /results/task-specific --tasks classification regression --scenarios stable abrupt gradual recurring covariate noise --seeds 7 19 43 --batches 96 --policies static drift
```

对照只将 `--config` 改为 `/app/configs/optimization-task-specific-control.json` 并使用独立空输出子目录。上述为复现手册，本轮收尾不再运行效果矩阵；新的代码、参数或实验仍须先诊断并经用户本轮明确确认。

本轮SwanLab归档 [f44h8phy](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/f44h8phy) 包含144次运行，实际上传的本地ZIP逐文件核验通过。最终交付为 `outputs/ite-task-specific-delivery-20261107.zip`，解包后按 `SHA256SUMS` 校验，再导入包内镜像；源码冻结提交afaf121与收尾文档版本分开记录。包外验收回执 `docs/validation/2026-11-07-task-specific-delivery.json` 保存最终ZIP校验值，矩阵峰值内存和生命周期回执明确缺测，不补造数据。

## 分类精确平局alpha优先（2026-11-07）

可选 `classification_tie_break=alpha_desc` 仅改变分类同错误整数时的决胜，固定键为 `(errors, -alpha, window)`；回归MSE精确/近似平局保持原严格比较。默认 `legacy` 不变。控制/候选分别为 `configs/optimization-classification-tie-control.json` 与 `configs/optimization-classification-tie-alpha.json`，只差该字段。现有标签分配保持，不新增按abrupt/gradual路由，也不实施检测前硬过滤。

宿主/断网Linux各175/175，144次已完成。分类突变均值略退化，seed19仍在future门控5/48对5/48而拒绝；四项历史门槛失败，NR-015保留。见[结果](classification-tie-results.md)、[曲线](../outputs/classification-tie-alpha-20261107/report.html)、[机器回执](validation/2026-11-07-classification-tie.json)。已有原始目录不得重跑覆盖。

离线审计在原参数外使用 `--control-arm control --candidate-arm alpha --control-selection-split task_specific --candidate-selection-split task_specific --paired-factor classification_tie_break`，历史control指向上一轮task-specific组。它逐次重建整数错误、精确平局、legacy/最终赢家及未来门控；输出独占新建。`candidate_selection` 中best_tied_candidates为最终最低错数并列数量，equal_error_comparisons是搜索过程中遇到当时最优同分次数，不能混用。

镜像 `ite-local:classification-tie-alpha-20261107` 来自Git提交4b4890b快照，导出tar在本轮delivery目录，重载ID与断网检查点预测一致。两组矩阵均4CPU/4GiB/断网、退出0无OOM，cgroup峰值和完整inspect回执已保存；不以单次缓存峰值差推断算法节省资源。复现必须另获本轮确认并使用新空目录，新的策略仍需先诊断和TDD。

本轮SwanLab [7s5w0kuz](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/7s5w0kuz) 已归档，实际上传ZIP逐字节核验，未独立下载服务器副本。交付包 `outputs/ite-classification-tie-delivery-20261107.zip` 解包后按SHA256SUMS校验，镜像tar与源码ZIP位于其中的本轮输出目录。最终ZIP哈希见[交付回执](validation/2026-11-07-classification-tie-delivery.json)。

## 待官方条件

官方数据、评测脚本、SDK、标注规则、评分公式、《实验记录规范》和 PyTRiO 接入仍未获得。当前没有可验证的获准大模型驱动器，`tokens=0` 表示没有调用大模型。规则归因仅描述观测证据，不声称识别了真正的工业因果关系。策略窗口自适应属于可关闭的实验选项，不能视为已证实的比赛优势。
