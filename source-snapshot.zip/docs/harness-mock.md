# Mock Harness 接口与运行

2026-11-07。实现范围依据用户确认及 [本轮计划](harness-mock-plan.md)：验证受限决策、预算熔断及独立未来门控，不做效果晋级或真实大模型收益评估。

## 开启与异常注入

`configs/harness-mock.json` 是独立演示配置，原默认不变。运行示例（每次使用新的输出目录）：

```powershell
.\.venv\Scripts\python.exe -m ite run --config configs/harness-mock.json --output outputs/my-harness-demo
```

此命令仍比较static/periodic/drift三策略；只有drift启用Harness，其他两者保留原策略作为对照。核心协议验证仅需两任务的stable/abrupt/gradual、seed7、36批，不运行大矩阵。

配置 `harness_mock_mode` 的可选值：`normal`、`invalid_json`、`token_exhausted`。后两者分别产生错误JSON与客户端额度耗尽异常，Guard保守记账后熔断。使用配置开关而非环境变量，保证每次配置文件可复核。`harness_enabled` 默认false，开启时要求：

- `deployment_validation="future"`、`training_preflight=true`、`candidate_feasibility=true`。
- `decision_backend="rules"`，禁用实验内部的旧Mock建议调用，避免双重决策和计费。
- 不启用窗口策略自适应，不使用读取模拟场景名称的`task_specific`分路。
- 演示的`max_tokens=1000`；0或不足以安全预留一次调用时按熔断处理。

## 数据契约

`ite/harness.py` 发布 `OBSERVATION_SCHEMA` / `ACTION_SCHEMA`，均为JSON Schema 2020-12，禁止额外字段。运行验证使用标准库，无新增依赖。

Observation恰好包含：

```json
{
  "loss_trend": [{"source_step": 10, "loss": 0.25, "labeled_samples": 12}],
  "drift_alarm": true,
  "remaining_label_budget": 720,
  "remaining_token_budget": 960,
  "model_age_batches": 15
}
```

趋势最多5个来源批次，来源严格递增，只用当前部署模型当时保存的预测及已申请、按时释放的标签；同来源的分次释放按样本数累计。分类为错误率（0至1），回归沿用初始验证方差归一化的MSE。没有证据用空数组，不补0。新模型部署后清空趋势，旧模型的延迟标签不会诊断新模型。模型年龄只随流预测递增，初始第一批为1，部署时重置0，筛选预测不计年龄。

报警取现有监测器`performance_drop`，不读取场景、漂移真值或离线评分。剩余预算来自账本，标签在申请时计费。

Action恰好包含`action`和`reason`。动作白名单：

| 动作 | 权限 |
| --- | --- |
| DO_NOTHING | 不启动训练，不改变训练冷却 |
| RETRAIN_SMALL | 最小配置窗口及所有配置alpha |
| RETRAIN_LARGE | 所有配置窗口及所有配置alpha |
| ROLLBACK | 仅筛选上一部署快照，合格后冻结，再等待未来门控 |

`reason`仅供审计：非空白、单行、最多160字符、可编码为UTF-8，不执行其内容。响应最多4096字节；拒绝重复键、额外字段、非法动作、代码围栏、尾随文本、非有限常量和非法Unicode。动作不能携带任意参数、路径或代码。训练/门控仍可拒绝合法动作，不自行换成另一动作。

`BaseLLMClient.get_decision(observation)`返回`LLMReply(raw_json, usage_tokens, token_accounting_mode)`；用量是适配器元数据，与模型动作内容分离。`MockLLMClient`收到报警返回SMALL，否则DO_NOTHING；不访问网络，不调用训练。将来真实适配器需另行设计真实用量及可取消的调用时限，本轮只处理Mock和已经返回/抛出的客户端结果，不宣称保护任意阻塞的真实服务。

## Guard与状态机

Runner申请标签之前和计费之后调用Controller共享的Guard；Controller观察、验收、冻结和启动实验入口同样受Guard保护。只有新释放证据、样本门槛、冷却且没有pending时才可询问客户端；相同证据不重复调用。正常DO_NOTHING不会推进训练冷却。

Guard使用整数比较判断`已用Token*5 >= 总Token*4`，含等号。每次Mock调用预留8个模拟单位；预留也会触及80%时不调用、不计费并熔断。正常响应按可信模拟元数据结算（不超过预留）；错误响应、用量错误或客户端异常保守计满8，无重试。Token与标签任一为0时可安全熔断，无除零。

`ACTIVE -> STATIC_FALLBACK`不可在本次运行自动恢复。触发条件为Token红线/预留红线、标签剩余0、非法观测或响应、客户端额度耗尽/异常/已抛出超时、无效用量。进入后冻结当前部署模型，停止新标签、LLM调用、训练、验收和所有模型切换；pending立即拒绝。在途标签仍释放并结算，最终评分可使用它们，绝不触发部署。当前批已经完成的预测不重写。

旧模式允许预算耗尽后用在途标签验收的行为保持；新模式的硬熔断明确优先。训练时间和实验次数仍受原ResourceBudget/BoundedTrainer约束，不因LLM动作放宽。系统仍为轻量Ridge，无GP或新模型族。

## 审计和成本口径

新增事件包括`harness_observation`、`harness_call`、`harness_decision`、`harness_action_rejected`、`budget_guard_tripped`、`harness_static_fallback`。后者记录冻结的实际模型版本。候选继续使用原`candidate_frozen`/`deploy`/`experiment_rejected`事件，deploy(k)从k+1预测生效。

summary/报告分列`mock_tokens`、`real_llm_tokens=0`、`token_accounting_mode="mock"`、`llm_calls`、`llm_seconds`、熔断状态/时钟/原因。既有`tokens`在Harness模式等于模拟用量，不能当作真实账单、tokenizer结果或官方分数。训练墙钟与预测耗时继续单列。

完整测试入口：`python -m unittest discover -s tests -v`。新增测试覆盖契约、Mock异常、80%边界、失败记账、模型年龄、pending取消、动作白名单、回滚未来门控、门控拒绝、Runner停止申请及两任务三场景真实工作进程。测试通过仅证明本轮协议范围，真实服务、官方SDK、长流资源与完整状态续跑仍未验收。
