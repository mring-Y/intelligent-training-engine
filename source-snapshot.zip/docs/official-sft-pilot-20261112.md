# 官方MLP锚定SFT试点：2026-11-12

**当前测试流为公开验证集的时序模拟，不代表官方隐藏测试集的真实表现。**

本轮完成数据生成器、官方MLP实际resume、九场景离线预检及真实27B Teacher小批。最终生成27条可审计的真实决策记录，全部位于review；合格train/eval均为0。没有复制样本凑数，没有执行4B LoRA训练，没有改变生产默认模型或门控。

## 数据、模型与隔离

输入来自固定官方CPU A/B/C包的验证集，128/34/24维、4326/865/833参数。A使用六类Macro-F1与Accuracy，B使用分钟RMSE/MAE，C使用循环RMSE及寿命高估。官方原始标签不截断、不换单位；偏移仅作用于特征，明确属于模拟协变量漂移。

固定12批、标签延迟1批、step3起偏移0.75倍初始checkpoint标准差，渐变宽4批。A按75%时间边界隔离并purge64行；B隔离Bearing1_4；C每五个排序发动机隔离一个。先分原始来源，再生成三种变体；衍生变体始终留在同一分区。train/eval分别从官方初始checkpoint开始，候选从当前部署checkpoint继续Adam与标准化状态。

主环境NumPy2.3.5未降级；工业模型沿用隔离NumPy1.26.4。真实Teacher在新建`.venv-sft`进程运行，system-site-packages=false，49个发行包按`requirements-sft.lock`固定版本，9062个复制文件逐SHA-256核对，pip check通过。未创建训练actor。

## 工程验证与离线结果

宿主完整514/514通过，228.204秒；固定镜像的4CPU/8GiB/--network none完整514项中513通过、1项宿主专用环境测试跳过，83.610秒。容器退出0、OOMKilled=false；内存峰值未测。镜像从完整ID已核验的本地基础构建，无网络安装或拉取依赖。

离线九场景分train/eval共18分区完成。23次实际resume、11次部署，最高分区累计训练0.591652秒，无worker错误或超时。配对主指标4分区改善、6分区退化、8持平。每条Mock记录均进入待审核范围，不能成为真实Teacher标签。详见NR-025及`records/offline-results-audit.json`。

## 真实27B调用

模型`Qwen/Qwen3.8-27B`。核验官方`https://pytrio.cn/api/model-prices`得到Prefill ¥3.15/M、Sample ¥25.29/M；用户提供的余额截图为现金¥49.99。接口余额GET返回401，浏览器访问被拒后未再使用；用户另明确授权将已揭晓Observation发到PyTRiO及最多¥0.50付费。

27/27次均成功解析单个JSON；输入15858、输出1045，共16903服务端Token。端到端7.596737–8.869293秒，均值7.998473秒；无超时、重试、未知用量。实际本地输入526–652 Token，服务端输入亦未超过1250，输出未超过128。19次DO_NOTHING、3次RETRAIN_SMALL、5次RETRAIN_LARGE。

费用按上述费率和服务端Token计算为**¥0.07638075估算**，不是服务商扣费回执。价格JSON带rounding=ceil但未说明粒度：整批取整为¥0.08，逐请求取整为¥0.27，逐请求输入/输出分别取整为¥0.54。运行中补充的24次提前停止未生效：监视进程遇到原子账本读取PermissionError，补写熔断时27次已经完成。原30次限制未超过；随后用户直接反馈界面两位小数账目约¥0.07，支持本轮未超过¥0.50；这是用户提供的界面账目，不是精确扣款回执，也不支持此前逐输入/输出取整到分的保守假设。24次补充停止失败仍如实保留。试点claim保持占用，完成后的账本已锁止，不会重跑。

## 同流静态与真实Teacher对照

下表均为相同ID、相同特征变换的配对结果。A为Macro-F1（越大越好）；B为分钟RMSE、C为循环RMSE（越小越好）。不能拿这些子分区/偏移结果直接与完整官方验证集参考值相减。

| 包/场景 | train静态→Teacher Harness | eval静态→Teacher Harness |
| --- | --- | --- |
| A stable | 0.730866→0.730866 | 0.166067→0.166067 |
| A abrupt | 0.643369→0.643369 | 0.085993→0.085993 |
| A gradual | 0.646388→0.646388 | 0.085993→0.085993 |
| B stable | 704.092356→704.092356 | 241.980799→241.980799 |
| B abrupt | 774.656867→774.656867 | 242.205220→242.205220 |
| B gradual | 702.301049→702.301049 | 274.191985→274.191985 |
| C stable | 53.502742→53.502742 | 50.350199→50.350199 |
| C abrupt | 128.372756→125.309991 | 124.423732→124.423732 |
| C gradual | 124.304549→121.138971 | 120.535091→120.535091 |

A六次候选中四次筛选失败、两次未来门控拒绝，最终预测与静态逐值相同。B全部DO_NOTHING，没有候选或部署；Loss下降不能证明静态模型“仍在学习”。C stable无更新，abrupt/gradual train各一次大窗口候选在step7冻结、source8标签于step9验收，step10起上线；每次训练最多720行、另留48行筛选。

C abrupt：RMSE128.372756→125.309991，但全流高估率16.519126%→18.071038%，平均高估6.085502→6.498474周期。C gradual：RMSE124.304549→121.138971，但高估率16.830601%→18.382514%，平均高估6.117819→6.530791周期。两者部署后同一3050条样本RMSE141.784006→124.261340，高估率0→9.311475%，因此未通过SFT安全筛选。该离线评分不追溯改变已经发生的部署，生产门控本身未改。

## 为什么没有可训练标签

| 审核结果 | 记录数 |
| --- | ---: |
| 筛选不优 | 4 |
| 独立未来门控拒绝 | 2 |
| C寿命高估安全项退化 | 2 |
| DO_NOTHING缺少动作最优性的反事实证据 | 19 |
| 合格train / eval | 0 / 0 |

原始Reason不改写。第11/14次将静态Loss下降解释为仍在学习，与实际无训练矛盾；第26次“持续恶化”过度概括，最后已揭晓Loss从3.1643降到2.7458。其他解释同样不能只凭表达通顺就当正确。`reason_audit`单独保留审阅意见与原文SHA-256；没有为任何记录发放合格审计。

`teacher/dataset/train.jsonl`和`eval.jsonl`为空，`review.jsonl`含27条原始决策。未来评分、来源和候选证据仅是审计元数据；模型输入只有messages，Teacher实际请求没有未来标签、原始行数据或账户信息。后续若要训练，必须另获方案确认且先有通过官方MLP目标与安全项的足量证据，本轮不晋级。

## 来源、限制与产物

固定源码`a7690435cf77bad05e6c5202d998f08e03cea39d`，core SHA-256 `b513b63534ea5e6d362cd3e5d1abec26793a8b173093f7862b125ad7ba75c72c`，runner SHA-256 `266b4c7ea7293ffd96e54b1d7a929f9d1b45129d0d57da31c7757f013d1a0316`。真实运行的Git字段为unavailable/null（提权进程safe-directory元数据限制），原值保留；精确core与已提交冻结源码/离线回执一致。

验证镜像`ite-official-sft:20261112`，manifest `sha256:f50a9ed1cdd3536effd4438aa8d9996572506e4b9e6740efc1cbfba0a7a6bfe0`，固定基础完整ID `sha256:76476d088433a4bb20a00d6eed16b136062ffe670a8d7541b727ce6ef8eb5228`。真实Teacher在允许联网的宿主隔离worker执行；九场景工程回放在断网容器执行，两者范围明确区分。

本地原始产物位于`outputs/official-sft-20261112/`：`container-output/offline-v1/`为九场景；`teacher/session/teacher-events.jsonl`为真实消息/原JSON/Token/延迟；`teacher/session/call-ledger.json`为持久账本；`teacher/teacher-decisions/`为MLP预测/检查点/门控；`teacher/dataset/`为导出；`records/teacher-results-audit.json`为后处理审计。

历史SwanLab里程碑已单独归档并确认FINISHED：<https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/ljc6re1q>。该历史归档不含本轮新Teacher产物；本轮保存于本地Git文档及不可覆写输出。阴性结果分别NR-025/026。

## 27次真实决策原文

以下reason是模型公开返回的审计理由，不是隐藏思维链。所有Observation都在对应调用时由实际MLP及已释放标签计算。

### 请求1：A / stable / train / step3

Action：`RETRAIN_SMALL`。服务端Token：543+54；端到端8.869293秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 0,
      "loss": 0.0,
      "labeled_samples": 76
    },
    {
      "source_step": 1,
      "loss": 0.06666666666666667,
      "labeled_samples": 75
    },
    {
      "source_step": 2,
      "loss": 0.16,
      "labeled_samples": 75
    }
  ],
  "drift_alarm": true,
  "remaining_label_budget": null,
  "remaining_token_budget": 60000,
  "model_age_batches": 4
}
```

原始模型JSON：

```json
{"action":"RETRAIN_SMALL","reason":"漂移告警且Loss从0升至0.16，模型仅4批，用最近192条小窗口续训以快速纠正近期分布偏移，避免大窗口混入旧数据。"}
```

### 请求2：A / stable / train / step7

Action：`RETRAIN_LARGE`。服务端Token：610+38；端到端7.859721秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 2,
      "loss": 0.16,
      "labeled_samples": 75
    },
    {
      "source_step": 3,
      "loss": 0.0,
      "labeled_samples": 75
    },
    {
      "source_step": 4,
      "loss": 0.013333333333333334,
      "labeled_samples": 75
    },
    {
      "source_step": 5,
      "loss": 0.06666666666666667,
      "labeled_samples": 75
    },
    {
      "source_step": 6,
      "loss": 0.28,
      "labeled_samples": 75
    }
  ],
  "drift_alarm": true,
  "remaining_label_budget": null,
  "remaining_token_budget": 59403,
  "model_age_batches": 8
}
```

原始模型JSON：

```json
{"action":"RETRAIN_LARGE","reason":"漂移告警且近期Loss波动大，剩余训练时间充足，采用大窗口续训以覆盖分布变化并稳定性能。"}
```

### 请求3：A / stable / eval / step3

Action：`DO_NOTHING`。服务端Token：526+40；端到端7.984543秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 0,
      "loss": 0.0,
      "labeled_samples": 24
    },
    {
      "source_step": 1,
      "loss": 0.0,
      "labeled_samples": 24
    },
    {
      "source_step": 2,
      "loss": 0.0,
      "labeled_samples": 24
    }
  ],
  "drift_alarm": true,
  "remaining_label_budget": null,
  "remaining_token_budget": 58755,
  "model_age_batches": 4
}
```

原始模型JSON：

```json
{"action":"DO_NOTHING","reason":"Loss连续为0且模型仅4批次，无性能退化证据，漂移告警可能为误报，续训风险大于收益。"}
```

### 请求4：A / abrupt / train / step3

Action：`RETRAIN_SMALL`。服务端Token：543+49；端到端8.306140秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 0,
      "loss": 0.0,
      "labeled_samples": 76
    },
    {
      "source_step": 1,
      "loss": 0.06666666666666667,
      "labeled_samples": 75
    },
    {
      "source_step": 2,
      "loss": 0.16,
      "labeled_samples": 75
    }
  ],
  "drift_alarm": true,
  "remaining_label_budget": null,
  "remaining_token_budget": 58189,
  "model_age_batches": 4
}
```

原始模型JSON：

```json
{"action":"RETRAIN_SMALL","reason":"漂移告警且Loss从0升至0.16，模型仅4批，用最近192条小窗口续训以快速适应新分布并保留Adam状态。"}
```

### 请求5：A / abrupt / train / step7

Action：`RETRAIN_LARGE`。服务端Token：610+41；端到端8.085874秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 2,
      "loss": 0.16,
      "labeled_samples": 75
    },
    {
      "source_step": 3,
      "loss": 0.0,
      "labeled_samples": 75
    },
    {
      "source_step": 4,
      "loss": 0.08,
      "labeled_samples": 75
    },
    {
      "source_step": 5,
      "loss": 0.14666666666666667,
      "labeled_samples": 75
    },
    {
      "source_step": 6,
      "loss": 0.29333333333333333,
      "labeled_samples": 75
    }
  ],
  "drift_alarm": true,
  "remaining_label_budget": null,
  "remaining_token_budget": 57597,
  "model_age_batches": 8
}
```

原始模型JSON：

```json
{"action":"RETRAIN_LARGE","reason":"漂移告警且Loss升至0.29，剩余训练时间充足，请求大窗口续训以覆盖近期分布变化并恢复性能。"}
```

### 请求6：A / abrupt / eval / step3

Action：`DO_NOTHING`。服务端Token：526+37；端到端7.900264秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 0,
      "loss": 0.0,
      "labeled_samples": 24
    },
    {
      "source_step": 1,
      "loss": 0.0,
      "labeled_samples": 24
    },
    {
      "source_step": 2,
      "loss": 0.0,
      "labeled_samples": 24
    }
  ],
  "drift_alarm": true,
  "remaining_label_budget": null,
  "remaining_token_budget": 56946,
  "model_age_batches": 4
}
```

原始模型JSON：

```json
{"action":"DO_NOTHING","reason":"Loss连续为0且模型仅4批次，特征距离1.18不足以证明漂移，证据不足不续训。"}
```

### 请求7：A / gradual / train / step3

Action：`RETRAIN_SMALL`。服务端Token：543+49；端到端8.266569秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 0,
      "loss": 0.0,
      "labeled_samples": 76
    },
    {
      "source_step": 1,
      "loss": 0.06666666666666667,
      "labeled_samples": 75
    },
    {
      "source_step": 2,
      "loss": 0.16,
      "labeled_samples": 75
    }
  ],
  "drift_alarm": true,
  "remaining_label_budget": null,
  "remaining_token_budget": 56383,
  "model_age_batches": 4
}
```

原始模型JSON：

```json
{"action":"RETRAIN_SMALL","reason":"漂移告警且Loss从0升至0.16，模型仅4批，用最近192条小窗口续训以快速适应新分布并保留Adam状态。"}
```

### 请求8：A / gradual / train / step7

Action：`RETRAIN_LARGE`。服务端Token：625+41；端到端7.902056秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 2,
      "loss": 0.16,
      "labeled_samples": 75
    },
    {
      "source_step": 3,
      "loss": 0.0,
      "labeled_samples": 75
    },
    {
      "source_step": 4,
      "loss": 0.05333333333333334,
      "labeled_samples": 75
    },
    {
      "source_step": 5,
      "loss": 0.09333333333333334,
      "labeled_samples": 75
    },
    {
      "source_step": 6,
      "loss": 0.29333333333333333,
      "labeled_samples": 75
    }
  ],
  "drift_alarm": true,
  "remaining_label_budget": null,
  "remaining_token_budget": 55791,
  "model_age_batches": 8
}
```

原始模型JSON：

```json
{"action":"RETRAIN_LARGE","reason":"漂移告警且近期Loss升至0.29，剩余训练时间充足，采用大窗口续训以覆盖分布变化并恢复性能。"}
```

### 请求9：A / gradual / eval / step3

Action：`DO_NOTHING`。服务端Token：526+40；端到端7.992649秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 0,
      "loss": 0.0,
      "labeled_samples": 24
    },
    {
      "source_step": 1,
      "loss": 0.0,
      "labeled_samples": 24
    },
    {
      "source_step": 2,
      "loss": 0.0,
      "labeled_samples": 24
    }
  ],
  "drift_alarm": true,
  "remaining_label_budget": null,
  "remaining_token_budget": 55125,
  "model_age_batches": 4
}
```

原始模型JSON：

```json
{"action":"DO_NOTHING","reason":"Loss连续为0且模型仅4批次，无性能退化证据，feature_distance不保证漂移，贸然续训可能破坏现有分布。"}
```

### 请求10：B / stable / train / step3

Action：`DO_NOTHING`。服务端Token：576+32；端到端7.788956秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 0,
      "loss": 1.9618308231317074,
      "labeled_samples": 130
    },
    {
      "source_step": 1,
      "loss": 2.1700654125195076,
      "labeled_samples": 130
    },
    {
      "source_step": 2,
      "loss": 1.5356603369161048,
      "labeled_samples": 130
    }
  ],
  "drift_alarm": false,
  "remaining_label_budget": null,
  "remaining_token_budget": 54559,
  "model_age_batches": 4
}
```

原始模型JSON：

```json
{"action":"DO_NOTHING","reason":"漂移未触发且模型仅4批次，Loss波动属正常初期，证据不足，保持现状。"}
```

### 请求11：B / stable / train / step7

Action：`DO_NOTHING`。服务端Token：644+33；端到端7.837320秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 2,
      "loss": 1.5356603369161048,
      "labeled_samples": 130
    },
    {
      "source_step": 3,
      "loss": 1.2737009860023443,
      "labeled_samples": 130
    },
    {
      "source_step": 4,
      "loss": 0.9121302285405375,
      "labeled_samples": 130
    },
    {
      "source_step": 5,
      "loss": 0.5940976764616407,
      "labeled_samples": 130
    },
    {
      "source_step": 6,
      "loss": 0.2958793560221138,
      "labeled_samples": 130
    }
  ],
  "drift_alarm": false,
  "remaining_label_budget": null,
  "remaining_token_budget": 53951,
  "model_age_batches": 8
}
```

原始模型JSON：

```json
{"action":"DO_NOTHING","reason":"漂移未触发且Loss持续下降，模型仍在有效学习，无需续训以免破坏当前收敛状态。"}
```

### 请求12：B / stable / eval / step3

Action：`DO_NOTHING`。服务端Token：574+38；端到端7.952211秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 0,
      "loss": 0.0757905904656309,
      "labeled_samples": 11
    },
    {
      "source_step": 1,
      "loss": 0.04101140004019857,
      "labeled_samples": 11
    },
    {
      "source_step": 2,
      "loss": 0.0542951194057977,
      "labeled_samples": 10
    }
  ],
  "drift_alarm": false,
  "remaining_label_budget": null,
  "remaining_token_budget": 53274,
  "model_age_batches": 4
}
```

原始模型JSON：

```json
{"action":"DO_NOTHING","reason":"漂移未触发且Loss趋势平稳，模型仅4批次，证据不足，保持现状避免小窗口续训破坏已有分布。"}
```

### 请求13：B / abrupt / train / step3

Action：`DO_NOTHING`。服务端Token：576+32；端到端7.674683秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 0,
      "loss": 1.9618308231317074,
      "labeled_samples": 130
    },
    {
      "source_step": 1,
      "loss": 2.1700654125195076,
      "labeled_samples": 130
    },
    {
      "source_step": 2,
      "loss": 1.5356603369161048,
      "labeled_samples": 130
    }
  ],
  "drift_alarm": false,
  "remaining_label_budget": null,
  "remaining_token_budget": 52662,
  "model_age_batches": 4
}
```

原始模型JSON：

```json
{"action":"DO_NOTHING","reason":"漂移未触发且模型仅4批次，Loss波动属正常初期，证据不足，保持现状。"}
```

### 请求14：B / abrupt / train / step7

Action：`DO_NOTHING`。服务端Token：643+40；端到端8.030758秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 2,
      "loss": 1.5356603369161048,
      "labeled_samples": 130
    },
    {
      "source_step": 3,
      "loss": 1.8713345811539448,
      "labeled_samples": 130
    },
    {
      "source_step": 4,
      "loss": 1.3985105655875638,
      "labeled_samples": 130
    },
    {
      "source_step": 5,
      "loss": 0.9583305863137078,
      "labeled_samples": 130
    },
    {
      "source_step": 6,
      "loss": 0.820016437073578,
      "labeled_samples": 130
    }
  ],
  "drift_alarm": false,
  "remaining_label_budget": null,
  "remaining_token_budget": 52054,
  "model_age_batches": 8
}
```

原始模型JSON：

```json
{"action":"DO_NOTHING","reason":"漂移未触发且Loss持续下降，模型仍在有效学习，当前无充分证据表明需要续训，保持现状以观察后续表现。"}
```

### 请求15：B / abrupt / eval / step3

Action：`DO_NOTHING`。服务端Token：574+34；端到端8.016912秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 0,
      "loss": 0.0757905904656309,
      "labeled_samples": 11
    },
    {
      "source_step": 1,
      "loss": 0.04101140004019857,
      "labeled_samples": 11
    },
    {
      "source_step": 2,
      "loss": 0.0542951194057977,
      "labeled_samples": 10
    }
  ],
  "drift_alarm": false,
  "remaining_label_budget": null,
  "remaining_token_budget": 51371,
  "model_age_batches": 4
}
```

原始模型JSON：

```json
{"action":"DO_NOTHING","reason":"漂移未触发且模型仅4批次，Loss波动在正常范围，证据不足，保持当前检查点。"}
```

### 请求16：B / gradual / train / step3

Action：`DO_NOTHING`。服务端Token：577+38；端到端7.785657秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 0,
      "loss": 1.9618308231317074,
      "labeled_samples": 130
    },
    {
      "source_step": 1,
      "loss": 2.1700654125195076,
      "labeled_samples": 130
    },
    {
      "source_step": 2,
      "loss": 1.5356603369161048,
      "labeled_samples": 130
    }
  ],
  "drift_alarm": false,
  "remaining_label_budget": null,
  "remaining_token_budget": 50763,
  "model_age_batches": 4
}
```

原始模型JSON：

```json
{"action":"DO_NOTHING","reason":"漂移未触发，模型仅4批次且Loss波动大，证据不足，保持现状避免小窗口续训破坏已有分布。"}
```

### 请求17：B / gradual / train / step7

Action：`DO_NOTHING`。服务端Token：643+31；端到端7.596737秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 2,
      "loss": 1.5356603369161048,
      "labeled_samples": 130
    },
    {
      "source_step": 3,
      "loss": 1.1486850866040728,
      "labeled_samples": 130
    },
    {
      "source_step": 4,
      "loss": 0.5570359626583187,
      "labeled_samples": 130
    },
    {
      "source_step": 5,
      "loss": 0.4466193143531127,
      "labeled_samples": 130
    },
    {
      "source_step": 6,
      "loss": 0.820016437073578,
      "labeled_samples": 130
    }
  ],
  "drift_alarm": false,
  "remaining_label_budget": null,
  "remaining_token_budget": 50148,
  "model_age_batches": 8
}
```

原始模型JSON：

```json
{"action":"DO_NOTHING","reason":"漂移未触发，Loss波动属正常范围，模型较新，证据不足，保持现状。"}
```

### 请求18：B / gradual / eval / step3

Action：`DO_NOTHING`。服务端Token：575+31；端到端7.723234秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 0,
      "loss": 0.0757905904656309,
      "labeled_samples": 11
    },
    {
      "source_step": 1,
      "loss": 0.04101140004019857,
      "labeled_samples": 11
    },
    {
      "source_step": 2,
      "loss": 0.0542951194057977,
      "labeled_samples": 10
    }
  ],
  "drift_alarm": false,
  "remaining_label_budget": null,
  "remaining_token_budget": 49474,
  "model_age_batches": 4
}
```

原始模型JSON：

```json
{"action":"DO_NOTHING","reason":"漂移未触发且模型仅4批次，Loss波动属正常，证据不足，保持现状。"}
```

### 请求19：C / stable / train / step3

Action：`DO_NOTHING`。服务端Token：582+40；端到端8.410421秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 0,
      "loss": 0.2689302817381978,
      "labeled_samples": 1525
    },
    {
      "source_step": 1,
      "loss": 0.23843390102620549,
      "labeled_samples": 1525
    },
    {
      "source_step": 2,
      "loss": 0.3305641082738383,
      "labeled_samples": 1525
    }
  ],
  "drift_alarm": false,
  "remaining_label_budget": null,
  "remaining_token_budget": 48868,
  "model_age_batches": 4
}
```

原始模型JSON：

```json
{"action":"DO_NOTHING","reason":"漂移未触发且模型仅4批，Loss波动在正常范围，无充分证据支持续训，避免小窗口破坏已有分布。"}
```

### 请求20：C / stable / train / step7

Action：`DO_NOTHING`。服务端Token：652+40；端到端8.177868秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 2,
      "loss": 0.3305641082738383,
      "labeled_samples": 1525
    },
    {
      "source_step": 3,
      "loss": 0.21265851917412357,
      "labeled_samples": 1525
    },
    {
      "source_step": 4,
      "loss": 0.18870800931810391,
      "labeled_samples": 1525
    },
    {
      "source_step": 5,
      "loss": 0.5031670073824753,
      "labeled_samples": 1525
    },
    {
      "source_step": 6,
      "loss": 0.3423733660546215,
      "labeled_samples": 1525
    }
  ],
  "drift_alarm": false,
  "remaining_label_budget": null,
  "remaining_token_budget": 48246,
  "model_age_batches": 8
}
```

原始模型JSON：

```json
{"action":"DO_NOTHING","reason":"漂移未触发，Loss波动大且无持续恶化趋势，证据不足，保持当前检查点以避免小窗口续训破坏已有分布。"}
```

### 请求21：C / stable / eval / step3

Action：`DO_NOTHING`。服务端Token：579+41；端到端8.186945秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 0,
      "loss": 0.1284511221053485,
      "labeled_samples": 396
    },
    {
      "source_step": 1,
      "loss": 0.19033786105213976,
      "labeled_samples": 396
    },
    {
      "source_step": 2,
      "loss": 0.17610349372160133,
      "labeled_samples": 396
    }
  ],
  "drift_alarm": false,
  "remaining_label_budget": null,
  "remaining_token_budget": 47554,
  "model_age_batches": 4
}
```

原始模型JSON：

```json
{"action":"DO_NOTHING","reason":"漂移未触发且模型仅4批，Loss波动在正常范围，无充分证据表明需续训，避免小窗口破坏已有分布。"}
```

### 请求22：C / abrupt / train / step3

Action：`DO_NOTHING`。服务端Token：581+34；端到端7.796756秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 0,
      "loss": 0.2689302817381978,
      "labeled_samples": 1525
    },
    {
      "source_step": 1,
      "loss": 0.23843390102620549,
      "labeled_samples": 1525
    },
    {
      "source_step": 2,
      "loss": 0.3305641082738383,
      "labeled_samples": 1525
    }
  ],
  "drift_alarm": false,
  "remaining_label_budget": null,
  "remaining_token_budget": 46934,
  "model_age_batches": 4
}
```

原始模型JSON：

```json
{"action":"DO_NOTHING","reason":"漂移未触发且模型仅4批次，Loss波动属正常范围，证据不足，保持当前检查点。"}
```

### 请求23：C / abrupt / train / step7

Action：`RETRAIN_LARGE`。服务端Token：645+33；端到端8.030558秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 2,
      "loss": 0.3305641082738383,
      "labeled_samples": 1525
    },
    {
      "source_step": 3,
      "loss": 1.9800642320593882,
      "labeled_samples": 1525
    },
    {
      "source_step": 4,
      "loss": 1.7506943313252452,
      "labeled_samples": 1525
    },
    {
      "source_step": 5,
      "loss": 3.397444464604141,
      "labeled_samples": 1525
    },
    {
      "source_step": 6,
      "loss": 2.7457725431278046,
      "labeled_samples": 1525
    }
  ],
  "drift_alarm": true,
  "remaining_label_budget": null,
  "remaining_token_budget": 46319,
  "model_age_batches": 8
}
```

原始模型JSON：

```json
{"action":"RETRAIN_LARGE","reason":"漂移告警且Loss持续高位，需大窗口续训以覆盖分布变化并降低RMSE。"}
```

### 请求24：C / abrupt / eval / step3

Action：`DO_NOTHING`。服务端Token：579+41；端到端8.068192秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 0,
      "loss": 0.1284511221053485,
      "labeled_samples": 396
    },
    {
      "source_step": 1,
      "loss": 0.19033786105213976,
      "labeled_samples": 396
    },
    {
      "source_step": 2,
      "loss": 0.17610349372160133,
      "labeled_samples": 396
    }
  ],
  "drift_alarm": false,
  "remaining_label_budget": null,
  "remaining_token_budget": 45641,
  "model_age_batches": 4
}
```

原始模型JSON：

```json
{"action":"DO_NOTHING","reason":"漂移未触发且模型仅4批，Loss波动在正常范围，无充分证据表明需续训，避免小窗口破坏已有分布。"}
```

### 请求25：C / gradual / train / step3

Action：`DO_NOTHING`。服务端Token：582+40；端到端7.936385秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 0,
      "loss": 0.2689302817381978,
      "labeled_samples": 1525
    },
    {
      "source_step": 1,
      "loss": 0.23843390102620549,
      "labeled_samples": 1525
    },
    {
      "source_step": 2,
      "loss": 0.3305641082738383,
      "labeled_samples": 1525
    }
  ],
  "drift_alarm": false,
  "remaining_label_budget": null,
  "remaining_token_budget": 45021,
  "model_age_batches": 4
}
```

原始模型JSON：

```json
{"action":"DO_NOTHING","reason":"漂移未触发且模型仅4批，Loss波动属正常范围，无充分证据支持续训，避免小窗口破坏已有分布。"}
```

### 请求26：C / gradual / train / step7

Action：`RETRAIN_LARGE`。服务端Token：645+37；端到端7.913524秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 2,
      "loss": 0.3305641082738383,
      "labeled_samples": 1525
    },
    {
      "source_step": 3,
      "loss": 0.8765064482615893,
      "labeled_samples": 1525
    },
    {
      "source_step": 4,
      "loss": 1.3540348913758402,
      "labeled_samples": 1525
    },
    {
      "source_step": 5,
      "loss": 3.164254625965767,
      "labeled_samples": 1525
    },
    {
      "source_step": 6,
      "loss": 2.7457725431278046,
      "labeled_samples": 1525
    }
  ],
  "drift_alarm": true,
  "remaining_label_budget": null,
  "remaining_token_budget": 44399,
  "model_age_batches": 8
}
```

原始模型JSON：

```json
{"action":"RETRAIN_LARGE","reason":"漂移告警且Loss持续恶化，特征距离显著，需利用大窗口续训以覆盖分布变化并挽救性能。"}
```

### 请求27：C / gradual / eval / step3

Action：`DO_NOTHING`。服务端Token：579+41；端到端7.864538秒。

Observation：

```json
{
  "loss_trend": [
    {
      "source_step": 0,
      "loss": 0.1284511221053485,
      "labeled_samples": 396
    },
    {
      "source_step": 1,
      "loss": 0.19033786105213976,
      "labeled_samples": 396
    },
    {
      "source_step": 2,
      "loss": 0.17610349372160133,
      "labeled_samples": 396
    }
  ],
  "drift_alarm": false,
  "remaining_label_budget": null,
  "remaining_token_budget": 43717,
  "model_age_batches": 4
}
```

原始模型JSON：

```json
{"action":"DO_NOTHING","reason":"漂移未触发且模型仅4批，Loss波动在正常范围，无充分证据表明需续训，避免小窗口破坏已有分布。"}
```
