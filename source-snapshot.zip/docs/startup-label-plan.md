# 启动标注供给：已确认的单因素开发实验

预登记日期：2026-11-04。用户已确认先处理“早期标注不足、预算分配保守”。本轮固定启动额度 144，不增加阻尼、影子模型、模型复杂度、历史复用或训练窗口改动。

## 诊断与假设

依据 [NR-004](negative-results.md) 和 [日志诊断](negative-diagnosis-20261104.md)，原 adaptive 前 10 批只申请 45 标签，前置调度申请 240；突变后第 10–12 批仍使用初始模型，不能归因为新模型替换太急。供给不足是已证实的等待来源，但不能解释全部恢复损失。

假设：在同一 864 标签总配额内提前提供一笔启动额度，同时保留原后段监测储备，可以缩短基础更新的等待，并改善突变、渐变恢复。144 来自现有训练下限 96 加时间切分选择验证量 48，不使用场景变化点或隐藏标签。提前供应的标签未必属于新概念，因此效果必须由配对实验验证。

## 已确认的实现范围

- `label_startup_budget` 默认 0，仅 adaptive 允许正值；旧配置、默认策略保持兼容。
- 实验配置固定 144：常规供给前六批每批 24，随后恢复原 adaptive 监测/退化脉冲调度。启动额度计入总配额，仍受每批上限、可释放时段与后段储备限制；小预算可能无法兑现全部启动额度。
- 保持 future 独立标签上线门控、monitor 32、训练/验证下限、ridge、训练窗口、退化阈值、冷却及回滚规则不变；窗口自适应、历史复用、候选容量与等待治理关闭。
- 先写调度/配置/真实延迟释放测试并观察失败，再实现最小改动；完整宿主机和断网 Linux 测试、保存恢复与预算审计均为必需项。

## 冻结的开发矩阵

对照 `configs/optimization-candidate.json`（startup 0），候选 `configs/optimization-startup-144.json`。每组两任务 × 六场景 × 种子 7/19/43 × static/drift = 72 次，共 144 次；流长 96、延迟 2、比例 .25、总预算 864、周期宽度 8。

两组使用同一干净源码镜像、4 CPU、4 GiB、CPU 推理、`--network none`，输出到新的 `outputs/startup-labels-20261104`，不覆盖旧记录。仅使用开发种子，不运行新的独立种子或扩大压力矩阵。

```powershell
# 镜像完成构建和测试后，两次分别执行；使用新的空输出目录。
& $Docker run --rm --network none --cpus 4 --memory 4g `
  --mount "type=bind,source=$Output,target=/results" ite-local:startup-144-20261104 `
  ite matrix --config /app/configs/optimization-candidate.json --output /results/adaptive-0 `
  --tasks classification regression --scenarios stable abrupt gradual recurring covariate noise `
  --seeds 7 19 43 --policies static drift
& $Docker run --rm --network none --cpus 4 --memory 4g `
  --mount "type=bind,source=$Output,target=/results" ite-local:startup-144-20261104 `
  ite matrix --config /app/configs/optimization-startup-144.json --output /results/startup-144 `
  --tasks classification regression --scenarios stable abrupt gradual recurring covariate noise `
  --seeds 7 19 43 --policies static drift
```

`$Docker` 指向本机 Docker CLI，`$Output` 是上述新输出目录的绝对路径。交付包附带可直接使用的复现说明与固定镜像。

## 判定与审计

1. 对照启动 0 的 36 次 drift 预测须与已有开发 adaptive 相同；两组 static 预测相同。计时单独比较。
2. 检查每次运行完整结束、标签申请/释放、总配额、后段供给、冻结后来源标签验收、预测版本与检查点保存加载。
3. 比较逐种子累计损失、检测/首次训练/冻结/上线时序、漂移后损失及资源成本；按特征/得分、同样本残差、复杂度、时序四层解释结果。漂移真值仅用于离线评分。
4. 开发门槛：周期两任务 drift 均值均不高于同组 static；其他五场景对历史 legacy 的退化不超过分类 .005、回归 NMSE .01。使用未舍入数值；历史 legacy 来自 `outputs/local-optimization-20261104/development/legacy/summary.csv`。
5. 失败先追加 NR-009 四字段，保留原默认；不在本轮继续调启动额度或混入新策略。即使开发通过，也只视为进入后续独立验收的候选，不宣称正式晋级。已看过的种子不作新的独立验收。
6. 沿用现有 SwanLab 项目归档，保留源码、配置、镜像及结果 SHA-256，导出并重载镜像验证断网预测。代码/配置/预登记先提交，再运行效果实验；结果另作本地 Git 提交。

本轮仅验证模拟环境，官方数据、SDK、评分和配额仍待提供。
