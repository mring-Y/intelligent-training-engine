# 2026-11-10：三个公开 A 数据集预处理与首轮静态 Baseline

依据用户本轮具体方案，完成 UCI Gas 六分类、C-MAPSS FD001 RUL 回归和 XJTU-SY RUL 回归的数据准备及固定静态对照。轴承目标以用户最后指令的 **RUL 回归**为准。三个公开源按用户要求作为开发 A 包；正式比赛 SDK、隐藏 B 流、官方基线和评分协议仍需另外对齐。

## 本轮结果

所有模型固定 `alpha=1.0`，只训练一次，无调参、模拟漂移注入、模型上线或付费 LLM。Gas 使用六个原有二分类 Ridge 的 One-vs-Rest 包装器，回归使用原有 `RidgeModel`；生产默认及二分类数值路径保持。

| 数据 | 训练 / 验证 / 流样本数 | 特征 / 流批次 | 验证指标 | 测试流指标 |
| --- | ---: | ---: | ---: | ---: |
| UCI Gas | 355 / 90 / 13,465 | 128 / 9 | Accuracy 96.666667% | **Accuracy 26.067583%** |
| C-MAPSS FD001 | 11,942 / 4,196 / 4,493 | 24 / 18 | RMSE 24.021152 周期 | **RMSE 21.383980 周期** |
| XJTU-SY 子集 | 123 / 122 / 52 | 8 / 4 | RMSE 2847.153036 秒 | **RMSE 3013.330070 秒**（50.222168 分钟） |

Gas 是按全部测试样本加权的准确率；不是九个批次准确率的简单均值。C-MAPSS 是测试流每个周期的 RMSE，不是原官方 censored test 每台发动机末周期的标准指标。轴承值为实际秒，未归一化、未截断预测；只覆盖工况 1 的 3/15 个轴承。

Gas 同批初始化验证高、后续时间流低，是此固定静态对照的观测。不能单凭准确率差确认唯一物理漂移原因，也不能据此推断 Harness 已改善效果。轴承误差较大；只保留初始参考，不更换模型、挑数据或自动优化。本轮没有预登记模型效果晋级门槛，不把“Baseline 已完成”写成“性能已晋级”。

## 来源、切分与标签定义

**UCI Gas**：用户指定 [UCI 数据集](https://archive.ics.uci.edu/dataset/224/gas)，从原站获取 9,989,262 字节 ZIP，来源及 SHA-256 在 `raw/uci_gas/gas-sensor-array-drift.zip.source.json`。公开数据共 13,910 条、六类、十批、128 特征；CC BY 4.0，保留作者/原站引用。只将源 batch 1 的 445 行按种子 7、类别分层留出 20% 验证；其余九批按原序在线预测。未对未来批次随机混合，未捏造批内时间戳。原始 source batch 2–10 的准确率依次为 30.948553%、22.698613%、44.099379%、26.903553%、24.739130%、22.446720%、29.251701%、46.382979%、26.583333%。

**C-MAPSS**：用户指定 [data.gov 条目](https://catalog.data.gov/dataset/cmapss-jet-engine-simulated-data)。其旧 NASA 链接与当前 NASA 页面关联的 S3 主机均遇到 DNS 问题，失败证据保留。实际数据取自可归因的 GitHub 镜像 `hankroark/Turbofan-Engine-Degradation`，固定提交 `ffde9492639af9c02ef6ab6607f8029dc8302591`、Git blob `d2809918c8b75fa3319714658ae994deb2017a89`，原始 `train_FD001.txt` 为 3,515,356 字节，SHA-256 `963b5e22825b34d8b21c69e1aeb4af3e647050eb672ee8834ba4b5d91d2de0f8`。同时保存原始说明。镜像来源、Git blob 哈希、100 台及 20,631 行结构均核验；未与当前不可达的官方 ZIP 做字节比对。

完整发动机 ID 1–60 / 61–80 / 81–100 分别进入训练、验证、开发流，单位不交叉；保持 unit/cycle 原序。特征只用三项工况和 21 个传感器；unit、cycle、目标及元数据不作特征。`RUL=min(125,max_cycle(unit)-cycle)`，单位周期。只用 run-to-failure training 文件；官方截断 test 及对应末端 RUL 未用于本轮，避免把观测终点误作失效终点。已有原始行/目标/实体/ID/Provider 独立审计覆盖全部 20,631 行。

**XJTU-SY**：用户指定 [原作者 GitHub 说明](https://github.com/WangBiaoXJTU/xjtu-sy-bearing-datasets/blob/master/README.md)。原作者网页、采集说明和寿命计数表已保存；作者 Google Drive 分卷及完整镜像 ZIP 下载长时间没有取得有效载荷，失败记录保留。实际采用 [Kaggle 公开镜像第 2 版](https://www.kaggle.com/datasets/groltalt/xjtu-sy-mirror/versions/2)，镜像说明引用原作者网页及 Drive/MediaFire/Baidu。下载了 297 个 CSV、393,539,862 字节，每个文件有 URL、字节、SHA-256 回执；与镜像文件清单及作者寿命计数核对，不宣称同原作者 RAR 字节逐一匹配。

首轮在提取和评分前固定最小完整实体子集：`Bearing1_1` 训练（123 次采集）、`Bearing1_4` 验证（122）、`Bearing1_5` 流（52）；分配依据完整实体大小和既有分区角色，没有按表现选择轴承。原始记录均 25,600 Hz、两通道、32,768 点/通道，间隔名义 60 秒。每次取一个完整一秒窗，提取两通道各 RMS、峰峰值、Pearson 峭度、非 DC 解析包络谱峰频率，合计八列。默认不重采样；脚本另有带抗混叠 FIR 的可选重采样并有数值测试。

每次剩余 7,168 个时间采样点/通道记为丢弃尾段，合计 2,128,896；不把间隔 60 秒的离散采集拼成连续波形。RUL 为最后完整记录窗口末端减当前窗口末端的秒数，是明确的记录终点代理，不能等同独立测得的精确机械失效瞬间。训练/验证/流目标分别从 7320 / 7260 / 3060 秒降到 0。流批数为 16/16/16/4。本轮零无效窗口、零特征填补、零标签丢弃。

## 实现与复现

入口说明和完整命令见 [`scripts/data_prep/README.md`](../scripts/data_prep/README.md)。三个模块分别为 `gas.py`、`cmapss.py`、`bearing.py`，信号函数在 `features.py`；公共 `common.py` 保存下载来源、训练集拟合中位数、唯一 ID、严格输出目录和 CSV/Parquet 导出。

每个准备包均包含 `train.csv`、`val.csv`、`test_stream.parquet`、`manifest.json`，位于 `outputs/a-package-20261110/prepared/{uci_gas,cmapss_fd001,xjtu_sy}`。原始字节和派生数据均被 Git/Docker context 排除。原始和本轮输出不可覆写。缺失标签不插补；仅从训练特征拟合中位数，验证和流不参与拟合。三个实际准备包均无标签丢弃及特征插补。

`PreparedDataProvider` 仅按文件后缀复用现有 CSV/Parquet reader，保留原 Provider 的预测提交和标签边界。独立 Baseline 先完成全部批次的 predict/commit，再以隔离评分器读取目标核对。保存 `initial.npz`、`predictions.npz`、逐事件 JSONL 和摘要。OVR 用未裁剪 Ridge 得分 argmax，六类均保留；checkpoint 禁用 pickle。

本轮主实现提交 `742f2b4`。宿主三份初始 Baseline 在本地提交冻结前后顺序运行，事件保存其当时 Git dirty/commit 及实现文件哈希；不把早期输出改写成后来源码版本。冻结修复提交 `5fc8380ccde2b07dfdc437ddfcbe1f719d61b1f9` 用于最终 Linux 复现，核心 `ite/`、依赖锁和原最终镜像未修改。

## 验证与边界

先写失败测试，覆盖解析/完整性、实体隔离、确切 RUL、特征公式、包络峰和抗混叠、训练中位数、无效标签、来源回执、不可覆写、OVR 持久化及 post-commit 评分。宿主最终完整套件 **337 项、0 失败/错误、1 项跳过**，100.437 秒；唯一跳过为未安装可选 scikit-learn 的独立树基准。新增数据准备测试不跳过。独立审查最终 spec/quality 均 PASS，回执保留。

首个数据准备验证镜像漏带历史 scripts 和 tokenizer 测试路径，完整测试失败已先归档 **NR-017**；原失败日志保留。仅补齐相同历史测试资产和原 tokenizer 路径，依赖、数据、算法和资源不变。修复镜像完整测试 **337 项、0 失败/错误、1 项跳过**，30.644 秒；断网、4 CPU、8 GiB，实测 cgroup 峰值 551,133,184 字节。新增镜像 `ite-local:public-a-prep-20261110-verified` 从固定依赖的原本地 runtime 扩展，不下载或安装依赖，不覆盖 `ite-final:official-submit`。

最终 Linux 从三份真实原始文件重新完成数据准备和 Baseline，逐条预测核对通过：Gas 和 FD001 最大差 0，轴承最大差 `8.640199666842818e-12`，RUL RMSE 与宿主一致。流水线峰值 322,961,408 字节，退出0、无OOM；与完整测试同时运行，墙钟不作性能基准。全部 18,010 条预测、31个批次完成，无模型更新或LLM调用。

最终验证镜像 ID `sha256:5a5bc1dd7d50ae724cd66d4e64cc83eea4f5db3711c9393815d1292bcb48c141`，运行大小 952,552,959 字节；导出 `outputs/a-package-20261110/public-a-prep-verified-image.tar` 为 211,583,488 字节，SHA-256 `3d75b6ca67e11901e94722774da18a13d4677ea49e6b7ccc7902af684fe6dde2`。重载镜像身份不变，并在断网容器只加载保存 checkpoint、不调用 fit，恢复三条完整流，预测逐值一致、最大差0。冻结源码 ZIP 位于 `outputs/a-package-20261110/source-5fc8380.zip`。这些是本轮专用数据准备/验证镜像与源码，不覆盖原最终提交镜像或旧产物。

完整源码、来源、宿主/Linux测试、容器退出/资源、包清单和导出重载身份见 [本轮机器记录](validation/2026-11-10-public-a-baseline.json)。

完整原始证据在 `outputs/a-package-20261110/records/`：宿主 `host-full-02.txt`，Linux `linux-full-final.txt`，真实流水线 `linux-real-pipeline.json`，逐批事后指标 `postrun-batch-metrics.json`；各源另有 `cmapss/` 和 `bearing/` 审计。所有旧原始实验、SwanLab run 和历史容器均保留。本轮真实 Token/付费请求均 0，未上传 SwanLab、未推送远程。

当前交付是可复现的数据准备和静态参考。Mock 干预及多分类生产 Controller 适配未在本轮实施；后续若开展，先用本轮真实标签时序和表现完成诊断、明确单因素及资源门槛，再按 SOP 确认。不要把公开开发 A 子集反复调参后再当独立隐藏验收。
