# 27B Harness续开结果（2026-11-14）

本轮在4B连续两次工具修正后仍无法形成合规第二轮候选，按用户条件切换到官方`Qwen/Qwen3.8-27B`。只改变Harness模型；提示、代码白名单、官方CPU检查点、公开数据、候选筛选、独立future gate、15秒截止、网络零重试、两次host修正和每包资源配额均保持不变。4B仍是默认配置，27B不代表最终总分更高。

赛题PDF第3-4页明确要求无人干预完成、完整记录、综合性能不低于静态基线，并把算力/训练额度、标注和大模型Token纳入客观评价；PDF没有列出4B固定加分。培训纪要只记录4B可能有资源分优势。本文不把该优势写成已获分值。

## 真实模型结果

| 包 | 真实候选轮数 | 筛选通过 | future gate通过 | 实际更新 | 累计CPU训练秒 | 最终checkpoint |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| A | 10/10 | 2 | 2 | 0 | 3.9401 | 官方起点 |
| B | 10/10 | 5 | 5 | 0 | 3.8371 | 官方起点 |
| C | 10/10 | 8 | 4 | 0 | 4.0703 | 官方起点 |

三包每轮都实际完成了代码校验、CPU续训、筛选和选择；所有选择均为`incumbent`，因此没有模型部署更新。A末块stable Macro-F1为`0.1666667`，B末块stable RMSE/MAE为`351.0995/257.2862`分钟，C末块stable RMSE/MAE/高估率为`48.7543/33.5549/46.3993%`；所选模型与static完全相同，所有公开末块差值为0。A末块只有一个类别，abrupt/gradual末时点使用相同偏移，不能把这些末块数值当作全流或隐藏成绩。

个别Reason与工具事实不一致：B第7轮称“已更新incumbent”，实际version仍为0；A最终称所有候选没有提升，实际有2条通过future gate。当前工具上下文只提供最近两条历史，完整档案在宿主保留；尚未证明限制历史范围或模型容量是错误原因。记录事实以events和checkpoint为准，不将Reason当作部署证明。本轮不修改候选选择/历史摘要，也不追加新的模型矩阵。

27B共36次请求，服务端输入/输出`85803/4533` Token，端到端单次`4.628-9.247`秒；本地计数与服务端输入逐请求一致，没有超时、网络重试或host工具修正。直接按Token费率估算为`¥0.38491902`，保守逐请求预留新增`¥1.44`；携带历史`¥9.40`后累计`¥10.84`，上限`¥29.99`。保守预留不是实际扣费回执。

## 断网复现与边界

冻结源码提交为`ae9f3bcf48c90db53041872e8a99f629c45a821f`，源码SHA-256为`4e9c500024b84521c106a1d4862b7c500fe65859d04aa2ac4e32b84ac2ee85c3`。固定基础镜像为`sha256:76476d088433a4bb20a00d6eed16b136062ffe670a8d7541b727ce6ef8eb5228`，本轮验证镜像为`sha256:6b83d6e171dc24322fa08f0273833cf15bc202b1cf995d070b7c6fa512c19445`，导出包SHA-256为`52fb39f64821c5aff21ae5809da693fd0e963b0dd76d1ddcb8b0c66c807ef9d0`。宿主675/675通过；断网Linux 675项中674通过、1项宿主专用跳过，4 CPU/4 GiB、network none、退出0、无OOM。

唯一36条真实提案在断网Linux重新完成A/B/C各10轮。30轮的候选配置、假设、父检查点链、选择和gate结果一致；最终预测数组完全一致。训练源码仅有CRLF/LF差异，检查点数值数组最大绝对差`5.55e-17`（1086个数组，`rtol=1e-12`,`atol=1e-12`），所以不声称检查点逐字节一致。

隐藏测试未访问，正式平台未提交，公开开发结果不证明三包超过baseline，也不证明27B的总分优于4B。27B的结论是“真实三包十轮协议完成”；效果结论是“所有候选均未被选中，当前模型保持static”。原始请求、训练、门控、预算和容器回执位于`outputs/code-harness-renewal-20261114/`。原始归档首次公开上传被自动审批拒绝；用户随后明确允许公开五份归档，现已完成同步并由服务器确认PUBLIC/FINISHED。

## 归档与交接

五份SwanLab offline原始归档合计9042055字节，718份证据文件逐文件SHA-256和ZIP校验全部通过：

| 内容 | SwanLab公开run（均FINISHED） | 归档字节 | 证据文件 |
| --- | --- | ---: | ---: |
| 4B预算续开后重复父配置 | [qxpw1uim](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/qxpw1uim/chart) | 223490 | 13 |
| 4B在读取阶段误用训练工具 | [o2b08cb8](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/o2b08cb8/chart) | 220835 | 13 |
| 4B完成A首轮、随后修正耗尽 | [5aixvjiv](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/5aixvjiv/chart) | 438382 | 22 |
| 27B真实三包各十轮 | [al0xjnid](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/al0xjnid/chart) | 4092649 | 336 |
| 27B提案断网Linux重放 | [v705j1kz](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/v705j1kz/chart) | 4066699 | 334 |

原helper回执的`mode=offline`按历史保留，[审查清单](../outputs/code-harness-renewal-20261114/records/54-local-swanlab-archive-review.json)记录公开前状态。用户随后明确回复“允许公开这5份归档”，才调用SwanLab sync同步上述相同SHA的五个run。五次同步退出0，分别确认2份save附件上传成功；服务器只读回查确认项目PUBLIC、五个run均FINISHED，见[云端回执](../outputs/code-harness-renewal-20261114/records/60-cloud-verified-corrected.json)。原始ZIP未改变，未独立下载服务器附件逐字节复核，因此不声称该项已完成。公开内容为提示/原始回复、候选训练代码、公开开发指标/预测、工业检查点及来源记录，不包括API凭证、隐藏测试或大模型权重。

[机器验证索引](validation/2026-11-14-code-harness-renewal-27b.json)保存全部轮数、指标、费用、镜像和复现边界。[执行计划](superpowers/plans/2026-11-14-code-harness-27b.md)记录本轮条件授权与测试步骤；旧[十轮演习/首次真实失败报告](code-harness-ten-rounds-results-20261114.md)按历史保留。新验证镜像不替换旧正式提交镜像，源码/实验/报告版本分开保留。后续若继续改4B提示、记忆摘要或候选选择，须按SOP重新确认单因素。

