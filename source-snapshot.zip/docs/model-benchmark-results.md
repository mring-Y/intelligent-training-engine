# 离线 Ridge 与决策树基准

本记录只评估备选模型在一条可控的合成非线性回归流上的训练耗时和测试误差，不代表官方 A/B 包效果，也不改变生产模型。

## 配置

- 固定种子 `20261108`，训练集 6,000 行、测试集 1,500 行、8 个特征。
- 目标为四段分段函数 `piecewise(x0) + 0.04*sin(3*x1) + N(0, 0.03)`；其余特征作为无关输入。
- 对照为仓库当前 `RidgeModel(alpha=1.0)`；备选为 `DecisionTreeRegressor(max_depth=3, random_state=20261108)`。
- 通过 `threadpoolctl` 将数值后端限制为单线程；决策树本身也不并行训练。时限门槛为 3 秒。
- 基准脚本和回归测试：[`scripts/bench_models.py`](../scripts/bench_models.py)、[`tests/test_bench_models.py`](../tests/test_bench_models.py)。

## 结果

| 模型 | 训练耗时 | 测试 MSE | 设置 |
| --- | ---: | ---: | --- |
| Ridge | 0.00515 秒 | 2.195131 | alpha=1.0 |
| Decision Tree | 0.02345 秒 | 0.001632 | max_depth=3，单线程，实际深度 3、8 个叶节点 |

决策树在这条合成流上低于 3 秒门槛；其测试 MSE 比 Ridge 低约 99.93%。同配置未限 CPU affinity 的复测中，决策树训练耗时 0.02532 秒，测试 MSE 相同。

## 运行边界

主测进程限制在 4 个 CPU（affinity `[0, 1, 2, 3]`）。环境为 Windows 10、Python 3.9.13、NumPy 1.21.5、scikit-learn 1.0.2；进程峰值工作集为 95,952,896 字节（约 91.5 MiB）。本机没有 Docker/Podman，WSL 发行版枚举返回 `E_ACCESSDENIED`，所以没有施加或验证 8 GiB 内存上限，也没有断网 Linux 容器回执。此结果不能表述为 4 核 8 GiB 容器验收。

这是刻意构造、对浅树有利的四段关系；它只说明该轻量树模型在本测试规模下训练很快且能拟合该关系，不证明其适合官方数据。`models.py`、生产依赖及锁文件均未修改。拿到官方 A 包后，应先用相同预算、切分和门控与 Ridge 做受控对比，再决定是否提出生产接入方案。
