# 2026-11-15 使用 ppt-master 美化5分钟答辩材料

用户指定通过 <https://github.com/hugohe3/ppt-master> 美化既有PPT。本轮仅处理演示材料，未更改生产代码、策略、数据、实验配置、模型或镜像，没有训练、付费调用、上传或平台提交。原5分钟版和8分钟版均保留。

## 交付位置

目录：`outputs/defense-20261115/ppt-master-beautified/deliverables/`。

- `智训引擎答辩-5分钟-ppt-master美化版.pptx`：20页，9页主讲和11页备查，备注建议时长合计300秒。16张原生表格、2张原生图表，3个原有SwanLab链接可点击。
- `智训引擎答辩-5分钟-ppt-master美化版.pdf`：从最终PPTX逐页渲染生成的固定预览，20页，带页面书签和原有实验链接。
- 原5分钟讲稿与问答MD/PDF、8页技术报告DOCX/PDF、证据与口径清单逐字节沿用。
- 美化版使用说明、制作来源JSON、MIT许可证和SHA256SUMS。

材料包：`outputs/defense-20261115/ppt-master-beautified/智训引擎答辩材料-5分钟-ppt-master美化版.zip`。54个成员、1,974,474字节，另含20页SVG、design_spec、spec_lock和全部原始备注源文件。

| 成品 | SHA-256 |
| --- | --- |
| PPTX | `97c8ab39dc6905f1cee9a0e3faaedc779117e347436b9801a7921540ed4a62ac` |
| PDF | `e0a8156f58ebc361d3992b633a298378111f9abbc7f8040fb9e1de853eace8eb` |
| ZIP | `f1e3b2cf373558d686455486f0aefd819194177b08c4aa5bdead4d03b183a713` |

## 实际制作路线

固定使用 ppt-master v6.9.0、提交 `3af3e8ef774c4d67ee57e1306d9256d08c9ee1bf`，MIT许可证。工作流为 `Generate PPTX / Beautify / Default`，执行源PPT导入和冻结清单、设计规范与执行锁、SVG原子图表/表格作者、前5页early gate、20页final gate、备注拆分、SVG后处理及 `svg_to_pptx.py --native-charts-and-tables --no-animations` 原生导出。工具源码和归属校验未修改。

美化保留源PPT实际采用的Microsoft YaHei和深蓝/青绿配色，重新组织字号、留白、表格横线、数字层级和C收益重点。标题、证据与风险披露保持原内容和顺序，不新增未经证明的指标或口号。讲稿、来源定位和哈希备注逐字保留。

导出后仅恢复3个原有外部超链接，并修复新图表工作簿一处浮点数序列化尾差：工作表数值与冻结图表缓存的精确小数对齐，没有重建源公式或改动原数据。修复后重新通过图表缓存与内嵌工作簿核验。

## 完成的复核及边界

20页SVG最终检查20/20通过、0警告、0错误；ppt-master导出postflight通过。随后第一方结构、几何、字体、20页导入、2个图表标题与工作簿检查通过。逐页查看20页实际原生PPTX渲染，修复并复看第7页多余图例和第17页单字断行。

冻结清单核验20/20页通过。额外核验所有可见文字（忽略排版空白）相等、全部表格单元格逐字相同、所有图表数值及名称相同、20页原始备注逐字相同、主讲300秒、源PPT哈希未变。PDF的20页嵌入图像与对应原生PPTX渲染逐像素一致，抽取第1/7/17/20页重新渲染检查。ZIP完整性及全部交付文件成员哈希通过。

仍保留A仅微增、B静态、整体 `effect_passed=false`、真实27B选定更新0、SFT未晋级、公开开发ID复用、C局部高估和最终检查点跨分布退化等事实边界。本轮美化不构成新的模型效果验收。

没有在原生Microsoft PowerPoint中打开，不声称完成原生应用验收。正式演示前应在实际电脑检查Microsoft YaHei、投影比例、图表及点击链接，并按前9页计时排练。学校、队伍、成员与视频录制仍待参赛者补充。

内部回执：`outputs/defense-20261115/ppt-master-beautified/.build/final-release-verification.json`、`native-final-v2.validation.json`、`final-frozen-verification.txt`及项目`validation/`。原5分钟交付索引见[五分钟材料](defense-materials-5min-20261115.md)。
