# 指数时间衰减：已确认的单因素开发实验

2026-11-04。用户已明确确认方案二及测试、容器和 144 次配对范围。依据 NR-011 与 training-preflight-results.md：较早首训的 27–28 个标签含较多转变过程；样本量、概念纯度和补训时序尚未分离。本轮不将时间加权称为保证改善，也不增加其他策略。

## Global Constraints

- 对照：configs/optimization-training-preflight.json，固定 8 批训练来源窗口，training_preflight=true。
- 候选：取消训练集 8 批硬截断，使用现有有界历史及 192/384/768 个样本候选，半衰期 4 批指数权重，training_preflight=true。
- w_i = 2 ** (-(latest_released_source_step - source_step_i) / 4)。只用已释放标签的来源批次；每个候选切片内将权重归一化为均值 1。实现可减去候选最大对数权重再归一化以保持数值稳定，归一化结果必须等价。
- 全链路加权：特征均值、总体方差、目标均值/截距、必要的基函数中心化及加权岭回归求解。截距不惩罚；分类保持原 0/1 岭模型。无权重旧分支保持兼容；同权等价。
- 训练下限保持 16。预算、标签调度、监测、冷却、候选正则化参数、时间筛选集和独立 future 门控保持原样。ESS 仅审计，不参与训练准入、选择、门控或晋级。
- 当前历史保留上限 768 个标签，不无限扩容，不额外回灌初始训练标签。不叠加动态窗口、历史模型复用、新训练/ESS 门槛或半衰期搜索。
- 候选筛选和上线损失仍为原错误率/NMSE；漂移真值仅用于离线评分。预测版本以 prediction 事件为准，deploy(k) 影响 k+1。
- TDD：生产代码前先写并运行失败测试；所有新增代码附行为测试。新增配置/接口不存在的错误必须与实际行为失败分开记录，不冒充同一种证据。
- 新输出根目录 outputs/time-decay-20261104；不得覆写历史输出。开发种子 7/19/43，不复用已见独立种子包装验收。固定依赖及基础镜像摘要。
- 144 次 = 两组 × 两任务 × 六场景（stable/abrupt/gradual/recurring/covariate/noise）× 三种子 × static/drift。96 批，延迟 2，标注比例 .25，标签预算 864，周期 8；4 CPU/4 GiB/CPU/--network none，顺序使用同一镜像。
- 晋级标准沿用：周期两任务均不劣于 static；其他五场景对历史 legacy 分类退化不超过 .005、回归 NMSE 不超过 .01，用未舍入值。优于本轮对照不自动晋级；失败先追加阴性档案，再诊断。不自动追加其他策略实验或独立验收。
- 保留 source commit、dirty、源码 SHA-256、配置哈希、镜像 ID、导出重载、检查点预测和每文件校验。沿用现有 SwanLab 项目归档，不读取/输出凭证、不重新登录。仅本地 Git，不推送或合并。

## Task 1: 测试先行与全链路实现

先阅读 AGENTS.md、SOP、NR-011、最近诊断和本 brief。工作区为现有 development 分支，基线 49cf8f9，使用本机 .venv。先写 tests/test_time_decay.py 并保存 RED 输出到新根目录 records/task-1-implementation。至少覆盖：旧无权重兼容；同权等价；手工加权闭式解（独立构造带非惩罚截距的增广设计矩阵，包含 ridge/quadratic、常量列和分类）；非法权重（维度/长度/负值/非有限/全零）；权重源时间、半衰期、均值 1、不同候选切片对齐；训练/筛选/未来门控不泄漏；候选取消硬截断但历史仍有界；不足 16 不计尝试/不推进冷却；真实 BoundedTrainer 加权传参及超时/恢复；检查点预测一致；配置严格校验/roundtrip/默认兼容及候选单因素配置；摘要含权重模式和 ESS 审计。测试使用真实组件，模拟仅限不可避免依赖。

建议新配置 training_weighting='none' 默认与 training_half_life_batches=4.0（有限正数，拒 bool），候选 'exponential' 且 train_source_window_batches=0。拒绝 exponential 与正硬窗口同时开启，避免含糊叠加。控制配置不变。拟合接口新增可选 sample_weight=None；trainer 旧调用不被迫改变。模型内部对权重均值 1 规范化并校验，控制器按每候选切片计算/记录同样权重。允许零权重但总和须正；同权走原数值分支。对 quadratic 基函数使用加权中心化。用 sqrt(w) 的行缩放或等价矩阵乘法，不能分配 N×N 对角阵。

记录 train raw count、source range、effective sample size、weight min/max/sum、half life/reference 和候选窗口；ESS 仅审计。给 experiment_started 和 candidate_evaluated 可追溯证据，run summary 聚合 ESS 可用审计字段。不要为 ESS 增加拒绝逻辑。runner/tracking 原结构只做必要扩展。

先观察 RED，再最小实现并跑 focused/full host（完整原 94 项仍通过），保留原始输出及退出码。更新 README/runbook 的参数与含义。自审、git diff --check 后将生产代码、测试、候选配置、说明和本计划提交本地 Git。不要跑矩阵、修改 Dockerfile/依赖或推送。报告含实现/测试/RED-GREEN证据/提交/风险，写入指定 report 路径；不派子代理。

## Task 2: 容器复现与 144 次配对

在 Task 1 审查通过后，对干净冻结提交构建 runtime/test 镜像。固定 Dockerfile 中现有基础摘要，不为本轮重新解析浮动 tag，不改依赖。若本地已有 build cache 先复用。宿主与断网 Linux 全绿后，镜像导出并重载，核对 ID。

用同一重载镜像运行 control（旧 preflight 配置）与 exponential（新候选配置），明确 --tasks classification regression --scenarios stable abrupt gradual recurring covariate noise --seeds 7 19 43 --batches 96 --policies static drift；各72、共144。宿主挂载全新目录，4 CPU/4 GiB/--network none，顺序运行。保留完整 stdout、退出状态、cgroup memory.peak/cpu.stat 和真实资源限制，不把停止后 0B 当峰值。

验证两组有效配置差异仅为训练时间证据模式（硬8批→有界历史指数权重h4）；static 逐值相同；本轮control与上轮preflight预测逐值相同；预测/检查点一致、有限且完整、标签与预算协议、独立未来门控、768历史上限、预检不耗尝试/冷却、权重与ESS审计可复算。记录镜像来源/源码hash/导出hash。只运行已批准矩阵，不重跑失败效果或搜索参数。报告与证据写新输出records，不改生产代码。若必须新增复用审计脚本，先有测试。

## Task 3: 判定、阴性归档、诊断与交付

读取完整144次结果，用原门槛及历史legacy作未舍入判定。若失败，先在docs/negative-results.md追加NR-012四字段（假设、stable/abrupt/gradual两任务具体数值、失败归因证据边界、后续启示），然后仅离线做特征/得分、残差、9参数复杂度和漂移/训练/部署时序诊断，报告逐种子差异和周期边界；不得未经新确认试其他策略。

新增docs/time-decay-results.md、docs/validation/2026-11-04-time-decay.json，更新README/runbook进度。保留开发阶段、默认不晋级、ESS仅审计的界限。沿用既有SwanLab归档命令和项目，保留回执；不发送消息给任何人。形成包含冻结镜像/源码/配置/原始输出/文档/每文件SHA256SUMS的本地交付ZIP及外部ZIP校验；排除凭证、.venv与其他历史实验。完整核验后本地Git提交，最终报告结果、测试、提交和实际限制，不推送/合并。
