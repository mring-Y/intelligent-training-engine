# 下一对话窗口交接：回到 Harness、成本与工业稳定性

**2026-11-14 最新：** 4B连续两次工具修正仍停在A第2轮后，用户条件授权一次27B切换。提交`ae9f3bc`将Harness模型路由参数化，默认仍为Qwen3.5-4B；官方Qwen3.8-27B会话已完成A/B/C各10/10真实CPU候选轮，36次请求无超时/重试，累计保守预留¥10.84。筛选通过A/B/C为2/5/8，future gate为2/5/4，但所有选择均为incumbent，0部署，三包公开末块与static相同。断网Linux重放三包30轮，候选配置/决策/预测一致；浮点数组最大差5.55e-17。隐藏测试未测、正式未提交。读[27B续开结果](code-harness-renewal-results-20261114.md)、[NR-041](negative-results.md)、[验证回执](validation/2026-11-14-code-harness-renewal-27b.json)和[执行计划](superpowers/plans/2026-11-14-code-harness-27b.md)。五份原始归档在自动审批初次拒绝后，获用户明确公开许可才同步；项目PUBLIC、五个run均FINISHED，真实27B为al0xjnid、重放v705j1kz，正确回执60保留服务器回查。没有新模型调用或预算消耗。

**本轮最新入口（2026-11-13，覆盖下方历史授权状态）：** 用户确认后已完成C包动态安全校准，`CALIBRATE_DOWN` 为固定head_only续训+独立历史48条残差P90校准候选；720训练/48筛选/未来MSE gate及资源上限保留。校准减少了普通head高估，但4个漂移分区仍高于对应静态安全值，NR-029已记，不晋级默认、不继续调分位数或门槛。最终宿主553/553、4CPU/8GiB断网Linux552通过1宿主专用跳过，0API/LoRA。先读[本轮报告](official-safety-calibration-results-20261113.md)、[验证索引](validation/2026-11-13-official-safety-calibration.json)、NR-029和SOP；下一策略仍需新的诊断与确认。以下轮次日期及其“未批准”语句均为当时历史状态。

**当前最新（2026-11-14，覆盖本文件其他历史“当前”入口）：** 受限代码 Harness 和三包十轮 CPU 确定性演习已实现并完成宿主/断网容器验证；真实 PyTRiO 工具会话则分别因重复父配置和15秒读取超时安全停止，真实A/B/C优化轮数均为0，累计reserved¥9.24且ledger stopped。读[结果报告](code-harness-ten-rounds-results-20261114.md)、[唯一执行计划](superpowers/plans/2026-11-14-code-harness-ten-rounds.md)、[NR-035/036/037](negative-results.md)及[机器索引](validation/2026-11-14-code-harness-ten-rounds.json)。不要重置任一paid-state，不用Mock冒充真实迭代；新付费策略需另行诊断并获用户确认。此前C校准、非对称损失等摘要均为历史结果，保持不晋级。

**当前入口（2026-11-14）：** 官方 C 的2×非对称训练损失实验未达到安全门槛；RMSE有下降，但高估率超静态。NR-028已经完整归档，宿主537/537、断网Linux536通过/1跳过，镜像与跨平台数组复现记录见[结果报告](official-asymmetric-loss-results-20261114.md)和[机器验收](validation/2026-11-14-official-asymmetric-loss.json)。不自动改3×、校准、gate或默认模型；用户未确认新的损失/后处理实验。

**当前入口（2026-11-13）：** 官方MLP冻结头已接通，C包18流证明RMSE能改善但高估风险仍增加，full/head均未过联合安全门槛。请先读[本轮结果](official-head-only-results-20261113.md)、[机器索引](validation/2026-11-13-official-head-only.json)、[NR-027](negative-results.md)和下方历史交接。最终宿主533/533；断网4CPU/8GiB Linux532通过1宿主专用跳过，0API/LoRA，不改默认策略。下一轮不自动继续低LR、不对称损失或安全门控调参。

**当前入口（2026-11-12）：** 本文其余为历史。请先读[官方A/B/C与SFT最新交接](handoff-after-A-package.md)、[真实27B小批报告](official-sft-pilot-20261112.md)、[NR-025/026](negative-results.md)及[迭代SOP](iteration-sop.md)。当前默认为官方MLP，真实Teacher27条全部待审核、train/eval为0；没有4B微调，不重开已占用paid claim。

**最新完成（2026-11-08）：** [三次突变与数据接口结果](three-abrupt-results.md)及[逐决策Mock报告](triple-drift-mock-report.md)。实现冻结6f03dff，OfficialDataProvider CSV/Parquet已接Runner，SwanLab Public/匿名核验和逐ActionText已实现，15秒硬截止、共享唯一付费声明与5次/0.16元保护生效。宿主与断网Linux各278/278；固定Mock流四次RETRAIN_SMALL建议、一次筛选拒绝、后续三次future-gate通过。唯一真实流首请求15.0053992秒超时，无Action/重训/上线，冻结v0完成30批；实际Token/扣款未知，保留2560Token/0.03017216元预留。NR-016已记，真实三链目标失败，不自动再付费或放宽截止。Public归档[8qr4s306](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/8qr4s306)，完整CPU镜像约950MB/导出211MB。共享账本与执行声明outputs/three-abrupt-paid-state不可删除以重置额度。下一轮仍需新诊断与确认；官方SDK/数据/任务映射/许可材料仍待对齐。

交接日期：2026-11-07。项目根目录：`C:\Users\LENOVO\Desktop\Intelligent Training Engine`。

**最新完成（2026-11-07）：** 用户随后明确批准实施，完成 [真实客户端、持久预算及免费标签契约](harness-pytrio.md)，冻结提交 b7713af。唯一真实流2次请求、1142服务端Token、预估0.01114030元，独立未来门控上线1次；宿主/断网Linux各240/240，144次Mock矩阵通过，13920批预测重建逐值一致。[结果与未验收边界](harness-pytrio-results.md)、[机器回执](validation/2026-11-07-pytrio-smoke.json) 为最新证据。用户充值50元未扩大本轮10次请求/.50元保护；原始输出位于 outputs/pytrio-smoke-20261107。三次迭代合规仍待官方口径和验收，真实流只有两轮尝试；不继续自动付费、不推远程、不上传SwanLab。

**后续更新（2026-11-07）：** 本文主体保留原交接时状态。其后 Mock Harness 已实现，宿主/断网 Linux 各 204/204，见 [验收](harness-mock-results.md)；PyTRiO 登录与目录查询已成功，见 [只读回执](validation/2026-11-07-pytrio-readonly.json)，用户报告充值 10 元，真实付费推理仍未验证。新收到的 [培训纪要及影响](competition-briefing-notes.md) 明确无需申请标签配额、四核八 G / 无 GPU / 2 G 提交包、至少三次尝试迭代、SwanLab 公开等补充口径，正式细节仍待材料核对。后续必须区分历史模拟标签配额与官方标签协议；`TrioLLMClient`、最多 10 次调用及 0.50 元预估费用上限仍为待确认方案，本次发送纪要不构成实施或付费授权。

**当前任务已转向：暂停继续优化数据切分、候选平局和分类模型；先重新对照赛题，梳理大模型 Harness、真实成本计量和无人值守稳定性的缺口。** 本轮只维护交接文档，没有批准新代码、调参、训练或实验。

## 1. 用户最新意图与授权边界

用户指出，我们过度投入传统机器学习的数据切分优化，忽略了赛题核心限制：大模型 Harness、算力/Token 成本以及工业场景稳定性。用户要求通过本文件交接给下一个对话窗口。

- 保留已有轻量模型、模拟器、预算、日志、门控、回滚和容器成果，作为后续 Harness 的工具及工程基线。
- 不自动续做上一条消息里的 Huber/IRLS 或双模型集成。那些方案尚未实施，也未获实现确认；本次重心调整优先于旧的讨论方向。
- 不再因局部模拟指标改善，就宣称已经攻克工业漂移、到达算法天花板或具备比赛优势。
- 下个窗口首先做只读核查，提交新的【诊断结论】及【准备采用的升级策略】，取得用户对具体一轮的明确确认后，才能写测试、代码和运行新实验。

## 2. 赛题原文：应当围绕什么交付

权威原文：[赛题 PDF](../c945f17fdaf0636a7a36aca3d4264fd8.pdf)，共 5 页；本轮重新提取并核对第 2–5 页。README 是摘要，不能替代原文及官方后续通知。

| 原文位置 | 已明确要求 | 对本项目的含义 |
| --- | --- | --- |
| 第 2–3 页 | 自动完成“漂移监测—诊断归因—实验优化—评估上线—回滚”；鼓励模型层与策略层两层自进化 | 单纯扩大候选搜索或调切分比例，不能充分展示受控策略改进与技术路线论证 |
| 第 2 页 | 支持基于大模型的智能体 Harness，也支持传统微调路线 | 不能误读为每个参赛方案都必须部署大模型；本项目若沿 Harness 路线，就要实证大模型的作用及成本 |
| 第 3 页 | 驱动 Harness 的大模型须选用选手通过 PyTRiO 平台训练得到的模型或 PyTRiO 的 Qwen3.8-27B | 通用 API、其他开源模型、规则或 mock 不能冒充获准模型；具体接入方式仍待确认 |
| 第 3–4 页 | 指定设备、统一离线环境、资源限制、隐藏测试流、无人干预 | 开发期云端服务如何衔接离线正式运行，需要官方协议澄清；不能默认正式运行可以访问公网 |
| 第 4 页 | 客观分主要考察单位增益消耗的算力、标注配额与大模型 Token | 不能只追求累计损失最低；须同时记录收益、训练/推理成本、标签成本和 Token 成本。精确评分公式尚未获得 |
| 第 4 页 | 基础门槛：按时自主完成；实验记录完整；综合性能不低于官方静态基线 | 稳定完成和审计完整是入场条件；本地 static 并非官方静态基线 |
| 第 3–5 页 | 提交系统镜像、模型配置与 Harness、云端实验记录依据及运行说明；提供 SDK 和《实验记录规范》 | 当前镜像与 SwanLab 归档是准备成果，正式入口、字段及输出协议尚未适配 |
| 第 4–5 页 | 预提取特征，基础任务可用 CPU；PyTRiO 额度仅在企业赛阶段提供 | 轻量预测模型可保留；不能由此推断 27B 大模型也可在本地 CPU 配额下运行 |

PDF 中关于平台“预计上线”的时间安排，不代表本机已经取得账号、额度或数据。后续官方通知优先。

## 3. 当前系统实际具备什么

当前是 **NumPy 固定基函数 Ridge + 本地规则控制器 + 受限决策接口**。分类和回归都使用轻量岭模型；不是 GP，没有种群、表达式树搜索、FSA、NSGA-II 或 QD。

| 层面 | 已有能力与入口 | 明确边界 |
| --- | --- | --- |
| 数据与标签 | [data.py](../ite/data.py)、[labeling.py](../ite/labeling.py)：模拟两任务、多种漂移、延迟标签、预算调度；先预测后申请/释放标签 | 尚未接官方数据/SDK。完整目标与漂移真值仅可用于隔离离线评分和诊断 |
| 监测与控制 | [monitor.py](../ite/monitor.py)、[controller.py](../ite/controller.py)：监测、有限候选、门控、历史模型、回滚；static/periodic/drift 对照 | 特征变化本身不能触发训练，也不能识别所有 P(y|x) 变化；收益依赖数据和供给 |
| 模型与训练 | [models.py](../ite/models.py)、[training.py](../ite/training.py)：线性/可选二阶基函数、加权 Ridge、检查点；spawn 子进程训练、超时终止及后续恢复 | 没有 Huber/IRLS 或双模型集成。工作进程清理存在额外耗时，不是硬实时保障 |
| 决策边界 | [decision.py](../ite/decision.py)：规则或离线 mock；只接受白名单内的窗口、alpha 建议；异常/非法建议回退 | 没有网络客户端或正式 PyTRiO 驱动。现在只是窄建议接口，并非已完成的大模型 Harness |
| 预算 | [budget.py](../ite/budget.py)：训练墙钟、尝试次数、标签及 Token 上限；预算用尽仍可继续预测 | 没有真实大模型调用成本证据；训练墙钟不能直接当 GPU 额度或官方计费 |
| 记录与交付 | [tracking.py](../ite/tracking.py)、[runner.py](../ite/runner.py)、[Dockerfile](../Dockerfile)：JSONL、预测、检查点、离线报告、源码指纹、显式 SwanLab 上传及断网容器 | 当前格式未获官方规范验收；SwanLab 上传与正式离线运行分开 |

运行顺序为：预测并记版本 → 申请标签 → 释放到期标签 → 观察监测 → 搜索/冻结/验收/部署。`deploy(k)` 从第 `k+1` 批预测开始生效；实际版本以 `events.jsonl` 的 `prediction` 事件为准，不能用 `curve.csv` 的观察后版本倒推。

### 默认配置与实验配置必须区分

[default.json](../configs/default.json) 加上 [config.py](../ite/config.py) 的默认值，仍保留历史兼容行为：`deployment_validation=legacy`、`selection_split=chronological`、`classification_tie_break=legacy`、`training_weighting=none`、`training_preflight=false`、`decision_backend=rules`、`max_tokens=0`；默认流长 36 批。

- `legacy` 会复用筛选证据作为上线比较，保留它是为了历史兼容，不能当成未来独立门控已默认启用。
- 近期实验使用 `deployment_validation=future`：候选冻结后，只用冻结后产生并按协议释放的标签做上线验收，同时最多一个待验收候选。未来任何新的 Harness 改造都要保留这个独立边界，不能为省成本而复用标签。
- 最近实验配置里的 h=4、训练预检、互斥切分等均是可选实验设置，未整体晋级为默认策略；不要把“代码已实现”写成“效果已验收”。
- `task_specific` 的历史实现直接检查 `config.scenario == "recurring"`，见 `controller.py` 的 `_experiment`。这是已知模拟场景条件下的研究选项，**不能用作未知真实流的场景识别或正式自适应路由**。用户已明确反对按模拟器 abrupt/gradual 等标签路由，后续不得推广这条路径。

## 4. 三个核心缺口及下一步应核查的内容

以下是待讨论范围，不是对下一轮实现的自动授权。

### 4.1 大模型 Harness：真实模型尚未进入闭环

当前 `DecisionAdvisor` 只把已观察摘要和允许的窗口/alpha 交给 provider；没有大模型驱动的完整诊断、实验计划及策略改进证据。规则闭环和 mock 测试可作为底座，不能冒充真实大模型能力。

下一窗口先只读梳理：工具与状态机边界是什么、哪些决策需要大模型、哪些由确定性代码保证、如何约束每次可执行动作。建议优先讨论受限结构化计划和白名单工具，不默认引入任意代码生成执行或无限自改写。

需要先确认 PyTRiO 模型标识、调用协议、额度、超时/取消方式，以及正式离线环境中的可用形式。缺接口时可在批准后补充离线协议/回放测试，但必须标记为替身验证，不能声称已经接通官方模型。

### 4.2 成本：当前计数器不足以证明收益/成本优势

`decision.py` 当前最多预留 64 个 Token 额度、验证 provider 返回的单个 `usage_tokens` 整数，并在未知用量时保守计费。它没有真实 tokenizer/服务账单核验，也未分别覆盖输入、输出、重试、缓存、失败和大模型推理时长。provider 还必须自行保证真实调用超时；训练子进程的超时不保护该调用。

默认 `tokens=0` 只表示没有调用大模型，不能解释为“大模型零成本”或“Harness Token 效率优秀”。

下一窗口应提出成本口径与边界方案：区分启动成本、预测、监测、候选训练、筛选/门控、大模型推理、失败和重试；明确预留、结算、超支拒绝及预算耗尽后的保底行为。官方公式未知时保留多维原始成本与性能对照，不自行发明一个“官方综合分”。真实模型接入后，才有条件比较规则基线、受控大模型方案及调用频率带来的边际收益。

### 4.3 工业稳定性：已有保障，仍有未验证边界

已具备的工程证据包括：失败候选保留当前模型、训练超时后可继续工作、预算耗尽继续预测、检查点拒绝非法状态、未来门控、候选等待结束处理、离线运行及来源校验。相关测试在 `tests/test_control.py`、`test_resilience.py`、`test_candidate_lifecycle.py`、`test_prospective.py`、`test_decision_interface.py`。

仍需重新审计的内容包括：

- 真实模型阻塞、服务不可用、非法输出、重复建议、重试风暴及 Token 耗尽的端到端降级；不能只以 mock 抛异常测试代替。
- 模型检查点恢复只验证预测一致；**完整流状态续跑尚未实现**，控制器、标签在途队列、预算和待验收状态并未形成完整恢复协议。
- 在线历史有容量限制，但模拟器、完整预测归档仍随流长增长；长流内存、磁盘、日志写入失败和正式输出时限尚需按协议验证。
- 当前数据隔离主要防意外泄露，同进程策略与评分接口不是恶意代码安全沙箱；若以后增加代码生成工具，需单独设计权限边界。
- 当前 4 CPU / 4 GiB 断网验收针对轻量引擎，不代表 27B 大模型已适配或满足官方资源要求。

优先解决哪一个缺口，应由下一轮只读证据和用户确认决定。不要同时重构 Harness、预算、恢复机制和预测算法。

## 5. 最新实验与不能重复走的路

阴性依据集中在 [negative-results.md](negative-results.md)，最新是 **NR-015**。最近链路为：启动标注（NR-009）→ 8 批训练来源窗口（NR-010）→ 样本可行性预检（NR-011）→ 时间衰减（NR-012）→ 近期标签互斥（NR-013）→ 任务级切分（NR-014）→ 分类精确平局偏好大 alpha（NR-015）。局部工程机制成立，不能据此推断整体晋级。

最新结果：[classification-tie-results.md](classification-tie-results.md)，预登记：[classification-tie-plan.md](classification-tie-plan.md)。两组各 72 次，共 144 次开发运行：2 任务 × 6 场景 × 3 种子 × static/drift × 2 组；每次 96 批，延迟 2、标注比例 .25、标签预算 864。

唯一因素是分类精确错误数平局时按 `(errors, -alpha, window)` 选择；回归及未来独立门控不变。drift 三种子均值如下，越低越好：

| 任务/场景 | 原平局对照 | alpha 优先 |
| --- | ---: | ---: |
| 分类 stable | .057400174 | .057400174 |
| 分类 abrupt | .223234954 | .224211516 |
| 分类 gradual | .224103009 | .225224248 |
| 分类 recurring | .477575231 | .477719907 |
| 回归 stable | .019779888 | .019779888 |
| 回归 abrupt | .453702647 | .453702647 |
| 回归 gradual | .460348595 | .460348595 |
| 回归 recurring | 1.080383365 | 1.080383365 |

分类突变未改善。seed 19 第 36 批改选 alpha=10 后，冻结候选仍在第 40 批未来门控中与当前模型同错 5/48，正确拒绝；该种子全流预测不变。拒绝候选无模型快照，不能补造它的全流表现，也不能据此证明所有分类算法已达上限。

周期均值虽优于本地 static，分类突变/渐变和回归突变/渐变相对历史 legacy 的退化仍超门槛，`candidate_passed=false`、四项失败，**默认未晋级**。最新历史测试为宿主 175/175、断网 Linux 175/175；这是已保存的历史回执，本轮只写文档，没有重跑测试或矩阵。

本地历史门槛：周期两任务均不劣于 static；其他五场景相对 legacy 的退化，分类不超过 .005、回归 NMSE 不超过 .01。它们不是官方门槛，后续若改变研究目标须重新预登记，不能为通过而事后改标准。

开发种子 `7/19/43` 可继续作为历史开发对照；`101/103/107/109/113`、`211/223/227/229/233` 已见，不得重新包装成独立验收。不得自动再跑 144 次矩阵；Harness 新阶段应先按其假设设计最小必要测试、成本对照和稳定性验证。

## 6. 环境、产物与可复核入口

- Windows / PowerShell，本地 Git 分支 `development`；Python 3.12.14，NumPy 2.3.5，SwanLab SDK 0.10.3。`.venv` 引用宿主运行时，不可当便携环境复制。
- Docker Desktop 的 Linux 引擎历史已完成构建、断网运行、导出和重新加载。Docker Hub 在 2026-11-04 已成功拉取，不再把历史网络失败当成当前必然阻塞；下次实际使用前核实引擎是否启动。本轮没有新拉取或构建。
- 基础镜像固定为 `python:3.12-slim@sha256:b18b261e1b4974b4f321451ad5251ded85abb22c2b8b262da527dda1d031ab30`；固定依赖见 [requirements.txt](../requirements.txt)、[requirements-tracking.txt](../requirements-tracking.txt) 和 Dockerfile。不要因新文档而重建旧效果镜像。
- SwanLab 工作空间/项目：`mring-Y/Intelligent_Training_Engine`，本机已登录；无需重复索取凭证，禁止把密钥放入聊天、文档或仓库。正式运行不隐式联网上传。

| 最新冻结/证据 | 位置或标识 |
| --- | --- |
| 本轮交接前的 Git HEAD（结果文档） | `bf7954a`，不是镜像源码提交 |
| 最新冻结运行源码 | `4b4890b983960ccf2c0696a137ed17ff52ea3efe` |
| 冻结源码 SHA-256 | `688768444ed9b4ffaa510b5549c35f132163ee1b1dab946182f1f7c4fb16b50b` |
| 原始两组运行与综合曲线 | [outputs/classification-tie-alpha-20261107](../outputs/classification-tie-alpha-20261107)、[report.html](../outputs/classification-tie-alpha-20261107/report.html) |
| 容器、协议及预测重建回执 | [验收 JSON](validation/2026-11-07-classification-tie.json) |
| 最新镜像 | `ite-local:classification-tie-alpha-20261107`，ID `sha256:d87168c0ede45e1291c633909c44d0e20c04bde0db31840a01685f6b7127709a` |
| 镜像 tar SHA-256 | `6425d5666dea5c967fc0bfe7fc86485fc7bb10aaa930e2726b2f4aeb19e27f67` |
| 最终本地交付 ZIP | [ite-classification-tie-delivery-20261107.zip](../outputs/ite-classification-tie-delivery-20261107.zip) |
| 最终 ZIP SHA-256 | `ab60aa4510e50781e5e09e7ef23419edcdce5f3400c0e5a180d002f7f76250ce`，包外 [交付回执](validation/2026-11-07-classification-tie-delivery.json) |
| 最新 SwanLab 归档 | [7s5w0kuz](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/7s5w0kuz)，144 次运行；本地实际上传 ZIP 已逐文件核验，未独立下载服务器副本 |

最近两组矩阵均为 4 CPU / 4 GiB / `--network none`、退出 0、无 OOM；墙钟约 56.44 / 56.62 秒。它们是轻量模拟矩阵的运行证据，不能换算成大模型推理成本或跨平台速度结论。

**保留用户原有改动：** 本轮开始时只有 `docs/negative-results.md` 未提交，首行有 6,524 个前导空格。本轮读取时文件 SHA-256 为 `0176f7dcb42502e3ea9b5f43629ff5ff4e8b4db63f19a767ad12c00c91bd203a`。不要清理、格式化、还原或顺手纳入交接提交；不要执行 `git add .`。

新交接文档及 README 入口属于文档维护，不改变冻结运行源码、旧镜像及旧交付包。源码来源、文档版本和镜像版本必须分开陈述。

## 7. 下一窗口的阅读与推进顺序

1. 读本文件、[AGENTS.md](../AGENTS.md)、[iteration-sop.md](iteration-sop.md)、[negative-results.md](negative-results.md)，再查 `git status --short`，保留既有用户改动。
2. 重读赛题 PDF 第 2–5 页，对照 [README](../README.md)、[architecture.md](architecture.md)、[runbook.md](runbook.md)，列出“明确要求 / 已有证据 / 缺口 / 需要官方确认”的表。
3. 只读审计 `decision.py`、`budget.py`、`controller.py`、`training.py`、`runner.py` 及对应测试，确认 Harness 权限、成本边界和故障路径；需要解释历史指标时查 NR-015 及其原始日志。
4. 给用户一份以 Harness、成本和稳定性为中心的分阶段提案，优先选择一个可本机验证的最小单元，说明真实模型缺失时能验证什么、不能验证什么，以及是否受硬件/服务条件阻塞。
5. 输出【诊断结论】与【准备采用的升级策略】，等明确确认后，再按 TDD 实施、宿主测试、断网 Linux 验证和预登记实验推进；未过门槛先追加阴性档案，再考虑下一项。

当前外部缺口：官方公开数据、隐藏流接口、SDK、评分脚本/公式、资源与标注协议、时限、《实验记录规范》、PyTRiO 账号/额度/模型调用及离线方式。本机没有部署获准 27B 模型，也没有本轮显存/量化可行性评估。先查项目已有资料；实际受阻时向用户提出具体条件，不重复索取已完成的 SwanLab 登录，也不自行下载部署大模型。

### 可直接粘贴到下一窗口的启动提示

> 请先阅读 `docs/handoff-next-session.md`、`AGENTS.md`、迭代 SOP、阴性档案和赛题 PDF。项目当前暂停传统 ML 数据切分、平局规则及 Huber/集成迭代，重心转向合规的大模型 Harness、算力/Token 成本和工业稳定性。先只读审计当前实现与赛题差距，给出【诊断结论】及【准备采用的升级策略】，等我确认后再按 TDD 写代码和做实验。保留用户在阴性档案中的未提交空格改动和全部原始输出，不把 mock、历史场景标记或本地成绩当成正式能力。
