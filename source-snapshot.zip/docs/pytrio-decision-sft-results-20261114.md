# PyTRiO 动作 SFT 结果

2026-11-14。本轮按已确认的 [执行计划](superpowers/plans/2026-11-14-pytrio-decision-sft.md) 完成一次 Qwen3.5-4B LoRA 动作 SFT。训练监督只作用于动作 marker 的一个 token，未监督自然语言理由；生产 Harness、CPU 模型、筛选和 future gate 没有修改。

本轮使用137条 train、70条 eval。配置固定为 rank 8、3 epochs、batch 16、学习率0.0001、seed 7、训练 attention/MLP、不训练 unembed。27个训练 batch 覆盖每个 epoch 的全部137条，累计411个监督位置、141120个本地精确训练输入 token。epoch监督loss为0.953009、0.549442、0.532347。最终权重为 `trio://run_mphtvnjpqb3d/sampler_weights/action-sft-final-epoch3`，续训 state 为 `trio://run_mphtvnjpqb3d/weights/action-sft-final-state-epoch3`。

动作评估使用同一70条公开开发记录和三个真实候选 token 的 prompt logprob：

| 策略 | Accuracy | Macro-F1 | NLL | Brier | 动作分布 |
| --- | ---: | ---: | ---: | ---: | --- |
| 基模 | 0.300000 | 0.292293 | 1.654400 | 0.904638 | NO19 / LARGE37 / HEAD14 |
| 恒NO | 0.800000 | 0.296296 | 6.907755 | 0.400000 | NO70 |
| SFT学生 | 0.800000 | 0.296296 | 1.110549 | 0.393522 | NO70 |

学生的概率质量和NLL有所改善，但三个动作的argmax完全退化为 `DO_NOTHING`；LARGE/HEAD召回均为0。因此预登记的“Macro-F1严格超过基模和恒NO”没有通过，不能称为有效动作策略。

把学生选出的动作映射到已归档 CPU 反事实臂后，学生70个去重状态对应72个原始来源变体，648份证据文件通过哈希复核。学生全部保留 static：A 的 Macro-F1/Accuracy、B 的 RMSE/MAE、C 的 RMSE/MAE/高估率/平均正向高估均与 static 相同，CPU保护通过但收益为0。A评估仍只有NO类，不能证明A干预泛化；公开数据也不能代表隐藏测试或官方总分。

本轮447个请求全部成功，无重试、超时或未知用量。按逐请求上取整的保守账本占用¥9.18，低于¥10；按原始 token 费率估算¥0.85610562，均不是服务商扣费回执。训练端没有独立 provider usage 字段，141120训练 token按本地精确提交记录并保留完整预留；采样端服务端用量为输入143298、输出420。

基模采样、训练/optimizer、学生采样的请求墙钟累计分别为27.074、69.922、30.647秒，不含全部客户端创建、模型加载与保存时间，不是远端GPU算力时间。SwanLab自动采集的硬件属于宿主电脑，不能据此认定远端训练GPU型号或GPU秒数；本轮没有远端GPU资源回执。训练响应的`token_count`是监督位置数，本轮未把它当成完整输入计费量。

SwanLab公开 run 已完成：[`6w6q826b`](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/6w6q826b)。原始训练、预测、checkpoint URI、账本、报告和验证回执保存在 `outputs/pytrio-decision-sft-20261114/paid-v1/` 及同目录 `records/`。完整[机器索引](validation/2026-11-14-pytrio-decision-sft.json)保存原始产物、测试与独立审阅的证据哈希。本轮源码冻结提交为 `3cc0a92f19a937275ebc76086e60ebd9bfa06373`；宿主634/634测试通过，最后只补充SwanLab记录覆盖的最终focused30/30在宿主与断网4 CPU/4 GiB Linux均通过，容器退出0且无OOM。

本轮不晋级默认、不追加训练或调参。完整失败归因和后续启示见 [NR-034](negative-results.md)。

收尾复核补充：独立审阅发现总CPU保护判定可能掩盖单场景退化，已在报告代码中修复为总体及 stable/abrupt/gradual 逐场景、逐包检查，并加入回归测试。该后处理修复不改 paid-v1 原始报告、训练输出或结论；31项 focused 测试在宿主和断网 Linux 均通过。
