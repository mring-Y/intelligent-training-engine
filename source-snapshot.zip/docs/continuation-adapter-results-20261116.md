# 官方CPU模型续训与独立预测适配（2026-11-16）

用户在[镜像兼容性诊断](image-protocol-audit-20261116.md)后明确要求“那你进行补齐操作”。本轮只补协议入口与产物交付，不改变A step7回放、B保留父模型、C head-only/2epoch、候选5秒/流20秒/最多4次及独立未来门控。没有新增依赖或付费请求，不上传平台。

## 实现

- 训练入口：`python train.py`或`python -m ite.continuation`，接受`--profile A|B|C --train <JSONL> --validation <JSONL> --from-baseline <官方父模型> --output <新目录> --stage-id <轮次>`；后续使用`--resume <平台选定父模型>`及对应`--parent-history`。
- 预测入口：`python predict.py --checkpoint <NPZ>`或`python -m ite.continuation predict --checkpoint <NPZ>`，stdin/stdout逐行JSONL，无须手动设置PYTHONPATH。只接收task（可省略）和inputs，不接收answer或隐藏标签；返回官方A类概率或B/C原单位非负数值。
- 模型交付目录只含真正的`checkpoint.npz`、`training.json`、`history.jsonl`及C的绑定策略sidecar。全目录总量检查64MiB后发布，检查点最后发布，已有输出目录拒绝覆写。详细审计另放相邻`.audit`目录。
- 复用原12批时序执行与规则/门控，使用传入数据的真实特征，无模拟漂移。梯度仅来自显式train；validation按时序揭晓，不并入梯度。平台可保留当前模型，本轮真实0训练/0更新时明确记录。
- 父模型无效或schema不匹配直接失败，不回退镜像内初始模型。保存权重、Adam状态、标准化、累计steps/epochs；第二轮只使用平台指定父模型，即使上一轮本地门控选择过另一个候选。
- 保存实际事件及候选参数/步数、输入和源码/模型哈希，不伪造逐epoch loss；初始官方历史仅在模型哈希与固定官方起点匹配时按原字节保留。历史前缀哈希与父模型链检查、已用train/validation ID记账跨轮保留。未知祖先不因下一轮生成了日志就变成已知来源。

调用约定随镜像存放于`/app/configs/continuation-contract.json`。它是本项目基于现有官方baseline的明确接入约定；平台尚未提供完整实际启动合同，不能把本地通过写成官方平台已认可。

## 参数示例

显式命令（路径均为容器内平台挂载位置，需按平台实际路径填写）：

```text
python /app/train.py --profile C --train /input/train.jsonl --validation /input/validation.jsonl --from-baseline /input/checkpoint.npz --output /artifacts/round-1 --stage-id round-1
python /app/train.py --profile C --train /input/train.jsonl --validation /input/validation-next.jsonl --resume /parents/checkpoint.npz --parent-history /parents/history.jsonl --output /artifacts/round-2 --stage-id round-2
python /app/predict.py --checkpoint /artifacts/round-2/checkpoint.npz
```

也支持`ITE_PROFILE/ITE_TRAIN/ITE_VALIDATION/ITE_PARENT_CHECKPOINT/ITE_OUTPUT/ITE_STAGE_ID/ITE_PARENT_HISTORY/ITE_LABEL_PROVENANCE`环境变量。环境变量父模型默认按resume处理；首次明确起点请用`--from-baseline`。B必须提供真实标签来源声明（`--label-provenance`），本适配器检查声明结构但不冒充主办方审批。

只有匹配官方初始检查点的首次显式起点，或带完整可绑定历史的父模型，才允许新candidate/future验收；resume缺失完整历史时保存传入父模型并报告原因。已见过的验证或训练样本不能重新包装成future独立数据。零更新并不被本公告直接禁止；若正式协议另要求每轮必须发生训练，需要按实际合同核对。

## 验证记录

工作计划见[实施计划](superpowers/plans/2026-11-16-continuation-adapter.md)。本轮先写11项测试，确认入口缺失及行为失败后实现；新增历史与发布边界测试分别先复现失败再修复。最终本轮19项聚焦测试通过，202.705秒。原始失败、修复及通过输出位于`outputs/continuation-adapter-20261116/records/01`至`13`。

覆盖真实A候选从外部父模型续接、B外部已续训父模型字节保留、两个轮次父链、平台不选候选、历史缺失/截断、训练/验证跨角色复用、官方初始训练ID、NPZ大小与独立预测。已有B/C/A官方底层训练与推理代码保持，预测由NumPy1.26.4常驻子进程执行。

最终验证和交付状态见[完成补记](continuation-adapter-completion-20261116.md)。此处的早期执行状态记录保留作时间顺序证据。

宿主第一次完整测试实际运行736项、661.543秒，735项通过；既有`test_isolated_runtime_reports_metadata_versions_without_sdk_version_attribute`在导入`.venv-sft`依赖时超过原15秒时限，原始日志`records/14-host-full-tests.txt`保留。未修改该模块、依赖或时限；同一测试单独复核通过（15.428秒为包含测试框架的总耗时），见`records/17-host-timeout-recheck.txt`。完整回归按原条件重新运行，结果待收齐，不将单项通过写成首轮全套通过，也不将工程环境超时混作策略阴性效果。

完整回归第二次运行736/736通过，691.986秒，退出0；原始输出为`records/18-host-full-tests-rerun.txt`。所有时限、固定依赖和源码保持；首次完整日志与单项复核仍保留。构建上下文213份文件与源码快照一致，两个已有配置与Git索引仅有换行差异，211份完全一致，无实质源码差异。夹具原始摘要和三种数据角色间ID互斥已复核，见`records/19`至`21`。

公开数据协议测试夹具保存在`outputs/continuation-adapter-20261116/fixtures-v1/`：A445行原训练、每轮622行验证；B/C固定顺序等距最多720行训练、每轮512行验证。两轮验证ID互斥，无特征偏移或标签改动。它们是已见公开数据的接线检查，不是新的泛化或效果验收，原A微增/B持平/C公开开发RMSE下降约2%与`effect_passed=false`结论不变。
