# 30批三次突变与数据接口验收

三次连续 Mock 门控链的逐候选、训练来源和Loss明细见[详细报告](triple-drift-mock-report.md)。144次 Mock 的范围和限制见[PyTRiO结果报告](harness-pytrio-results.md)。

2026-11-08，按用户确认的[四项计划](superpowers/plans/2026-11-08-three-abrupt.md)实施。**接口和降级工程验证通过，真实三次未来门控目标未达成。** 没有追加付费流，没有调整15秒截止、突变点、种子或验收门槛，没有算法效果晋级。

## 唯一真实流

分类、seed7、30批、drift，初始A，零基批次2/10/18切换B/A/B。处理批4第一次请求在 **15.0053992秒** 达到端到端截止；子进程终止、预算熔断、冻结v0。随后完成30/30批预测，未返回可解析Action，训练/冻结/未来验收/上线均0。实际预测版本全为v0，熔断后没有新的LLM、训练、模型切换或标签申请；已申请480条标签，剩余192条在途标签继续释放，仅用于审计。

真实错误率0.6496527777777777，是冻结初始模型在本条反复翻转合成流上的结果。没有新的真实static/gradual/stable效果对照或回归真实流；工程测试不能冒充这些测量。日志没有服务端回执和分段计时，无法判断超时发生在冷启动、网络还是服务生成阶段，不称为纯API延迟。

已知结算Token为0，**本次实际Token和扣款未知**。共享账本保留输入2048+输出512=2560Token及 **0.03017216元** 费用预留；这不是已核实的实际扣款。请求次数1/5，未自动重试。`outputs/three-abrupt-paid-state/{run-claim.json,execution-started.json,paid-call-ledger.json}` 锁定本轮执行；更换输出目录不能自动重置额度。容器调用必须持久挂载整个outputs，不能通过换容器丢弃声明和账本。

原始流、不可解析/超时事件、账本副本与审计在 `outputs/three-abrupt-20261108/real`；实际失败回执 `records/26-real-run.txt`。阴性结果已追加NR-016，保留用户已有档案字节。正式“三次迭代”的官方计数口径仍待确认，本轮真实链数0，不能用于宣称满足门槛。

## Mock独立未来门控证据

同一冻结源码和固定配置的Mock四次RETRAIN_SMALL，32模拟Token、真实Token0；一次止于筛选，另外三条完整门控链如下。所有损失观察来自已释放标签，突变真值只在离线清单和诊断中。

| 决策 | 冻结批 | 独立标签来源 | 验收批 | 样本 | 结果/开始使用 |
| --- | ---: | ---: | ---: | ---: | --- |
| decision-1 | 无 | 无 | 无 | 无 | 批4筛选拒绝，不计未来门控 |
| decision-2 | 8 | 9 | 11 | 96 | 通过；预测12起使用 |
| decision-3 | 15 | 16 | 18 | 96 | 通过；预测19起使用 |
| decision-4 | 22 | 23 | 25 | 96 | 通过；预测26起使用 |

Mock错误率0.6770833333333335，不宣称效果改善：概念在批10/18再次变化，延迟标签门控可在旧概念证据上合法通过。三次“执行正确”是协议和来源时序结论，不等于变化后的模型总能更好。没有向LLM暴露突变时间、强制动作、降低增益阈值或删除中间拒绝记录。全部JSON Schema、window/alpha白名单、预检、冷却和未来门控保持。

`decision_id → attempt_id → candidate_id`贯穿日志。审计逐项检查原始真实JSON与解析动作、独立决策与唯一尝试、预测完整性、标签申请/释放数量与延迟、最少32未来标签、冻结后来源和下一批版本。无效或重复证据不能凑出三链成功。单次专用付费入口要求同源码/配置的合成Mock预检；CLI和Runner共享执行边界，禁止绕过前置声明。

## 数据和公开归档

[OfficialDataProvider](official-data-provider.md)及CSV/Parquet实现已接Runner，分批yield纯特征PublicBatch，显式列映射；预测提交后才可申请/释放标签。真实Parquet测试无跳过。记录文件、初始数据指纹、列映射、批边界和延迟；官方数据不套用模拟漂移真值。当前训练器支持数值特征、二分类0/1和数值回归，多分类、波形特征与RUL单位需要按正式任务适配，不能保证只改字段即可解决所有未知任务。

SwanLab已核验Public及无认证结构化项目身份。公开归档：[8qr4s306](https://swanlab.cn/@mring-Y/Intelligent_Training_Engine/runs/8qr4s306)，包含宿主Mock和真实失败两流；本地上传ZIP含30个文件，逐文件字节和哈希均核验。SHA256 `1f1af9d89fea7b3de932cc533ea0169013a827188a60fedce57b98049128eaeb`。每个Action用独立`audit/action_json` Text展示Observation/Action/Reason、ID和执行状态，未来门控另有`audit/gate_json`；真实超时没有Action，保留观测、失败和熔断事件。上传前后均验证匿名Public，不仅依赖init(public=True)；无凭证、tokenizer或原始官方数据上传。SDK上传完成，未独立下载服务器ZIP副本。

## 测试、容器和成本上界

TDD红绿及独立审查回执保存在本轮records。宿主 **278/278（169.299秒）**、断网Linux **278/278（19.819秒）**，均无跳过。Linux实际限制cpu.max=400000/100000、memory.max=8589934592，测试峰值258387968字节，退出0、无OOM。核心stable/abrupt/gradual和故障路径由测试覆盖，未跑144矩阵。

最终运行镜像在断网4核8GiB下另跑固定Mock30批，实际BoundedTrainer完成同样四次建议/三条未来门控，峰值64520192字节。镜像导出重载后，只读重建宿主真实+Mock共60批预测，最大绝对差0.0，无重训或API调用。资源回执分别保存，不把Mock/Linux内存说成真实付费流的内存测量。

包含PyTRiO、HTTP、SwanLab、PyArrow及本地tokenizer的完整CPU运行镜像为 **949862622字节**，导出tar **210962944字节**，均低于保守2,000,000,000字节限制。没有Torch/GPU运行时或模型权重。固定基础镜像摘要和全部依赖锁版本；构建安装依赖时联网，实际Linux测试/Mock/重载均network=none。官方内网地址和SDK仍待对齐，上游tokenizer许可副本尚未归档；这是工程交付，不能宣称正式提交合规已全部验收。

100批成本投影以合格漂移调用数K为参数。有5次上限时，配置最坏为min(K,5)×2560Token，K≥5时 **12800Token / 0.15086080元**；本次0.16元预算和80%Token阈值仍包裹在请求外。价格沿用2026-11-07核实的输入8.41/输出25.29元每百万Token，不假设缓存折扣。本轮没有成功响应样本，不能计算新的平均Token费用或P95。机器成本审计为`real/cost-audit.json`，答辩摘录为`cost-slide-notes.md`。

## 冻结来源

- 实现提交：`6f03dff1df144aec0b7e0ab8abc5fb35cde673b4`；源码SHA256：`d825a0cfa647b8f72639cddbfcd977649b4c7f3f1eed3a3f8ac79df66dc9de1c`。
- Git源码ZIP：`d679bb2ff1e77ba31b2ecbcb874c0118840b61b5ebaa995938c0fe66dee74e1c`；容器由提交快照构建，不包含用户已有文档修改。宿主与Linux的Python分别3.12.14/3.12.16，均记录实际环境。
- 运行镜像：`ite-local:three-abrupt-20261108`，ID `sha256:3cc5dd003e976dde6fefdef7832cc86c4d2e3cfafca36f4ac2e435e3cc2b1f1e`。
- 导出tar SHA256：`f87fd937b451b06411c8c8b3e8eb45657de0f8ddfecf8aa812dfe5ed3fc54943`；重载身份一致。
- 本轮机器验收：[validation/2026-11-08-three-abrupt.json](validation/2026-11-08-three-abrupt.json)。结果文档提交与实现/镜像提交分开记录；仅本地Git，不推送远程。
