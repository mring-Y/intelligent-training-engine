# 安全树模型接入设计

本文件备案未来的低风险接入方案；当前生产默认保持 Ridge，本设计不代表树模型已在官方 A 包上验证。

## 建议范围

优先只对回归任务增加可选 `TreeModel`，以 `model_type="tree"` 明确启用；默认值仍为 `ridge`，分类、旧配置、Ridge checkpoint 和现有预测路径保持不变。训练端在受限子进程中使用固定版本的 `sklearn.tree.DecisionTreeRegressor`，采用固定随机种子、最大深度/叶节点/最小叶样本数上限、单线程，并继续受 `BoundedTrainer` 的墙钟与资源预算约束。候选仍通过现有独立未来标签门控，不能以历史筛选成绩直接部署。

应先用官方 A 包做同一批次、同一标签预算、同一切分的配对 Ridge 对照，分别报告稳定、突变、渐变的误差、训练时间和模型大小。只有预登记门槛通过后，才单独批准接入；不以合成非线性基准结果替代该门槛。

## 序列化选择

| 方案 | 风险 | 成本 | 结论 |
| --- | --- | --- | --- |
| `joblib` / pickle | 加载过程可执行任意 pickle payload；断网不消除恶意文件风险；sklearn/Python 版本耦合 | 最低 | 不用于 checkpoint，也不在运行时加载外部 pickle |
| JSON 节点表 | 数据可读、可审计；大树文件膨胀明显，浮点往返和解析内存开销较高 | 中 | 可用于小型调试导出，不作为主要 checkpoint |
| NPZ 数组 + 自定义遍历 | `allow_pickle=False` 时只读数值数组；需自行严格验证树拓扑和预测器正确性 | 中 | 推荐。训练可依赖 sklearn，持久化和在线预测不依赖 sklearn estimator 对象 |

## NPZ 格式

持久化仅包含固定 `format_version` 和数值数组，不保存 estimator 对象、object dtype、Python 类名或可执行内容：

- `children_left`、`children_right`：长度为节点数的整数数组，叶节点值为 `-1`。
- `feature`：内部节点特征索引；叶节点使用 `-2`。
- `threshold`：每节点 float64 阈值；内部节点必须有限。
- `value`：每节点一个回归叶值的 float64 数组。
- 可选 `impurity`、`weighted_n_node_samples` 仅用于审计，不参与在线遍历。

加载时先限制 NPZ 文件字节数，并检查 ZIP member 白名单及每个 member 的压缩/解压尺寸上限，避免压缩载荷造成内存耗尽；随后使用 `np.load(path, allow_pickle=False)`。拒绝额外或缺失字段、错误版本、object dtype、尺寸不匹配、超出节点/特征上限、非有限数、越界 child/feature 索引、单边 child、非法叶节点字段、重复父节点、环、不可达节点及违反深度/叶节点上限的拓扑。根节点固定为 0。校验通过后由 `TreeModel.predict` 从根开始，按 `x[feature[node]] <= threshold[node]` 选择左/右子节点，直到叶节点并读取其回归值；遍历步数也受最大深度约束。输入特征维度与有限值校验沿用现有模型契约。

写盘采用临时文件、flush/fsync 后原子替换；输出目录权限受控，并将格式版本、模型配置和文件 SHA-256 写入运行 provenance。Checkpoint 只接收由本进程训练出的 NPZ；来自数据包的 NPZ 仍需经过同一结构校验，不能因文件扩展名可信。

## 兼容性与验收

未来实施应先增加失败测试，再分步改造配置解析、模型工厂、隔离 worker 返回值和 checkpoint 加载器。保持统一的 `fit(X, y)` / `predict(X)` 行为，使用显式模型类型分发 `state/from_state/save/load`，不能静默把未知类型当 Ridge。训练 worker 返回经过限制的节点数组；在线进程从校验过的状态构造轻量 `TreeModel`，避免持久化 pickle。

必要测试包括 sklearn 与自定义遍历对同一输入的逐值预测一致、二分类范围外特征/非有限输入拒绝、损坏 NPZ 拒绝、恶意拓扑（环、越界索引、孤立节点、重复父节点）拒绝、旧 Ridge checkpoint 向后兼容、子进程超时回收、独立未来门控仍生效，以及在固定 4 核/内存/断网 Linux 容器中的训练时限和包体积验收。依赖必须固定版本；若官方镜像缺少 sklearn，则该模型选项在配置验证阶段明确拒绝启用，不触碰 Ridge 路径。
