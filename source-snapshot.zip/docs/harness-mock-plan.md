# Mock LLM Harness：已确认设计与实施计划

2026-11-07。用户已明确批准接口设计、失败关闭熔断、冻结当前模型及取消 pending（含在途标签）语义，并要求直接 TDD 实施。本轮是架构/协议验收，不作效果晋级，不跑大矩阵。

## 诊断与范围

现有 DecisionAdvisor 只在实验内部建议窗口/alpha；Runner 独立申请标签；Controller 在漂移判断前验收 pending。旧 legacy 模式仍可更新，不是静态预测。NR-015 的175项历史测试通过与效果失败分别保留，不能当作本轮证据。

新增 Harness 模式由配置显式启用，使用 `future`、训练预检和未来标签容量检查；禁止模拟场景分路。原 rules/mock 路径及默认配置保持。熔断进入不可自动恢复的 STATIC_FALLBACK：冻结当时模型，不申请标签、不训练、不调用客户端、不切模型；到期标签只作审计/最终评分。

## 接口

- `ite/harness.py`：Observation/Action JSON Schema、严格验证、BaseLLMClient、LLMReply、MockLLMClient。Observation 固定至多5个来源批次，只用当前部署版本已揭晓标签的原预测误差。Action 仅 action/reason。
- `MockLLMClient.get_decision(observation)`：正常模式报警返回 RETRAIN_SMALL，否则 DO_NOTHING；每次8模拟Token。配置支持 normal/token_exhausted/invalid_json；耗尽模式抛出明确的客户端预算异常，由Guard保守结算预留并熔断。真实Token保持0。
- `ite/budget_guard.py`：ACTIVE/STATIC_FALLBACK、调用预留/结算、严格动作解析、预算边界；已用量>=80%或预留触及80%、标签剩余0、非法响应/异常/超时/用量错误均失败关闭。
- SMALL 使用最小白名单窗口、全部白名单alpha；LARGE 使用全部既有窗口/alpha；ROLLBACK 只筛选上一部署快照并冻结，最终独立未来门控保持。

## TDD 执行单元

- [x] 1. 先新增 `tests/test_harness.py`，观察缺失契约/客户端失败；实现 `ite/harness.py`，验证严格JSON、观测限制、动作和异常开关。
- [x] 2. 先新增 `tests/test_budget_guard.py`，观察80%边界、预留/结算、标签耗尽和故障失败；实现Guard，验证错误调用计费和锁定状态。
- [x] 3. 先新增 Controller/Runner 测试：五批趋势、版本年龄、预检、动作白名单、回滚未来门控、同批熔断优先于验收、pending取消及停止标签申请；再接入config/controller/runner，旧路径完整回归。
- [x] 4. 使用真实轻量模型和训练子进程验证stable/abrupt/gradual两任务核心链路。测试分别覆盖接受、拒绝与熔断，不能降低生产门槛制造通过。保存JSONL/预测/检查点及核心链路摘要，不做144次矩阵。
- [x] 5. 宿主完整unittest；独立代码审查；冻结源码提交，固定基础摘要/依赖构建Linux测试镜像，4CPU/4GiB/断网完整测试及核心链路，保存镜像来源/退出状态/时间回执。
- [x] 6. 更新使用说明与验证报告，本地Git提交明确列出的文件，保留用户negative-results.md原有改动，不推送、不上传云端、不发布。

## 验收与成本

所有新增行为都有先红后绿记录；旧模式不受Guard影响。预算达到边界后的模型版本、训练次数、LLM调用和标签申请量不再增加，剩余预测完整。部署只允许来源批次严格晚于冻结批次且已到期的标签，deploy(k)只影响k+1预测。Mock用量与真实用量分列，不宣称大模型收益。JSON运行校验使用标准库，不新增依赖或改变基础镜像摘要。

本轮只验证批准的协议行为；若效果未运行，明确写未测。需要新增因素或扩大效果矩阵时重新确认。既有用户阴性文档SHA256为0176f7dcb42502e3ea9b5f43629ff5ff4e8b4db63f19a767ad12c00c91bd203a，实施与提交时保持。
