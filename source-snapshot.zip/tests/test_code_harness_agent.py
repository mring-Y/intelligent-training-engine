"""No model-service failures or retrospective results may invent completed rounds."""

import json
import tempfile
import unittest
from decimal import Decimal
from pathlib import Path


class CodeHarnessAgentTests(unittest.TestCase):
    def module(self):
        from ite import code_harness_agent
        return code_harness_agent

    def test_explicit_27b_session_uses_its_tariff_and_retains_unknown_cost_on_timeout(self):
        from unittest.mock import Mock
        m = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            prior = root / "prior.json"
            prior.write_text(json.dumps({"requests":{"old":{"reserved_cny":"9.40"}}}))
            session = m.PaidToolSession(root/"network", root/"state", prior,
                model="Qwen/Qwen3.8-27B", renewal_cny="29.99", max_proposal_corrections=2)
            claim = json.loads((root/"state/claim.json").read_text())
            self.assertEqual(claim["model"], "Qwen/Qwen3.8-27B")
            self.assertEqual(claim["maximum_calls"], 108)
            self.assertEqual(claim["reservation_per_call_cny"], "0.04")
            self.assertEqual(session.client.model, "Qwen/Qwen3.8-27B")
            self.assertEqual(Path(session.client.tokenizer_path).name, "tokenizer")
            self.assertEqual(session.client.timeout_seconds, 15)
            session.tokenizer = Mock()
            session.tokenizer.apply_chat_template.return_value = "prompt"
            session.tokenizer.encode.return_value = [1]*100
            session.client.get_messages = Mock(side_effect=TimeoutError())
            with self.assertRaises(TimeoutError):
                session.ask("read", {"context":{"profile":"A"}})
            with self.assertRaises(RuntimeError):
                session.ask("read", {"context":{"profile":"A"}})
            self.assertEqual(session.calls, 1)
            self.assertEqual(session.ledger.reserved_cny, "0.04")
            self.assertEqual(session.ledger.data["requests"]["tool-001"]["metadata"]["model"], "Qwen/Qwen3.8-27B")

    def test_27b_settlement_uses_27b_prices_instead_of_the_default_4b_tariff(self):
        from unittest.mock import Mock
        from ite.harness import LLMReply
        m = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            prior = root/"prior.json"
            prior.write_text(json.dumps({"requests":{"old":{"reserved_cny":"9.40"}}}))
            session = m.PaidToolSession(root/"network", root/"state", prior,
                model="Qwen/Qwen3.8-27B", renewal_cny="29.99")
            session.tokenizer = Mock()
            session.tokenizer.apply_chat_template.return_value = "prompt"
            session.tokenizer.encode.return_value = [1]*4000
            session.client.get_messages = Mock(return_value=LLMReply(
                '{"tool":"read_public"}', 4700, "real", 4000, 700, "stop"))
            session.ask("read", {"context":{"profile":"A"}})
            row = session.ledger.data["requests"]["tool-001"]
            self.assertEqual(row["rounded_cost_estimate_cny"], "0.04")
            self.assertEqual(json.loads((root/"network/provider-events.jsonl").read_text())["model"],
                             "Qwen/Qwen3.8-27B")

    def test_27b_assets_are_verified_before_any_paid_reservation(self):
        from unittest.mock import patch
        m = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            prior = root/"prior.json"
            prior.write_text(json.dumps({"requests":{"old":{"reserved_cny":"9.40"}}}))
            session = m.PaidToolSession(root/"network", root/"state", prior,
                model="Qwen/Qwen3.8-27B", renewal_cny="29.99")
            with patch("ite.official_sft_teacher.verify_teacher_tokenizer",
                       side_effect=ValueError("Teacher tokenizer digest mismatch")):
                with self.assertRaisesRegex(ValueError, "digest mismatch"):
                    session.ask("read", {"context":{"profile":"A"}})
            self.assertEqual(session.calls, 0)
            self.assertEqual(session.ledger.reserved_cny, "0.00")

    def test_unknown_model_cannot_create_a_paid_claim(self):
        m = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            prior = root/"prior.json"
            prior.write_text(json.dumps({"requests":{}}))
            with self.assertRaises(ValueError):
                m.PaidToolSession(root/"network", root/"state", prior,
                    model="unapproved/model", renewal_cny="29.99")
            self.assertFalse((root/"network").exists())
            self.assertFalse((root/"state/claim.json").exists())

    def test_remaining_budget_keeps_all_previous_reservations(self):
        m = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            ledger = Path(tmp)/"previous.json"
            ledger.write_text(json.dumps({"requests": {"a": {"reserved_cny": "9.18"}},
                                          "stopped": False, "total_cny": "10.00", "version": 1}))
            self.assertEqual(m.remaining_budget(ledger), Decimal("0.82"))
            self.assertEqual(m.digest(ledger), m.digest(ledger))
            ledger.write_text(json.dumps({"requests": {"a": {"reserved_cny": "10.01"}}}))
            with self.assertRaises(ValueError):
                m.remaining_budget(ledger)
            ledger.write_text(json.dumps({"requests":{"a":{"reserved_cny":"9.18"}},
                                          "stopped":True,"total_cny":"10.00"}))
            with self.assertRaises(ValueError):
                m.remaining_budget(ledger)

    def test_final_budget_reservation_fits_remaining_cumulative_cap(self):
        m = self.module()
        from ite.decision_sft import BudgetLedger
        reserve=Decimal(BudgetLedger.rounded_request_cost(m.INPUT_LIMIT,m.OUTPUT_LIMIT,
            m.INPUT_PRICE,m.OUTPUT_PRICE))
        self.assertLessEqual(36*reserve,Decimal("0.82"))
        self.assertGreater(42*reserve,Decimal("0.82"))

    def test_remaining_budget_adds_previous_tool_ledger_without_resetting_it(self):
        m = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            old=Path(tmp)/"old.json"; prior=Path(tmp)/"prior-tool.json"
            old.write_text(json.dumps({"requests":{"a":{"reserved_cny":"9.18"}},"stopped":False}))
            prior.write_text(json.dumps({"requests":{"b":{"reserved_cny":"0.04"}},"stopped":False}))
            self.assertEqual(m.remaining_budget(old,[prior]),Decimal("0.78"))

    def test_explicit_budget_renewal_carries_unknown_reservations_without_touching_old_ledgers(self):
        m = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            paths=[]
            for n,amount,state,stopped in ((1,"9.18","settled",False),(2,"0.04","settled",False),
                                            (3,"0.02","unknown",True)):
                p=root/f"prior-{n}.json"
                p.write_text(json.dumps({"requests":{f"old-{n}":{"reserved_cny":amount,"state":state}},
                                         "stopped":stopped}))
                paths.append(p)
            original=[p.read_bytes() for p in paths]
            with self.assertRaises(ValueError):
                m.remaining_budget(paths)
            self.assertEqual(m.remaining_budget(paths,renewal_cny="29.99"),Decimal("20.75"))
            session=m.PaidToolSession(root/"network",root/"state",paths,renewal_cny="29.99")
            self.assertEqual(session.total_budget_cny,Decimal("29.99"))
            self.assertEqual(session.remaining,Decimal("20.75"))
            claim=json.loads((root/"state/claim.json").read_text())
            self.assertEqual(claim["prior_reserved_cny"],"9.24")
            self.assertEqual(claim["cumulative_limit_cny"],"29.99")
            self.assertEqual(claim["renewed_budget"],True)
            self.assertEqual([p.read_bytes() for p in paths],original)
            self.assertEqual(session.calls,0)

    def test_renewed_budget_must_be_finite_positive_and_strictly_below_thirty(self):
        m = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/"prior.json"
            p.write_text(json.dumps({"requests":{"old":{"reserved_cny":"9.24","state":"settled"}}}))
            for limit in ("30.00","30.01","NaN","Infinity","0","-1",True):
                with self.subTest(limit=limit),self.assertRaises(ValueError):
                    m.remaining_budget(p,renewal_cny=limit)

    def test_renewed_session_still_latches_on_its_own_first_timeout(self):
        m = self.module()
        from unittest.mock import Mock
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); prior=root/"prior.json"
            prior.write_text(json.dumps({"requests":{"old":{"reserved_cny":"9.24","state":"unknown"}},
                                          "stopped":True}))
            session=m.PaidToolSession(root/"network",root/"state",prior,renewal_cny="29.99")
            session.tokenizer=Mock()
            session.tokenizer.apply_chat_template.return_value="prompt"
            session.tokenizer.encode.return_value=[1]*100
            session.client=Mock()
            session.client.get_messages.side_effect=TimeoutError()
            with self.assertRaises(TimeoutError):
                session.ask("read",{"context":{"profile":"A"}})
            with self.assertRaises(RuntimeError):
                session.ask("read",{"context":{"profile":"A"}})
            self.assertEqual(session.client.get_messages.call_count,1)
            self.assertEqual(session.ledger.reserved_cny,"0.02")
            self.assertTrue(session.ledger.data["stopped"])

    def test_model_reads_sources_then_decides_from_each_observed_result(self):
        m = self.module()
        from ite.code_harness import candidate_source
        calls, selections = [], []
        class Run:
            completed_rounds = 0
            def read_public(self, paths):
                calls.append(("read", paths))
                return {"TASK.md": "official public task"}
            def context(self):
                return {"completed_rounds": self.completed_rounds}
            def experiment(self, source, hypothesis):
                calls.append(("fit", source))
                return {"round": self.completed_rounds+1, "gate_passed": False}
            def select(self, choice, reason):
                selections.append(choice)
                self.completed_rounds += 1
            def finish(self):
                return {"completed_rounds": self.completed_rounds}
        responses = [{"tool":"read_public", "paths":m.PUBLIC_PATHS}]
        for n in range(10):
            responses.append({"tool":"select_and_experiment", "selection":"incumbent",
                "selection_reason":"Previous candidate failed." if n else "Official initial checkpoint.",
                "source":candidate_source(4 if n%2==0 else 3,"full"), "hypothesis":"One factor."})
        responses.append({"tool":"finish", "selection":"incumbent", "reason":"No gain."})
        observed = []
        def ask(stage, payload):
            observed.append((stage, payload))
            return responses.pop(0)
        result = m.run_agent(Run(), ask)
        self.assertEqual(result["completed_rounds"],10)
        self.assertEqual(len([c for c in calls if c[0]=="fit"]),10)
        self.assertEqual(len(selections),10)
        self.assertEqual(observed[2][1]["last_result"]["round"],1)

    def test_do_nothing_cannot_be_converted_to_a_training_trial(self):
        m = self.module()
        class Run:
            def context(self): return {}
            def read_public(self, paths): return {}
            def experiment(self, *a): raise AssertionError("must not fit")
        with self.assertRaises(ValueError):
            m.run_agent(Run(), lambda *a: {"tool":"DO_NOTHING"})

    def test_all_four_public_documents_must_be_read_before_the_first_code_proposal(self):
        m = self.module()
        class Run:
            def context(self): return {}
            def read_public(self, paths): raise AssertionError("incomplete read must be refused")
        with self.assertRaises(ValueError):
            m.run_agent(Run(), lambda *a: {"tool":"read_public", "paths":["TASK.md"]})

    def test_system_prompt_excludes_repeating_the_official_parent_configuration(self):
        m = self.module()
        self.assertIn("严禁原样重复", m.SYSTEM)
        self.assertIn("allowed_next_configs", m.SYSTEM)

    def test_first_selection_is_distinguished_from_candidate_parameters(self):
        m = self.module()
        self.assertIn("selection只选择父检查点", m.SYSTEM)
        self.assertNotIn("首轮仅确认官方起点", m.SYSTEM)

    def test_invalid_candidate_receives_feedback_without_duplicate_fits_or_selections(self):
        m = self.module()
        from ite.code_harness import TenRoundRun,candidate_source
        from tests.test_code_harness import Model,dataset
        fits=[]
        def train(parent,*args,**kwargs):
            fits.append(kwargs)
            return Model(0.,f"candidate-{len(fits)}",parent.steps+1),.01
        configs=m.RehearsalActor.configurations
        calls=[]
        with tempfile.TemporaryDirectory() as tmp:
            run=TenRoundRun(Path(tmp)/"run",dataset(),Model(),trainer=train)
            stage_count={"read":0,"experiment":0,"finish":0}
            def ask(stage,payload):
                calls.append((stage,payload))
                stage_count[stage]+=1
                if stage=="read":return {"tool":"read_public","paths":m.PUBLIC_PATHS}
                if stage=="finish":return {"tool":"finish","selection":"incumbent","reason":"No gain."}
                # The second round commits the first selection, then sees bad
                # source. Correction must not select that prior result twice.
                bad=stage_count[stage] in (1,3)
                epochs,policy=(run.previous["epochs"],run.previous["trainable_policy"]) if bad else configs[len(fits)]
                if stage_count[stage] in (2,4):self.assertIn("tool_error",payload)
                return {"tool":"select_and_experiment","selection":"incumbent",
                    "selection_reason":"Retain checkpoint.","source":candidate_source(epochs,policy),
                    "hypothesis":"Single-factor candidate."}
            result=m.run_agent(run,ask,max_proposal_corrections=2)
            self.assertEqual(result["completed_rounds"],10)
            self.assertEqual(len(fits),10)
            self.assertEqual(stage_count["experiment"],12)

    def test_correction_limit_stops_three_invalid_proposals_before_any_cpu_training(self):
        m = self.module()
        from ite.code_harness import TenRoundRun,candidate_source
        from tests.test_code_harness import Model,dataset
        with tempfile.TemporaryDirectory() as tmp:
            run=TenRoundRun(Path(tmp)/"run",dataset(),Model(),trainer=lambda *a,**k:self.fail("CPU fit"))
            calls=[]
            def ask(stage,payload):
                calls.append(stage)
                if stage=="read":return {"tool":"read_public","paths":m.PUBLIC_PATHS}
                return {"tool":"select_and_experiment","selection":"incumbent","selection_reason":"Parent.",
                    "source":candidate_source(5,"full"),"hypothesis":"Invalid unchanged proposal."}
            with self.assertRaises(ValueError):m.run_agent(run,ask,max_proposal_corrections=2)
            self.assertEqual(calls.count("experiment"),3)
            self.assertEqual(run.attempts,0)

    def test_wrong_read_stage_tool_gets_bounded_feedback_before_any_training(self):
        m = self.module()
        from ite.code_harness import TenRoundRun,candidate_source
        from tests.test_code_harness import Model,dataset
        fits=[];reads=[]
        def train(parent,*a,**kw):
            fits.append(kw)
            return Model(0.,f"candidate-{len(fits)}",parent.steps+1),.01
        with tempfile.TemporaryDirectory() as tmp:
            run=TenRoundRun(Path(tmp)/"run",dataset(),Model(),trainer=train)
            actor=m.RehearsalActor()
            def ask(stage,payload):
                if stage=="read":
                    reads.append(payload)
                    if len(reads)==1:return {"tool":"select_and_experiment","source":candidate_source(4,"full")}
                    self.assertEqual(len(fits),0)
                    self.assertIn("tool_error",payload)
                return actor(stage,payload)
            result=m.run_agent(run,ask,max_proposal_corrections=2)
            self.assertEqual(len(reads),2)
            self.assertEqual(result["completed_rounds"],10)
            self.assertEqual(len(fits),10)

    def test_wrong_finish_tool_gets_feedback_without_eleventh_fit(self):
        m = self.module()
        from ite.code_harness import TenRoundRun
        from tests.test_code_harness import Model,dataset
        fits=[];finishes=[]
        def train(parent,*a,**kw):
            fits.append(kw)
            return Model(0.,f"candidate-{len(fits)}",parent.steps+1),.01
        with tempfile.TemporaryDirectory() as tmp:
            run=TenRoundRun(Path(tmp)/"run",dataset(),Model(),trainer=train)
            actor=m.RehearsalActor()
            def ask(stage,payload):
                if stage=="finish":
                    finishes.append(payload)
                    if len(finishes)==1:return {"tool":"select_and_experiment"}
                    self.assertIn("tool_error",payload)
                return actor(stage,payload)
            result=m.run_agent(run,ask,max_proposal_corrections=2)
            self.assertEqual(result["completed_rounds"],10)
            self.assertEqual(len(fits),10)
            self.assertEqual(len(finishes),2)

    def test_training_error_after_a_fit_started_never_triggers_model_correction(self):
        m = self.module()
        from ite.code_harness import TenRoundRun,candidate_source
        from tests.test_code_harness import Model,dataset
        with tempfile.TemporaryDirectory() as tmp:
            def train(*a,**k):raise ValueError("Started training failed.")
            run=TenRoundRun(Path(tmp)/"run",dataset(),Model(),trainer=train)
            calls=[]
            def ask(stage,payload):
                calls.append(stage)
                if stage=="read":return {"tool":"read_public","paths":m.PUBLIC_PATHS}
                return {"tool":"select_and_experiment","selection":"incumbent","selection_reason":"Parent.",
                    "source":candidate_source(4,"full"),"hypothesis":"Valid source."}
            with self.assertRaises(ValueError):m.run_agent(run,ask,max_proposal_corrections=2)
            self.assertEqual(calls.count("experiment"),1)
            self.assertEqual(run.attempts,1)

    def test_tool_json_does_not_allow_duplicate_keys_or_code_fences(self):
        m = self.module()
        for raw in ('{"tool":"read_public","tool":"finish"}', '```json\n{}\n```', '{"tool":NaN}'):
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                m.parse_tool(raw)

    def test_invalid_paid_output_is_billed_once_and_latches_before_any_retry(self):
        m = self.module()
        from ite.harness import LLMReply
        from unittest.mock import Mock
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            prior=root/"prior.json"
            prior.write_text(json.dumps({"requests":{"old":{"reserved_cny":"9.18"}}}))
            session=m.PaidToolSession(root/"network",root/"state",prior)
            session.tokenizer=Mock()
            session.tokenizer.apply_chat_template.return_value="prompt"
            session.tokenizer.encode.return_value=[1]*100
            session.client=Mock()
            session.client.get_messages.return_value=LLMReply('not JSON',110,"real",100,10,"stop")
            with self.assertRaises(ValueError):
                session.ask("read",{"context":{"profile":"A"}})
            with self.assertRaises(RuntimeError):
                session.ask("read",{"context":{"profile":"A"}})
            self.assertEqual(session.client.get_messages.call_count,1)
            self.assertEqual(session.ledger.data["requests"]["tool-001"]["state"],"settled")
            self.assertTrue(session.ledger.data["stopped"])
            self.assertEqual(session.ledger.available_cny,"0.80")

    def test_timeout_keeps_reservation_and_changed_old_ledger_prevents_network(self):
        m = self.module()
        from unittest.mock import Mock
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            prior=root/"prior.json"
            prior.write_text(json.dumps({"requests":{"old":{"reserved_cny":"9.18"}}}))
            session=m.PaidToolSession(root/"network",root/"state",prior)
            session.tokenizer=Mock()
            session.tokenizer.apply_chat_template.return_value="prompt"
            session.tokenizer.encode.return_value=[1]*100
            session.client=Mock()
            session.client.get_messages.side_effect=TimeoutError()
            with self.assertRaises(TimeoutError):
                session.ask("read",{"context":{"profile":"A"}})
            self.assertEqual(session.ledger.data["requests"]["tool-001"]["state"],"unknown")
            self.assertEqual(session.ledger.reserved_cny,"0.02")
            prior.write_text(json.dumps({"requests":{}}))
            with self.assertRaises(RuntimeError):
                session.ask("read",{"context":{"profile":"A"}})
            self.assertEqual(session.client.get_messages.call_count,1)

    def test_provider_token_overage_is_settled_and_stops_even_if_cent_rounding_hides_it(self):
        m = self.module()
        from ite.harness import LLMReply
        from unittest.mock import Mock
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            prior=root/"prior.json"
            prior.write_text(json.dumps({"requests":{"old":{"reserved_cny":"9.18"}}}))
            session=m.PaidToolSession(root/"network",root/"state",prior)
            session.tokenizer=Mock()
            session.tokenizer.apply_chat_template.return_value="prompt"
            session.tokenizer.encode.return_value=[1]*100
            session.client=Mock()
            count=m.INPUT_LIMIT+1
            session.client.get_messages.return_value=LLMReply('{"tool":"read_public"}',count+10,"real",count,10,"stop")
            with self.assertRaises(ValueError):
                session.ask("read",{"context":{"profile":"A"}})
            self.assertTrue(session.ledger.data["stopped"])
            self.assertEqual(session.ledger.data["requests"]["tool-001"]["input_tokens"],count)

    def test_generic_transport_accepts_explicit_messages_without_action_prompt(self):
        from ite.trio_client import TrioLLMClient
        from unittest.mock import Mock, patch
        worker = Mock()
        worker.returncode = 0
        worker.communicate.return_value = (json.dumps({"content":'{"tool":"read_public"}',
            "input_tokens":20,"output_tokens":8,"finish_reason":"stop"}), "")
        client = TrioLLMClient(model="Qwen/Qwen3.5-4B", input_price_per_million="1.49",
                               output_price_per_million="4.54")
        with patch("ite.trio_client.subprocess.Popen",return_value=worker):
            reply = client.get_messages([{"role":"user","content":"Read public code."}])
        request = json.loads(worker.communicate.call_args.args[0])
        self.assertEqual(request["messages"],[{"role":"user","content":"Read public code."}])
        self.assertEqual(reply.input_tokens,20)


if __name__ == "__main__":
    unittest.main()
