"""Official model gateway, actual parent continuation and prediction boundaries."""

import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

from contest_host import OfflineHost, PROMPT, ROOT, fixture, frame, rows
from contest_harness.errors import HarnessError

RUNTIME = Path(os.environ.get("ITE_OFFICIAL_RUNTIME_PYTHON", ROOT / ".venv-official-a/Scripts/python.exe"))
RETAIN = {"action": "RETAIN", "reason": "Prior failures and the unchanged parent support retaining it."}
EXPERIMENT = {"action": "EXPERIMENT", "reason": "Test the frozen continuation policy on the supplied parent."}
SELECT = {"action": "SELECT_CANDIDATE", "reason": "The measured candidate passed the independent gate."}


class ContestProtocolTests(unittest.TestCase):
    def submission(self):
        self.assertIsNotNone(importlib.util.find_spec("ite.contest_submission"),
            "Official SDK train/predict submission must exist; custom CLI has zero model calls")
        from ite import contest_submission
        return contest_submission

    @staticmethod
    def context(call):
        return json.loads(call["messages"][1]["content"])

    def test_describe_loads_the_official_module_and_reports_host_gateway(self):
        self.assertTrue((ROOT / "harness.py").is_file(), "The required official harness.py entry is missing")
        result = subprocess.run([sys.executable, str(ROOT / "harness.py"), "describe"],
            text=True, capture_output=True, timeout=20)
        self.assertEqual(result.returncode, 0, result.stderr)
        value = json.loads(result.stdout)
        self.assertEqual(value["model_access"], "host_gateway_rpc")
        self.assertEqual(value["protocol"], "contest.harness.workspace.v2")
        self.assertEqual(set(value["tasks"]), {"classification", "regression"})

    def test_offline_verifier_has_a_runnable_container_protocol_entry(self):
        script = ROOT / "scripts/verify_contest_protocol.py"
        self.assertTrue(script.is_file(), "The Docker protocol verification runner is missing")
        result = subprocess.run([sys.executable, str(script), "--help"],
            text=True, capture_output=True, timeout=20)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("--image", result.stdout)
        self.assertIn("--output", result.stdout)

    def test_import_does_not_load_private_client_or_paid_ledger(self):
        self.submission()
        command = "import contest_submission,sys; print([x for x in ('ite.trio_client','ite.trio_worker','ite.code_harness_agent','pytrio') if x in sys.modules])"
        result = subprocess.run([sys.executable, "-c", command], text=True, capture_output=True, timeout=20)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout.strip(), "[]")

    def test_retain_still_reads_history_calls_bound_model_and_saves_true_history(self):
        module = self.submission()
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            parent, train, validation = fixture(root, "B")
            original = (parent / "checkpoint.npz").read_bytes()
            start = frame(parent, train, validation, "B")
            host = OfflineHost(start, [RETAIN, RETAIN], history=[{"id": "real-history-0", "round_index": 0}])
            with patch.dict(os.environ, {"CONTEST_WORK": str(root / "work")}):
                module.train(host.round(parent))
            self.assertEqual(host.record["selected_artifact_id"], "baseline-B")
            self.assertEqual(host.record["history_ids"], ["real-history-0"])
            self.assertEqual(host.record["model_call_ids"], ["call-1", "call-2"])
            self.assertEqual((parent / "checkpoint.npz").read_bytes(), original)
            self.assertFalse(host.candidates)
            self.assertEqual(len(host.states), 1)
            for index, call in enumerate(host.calls):
                self.assertNotIn(PROMPT, json.dumps(call["messages"]))
                self.assertLessEqual(call["max_tokens"], 512)
                self.assertEqual(call["tool_choice"]["type"], "function")
                self.assertEqual(call["tools"][0]["function"]["name"],
                    "run_frozen_experiment" if index == 0 else "select_candidate")
            self.assertIn("real-history-0", json.dumps(host.calls[0]))
            self.assertIn("training_attempts", json.dumps(host.calls[-1]))

    def test_missing_model_receipt_never_finishes_a_round(self):
        module = self.submission()
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            parent, train, validation = fixture(root, "B")
            host = OfflineHost(frame(parent, train, validation, "B"), [])
            with patch.dict(os.environ, {"CONTEST_WORK": str(root / "work")}):
                with self.assertRaises(Exception):
                    module.train(host.round(parent))
            self.assertIsNone(host.record)
            self.assertFalse(host.candidates)

    def test_declared_parent_digest_mismatch_cannot_reset_to_packaged_baseline(self):
        module = self.submission()
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            parent, train, validation = fixture(root, "C")
            start = frame(parent, train, validation, "C")
            content = (parent / "checkpoint.npz").read_bytes()
            (parent / "checkpoint.npz").write_bytes(content + b"changed")
            host = OfflineHost(start, [EXPERIMENT, SELECT])
            with patch.dict(os.environ, {"CONTEST_WORK": str(root / "work")}):
                with self.assertRaises(HarnessError) as error:
                    module.train(host.round(parent))
            self.assertEqual(error.exception.code, "PARENT_DIGEST_MISMATCH")
            self.assertIsNone(host.record)
            self.assertFalse(host.candidates)

    @unittest.skipUnless(RUNTIME.is_file(), "official CPU runtime unavailable")
    def test_c_experiment_advances_optimizer_from_actual_parent_and_cites_both_calls(self):
        module = self.submission()
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            parent, train, validation = fixture(root, "C")
            start = frame(parent, train, validation, "C")
            host = OfflineHost(start, [EXPERIMENT, SELECT])
            with patch.dict(os.environ, {"CONTEST_WORK": str(root / "work")}):
                module.train(host.round(parent))
            self.assertEqual(len(host.candidates), 1, "Fixture must really train/pass the existing future gate")
            files = {x["path"]: base64.b64decode(x["data_base64"]) for x in host.candidates[0]["files"]}
            report = json.loads(files["training.json"])
            self.assertGreater(report["training_attempts"], 0)
            self.assertGreater(report["final_steps"], report["initial_steps"])
            self.assertEqual(report["parent_checkpoint_sha256"], hashlib.sha256((parent / "checkpoint.npz").read_bytes()).hexdigest())
            self.assertEqual(host.record["model_call_ids"], ["call-1", "call-2"])
            context = self.context(host.calls[-1])
            self.assertIn("candidate-1", json.dumps(context))
            self.assertGreater(context["platform_candidate_receipt"]["summary"]["metrics"]["rmse"], 0)
            self.assertEqual(context["actual_cpu_report"]["fresh_validation_after"], report["fresh_validation_after"])
            self.assertTrue(context["candidate_selectable"])
            self.assertEqual(host.record["selected_artifact_id"], "candidate-1")

    @unittest.skipUnless(RUNTIME.is_file(), "official CPU runtime unavailable")
    def test_model_retain_prevents_real_c_training(self):
        module = self.submission()
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            parent, train, validation = fixture(root, "C")
            host = OfflineHost(frame(parent, train, validation, "C"), [RETAIN, RETAIN])
            with patch.dict(os.environ, {"CONTEST_WORK": str(root / "work")}):
                module.train(host.round(parent))
            self.assertFalse(host.candidates)
            self.assertEqual(host.record["selected_artifact_id"], "baseline-C")
            self.assertEqual(self.context(host.calls[-1])["actual_cpu_report"]["training_attempts"], 0)

    def test_invalid_model_action_is_recorded_as_retain_without_training(self):
        module = self.submission()
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            parent, train, validation = fixture(root, "B")
            host = OfflineHost(frame(parent, train, validation, "B"), ["not-json", RETAIN])
            with patch.dict(os.environ, {"CONTEST_WORK": str(root / "work")}):
                module.train(host.round(parent))
            self.assertEqual(host.record["selected_artifact_id"], "baseline-B")
            self.assertIn("invalid_model_decision", json.dumps(host.calls[-1]))

    def test_second_round_cannot_reuse_validation_as_fresh_after_parent_is_retained(self):
        module = self.submission()
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            parent, train, validation = fixture(root, "C")
            first = OfflineHost(frame(parent, train, validation, "C"), [EXPERIMENT, RETAIN])
            with patch.dict(os.environ, {"CONTEST_WORK": str(root / "work1")}):
                module.train(first.round(parent))
            self.assertEqual(len(first.candidates), 1)
            self.assertEqual(first.record["selected_artifact_id"], "baseline-C")
            cpu_report = json.loads((root / "work1/cpu-result/training.json").read_text())
            self.assertGreater(cpu_report["training_attempts"], 0)
            self.assertNotEqual(cpu_report["checkpoint_sha256"], cpu_report["parent_checkpoint_sha256"])
            state = root / "saved-state"
            first.save_state(state)
            _, lineage, seen = __import__("ite.continuation", fromlist=["load_history"]).load_history(
                state / "history.jsonl", hashlib.sha256((parent / "checkpoint.npz").read_bytes()).hexdigest(), "C")
            self.assertEqual(lineage[-1]["checkpoint_sha256"], hashlib.sha256((parent / "checkpoint.npz").read_bytes()).hexdigest())
            self.assertNotEqual(lineage[-1]["candidate_checkpoint_sha256"], lineage[-1]["checkpoint_sha256"])
            second = OfflineHost(frame(parent, train, validation, "C", index=2, state=state), [EXPERIMENT, RETAIN],
                history=[{"id": "real-round-1", **first.record}])
            with patch.dict(os.environ, {"CONTEST_WORK": str(root / "work2")}):
                module.train(second.round(parent))
            self.assertFalse(second.candidates)
            second_context = self.context(second.calls[-1])
            self.assertEqual(second_context["actual_cpu_report"]["fresh_validation_rows"], 0)
            self.assertIsNone(second_context["actual_cpu_report"]["fresh_validation_before"])
            self.assertNotIn("validation_before", second_context["actual_cpu_report"])
            self.assertEqual(second.record["history_ids"], ["real-round-1"])

    def test_selection_protection_requires_full_paired_metrics_and_registered_thresholds(self):
        module = self.submission()
        before_c = {"rmse": 10., "mae": 8., "overestimate_rate": .2, "mean_overestimate": 2.}
        self.assertFalse(module.safe_candidate_selection("C", before_c, {"rmse": 9.}))
        self.assertFalse(module.safe_candidate_selection("C", before_c, {"rmse": 9., "mae": 8.,
            "overestimate_rate": .25, "mean_overestimate": 2.}))
        self.assertTrue(module.safe_candidate_selection("C", before_c, {"rmse": 9., "mae": 8.,
            "overestimate_rate": .22, "mean_overestimate": 3.}))
        before_a = {"macro_f1": .6, "accuracy": .8}
        self.assertTrue(module.safe_candidate_selection("A", before_a, {"macro_f1": .605, "accuracy": .796}))
        self.assertFalse(module.safe_candidate_selection("A", before_a, {"macro_f1": .6049, "accuracy": .8}))
        self.assertFalse(module.safe_candidate_selection("A", before_a, {"macro_f1": .61, "accuracy": .79}))

    def test_host_missing_metrics_never_authorizes_selection(self):
        module = self.submission()
        self.assertFalse(module._host_selection("C", {}, {}, None))
        self.assertFalse(module._host_selection("C", {"metrics": {"rmse": 8.}},
            {"metrics": {"rmse": 9., "mae": 7., "overestimate_rate": .1, "mean_overestimate": 1.}}, None))
        self.assertFalse(module._host_selection("C", {}, {"metrics": {"rmse": 9.}}, None))

    def test_rejected_candidate_history_records_the_actually_retained_checkpoint(self):
        module = self.submission()
        self.assertTrue(callable(getattr(module, "selection_history", None)),
            "SDK state must bind the retained parent after a locally accepted candidate is declined")
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "history.jsonl"
            before = "a" * 64
            candidate = "b" * 64
            records = [{"event": "round_started", "profile": "C", "stage_id": "platform-round-1",
                "parent_checkpoint_sha256": before, "parent_history_sha256": None},
                {"event": "round_completed", "profile": "C", "stage_id": "platform-round-1",
                "parent_checkpoint_sha256": before, "checkpoint_sha256": candidate,
                "initial_steps": 10, "final_steps": 12, "initial_epochs": 2, "final_epochs": 4,
                "training_attempts": 1, "accepted_updates": 1, "validation_id_hashes": ["c" * 64]}]
            raw = "".join(json.dumps(row) + "\n" for row in records).encode()
            selected = module.selection_history(raw, False, {"action": "RETAIN"})
            path.write_bytes(selected)
            from ite.continuation import load_history
            _, entries, seen = load_history(path, before, "C")
            last = entries[-1]
            self.assertEqual(last["checkpoint_sha256"], before)
            self.assertEqual(last["final_steps"], 10)
            self.assertEqual(last["candidate_checkpoint_sha256"], candidate)
            self.assertEqual(last["candidate_training_attempts"], 1)
            self.assertIn("c" * 64, seen)

    def test_predict_process_answers_each_line_without_eof(self):
        self.submission()
        import queue
        import threading
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            parent, _, _ = fixture(root, "B")
            request = {"task": "regression", "inputs": rows("B", "public/validation.jsonl")[0]["inputs"]}
            env = {**os.environ, "CONTEST_ARTIFACT_PATH": str(parent / "checkpoint.npz")}
            # SDK serves /model. Direct process uses our predict callback with an
            # explicitly patched directory only for this local host fixture.
            source = "from contest_harness.predict import serve_predictions; from contest_submission import predict; from pathlib import Path; import sys; serve_predictions(lambda sample,_: predict(sample,Path(sys.argv[1])))"
            process = subprocess.Popen([sys.executable, "-c", source, str(parent)], env=env,
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True, encoding="utf-8")
            output = queue.Queue()
            thread = threading.Thread(target=lambda: output.put(process.stdout.readline()), daemon=True)
            thread.start()
            try:
                process.stdin.write(json.dumps(request) + "\n")
                process.stdin.flush()
                line = output.get(timeout=20)
                self.assertGreaterEqual(json.loads(line)["outputs"]["value"], 0.)
                self.assertIsNone(process.poll(), "predictor must respond before stdin closes")
            finally:
                process.stdin.close()
                process.wait(timeout=10)
                process.stdout.close()
                process.stderr.close()

    @unittest.skipUnless(RUNTIME.is_file(), "official CPU runtime unavailable")
    def test_sdk_prediction_matches_official_parent_and_rejects_context_mismatch(self):
        module = self.submission()
        from contest_harness.predict import Sample
        from ite.official_model import OFFICIAL_PROFILES, OfficialModelAdapter
        from ite.platform_data import flatten
        with tempfile.TemporaryDirectory() as temp:
            for profile in ("A", "B", "C"):
                root = Path(temp) / profile
                root.mkdir()
                parent, _, _ = fixture(root, profile)
                task = OFFICIAL_PROFILES[profile]["task"]
                row = rows(profile, "public/validation.jsonl")[0]
                sample = Sample(task, row["inputs"], {"dataset_key": profile, "artifact_id": "parent"})
                with patch.dict(os.environ, {"CONTEST_ARTIFACT_PATH": str(parent / "checkpoint.npz")}):
                    result = module.predict(sample, parent)
                model = OfficialModelAdapter(task, str(RUNTIME), profile_type=profile,
                    checkpoint_path=parent / "checkpoint.npz")
                x = np.asarray([flatten(row["inputs"])[1]])
                if profile == "A":
                    self.assertEqual(result[int(np.argmax([x["score"] for x in result]))]["label"],
                                     OFFICIAL_PROFILES["A"]["classes"][int(model.predict(x)[0]) - 1])
                else:
                    self.assertAlmostEqual(result["value"], float(model.predict(x)[0]), places=10)
                wrong = Sample("regression" if profile == "A" else "classification", row["inputs"],
                    {"dataset_key": profile, "artifact_id": "parent"})
                with self.assertRaises(ValueError):
                    module.predict(wrong, parent)


if __name__ == "__main__":
    unittest.main()
