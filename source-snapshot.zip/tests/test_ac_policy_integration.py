"""Integrate A step7 replay while retaining the train-only C2 delivery boundary."""

import json
from pathlib import Path
import tempfile
import unittest

import numpy as np

from scripts import run_heuristic_comparison as comparison
from tests.test_official_sft_replay import ConstantClassifier


class CombinedPolicyTests(unittest.TestCase):
    def policy(self, profile, arm="heuristic", **options):
        policy = getattr(comparison, "policy_for_case", None)
        self.assertTrue(callable(policy), "Combined A step7 policy routing is missing")
        return policy(profile, arm, 2, a_step7_replay=True, **options)

    def test_a_schedules_one_full_replay_and_c_keeps_existing_trigger_and_epochs(self):
        a = self.policy("A")
        self.assertEqual(a["decision_steps"], (7,))
        self.assertEqual(a["action"], "RETRAIN_LARGE")
        self.assertEqual(a["candidate_epochs"], 5)
        self.assertEqual(a["a_replay_policy"], "class_balanced_official_train")
        self.assertFalse(a["heuristic_override"])
        c = self.policy("C")
        self.assertEqual(c["decision_steps"], (3, 4, 5, 6, 7, 8, 9))
        self.assertEqual(c["candidate_epochs"], 2)
        self.assertTrue(c["heuristic_override"])
        for profile, arm in (("B", "heuristic"), ("A", "static"), ("A", "no_control")):
            policy = self.policy(profile, arm)
            self.assertEqual(policy["action"], "DO_NOTHING")
            self.assertFalse(policy["heuristic_override"])
            self.assertEqual(policy["a_replay_policy"], "none")

    def test_old_c_only_combination_and_original_experiment_remain_available(self):
        self.policy("A")  # Require the new route before checking compatibility.
        old = comparison.policy_for_case("A", "heuristic", 2)
        self.assertEqual(old["action"], "DO_NOTHING")
        self.assertFalse(old["heuristic_override"])
        original = comparison.policy_for_case("A", "heuristic", None)
        self.assertTrue(original["heuristic_override"])
        self.assertEqual(original["a_replay_policy"], "class_balanced_official_train")

    def test_new_combination_rejects_other_c_epochs_and_preserves_existing_outputs(self):
        self.policy("A")
        for epoch in (None, 1, 3, 5):
            with self.subTest(epoch=epoch), self.assertRaises(ValueError):
                comparison.policy_for_case("A", "heuristic", epoch, a_step7_replay=True)
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(FileExistsError):
                comparison.run_comparison(Path(tmp), "unused", c_epochs=2, a_step7_replay=True)

    def test_global_a_gain_must_be_substantial_and_cannot_hide_scene_regression(self):
        assess = getattr(comparison, "assess_a_step7", None)
        self.assertTrue(callable(assess), "Integrated A acceptance is missing")
        before = {"macro_f1": .5, "accuracy": .7}
        after = {"macro_f1": .51, "accuracy": .7}
        scores = {"static": before, "heuristic": after}
        scenes = {s: {"static": before, "heuristic": before if s == "stable" else after}
                  for s in ("stable", "abrupt", "gradual")}
        self.assertTrue(assess(scores, scenes)["passed"])
        self.assertFalse(assess({"static": before, "heuristic": before}, scenes)["passed"])
        self.assertFalse(assess({"static": before,
                                "heuristic": {"macro_f1": .504, "accuracy": .7}}, scenes)["passed"])
        scenes["gradual"] = {"static": before, "heuristic": {"macro_f1": .499, "accuracy": .7}}
        self.assertFalse(assess(scores, scenes)["passed"])
        scenes["gradual"] = scores
        self.assertFalse(assess({"static": before,
                                "heuristic": {"macro_f1": .51, "accuracy": .694}}, scenes)["passed"])


class SavedClassifier(ConstantClassifier):
    def save(self, path):
        np.savez_compressed(path, selected_label=np.asarray(self.label))


class ATrainOnlyReplayTests(unittest.TestCase):
    def run_case(self, output, *, reject_future=False):
        from ite.official_sft_data import OFFICIAL_A_CLASSES
        from ite.official_sft_replay import replay_partition
        policy = CombinedPolicyTests().policy("A")
        count = 2400
        targets = np.full(count, 2)
        if reject_future:
            targets[1600:1800] = 1
        reserve = {"x": np.full((48, 2), -100.), "y": np.tile(np.arange(1, 7), 8),
                   "ids": [f"reserve-{i}" for i in range(48)],
                   "class_counts": dict.fromkeys(OFFICIAL_A_CLASSES, 8),
                   "selection_policy": "sha256_ranked_8_per_class_v1"}
        data = {"profile": "A", "task": "classification", "unit": "class", "loss_scale": 1.,
                "x": np.zeros((count, 2)), "y": targets,
                "ids": [f"validation-{i}" for i in range(count)],
                "groups": ["validation-batch"] * count, "scale": np.ones(2), "replay_reserve": reserve}
        stream = {"x": np.repeat((5000. + np.arange(397))[:, None], 2, axis=1),
                  "y": np.full(397, 3), "ids": [f"train-{i}" for i in range(397)]}
        calls = []
        parent = SavedClassifier(1, "initial")
        candidate = SavedClassifier(2, "candidate")
        candidate.steps = 11
        def train(model, x, y, allowance, **options):
            calls.append((x.copy(), y.copy(), allowance, options))
            return candidate, .01
        summary = replay_partition(data, list(range(count)), "eval", "abrupt", output, parent,
            lambda _: {"action": policy["action"], "reason": "Scheduled replay", "source": "fixed_policy"},
            decision_steps=policy["decision_steps"], action_profile="official_finetune",
            a_replay_policy=policy["a_replay_policy"], heuristic_override=policy["heuristic_override"],
            training_stream=stream, trainer=train)
        events = [json.loads(line) for line in (output / "events.jsonl").read_text(encoding="utf-8").splitlines()]
        return summary, calls, events

    def test_a_gradients_use_clock_released_train_rows_and_original_reserve_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "run"
            summary, calls, events = self.run_case(out)
            with np.load(out / "predictions.npz", allow_pickle=False) as v:
                np.testing.assert_array_equal(v["versions"], np.r_[np.zeros(2000), np.ones(400)])
            with np.load(out / "selected.npz", allow_pickle=False) as selected:
                self.assertEqual(selected["selected_label"].item(), 2)
        self.assertEqual(len(calls), 1)
        x, y, seconds, options = calls[0]
        self.assertEqual((x.shape, seconds, options), ((232, 2), 5., {}))
        np.testing.assert_array_equal(x[:48], -100.)
        expected = np.repeat((5000. + np.arange(48, 232))[:, None], 2, axis=1)
        expected[52:] += .75  # First three released training chunks contain 100 rows.
        np.testing.assert_array_equal(x[48:], expected)
        np.testing.assert_array_equal(y[48:], 3)
        fit = next(e for e in events if e["event"] == "candidate_evaluated")
        self.assertEqual(fit["step"], 7)
        self.assertEqual(fit["train_source_ids"], [f"reserve-{i}" for i in range(48)] +
                         [f"train-{i}" for i in range(48, 232)])
        self.assertTrue(all(i.startswith("validation-") for i in fit["screening_source_ids"]))
        gate = next(e for e in events if e["event"] == "deploy")
        self.assertEqual((gate["step"], gate["frozen_at"], gate["gate_min_source_step"]), (9, 7, 8))
        self.assertFalse(set(gate["source_ids"]) & set(fit["train_source_ids"]))
        self.assertEqual(summary["updates"], 1)

    def test_scheduled_a_attempt_cannot_bypass_future_rejection_or_replace_checkpoint(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "run"
            summary, calls, events = self.run_case(out, reject_future=True)
            with np.load(out / "selected.npz", allow_pickle=False) as selected:
                self.assertEqual(selected["selected_label"].item(), 1)
            with np.load(out / "predictions.npz", allow_pickle=False) as values:
                self.assertTrue(np.all(values["versions"] == 0))
        self.assertEqual(len(calls), 1)
        self.assertEqual(summary["updates"], 0)
        self.assertTrue(any(e["event"] == "experiment_rejected" and
                            e.get("reason") == "independent_future_labels" for e in events))


if __name__ == "__main__":
    unittest.main()
