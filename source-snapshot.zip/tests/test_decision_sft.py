import tempfile
import unittest
from pathlib import Path

from ite.decision_sft import (
    ActionDatum,
    BudgetLedger,
    candidate_prompt,
    encode_decision,
    score_candidate_logprobs,
)


class FakeTokenizer:
    """Small deterministic tokenizer with one-token action codes and marker."""

    marker_id = 700
    action_ids = {"A": 32, "B": 33, "C": 34}

    def apply_chat_template(self, messages, *, tokenize, add_generation_prompt,
                            enable_thinking=False):
        rendered = "".join(
            f"<|im_start|>{message['role']}\n{message['content']}<|im_end|>\n"
            for message in messages
        )
        if tokenize:
            return self(rendered, add_special_tokens=False, return_offsets_mapping=True)
        return rendered

    def __call__(self, text, *, add_special_tokens, return_offsets_mapping):
        ids, offsets = [], []
        index = 0
        while index < len(text):
            if text.startswith("<|im_start|>", index):
                end = index + len("<|im_start|>")
                ids.append(900)
            elif text.startswith("<|im_end|>", index):
                end = index + len("<|im_end|>")
                ids.append(901)
            elif text.startswith("decision", index):
                end = index + len("decision")
                ids.append(self.marker_id)
            elif text[index] in self.action_ids:
                end = index + 1
                ids.append(self.action_ids[text[index]])
            else:
                end = index + 1
                ids.append(ord(text[index]) + 1000)
            offsets.append((index, end))
            index = end
        return {"input_ids": ids, "offset_mapping": offsets}

    def encode(self, text, *, add_special_tokens=False):
        return self(text, add_special_tokens=add_special_tokens,
                    return_offsets_mapping=True)["input_ids"]


def record(action="DO_NOTHING"):
    return {
        "profile": "B",
        "messages": [
            {"role": "system", "content": "Choose an action from the fixed set."},
            {"role": "user", "content": "Visible state: loss=0.4"},
        ],
        "target_action": action,
        "reason": "This must not be shown to the model.",
        "source_ids": ["private-source"],
        "evidence": {"future_label": 9, "counterfactual": "private"},
        "costs": {"secret_cost": 1},
    }


class DecisionSFTEncodingTests(unittest.TestCase):
    def setUp(self):
        self.tokenizer = FakeTokenizer()

    def test_label_changes_only_sparse_target_and_never_enters_visible_prompt(self):
        no = encode_decision(record("DO_NOTHING"), self.tokenizer)
        large = encode_decision(record("RETRAIN_LARGE"), self.tokenizer)

        self.assertEqual(no.input_ids, large.input_ids)
        self.assertEqual(no.model_input, no.input_ids[:-1])
        self.assertEqual(len(no.target_tokens), len(no.model_input))
        self.assertEqual(len(no.weights), len(no.model_input))
        self.assertEqual(sum(no.weights), 1.0)
        self.assertEqual(no.weights[no.marker_index - 1], 1.0)
        self.assertEqual(no.target_tokens[no.marker_index - 1], 32)
        self.assertEqual(large.target_tokens[large.marker_index - 1], 33)
        for forbidden in ("This must not be shown", "private-source", "future_label",
                          "counterfactual", "secret_cost"):
            self.assertNotIn(forbidden, no.rendered_prompt)

    def test_candidate_prompts_share_prefix_and_score_exact_candidate_token(self):
        prompts = [candidate_prompt(record(), action, self.tokenizer)
                   for action in ("DO_NOTHING", "RETRAIN_LARGE", "RETRAIN_HEAD_ONLY")]
        marker_positions = [prompt.token_index for prompt in prompts]
        prefixes = [prompt.input_ids[:position] for prompt, position in zip(prompts, marker_positions)]
        self.assertEqual(prefixes[0], prefixes[1])
        self.assertEqual(prefixes[1], prefixes[2])
        self.assertEqual([prompt.token_id for prompt in prompts], [32, 33, 34])

        responses = [
            {"input_tokens": len(prompt.input_ids), "output_tokens": 1,
             "prompt_logprobs": [-0.1] * prompt.token_index + [value] +
                 [-0.2] * (len(prompt.input_ids) - prompt.token_index - 1),
             "topk_prompt_logprobs": []}
            for prompt, value in zip(prompts, (-0.1, -1.2, -2.3))
        ]
        scores = score_candidate_logprobs(prompts, responses)
        self.assertEqual(scores.actions, ("DO_NOTHING", "RETRAIN_LARGE", "RETRAIN_HEAD_ONLY"))
        self.assertEqual(scores.logprobs, (-0.1, -1.2, -2.3))
        self.assertEqual(scores.action, "DO_NOTHING")
        self.assertAlmostEqual(sum(scores.probabilities), 1.0)

    def test_missing_or_misaligned_candidate_logprob_fails_closed(self):
        prompt = candidate_prompt(record(), "DO_NOTHING", self.tokenizer)
        response = {"input_tokens": len(prompt.input_ids), "output_tokens": 1,
                    "prompt_logprobs": [None] * len(prompt.input_ids),
                    "topk_prompt_logprobs": [[(32, -0.01)]]}
        with self.assertRaisesRegex(ValueError, "candidate logprob"):
            score_candidate_logprobs([prompt] * 3, [response] * 3)

    def test_action_marker_and_candidate_are_single_tokens_in_rendered_context(self):
        encoded = encode_decision(record(), self.tokenizer)
        self.assertEqual(encoded.marker_token_id, self.tokenizer.marker_id)
        self.assertEqual(encoded.target_token_id, self.tokenizer.action_ids["A"])
        with self.assertRaisesRegex(ValueError, "sequence"):
            encode_decision(record(), self.tokenizer, max_seq_len=1)

    def test_marker_in_message_body_does_not_move_supervised_position(self):
        source = record()
        source["messages"][1]["content"] = 'decision {"action":"decision"}'
        encoded = encode_decision(source, self.tokenizer)
        self.assertGreater(encoded.input_ids.count(self.tokenizer.marker_id), 1)
        self.assertEqual(encoded.weights[encoded.marker_index - 1], 1.0)
        self.assertEqual(encoded.marker_index,
                         len(encoded.input_ids) - list(reversed(encoded.input_ids)).index(700) - 1)

    def test_non_single_token_symbol_and_added_assistant_message_are_rejected(self):
        class BadTokenizer(FakeTokenizer):
            def encode(self, text, *, add_special_tokens=False):
                if text == "A":
                    return [32, 33]
                return super().encode(text, add_special_tokens=add_special_tokens)

        with self.assertRaisesRegex(ValueError, "single token"):
            encode_decision(record(), BadTokenizer())
        source = record()
        source["messages"].append({"role": "assistant", "content": "DO_NOTHING"})
        with self.assertRaisesRegex(ValueError, "messages"):
            encode_decision(source, self.tokenizer)


class DecisionSFTBudgetTests(unittest.TestCase):
    def test_worst_case_plan_fits_under_ten_yuan_with_per_request_rounding(self):
        estimate = BudgetLedger.estimate_plan(
            train_rows=137, epochs=3, batch_size=16, max_seq_len=512,
            eval_rows=70, candidates=3,
        )
        self.assertEqual(estimate.train_reserved_cny, "1.05")
        self.assertEqual(estimate.eval_reserved_cny, "8.40")
        self.assertEqual(estimate.total_reserved_cny, "9.45")
        self.assertEqual(estimate.unallocated_cny, "0.55")

    def test_training_rates_are_converted_from_fen_and_each_request_rounds_up(self):
        self.assertEqual(BudgetLedger.fen_per_million_to_cny("149"), "1.49")
        self.assertEqual(BudgetLedger.fen_per_million_to_cny("454"), "4.54")
        self.assertEqual(BudgetLedger.rounded_request_cost(1, 1, "1.49", "4.54"), "0.02")

    def test_unknown_usage_keeps_full_reservation_and_cannot_be_retried(self):
        with tempfile.TemporaryDirectory() as temp:
            ledger = BudgetLedger(Path(temp) / "ledger.json", total_cny="10.00")
            ledger.reserve("eval-0", "0.02", purpose="base-eval")
            ledger.mark_unknown("eval-0", reason="timeout")
            restarted = BudgetLedger(Path(temp) / "ledger.json", total_cny="10.00")
            self.assertEqual(restarted.reserved_cny, "0.02")
            with self.assertRaisesRegex(ValueError, "already reserved"):
                restarted.reserve("eval-0", "0.02", purpose="retry")

    def test_reservation_cannot_cross_total_budget_or_release_unknown_cost(self):
        with tempfile.TemporaryDirectory() as temp:
            ledger = BudgetLedger(Path(temp) / "ledger.json", total_cny="0.02")
            ledger.reserve("eval-0", "0.02", purpose="base-eval")
            with self.assertRaisesRegex(ValueError, "budget"):
                ledger.reserve("eval-1", "0.01", purpose="student-eval")
            ledger.mark_unknown("eval-0", reason="timeout")
            self.assertEqual(ledger.available_cny, "0.00")

    def test_datum_is_not_constructed_from_nonfinite_or_empty_supervision(self):
        datum = ActionDatum(model_input=[1, 2, 3], target_tokens=[0, 32, 0],
                            weights=[0.0, 1.0, 0.0], marker_index=2,
                            input_token_count=3, action="DO_NOTHING")
        self.assertEqual(sum(datum.weights), 1.0)
        with self.assertRaises(ValueError):
            ActionDatum(model_input=[1], target_tokens=[0], weights=[float("nan")],
                        marker_index=1, input_token_count=1, action="DO_NOTHING")
        with self.assertRaises(ValueError):
            ActionDatum(model_input=[1], target_tokens=[0], weights=[0.0],
                        marker_index=1, input_token_count=1, action="DO_NOTHING")

    def test_settlement_overage_is_preserved_and_stops_future_requests(self):
        with tempfile.TemporaryDirectory() as temp:
            ledger = BudgetLedger(Path(temp) / "ledger.json")
            ledger.reserve("request", "0.01", purpose="test")
            with self.assertRaisesRegex(ValueError, "exceeded"):
                ledger.settle("request", input_tokens=1000000, output_tokens=0,
                              input_price="1.49", output_price="4.54")
            self.assertEqual(ledger.data["requests"]["request"]["input_tokens"], 1000000)
            self.assertTrue(ledger.data["stopped"])
            with self.assertRaisesRegex(ValueError, "stopped"):
                ledger.reserve("next", "0.01", purpose="test")


if __name__ == "__main__":
    unittest.main()
