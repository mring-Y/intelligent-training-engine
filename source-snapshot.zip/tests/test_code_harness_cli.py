"""Suite entrypoint and cloud evidence must describe real, separate package rounds."""

import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock


class CodeHarnessCLITests(unittest.TestCase):
    def test_cli_defaults_to_offline_rehearsal_and_requires_frozen_answers_for_replay(self):
        from scripts.run_code_harness import argument_parser
        parser=argument_parser()
        args=parser.parse_args(["--output","example"])
        self.assertEqual(args.mode,"rehearsal")
        self.assertIsNone(args.answers)
        self.assertEqual(args.model,"Qwen/Qwen3.5-4B")

    def test_cli_requires_explicit_budget_renewal_and_keeps_legacy_default(self):
        from scripts.run_code_harness import argument_parser
        parser=argument_parser()
        self.assertIsNone(parser.parse_args(["--output","legacy"]).renewed_cumulative_budget_cny)
        args=parser.parse_args(["--output","fresh","--mode","paid",
                               "--renewed-cumulative-budget-cny","29.99"])
        self.assertEqual(args.renewed_cumulative_budget_cny,"29.99")

    def test_27b_pricing_is_checked_against_its_own_official_entry(self):
        import io
        import json
        from unittest.mock import patch
        from scripts.run_code_harness import check_prices
        prices = {"currency":"CNY", "token_unit":"per_1m_tokens", "items":[
            {"display_name":"Qwen/Qwen3.5-4B", "prices":{
                "prefill":{"unit_price":149}, "sample":{"unit_price":454}}},
            {"display_name":"Qwen/Qwen3.8-27B", "prices":{
                "prefill":{"unit_price":315}, "sample":{"unit_price":2529}}}]}
        with patch("scripts.run_code_harness.urllib.request.urlopen",
                   return_value=io.BytesIO(json.dumps(prices).encode())):
            self.assertEqual(check_prices("Qwen/Qwen3.8-27B"), prices)
        prices["items"][1]["prices"]["sample"]["unit_price"] = 2530
        with patch("scripts.run_code_harness.urllib.request.urlopen",
                   return_value=io.BytesIO(json.dumps(prices).encode())):
            with self.assertRaises(ValueError):
                check_prices("Qwen/Qwen3.8-27B")

    def test_explicit_model_reaches_paid_claim_and_run_evidence(self):
        import json
        from unittest.mock import patch
        from scripts.run_code_harness import argument_parser, execute
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            prior = root/"prior.json"
            prior.write_text(json.dumps({"requests":{"old":{"reserved_cny":"9.40"}}}))
            args = argument_parser().parse_args(["--output",str(root/"run"),"--mode","paid",
                "--model","Qwen/Qwen3.8-27B","--previous-ledger",str(prior),
                "--paid-state",str(root/"state"),"--renewed-cumulative-budget-cny","29.99"])
            with patch("scripts.run_code_harness.check_prices",return_value={}), \
                 patch("scripts.run_code_harness.load_round_data"), \
                 patch("scripts.run_code_harness.OfficialModelAdapter"), \
                 patch("scripts.run_code_harness.TenRoundRun"), \
                 patch("scripts.run_code_harness.run_agent",return_value={"ten_rounds_complete":False}):
                result = execute(args)
            self.assertEqual(result["model"], "Qwen/Qwen3.8-27B")
            self.assertEqual(json.loads((root/"run/freeze.json").read_text())["model"], result["model"])
            self.assertEqual(json.loads((root/"state/claim.json").read_text())["model"], result["model"])

    def test_swanlab_logs_each_completed_round_and_preserves_exact_summary(self):
        from scripts.run_code_harness import log_swanlab
        import json
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            package=root/"A"/"round-01"
            package.mkdir(parents=True)
            (package/"experiment.json").write_text(json.dumps({"train_seconds":.2,"screen_passed":False,
                "gate_passed":False,"config":{"epochs":4,"trainable_policy":"full"}}))
            result={"mode":"replay","model":"Qwen/Qwen3.8-27B","all_ten_rounds_complete":False,"packages":{"A":{
                "completed_rounds":1,"final_development_metrics":{"stable":{"static":{"macro_f1":.5},
                "selected":{"macro_f1":.5,"classes":[1,2,3,4,5,6]}}}}}}
            (root/"summary.json").write_text(json.dumps(result))
            swan=Mock()
            swan.init.return_value.id="record"
            def check_scalars(values,**kwargs):
                if not all(type(value) in (int,float) for value in values.values()):
                    raise TypeError("Only numeric metrics belong in scalar series")
            swan.init.return_value.log.side_effect=check_scalars
            receipt=log_swanlab(root,result,mode="offline",swan=swan)
            self.assertEqual(receipt["run_id"],"record")
            self.assertEqual(swan.init.call_args.kwargs["config"]["mode"],"replay")
            self.assertEqual(swan.init.call_args.kwargs["config"]["model"],"Qwen/Qwen3.8-27B")
            self.assertGreaterEqual(swan.init.return_value.log.call_count,2)
            self.assertTrue((root/"swanlab-receipt.json").is_file())
            self.assertTrue((root/"evidence.zip").is_file())


if __name__=="__main__":
    unittest.main()
