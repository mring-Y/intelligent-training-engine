"""B replay balances historical bearings without sharing validation evidence."""

import copy
import importlib
import json
import tempfile
import unittest
import zipfile
from collections import Counter
from pathlib import Path

import numpy as np

from ite import official_sft_data as data_module
from ite.official_sft_replay import replay_partition


def training_fixture():
    return [{"id": f"B-{condition}-{bearing}-{snapshot}", "answer": 10. - snapshot,
             "inputs": {"features": [float(snapshot)] * 34},
             "meta": {"bearing": f"Bearing{condition}_{bearing}", "snapshot": snapshot}}
            for condition in (1, 2, 3) for bearing in (1, 2, 3)
            for snapshot in range(1, 9)]


class BReserveTests(unittest.TestCase):
    def select(self, rows, ids=(), groups=(), **kwargs):
        selector = getattr(data_module, "select_b_replay_reserve", None)
        self.assertTrue(callable(selector), "B source-balanced reserve selector is missing")
        return selector(rows, ids, groups, **kwargs)

    def test_sampling_balances_all_bearings_and_conditions_without_ranking_targets(self):
        rows = training_fixture()
        reserve = self.select(rows)
        changed = copy.deepcopy(list(reversed(rows)))
        for row in changed:
            row["answer"] += 1000.
        again = self.select(changed)
        self.assertEqual(reserve["ids"], again["ids"])
        self.assertEqual(len(set(reserve["ids"])), 48)
        counts = Counter(reserve["groups"])
        self.assertEqual(len(counts), 9)
        self.assertEqual(sorted(counts.values()), [5] * 6 + [6] * 3)
        self.assertEqual(Counter(group.split("_")[0] for group in reserve["groups"]),
                         {"Bearing1": 16, "Bearing2": 16, "Bearing3": 16})
        self.assertEqual(dict(counts), reserve["bearing_counts"])
        np.testing.assert_array_equal(again["y"], reserve["y"] + 1000.)
        np.testing.assert_array_equal(again["x"], reserve["x"])
        lookup = {row["id"]: row for row in rows}
        for index, identity in enumerate(reserve["ids"]):
            row = lookup[identity]
            values, _ = data_module.flatten_features(row["inputs"])
            np.testing.assert_array_equal(reserve["x"][index], values)
            self.assertEqual(reserve["y"][index], row["answer"])
            self.assertEqual(reserve["groups"][index], row["meta"]["bearing"])

    def test_reserve_refuses_duplicate_ids_validation_entities_and_missing_bearings(self):
        rows = training_fixture()
        invalid = ((rows + [rows[0]], (), ()), (rows, [rows[0]["id"]], ()),
                   (rows, (), ["Bearing2_2"]),
                   ([r for r in rows if r["meta"]["bearing"] != "Bearing3_3"], (), ()),
                   ([r for r in rows if r["meta"]["snapshot"] < 6], (), ()))
        for subset, ids, groups in invalid:
            with self.subTest(rows=len(subset), ids=ids, groups=groups), self.assertRaises(ValueError):
                self.select(subset, ids, groups)

    def test_reserve_rejects_invalid_labels_metadata_and_feature_identity(self):
        for field, value in (("answer", float("nan")), ("answer", -1.),
                             ("inputs", {"different": [0.] * 34}),
                             ("meta", {"bearing": "Bearing1_4", "snapshot": 1})):
            rows = training_fixture()
            for row in rows:
                row[field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                self.select(rows, feature_paths=[f"features[{i}]" for i in range(34)])

    def test_actual_reserve_preserves_original_rows_and_disjoint_entities(self):
        from ite.official_model import default_package_path
        data = data_module.load_public_package("B")
        self.assertIn("replay_reserve", data, "B loader must expose historical provenance")
        reserve = data["replay_reserve"]
        self.assertEqual(reserve["x"].shape, (48, 34))
        self.assertFalse(set(reserve["ids"]) & set(data["ids"]))
        self.assertFalse(set(reserve["groups"]) & set(data["groups"]))
        with zipfile.ZipFile(default_package_path("B")) as archive:
            original = {row["id"]: row for row in map(
                json.loads, archive.read("public/train.jsonl").decode().splitlines())}
        for index, identity in enumerate(reserve["ids"]):
            values, paths = data_module.flatten_features(original[identity]["inputs"])
            self.assertEqual(paths, data["feature_paths"])
            np.testing.assert_array_equal(values, reserve["x"][index])
            self.assertEqual(original[identity]["answer"], reserve["y"][index])


class ReplayModel:
    task = "regression"
    mean = np.zeros(34)
    std = np.ones(34)
    candidate_epochs = 5

    def __init__(self, value=0.):
        self.value = value
        self.checkpoint_sha256 = "initial" if value == 0. else "candidate"
        self.steps = 10 if value == 0. else 25

    def predict(self, x):
        return np.full(len(x), self.value)


class BReplayTests(unittest.TestCase):
    def data(self, rows=2400):
        groups = [f"Bearing{condition}_{bearing}" for condition in (1, 2, 3)
                  for bearing in (1, 2, 3) for _ in range(6 if bearing == 1 else 5)]
        reserve = {"x": np.full((48, 34), -100.), "y": np.full(48, 3.),
                   "ids": [f"historical-{i}" for i in range(48)], "groups": groups,
                   "bearing_counts": dict(Counter(groups)),
                   "condition_counts": {f"Bearing{i}": 16 for i in (1, 2, 3)},
                   "selection_policy": "sha256_ranked_5_or_6_per_bearing_48_v1"}
        return {"profile": "B", "task": "regression", "unit": "minutes", "loss_scale": 1.,
                "x": np.repeat(np.arange(rows, dtype=float)[:, None], 34, axis=1),
                "y": np.full(rows, 2.), "ids": [f"online-{i}" for i in range(rows)],
                "groups": ["Bearing3_4"] * rows, "scale": np.ones(34), "replay_reserve": reserve}

    def run_replay(self, data, output, trainer, **kwargs):
        return replay_partition(data, list(range(len(data["ids"]))), "train", "abrupt", output,
            ReplayModel(), lambda _: {"action": "RETRAIN_HEAD_ONLY", "reason": "来源均衡回放。"},
            decision_steps=(7,), trainer=trainer, action_profile="official_finetune",
            b_replay_policy="source_balanced_official_train", **kwargs)

    def test_replay_replaces_oldest_48_preserving_screen_future_and_effective_version(self):
        data = self.data()
        calls = []
        def train(parent, x, y, allowance, **options):
            calls.append((x.copy(), y.copy(), allowance, options))
            return ReplayModel(2.), .01
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "run"
            summary = self.run_replay(data, out, train)
            events = [json.loads(s) for s in (out / "events.jsonl").read_text(encoding="utf-8").splitlines()]
            with np.load(out / "predictions.npz", allow_pickle=False) as v:
                np.testing.assert_array_equal(v["versions"], np.r_[np.zeros(2000), np.ones(400)])
        self.assertEqual(len(calls), 1)
        x, y, allowance, options = calls[0]
        self.assertEqual(x.shape, (720, 34))
        np.testing.assert_array_equal(x[:48], data["replay_reserve"]["x"])
        np.testing.assert_array_equal(x[48:], data["x"][680:1352] + .75)
        np.testing.assert_array_equal(y, np.r_[np.full(48, 3.), np.full(672, 2.)])
        self.assertEqual((allowance, options), (5., {"trainable_policy": "head_only"}))
        c = next(e for e in events if e["event"] == "candidate_evaluated")
        self.assertEqual(c["train_source_ids"], data["replay_reserve"]["ids"] + data["ids"][680:1352])
        self.assertEqual(c["replaced_online_source_ids"], data["ids"][632:680])
        self.assertEqual(c["screening_source_ids"], data["ids"][1352:1400])
        self.assertEqual(c["b_replay_policy"], "source_balanced_official_train")
        gate = next(e for e in events if e["event"] == "deploy")
        self.assertEqual((gate["step"], gate["frozen_at"], gate["gate_min_source_step"]), (9, 7, 8))
        self.assertEqual(gate["source_ids"], data["ids"][1600:1800])
        self.assertFalse(set(gate["source_ids"]) & set(c["train_source_ids"]))
        self.assertEqual(summary["updates"], 1)

    def test_replay_rejects_future_ids_validation_entities_and_invalid_distribution(self):
        for field, value in (("ids", "online-2200"), ("groups", "Bearing3_4"),
                             ("groups", "Bearing1_1")):
            data = self.data()
            data["replay_reserve"][field][-1] = value
            with self.subTest(field=field, value=value), tempfile.TemporaryDirectory() as tmp:
                with self.assertRaises(ValueError):
                    self.run_replay(data, Path(tmp) / "run", None)

    def test_replay_rejects_cross_profile_and_loss_changes_before_creating_output(self):
        for change, options in (({"profile": "C"}, {}),
                                ({}, {"candidate_loss_policy": "overestimate_2x"})):
            with self.subTest(change=change), tempfile.TemporaryDirectory() as tmp:
                out = Path(tmp) / "run"
                with self.assertRaises(ValueError):
                    self.run_replay({**self.data(), **change}, out, None, **options)
                self.assertFalse(out.exists())

    def test_short_history_refuses_replay_without_padding_fit_size(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "run"
            result = self.run_replay(self.data(96), out, None)
        self.assertEqual(result["training_attempts"], 0)
        self.assertEqual(result["records"][0]["rejection"], "insufficient_online_train_rows_for_b_replay")


class BReplayComparisonTests(unittest.TestCase):
    def module(self):
        try:
            return importlib.import_module("scripts.run_official_b_replay_comparison")
        except ImportError as error:
            self.fail(f"B source-balanced comparison is missing: {error}")

    def test_case_plan_is_paired_head_training_at_step7_in_all_partitions(self):
        m = self.module()
        cases = m.case_plan()
        self.assertEqual(len(cases), 18)
        for split in ("train", "eval"):
            for scenario in ("stable", "abrupt", "gradual"):
                group = [c for c in cases if c["split"] == split and c["scenario"] == scenario]
                self.assertEqual({c["arm"] for c in group}, {"static", "head_only", "head_replay"})
                self.assertTrue(all(c["decision_steps"] == (7,) for c in group))

    def test_lower_rmse_cannot_hide_higher_mae_and_unchanged_drift_is_not_a_win(self):
        m = self.module()
        base = {"targets": np.zeros(4), "static": np.asarray([0., 0., 0., 4.]),
                "source_ids": np.asarray(["a", "b", "c", "d"])}
        rows = {arm: {**base, "active": values} for arm, values in (
            ("static", base["static"]), ("head_only", np.full(4, 1.5)),
            ("head_replay", base["static"]))}
        result = m.summarize_b_replay_paired(rows, "abrupt", source_groups=np.asarray(["B1"] * 2 + ["B2"] * 2))
        self.assertFalse(result["passes"]["head_only"])
        self.assertFalse(result["passes"]["head_replay"])
        self.assertEqual(result["bearing_metrics"]["B1"]["head_only"]["bias"], 1.5)
        self.assertEqual(result["bearing_metrics"]["B1"]["head_only"]["residual_std"], 0.)

    def test_pairing_rejects_changed_ids_and_existing_output_is_immutable(self):
        m = self.module()
        base = {"targets": np.zeros(2), "static": np.ones(2), "active": np.ones(2),
                "source_ids": np.asarray(["a", "b"])}
        rows = {arm: dict(base) for arm in ("static", "head_only", "head_replay")}
        rows["head_replay"]["source_ids"] = np.asarray(["b", "a"])
        with self.assertRaises(ValueError):
            m.summarize_b_replay_paired(rows, "stable")
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(FileExistsError):
                m.run_comparison(Path(tmp))

    def test_engineering_audit_requires_bound_future_verdict_for_frozen_candidate(self):
        m = self.module()
        online = [f"online-{i}" for i in range(54)]
        reserve = [f"history-{i}" for i in range(48)]
        candidate = {"event": "candidate_evaluated", "step": 7, "decision_id": "B-eval-abrupt-7",
            "train_source_ids": reserve + online[48:], "screening_source_ids": [f"screen-{i}" for i in range(18)],
            "online_train_source_ids": online, "replay_source_ids": reserve,
            "replaced_online_source_ids": online[:48], "train_samples": 54, "screening_samples": 18,
            "train_seconds": .02, "candidate_adam_steps": 15, "parent_adam_steps": 10,
            "fit_audit": {"trainable_policy": "head_only", "trainable_parameters": 25, "epochs_added": 5},
            "b_replay_policy": "source_balanced_official_train"}
        events = [{"event": "prediction", "step": s, "model_version": int(s >= 10)} for s in range(12)]
        events += [candidate, {"event": "candidate_frozen", "step": 7, "decision_id": candidate["decision_id"]},
            {"event": "deploy", "step": 9, "reason": "independent_future_labels", "frozen_at": 7,
             "gate_min_source_step": 8, "decision_id": candidate["decision_id"], "source_ids": ["future-1"],
             "candidate_replay_source_ids": reserve}]
        case = {"arm": "head_replay", "split": "eval", "replay_policy": "source_balanced_official_train"}
        summary = {"train_seconds": .02, "training_attempts": 1, "updates": 1}
        self.assertEqual(m.engineering_issues(case, summary, events, reserve), [])
        events[-1]["source_ids"] = [reserve[0]]
        self.assertIn("future_isolation", m.engineering_issues(case, summary, events, reserve))
        events.pop()
        for e in events[:12]:
            e["model_version"] = 0
        summary["updates"] = 0
        self.assertIn("missing_future_verdict", m.engineering_issues(case, summary, events, reserve))


if __name__ == "__main__":
    unittest.main()
