import unittest

import numpy as np

from ite.config import ExperimentConfig
from ite.data import make_simulation
from ite.models import RidgeModel

try:
    from ite.diagnostics import drift_diagnostics
except ImportError:
    drift_diagnostics = None


class DiagnosticTests(unittest.TestCase):
    def test_repeated_drift_delays_misses_and_postchange_loss_are_scored_offline(self):
        self.assertIsNotNone(drift_diagnostics, "Offline drift diagnostics are missing")
        config = ExperimentConfig(n_batches=12, drift_start=3, drift_width=4, scenario="recurring")
        result = drift_diagnostics(config, [0.25] * 12, [3, 7, 8, 10])
        self.assertEqual(result["drift_changes"], 3)
        self.assertEqual(result["missed_changes"], 1)
        self.assertEqual(result["mean_detection_delay_batches"], 0)
        self.assertEqual(result["false_alarms"], 0)
        self.assertEqual(result["redundant_alerts"], 2)
        self.assertEqual(result["post_drift_cumulative_loss"], 2.25)
        self.assertEqual(result["changes"][-1]["detection_delay_batches"], None)

    def test_recurring_diagnostics_start_at_the_generators_first_changed_batch(self):
        config = ExperimentConfig(task="regression", n_batches=12, drift_start=3, drift_width=4,
                                  scenario="recurring", initial_train=2048)
        simulation = make_simulation(config)
        initial = simulation.initial
        model = RidgeModel("regression", .1).fit(initial.train_x, initial.train_y)
        losses = simulation.scorer.score([model.predict(batch.features) for batch in simulation.batches])
        self.assertLess(losses[2], .1)
        self.assertGreater(losses[3], 1.)
        diagnostics = drift_diagnostics(config, losses, [])
        self.assertEqual([change["source_step"] for change in diagnostics["changes"]], [3, 7, 11])

    def test_covariate_shift_does_not_count_as_a_known_concept_change(self):
        self.assertIsNotNone(drift_diagnostics, "Offline drift diagnostics are missing")
        result = drift_diagnostics(ExperimentConfig(n_batches=4, scenario="covariate"), [0.1] * 4, [2])
        self.assertEqual(result["drift_changes"], 0)
        self.assertEqual(result["false_alarms"], 1)
        self.assertIsNone(result["mean_detection_delay_batches"])
        self.assertIsNone(result["post_drift_cumulative_loss"])


if __name__ == "__main__":
    unittest.main()
