"""The pre-registered stress matrix is exactly 144 offline runs."""

import unittest

from ite.config import ExperimentConfig


class HarnessMatrixTests(unittest.TestCase):
    def test_matrix_cases_cover_normal_and_faults_without_real_backend(self):
        from ite.harness_matrix import matrix_cases
        cases = matrix_cases()
        self.assertEqual(len(cases), 144)
        self.assertEqual(len({name for name, _, _ in cases}), 144)
        self.assertEqual(sum(policy == "static" for _, _, policy in cases), 36)
        self.assertEqual(sum(config.harness_mock_mode == "normal" for _, config, _ in cases), 72)
        self.assertEqual(sum(config.harness_mock_mode == "invalid_json" for _, config, _ in cases), 36)
        self.assertEqual(sum(config.harness_mock_mode == "token_exhausted" for _, config, _ in cases), 36)
        self.assertTrue(all(config.harness_backend == "mock" and config.n_batches == 96 for _, config, _ in cases))

    def test_supplied_real_config_is_rejected(self):
        from ite.harness_matrix import matrix_cases
        real = ExperimentConfig(harness_backend="pytrio", harness_enabled=True,
            n_batches=96,
            harness_drift_only=True, llm_ledger_path="never.json", deployment_validation="future",
            training_preflight=True, candidate_feasibility=True)
        with self.assertRaises(ValueError):
            matrix_cases(real)

    def test_protocol_audit_rejects_work_after_trip_in_the_same_batch(self):
        from ite.harness_matrix import audit_protocol
        events = [{"event": "prediction", "step": 0},
                  {"event": "budget_guard_tripped", "step": 0, "reason": "token_limit"},
                  {"event": "deploy", "step": 0}]
        for name in ("deploy", "candidate_evaluated", "candidate_selection"):
            with self.subTest(name=name), self.assertRaisesRegex(RuntimeError, "after fallback"):
                events[-1]["event"] = name
                audit_protocol(events, {"real_llm_tokens": 0, "llm_calls": 1}, batches=1)


if __name__ == "__main__":
    unittest.main()
