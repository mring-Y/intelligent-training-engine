"""Prediction parity for the official CPU regression checkpoints."""

import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import zipfile

import numpy as np

from ite.official_model import OfficialModelAdapter
from ite.model_factory import make_model


ROOT = Path(__file__).resolve().parents[1]
PACKAGES = {
    "B": (ROOT / "third_party/official_baselines/cpu-b-rul-20261110-v1.zip", 34),
    "C": (ROOT / "third_party/official_baselines/cpu-c-guide-20261110-v1.zip", 24),
}
RUNTIME = Path(os.environ.get(
    "ITE_OFFICIAL_RUNTIME_PYTHON", ROOT / ".venv-official-a" / "Scripts" / "python.exe"))
RUNTIME_IS_SEPARATE = RUNTIME.resolve() != Path(sys.executable).resolve()


def _rows(package, limit=32):
    with zipfile.ZipFile(package) as archive:
        return [json.loads(line) for line in archive.read("public/validation.jsonl").decode("utf-8").splitlines()[:limit]]


def _member_rows(package, member, limit):
    with zipfile.ZipFile(package) as archive:
        return [json.loads(line) for line in archive.read(member).decode("utf-8").splitlines()[:limit]]


def _flatten(value):
    values = []
    def visit(item):
        if isinstance(item, dict):
            for key in sorted(item):
                visit(item[key])
        elif isinstance(item, list):
            for child in item:
                visit(child)
        else:
            values.append(float(item))
    visit(value)
    return values


@unittest.skipUnless(RUNTIME.is_file(), "isolated NumPy 1.26.4 official runtime is not provisioned")
class OfficialRegressionPredictionParityTests(unittest.TestCase):
    def test_b_and_c_predictions_match_official_predict_cli_within_one_micro_unit(self):
        for profile, (package, expected_features) in PACKAGES.items():
            with self.subTest(profile=profile):
                rows = _rows(package)
                features = np.asarray([_flatten(row["inputs"]) for row in rows], dtype=np.float64)
                self.assertEqual(features.shape[1], expected_features)
                task = "regression"
                try:
                    model = make_model(task, None, model_type="official_mlp", official_options={
                        "profile_type": profile, "runtime_python": str(RUNTIME),
                        "package_path": str(package), "classes": (), "class_labels": (),
                    })
                except Exception as error:
                    self.fail(f"Official profile {profile} must load for prediction parity: {error}")

                with tempfile.TemporaryDirectory() as temporary:
                    checkpoint = Path(temporary) / "checkpoint.npz"
                    with zipfile.ZipFile(package) as archive:
                        checkpoint.write_bytes(archive.read("checkpoint.npz"))
                    environment = os.environ.copy()
                    environment["PYTHONPATH"] = str(package) + os.pathsep + environment.get("PYTHONPATH", "")
                    for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
                        environment[key] = "1"
                    requests = "".join(json.dumps({"task": task, "inputs": row["inputs"]}) + "\n"
                                       for row in rows)
                    completed = subprocess.run([str(RUNTIME), "-m", "baselines.predict",
                        "--checkpoint", str(checkpoint)], input=requests, text=True,
                        capture_output=True, env=environment, check=True)

                expected = np.asarray([json.loads(line)["outputs"]["value"]
                                       for line in completed.stdout.splitlines()], dtype=np.float64)
                actual = np.asarray(model.predict(features), dtype=np.float64)
                self.assertEqual(actual.shape, expected.shape)
                self.assertTrue(np.isfinite(actual).all())
                self.assertLess(float(np.max(np.abs(actual - expected))), 1e-6)

    def test_package_profile_mismatch_is_rejected(self):
        package = PACKAGES["B"][0]
        try:
            OfficialModelAdapter(task="regression", runtime_python=RUNTIME,
                                 package_path=package, profile_type="C", validate_runtime=False)
        except ValueError as error:
            self.assertRegex(str(error), "profile|metadata|dataset")
        except Exception as error:
            self.fail(f"Profile mismatch must be rejected as package validation: {error}")
        else:
            self.fail("A B checkpoint must not load as profile C")

    def test_b_and_c_resume_matches_official_cli_checkpoint_bytes(self):
        for profile, (package, _) in PACKAGES.items():
            with self.subTest(profile=profile), tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary)
                vendor = root / "vendor"
                vendor.mkdir()
                with zipfile.ZipFile(package) as archive:
                    for item in archive.infolist():
                        destination = (vendor / item.filename).resolve()
                        if not destination.is_relative_to(vendor.resolve()):
                            self.fail("Official package contains a path outside its archive root")
                        if item.is_dir():
                            destination.mkdir(parents=True, exist_ok=True)
                        else:
                            destination.parent.mkdir(parents=True, exist_ok=True)
                            destination.write_bytes(archive.read(item))
                train_rows = _member_rows(package, "public/train.jsonl", 32)
                validation_rows = _member_rows(package, "public/validation.jsonl", 16)
                train_path, validation_path = root / "train.jsonl", root / "validation.jsonl"
                train_path.write_text("".join(json.dumps(row) + "\n" for row in train_rows), encoding="utf-8")
                validation_path.write_text("".join(json.dumps(row) + "\n" for row in validation_rows), encoding="utf-8")
                train_x = np.asarray([_flatten(row["inputs"]) for row in train_rows], dtype=np.float64)
                train_y = np.asarray([row["answer"] for row in train_rows], dtype=np.float64)
                try:
                    parent = OfficialModelAdapter(task="regression", runtime_python=RUNTIME,
                        package_path=package, profile_type=profile,
                        validate_runtime=RUNTIME_IS_SEPARATE)
                except Exception as error:
                    self.fail(f"Official profile {profile} must load before resume parity: {error}")
                parent_bytes = parent.checkpoint_bytes
                candidate = OfficialModelAdapter.from_state(parent.state())
                output = root / "resume-round"
                environment = os.environ.copy()
                environment["BASELINE_CPU_THREADS"] = "1"
                environment["PYTHONPATH"] = str(vendor) + os.pathsep + environment.get("PYTHONPATH", "")
                subprocess.run([str(RUNTIME), "-m", "baselines.train", "--profile", profile,
                    "--train", str(train_path), "--validation", str(validation_path),
                    "--resume", str(vendor / "checkpoint.npz"), "--epochs", "1",
                    "--output", str(output), "--stage-id", "adapter-parity"], cwd=vendor,
                    text=True, capture_output=True, env=environment, check=True)
                candidate.fit(train_x, train_y, epochs=1, timeout_seconds=10.0)
                self.assertEqual(parent.checkpoint_bytes, parent_bytes)
                self.assertEqual(candidate.checkpoint_bytes, (output / "checkpoint.npz").read_bytes())
                self.assertGreater(candidate.steps, parent.steps)

    def test_regression_metrics_are_reported_in_target_units(self):
        from ite.data import RetrospectiveScorer

        scorer = RetrospectiveScorer("regression", [np.asarray([60.0, 120.0])], scale=3600.0)
        metrics = getattr(scorer, "regression_metrics", None)
        self.assertTrue(callable(metrics), "Regression scorer must expose raw-unit RMSE and MAE")
        result = metrics([np.asarray([50.0, 100.0])])
        self.assertAlmostEqual(result["rmse"], np.sqrt(250.0))
        self.assertAlmostEqual(result["mae"], 15.0)
        self.assertNotIn("macro_f1", result)


if __name__ == "__main__":
    unittest.main()
