"""Multiclass Runner integration and retrospective-only real-file scoring."""

import importlib
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

from ite.config import ExperimentConfig
from ite.runner import _validate_targets, run_policy
from ite.training import BoundedTrainer
from scripts.data_prep.common import export_dataset
from scripts.data_prep.provider import PreparedDataProvider


class GasHarnessExperimentTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def module(self):
        try:
            return importlib.import_module("scripts.run_gas_harness")
        except ImportError as error:
            self.fail(f"Gas Harness experiment integration missing: {error}")

    def config(self):
        return ExperimentConfig.from_dict(dict(task="classification", model_family="ovr_ridge",
            n_features=6, initial_train=24, initial_validation=24, n_batches=9, batch_size=24,
            drift_start=0, label_mode="provided", label_delay=2, harness_enabled=True,
            harness_drift_only=True, deployment_validation="future", training_preflight=True,
            candidate_feasibility=True, selection_split="recent_disjoint", candidate_alphas=[1.0],
            history_windows=[24, 48, 72], min_labeled=24, monitor_min_labeled=24,
            min_validation=6, max_tokens=1000, max_llm_calls=5))

    def package(self, sizes=(24,) * 9):
        rows = [{**{f"x{j}": float(i == j) for j in range(6)}, "target": i + 1}
                for i in range(6) for _ in range(4)]
        stream = []
        # Future concept is a cyclic label permutation, with all six classes.
        for step, size in enumerate(sizes):
            for i in range(size):
                stream.append({**{f"x{j}": float(i % 6 == j) for j in range(6)},
                               "target": (i % 6 + 1) % 6 + 1, "batch_id": step})
        export_dataset(self.root / "gas", dataset="uci_gas", task="multiclass",
            features=[f"x{i}" for i in range(6)], train_rows=rows, val_rows=rows,
            stream_rows=stream, metadata={"classes": [1, 2, 3, 4, 5, 6],
                "stream_source_batches": list(range(2, 11))}, batch_size=24)
        return self.root / "gas"

    def test_explicit_ovr_target_validation_preserves_binary_default(self):
        _validate_targets("classification", np.arange(1, 7), "ovr_ridge")
        _validate_targets("classification", np.array([0, 1]))
        for values in ([0, 1, 2], [1, 2, 7], [1, 2.5], [1, np.nan], ["1", "2"]):
            with self.subTest(values=values), self.assertRaises(ValueError):
                _validate_targets("classification", np.asarray(values), "ovr_ridge")
        with self.assertRaises(ValueError):
            _validate_targets("classification", np.array([1, 2]))

    def test_ovr_runner_rejects_synthetic_source_before_creating_output(self):
        with self.assertRaisesRegex(ValueError, "provider|Provider"):
            run_policy(self.config(), "static", self.root / "invalid", None)
        self.assertFalse((self.root / "invalid").exists())

    def test_scorer_is_lazy_checks_boundaries_and_uses_sample_weighted_accuracy(self):
        module = self.module()
        package = self.package(sizes=(6, 12, 24, 24, 24, 24, 24, 24, 24))
        manifest = json.loads((package / "manifest.json").read_text())
        with patch.object(module.pq, "ParquetFile", side_effect=AssertionError("early label read")):
            scorer = module.GasOfflineScorer(package, manifest, (6, 12, 24, 24, 24, 24, 24, 24, 24))
        predictions = [np.array([(i % 6 + 1) % 6 + 1 for i in range(n)])
                       for n in scorer.batch_sizes]
        predictions[0][:] = 1
        losses = scorer.score(predictions)
        self.assertEqual(losses[0], 5 / 6)
        self.assertEqual(losses[1:], [0.] * 8)
        counts = scorer.classification_counts(predictions)
        self.assertEqual(counts["samples"], 186)
        self.assertEqual(counts["correct"], 181)
        self.assertEqual(counts["sample_weighted_accuracy"], 181 / 186)
        self.assertEqual(sum(map(sum, counts["confusion_matrix"])), 186)
        with self.assertRaises(ValueError):
            scorer.score(predictions[:-1])
        predictions[0][0] = 7
        with self.assertRaises(ValueError):
            scorer.score(predictions)

    def test_pair_reuses_controller_future_gate_and_actual_next_prediction_version(self):
        module = self.module()
        package = self.package()
        completed = []
        original = PreparedDataProvider.iter_batches
        original_score = module.GasOfflineScorer.score

        def tracked(provider):
            yield from original(provider)
            completed.append(provider)

        def score(scorer, predictions):
            self.assertGreaterEqual(len(completed), 1)
            return original_score(scorer, predictions)

        with patch.object(PreparedDataProvider, "iter_batches", tracked), \
                patch.object(module.GasOfflineScorer, "score", score):
            result = module.run_gas_pair(package, self.root / "pair", self.config())
        self.assertEqual(len(completed), 2)
        self.assertEqual(result["static"]["sample_weighted_accuracy"], 0.)
        self.assertGreater(result["drift"]["sample_weighted_accuracy"], 0.)
        self.assertEqual(result["drift"]["real_llm_tokens"], 0)
        self.assertEqual(result["drift"]["stream_batches"], 9)
        events = [json.loads(line) for line in
                  (self.root / "pair/drift/events.jsonl").read_text().splitlines()]
        self.assertTrue(any(e["event"] == "harness_decision" and e["action"] == "RETRAIN_SMALL" for e in events))
        deployments = [e for e in events if e["event"] == "deploy"]
        self.assertTrue(deployments)
        for event in deployments:
            self.assertGreater(event["gate_min_source_step"], event["frozen_at"])
            same = next(e for e in events if e["event"] == "prediction" and e["step"] == event["step"])
            after = next(e for e in events if e["event"] == "prediction" and e["step"] == event["step"] + 1)
            self.assertLess(same["model_version"], event["model_version"])
            self.assertEqual(after["model_version"], event["model_version"])
        self.assertFalse(any(e["event"] == "run_failed" for e in events))
        self.assertNotIn("false_positive_rate", result["drift"])
        with self.assertRaises(FileExistsError):
            module.run_gas_pair(package, self.root / "pair", self.config())

    def test_fixed_real_config_is_mock_nine_batches_and_original_alpha(self):
        config = ExperimentConfig.load(Path(__file__).resolve().parents[1] / "configs/gas-harness-mock.json")
        self.assertEqual((config.n_batches, config.n_features, config.batch_size), (9, 128, 3613))
        self.assertEqual(config.candidate_alphas, (1.0,))
        self.assertEqual(config.harness_backend, "mock")
        self.assertEqual(config.label_delay, 2)
        self.assertTrue(config.harness_enabled and config.harness_drift_only)


if __name__ == "__main__":
    unittest.main()
