import importlib
import json
import tempfile
import unittest
from pathlib import Path

import numpy as np

from ite.models import RidgeModel
from scripts.data_prep.common import export_dataset

try:
    models = importlib.import_module("scripts.data_prep.models")
    baseline = importlib.import_module("scripts.data_prep.baseline")
except ImportError:
    models = baseline = None


class PublicABaselineTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(models, "One-vs-Rest Ridge wrapper is not implemented")
        self.assertIsNotNone(baseline, "Public A static baseline is not implemented")
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def test_ovr_argmax_keeps_all_six_classes_and_restores_without_pickle(self):
        x = np.repeat(np.eye(6), 4, axis=0)
        y = np.repeat(np.arange(1, 7), 4)
        model = models.OneVsRestRidge(alpha=1.0).fit(x, y)
        np.testing.assert_array_equal(model.predict(np.eye(6)), [1, 2, 3, 4, 5, 6])
        model.save(self.root / "model.npz")
        restored = models.OneVsRestRidge.load(self.root / "model.npz")
        np.testing.assert_array_equal(restored.decision_function(x), model.decision_function(x))
        with np.load(self.root / "model.npz", allow_pickle=False) as values:
            self.assertTrue(all(values[name].dtype.kind != "O" for name in values.files))
        with self.assertRaises(ValueError):
            models.OneVsRestRidge().fit(x[y != 6], y[y != 6])
        with self.assertRaises(ValueError):
            models.OneVsRestRidge().fit(x, np.where(y == 6, 7, y))

    def test_regression_stream_scores_only_after_all_prediction_commits(self):
        rows = [{"x": float(i), "target": 2. * i + 3.} for i in range(8)]
        package = self.root / "package"
        export_dataset(package, dataset="linear", task="regression", features=["x"],
                       train_rows=rows, val_rows=[dict(row) for row in rows],
                       stream_rows=[{"x": 1., "target": 5.}, {"x": 2., "target": 7.}],
                       metadata={"target_unit": "cycles"}, batch_size=1)
        result = baseline.run_baseline(package, self.root / "run", alpha=1.0)
        # Standardized ridge with n=8, alpha=1 shrinks the slope by 8/9.
        # At x=1,2 residuals are +5/9,+1/3; RMSE=sqrt(17)/9.
        self.assertAlmostEqual(result["test"]["rmse"], np.sqrt(17) / 9, places=10)
        self.assertEqual(result["stream_batches"], 2)
        events = [json.loads(line) for line in (self.root / "run/events.jsonl").read_text().splitlines()]
        self.assertEqual([event["event"] for event in events],
                         ["run_started", "initial_training", "prediction", "prediction", "offline_scoring", "run_completed"])
        with self.assertRaises(FileExistsError):
            baseline.run_baseline(package, self.root / "run")

    def test_six_class_package_baseline_and_binary_model_compatibility(self):
        rows = [{**{f"x{j}": float(i == j) for j in range(6)}, "target": i + 1}
                for i in range(6) for _ in range(4)]
        export_dataset(self.root / "gas", dataset="gas", task="multiclass",
                       features=[f"x{i}" for i in range(6)], train_rows=rows, val_rows=rows,
                       stream_rows=rows, metadata={"classes": [1, 2, 3, 4, 5, 6]}, batch_size=12)
        result = baseline.run_baseline(self.root / "gas", self.root / "gas-run")
        self.assertEqual(result["test"]["accuracy"], 1.0)
        self.assertEqual(result["test"]["confusion_matrix"], (4 * np.eye(6, dtype=int)).tolist())
        original = RidgeModel().fit([[-2], [-1], [1], [2]], [0, 0, 1, 1])
        np.testing.assert_array_equal(original.predict([[-2], [2]]), [0, 1])

    def test_manifest_tampering_is_rejected_before_predictions(self):
        rows = [{"x": i, "target": i} for i in range(4)]
        export_dataset(self.root / "package", dataset="test", task="regression", features=["x"],
                       train_rows=rows, val_rows=rows, stream_rows=rows, metadata={})
        with (self.root / "package/train.csv").open("a") as stream:
            stream.write("corruption\n")
        with self.assertRaises(ValueError):
            baseline.run_baseline(self.root / "package", self.root / "bad-run")


if __name__ == "__main__":
    unittest.main()
