"""Optional RUL clipping preserves recorded-time labels and immutable exports."""
import csv
import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from contextlib import redirect_stdout
from unittest.mock import patch

import numpy as np
import pyarrow.parquet as pq

from scripts.data_prep.bearing import prepare_bearing


class BearingRulCapTests(unittest.TestCase):
    def make_source(self, root):
        # Two 1-second windows and two dropped samples per capture at 4 Hz.
        # Lifecycles have 3/4/2 captures, spaced by 60 seconds. Thus their
        # first raw targets are 121/181/61 seconds, independently of features.
        counts = {"Bearing1_1": 3, "Bearing1_4": 4, "Bearing1_5": 2}
        for bearing, captures in counts.items():
            for capture in range(1, captures + 1):
                path = root / "35Hz12kN" / bearing / f"{capture}.csv"
                path.parent.mkdir(parents=True, exist_ok=True)
                with path.open("x", newline="", encoding="utf-8") as handle:
                    writer = csv.writer(handle)
                    writer.writerow(["Horizontal_vibration_signals", "Vertical_vibration_signals"])
                    writer.writerows([(capture + index / 10, capture - index / 20)
                                      for index in range(10)])
        return counts

    def prepare(self, source, output, **options):
        return prepare_bearing(
            source, output, sample_rate=4, window_seconds=1,
            capture_interval_seconds=60, expected_capture_samples=10,
            expected_capture_counts={"Bearing1_1": 3, "Bearing1_4": 4, "Bearing1_5": 2},
            train_bearings=["Bearing1_1"], val_bearings=["Bearing1_4"],
            stream_bearings=["Bearing1_5"], batch_size=3, **options)

    def rows(self, package, split):
        if split == "stream":
            return pq.read_table(package / "test_stream.parquet").to_pylist()
        filename = "train.csv" if split == "train" else "val.csv"
        with (package / filename).open(newline="", encoding="utf-8") as handle:
            return list(csv.DictReader(handle))

    def test_none_keeps_uncapped_labels_and_exported_bytes(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.make_source(root / "raw")
            self.prepare(root / "raw", root / "default")
            manifest = self.prepare(root / "raw", root / "none", max_rul=None)
            expected = {
                "train": [121., 120., 61., 60., 1., 0.],
                "validation": [181., 180., 121., 120., 61., 60., 1., 0.],
                "stream": [61., 60., 1., 0.],
            }
            for split, targets in expected.items():
                self.assertEqual([float(row["target"]) for row in self.rows(root / "none", split)], targets)
            for filename in ("train.csv", "val.csv", "test_stream.parquet"):
                self.assertEqual((root / "default" / filename).read_bytes(),
                                 (root / "none" / filename).read_bytes())
            self.assertEqual(manifest["metadata"]["rul_cap"], {
                "max_rul_seconds": None,
                "population": "retained valid waveform windows",
                "per_split": {
                    "train": {"raw_max_seconds": 121., "clipped_rows": 0},
                    "validation": {"raw_max_seconds": 181., "clipped_rows": 0},
                    "stream": {"raw_max_seconds": 61., "clipped_rows": 0},
                },
            })

    def test_cap_changes_only_targets_and_counts_strictly_clipped_rows(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.make_source(root / "raw")
            original = self.prepare(root / "raw", root / "original")
            capped = self.prepare(root / "raw", root / "capped", max_rul=60)
            expected = {
                "train": [60., 60., 60., 60., 1., 0.],
                "validation": [60., 60., 60., 60., 60., 60., 1., 0.],
                "stream": [60., 60., 1., 0.],
            }
            for split, targets in expected.items():
                before = self.rows(root / "original", split)
                after = self.rows(root / "capped", split)
                self.assertEqual([float(row["target"]) for row in after], targets)
                self.assertEqual([{key: value for key, value in row.items() if key != "target"}
                                  for row in before],
                                 [{key: value for key, value in row.items() if key != "target"}
                                  for row in after])
            self.assertEqual(capped["metadata"]["rul_cap"], {
                "max_rul_seconds": 60.,
                "population": "retained valid waveform windows",
                "per_split": {
                    "train": {"raw_max_seconds": 121., "clipped_rows": 3},
                    "validation": {"raw_max_seconds": 181., "clipped_rows": 5},
                    "stream": {"raw_max_seconds": 61., "clipped_rows": 1},
                },
            })
            self.assertEqual(capped["column_mapping"], original["column_mapping"])
            self.assertEqual(capped["quality"], original["quality"])
            self.assertEqual(capped["metadata"]["window_audit"], original["metadata"]["window_audit"])
            self.assertEqual(capped["metadata"]["source_files"], original["metadata"]["source_files"])

    def test_cap_above_raw_maximum_is_a_label_and_feature_noop(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.make_source(root / "raw")
            self.prepare(root / "raw", root / "original")
            capped = self.prepare(root / "raw", root / "capped", max_rul=10000.)
            for filename in ("train.csv", "val.csv", "test_stream.parquet"):
                self.assertEqual((root / "original" / filename).read_bytes(),
                                 (root / "capped" / filename).read_bytes())
            self.assertEqual([entry["clipped_rows"] for entry in capped["metadata"]["rul_cap"]["per_split"].values()],
                             [0, 0, 0])

    def test_invalid_cap_is_rejected_before_writing_any_output(self):
        invalid = [True, False, np.bool_(True), 0, -1, float("nan"),
                   float("inf"), -float("inf"), "60", [], 1 + 2j, 10 ** 1000]
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.make_source(root / "raw")
            for index, cap in enumerate(invalid):
                with self.subTest(max_rul=cap):
                    output = root / f"bad-{index}"
                    with self.assertRaisesRegex(ValueError, "max_rul"):
                        self.prepare(root / "raw", output, max_rul=cap)
                    self.assertFalse(output.exists())

    def test_fractional_numeric_cap_is_preserved_in_seconds(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.make_source(root / "raw")
            manifest = self.prepare(root / "raw", root / "out", max_rul=np.float64(.5))
            self.assertEqual([row["target"] for row in self.rows(root / "out", "stream")],
                             [.5, .5, .5, 0.])
            self.assertEqual(manifest["metadata"]["rul_cap"]["max_rul_seconds"], .5)

    def test_existing_package_is_not_overwritten_by_a_different_cap(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.make_source(root / "raw")
            output = root / "out"
            self.prepare(root / "raw", output)
            before = {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                      for path in output.iterdir()}
            with self.assertRaises(FileExistsError):
                self.prepare(root / "raw", output, max_rul=60)
            after = {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                     for path in output.iterdir()}
            self.assertEqual(after, before)

    def test_cli_max_rul_reaches_real_preparation_and_records_counts(self):
        from scripts.data_prep import bearing

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.make_source(root / "raw")
            # The real CLI keeps acquisition defaults; substitute only the
            # controlled fixture's sample/count contract at its I/O boundary.
            real_prepare = bearing.prepare_bearing

            def fixture_prepare(source, output, **options):
                return real_prepare(source, output, sample_rate=4,
                                    expected_capture_samples=10,
                                    expected_capture_counts={"Bearing1_1": 3, "Bearing1_4": 4, "Bearing1_5": 2},
                                    **options)

            with patch.object(bearing, "prepare_bearing", side_effect=fixture_prepare):
                with redirect_stdout(io.StringIO()):
                    bearing.main(["--source", str(root / "raw"), "--output", str(root / "out"),
                                  "--train-bearings", "Bearing1_1", "--val-bearings", "Bearing1_4",
                                  "--stream-bearings", "Bearing1_5", "--batch-size", "3", "--max-rul", "60"])
            manifest = json.loads((root / "out" / "manifest.json").read_text(encoding="utf-8"))
            self.assertEqual([row["target"] for row in self.rows(root / "out", "stream")],
                             [60., 60., 1., 0.])
            self.assertEqual(manifest["metadata"]["rul_cap"]["per_split"]["validation"]["clipped_rows"], 5)


if __name__ == "__main__":
    unittest.main()
