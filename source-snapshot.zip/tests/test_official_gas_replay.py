"""Time-split and scoring contracts for the official A replay."""

import importlib.util
import unittest

import numpy as np

from scripts.run_official_gas import (DEFAULT_PACKAGE, _read_rows, classification_metrics,
    simulate_covariate_drift, split_validation_rows)


class OfficialGasReplayTests(unittest.TestCase):
    def test_replay_exposes_an_explicit_time_ordered_validation_split(self):
        spec = importlib.util.find_spec("scripts.run_official_gas")
        self.assertIsNotNone(spec, "The A baseline replay entry point must exist")
        from scripts.run_official_gas import split_validation_rows
        self.assertTrue(callable(split_validation_rows))

    def test_supplied_validation_rows_keep_time_order_and_disjoint_holdout(self):
        rows = _read_rows(DEFAULT_PACKAGE, "public/validation.jsonl")
        split = split_validation_rows(rows)
        self.assertEqual((len(split["calibration"]), len(split["stream"]), len(split["future"])),
                         (124, 809, 311))
        ids = [row["id"] for key in ("calibration", "stream", "future") for row in split[key]]
        self.assertEqual(len(ids), len(set(ids)))
        self.assertEqual(split["source_batch"], 2)

    def test_simulated_covariate_shift_does_not_change_labels_or_pre_drift_features(self):
        features = np.zeros((2, 128))
        scale = np.ones(128)
        untouched = simulate_covariate_drift(features, scale, False)
        shifted = simulate_covariate_drift(features, scale, True)
        np.testing.assert_array_equal(untouched, features)
        np.testing.assert_array_equal(shifted, np.full((2, 128), 1.5))

    def test_macro_f1_includes_all_six_fixed_classes(self):
        metrics = classification_metrics([1, 1, 2, 3, 4, 5], [1, 2, 2, 3, 4, 4])
        self.assertEqual(len(metrics["classes"]), 6)
        self.assertAlmostEqual(metrics["accuracy"], 4 / 6)
        self.assertAlmostEqual(metrics["macro_f1"], (2 / 3 + 2 / 3 + 1 + 2 / 3 + 0 + 0) / 6)


if __name__ == "__main__":
    unittest.main()
