"""C replay comparisons cannot trade safety, source pairing or frozen state for RMSE."""

import importlib
import io
import json
import tempfile
import unittest
import zipfile
from pathlib import Path

import numpy as np


class CReplayComparisonTests(unittest.TestCase):
    def module(self):
        try:
            return importlib.import_module("scripts.run_official_c_replay_comparison")
        except ImportError as error:
            self.fail(f"C replay comparison is missing: {error}")

    def test_plan_pairs_eighteen_flows_with_identical_head_actions_at_step_seven(self):
        m = self.module()
        cases = m.case_plan()
        self.assertEqual(len({(c["scenario"], c["split"], c["arm"]) for c in cases}), 18)
        self.assertEqual({tuple(c["decision_steps"]) for c in cases}, {(7,)})
        self.assertEqual({c["arm"] for c in cases}, {"static", "head_only", "head_with_replay"})
        for c in cases:
            self.assertEqual(m.fixed_decision(c["arm"])({})["action"],
                             "DO_NOTHING" if c["arm"] == "static" else "RETRAIN_HEAD_ONLY")
        with self.assertRaises(ValueError):
            m.fixed_decision("full")

    def paired(self):
        y = np.asarray([2., 2., 2., 2.])
        baseline = np.zeros(4)
        return {arm: {"targets": y, "source_ids": np.asarray(["a", "b", "c", "d"]),
            "static": baseline, "active": p} for arm, p in (("static", baseline),
                ("head_only", np.full(4, 2.5)), ("head_with_replay", np.ones(4)))}

    def test_primary_gain_with_any_safety_regression_is_rejected_and_equal_drift_fails(self):
        m = self.module()
        rows = self.paired()
        result = m.summarize_paired(rows, "abrupt", source_groups=np.asarray(["FD001:0001"]*2+["FD004:0002"]*2))
        self.assertFalse(result["passes"]["head_only"])
        self.assertTrue(result["passes"]["head_with_replay"])
        self.assertEqual(set(result["subset_metrics"]), {"FD001", "FD004"})
        self.assertEqual(result["engine_metrics"]["FD004:0002"]["head_with_replay"]["bias"], -1.)
        for arm in rows:
            rows[arm]["active"] = rows[arm]["static"]
        self.assertTrue(m.summarize_paired(rows, "stable")["passes"]["head_with_replay"])
        self.assertFalse(m.summarize_paired(rows, "gradual")["passes"]["head_with_replay"])

    def test_mean_positive_overestimate_guard_is_separate_from_rate_guard(self):
        m = self.module()
        rows = self.paired()
        for row in rows.values():
            row["static"] = np.asarray([2.1, 0., 0., 0.])
        rows["static"]["active"] = rows["static"]["static"]
        rows["head_with_replay"]["active"] = np.asarray([2.2, 1., 1., 1.])
        result = m.summarize_paired(rows, "abrupt")
        self.assertLess(result["metrics"]["head_with_replay"]["rmse"], result["metrics"]["static"]["rmse"])
        self.assertEqual(result["metrics"]["head_with_replay"]["overestimate_rate"], .25)
        self.assertFalse(result["passes"]["head_with_replay"])

    def test_changed_ids_targets_or_static_reference_reject_unpaired_results(self):
        m = self.module()
        for key, value in (("source_ids", np.asarray(["a", "b", "c", "x"])),
                           ("targets", np.zeros(4)), ("static", np.ones(4))):
            rows = self.paired()
            rows["head_with_replay"][key] = value
            with self.subTest(key=key), self.assertRaisesRegex(ValueError, "Unpaired"):
                m.summarize_paired(rows, "stable")

    def test_checkpoint_audit_rejects_bottom_layer_optimizer_or_fit_contract_changes(self):
        m = self.module()
        from ite.official_model import default_package_path
        with zipfile.ZipFile(default_package_path("C")) as z:
            original = z.read("checkpoint.npz")
        with np.load(io.BytesIO(original), allow_pickle=False) as z:
            state = {k: z[k].copy() for k in z.files}
        metadata = json.loads(state["metadata"].item())
        with tempfile.TemporaryDirectory() as tmp:
            parent, candidate = Path(tmp)/"parent.npz", Path(tmp)/"candidate.npz"
            parent.write_bytes(original)
            for changed_key in (None, "w1", "adam_second_b1", "mean", "learning_rate"):
                values = {k: v.copy() for k, v in state.items()}
                meta = {**metadata, "steps": metadata["steps"] + 15, "epochs": metadata["epochs"] + 5}
                values["w2"] += .01
                values["b2"] += .01
                if changed_key == "learning_rate":
                    meta[changed_key] *= 2
                elif changed_key:
                    values[changed_key] += .01
                values["metadata"] = np.asarray(json.dumps(meta))
                np.savez(candidate, **values)
                if changed_key:
                    with self.subTest(key=changed_key), self.assertRaises(ValueError):
                        m.audit_candidate(parent, candidate)
                else:
                    self.assertEqual(m.audit_candidate(parent, candidate)["trainable_parameters"], 33)

    def test_existing_output_is_refused_before_runtime_or_training(self):
        with tempfile.TemporaryDirectory() as tmp, self.assertRaises(FileExistsError):
            self.module().run_comparison(Path(tmp), "missing-runtime")

    def test_engineering_audit_rejects_future_overlap_or_early_prediction_version(self):
        m = self.module()
        replay_ids = [f"historical-{i}" for i in range(48)]
        online_ids = [f"online-{i}" for i in range(720)]
        candidate = {"event": "candidate_evaluated", "step": 7, "decision_id": "c",
            "train_seconds": .01, "train_samples": 720, "screening_samples": 48,
            "train_source_ids": replay_ids + online_ids[48:], "online_train_source_ids": online_ids,
            "replay_source_ids": replay_ids, "replaced_online_source_ids": online_ids[:48],
            "screening_source_ids": [f"screen-{i}" for i in range(48)],
            "c_replay_policy": "source_balanced_official_train", "loss_policy": "squared",
            "parent_adam_steps": 10, "candidate_adam_steps": 25,
            "fit_audit": {"trainable_policy": "head_only", "trainable_parameters": 33, "epochs_added": 5}}
        gate = {"event": "deploy", "step": 9, "decision_id": "c", "frozen_at": 7,
            "gate_min_source_step": 8, "reason": "independent_future_labels", "model_version": 1,
            "source_ids": ["future"], "candidate_replay_source_ids": replay_ids}
        events = [{"event": "prediction", "step": step, "model_version": int(step >= 10)} for step in range(12)]
        events += [candidate, gate]
        summary = {"train_seconds": .01, "training_attempts": 1, "updates": 1}
        self.assertEqual(m.engineering_issues("head_with_replay", summary, events), [])
        gate["source_ids"] = [replay_ids[0]]
        self.assertTrue(m.engineering_issues("head_with_replay", summary, events))
        gate["source_ids"] = ["future"]
        events[9]["model_version"] = 1
        self.assertTrue(m.engineering_issues("head_with_replay", summary, events))


if __name__ == "__main__":
    unittest.main()
