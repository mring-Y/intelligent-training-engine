import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


class CommandTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(importlib.util.find_spec("ite.cli"), "The command interface is not implemented")

    def test_cli_generates_report_without_external_services(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "run"
            result = subprocess.run([sys.executable, "-m", "ite", "run", "--output", str(output),
                                     "--batches", "6", "--scenario", "stable"],
                                    capture_output=True, text=True, timeout=30)
            self.assertEqual(result.returncode, 0, result.stderr)
            summary = json.loads((output / "summary.json").read_text())
            self.assertEqual(len(summary), 3)
            self.assertTrue(all(item["tokens"] == 0 for item in summary))
            self.assertTrue((output / "report.html").exists())

    def test_invalid_config_has_actionable_error_and_no_traceback(self):
        with tempfile.TemporaryDirectory() as directory:
            config = Path(directory) / "invalid.json"
            config.write_text('{"label_fraction": 2}')
            result = subprocess.run([sys.executable, "-m", "ite", "run", "--config", str(config)],
                                    capture_output=True, text=True, timeout=20)
            self.assertNotEqual(result.returncode, 0)
            self.assertNotIn("Traceback", result.stderr)
            self.assertIn("label", result.stderr.lower())

    def test_matrix_aggregates_two_tasks_even_when_regression_is_first(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "matrix"
            result = subprocess.run([sys.executable, "-m", "ite", "matrix", "--output", str(output),
                                     "--tasks", "regression", "classification", "--scenarios", "stable",
                                     "--seeds", "7", "--batches", "4", "--ablation"],
                                    capture_output=True, text=True, timeout=40)
            self.assertEqual(result.returncode, 0, result.stderr)
            summary = json.loads((output / "summary.json").read_text())
            self.assertEqual(len(summary), 9)
            self.assertTrue((output / "aggregates.csv").exists())

    def test_matrix_config_is_used_and_only_explicit_cli_values_override_it(self):
        with tempfile.TemporaryDirectory() as directory:
            config = Path(directory) / "config.json"
            config.write_text(json.dumps({"task": "regression", "scenario": "stable", "seed": 23,
                                          "n_batches": 5, "label_delay": 4, "label_fraction": 0.1,
                                          "deployment_validation": "future"}))
            output = Path(directory) / "matrix"
            result = subprocess.run([sys.executable, "-m", "ite", "matrix", "--config", str(config),
                                     "--output", str(output), "--batches", "6"],
                                    capture_output=True, text=True, timeout=30)
            self.assertEqual(result.returncode, 0, result.stderr)
            saved = json.loads((output / "regression/stable/seed-23/config.json").read_text())
            self.assertEqual(saved["n_batches"], 6)
            self.assertEqual(saved["label_delay"], 4)
            self.assertEqual(saved["label_fraction"], 0.1)
            self.assertEqual(saved["deployment_validation"], "future")
            rows = json.loads((output / "summary.json").read_text())
            self.assertEqual(len(rows), 3)


if __name__ == "__main__":
    unittest.main()
