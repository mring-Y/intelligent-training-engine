"""Official-model routing and audited fallback contracts."""

import json
import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

from ite.config import ExperimentConfig
from ite.data import InitialData, PublicBatch
from ite.model_factory import make_model as factory_make_model
from ite.providers import OfficialDataProvider
import ite.runner as runner
from ite.runner import run_policy
from ite.training import TrainingResult
from ite.training import BoundedTrainer
from tests.tree_worker_test_timeout import tree_initial_timeout


ROOT = Path(__file__).resolve().parents[1]


class _ProviderIdentity:
    def __init__(self, provenance):
        self._provenance = provenance

    def provenance(self):
        return self._provenance


class _TreeUnavailableTrainer:
    def fit(self, *args, **kwargs):
        return TrainingResult("error", None, 0.001, "scikit-learn unavailable")


class _FailAfterInitialOfficialPrediction:
    model_type = "official_mlp"
    family = "official_cpu_mlp"
    task = "regression"

    def __init__(self, n_features):
        self.mean = np.zeros(n_features)
        self.std = np.ones(n_features)
        self.checkpoint_sha256 = "fake-checkpoint"
        self.calls = 0

    def predict(self, features):
        self.calls += 1
        if self.calls > 1:
            raise RuntimeError("injected official inference failure")
        return np.zeros(len(features))

    def save(self, path):
        Path(path).write_bytes(b"fake official checkpoint")


class _OfficialBearingProvider(OfficialDataProvider):
    def __init__(self, initial):
        self.n_features = 34
        self.batch_sizes = (4,)
        self.label_delay = 0
        self.max_labels = None
        self.total_requested = 0
        self._initial = initial
        self._current = None
        self._committed = False

    def provenance(self):
        return {"kind": "official", "official_profile": "B"}

    def initial_data(self):
        return self._initial

    def iter_batches(self):
        if self._current is not None:
            raise RuntimeError("provider is single use")
        self._current = PublicBatch(0, np.arange(1000, 1004, dtype=np.int64),
                                    self._initial.validation_x[:4])
        yield self._current
        if not self._committed:
            raise ValueError("prediction commit is required")

    def commit_predictions(self, step, sample_ids, predictions):
        if (step != 0 or self._committed or not np.array_equal(sample_ids, self._current.sample_ids)
                or np.shape(predictions) != (4,)):
            raise ValueError("invalid prediction commit")
        self._committed = True

    def request_labels(self, sample_ids, step):
        return 0

    def release_labels(self, step):
        return None

    @property
    def pending_schedule(self):
        return ()


class _RawRegressionScorer:
    def __init__(self, targets):
        self.targets = np.asarray(targets, dtype=float)

    def score(self, predictions):
        residual = np.concatenate(predictions) - self.targets
        return [float(np.mean(residual ** 2))]

    def regression_metrics(self, predictions):
        residual = np.concatenate(predictions) - self.targets
        return {"rmse": float(np.sqrt(np.mean(residual ** 2))),
                "mae": float(np.mean(np.abs(residual)))}


class OfficialFallbackTests(unittest.TestCase):
    def _small_config(self, **overrides):
        values = dict(task="regression", scenario="stable", n_features=3,
            initial_train=24, initial_validation=12, n_batches=2, batch_size=8,
            model_type="official_mlp", official_profile="auto")
        values.update(overrides)
        return ExperimentConfig.from_dict(values)

    def test_auto_profile_uses_provider_identity_and_not_drift_scenario(self):
        config = self._small_config()
        resolve = getattr(runner, "_resolve_official_profile", None)
        self.assertTrue(callable(resolve), "Runner must resolve auto from official provider identity")
        self.assertEqual(resolve(config,
            _ProviderIdentity({"kind": "official", "official_profile": "B"})), "B")
        with self.assertRaisesRegex(ValueError, "official_profile"):
            resolve(config, _ProviderIdentity({"scenario": "C"}))
        with self.assertRaisesRegex(ValueError, "disagree"):
            resolve(ExperimentConfig.from_dict({
                "task": "regression", "n_features": 34, "model_type": "official_mlp",
                "official_profile": "B"}),
                _ProviderIdentity({"official_profile": "C"}))

    def test_auto_profile_routes_runner_to_official_b_regression_contract(self):
        import zipfile

        package = ROOT / "third_party/official_baselines/cpu-b-rul-20261110-v1.zip"
        with zipfile.ZipFile(package) as archive:
            train_rows = [json.loads(line) for line in
                          archive.read("public/train.jsonl").decode("utf-8").splitlines()[:64]]
            validation_rows = [json.loads(line) for line in
                               archive.read("public/validation.jsonl").decode("utf-8").splitlines()[:16]]

        def flatten(value):
            values = []
            def visit(item):
                if isinstance(item, dict):
                    for key in sorted(item):
                        visit(item[key])
                elif isinstance(item, list):
                    for child in item:
                        visit(child)
                else:
                    values.append(float(item))
            visit(value)
            return values

        initial = InitialData(
            np.asarray([flatten(row["inputs"]) for row in train_rows], dtype=float),
            np.asarray([row["answer"] for row in train_rows], dtype=float),
            np.asarray([flatten(row["inputs"]) for row in validation_rows], dtype=float),
            np.asarray([row["answer"] for row in validation_rows], dtype=float))
        provider = _OfficialBearingProvider(initial)
        scorer = _RawRegressionScorer(initial.validation_y[:4])
        config = ExperimentConfig.from_dict({
            "task": "classification", "n_features": 8, "model_type": "official_mlp",
            "official_profile": "auto", "n_batches": 1, "batch_size": 4, "label_delay": 0,
        })

        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "auto-b"
            summary = run_policy(config, "static", output, None, provider=provider, offline_scorer=scorer)
            saved_config = json.loads((output / "config.json").read_text())
            with np.load(output / "predictions.npz", allow_pickle=False) as saved:
                saved_predictions = saved["predictions"].copy()

        self.assertEqual((saved_config["task"], saved_config["n_features"],
                          saved_config["official_profile"]), ("regression", 34, "B"))
        self.assertEqual(summary["model_type"], "official_mlp")
        self.assertEqual(summary["official_profile"], "B")
        self.assertAlmostEqual(summary["rmse"], scorer.regression_metrics(
            [saved_predictions])["rmse"])

    def test_missing_official_profile_falls_back_and_audits_tree_then_ridge(self):
        config = self._small_config()
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "fallback"
            try:
                run_policy(config, "static", output, _TreeUnavailableTrainer())
            except Exception as error:
                self.fail(f"Runner must complete the configured fallback path: {error}")
            events = [json.loads(line) for line in (output / "events.jsonl").read_text().splitlines()]
        fallback = next((event for event in events if event["event"] == "model_fallback"), None)
        self.assertIsNotNone(fallback, "Official initialization failure must have an audit event")
        self.assertEqual(fallback["requested_model_type"], "official_mlp")
        self.assertEqual(fallback["fallback_model_type"], "ridge")
        self.assertIn("official_profile", fallback["failure_reason"])
        self.assertEqual([entry["model_type"] for entry in fallback["attempts"]], ["tree", "ridge"])

    @unittest.skipUnless(importlib.util.find_spec("sklearn"), "scikit-learn is not installed")
    def test_missing_official_profile_prefers_a_trained_tree_when_available(self):
        config = self._small_config()
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "tree-fallback"
            with tree_initial_timeout(), BoundedTrainer() as trainer:
                result = run_policy(config, "static", output, trainer)
            events = [json.loads(line) for line in (output / "events.jsonl").read_text().splitlines()]
        fallback = next(event for event in events if event["event"] == "model_fallback")
        self.assertEqual(fallback["fallback_model_type"], "tree", str(fallback))
        self.assertEqual(fallback["attempts"][0]["status"], "ok")
        self.assertEqual(result["model_type"], "tree")

    def test_official_inference_error_switches_before_prediction_commit(self):
        config = self._small_config(n_features=24, official_profile="C",
                                    official_package_path="unused-official-package.zip")
        original = factory_make_model
        fake = _FailAfterInitialOfficialPrediction(24)

        def make(task, alpha, family="ridge", **options):
            if options.get("model_type") in ("official", "official_mlp"):
                return fake
            return original(task, alpha, family, **options)

        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "inference-fallback"
            with patch("ite.runner.make_model", side_effect=make):
                try:
                    result = run_policy(config, "static", output, _TreeUnavailableTrainer())
                except Exception as error:
                    self.fail(f"Runner must recover from an official inference exception: {error}")
            events = [json.loads(line) for line in (output / "events.jsonl").read_text().splitlines()]

        fallback = next((event for event in events if event["event"] == "model_fallback"), None)
        self.assertIsNotNone(fallback, "Official inference failure must have an audit event")
        prediction = next((event for event in events if event["event"] == "prediction"), None)
        self.assertIsNotNone(prediction)
        self.assertEqual(fallback["step"], 0)
        self.assertIn("injected official inference failure", fallback["failure_reason"])
        self.assertEqual(fallback["fallback_model_type"], "ridge")
        self.assertEqual(prediction["step"], 0)
        self.assertEqual(result["model_type"], "ridge")

    @unittest.skipUnless(importlib.util.find_spec("sklearn"), "scikit-learn is not installed")
    def test_official_inference_error_prefers_tree_when_available(self):
        config = self._small_config(n_features=24, official_profile="C",
                                    official_package_path="unused-official-package.zip")
        original = factory_make_model
        fake = _FailAfterInitialOfficialPrediction(24)

        def make(task, alpha, family="ridge", **options):
            if options.get("model_type") in ("official", "official_mlp"):
                return fake
            return original(task, alpha, family, **options)

        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "inference-tree-fallback"
            with (patch("ite.runner.make_model", side_effect=make), tree_initial_timeout(),
                  BoundedTrainer() as trainer):
                result = run_policy(config, "static", output, trainer)
            events = [json.loads(line) for line in (output / "events.jsonl").read_text().splitlines()]

        fallback = next(event for event in events if event["event"] == "model_fallback")
        prediction = next(event for event in events if event["event"] == "prediction")
        self.assertEqual(fallback["fallback_model_type"], "tree", str(fallback))
        self.assertIn("injected official inference failure", fallback["failure_reason"])
        self.assertEqual(prediction["model_version"], 1)
        self.assertEqual(result["model_type"], "tree")


if __name__ == "__main__":
    unittest.main()
