"""Offline workspace-v2 host fixture; it never calls a model provider."""

from collections import deque
import base64
import hashlib
import json
from pathlib import Path
import zipfile
import tempfile
import os

from contest_harness import Round

ROOT = Path(__file__).resolve().parents[1]
PROMPT = "OFFICIAL_TASK_PROMPT_ATTACHED_ONLY_BY_HOST"


def rows(profile, member):
    from ite.official_model import default_package_path
    with zipfile.ZipFile(default_package_path(profile)) as archive:
        return [json.loads(line) for line in archive.read(member).decode().splitlines() if line.strip()]


def fixture(root, profile):
    source = ROOT / "outputs/continuation-adapter-20261116/fixtures-v1" / profile
    parent = root / "previous"
    parent.mkdir()
    from ite.official_model import default_package_path
    with zipfile.ZipFile(default_package_path(profile)) as archive:
        (parent / "checkpoint.npz").write_bytes(archive.read("checkpoint.npz"))
    train = root / "train.jsonl"
    validation = root / "validation.jsonl"
    if source.is_dir():
        train.write_bytes((source / "train.jsonl").read_bytes())
        validation.write_bytes((source / "validation-1.jsonl").read_bytes())
    else:
        import numpy as np
        train_rows = rows(profile, "public/train.jsonl")
        selected = np.linspace(0, len(train_rows) - 1, min(720, len(train_rows)), dtype=int)
        train.write_text("".join(json.dumps(train_rows[i]) + "\n" for i in selected), encoding="utf-8")
        count = len(rows(profile, "public/validation.jsonl")) // 2 if profile == "A" else 512
        validation.write_text("".join(json.dumps(row) + "\n" for row in rows(profile, "public/validation.jsonl")[:count]), encoding="utf-8")
    return parent, train, validation


def frame(parent, train, validation, profile, *, index=1, state=None, artifact_id=None):
    files = [{"path": p.name, "size_bytes": p.stat().st_size,
              "sha256": "sha256:" + hashlib.sha256(p.read_bytes()).hexdigest()}
             for p in sorted(parent.iterdir()) if p.is_file()]
    descriptor = {"checkpoint_paths": ["checkpoint.npz"],
                  "code_paths": [p["path"] for p in files if p["path"] != "checkpoint.npz"],
                  "predict_argv": ["python3", "/app/harness.py", "predict"]}
    artifact = {"artifact_id": artifact_id or "baseline-" + profile,
                "artifact": descriptor, "files": files}
    artifact["artifact_sha256"] = "sha256:" + hashlib.sha256(json.dumps(
        {"files": files, "artifact": descriptor}, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return {"protocol": "contest.harness.workspace.v2", "run_id": "offline-test",
            "prompt": PROMPT, "prompt_version": "industrial-workspace-flexible-v3",
            "dataset_key": profile, "round_index": index, "rounds_per_dataset": 10,
            "stage_id": "public-development", "parent_checkpoint_sha256": next(p["sha256"] for p in files if p["path"] == "checkpoint.npz"),
            "task_contract": {"dataset_key": profile,
                "task": "classification" if profile == "A" else "regression",
                "metric": "macro_f1" if profile == "A" else "rmse",
                "metric_direction": "higher" if profile == "A" else "lower",
                "public_projection": {"train_path": str(train), "validation_path": str(validation)}},
            "model_name": "trio://offline-test/bound-sampler", "max_output_tokens": 512,
            "parent_artifact": artifact, "artifacts": [artifact],
            "state_path": str(state) if state else None, "state_sha256": "",
            "resource_limits": {"candidate_upload_bytes_per_round": 64 * 1024 * 1024},
            "current_validation": {}, "wall_seconds": 120}


class OfflineHost:
    """Emulate only the external host; run participant and CPU worker unchanged."""

    def __init__(self, start, replies=(), history=(), *, candidate_id="candidate-1"):
        self.start, self.replies, self.history = start, deque(replies), list(history)
        self.candidate_id = candidate_id
        self.incoming, self.frames, self.calls, self.candidates = deque(), [], [], []
        self.states, self.record, self.sequence, self.partial = [], None, 0, ""

    def readline(self):
        return json.dumps(self.incoming.popleft(), ensure_ascii=False) + "\n" if self.incoming else ""

    def write(self, text):
        self.partial += text
        while "\n" in self.partial:
            line, self.partial = self.partial.split("\n", 1)
            if line:
                self.respond(json.loads(line))
        return len(text)

    def flush(self):
        pass

    def respond(self, request):
        self.frames.append(request)
        kind = request["type"]
        if kind == "round_complete":
            self.record = request["record"]
            self.incoming.append({"type": "round_ack", "accepted": True})
            return
        assert request["id"] == self.sequence
        self.sequence += 1
        reply = {"id": request["id"]}
        if kind == "history_request":
            reply.update(type="history_response", records=self.history)
        elif kind == "model_request":
            assert self.replies, "Unexpected additional model request"
            self.calls.append(request)
            content = self.replies.popleft()
            name = request["tools"][0]["function"]["name"]
            arguments = json.dumps(content, ensure_ascii=False) if isinstance(content, dict) else content
            reply.update(type="model_response", call_id=f"call-{len(self.calls)}", response={
                "choices": [{"message": {"role": "assistant", "content": None,
                    "tool_calls": [{"id": f"tool-{len(self.calls)}", "type": "function",
                        "function": {"name": name, "arguments": arguments}}]}}]})
        elif kind == "candidate_request":
            assert request["parent_checkpoint_sha256"] == self.start["parent_checkpoint_sha256"]
            assert request["parent_artifact_id"] == self.start["parent_artifact"]["artifact_id"]
            self.candidates.append(request)
            # Exercise the measurement boundary with actual checkpoint predictions.
            # These are seen public fixtures, not platform or hidden-test scores.
            from ite.official_model import OfficialModelAdapter, OFFICIAL_PROFILES
            from ite.official_sft_data import metrics
            from ite.platform_data import checkpoint_metadata, read_dataset
            with tempfile.TemporaryDirectory() as temp:
                directory = Path(temp)
                for item in request["files"]:
                    (directory / item["path"]).write_bytes(base64.b64decode(item["data_base64"]))
                profile = self.start["dataset_key"]
                checkpoint = directory / "checkpoint.npz"
                runtime = os.environ.get("ITE_OFFICIAL_RUNTIME_PYTHON", str(ROOT / ".venv-official-a/Scripts/python.exe"))
                model = OfficialModelAdapter(OFFICIAL_PROFILES[profile]["task"], runtime,
                    profile_type=profile, checkpoint_path=checkpoint)
                data = read_dataset(self.start["task_contract"]["public_projection"]["validation_path"],
                    profile, checkpoint_metadata(checkpoint)["paths"])
                measured = metrics(profile, data["y"], model.predict(data["x"]))
            reply.update(type="candidate_response", artifact_id=self.candidate_id, summary={"metrics": measured})
        elif kind == "state_request":
            self.states.append(request)
            reply.update(type="state_response", state_sha256="sha256:" + "22" * 32)
        else:
            raise AssertionError(kind)
        self.incoming.append(reply)

    def round(self, parent):
        rnd = Round(self.start, self, self)
        rnd.parent.root = parent
        return rnd

    def save_state(self, destination):
        destination.mkdir()
        for item in self.states[-1]["files"]:
            path = destination / item["path"]
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(base64.b64decode(item["data_base64"]))
