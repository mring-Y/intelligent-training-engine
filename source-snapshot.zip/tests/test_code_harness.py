"""Contracts for model-written code and ten real CPU optimization rounds."""

import json
import tempfile
import unittest
from pathlib import Path

import numpy as np


class Model:
    task = "regression"
    steps = 10
    checkpoint_sha256 = "official"
    candidate_epochs = 5
    mean = np.zeros(2)
    std = np.ones(2)

    def __init__(self, value=0., identity="official", steps=10):
        self.value, self.checkpoint_sha256, self.steps = value, identity, steps

    def predict(self, x):
        return np.full(len(x), self.value)

    def save(self, path):
        Path(path).write_text(self.checkpoint_sha256)


def dataset():
    x = np.column_stack((np.arange(210), np.zeros(210)))
    return {"profile": "B", "task": "regression", "loss_scale": 1.,
            "train_x": np.zeros((12, 2)), "train_y": np.full(12, 2.),
            "train_ids": [f"train-{i}" for i in range(12)],
            "x": x, "y": np.full(210, 2.), "ids": [f"val-{i}" for i in range(210)],
            "scale": np.ones(2), "documents": {"TASK.md": "Public task.",
                "TRAINING_GUIDE.md": "Gradients use public/train.jsonl only."}}


class CodeHarnessTests(unittest.TestCase):
    def module(self):
        from ite import code_harness
        return code_harness

    def test_compiled_code_calls_only_the_supplied_training_capability(self):
        m = self.module()
        source = m.candidate_source(4, "full")
        config, function = m.compile_candidate(source, previous={"epochs": 5, "trainable_policy": "full"},
                                               seen=set(), parent="official")
        calls = []
        result = function(lambda *a, **k: calls.append((a, k)) or "candidate", "parent", "x", "y", 5.)
        self.assertEqual(result, "candidate")
        self.assertEqual(calls, [(("parent", "x", "y", 5.), config)])

    def test_arbitrary_code_and_two_factor_or_duplicate_trials_are_rejected(self):
        m = self.module()
        previous = {"epochs": 5, "trainable_policy": "full"}
        sources = ["import os\nos.system('echo unsafe')", m.candidate_source(3, "head_only"),
                   m.candidate_source(5, "full"), m.candidate_source(0, "full"),
                   m.candidate_source(4, "full") + "\nprint('side effect')\n",
                   "def train_candidate(train, parent, x, y, seconds):\n    return train.__globals__\n"]
        for source in sources:
            with self.subTest(source=source), self.assertRaises(ValueError):
                m.compile_candidate(source, previous=previous, seen=set(), parent="official")
        with self.assertRaises(ValueError):
            m.compile_candidate(m.candidate_source(4, "full"), previous=previous,
                                seen={("official", 4, "full")}, parent="official")

    def test_validation_blocks_are_unique_and_final_block_never_trains(self):
        m = self.module()
        blocks = m.round_blocks(210)
        self.assertEqual(len(blocks), 21)
        self.assertEqual(len(set(np.concatenate(blocks).tolist())), 210)
        with self.assertRaises(ValueError):
            m.round_blocks(41)

    def test_official_gradient_ids_come_only_from_training_and_never_validation(self):
        m = self.module()
        from zipfile import ZipFile
        for profile, count in (("A",445),("B",720),("C",720)):
            with self.subTest(profile=profile):
                data = m.load_round_data(profile)
                with ZipFile(data["package"]) as archive:
                    training_ids = {json.loads(s)["id"] for s in archive.read("public/train.jsonl").decode().splitlines()}
                self.assertEqual(len(data["train_ids"]), count)
                self.assertTrue(set(data["train_ids"]) <= training_ids)
                self.assertFalse(set(data["train_ids"]) & set(data["ids"]))
                self.assertEqual(len(m.round_blocks(len(data["ids"]))),21)

    def test_tool_reads_are_explicit_and_cannot_reach_hidden_or_host_paths(self):
        m = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            run = m.TenRoundRun(Path(tmp)/"run", dataset(), Model(), trainer=None)
            public = run.read_public(["TASK.md", "training.py", "history.json"])
            self.assertIn("TASK.md", public)
            for path in ("../secret", "hidden/test.jsonl", "C:/Users/key", "checkpoint.npz"):
                with self.subTest(path=path), self.assertRaises(ValueError):
                    run.read_public([path])

    def test_freeze_precedes_gate_release_and_selection_requires_future_gain(self):
        m = self.module()
        parents = []
        def train(parent, x, y, seconds, **options):
            parents.append((parent.checkpoint_sha256, x.copy(), seconds, options))
            return Model(2., "candidate", 11), .01
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)/"run"
            run = m.TenRoundRun(root, dataset(), Model(), trainer=train)
            result = run.experiment(m.candidate_source(4, "full"), "Change epochs only.")
            self.assertTrue(result["gate_passed"])
            self.assertEqual(run.model.checkpoint_sha256, "official")
            run.select("candidate", "Independent gate improved.")
            self.assertEqual(run.model.checkpoint_sha256, "candidate")
            events = [json.loads(s) for s in (root/"events.jsonl").read_text().splitlines()]
            names = [e["event"] for e in events]
            self.assertLess(names.index("candidate_frozen"), names.index("future_labels_released"))
            self.assertTrue(set(result["train_ids"]).isdisjoint(result["gate_ids"]))
            self.assertTrue(set(result["screen_ids"]).isdisjoint(result["gate_ids"]))
            np.testing.assert_array_equal(parents[0][1], dataset()["train_x"])

    def test_rejected_candidate_cannot_be_selected_and_next_round_resumes_incumbent(self):
        m = self.module()
        parents = []
        def train(parent, *args, **kwargs):
            parents.append(parent.checkpoint_sha256)
            return Model(0., "bad", 11), .01
        with tempfile.TemporaryDirectory() as tmp:
            run = m.TenRoundRun(Path(tmp)/"run", dataset(), Model(), trainer=train)
            run.experiment(m.candidate_source(4, "full"), "Try epochs.")
            with self.assertRaises(ValueError):
                run.select("candidate", "Ignore gate.")
            run.select("incumbent", "Candidate failed screening.")
            run.experiment(m.candidate_source(3, "full"), "Reduce epochs further.")
            self.assertEqual(parents, ["official", "official"])
            self.assertEqual(run.completed_rounds, 1)

    def test_exact_ten_real_fits_and_decisions_complete_the_run(self):
        m = self.module()
        fits = []
        def train(parent, *args, **kwargs):
            fits.append(kwargs)
            return Model(0., f"candidate-{len(fits)}", 11), .01
        configs = [(4,"full"),(3,"full"),(2,"full"),(1,"full"),(1,"head_only"),
                   (2,"head_only"),(3,"head_only"),(4,"head_only"),(5,"head_only"),(5,"full")]
        with tempfile.TemporaryDirectory() as tmp:
            run = m.TenRoundRun(Path(tmp)/"run", dataset(), Model(), trainer=train)
            for epochs, policy in configs:
                run.experiment(m.candidate_source(epochs, policy), "Single factor candidate.")
                run.select("incumbent", "Candidate did not improve.")
            report = run.finish()
            self.assertEqual(len(fits), 10)
            self.assertEqual(report["completed_rounds"], 10)
            self.assertTrue(report["ten_rounds_complete"])
            self.assertEqual(report["initial_checkpoint"], report["selected_checkpoint"])
            self.assertFalse(report["hidden_test_evaluated"])
            for comparison in report["final_development_metrics"].values():
                self.assertIn("delta_selected_minus_static",comparison)
            with self.assertRaises(ValueError):
                run.experiment(m.candidate_source(4, "full"), "Eleventh trial.")

    def test_early_finish_and_training_resource_failure_are_not_ten_rounds(self):
        m = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            run = m.TenRoundRun(Path(tmp)/"run", dataset(), Model(), trainer=lambda *a, **k: (Model(), 6.))
            self.assertFalse(run.finish()["ten_rounds_complete"])
            with self.assertRaises(RuntimeError):
                run.experiment(m.candidate_source(4, "full"), "Trial exceeds five seconds.")
            self.assertEqual(run.completed_rounds, 0)


if __name__ == "__main__":
    unittest.main()
