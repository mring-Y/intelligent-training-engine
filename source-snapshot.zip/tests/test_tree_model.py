"""Numeric CART inference and hostile-checkpoint boundary contracts."""

import copy
import io
import json
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
import warnings
import zipfile

import numpy as np

try:
    from ite.tree_model import TreeModel, preflight_npz
except ImportError:
    TreeModel = preflight_npz = None


def stump_state(task="regression"):
    """A hand-authored split at 1.5; no estimator computes expectations."""
    return {"model_kind": "tree", "format_version": 1, "task": task, "family": "tree",
            "max_depth": 2, "min_samples_leaf": 1, "max_leaf_nodes": 4,
            "random_state": 7, "allow_missing_classes": False,
            "class_labels": [] if task == "regression" else [1, 2, 3, 4, 5, 6],
            "mean": [1.5, 9.0], "std": [1.0, 1.0],
            "children_left": [1, -1, -1], "children_right": [2, -1, -1],
            "feature": [0, -2, -2], "threshold": [1.5, -2., -2.],
            "value": [[4.], [2.], [6.]] if task == "regression" else
                     [[1/6] * 6, [0., .75, .25, 0., 0., 0.], [0., 0., 0., 0., 0., 1.]]}


def npy_bytes(value):
    stream = io.BytesIO()
    np.save(stream, value, allow_pickle=False)
    return stream.getvalue()


def header_only(shape, descr="<f8", *, fortran=False, payload=b""):
    header = repr({"descr": descr, "fortran_order": fortran, "shape": shape})
    encoded = header.encode("latin1")
    encoded += b" " * ((-10 - len(encoded) - 1) % 64) + b"\n"
    return b"\x93NUMPY\x01\x00" + struct.pack("<H", len(encoded)) + encoded + payload


class TreeModelTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(TreeModel, "The approved numeric TreeModel interface is missing")

    def test_hand_regression_uses_raw_features_and_left_inclusive_threshold(self):
        model = TreeModel.from_state(stump_state())
        np.testing.assert_array_equal(model.predict([[0., 99.], [1.5, 99.], [2., -3.]]), [2., 2., 6.])
        self.assertEqual(model.predict(np.empty((0, 2))).shape, (0,))
        with self.assertRaises(ValueError):
            model.predict_proba([[0., 0.]])

    def test_hand_classifier_maps_columns_to_explicit_class_ids(self):
        model = TreeModel.from_state(stump_state("classification"))
        np.testing.assert_array_equal(model.classes_, [1, 2, 3, 4, 5, 6])
        np.testing.assert_array_equal(model.predict([[1., 1.], [2., 1.]]), [2, 6])
        np.testing.assert_array_equal(model.predict_proba([[1., 1.], [2., 1.]]),
                                      [[0., .75, .25, 0., 0., 0.], [0., 0., 0., 0., 0., 1.]])

    def test_float32_rounding_matches_sklearn_threshold_semantics(self):
        state = stump_state()
        state["threshold"][0] = 1.0
        model = TreeModel.from_state(state)
        # These two distinct float64 inputs straddle 1 but round to the same float32.
        np.testing.assert_array_equal(model.predict([[1.0, 0.], [1.0 + 2**-25, 0.],
                                                     [1.0 + 2**-22, 0.]]), [2., 2., 6.])

    def test_prediction_rejects_shape_nonfinite_and_float32_overflow(self):
        model = TreeModel.from_state(stump_state())
        for features in ([[1.]], [1., 2.], [[np.nan, 0.]], [[np.inf, 0.]], [[1e39, 0.]],
                         [["1", "2"]], [[1+1j, 0.]]):
            with self.subTest(features=features), self.assertRaises(ValueError):
                model.predict(features)

    def test_unfitted_model_reports_a_value_error(self):
        model = TreeModel()
        for operation in (lambda: model.predict([[1.]]), model.state):
            with self.assertRaises(ValueError):
                operation()

    def test_native_regression_and_weighted_statistics_match(self):
        from sklearn.tree import DecisionTreeRegressor
        rng = np.random.default_rng(41)
        x = rng.normal(size=(90, 4))
        x[:, 3] = 7.
        y = np.where(x[:, 0] < .2, x[:, 1] ** 2, 4. + x[:, 2])
        weights = np.arange(1., 91.)
        model = TreeModel(max_depth=3, min_samples_leaf=2, max_leaf_nodes=7).fit(x, y, weights)
        native = DecisionTreeRegressor(max_depth=3, min_samples_leaf=2, max_leaf_nodes=7,
                                       random_state=7).fit(x, y, sample_weight=weights / weights.max() *
                                                          (len(weights) / (weights / weights.max()).sum()))
        probes = np.vstack((x, rng.normal(size=(80, 4))))
        np.testing.assert_array_equal(model.predict(probes), native.predict(probes))
        np.testing.assert_allclose(model.mean, np.average(x, axis=0, weights=weights), rtol=1e-14)
        self.assertEqual(model.std[3], 1.)
        before = model.mean.copy()
        model.predict(probes + 1e4)
        np.testing.assert_array_equal(model.mean, before)

    def test_fitted_leaf_values_have_independent_hand_computed_expectations(self):
        x = np.repeat([[0.], [1.]], 5, axis=0)
        y = np.array([0., 2., 4., 6., 8., 10., 12., 14., 16., 18.])
        model = TreeModel().fit(x, y)
        np.testing.assert_array_equal(model.predict([[-10.], [10.]]), [4., 14.])
        np.testing.assert_array_equal(model.mean, [.5])
        np.testing.assert_array_equal(model.std, [.5])
        weighted = TreeModel(min_samples_leaf=1).fit([[1.], [1.]], [0., 10.], [1., 3.])
        np.testing.assert_array_equal(weighted.predict([[1.], [2.]]), [7.5, 7.5])

    def test_native_multiclass_predictions_probabilities_and_threshold_edges_match(self):
        from sklearn.tree import DecisionTreeClassifier
        rng = np.random.default_rng(93)
        x = rng.normal(size=(240, 3))
        y = np.tile(np.arange(1, 7), 40)
        weights = rng.uniform(.2, 2., len(y))
        normalized = weights / weights.max() * (len(weights) / (weights / weights.max()).sum())
        model = TreeModel("classification", max_depth=4, min_samples_leaf=2, max_leaf_nodes=12,
                          class_labels=(1, 2, 3, 4, 5, 6)).fit(x, y, weights)
        native = DecisionTreeClassifier(max_depth=4, min_samples_leaf=2, max_leaf_nodes=12,
                                        random_state=7).fit(x, y, sample_weight=normalized)
        probes = list(x)
        for feature, threshold in zip(native.tree_.feature, native.tree_.threshold):
            if feature >= 0:
                for value in (threshold, np.nextafter(threshold, -np.inf),
                              np.nextafter(threshold, np.inf), float(np.float32(threshold))):
                    probe = np.zeros(3)
                    probe[feature] = value
                    probes.append(probe)
        probes = np.asarray(probes)
        np.testing.assert_array_equal(model.predict(probes), native.predict(probes))
        np.testing.assert_array_equal(model.predict_proba(probes), native.predict_proba(probes))

    def test_initial_training_requires_all_classes_candidates_keep_zero_columns(self):
        x = np.arange(20.).reshape(10, 2)
        y = np.array([1, 1, 2, 2, 3, 3, 4, 4, 5, 5])
        with self.assertRaises(ValueError):
            TreeModel("classification", class_labels=(1, 2, 3, 4, 5, 6)).fit(x, y)
        candidate = TreeModel("classification", min_samples_leaf=1, class_labels=(1, 2, 3, 4, 5, 6),
                              allow_missing_classes=True).fit(x, y)
        self.assertEqual(candidate.predict_proba(x).shape, (10, 6))
        np.testing.assert_array_equal(candidate.predict_proba(x)[:, 5], np.zeros(10))
        self.assertFalse(np.any(candidate.predict(x) == 6))
        single = TreeModel("classification", class_labels=(1, 2, 3, 4, 5, 6),
                           allow_missing_classes=True).fit(x, np.full(10, 4))
        np.testing.assert_array_equal(single.predict(x), np.full(10, 4))
        np.testing.assert_array_equal(single.predict_proba(x), np.tile([0, 0, 0, 1, 0, 0], (10, 1)))

    def test_binary_classes_default_to_zero_one_and_unknown_targets_fail(self):
        x = np.arange(12.).reshape(6, 2)
        model = TreeModel("classification", min_samples_leaf=1).fit(x, [0, 0, 0, 1, 1, 1])
        np.testing.assert_array_equal(model.predict(x), [0, 0, 0, 1, 1, 1])
        np.testing.assert_array_equal(model.classes_, [0, 1])
        with self.assertRaises(ValueError):
            TreeModel("classification").fit(x, [0, 0, 1, 1, 1, 2])

    def test_bad_training_data_and_weights_fail_before_native_fitting(self):
        bad = [([[0.], [1e39]], [0., 1.], None), ([[0.], [1.]], [0., np.nan], None),
               ([[0.], [1.]], [0., 1.], [0., 0.]), ([[0.], [1.]], [0., 1.], [-1., 2.]),
               ([[0.], [1.]], [0., 1.], [np.inf, 2.]), ([[0.], [1.]], [0., 1.], [1.]),
               ([[0.]], [0.], None), (np.zeros((2, 2049)), [0., 1.], None)]
        for features, targets, weights in bad:
            with self.subTest(shape=np.shape(features)), self.assertRaises(ValueError):
                TreeModel().fit(features, targets, weights)

    def test_parameters_are_strict_and_bounded(self):
        cases = [{"task": "other"}, {"max_depth": 0}, {"max_depth": 17}, {"max_depth": True},
                 {"max_depth": 2.5}, {"min_samples_leaf": 0}, {"max_leaf_nodes": 1},
                 {"max_leaf_nodes": 4097}, {"random_state": -1}, {"allow_missing_classes": 1},
                 {"task": "regression", "class_labels": (0, 1)},
                 {"task": "classification", "class_labels": (0, 2)},
                 {"task": "classification", "class_labels": (1., 2., 3., 4., 5., 6.)}]
        for kwargs in cases:
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                TreeModel(**kwargs)

    def test_state_is_detached_and_round_trips_exact_predictions(self):
        model = TreeModel.from_state(stump_state())
        state = model.state()
        state["value"][1][0] = 999.
        np.testing.assert_array_equal(model.predict([[1., 0.]]), [2.])
        restored = TreeModel.from_state(model.state())
        np.testing.assert_array_equal(restored.predict([[1., 0.], [2., 0.]]), [2., 6.])
        model.mean[:] = 999.
        np.testing.assert_array_equal(model.mean, [1.5, 9.])

    def test_state_rejects_wrong_identity_fields_and_array_types(self):
        changes = [("model_kind", "ridge"), ("format_version", 2), ("format_version", True),
                   ("family", "ridge"), ("task", "bogus"), ("mean", []), ("mean", [np.nan, 0.]),
                   ("std", [1., 0.]), ("std", [1., np.inf]), ("children_left", [1., -1., -1.]),
                   ("value", [[1.], [np.nan], [2.]]), ("threshold", [np.inf, -2., -2.]),
                   ("value", [[1., 2.]] * 3), ("mean", ["1", "2"])]
        for field, value in changes:
            state = stump_state()
            state[field] = value
            with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                TreeModel.from_state(state)
        for remove in (True, False):
            state = stump_state()
            if remove:
                del state["threshold"]
            else:
                state["injected"] = 1
            with self.assertRaises(ValueError):
                TreeModel.from_state(state)

    def test_state_rejects_cycles_multiple_parents_unreachable_and_one_sided_nodes(self):
        changes = [("children_left", [0, -1, -1]), ("children_left", [3, -1, -1]),
                   ("children_right", [1, -1, -1]), ("children_right", [-1, -1, -1]),
                   ("feature", [2, -2, -2]), ("feature", [0, 0, -2]),
                   ("threshold", [1.5, 0., -2.]), ("children_left", [1, 0, -1])]
        for field, value in changes:
            state = stump_state()
            state[field] = value
            with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                TreeModel.from_state(state)
        state = stump_state()
        for name in ("children_left", "children_right", "feature", "threshold", "value"):
            state[name].append(copy.deepcopy(state[name][-1]))
        with self.assertRaises(ValueError):
            TreeModel.from_state(state)
        # All nonroot nodes have one parent, but a disconnected component cycles.
        state = stump_state()
        state.update(children_left=[-1, 2, 1, -1, -1], children_right=[-1, 3, 4, -1, -1],
                     feature=[-2, 0, 0, -2, -2], threshold=[-2., 1., 2., -2., -2.],
                     value=[[0.]] * 5)
        with self.assertRaises(ValueError):
            TreeModel.from_state(state)

    def test_state_rejects_depth_leaf_feature_and_node_resource_excess(self):
        state = stump_state()
        state.update(children_left=[1, 3, -1, -1, -1], children_right=[2, 4, -1, -1, -1],
                     feature=[0, 0, -2, -2, -2], threshold=[1.5, .5, -2., -2., -2.],
                     value=[[4.], [2.], [6.], [1.], [3.]])
        for changed in ({"max_depth": 1}, {"max_leaf_nodes": 2}):
            with self.subTest(changed=changed), self.assertRaises(ValueError):
                TreeModel.from_state({**state, **changed})
        for changed in ({"mean": [0.] * 2049, "std": [1.] * 2049},
                        {"children_left": [-1] * 8192}, {"value": [[0.] * 100000] * 3}):
            with self.assertRaises(ValueError):
                TreeModel.from_state({**stump_state(), **changed})

    def test_classifier_state_rejects_invalid_probabilities_or_class_mapping(self):
        for values in ([[1.] * 6] * 3, [[-.1, .3, .2, .2, .2, .2]] * 3,
                       [[np.nan] * 6] * 3, [[0.] * 6] * 3):
            state = stump_state("classification")
            state["value"] = values
            with self.assertRaises(ValueError):
                TreeModel.from_state(state)
        state = stump_state("classification")
        state["class_labels"] = [6, 5, 4, 3, 2, 1]
        with self.assertRaises(ValueError):
            TreeModel.from_state(state)
        state = stump_state("classification")
        state["allow_missing_classes"] = True
        state["value"][0] = [.2, .2, .2, .2, .2, 0.]
        # A globally absent class cannot reappear in one leaf.
        with self.assertRaises(ValueError):
            TreeModel.from_state(state)

    def test_numeric_checkpoint_roundtrip_and_load_without_training_dependencies(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "tree.npz"
            TreeModel.from_state(stump_state("classification")).save(path)
            fields = preflight_npz(path)
            self.assertIn("tree_format", fields)
            self.assertIn("tree_kind", fields)
            with np.load(path, allow_pickle=False) as archive:
                self.assertTrue(all(archive[name].dtype.kind in "iuf" for name in archive.files))
            script = """
import importlib.abc, json, sys
class BlockTraining(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] in {'sklearn', 'scipy', 'joblib', 'threadpoolctl'}:
            raise AssertionError('Training dependency imported during inference: ' + fullname)
sys.meta_path.insert(0, BlockTraining())
from ite.tree_model import TreeModel
model = TreeModel.load(sys.argv[1])
print(json.dumps({'prediction': model.predict([[1., 0.], [2., 0.]]).tolist(),
                  'probability': model.predict_proba([[1., 0.]]).tolist()}))
"""
            result = subprocess.run([sys.executable, "-c", script, str(path)], text=True,
                                    capture_output=True, check=False, timeout=20)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stdout), {"prediction": [2, 6],
                              "probability": [[0., .75, .25, 0., 0., 0.]]})

    def test_preflight_and_load_share_an_open_binary_stream_without_reopening(self):
        """The caller can validate and load one immutable file descriptor."""
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "tree.npz"
            TreeModel.from_state(stump_state("classification")).save(path)
            with path.open("rb") as stream:
                fields = preflight_npz(stream)
                self.assertEqual(stream.tell(), 0)
                restored = TreeModel.load(stream)
                self.assertFalse(stream.closed)
                self.assertEqual(fields, {
                    "tree_format", "tree_kind", "task_id", "allow_missing_classes",
                    "class_labels", "max_depth", "min_samples_leaf", "max_leaf_nodes",
                    "random_state", "mean", "std", "children_left", "children_right",
                    "feature", "threshold", "value"})
                np.testing.assert_array_equal(restored.predict([[1., 0.], [2., 0.]]), [2, 6])

    def test_atomic_replace_failure_preserves_original_and_cleans_temporary_file(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "tree.npz"
            model = TreeModel.from_state(stump_state())
            model.save(path)
            original = path.read_bytes()
            with mock.patch("ite.tree_model.os.replace", side_effect=OSError("injected disk failure")):
                with self.assertRaises(OSError):
                    model.save(path)
            self.assertEqual(path.read_bytes(), original)
            self.assertEqual(list(Path(directory).iterdir()), [path])

    def test_save_fsync_failure_preserves_original_and_cleans_temporary_file(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "tree.npz"
            model = TreeModel.from_state(stump_state())
            model.save(path)
            original = path.read_bytes()
            with mock.patch("ite.tree_model.os.fsync", side_effect=OSError("injected sync failure")):
                with self.assertRaises(OSError):
                    model.save(path)
            self.assertEqual(path.read_bytes(), original)
            self.assertEqual(list(Path(directory).iterdir()), [path])


class TreeArchiveTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(preflight_npz, "The bounded archive preflight is missing")
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.path = Path(self.temporary.name) / "candidate.npz"

    def write_members(self, members, compression=zipfile.ZIP_DEFLATED):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            with zipfile.ZipFile(self.path, "w", compression=compression) as archive:
                for name, payload in members:
                    archive.writestr(name, payload)

    def assert_rejected_before_np_load(self):
        with mock.patch("ite.tree_model.np.load", side_effect=AssertionError("unbounded load called")):
            with self.assertRaises(ValueError):
                TreeModel.load(self.path)

    def test_generic_preflight_allows_only_explicitly_enabled_bounded_legacy_text(self):
        np.savez_compressed(self.path, task="classification", weights=np.zeros(9))
        with self.assertRaises(ValueError):
            preflight_npz(self.path)
        self.assertEqual(preflight_npz(self.path, allow_text=True), {"task", "weights"})
        with self.assertRaises(ValueError):
            preflight_npz(self.path, allowed_fields={"weights"}, allow_text=True)

    def test_stream_preflight_resets_after_rejecting_malformed_archive(self):
        stream = io.BytesIO(b"not a zip")
        with self.assertRaises(ValueError):
            preflight_npz(stream)
        self.assertEqual(stream.tell(), 0)

    def test_extra_missing_or_unknown_version_tree_fields_are_rejected(self):
        TreeModel.from_state(stump_state()).save(self.path)
        with np.load(self.path, allow_pickle=False) as archive:
            values = {name: archive[name] for name in archive.files}
        for mode in ("extra", "missing", "version", "kind", "scalar_shape", "float_marker"):
            changed = values.copy()
            if mode == "extra":
                changed["extra"] = np.zeros(1)
            elif mode == "missing":
                del changed["std"]
            elif mode == "version":
                changed["tree_format"] = np.asarray(999)
            elif mode == "kind":
                changed["tree_kind"] = np.asarray(99)
            elif mode == "scalar_shape":
                changed["tree_kind"] = np.asarray([1])
            else:
                changed["tree_kind"] = np.asarray(1.)
            np.savez_compressed(self.path, **changed)
            with self.subTest(mode=mode), self.assertRaises(ValueError):
                TreeModel.load(self.path)

    def test_duplicate_path_object_complex_and_unsupported_compression_rejected(self):
        bad_members = [[("x.npy", npy_bytes(np.zeros(1)))] * 2,
                       [("../x.npy", npy_bytes(np.zeros(1)))],
                       [("x.txt", b"anything")], [("x.npy", npy_bytes(np.array([1+2j])))]]
        for members in bad_members:
            self.write_members(members)
            self.assert_rejected_before_np_load()
        stream = io.BytesIO()
        np.save(stream, np.array([{"payload": 1}], dtype=object), allow_pickle=True)
        self.write_members([("x.npy", stream.getvalue())])
        self.assert_rejected_before_np_load()
        self.write_members([("x.npy", npy_bytes(np.zeros(1)))], compression=zipfile.ZIP_BZIP2)
        self.assert_rejected_before_np_load()

    def test_tiny_archive_with_huge_header_shape_is_rejected_before_load(self):
        self.write_members([("value.npy", header_only((2**50, 6)))])
        self.assert_rejected_before_np_load()

    def test_payload_length_and_fortran_header_mismatch_are_rejected_before_load(self):
        for payload in (header_only((2,), payload=b"\x00" * 8),
                        header_only((1,), payload=b"\x00" * 16),
                        header_only((1,), fortran=True, payload=b"\x00" * 8),
                        header_only((-1,), payload=b""), header_only((True,), payload=b"\x00" * 8)):
            self.write_members([("value.npy", payload)])
            self.assert_rejected_before_np_load()

    def test_member_count_compressed_and_uncompressed_file_limits_precede_load(self):
        self.write_members([(f"x{index}.npy", npy_bytes(np.zeros(1))) for index in range(65)])
        self.assert_rejected_before_np_load()
        # A highly compressible ZIP payload stays tiny while exceeding the decompression quota.
        self.write_members([("value.npy", npy_bytes(np.zeros(3_000_000)))])
        self.assert_rejected_before_np_load()
        with self.path.open("wb") as stream:
            stream.truncate(16 * 1024 * 1024 + 1)
        self.assert_rejected_before_np_load()

    def test_oversized_or_malformed_npy_headers_and_invalid_zip_rejected(self):
        oversized = b"\x93NUMPY\x02\x00" + struct.pack("<I", 100000) + b" " * 100000
        for payload in (oversized, b"not an array", header_only((1,), descr="|V8", payload=b"0" * 8),
                        b"\x93NUMPY\x09\x00" + b"\x00" * 20):
            self.write_members([("value.npy", payload)])
            self.assert_rejected_before_np_load()
        self.path.write_bytes(b"not a zip")
        self.assert_rejected_before_np_load()

    def test_corrupt_deflate_stream_is_a_clean_validation_failure(self):
        self.write_members([("value.npy", npy_bytes(np.arange(100.)))])
        with zipfile.ZipFile(self.path) as archive:
            member = archive.infolist()[0]
        content = bytearray(self.path.read_bytes())
        # Offset 26 in a local ZIP header stores filename/extra-field lengths.
        filename_size, extra_size = struct.unpack_from("<HH", content, member.header_offset + 26)
        offset = member.header_offset + 30 + filename_size + extra_size
        content[offset] = 0xff  # Invalid DEFLATE block type.
        self.path.write_bytes(content)
        with self.assertRaises(ValueError):
            preflight_npz(self.path)
        self.assert_rejected_before_np_load()


if __name__ == "__main__":
    unittest.main()
