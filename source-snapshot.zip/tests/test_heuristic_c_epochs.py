"""Approved C epoch tuning must preserve safe selection and real CPU routing."""

import json
import os
from pathlib import Path
import tempfile
import unittest

import numpy as np

from ite.config import ExperimentConfig


def c_options():
    return dict(task="regression", n_features=24, model_type="official_mlp", official_profile="C",
        harness_enabled=True, heuristic_override=True, deployment_validation="future",
        training_preflight=True, candidate_feasibility=True, max_tokens=60000,
        history_windows=[192, 768], min_validation=48)


class EpochContractTests(unittest.TestCase):
    def test_c_approved_epochs_round_trip_without_relaxing_a_or_other_limits(self):
        for epoch in (1, 2, 3, 5):
            try:
                cfg = ExperimentConfig.from_dict({**c_options(), "official_candidate_epochs": epoch})
            except ValueError as error:
                self.fail(f"Approved C epoch {epoch} was rejected: {error}")
            self.assertEqual(ExperimentConfig.from_dict(cfg.to_dict()).official_options()["candidate_epochs"], epoch)
        for epoch in (0, 4, 6, True, 1.5):
            with self.subTest(epoch=epoch), self.assertRaises(ValueError):
                ExperimentConfig.from_dict({**c_options(), "official_candidate_epochs": epoch})
        for epoch in (1, 2, 3):
            with self.subTest(a_epoch=epoch), self.assertRaises(ValueError):
                ExperimentConfig.from_dict({**c_options(), "task":"classification", "n_features":128,
                    "official_profile":"A", "official_candidate_epochs":epoch})

    def test_combined_candidate_only_enables_c_while_old_experiment_still_enables_a(self):
        from scripts.run_heuristic_comparison import effective_policy
        self.assertEqual(effective_policy("A", "heuristic", None), (True, 5))
        for epoch in (1, 2, 3, 5):
            self.assertEqual(effective_policy("A", "heuristic", epoch), (False, 5))
            self.assertEqual(effective_policy("B", "heuristic", epoch), (False, 5))
            self.assertEqual(effective_policy("C", "heuristic", epoch), (True, epoch))
            self.assertEqual(effective_policy("C", "static", epoch), (False, epoch))
        with self.assertRaises(ValueError):
            effective_policy("C", "heuristic", 4)

    def test_static_a_in_final_combination_accepts_equality_but_rejects_regression(self):
        from scripts.run_heuristic_comparison import assess_metrics
        baseline = {"macro_f1":.5, "accuracy":.7}
        self.assertFalse(assess_metrics("A",baseline,baseline,"abrupt")["passed"])
        self.assertTrue(assess_metrics("A",baseline,baseline,"abrupt",allow_equal=True)["passed"])
        self.assertFalse(assess_metrics("A",baseline,{**baseline,"macro_f1":.499},
                                       "abrupt",allow_equal=True)["passed"])


class EpochAssessmentTests(unittest.TestCase):
    def fixture(self):
        before = {"rmse":100., "mae":80., "overestimate_rate":.16, "mean_overestimate":5.}
        scores = {"static":before, "no_control":before,
            "epoch1":{**before, "rmse":96.}, "epoch2":{**before, "rmse":96.},
            "epoch3":{**before, "rmse":95., "mean_overestimate":6.01},
            "epoch5":{**before, "rmse":90., "overestimate_rate":.181}}
        groups = {f"{s}-merged":{"metrics":{k:dict(v) for k,v in scores.items()}}
                  for s in ("stable", "abrupt", "gradual")}
        return groups, scores

    def test_selection_excludes_unsafe_lower_rmse_and_resolves_ties_to_lower_epoch(self):
        from scripts.run_heuristic_c_epochs import select_epoch
        groups, scores = self.fixture()
        result = select_epoch(groups, scores)
        self.assertEqual(result["selected_epoch"], 1)
        self.assertFalse(result["candidates"]["epoch3"]["passed"])
        self.assertFalse(result["candidates"]["epoch5"]["passed"])
        groups["stable-merged"]["metrics"]["epoch1"]["rmse"] = 100.01
        self.assertEqual(select_epoch(groups, scores)["selected_epoch"], 2)

    def test_flat_results_or_any_training_error_cannot_be_called_an_optimization(self):
        from scripts.run_heuristic_c_epochs import select_epoch
        groups, scores = self.fixture()
        self.assertIsNone(select_epoch(groups, scores, engineering_passed=False)["selected_epoch"])
        for epoch in (1, 2):
            scores[f"epoch{epoch}"]["rmse"] = 100.
        self.assertIsNone(select_epoch(groups, scores)["selected_epoch"])

    def test_pairing_scores_original_rows_and_rejects_changed_ids(self):
        from scripts.run_heuristic_c_epochs import summarize_predictions
        arrays = {}
        for scenario in ("stable", "abrupt", "gradual"):
            for split, prediction in (("train", 1.), ("eval", 3.)):
                for arm in ("static", "no_control", "epoch1", "epoch2", "epoch3", "epoch5"):
                    arrays[scenario, split, arm] = dict(targets=np.zeros(1), active=np.array([prediction]),
                        static=np.array([prediction]), source_ids=np.array([f"{split}-row"]))
        groups, composite = summarize_predictions(arrays)
        self.assertAlmostEqual(composite["static"]["rmse"], np.sqrt(5.))
        self.assertAlmostEqual(groups["abrupt-merged"]["metrics"]["static"]["rmse"], np.sqrt(5.))
        arrays["abrupt", "eval", "epoch1"]["source_ids"] = np.array(["different-row"])
        with self.assertRaises(ValueError):
            summarize_predictions(arrays)


RUNTIME = Path(os.environ.get("ITE_OFFICIAL_RUNTIME_PYTHON",
    Path(__file__).resolve().parents[1]/".venv-official-a/Scripts/python.exe"))


@unittest.skipUnless(RUNTIME.is_file(), "official isolated CPU runtime missing")
class EpochCpuIntegrationTests(unittest.TestCase):
    def test_controller_no_override_runs_one_epoch_and_requires_independent_future(self):
        from ite.controller import AdaptationController
        from ite.data import ReleasedLabels
        from ite.harness import LLMReply
        from ite.heuristic_override import load_training_stream
        from ite.official_model import OfficialModelAdapter
        from ite.tracking import JsonlLogger
        from ite.training import BoundedTrainer
        try:
            cfg = ExperimentConfig.from_dict({**c_options(), "official_runtime_python":str(RUNTIME),
                                             "official_candidate_epochs":1})
        except ValueError as error:
            self.fail(f"Approved one-epoch C route is unavailable: {error}")
        parent = OfficialModelAdapter("regression", RUNTIME, profile_type="C", candidate_epochs=1)
        x = load_training_stream("C")["x"][:900]
        y = parent.predict(x) + 20.
        class NoClient:
            def get_decision(self, observation):
                return LLMReply('{"action":"DO_NOTHING","reason":"Retain"}', 8)
        with tempfile.TemporaryDirectory() as tmp, BoundedTrainer() as trainer:
            path = Path(tmp)
            with JsonlLogger(path/"events.jsonl", "c-one-epoch") as log:
                controller = AdaptationController(cfg, "drift", parent, .01, 1., log, trainer, path)
                controller.history_x=x.copy(); controller.history_y=y.copy()
                controller.history_steps=np.repeat(np.arange(9),100)
                controller.llm_client=NoClient()
                controller._record_harness_losses(np.repeat([.1,.25,.23],48),np.repeat([6,7,8],48))
                controller._harness_decide(10,{"performance_drop":True,"diagnosis":"test"})
                self.assertEqual(controller.budget.training_attempts,1)
                self.assertIsNotNone(controller.pending)
                self.assertEqual(controller.gate.version,0)
                same=ReleasedLabels(np.arange(1000,1060),x[:60],y[:60],np.full(60,10))
                controller._validate_pending(same,11)
                self.assertEqual(controller.gate.version,0)
                fresh=ReleasedLabels(np.arange(1100,1160),x[60:120],y[60:120],np.full(60,11))
                controller._validate_pending(fresh,12)
                self.assertEqual(controller.gate.version,1)
            events=[json.loads(line) for line in (path/"events.jsonl").read_text().splitlines()]
            fit=next(e for e in events if e["event"]=="candidate_evaluated")
            self.assertEqual(fit["train_samples"],720)
            self.assertEqual(fit["fit_audit"]["epochs_added"],1)
            self.assertEqual(fit["fit_audit"]["trainable_parameters"],33)
            self.assertEqual(controller.gate.model.steps-parent.steps,3)
            self.assertEqual(fit["fit_audit"]["max_parameter_delta"]["w1"],0.)
            deploy=next(e for e in events if e["event"]=="deploy")
            self.assertGreater(deploy["gate_min_source_step"],deploy["frozen_at"])


if __name__ == "__main__":
    unittest.main()
