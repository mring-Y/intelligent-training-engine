import json
import tempfile
import unittest
from pathlib import Path

import numpy as np

from ite.config import ExperimentConfig
from ite.controller import AdaptationController
from ite.data import PublicBatch, ReleasedLabels
from ite.models import RidgeModel
from ite.monitor import DriftMonitor
from ite.runner import run_comparison
from ite.tracking import JsonlLogger
from ite.training import BoundedTrainer


class ProspectiveTests(unittest.TestCase):
    def config(self, **overrides):
        try:
            return ExperimentConfig.from_dict({"deployment_validation": "future", **overrides})
        except ValueError as error:
            self.fail(f"Independent future-label validation must be configurable: {error}")

    def test_monitor_threshold_can_be_smaller_than_training_threshold(self):
        config = self.config(monitor_min_labeled=32, min_labeled=96)
        monitor = DriftMonitor(config, np.zeros(3), np.ones(3), 0.05)
        monitor.observe_losses(np.ones(31))
        self.assertFalse(monitor.evidence(0)["performance_drop"])
        monitor.observe_losses([1])
        self.assertTrue(monitor.evidence(0)["performance_drop"])
        self.assertEqual(config.min_labeled, 96)

    def test_earlier_monitor_threshold_records_detection_before_training_is_eligible(self):
        first, last = [], []
        for threshold, found in ((32, first), (96, last)):
            config = self.config(n_batches=8, drift_start=0, monitor_min_labeled=threshold,
                                 label_delay=0, max_train_seconds=0)
            with tempfile.TemporaryDirectory() as directory:
                run_comparison(config, Path(directory), policies=("drift",))
                events = [json.loads(line) for line in (Path(directory) / "drift/events.jsonl").read_text().splitlines()]
                found.extend(event["step"] for event in events if event["event"] == "drift_detected")
        self.assertEqual(first, [1])
        self.assertEqual(last, [3])

    def test_search_freezes_candidate_and_ignores_late_labels_from_before_freeze(self):
        config = self.config(n_batches=14, drift_start=0, update_interval=3, cooldown=0)
        with tempfile.TemporaryDirectory() as directory, BoundedTrainer() as trainer:
            results = run_comparison(config, Path(directory), policies=("periodic",), trainer=trainer)
            events = [json.loads(line) for line in (Path(directory) / "periodic/events.jsonl").read_text().splitlines()]
            frozen = [e for e in events if e["event"] == "candidate_frozen"]
            deployed = [e for e in events if e["event"] == "deploy"]
            self.assertTrue(frozen)
            self.assertTrue(deployed)
            for event in deployed:
                self.assertGreater(event["gate_min_source_step"], event["frozen_at"])
                self.assertGreaterEqual(event["step"], event["gate_max_source_step"] + config.label_delay)
                self.assertGreaterEqual(event["gate_samples"], config.min_validation)
            for candidate in frozen:
                end = next((e["step"] for e in events if e["event"] in ("deploy", "experiment_rejected")
                            and e.get("candidate_id") == candidate["candidate_id"]), config.n_batches)
                overlapping = [e for e in events if e["event"] == "experiment_started"
                               and candidate["step"] < e["step"] < end]
                self.assertEqual(overlapping, [])
            self.assertGreater(results[0]["updates"], 0)

    def test_pending_candidate_at_end_is_rejected_without_changing_predictions(self):
        config = self.config(n_batches=8, drift_start=0, update_interval=8, label_delay=0)
        with tempfile.TemporaryDirectory() as directory:
            rows = run_comparison(config, Path(directory), policies=("periodic", "static"))
            self.assertEqual(rows[0]["updates"], 0)
            with np.load(Path(directory) / "periodic/predictions.npz", allow_pickle=False) as adapted:
                with np.load(Path(directory) / "static/predictions.npz", allow_pickle=False) as static:
                    np.testing.assert_array_equal(adapted["predictions"], static["predictions"])
            events = [json.loads(line) for line in (Path(directory) / "periodic/events.jsonl").read_text().splitlines()]
            rejected = [e for e in events if e["event"] == "experiment_rejected"]
            self.assertTrue(any(e["reason"] == "stream_ended_before_independent_validation" for e in rejected))

    def test_archive_reuse_does_not_train_and_waits_for_independent_labels(self):
        rng = np.random.default_rng(12)
        train = rng.normal(size=(300, 3))
        target = (train[:, 0] > 0).astype(int)
        original = RidgeModel().fit(train, target)
        opposite = RidgeModel().fit(train, 1 - target)
        config = self.config(n_features=3, reuse_history=True, monitor_min_labeled=32,
                             max_train_seconds=0, cooldown=0, min_validation=32)
        with tempfile.TemporaryDirectory() as directory:
            with JsonlLogger(Path(directory) / "events.jsonl", "reuse") as logger:
                controller = AdaptationController(config, "drift", opposite, 0.01, 1,
                                                  logger, None, Path(directory))
                controller.gate.archive = [original, opposite]
                for step in range(3):
                    x = rng.normal(size=(48, 3))
                    y = (x[:, 0] > 0).astype(int)
                    ids = np.arange(step * 48, (step + 1) * 48)
                    predictions = dict(zip(map(int, ids), opposite.predict(x)))
                    controller.observe(PublicBatch(step, ids, x),
                                       ReleasedLabels(ids, x, y, np.full(48, step)), predictions)
                    if step == 0:
                        self.assertIs(controller.gate.model, opposite)
                self.assertGreater(controller.history_reuses, 0)
                self.assertEqual(controller.budget.train_seconds, 0)
                self.assertGreater(np.mean(controller.predict(train) == target), 0.95)

    def test_history_reuse_requires_future_validation_mode(self):
        with self.assertRaises(ValueError):
            ExperimentConfig.from_dict({"reuse_history": True, "deployment_validation": "legacy"})


if __name__ == "__main__":
    unittest.main()
