"""The official SFT runner freezes all source/scenario cases before inference."""

import importlib
import json
import hashlib
from datetime import datetime, timezone
from pathlib import Path
import tempfile
import unittest


class OfficialSFTRunnerTests(unittest.TestCase):
    def test_case_plan_has_nine_frozen_variants_and_an_upper_bound_of_27_requests(self):
        try:
            runner = importlib.import_module("scripts.build_official_sft")
        except ImportError as error:
            self.fail(f"Official SFT runner is missing: {error}")
        cases = runner.case_plan()
        self.assertEqual(len(cases), 18)
        self.assertEqual(len({(case["profile"], case["scenario"]) for case in cases}), 9)
        self.assertEqual({case["split"] for case in cases}, {"train", "eval"})
        self.assertEqual(sum(len(case["decision_steps"]) for case in cases), 27)
        self.assertTrue(all(case["decision_steps"] == ((3, 7) if case["split"] == "train" else (3,))
                            for case in cases))

    def test_payment_preflight_without_current_evidence_or_with_low_balance_is_rejected(self):
        try:
            runner = importlib.import_module("scripts.build_official_sft")
        except ImportError as error:
            self.fail(f"Official SFT runner is missing: {error}")
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/"payment.json"
            prices = Path(tmp)/"prices.json"
            prices.write_text(json.dumps({"currency": "CNY", "token_unit": "per_1m_tokens", "items": [
                {"alias": "qwen38-27b", "display_name": "Qwen/Qwen3.8-27B", "prices": {
                    "prefill": {"unit_price": 315}, "sample": {"unit_price": 2529}}}]}), encoding="utf-8")
            with self.assertRaises((ValueError, FileNotFoundError)):
                runner.verify_payment_preflight(path, prices)
            screenshot = Path(tmp)/"balance.png"
            screenshot.write_bytes(b"test balance receipt")
            valid = {"source": "user_provided_balance_screenshot", "cash_balance_cny": "49.99",
                "verified_at": datetime.now(timezone.utc).isoformat(), "screenshot_path": str(screenshot),
                "screenshot_sha256": hashlib.sha256(screenshot.read_bytes()).hexdigest()}
            path.write_text(json.dumps(valid), encoding="utf-8")
            self.assertEqual(runner.verify_payment_preflight(path, prices)["cash_balance_cny"], "49.99")
            for balance in ("0.49", "NaN", "Infinity"):
                path.write_text(json.dumps({**valid, "cash_balance_cny": balance}), encoding="utf-8")
                with self.subTest(balance=balance), self.assertRaises(ValueError):
                    runner.verify_payment_preflight(path, prices)

    def test_offline_probe_requests_real_resume_but_never_claims_teacher_labels(self):
        try:
            runner = importlib.import_module("scripts.build_official_sft")
        except ImportError as error:
            self.fail(f"Official SFT runner is missing: {error}")
        decision = runner.offline_decision({"step": 3, "observation": {"drift_alarm": False}})
        self.assertEqual(decision["action"], "RETRAIN_LARGE")
        self.assertEqual(decision["source"], "offline_mock")

    def test_paid_entry_rejects_incomplete_offline_receipt_before_creating_output(self):
        try:
            runner = importlib.import_module("scripts.build_official_sft")
        except ImportError as error:
            self.fail(f"Official SFT runner is missing: {error}")
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/"offline"
            path.mkdir()
            (path/"manifest.json").write_text(json.dumps({"mode": "offline_preflight", "physical_partitions": 18}), encoding="utf-8")
            with self.assertRaises(ValueError):
                runner.run_teacher(path, Path(tmp)/"teacher")
            self.assertFalse((Path(tmp)/"teacher").exists())

    def test_runner_changes_cannot_reuse_an_older_offline_receipt(self):
        runner = importlib.import_module("scripts.build_official_sft")
        from ite.tracking import source_metadata
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)
            manifest = {"mode": "offline_preflight", "engineering_preflight_passed": True,
                "source": source_metadata(), "runner_sha256": "0"*64,
                "cases": [{"case": c, "output": str(i), "evidence_files": {}}
                          for i,c in enumerate(runner.case_plan())]}
            (path/"manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "runner"):
                runner.verify_offline_preflight(path)

    def test_a_declared_pass_without_any_evidence_files_cannot_unlock_payment(self):
        runner = importlib.import_module("scripts.build_official_sft")
        from ite.tracking import source_metadata
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)
            manifest = {"mode": "offline_preflight", "engineering_preflight_passed": True,
                "source": source_metadata(), "runner_sha256": runner.digest(Path(runner.__file__)),
                "cases": [{"case": c, "output": str(i), "evidence_files": {}}
                          for i,c in enumerate(runner.case_plan())]}
            (path/"manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "evidence"):
                runner.verify_offline_preflight(path)


if __name__ == "__main__":
    unittest.main()
