"""FD001 intervention keeps delayed labels and scores saved cycle predictions."""

import importlib
import json
import math
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

from ite.config import ExperimentConfig
from scripts.data_prep.cmapss import FEATURES
from scripts.data_prep.common import export_dataset
from tests.tree_worker_test_timeout import tree_initial_timeout


class CmapssHarnessTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def module(self):
        try:
            return importlib.import_module("scripts.run_cmapss_harness")
        except ImportError as error:
            self.fail(f"FD001 paired intervention and saved-result assessment missing: {error}")

    def package(self, *, online=False):
        initial = [{**{f: float(i % 2) if f == FEATURES[0] else 0. for f in FEATURES},
                    "target": float(i % 2), "unit_id": 1, "cycle": i + 1}
                   for i in range(32)]
        if online:
            stream = []
            for step in range(9):
                unit = 81 if step < 4 else 82
                for i in range(32):
                    stream.append({**{f: float(i % 2) if f == FEATURES[0] else 0. for f in FEATURES},
                                   "target": 10. + i % 2, "unit_id": unit,
                                   "cycle": (step if unit == 81 else step - 4) * 32 + i + 1})
            batch_size, counts = 32, {"81": 128, "82": 160}
        else:
            # A hand-scored file fixture, rather than a physical lifetime claim.
            stream = [{**{f: 0. for f in FEATURES}, "target": y,
                       "unit_id": 81 if i < 4 else 82, "cycle": i + 1 if i < 4 else i - 3}
                      for i, y in enumerate((125., 100., 40., 30., 1., 0.))]
            batch_size, counts = 2, {"81": 4, "82": 2}
        output = self.root / "package"
        manifest = export_dataset(output, dataset="cmapss_fd001", task="regression", features=FEATURES,
            train_rows=initial, val_rows=[{**r, "unit_id": 2} for r in initial], stream_rows=stream,
            metadata={"subset": "FD001", "target_unit": "cycles", "target": {"rul_cap": 125.},
                      "split_units": {"train": [1], "val": [2], "stream": [81, 82]},
                      "unit_cycle_counts": {"1": 32, "2": 32, **counts}}, batch_size=batch_size)
        return output, manifest

    def saved_pair(self, *, deployed=True, post_error=0.):
        package, manifest = self.package()
        pair = self.root / "pair"
        y = np.array([125., 100., 40., 30., 1., 0.])
        ids = np.arange(manifest["splits"]["stream"]["sample_id_min"],
                        manifest["splits"]["stream"]["sample_id_max"] + 1)
        for policy in ("static", "drift"):
            folder = pair / policy
            folder.mkdir(parents=True)
            p = y + 2.
            if policy == "drift" and deployed:
                p[4:] = y[4:] + post_error
            np.savez_compressed(folder / "predictions.npz", predictions=p,
                                sample_ids=ids, batch_offsets=np.array([0, 2, 4, 6]))
            events = [{"event": "run_started", "step": -1}]
            for step in range(3):
                events.append({"event": "prediction", "step": step, "samples": 2,
                               "model_version": int(policy == "drift" and deployed and step == 2)})
                if policy == "drift" and deployed and step == 1:
                    events.append({"event": "deploy", "step": 1, "model_version": 1,
                                   "accepted": True, "reason": "independent_future_labels",
                                   "frozen_at": 0, "gate_min_source_step": 1,
                                   "gate_max_source_step": 1, "gate_samples": 2})
            events.append({"event": "run_completed", "step": 3})
            (folder / "events.jsonl").write_text("\n".join(json.dumps(e) for e in events) + "\n")
        return package, pair

    def test_report_uses_sample_squared_errors_and_actual_postdeployment_subset(self):
        module = self.module()
        package, pair = self.saved_pair()
        result = module.build_report(pair, package, self.root / "report")
        self.assertEqual(result["full_stream"]["static"]["rmse"], 2.)
        self.assertAlmostEqual(result["full_stream"]["drift"]["rmse"], math.sqrt(16 / 6))
        self.assertEqual(result["post_deployment"]["drift"]["samples"], 2)
        self.assertEqual(result["post_deployment"]["drift"]["rmse"], 0.)
        self.assertEqual(result["post_deployment"]["static_same_samples"]["rmse"], 2.)
        self.assertTrue(result["positive_condition"]["passed"])
        self.assertEqual(result["actual_prediction_versions"]["drift"], [0, 0, 1])
        self.assertEqual(result["by_engine"][1]["drift"]["rmse"], 0.)
        self.assertEqual([r["static"]["samples"] for r in result["by_rul_stage"]], [3, 2, 1])
        for name in ("assessment.json", "batch_metrics.csv", "engine_metrics.csv", "stage_metrics.csv",
                     "events.json", "curves.svg", "report.md"):
            self.assertTrue((self.root / "report" / name).is_file(), name)
        with self.assertRaises(FileExistsError):
            module.build_report(pair, package, self.root / "report")

    def test_no_deployment_is_not_positive_and_missing_metrics_are_null(self):
        module = self.module()
        package, pair = self.saved_pair(deployed=False)
        result = module.build_report(pair, package, self.root / "report")
        self.assertFalse(result["positive_condition"]["passed"])
        self.assertEqual(result["events"]["deployments"], 0)
        self.assertEqual(result["post_deployment"]["drift"]["samples"], 0)
        self.assertIsNone(result["post_deployment"]["drift"]["rmse"])
        self.assertEqual(result["full_stream"]["static"], result["full_stream"]["drift"])

    def test_deployment_with_worse_future_rmse_blocks_positive_condition(self):
        module = self.module()
        package, pair = self.saved_pair(post_error=4.)
        result = module.build_report(pair, package, self.root / "report")
        self.assertFalse(result["positive_condition"]["passed"])
        self.assertEqual(result["post_deployment"]["drift"]["rmse"], 4.)
        self.assertAlmostEqual(result["full_stream"]["drift"]["rmse"], math.sqrt(8))

    def test_report_rejects_misaligned_ids_before_writing_results(self):
        module = self.module()
        package, pair = self.saved_pair()
        path = pair / "drift/predictions.npz"
        with np.load(path, allow_pickle=False) as z:
            arrays = {k: z[k].copy() for k in z.files}
        arrays["sample_ids"] = arrays["sample_ids"][::-1]
        np.savez_compressed(path, **arrays)
        with self.assertRaisesRegex(ValueError, "ID|align|match"):
            module.build_report(pair, package, self.root / "report")
        self.assertFalse((self.root / "report").exists())

    def test_report_rejects_incomplete_runs_or_same_batch_new_version(self):
        module = self.module()
        package, pair = self.saved_pair()
        path = pair / "drift/events.jsonl"
        events = [json.loads(s) for s in path.read_text().splitlines()]
        original = path.read_text()
        path.write_text("\n".join(json.dumps(e) for e in events[:-1]))
        with self.assertRaises(ValueError):
            module.build_report(pair, package, self.root / "report")
        events = [json.loads(s) for s in original.splitlines()]
        next(e for e in events if e["event"] == "prediction" and e["step"] == 1)["model_version"] = 1
        path.write_text("\n".join(json.dumps(e) for e in events))
        with self.assertRaises(ValueError):
            module.build_report(pair, package, self.root / "report")

    def test_pair_runs_real_tree_workers_and_scores_after_both_streams_finish(self):
        module = self.module()
        package, _ = self.package(online=True)
        config = ExperimentConfig.from_dict(dict(task="regression", model_type="tree", n_features=24,
            initial_train=32, initial_validation=32, n_batches=9, batch_size=32, label_delay=2,
            label_mode="provided", history_windows=[24, 48, 96], min_labeled=24, min_validation=6,
            monitor_min_labeled=24, selection_split="recent_disjoint", deployment_validation="future",
            training_preflight=True, candidate_feasibility=True, harness_enabled=True,
            harness_drift_only=True, max_tokens=1000, max_llm_calls=5))
        completed = []
        original_run, original_report = module.run_policy, module.build_report

        def run(*args, **kwargs):
            self.assertIsNone(kwargs.get("offline_scorer"))
            result = original_run(*args, **kwargs)
            completed.append(args[1])
            return result

        def report(*args, **kwargs):
            self.assertEqual(completed, ["static", "drift"])
            return original_report(*args, **kwargs)

        with (tree_initial_timeout(), patch.object(module, "run_policy", side_effect=run),
              patch.object(module, "build_report", side_effect=report)):
            result = module.run_cmapss_pair(package, self.root / "online-pair", config)
        self.assertTrue(result["positive_condition"]["passed"])
        self.assertEqual(result["full_stream"]["static"]["rmse"], 10.)
        self.assertEqual(result["post_deployment"]["drift"]["rmse"], 0.)
        for e in result["deployment_timeline"]:
            self.assertGreater(e["deploy"]["gate_min_source_step"], e["deploy"]["frozen_at"])
            self.assertEqual(e["first_next_prediction"]["model_version"], e["deploy"]["model_version"])
        self.assertEqual(result["online_summaries"]["drift"]["real_llm_tokens"], 0)
        with self.assertRaises(FileExistsError):
            module.run_cmapss_pair(package, self.root / "online-pair", config)

    def test_real_config_fixes_existing_twenty_engine_eighteen_batch_protocol(self):
        self.module()
        cfg = ExperimentConfig.load(Path(__file__).resolve().parents[1] / "configs/cmapss-harness-tree.json")
        self.assertEqual((cfg.n_features, cfg.initial_train, cfg.initial_validation), (24, 11942, 4196))
        self.assertEqual((cfg.n_batches, cfg.batch_size, cfg.label_delay), (18, 256, 2))
        self.assertEqual((cfg.tree_max_depth, cfg.tree_min_samples_leaf, cfg.tree_max_leaf_nodes), (6, 5, 64))
        self.assertEqual(cfg.history_windows, (192, 384, 768))
        self.assertEqual((cfg.tree_timeout_seconds, cfg.max_train_seconds), (5., 20.))
        self.assertEqual(cfg.harness_backend, "mock")
        self.assertTrue(cfg.harness_enabled and cfg.harness_drift_only)
        self.assertEqual(cfg.selection_split, "recent_disjoint")


if __name__ == "__main__":
    unittest.main()
