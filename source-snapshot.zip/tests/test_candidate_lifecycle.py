import json
import tempfile
import unittest
from pathlib import Path

import numpy as np

from ite.config import ExperimentConfig
from ite.controller import AdaptationController
from ite.data import PublicBatch, ReleasedLabels
from ite.labeling import LabelAvailability
from ite.models import RidgeModel
from ite.runner import run_comparison
from ite.tracking import JsonlLogger


class CandidateLifecycleTests(unittest.TestCase):
    def exercise(self, *, final_step, release=False, outstanding=(), wait=3):
        rng = np.random.default_rng(12)
        x = rng.normal(size=(96, 3))
        y = (x[:, 0] > 0).astype(int)
        original = RidgeModel().fit(x, 1 - y)
        candidate = RidgeModel().fit(x, y)
        config = ExperimentConfig.from_dict({"n_features": 3, "deployment_validation": "future",
            "candidate_feasibility": True, "candidate_max_wait_batches": wait,
            "update_interval": 100, "n_batches": 12})
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            with JsonlLogger(output / "events.jsonl", "lifecycle") as logger:
                controller = AdaptationController(config, "periodic", original, .01, 1,
                                                  logger, None, output)
                controller.history_steps = np.array([0])
                controller.history_x, controller.history_y = x[:1].copy(), y[:1].copy()
                controller._freeze(candidate, 0, {"candidate_kind": "trained"})
                ids = np.arange(48)
                labels = ReleasedLabels(ids, x[:48], y[:48], np.ones(48, dtype=int)) if release else None
                availability = LabelAvailability(0, 24, 11, 2, outstanding)
                controller.observe(PublicBatch(final_step, ids, x[:48]), labels,
                                   dict(zip(map(int, ids), original.predict(x[:48]))), availability)
                unchanged = controller.gate.model is original
                pending = controller.pending is not None
            events = [json.loads(line) for line in (output / "events.jsonl").read_text().splitlines()]
        return unchanged, pending, events

    def test_wait_deadline_rejects_candidate_and_preserves_incumbent(self):
        unchanged, pending, events = self.exercise(final_step=3, outstanding=((1, 8),) * 48)
        self.assertTrue(unchanged)
        self.assertFalse(pending, "No label release must not prevent deadline expiry")
        rejection = next(e for e in events if e["event"] == "experiment_rejected")
        self.assertEqual(rejection["reason"], "independent_validation_deadline")
        self.assertEqual(rejection["waited_batches"], 3)

    def test_inflight_independent_labels_are_valid_even_after_budget_exhaustion(self):
        unchanged, pending, _ = self.exercise(final_step=1, outstanding=((1, 3),) * 48)
        self.assertTrue(unchanged)
        self.assertTrue(pending, "Already requested future labels can still complete the gate")
        unchanged, pending, events = self.exercise(final_step=3, release=True)
        self.assertFalse(unchanged)
        self.assertFalse(pending)
        self.assertTrue(any(e["event"] == "deploy" for e in events))

    def test_labels_arriving_after_deadline_cannot_deploy_candidate(self):
        unchanged, pending, events = self.exercise(final_step=4, release=True)
        self.assertTrue(unchanged)
        self.assertFalse(pending)
        self.assertFalse(any(e["event"] == "deploy" for e in events))

    def test_impossible_gate_skips_training_before_spending_resources(self):
        config = ExperimentConfig.from_dict({"n_batches": 12, "drift_start": 0,
            "deployment_validation": "future", "candidate_feasibility": True,
            "max_labels": 96, "label_delay": 2})
        with tempfile.TemporaryDirectory() as directory:
            result = run_comparison(config, Path(directory), policies=("drift",))[0]
            self.assertEqual(result["experiments"], 0)
            self.assertEqual(result["adaptation_train_seconds"], 0)
            self.assertGreater(result["label_infeasible_skips"], 0)

    def test_protocol_capacity_excludes_prefreeze_and_late_pending_labels(self):
        availability = LabelAvailability(10, 24, 11, 2, ((1, 6), (5, 7), (6, 12)))
        self.assertEqual(availability.capacity(frozen_at=4, step=6, deadline=8), 1)
        self.assertEqual(availability.capacity(frozen_at=4, step=5, deadline=8), 11)


if __name__ == "__main__":
    unittest.main()
