"""The A replay comparison keeps source pairing and accuracy guards explicit."""

import importlib
import unittest

import numpy as np


class OfficialAReplayComparisonTests(unittest.TestCase):
    def module(self):
        try:
            return importlib.import_module("scripts.run_official_a_replay_comparison")
        except ImportError as error:
            self.fail(f"Official A replay comparison is missing: {error}")

    def test_macro_f1_gain_cannot_hide_accuracy_regression(self):
        m = self.module()
        targets = np.asarray([1] * 90 + [2] * 2 + [3] * 2 + [4] * 2 + [5] * 2 + [6] * 2)
        static = np.ones(len(targets), dtype=int)
        accuracy_regression = np.asarray([1] * 51 + [2] * 39 + [2] * 2 + [3] * 2 +
                                         [4] * 2 + [5] * 2 + [6] * 2)
        perfect = targets.copy()
        source_ids = np.asarray([f"source-{i}" for i in range(len(targets))])
        rows = {
            "static": {"targets": targets, "static": static, "active": static, "source_ids": source_ids},
            "full_no_replay": {"targets": targets, "static": static, "active": static, "source_ids": source_ids},
            "full_with_replay": {"targets": targets, "static": static, "active": accuracy_regression,
                                  "source_ids": source_ids},
        }
        result = m.summarize_a_paired(rows, "abrupt")
        self.assertGreater(result["metrics"]["full_with_replay"]["macro_f1"],
                           result["metrics"]["static"]["macro_f1"])
        self.assertLess(result["metrics"]["full_with_replay"]["accuracy"],
                        result["metrics"]["static"]["accuracy"])
        self.assertFalse(result["passes"]["full_with_replay"])
        rows["full_with_replay"]["active"] = perfect
        result = m.summarize_a_paired(rows, "abrupt")
        self.assertTrue(result["passes"]["full_with_replay"])

    def test_comparison_rejects_unpaired_source_ids(self):
        m = self.module()
        targets = np.asarray([1, 2, 3, 4, 5, 6])
        static = np.ones(6, dtype=int)
        source_ids = np.asarray([f"source-{i}" for i in range(6)])
        rows = {name: {"targets": targets, "static": static, "active": static,
                       "source_ids": source_ids.copy()}
                for name in ("static", "full_no_replay", "full_with_replay")}
        rows["full_with_replay"]["source_ids"][0] = "different-source"
        with self.assertRaisesRegex(ValueError, "Unpaired"):
            m.summarize_a_paired(rows, "stable")

    def test_engineering_audit_rejects_future_gate_overlap_with_candidate_data(self):
        m = self.module()
        replay_ids = [f"replay-{i}" for i in range(48)]
        candidate = {"event": "candidate_evaluated", "decision_id": "candidate-1",
            "candidate_adam_steps": 11, "parent_adam_steps": 10, "train_seconds": .02,
            "train_samples": 48, "train_source_ids": replay_ids,
            "online_train_source_ids": [f"replaced-{i}" for i in range(48)],
            "replay_source_ids": replay_ids, "screening_source_ids": ["screen-1"]}
        gate = {"event": "deploy", "reason": "independent_future_labels", "decision_id": "candidate-1",
                "candidate_replay_source_ids": replay_ids, "source_ids": ["future-1"]}
        events = [{"event": "prediction"} for _ in range(12)] + [candidate, gate]
        self.assertTrue(m._engineering_ok("full_with_replay", {"train_seconds": .02, "updates": 1}, events))
        events[-1]["source_ids"] = [replay_ids[0]]
        self.assertFalse(m._engineering_ok("full_with_replay", {"train_seconds": .02, "updates": 1}, events))


if __name__ == "__main__":
    unittest.main()
