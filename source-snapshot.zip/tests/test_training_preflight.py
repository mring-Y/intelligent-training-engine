import json
import tempfile
import unittest
from contextlib import contextmanager
from pathlib import Path

import numpy as np

from ite.budget import ResourceBudget
from ite.config import ExperimentConfig
from ite.controller import AdaptationController
from ite.data import PublicBatch, ReleasedLabels, make_simulation
from ite.models import RidgeModel, prediction_loss
from ite.runner import run_comparison
from ite.tracking import JsonlLogger
from ite.training import BoundedTrainer


class TrainingPreflightTests(unittest.TestCase):
    def config(self, **overrides):
        return ExperimentConfig.from_dict({
            "task": "regression", "n_features": 3, "n_batches": 96,
            "deployment_validation": "future", "history_windows": [192],
            "candidate_alphas": [1.0], "min_gain": 0,
            "train_source_window_batches": 8, "training_preflight": True,
            "update_interval": 1, **overrides})

    @contextmanager
    def controller(self, recent_count=15, **overrides):
        steps = np.concatenate((np.repeat(np.arange(3), 24),
                                np.full(recent_count, 4), np.full(48, 11)))
        rng = np.random.default_rng(821)
        x = rng.normal(size=(len(steps), 3))
        y = 2 * x[:, 0] - x[:, 1]
        model = RidgeModel("regression").fit(x, -y)
        with tempfile.TemporaryDirectory() as directory, BoundedTrainer() as trainer:
            root = Path(directory)
            with JsonlLogger(root / "events.jsonl", "preflight") as logger:
                controller = AdaptationController(self.config(**overrides), "periodic", model,
                                                  .01, 1, logger, trainer, root)
                controller.history_x, controller.history_y, controller.history_steps = x, y, steps
                yield controller, root, x, y

    def events(self, root):
        return [json.loads(line) for line in (root / "events.jsonl").read_text().splitlines()]

    def observe(self, controller, step, released=None):
        x = np.array([[1., 0., 0.], [-1., 0., 0.]])
        predictions = (dict(zip(map(int, released.sample_ids), controller.predict(released.features)))
                       if released is not None else {})
        controller.observe(PublicBatch(step, np.array([10000, 10001]), x), released, predictions)

    def release(self, count, source, first_id=0):
        rng = np.random.default_rng(822 + source + first_id)
        x = rng.normal(size=(count, 3))
        return ReleasedLabels(np.arange(first_id, first_id + count), x,
                              2 * x[:, 0] - x[:, 1], np.full(count, source))

    def test_option_is_strict_boolean_default_false_and_json_roundtrips(self):
        self.assertFalse(ExperimentConfig().training_preflight)
        for enabled in (False, True):
            config = self.config(training_preflight=enabled)
            self.assertEqual(ExperimentConfig.from_dict(json.loads(json.dumps(config.to_dict()))), config)
        for invalid in (0, 1, None, "true", [], {}):
            with self.subTest(invalid=invalid), self.assertRaises(ValueError):
                self.config(training_preflight=invalid)

    def test_insufficient_samples_do_not_spend_training_attempts_or_experiments(self):
        # Catches charging a training experiment before the 16-label feasibility check.
        for count in (0, 15):
            with self.subTest(train_samples=count), self.controller(count) as (controller, root, x, _):
                before = controller.predict(x)
                controller._experiment(13, {"diagnosis": "performance"})
                self.assertEqual(controller.budget.experiments, 0)
                self.assertEqual(controller.budget.training_attempts, 0)
                self.assertEqual(controller.budget.train_seconds, 0)
                self.assertIsNone(controller.pending)
                np.testing.assert_array_equal(controller.predict(x), before)
                events = self.events(root)
                self.assertFalse(any(e["event"] in ("experiment_started", "candidate_evaluated") for e in events))
                skipped = next(e for e in events if e["event"] == "training_preflight_skipped")
                self.assertEqual(skipped["train_samples"], count)
                self.assertEqual(skipped["validation_samples"], 48)
                self.assertEqual(skipped["train_source_cutoff"], 4)
                self.assertEqual(skipped["training_attempts"], 0)
                self.assertEqual(skipped["experiments"], 0)

    def test_insufficient_samples_do_not_move_real_or_audited_cooldown(self):
        # Catches advancing the actual cooldown clock even if an audit counter is static.
        with self.controller() as (controller, root, _, _):
            before = controller.last_experiment
            controller._experiment(13, {"diagnosis": "performance"})
            self.assertEqual(controller.last_experiment, before)
            self.assertEqual(controller.cooldown_until, 0)
            self.assertEqual(controller.last_experiment_source, -1)
            skipped = next(e for e in self.events(root) if e["event"] == "training_preflight_skipped")
            self.assertEqual(skipped["last_experiment"], before)
            self.assertEqual(skipped["cooldown_until"], 0)

    def test_default_disabled_keeps_legacy_insufficient_sample_accounting(self):
        with self.controller(training_preflight=False) as (controller, root, _, _):
            controller._experiment(13, {"diagnosis": "performance"})
            self.assertEqual(controller.budget.experiments, 1)
            self.assertEqual(controller.budget.training_attempts, 1)
            self.assertEqual(controller.last_experiment, 13)
            self.assertEqual(controller.cooldown_until, 17)
            self.assertEqual(controller.last_experiment_source, 11)
            skipped = next(e for e in self.events(root) if e["event"] == "experiment_skipped")
            self.assertEqual(skipped["reason"], "insufficient_temporally_separate_labels")

    def test_sixteen_samples_train_on_original_split_and_require_future_gate(self):
        with self.controller(16) as (controller, root, x, y):
            original = controller.gate.model
            controller._experiment(13, {"diagnosis": "performance"})
            self.assertEqual(controller.budget.experiments, 1)
            self.assertEqual(controller.budget.training_attempts, 1)
            self.assertEqual(controller.last_experiment, 13)
            self.assertEqual(controller.cooldown_until, 17)
            self.assertIs(controller.gate.model, original)
            self.assertIsNotNone(controller.pending)
            expected = RidgeModel("regression", 1).fit(x[72:88], y[72:88])
            np.testing.assert_allclose(controller.pending["model"].predict(x), expected.predict(x))
            expected_loss = prediction_loss("regression", y[88:], expected.predict(x[88:]))
            self.assertAlmostEqual(controller.pending["spec"]["selection_loss"], expected_loss)
            controller._validate_pending(self.release(48, 13), 15)
            self.assertEqual(controller.pending["y"], [])
            controller._validate_pending(self.release(48, 14), 16)
            self.assertEqual(controller.gate.updates, 1)
            self.assertEqual(controller.last_experiment, 16)
            self.assertEqual(controller.cooldown_until, 20)
            np.testing.assert_array_equal(RidgeModel.load(root / "deployed.npz").predict(x), controller.predict(x))
            started = next(e for e in self.events(root) if e["event"] == "experiment_started")
            self.assertEqual((started["train_min_step"], started["train_max_step"], started["train_samples"]), (4, 4, 16))
            self.assertEqual((started["validation_min_step"], started["validation_samples"]), (11, 48))

    def test_unchanged_evidence_is_not_repeated_but_newly_released_labels_retry(self):
        with self.controller() as (controller, root, _, _):
            self.observe(controller, 13)
            self.observe(controller, 14)
            self.assertEqual(sum(e["event"] == "training_preflight_skipped" for e in self.events(root)), 1)
            # Same latest source, but a newly released sample is new evidence.
            self.observe(controller, 15, self.release(1, 11))
            self.observe(controller, 16)
            self.assertEqual(sum(e["event"] == "training_preflight_skipped" for e in self.events(root)), 2)
            self.assertEqual(controller.budget.experiments, 0)
            self.assertEqual(controller.last_experiment, -4)
            self.observe(controller, 17, self.release(48, 12, 1))
            self.assertEqual(controller.budget.experiments, 1)
            self.assertEqual(controller.budget.training_attempts, 1)
            self.assertEqual(controller.last_experiment, 17)
            self.assertIsNotNone(controller.pending)
            self.assertEqual(controller.training_preflight_skips, 2)

    def test_actual_training_cooldown_and_exhausted_budget_still_block_work(self):
        with self.controller(16, min_gain=1e6, max_experiments=1) as (controller, root, x, _):
            before = controller.predict(x)
            self.observe(controller, 13)
            self.assertIsNone(controller.pending)
            self.assertEqual(controller.budget.experiments, 1)
            self.assertEqual(controller.budget.training_attempts, 1)
            self.assertEqual(controller.cooldown_until, 17)
            self.observe(controller, 14, self.release(48, 12))
            self.observe(controller, 16)
            self.assertEqual(controller.last_experiment, 13)
            self.assertEqual(len([e for e in self.events(root) if e["event"] == "candidate_evaluated"]), 1)
            self.observe(controller, 17)
            self.assertEqual(controller.budget.experiments, 1)
            self.assertEqual(controller.budget.training_attempts, 1)
            self.assertEqual(controller.last_experiment, 17)
            self.assertEqual(controller.cooldown_until, 21)
            self.assertTrue(any(e.get("reason") == "budget_exhausted" for e in self.events(root)))
            np.testing.assert_array_equal(controller.predict(x), before)

    def test_training_attempt_audit_excludes_archive_experiments_and_failed_starts(self):
        budget = ResourceBudget(self.config(max_experiments=2))
        self.assertTrue(budget.start_experiment(needs_training=False))
        self.assertTrue(budget.start_experiment())
        self.assertFalse(budget.start_experiment())
        self.assertEqual(budget.experiments, 2)
        self.assertEqual(budget.training_attempts, 1)
        self.assertEqual(budget.snapshot()["training_attempts"], 1)

    def test_training_time_exhaustion_does_not_increment_training_attempts(self):
        with self.controller(16, max_train_seconds=0) as (controller, root, _, _):
            controller._experiment(13, {"diagnosis": "performance"})
            self.assertEqual(controller.budget.experiments, 0)
            self.assertEqual(controller.budget.training_attempts, 0)
            self.assertEqual(controller.last_experiment, 13)
            self.assertTrue(any(e.get("reason") == "budget_exhausted" for e in self.events(root)))

    def test_delayed_and_short_streams_keep_predictions_checkpoints_and_audits(self):
        for batches, delay in ((18, 2), (8, 0)):
            with self.subTest(batches=batches), tempfile.TemporaryDirectory() as directory:
                config = self.config(n_batches=batches, label_delay=delay, drift_start=0,
                                     update_interval=4 if delay else 8, cooldown=0)
                root = Path(directory)
                result = run_comparison(config, root, policies=("periodic", "static"))[0]
                events = self.events(root / "periodic")
                self.assertTrue(result["training_preflight"])
                self.assertEqual(result["stream_batches"], batches)
                self.assertEqual(result["training_attempts"], result["experiments"])
                self.assertEqual(result["training_preflight_skips"], sum(e["event"] == "training_preflight_skipped" for e in events))
                self.assertGreaterEqual(result["cooldown_until"], 0)
                self.assertLessEqual(result["labels_requested"], config.max_labels)
                self.assertEqual(result["labels_unreleased"], delay * 24)
                if delay:
                    self.assertGreater(result["updates"], 0)
                    for event in events:
                        if event["event"] == "deploy":
                            self.assertGreater(event["gate_min_source_step"], event["frozen_at"])
                            self.assertLessEqual(event["gate_max_source_step"] + delay, event["step"])
                else:
                    self.assertEqual(result["updates"], 0)
                    self.assertTrue(any(e.get("reason") == "stream_ended_before_independent_validation" for e in events))
                simulation = make_simulation(config)
                versions = [e["model_version"] for e in events if e["event"] == "prediction"]
                with np.load(root / "periodic/predictions.npz", allow_pickle=False) as saved:
                    for batch, version, prediction in zip(simulation.batches, versions, saved["predictions"]):
                        checkpoint = f"model-v{version}.npz" if version else "initial.npz"
                        np.testing.assert_array_equal(RidgeModel.load(root / "periodic" / checkpoint).predict(batch.features), prediction)

    def test_candidate_configuration_changes_only_preflight_switch(self):
        root = Path(__file__).resolve().parents[1]
        baseline = ExperimentConfig.load(root / "configs/optimization-training-freshness-8.json").to_dict()
        candidate = ExperimentConfig.load(root / "configs/optimization-training-preflight.json").to_dict()
        self.assertFalse(baseline.pop("training_preflight"))
        self.assertTrue(candidate.pop("training_preflight"))
        self.assertEqual(candidate, baseline)


if __name__ == "__main__":
    unittest.main()
