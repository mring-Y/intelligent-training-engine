"""The approved 4B run uses configured rates and preserves historical receipts."""

import json
import inspect
import sys
import tempfile
import unittest
from pathlib import Path

from ite.budget import ResourceBudget
from ite.budget_guard import BudgetGuard
from ite.config import ExperimentConfig
from ite.llm_ledger import CallLedger
from ite.tracking import JsonlLogger
from ite.trio_client import TrioLLMClient


class Qwen4BAccountingTests(unittest.TestCase):
    def test_configured_rates_reserve_and_settle_a_real_client_reply(self):
        self.assertIn("llm_input_price_per_million", ExperimentConfig.__dataclass_fields__)
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)
            worker_path = path / "worker.py"
            worker_path.write_text("import json,sys\njson.load(sys.stdin)\n"
                "print(json.dumps({'content':json.dumps({'action':'DO_NOTHING','reason':'hold'}),"
                "'input_tokens':960,'output_tokens':40,'finish_reason':'stop'}))\n", encoding="utf-8")
            worker = [sys.executable, "-X", "utf8", str(worker_path)]
            config = ExperimentConfig(max_tokens=3600, max_llm_calls=2,
                max_llm_cost_cny="0.03", label_mode="provided",
                llm_input_price_per_million="1.49", llm_output_price_per_million="4.54")
            budget = ResourceBudget(config)
            ledger = CallLedger(path / "ledger.json", identity="new-4b")
            with JsonlLogger(path / "events.jsonl", "4b") as logger:
                guard = BudgetGuard(budget, logger, ledger=ledger)
                client = TrioLLMClient(model="Qwen/Qwen3.5-4B", max_input_tokens=1250,
                    max_output_tokens=128, worker_command=worker,
                    input_price_per_million=config.llm_input_price_per_million,
                    output_price_per_million=config.llm_output_price_per_million)
                observation = {"loss_trend": [], "drift_alarm": True,
                    "remaining_label_budget": None, "remaining_token_budget": 3600,
                    "model_age_batches": 11}
                decision = guard.get_decision(observation, client, 10)
            self.assertEqual(decision.action, "DO_NOTHING")
            receipt = json.loads(ledger.path.read_text(encoding="utf-8"))["requests"][0]
            self.assertEqual(receipt["reserved_cost_cny"], "0.00244362")
            self.assertEqual(receipt["cost_cny"], "0.00161200")
            self.assertEqual((receipt["input_price_per_million"], receipt["output_price_per_million"]),
                             ("1.49", "4.54"))
            self.assertEqual(receipt["model"], "Qwen/Qwen3.5-4B")

    def test_invalid_configured_prices_cannot_understate_budget(self):
        self.assertIn("llm_input_price_per_million", ExperimentConfig.__dataclass_fields__)
        for value in ("0", "-1", "NaN", "Infinity", "invalid", True):
            with self.subTest(value=value), self.assertRaises(ValueError):
                ExperimentConfig(llm_input_price_per_million=value)

    def test_nondefault_model_without_explicit_prices_is_rejected_before_accounting(self):
        with self.assertRaisesRegex(ValueError, "explicit.*price"):
            ExperimentConfig(llm_model="Qwen/Qwen3.8-27B")
        with self.assertRaisesRegex(ValueError, "explicit.*price"):
            TrioLLMClient(model="Qwen/Qwen3.8-27B")
        client = TrioLLMClient(model="Qwen/Qwen3.8-27B",
                              input_price_per_million="8.41", output_price_per_million="25.29")
        self.assertEqual((client.input_price_per_million, client.output_price_per_million), ("8.41", "25.29"))

    def test_cost_projection_uses_explicit_rates_without_falling_back_to_27b(self):
        from ite.llm_audit import audit_cost
        self.assertIn("input_price_per_million", inspect.signature(audit_cost).parameters)
        result = audit_cost({"identity": "empty-4b", "requests": []}, [], batches=18,
            drift_calls=2, max_calls=2, max_input_tokens=1250, max_output_tokens=128,
            input_price_per_million="1.49", output_price_per_million="4.54")
        self.assertEqual(result["configured_upper_bound"]["estimated_cost_cny"], "0.00488724")
        self.assertIsNone(result["capped"])

    def test_legacy_and_4b_requests_settle_at_their_own_frozen_prices(self):
        self.assertIn("model", inspect.signature(CallLedger.reserve).parameters)
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "receipts.json"
            ledger = CallLedger(path, identity="historical-fixture")
            first = ledger.reserve(max_calls=2, max_input_tokens=1250, max_output_tokens=128,
                max_total_tokens=40000, max_cost_cny="0.03", input_price_per_million="8.41",
                output_price_per_million="25.29", step=0, model="Qwen/Qwen3.8-27B")
            ledger.settle(first["call_id"], input_tokens=100, output_tokens=20)
            old = json.loads(path.read_text(encoding="utf-8"))["requests"][0]
            second = ledger.reserve(max_calls=2, max_input_tokens=1250, max_output_tokens=128,
                max_total_tokens=40000, max_cost_cny="0.03", input_price_per_million="1.49",
                output_price_per_million="4.54", step=1, model="Qwen/Qwen3.5-4B")
            ledger.settle(second["call_id"], input_tokens=100, output_tokens=20)
            receipts = json.loads(path.read_text(encoding="utf-8"))["requests"]
            self.assertEqual(receipts[0], old)
            self.assertEqual((receipts[0]["cost_cny"], receipts[1]["cost_cny"]),
                             ("0.00134680", "0.00023980"))


if __name__ == "__main__":
    unittest.main()
