"""The A replay timing review must isolate decision time and preserve safeguards."""

import importlib
import unittest

import numpy as np


class OfficialAReplayTimingComparisonTests(unittest.TestCase):
    def module(self):
        try:
            return importlib.import_module("scripts.run_official_a_replay_timing_comparison")
        except ImportError as error:
            self.fail(f"Official A replay timing comparison is missing: {error}")

    def test_case_plan_pairs_static_early_and_late_in_all_scenarios_and_splits(self):
        module = self.module()
        cases = module.case_plan()
        self.assertEqual(len(cases), 18)
        self.assertEqual({case["arm"] for case in cases},
                         {"static", "replay_step3", "replay_step7"})
        for scenario in ("stable", "abrupt", "gradual"):
            for split in ("train", "eval"):
                by_arm = {case["arm"]: case for case in cases
                          if case["scenario"] == scenario and case["split"] == split}
                self.assertEqual(set(by_arm), {"static", "replay_step3", "replay_step7"})
                self.assertEqual(by_arm["static"]["decision_steps"], ())
                self.assertEqual(by_arm["replay_step3"]["decision_steps"], (3,))
                self.assertEqual(by_arm["replay_step7"]["decision_steps"], (7,))
                self.assertEqual(by_arm["static"]["expected_screening_samples"], 0)
                self.assertEqual(by_arm["replay_step3"]["expected_screening_samples"],
                                 18 if split == "eval" else 48)
                self.assertEqual(by_arm["replay_step7"]["expected_screening_samples"],
                                 41 if split == "eval" else 48)

    def test_macro_f1_gain_cannot_hide_accuracy_regression_in_either_timing_arm(self):
        module = self.module()
        targets = np.asarray([1] * 90 + [2] * 2 + [3] * 2 + [4] * 2 + [5] * 2 + [6] * 2)
        static = np.ones(len(targets), dtype=int)
        candidate = np.asarray([1] * 51 + [2] * 39 + [2] * 2 + [3] * 2 +
                               [4] * 2 + [5] * 2 + [6] * 2)
        source_ids = np.asarray([f"source-{i}" for i in range(len(targets))])
        rows = {
            "static": {"targets": targets, "static": static, "active": static,
                       "source_ids": source_ids},
            "replay_step3": {"targets": targets, "static": static, "active": candidate,
                             "source_ids": source_ids},
            "replay_step7": {"targets": targets, "static": static, "active": candidate,
                             "source_ids": source_ids},
        }

        result = module.summarize_a_timing_paired(rows, "abrupt")

        for arm in ("replay_step3", "replay_step7"):
            self.assertGreater(result["metrics"][arm]["macro_f1"],
                               result["metrics"]["static"]["macro_f1"])
            self.assertLess(result["metrics"][arm]["accuracy"],
                            result["metrics"]["static"]["accuracy"])
            self.assertFalse(result["passes"][arm])

    def test_engineering_audit_enforces_screen_count_and_disjoint_future(self):
        module = self.module()
        replay_ids = [f"replay-{i}" for i in range(48)]
        online_ids = [f"online-{i}" for i in range(54)]
        candidate = {
            "event": "candidate_evaluated",
            "step": 7,
            "decision_id": "A-eval-abrupt-7",
            "candidate_adam_steps": 11,
            "parent_adam_steps": 10,
            "train_seconds": 0.02,
            "train_samples": 54,
            "screening_samples": 41,
            "train_source_ids": replay_ids + online_ids[48:],
            "online_train_source_ids": online_ids,
            "replay_source_ids": replay_ids,
            "replaced_online_source_ids": online_ids[:48],
            "screening_source_ids": [f"screen-{i}" for i in range(41)],
        }
        events = ([{"event": "run_started", "split": "eval"}] +
                  [{"event": "prediction", "step": step} for step in range(12)] +
                  [candidate, {"event": "deploy", "decision_id": candidate["decision_id"],
                               "reason": "independent_future_labels", "gate_min_source_step": 8,
                               "source_ids": ["future-1"],
                               "candidate_replay_source_ids": replay_ids}])
        summary = {"training_attempts": 1, "train_seconds": 0.02, "updates": 1}

        self.assertTrue(module._engineering_ok("replay_step7", summary, events, 41))

        candidate["screening_samples"] = 40
        candidate["screening_source_ids"] = candidate["screening_source_ids"][:-1]
        self.assertFalse(module._engineering_ok("replay_step7", summary, events, 41))
        candidate["screening_samples"] = 41
        candidate["screening_source_ids"] = [f"screen-{i}" for i in range(41)]
        candidate["step"] = 3
        self.assertFalse(module._engineering_ok("replay_step7", summary, events, 41))
        candidate["step"] = 7
        events[-1]["source_ids"] = [replay_ids[0]]
        self.assertFalse(module._engineering_ok("replay_step7", summary, events, 41))
        events[-1]["source_ids"] = ["future-1"]
        candidate["train_source_ids"][0] = "unexpected-training-source"
        self.assertFalse(module._engineering_ok("replay_step7", summary, events, 41))


if __name__ == "__main__":
    unittest.main()
