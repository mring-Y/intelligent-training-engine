import csv
import tempfile
import unittest
from pathlib import Path

try:
    from ite.validation import assess_deployment
except ImportError:
    assess_deployment = None


class DeploymentAssessmentTests(unittest.TestCase):
    def write_matrix(self, path, rows):
        with path.open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=("task", "scenario", "seed", "policy", "mean_loss"))
            writer.writeheader()
            writer.writerows(rows)

    def test_assessment_checks_paired_nonrecurring_regression_and_both_recurring_tasks(self):
        self.assertIsNotNone(assess_deployment, "Paired independent deployment assessment is missing")
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            baseline, candidate, history = (root / name for name in ("baseline.csv", "candidate.csv", "history.csv"))
            rows = []
            tasks = ("classification", "regression")
            scenarios = ("stable", "abrupt", "gradual", "recurring", "covariate", "noise")
            seeds = (101, 103)
            for task in tasks:
                for scenario in scenarios:
                    for seed in seeds:
                        base = 0.4 if task == "classification" else 0.5
                        rows.extend(({"task": task, "scenario": scenario, "seed": seed,
                                      "policy": policy, "mean_loss": base}
                                     for policy in ("static", "periodic", "drift")))
            self.write_matrix(baseline, rows)
            candidate_rows = [dict(row, mean_loss=float(row["mean_loss"])) for row in rows]
            for row in candidate_rows:
                if row["scenario"] == "recurring" and row["policy"] == "drift":
                    row["mean_loss"] = "0.39"
                elif row["scenario"] == "recurring" and row["policy"] == "static":
                    row["mean_loss"] = "0.40"
            self.write_matrix(candidate, candidate_rows)
            history_rows = [dict(row) for row in candidate_rows if row["policy"] == "drift"]
            self.write_matrix(history, history_rows)
            result = assess_deployment(baseline, candidate, history, seeds=seeds)
            self.assertTrue(result["candidate_passed"])
            self.assertTrue(result["history_reuse_passed"])

            for row in candidate_rows:
                if row["task"] == "regression" and row["scenario"] == "stable" and row["policy"] == "drift":
                    row["mean_loss"] = "0.511"
            self.write_matrix(candidate, candidate_rows)
            result = assess_deployment(baseline, candidate, history, seeds=seeds)
            self.assertFalse(result["candidate_passed"])
            self.assertIn("regression_tolerance_exceeded", [failure["reason"] for failure in result["failures"]])

    def test_missing_seed_or_task_fails_closed(self):
        self.assertIsNotNone(assess_deployment, "Paired independent deployment assessment is missing")
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            baseline, candidate = root / "baseline.csv", root / "candidate.csv"
            rows = [{"task": "classification", "scenario": "stable", "seed": 101,
                     "policy": policy, "mean_loss": 0.2} for policy in ("static", "periodic", "drift")]
            self.write_matrix(baseline, rows)
            self.write_matrix(candidate, rows)
            result = assess_deployment(baseline, candidate, seeds=(101, 103))
            self.assertFalse(result["candidate_passed"])
            self.assertEqual(result["failure_count"], 2 * (12 * 2 * 3 - 3))


if __name__ == "__main__":
    unittest.main()
