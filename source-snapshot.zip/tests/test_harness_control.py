"""Guard ordering, action authority and prospective gates use real model state."""

import json
import tempfile
import unittest
from contextlib import contextmanager
from pathlib import Path

import numpy as np

from ite.config import ExperimentConfig
from ite.controller import AdaptationController
from ite.data import PublicBatch, ReleasedLabels
from ite.harness import LLMReply
from ite.models import RidgeModel
from ite.tracking import JsonlLogger
from ite.training import TrainingResult


class FixedClient:
    def __init__(self, action):
        self.action, self.observations = action, []

    def get_decision(self, observation):
        self.observations.append(observation)
        return LLMReply(json.dumps({"action": self.action, "reason": "test decision"}), 8)


class InlineTrainer:
    """Only the process boundary is replaced; fitting and gates remain real."""
    def __init__(self):
        self.calls = []

    def fit(self, task, alpha, x, y, timeout_seconds, model_family="ridge", sample_weight=None):
        self.calls.append((len(y), alpha))
        model = RidgeModel(task, alpha, model_family).fit(x, y, sample_weight=sample_weight)
        return TrainingResult("ok", model, .001)

    def close(self):
        pass


class TreeInlineTrainer(InlineTrainer):
    """Record Tree candidate calls while keeping the controller test local."""

    def fit(self, task, alpha, x, y, timeout_seconds, model_family="ridge", sample_weight=None, **options):
        self.calls.append((len(y), alpha, options))
        model = RidgeModel(task, alpha or 1., model_family).fit(x, y, sample_weight=sample_weight)
        return TrainingResult("ok", model, .001)


class HarnessControlTests(unittest.TestCase):
    def config(self, **overrides):
        return ExperimentConfig.from_dict({"harness_enabled": True, "deployment_validation": "future",
            "training_preflight": True, "candidate_feasibility": True, "max_tokens": 1000,
            "n_features": 3, "history_windows": [96, 192, 384], **overrides})

    @contextmanager
    def controller(self, **overrides):
        rng = np.random.default_rng(184)
        x = rng.normal(size=(300, 3))
        y = 2 * x[:, 0] - x[:, 1]
        config = self.config(task="regression", **overrides)
        initial = RidgeModel("regression").fit(x, -y)
        trainer = InlineTrainer()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with JsonlLogger(root / "events.jsonl", "harness-test") as logger:
                controller = AdaptationController(config, "drift", initial, .01, 1, logger, trainer, root)
                controller.history_x, controller.history_y = x.copy(), y.copy()
                controller.history_steps = np.repeat(np.arange(10), 30)
                yield controller, trainer, root, x, y

    def events(self, root):
        return [json.loads(line) for line in (root / "events.jsonl").read_text().splitlines()]

    def observe(self, controller, step, released=None, predictions=None):
        x = np.ones((2, 3))
        controller.observe(PublicBatch(step, np.array([10000, 10001]), x), released,
                           {} if predictions is None else predictions)

    def test_new_mode_requires_independent_gate_preflight_and_no_scenario_routing(self):
        config = self.config()
        self.assertEqual(ExperimentConfig.from_dict(json.loads(json.dumps(config.to_dict()))), config)
        for options in ({"deployment_validation": "legacy"}, {"training_preflight": False},
                        {"candidate_feasibility": False}, {"decision_backend": "mock"},
                        {"selection_split": "task_specific"}, {"harness_enabled": 1},
                        {"harness_mock_mode": "bad"}, {"strategy_adaptation": True}):
            with self.subTest(options=options), self.assertRaises(ValueError):
                self.config(**options)
        self.assertFalse(ExperimentConfig().harness_enabled)

    def test_small_large_only_use_configured_windows_and_alphas(self):
        for action, expected in (("RETRAIN_SMALL", [(96, .1), (96, 10.)]),
                                 ("RETRAIN_LARGE", [(96, .1), (96, 10.), (192, .1),
                                                    (192, 10.), (240, .1), (240, 10.)])):
            with self.subTest(action=action), self.controller() as (controller, trainer, root, _, _):
                controller.llm_client = FixedClient(action)
                controller.monitor.observe_losses([1.] * 96)
                self.observe(controller, 12)
                self.assertEqual(trainer.calls, expected)
                self.assertEqual(controller.budget.tokens, 8)
                self.assertEqual(controller.budget.training_attempts, 1)
                self.assertIsNotNone(controller.pending)
                self.assertEqual(controller.gate.version, 0)
                self.assertFalse(any(e["event"] == "decision_advice" for e in self.events(root)))

    def test_tree_small_and_large_actions_route_to_distinct_window_sets(self):
        for action, expected_windows in (("RETRAIN_SMALL", (96,)),
                                         ("RETRAIN_LARGE", (96, 192, 240))):
            with self.subTest(action=action):
                rng = np.random.default_rng(184)
                x = rng.normal(size=(300, 3))
                y = 2 * x[:, 0] - x[:, 1]
                config = self.config(task="regression", model_type="tree",
                                     history_windows=[96, 192, 384])
                initial = RidgeModel("regression").fit(x, -y)
                trainer = TreeInlineTrainer()
                with tempfile.TemporaryDirectory() as directory:
                    root = Path(directory)
                    with JsonlLogger(root / "events.jsonl", "tree-action") as logger:
                        controller = AdaptationController(config, "drift", initial, .01, 1,
                                                          logger, trainer, root)
                        controller.history_x, controller.history_y = x.copy(), y.copy()
                        controller.history_steps = np.repeat(np.arange(10), 30)
                        controller.llm_client = FixedClient(action)
                        controller.monitor.observe_losses([1.] * 96)
                        self.observe(controller, 12)
                self.assertEqual([call[0] for call in trainer.calls], list(expected_windows))
                self.assertTrue(all(call[2]["model_type"] == "tree" for call in trainer.calls))

    def test_guard_trip_during_fit_stops_following_candidates(self):
        with self.controller() as (controller, trainer, root, _, _):
            controller.llm_client = FixedClient("RETRAIN_LARGE")
            original_fit = trainer.fit
            def fit_and_trip(*args, **kwargs):
                result = original_fit(*args, **kwargs)
                controller.budget_guard.trip(12, "client_timeout")
                return result
            trainer.fit = fit_and_trip
            controller.monitor.observe_losses([1.] * 96)
            self.observe(controller, 12)
            self.assertEqual(len(trainer.calls), 1)
            self.assertIsNone(controller.pending)
            self.assertEqual(controller.gate.version, 0)

    def test_do_nothing_does_not_consume_training_or_move_cooldown(self):
        with self.controller() as (controller, trainer, _, _, _):
            controller.llm_client = FixedClient("DO_NOTHING")
            controller.monitor.observe_losses([1.] * 96)
            before = controller.last_experiment
            self.observe(controller, 12)
            self.observe(controller, 13)
            self.assertEqual((trainer.calls, controller.budget.training_attempts), ([], 0))
            self.assertEqual(controller.last_experiment, before)
            self.assertEqual(controller.budget.tokens, 8, "Unchanged evidence must not repeatedly call the client")

    def test_preflight_remains_outer_and_does_not_charge_training_on_failure(self):
        with self.controller() as (controller, trainer, root, _, _):
            controller.llm_client = FixedClient("RETRAIN_SMALL")
            controller.history_steps[:] = 9  # Whole-batch split leaves no training labels.
            controller.monitor.observe_losses([1.] * 96)
            before = controller.last_experiment
            self.observe(controller, 12)
            self.assertEqual((trainer.calls, controller.budget.experiments), ([], 0))
            self.assertEqual(controller.last_experiment, before)
            self.assertTrue(any(e["event"] == "training_preflight_skipped" for e in self.events(root)))

    def test_observation_uses_saved_predictions_delayed_sources_and_five_batches(self):
        with self.controller() as (controller, _, _, _, _):
            for source in range(7):
                x = np.zeros((2, 3))
                controller.predict(x)
                release = ReleasedLabels(np.array([source * 2, source * 2 + 1]), x,
                                         np.ones(2), np.full(2, source))
                self.observe(controller, source + 2, release,
                             {source * 2: 0., source * 2 + 1: 0.})
            value = controller.harness_observation(False)
            self.assertEqual(value["loss_trend"], [
                {"source_step": source, "loss": 1., "labeled_samples": 2} for source in range(2, 7)])
            self.assertEqual(value["model_age_batches"], 7)
            self.assertEqual(set(value), {"loss_trend", "drift_alarm", "remaining_label_budget",
                                          "remaining_token_budget", "model_age_batches"})
            controller.gate.deployed_at = 8
            controller._save_deployment()
            self.assertEqual(controller.harness_observation(False)["loss_trend"], [])
            self.assertEqual(controller.harness_observation(False)["model_age_batches"], 0)
            controller.predict(np.zeros((1, 3)))
            self.assertEqual(controller.harness_observation(False)["model_age_batches"], 1)
            old = ReleasedLabels(np.array([99]), np.zeros((1, 3)), np.ones(1), np.array([7]))
            self.observe(controller, 10, old, {99: 0.})
            self.assertEqual(controller.harness_observation(False)["loss_trend"], [])

    def test_rollback_request_freezes_previous_snapshot_and_uses_new_future_labels(self):
        with self.controller() as (controller, trainer, root, x, y):
            original = controller.gate.model
            previous = RidgeModel("regression").fit(x, y)
            controller.gate.previous = previous
            controller.llm_client = FixedClient("ROLLBACK")
            controller.monitor.observe_losses([1.] * 96)
            self.observe(controller, 12)
            self.assertIs(controller.gate.model, original)
            self.assertIs(controller.pending["model"], previous)
            self.assertEqual(trainer.calls, [])
            for source, expected_version in ((12, 0), (13, 1)):
                release = ReleasedLabels(np.arange(48), x[:48], y[:48], np.full(48, source))
                controller._validate_pending(release, source + 2)
                self.assertEqual(controller.gate.version, expected_version)
            self.assertIs(controller.gate.model, previous)
            self.assertEqual(controller.gate.rollbacks, 1)
            deploy = next(e for e in self.events(root) if e["event"] == "deploy")
            self.assertGreater(deploy["gate_min_source_step"], deploy["frozen_at"])

    def test_rollback_without_previous_snapshot_is_rejected_without_training(self):
        with self.controller() as (controller, trainer, root, _, _):
            controller.llm_client = FixedClient("ROLLBACK")
            controller.monitor.observe_losses([1.] * 96)
            self.observe(controller, 12)
            self.assertIsNone(controller.pending)
            self.assertEqual(trainer.calls, [])
            self.assertTrue(any(e["event"] == "harness_action_rejected" for e in self.events(root)))

    def test_selection_evaluation_does_not_age_a_model_or_create_a_prediction_batch(self):
        with self.controller(min_gain=1000) as (controller, _, _, x, _):
            controller.predict(x[:2])
            self.assertEqual(controller.harness_observation(False)["model_age_batches"], 1)
            controller._experiment(12, {"diagnosis": "observed_prediction_degradation"})
            self.assertIsNone(controller.pending)
            self.assertEqual(controller.harness_observation(False)["model_age_batches"], 1)

    def test_pending_candidate_blocks_calls_and_bad_future_performance_is_rejected(self):
        with self.controller() as (controller, _, root, x, y):
            client = FixedClient("RETRAIN_SMALL")
            controller.llm_client = client
            controller.monitor.observe_losses([1.] * 96)
            self.observe(controller, 12)
            self.assertIsNotNone(controller.pending)
            self.observe(controller, 13)
            self.assertEqual(len(client.observations), 1)
            release = ReleasedLabels(np.arange(48), x[:48], -y[:48], np.full(48, 13))
            controller._validate_pending(release, 15)
            self.assertIsNone(controller.pending)
            self.assertEqual(controller.gate.version, 0)
            self.assertTrue(any(e["event"] == "experiment_rejected" and
                                e.get("reason") == "independent_future_labels" for e in self.events(root)))

    def test_label_or_token_trip_cancels_pending_before_same_batch_acceptance(self):
        for kind in ("labels", "tokens"):
            with self.subTest(kind=kind), self.controller() as (controller, trainer, root, x, y):
                incumbent = controller.gate.model
                controller._freeze(RidgeModel("regression").fit(x, y), 10,
                                   {"candidate_kind": "trained"})
                if kind == "labels":
                    controller.budget.record_labels(controller.config.max_labels)
                else:
                    controller.budget.record_tokens(800)
                release = ReleasedLabels(np.arange(48), x[:48], y[:48], np.full(48, 11))
                self.observe(controller, 13, release, dict(zip(range(48), incumbent.predict(x[:48]))))
                controller._validate_pending(release, 14)
                controller._experiment(14, {"diagnosis": "observed_prediction_degradation"})
                self.assertIs(controller.gate.model, incumbent)
                self.assertIsNone(controller.pending)
                self.assertEqual(controller.gate.version, 0)
                self.assertEqual(trainer.calls, [])
                self.assertFalse(controller.allow_label_request(14))
                self.assertFalse(any(e["event"] == "deploy" for e in self.events(root)))


if __name__ == "__main__":
    unittest.main()
