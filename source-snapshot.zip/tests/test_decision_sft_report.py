import json
import tempfile
import unittest
from pathlib import Path

from scripts.report_decision_sft import (action_metrics, compare_cpu_outcomes, cpu_guards_pass,
                                         load_predictions, log_swanlab)


def prediction(index, action, probabilities, profile="B"):
    return {"index": index, "input_sha256": f"id-{index}", "profile": profile,
            "action": action, "actions": ["DO_NOTHING", "RETRAIN_LARGE", "RETRAIN_HEAD_ONLY"],
            "logprobs": [0.0, -1.0, -2.0], "probabilities": probabilities}


def outcome(action, rmse, mae, overestimate_rate=0.0, mean_overestimate=0.0):
    return {"action": action, "qualified": action != "DO_NOTHING",
            "evidence": {"post_deployment_static": {"samples": 2, "rmse": 10.0, "mae": 8.0,
                                                       "overestimate_rate": 0.0, "mean_overestimate": 0.0,
                                                       "unit": "minutes"},
                         "post_deployment_active": {"samples": 2, "rmse": rmse, "mae": mae,
                                                      "overestimate_rate": overestimate_rate,
                                                      "mean_overestimate": mean_overestimate,
                                                      "unit": "minutes"},
                         "whole_static": {"samples": 4, "rmse": 10.0, "mae": 8.0,
                                          "overestimate_rate": 0.0, "mean_overestimate": 0.0,
                                          "unit": "minutes"},
                         "whole_active": {"samples": 4, "rmse": rmse, "mae": mae,
                                          "overestimate_rate": overestimate_rate,
                                          "mean_overestimate": mean_overestimate,
                                          "unit": "minutes"}}}


class DecisionSFTReportTests(unittest.TestCase):
    def test_action_metrics_reports_full_confusion_recall_macro_nll_ece_and_brier(self):
        labels = ["DO_NOTHING", "RETRAIN_LARGE", "RETRAIN_HEAD_ONLY"]
        predictions = [
            {"action": labels[0], "probabilities": [0.8, 0.1, 0.1]},
            {"action": labels[0], "probabilities": [0.8, 0.1, 0.1]},
            {"action": labels[2], "probabilities": [0.1, 0.2, 0.7]},
        ]
        metrics = action_metrics(labels, predictions)
        self.assertEqual(metrics["accuracy"], 2 / 3)
        self.assertEqual(metrics["confusion_matrix"], [[1, 0, 0], [1, 0, 0], [0, 0, 1]])
        self.assertEqual(metrics["recall"], {labels[0]: 1.0, labels[1]: 0.0, labels[2]: 1.0})
        self.assertAlmostEqual(metrics["macro_f1"], 5 / 9)
        self.assertGreater(metrics["nll"], 0.0)
        self.assertGreaterEqual(metrics["ece_10_bin"], 0.0)
        self.assertGreater(metrics["brier"], 0.0)

    def test_constant_no_baseline_is_measured_against_all_three_classes(self):
        labels = ["DO_NOTHING", "DO_NOTHING", "RETRAIN_LARGE"]
        predictions = [
            {"action": "DO_NOTHING", "probabilities": [1.0, 0.0, 0.0]},
            {"action": "DO_NOTHING", "probabilities": [1.0, 0.0, 0.0]},
            {"action": "DO_NOTHING", "probabilities": [1.0, 0.0, 0.0]},
        ]
        result = action_metrics(labels, predictions)
        self.assertEqual(result["accuracy"], 2 / 3)
        self.assertEqual(result["class_support"]["RETRAIN_HEAD_ONLY"], 0)
        self.assertIsNone(result["recall"]["RETRAIN_HEAD_ONLY"])
        self.assertTrue(result["missing_classes"])
        self.assertTrue(0.0 <= result["nll"] < float("inf"))

    def test_prediction_file_checks_hash_action_probability_and_counts(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "predictions.jsonl"
            path.write_text(json.dumps(prediction(0, "DO_NOTHING", [0.8, 0.1, 0.1])) + "\n", encoding="utf-8")
            result = load_predictions(path, ["id-0"])
            self.assertEqual(result[0]["input_sha256"], "id-0")
            invalid = prediction(1, "DO_NOTHING", [0.8, 0.1, 0.1])
            invalid["probabilities"] = [0.8, 0.1, float("nan")]
            path.write_text(json.dumps(invalid) + "\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "probabilities"):
                load_predictions(path, ["id-1"])

    def test_cpu_outcomes_follow_predicted_action_and_keep_c_safety_separate(self):
        rows = [{"input_sha256": "id-0", "profile": "B", "target_action": "DO_NOTHING",
                 "evidence": {"outcomes": [outcome("DO_NOTHING", 10.0, 8.0),
                                             outcome("RETRAIN_LARGE", 8.0, 7.0),
                                             outcome("RETRAIN_HEAD_ONLY", 9.0, 7.5)]}}]
        selected = [prediction(0, "RETRAIN_LARGE", [0.1, 0.8, 0.1])]
        report = compare_cpu_outcomes(rows, selected)
        self.assertEqual(report["packages"]["B"]["selected_policy"]["rmse"], 8.0)
        self.assertEqual(report["packages"]["B"]["static_fallback"]["rmse"], 10.0)
        self.assertEqual(report["packages"]["B"]["paired_decisions"], 1)
        self.assertEqual(report["packages"]["B"]["static_fallback_decisions"], 0)

    def test_c_safety_violation_is_not_hidden_by_primary_rmse_gain(self):
        rows = [{"input_sha256": "id-0", "profile": "C", "target_action": "DO_NOTHING",
                 "evidence": {"outcomes": [
                     outcome("DO_NOTHING", 10.0, 8.0, 0.0, 0.0),
                     outcome("RETRAIN_LARGE", 8.0, 7.0, 0.25, 2.0),
                     outcome("RETRAIN_HEAD_ONLY", 9.0, 7.5, 0.1, 1.0)]}}]
        selected = [prediction(0, "RETRAIN_LARGE", [0.1, 0.8, 0.1], profile="C")]
        report = compare_cpu_outcomes(rows, selected)
        package = report["packages"]["C"]["selected_policy"]
        self.assertLess(package["rmse"], package["static_rmse"])
        self.assertFalse(package["safety_pass"])
        self.assertEqual(package["overestimate_rate"], 0.25)

    def test_overall_cpu_safety_cannot_hide_a_single_scenario_regression(self):
        package = {profile: {"selected_policy": {"safety_pass": True}} for profile in "ABC"}
        result = {
            "student": {"packages": package, "by_scenario": {
                "stable": {"packages": {p: {"selected_policy": {"safety_pass": True}} for p in "ABC"}},
                "abrupt": {"packages": {p: {"selected_policy": {"safety_pass": p != "C"}} for p in "ABC"}},
                "gradual": {"packages": {p: {"selected_policy": {"safety_pass": True}} for p in "ABC"}},
            }}}
        self.assertFalse(cpu_guards_pass(result))

    def test_swanlab_tracks_fixed_config_and_reports_student_against_no_baseline(self):
        class FakeRun:
            id = "run-id"
            def __init__(self):
                self.config, self.logs = None, []
            def log(self, values, step):
                self.logs.append((values, step))

        class FakeSwanLab:
            run = FakeRun()
            saved = []
            @classmethod
            def init(cls, **kwargs):
                cls.config = kwargs
                return cls.run
            @classmethod
            def finish(cls):
                cls.finished = True
            @classmethod
            def save(cls, path, **kwargs):
                cls.saved.append(str(path))

        result = {"action_metrics": {"student": {"all": {"accuracy": 0.7, "macro_f1": 0.6,
                                                               "nll": 0.8, "ece_10_bin": 0.1,
                                                               "brier": 0.3}},
                                      "constant_no": {"all": {"accuracy": 0.8, "macro_f1": 0.4}}},
                  "imitation_pass": True, "cpu_guards_pass": False}
        logged = log_swanlab(result, run_name="test", mode="local", swanlab_module=FakeSwanLab)
        self.assertEqual(logged["run_id"], "run-id")
        self.assertEqual(FakeSwanLab.config["config"]["budget_limit_cny"], 10.0)
        self.assertEqual(FakeSwanLab.run.logs[0][0]["eval/macro_f1"], 0.6)
        self.assertEqual(FakeSwanLab.run.logs[0][0]["baseline/constant_no_accuracy"], 0.8)
        self.assertEqual(FakeSwanLab.run.logs[0][0]["cpu/guards_pass"], 0)
        self.assertTrue(FakeSwanLab.finished)

    def test_tracking_includes_base_comparison_cpu_values_and_exact_artifacts(self):
        class Tracking:
            logs, saved = [], []
            id = "complete-run"
            @classmethod
            def init(cls, **kwargs):
                return cls
            @classmethod
            def log(cls, values, step):
                cls.logs.append(values)
            @classmethod
            def save(cls, path, **kwargs):
                cls.saved.append(Path(path).name)
            @classmethod
            def finish(cls):
                pass
        metrics = {"accuracy": 0.8, "macro_f1": 0.4, "nll": 0.7, "ece_10_bin": 0.1, "brier": 0.2}
        result = {"action_metrics": {name: {"all": metrics, "by_package": {"B": metrics}}
                                     for name in ("base", "student", "constant_no")},
                  "cpu_outcomes": {"student": {"packages": {"B": {"selected_policy": {"rmse": 8.0}}}}},
                  "imitation_pass": False, "cpu_guards_pass": True}
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "request-ledger.json").write_text('{"requests":{}}', encoding="utf-8")
            (root / "train-metrics.jsonl").write_text(json.dumps({"loss": 0.4, "epoch": 1,
                "supervised_tokens": 16, "input_tokens": 4000, "global_step": 1})+'\n', encoding="utf-8")
            (root / "report.json").write_text(json.dumps(result), encoding="utf-8")
            log_swanlab(result, run_name="complete", mode="offline", swanlab_module=Tracking,
                        output=root)
        values = {key: value for row in Tracking.logs for key, value in row.items()}
        self.assertEqual(values["baseline/base_macro_f1"], 0.4)
        self.assertEqual(values["cpu/student/B/rmse"], 8.0)
        self.assertIn("report.json", Tracking.saved)
        self.assertIn("train-metrics.jsonl", Tracking.saved)

    def test_tracking_does_not_turn_unmeasured_eval_into_zero(self):
        class Tracking:
            logs = []
            id = "failed-run"
            @classmethod
            def init(cls, **kwargs):
                return cls
            @classmethod
            def log(cls, values, step):
                cls.logs.append(values)
            @classmethod
            def finish(cls):
                pass
        log_swanlab({"execution_status": "failed"}, run_name="failure", mode="local",
                    swanlab_module=Tracking)
        self.assertFalse(any("eval/accuracy" in row for row in Tracking.logs))


if __name__ == "__main__":
    unittest.main()
