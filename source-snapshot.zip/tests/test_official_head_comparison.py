"""Frozen three-arm comparisons reject unpaired evidence and unsafe RMSE wins."""

import importlib
import tempfile
import unittest
from pathlib import Path

import numpy as np


class OfficialHeadComparisonTests(unittest.TestCase):
    def module(self):
        try:
            return importlib.import_module("scripts.run_official_head_comparison")
        except ImportError as error:
            self.fail(f"Official head comparison runner missing: {error}")

    def test_plan_is_eighteen_flows_and_both_partitions_decide_at_step_seven(self):
        cases = self.module().case_plan()
        self.assertEqual(len(cases), 18)
        self.assertEqual(len({(c["scenario"], c["split"], c["arm"]) for c in cases}), 18)
        self.assertEqual({c["arm"] for c in cases}, {"static", "head_only", "head_calibrated"})
        self.assertEqual({tuple(c["decision_steps"]) for c in cases}, {(7,)})
        for case in cases:
            action = self.module().fixed_decision(case["arm"])
            self.assertEqual(action({})["action"], {"static": "DO_NOTHING", "head_only": "RETRAIN_HEAD_ONLY",
                "head_calibrated": "CALIBRATE_DOWN"}[case["arm"]])
            self.assertEqual(action({})["source"], "fixed_comparison")

        self.assertEqual(self.module().loss_policy("head_only"), "squared")
        self.assertEqual(self.module().loss_policy("head_calibrated"), "squared")
        with self.assertRaises(ValueError):
            self.module().loss_policy("unexpected")

    def test_lower_rmse_with_new_overestimation_fails_safety(self):
        m = self.module()
        y = np.array([2., 2.])
        result = m.summarize_paired({arm: {"targets": y, "source_ids": np.array(["b", "a"]),
            "static": np.array([0., 0.]), "active": p} for arm, p in (
                ("static", np.array([0., 0.])), ("head_only", np.array([2.5, 2.5])),
            ("head_calibrated", np.array([1., 1.])))}, "abrupt")
        self.assertEqual(result["metrics"]["head_calibrated"]["rmse"], 1.)
        self.assertEqual(result["metrics"]["head_only"]["overestimate_rate"], 1.)
        self.assertFalse(result["passes"]["head_only"])
        self.assertTrue(result["passes"]["head_calibrated"])
        # No update and equal predictions are allowed only on stable controls.
        unchanged = {arm: {"targets": y, "source_ids": np.array(["a", "b"]),
                     "static": np.zeros(2), "active": np.zeros(2)} for arm in (
                         "static", "head_only", "head_calibrated")}
        self.assertTrue(m.summarize_paired(unchanged, "stable")["passes"]["head_calibrated"])
        self.assertFalse(m.summarize_paired(unchanged, "gradual")["passes"]["head_calibrated"])

    def test_pairing_rejects_changed_ids_labels_or_static_reference(self):
        m = self.module()
        base = {"targets": np.array([2., 2.]), "source_ids": np.array(["a", "b"]),
                "static": np.zeros(2), "active": np.zeros(2)}
        for key, value in (("source_ids", np.array(["a", "c"])), ("source_ids", np.array(["a", "a"])),
                           ("targets", np.array([2., 3.])), ("static", np.ones(2))):
            with self.subTest(key=key), self.assertRaises(ValueError):
                m.summarize_paired({"static": base, "head_only": base,
                    "head_calibrated": {**base, key: value}}, "stable")

    def test_calibrated_arm_must_meet_the_registered_overestimate_ceiling(self):
        m = self.module()
        y = np.full(100, 2.)
        static = np.zeros(100)
        head = np.zeros(100)
        calibrated = np.ones(100) * 1.5
        static[:20] = 3.
        head[:30] = 3.
        calibrated[:17] = 3.
        rows = {arm: {"targets": y, "source_ids": np.arange(100), "static": static, "active": pred}
                for arm, pred in (("static", static), ("head_only", head),
                                  ("head_calibrated", calibrated))}
        result = m.summarize_paired(rows, "abrupt")
        self.assertLess(result["metrics"]["head_calibrated"]["rmse"], result["metrics"]["static"]["rmse"])
        self.assertLess(result["metrics"]["head_calibrated"]["overestimate_rate"],
                        result["metrics"]["static"]["overestimate_rate"])
        self.assertFalse(result["passes"]["head_calibrated"])

    def test_existing_output_cannot_be_overwritten_before_any_model_is_loaded(self):
        m = self.module()
        with tempfile.TemporaryDirectory() as tmp, self.assertRaises(FileExistsError):
            m.run_comparison(Path(tmp), "missing-runtime")
