"""FD001 contracts: engine isolation and literal run-to-failure RUL."""

import csv
import importlib
import functools
import http.server
import json
import subprocess
import sys
import tempfile
import threading
import unittest
import zipfile
from pathlib import Path

import numpy as np
import pyarrow.parquet as pq


try:
    cmapss = importlib.import_module("scripts.data_prep.cmapss")
except ModuleNotFoundError:
    cmapss = None


def source_line(unit, cycle, features=None):
    values = [str(unit), str(cycle)]
    values += [str(value) for value in (features if features is not None else range(1, 25))]
    return " ".join(values)


class CmapssPreparationTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(cmapss, "The approved C-MAPSS preparation module is missing")
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.source = self.root / "train_FD001.txt"
        self.output = self.root / "prepared"

    def write(self, lines=None, units=range(1, 7), cycles=3):
        if lines is None:
            lines = [source_line(unit, cycle)
                     for unit in units for cycle in range(1, cycles + 1)]
        self.source.write_text("\n".join(lines) + "\n", encoding="ascii")

    def prepare(self, **options):
        arguments = {"train_units": [1, 2], "val_units": [3, 4],
                     "stream_units": [5, 6], "batch_size": 4}
        arguments.update(options)
        return cmapss.prepare_cmapss(self.source, self.output, **arguments)

    def read_split(self, name):
        if name == "stream":
            return pq.read_table(self.output / "test_stream.parquet").to_pylist()
        with (self.output / (name + ".csv")).open(newline="", encoding="utf-8") as stream:
            return list(csv.DictReader(stream))

    def test_rul_is_literal_remaining_cycles_and_resets_only_at_engine_boundary(self):
        self.write()
        self.prepare()
        stream = self.read_split("stream")
        self.assertEqual([float(row["target"]) for row in stream], [2, 1, 0, 2, 1, 0])
        self.assertEqual([(int(row["unit_id"]), int(row["cycle"])) for row in stream],
                         [(5, 1), (5, 2), (5, 3), (6, 1), (6, 2), (6, 3)])

    def test_rul_cap_is_applied_before_export_without_scaling_target(self):
        self.write(units=range(1, 4), cycles=130)
        self.prepare(train_units=[1], val_units=[2], stream_units=[3])
        stream = self.read_split("stream")
        self.assertEqual([float(stream[index]["target"]) for index in (0, 3, 4, 5, 128, 129)],
                         [125, 125, 125, 124, 1, 0])

    def test_entities_are_whole_disjoint_and_ordered_even_when_partition_arguments_are_unsorted(self):
        self.write()
        self.prepare(train_units=[2, 1], val_units=[4, 3], stream_units=[6, 5])
        splits = [self.read_split(name) for name in ("train", "val", "stream")]
        self.assertEqual([{int(row["unit_id"]) for row in rows} for rows in splits],
                         [{1, 2}, {3, 4}, {5, 6}])
        for rows in splits:
            self.assertEqual(len(rows), 6)
            pairs = [(int(row["unit_id"]), int(row["cycle"])) for row in rows]
            self.assertEqual(pairs, sorted(pairs))
        ids = [int(row["sample_id"]) for rows in splits for row in rows]
        self.assertEqual(len(ids), len(set(ids)))

    def test_default_partitions_are_units_1_60_61_80_81_100(self):
        self.write(units=range(1, 101), cycles=4)
        cmapss.prepare_cmapss(self.source, self.output, batch_size=17)
        expected = {"train": set(range(1, 61)), "val": set(range(61, 81)),
                    "stream": set(range(81, 101))}
        for split, units in expected.items():
            rows = self.read_split(split)
            self.assertEqual({int(row["unit_id"]) for row in rows}, units)
            self.assertEqual(len(rows), len(units) * 4)
        batch_ids = [int(row["batch_id"]) for row in self.read_split("stream")]
        self.assertEqual(sorted(set(batch_ids)), [0, 1, 2, 3, 4])

    def test_predictors_are_exactly_the_three_settings_and_twenty_one_sensors(self):
        self.write()
        manifest = self.prepare()
        features = manifest["column_mapping"]["features"]
        self.assertEqual(features, ["setting_1", "setting_2", "setting_3"] +
                         [f"sensor_{number}" for number in range(1, 22)])
        rows = self.read_split("stream")
        self.assertEqual([float(rows[0][feature]) for feature in features], list(range(1, 25)))
        self.assertTrue(set(features).isdisjoint({"unit_id", "cycle", "target", "sample_id", "batch_id"}))

    def test_manifest_records_source_hash_target_formula_and_reserved_test_boundary(self):
        self.write()
        manifest = self.prepare()
        metadata = manifest["metadata"]
        self.assertEqual(metadata["source"]["sha256"],
                         __import__("hashlib").sha256(self.source.read_bytes()).hexdigest())
        self.assertEqual(metadata["target"]["units"], "cycles")
        self.assertEqual(metadata["target_unit"], "cycles")
        self.assertEqual(metadata["target"]["rul_cap"], 125.0)
        self.assertEqual(metadata["split_units"],
                         {"train": [1, 2], "val": [3, 4], "stream": [5, 6]})
        self.assertTrue(metadata["published_censored_test_reserved"])
        self.assertEqual(json.loads((self.output / "manifest.json").read_text()), manifest)

    def test_provider_round_trip_uses_only_features_and_preserves_stream_batches(self):
        from ite.providers import ColumnMapping
        from scripts.data_prep.provider import PreparedDataProvider

        self.write()
        manifest = self.prepare()
        provider = PreparedDataProvider(
            self.output / "test_stream.parquet", ColumnMapping(**manifest["column_mapping"]),
            initial_train_path=self.output / "train.csv",
            initial_validation_path=self.output / "val.csv")
        initial = provider.initial_data()
        self.assertEqual(initial.train_x.shape, (6, 24))
        self.assertEqual(initial.validation_x.shape, (6, 24))
        self.assertEqual(initial.train_y.tolist(), [2, 1, 0, 2, 1, 0])
        seen = []
        for batch in provider.iter_batches():
            self.assertEqual(batch.features.shape[1], 24)
            seen.append(len(batch.sample_ids))
            provider.commit_predictions(batch.step, batch.sample_ids, np.zeros(len(batch.sample_ids)))
        self.assertEqual(seen, [4, 2])

    def test_source_receipt_is_bound_to_raw_bytes_and_carried_into_manifest(self):
        self.write()
        digest = __import__("hashlib").sha256(self.source.read_bytes()).hexdigest()
        receipt = {"url": "https://example.test/pinned/train_FD001.txt", "sha256": digest,
                   "source_type": "attributable mirror"}
        self.source.with_suffix(".txt.source.json").write_text(json.dumps(receipt), encoding="utf-8")
        manifest = self.prepare()
        self.assertEqual(manifest["metadata"].get("source_provenance"), receipt)

    def test_source_receipt_with_wrong_raw_hash_is_rejected_before_export(self):
        self.write()
        self.source.with_suffix(".txt.source.json").write_text(
            json.dumps({"url": "https://example.test/pinned/train_FD001.txt", "sha256": "0" * 64}),
            encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "receipt|SHA|hash"):
            self.prepare()
        self.assertFalse(self.output.exists())

    def test_rejects_censored_test_and_endpoint_rul_files(self):
        self.write()
        for filename in ("test_FD001.txt", "RUL_FD001.txt"):
            with self.subTest(filename=filename):
                path = self.root / filename
                path.write_bytes(self.source.read_bytes())
                with self.assertRaisesRegex(ValueError, "run-to-failure|train_FD001"):
                    cmapss.prepare_cmapss(path, self.output, train_units=[1, 2],
                                          val_units=[3, 4], stream_units=[5, 6])
        self.assertFalse(self.output.exists())

    def test_rejects_wrong_subset_and_invalid_cap(self):
        self.write()
        for arguments in ({"subset": "FD002"}, {"rul_cap": -1}, {"rul_cap": 0},
                          {"rul_cap": float("nan")}, {"rul_cap": float("inf")}):
            with self.subTest(arguments=arguments):
                with self.assertRaises(ValueError):
                    self.prepare(**arguments)
        self.assertFalse(self.output.exists())

    def test_rejects_wrong_column_counts_and_nonnumeric_features(self):
        valid = [source_line(unit, cycle) for unit in range(1, 7) for cycle in range(1, 4)]
        for malformed in (" ".join(valid[0].split()[:-1]), valid[0] + " 99",
                          valid[0].replace(" 24", " invalid")):
            with self.subTest(malformed=malformed):
                self.write([malformed] + valid[1:])
                with self.assertRaisesRegex(ValueError, "column|numeric"):
                    self.prepare()
        self.assertFalse(self.output.exists())

    def test_rejects_nonpositive_noninteger_or_nonfinite_unit_and_cycle(self):
        valid = [source_line(unit, cycle) for unit in range(1, 7) for cycle in range(1, 4)]
        for unit, cycle in ((0, 1), (1.5, 1), ("nan", 1), (1, 0), (1, 1.5), (1, "inf"),
                            ("1e0", 1), (1, "1.0"), (1, 2 ** 63)):
            with self.subTest(unit=unit, cycle=cycle):
                self.write([source_line(unit, cycle)] + valid[1:])
                with self.assertRaisesRegex(ValueError, "unit|cycle"):
                    self.prepare()
        self.assertFalse(self.output.exists())

    def test_rejects_duplicate_cycles_gaps_and_truncated_initial_cycle(self):
        valid = [source_line(unit, cycle) for unit in range(1, 7) for cycle in range(1, 4)]
        for first_engine in ([source_line(1, 1), source_line(1, 1), source_line(1, 3)],
                             [source_line(1, 1), source_line(1, 3), source_line(1, 4)],
                             [source_line(1, 2), source_line(1, 3), source_line(1, 4)]):
            with self.subTest(first_engine=first_engine):
                self.write(first_engine + valid[3:])
                with self.assertRaisesRegex(ValueError, "cycle|contiguous"):
                    self.prepare()
        self.assertFalse(self.output.exists())

    def test_rejects_out_of_order_or_interleaved_engines(self):
        valid = [source_line(unit, cycle) for unit in range(1, 7) for cycle in range(1, 4)]
        for lines in ([valid[1], valid[0]] + valid[2:],
                      valid[3:6] + valid[:3] + valid[6:],
                      [valid[0], valid[3], valid[1], valid[2]] + valid[4:]):
            with self.subTest(lines=lines[:5]):
                self.write(lines)
                with self.assertRaisesRegex(ValueError, "order|cycle|contiguous"):
                    self.prepare()
        self.assertFalse(self.output.exists())

    def test_rejects_overlapping_duplicated_unknown_or_unassigned_engine_partitions(self):
        self.write()
        for arguments in ({"train_units": [1, 2, 3]}, {"train_units": [1, 1, 2]},
                          {"stream_units": [5, 6, 7]}, {"stream_units": [5]},
                          {"train_units": []}, {"train_units": [1.5, 2]}):
            with self.subTest(arguments=arguments):
                with self.assertRaises(ValueError):
                    self.prepare(**arguments)
        self.assertFalse(self.output.exists())

    def test_short_source_requires_explicit_partitions_instead_of_implicit_row_splitting(self):
        self.write()
        with self.assertRaisesRegex(ValueError, "unit|partition"):
            cmapss.prepare_cmapss(self.source, self.output)
        self.assertFalse(self.output.exists())

    def test_directory_source_resolves_train_file_and_ignores_reserved_censored_files(self):
        self.write()
        (self.root / "test_FD001.txt").write_text("not used", encoding="ascii")
        cmapss.prepare_cmapss(self.root, self.output, train_units=[1, 2], val_units=[3, 4],
                              stream_units=[5, 6])
        self.assertEqual(len(self.read_split("stream")), 6)

    def test_rejects_empty_or_ambiguous_training_sources(self):
        self.write([])
        with self.assertRaisesRegex(ValueError, "empty|trajectory"):
            self.prepare()
        self.write()
        nested = self.root / "nested"
        nested.mkdir()
        (nested / "train_FD001.txt").write_bytes(self.source.read_bytes())
        with self.assertRaisesRegex(ValueError, "ambiguous|exactly one"):
            cmapss.prepare_cmapss(self.root, self.output, train_units=[1, 2], val_units=[3, 4],
                                  stream_units=[5, 6])
        self.assertFalse(self.output.exists())

    def test_output_is_immutable_and_raw_source_does_not_change(self):
        self.write()
        original = self.source.read_bytes()
        self.prepare()
        before = {path.name: path.read_bytes() for path in self.output.iterdir()}
        with self.assertRaises((ValueError, FileExistsError)):
            self.prepare()
        self.assertEqual({path.name: path.read_bytes() for path in self.output.iterdir()}, before)
        self.assertEqual(self.source.read_bytes(), original)

    def test_module_cli_prepares_local_source_without_network(self):
        self.write()
        process = subprocess.run(
            [sys.executable, "-m", "scripts.data_prep.cmapss", "--source", str(self.source),
             "--output", str(self.output), "--train-units", "1,2", "--val-units", "3,4",
             "--stream-units", "5,6", "--batch-size", "4"], capture_output=True, text=True)
        self.assertEqual(process.returncode, 0, process.stderr)
        self.assertEqual(len(self.read_split("stream")), 6)

    def test_module_cli_downloads_archive_and_prepares_the_named_training_trajectories(self):
        self.write()
        with zipfile.ZipFile(self.root / "CMAPSSData.zip", "x") as archive:
            archive.write(self.source, "CMAPSSData/train_FD001.txt")

        class QuietHandler(http.server.SimpleHTTPRequestHandler):
            def log_message(self, *args):
                pass

        server = http.server.ThreadingHTTPServer(
            ("127.0.0.1", 0), functools.partial(QuietHandler, directory=str(self.root)))
        worker = threading.Thread(target=server.serve_forever, daemon=True)
        worker.start()
        try:
            process = subprocess.run(
                [sys.executable, "-m", "scripts.data_prep.cmapss", "--download", "--url",
                 f"http://127.0.0.1:{server.server_port}/CMAPSSData.zip", "--raw-dir",
                 str(self.root / "downloaded"), "--output", str(self.output), "--train-units",
                 "1,2", "--val-units", "3,4", "--stream-units", "5,6"],
                capture_output=True, text=True)
        finally:
            server.shutdown()
            server.server_close()
            worker.join(timeout=5)
        self.assertEqual(process.returncode, 0, process.stderr)
        self.assertEqual(len(self.read_split("stream")), 6)
        self.assertEqual((self.root / "downloaded" / "CMAPSSData.zip").read_bytes(),
                         (self.root / "CMAPSSData.zip").read_bytes())


if __name__ == "__main__":
    unittest.main()
