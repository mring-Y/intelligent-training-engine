"""Tree-only baseline isolation, native six-class output and conditional prompt."""

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

from ite.harness import MockLLMClient
from ite.models import RidgeModel
from ite.trio_client import SYSTEM_PROMPT, build_messages
from scripts.data_prep.baseline import run_baseline
from scripts.data_prep.common import export_dataset
from tests.tree_worker_test_timeout import tree_initial_timeout


class TreeBaselinePromptTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def regression_package(self):
        rows = [{"x": float(i), "target": 0. if i < 4 else 10.} for i in range(8)]
        return export_dataset(self.root / "package", dataset="hand_step", task="regression",
            features=["x"], train_rows=rows, val_rows=rows,
            stream_rows=[{"x": -100., "target": 0.}, {"x": 100., "target": 10.}],
            metadata={"target_unit": "seconds"}, batch_size=1)

    def test_tree_step_regression_scores_exactly_and_preserves_original_data(self):
        self.regression_package()
        before = (self.root / "package/test_stream.parquet").read_bytes()
        with tree_initial_timeout():
            result = run_baseline(self.root / "package", self.root / "tree", model_type="tree",
                tree_options=dict(max_depth=2, min_samples_leaf=1, max_leaf_nodes=4, random_state=7),
                tree_timeout_seconds=5.)
        self.assertEqual(result["test"]["rmse"], 0.)
        self.assertIsNone(result["alpha"])
        self.assertEqual(result["model_type"], "tree")
        self.assertEqual((self.root / "package/test_stream.parquet").read_bytes(), before)
        with self.assertRaises(FileExistsError):
            run_baseline(self.root / "package", self.root / "tree", model_type="tree")

    def test_tree_multiclass_saves_six_aligned_probability_columns(self):
        rows = [{**{f"x{j}": float(i == j) for j in range(6)}, "target": i + 1}
                for i in range(6) for _ in range(4)]
        export_dataset(self.root / "gas", dataset="uci_gas", task="multiclass",
            features=[f"x{i}" for i in range(6)], train_rows=rows, val_rows=rows,
            stream_rows=rows, metadata={"classes": [1, 2, 3, 4, 5, 6]}, batch_size=13)
        with tree_initial_timeout():
            result = run_baseline(self.root / "gas", self.root / "tree", model_type="tree",
                tree_options=dict(max_depth=6, min_samples_leaf=1, max_leaf_nodes=64, random_state=7),
                tree_timeout_seconds=5.)
        self.assertEqual(result["test"]["accuracy"], 1.)
        with np.load(self.root / "tree/predictions.npz", allow_pickle=False) as saved:
            self.assertEqual(saved["probabilities"].shape, (24, 6))
            np.testing.assert_array_equal(saved["class_labels"], [1, 2, 3, 4, 5, 6])
            np.testing.assert_array_equal(saved["probabilities"].sum(axis=1), np.ones(24))
            np.testing.assert_array_equal(saved["class_labels"][saved["probabilities"].argmax(axis=1)],
                                          saved["predictions"])

    def test_tree_baseline_never_fits_in_the_parent_process(self):
        self.regression_package()
        with tree_initial_timeout(), patch("ite.tree_model.TreeModel.fit",
                                           side_effect=AssertionError("parent fit forbidden")):
            result = run_baseline(self.root / "package", self.root / "tree", model_type="tree",
                tree_timeout_seconds=5.)
        self.assertEqual(result["model_type"], "tree")

    def test_original_ridge_baseline_remains_numerically_unchanged(self):
        self.regression_package()
        result = run_baseline(self.root / "package", self.root / "ridge")
        expected = RidgeModel("regression", 1.).fit(np.arange(8.).reshape(-1, 1), [0.] * 4 + [10.] * 4)
        with np.load(self.root / "ridge/predictions.npz", allow_pickle=False) as saved:
            np.testing.assert_array_equal(saved["predictions"], expected.predict([[-100.], [100.]]))
            self.assertNotIn("probabilities", saved.files)
        self.assertEqual(result["alpha"], 1.)

    def test_prompt_tree_note_is_conditional_and_old_prompt_is_exact(self):
        observation = {"loss_trend": [], "drift_alarm": False, "remaining_label_budget": None,
                       "remaining_token_budget": 1000, "model_age_batches": 0}
        original = build_messages(observation)
        explicit = build_messages(observation, model_type="ridge")
        self.assertEqual(original, explicit)
        self.assertTrue(original[0]["content"].startswith(SYSTEM_PROMPT))
        tree = build_messages(observation, model_type="tree")
        self.assertIn("当前使用的是非线性树模型", tree[0]["content"])
        self.assertIn("RETRAIN_LARGE", tree[0]["content"])
        self.assertEqual(tree[1], original[1])
        self.assertNotIn("当前使用的是非线性树模型", original[0]["content"])
        with self.assertRaises(ValueError):
            build_messages(observation, model_type="unrecognized")

    def test_mock_receives_model_type_but_keeps_fixed_action_and_tokens(self):
        observation = {"loss_trend": [], "drift_alarm": True, "remaining_label_budget": None,
                       "remaining_token_budget": 1000, "model_age_batches": 0}
        ridge = MockLLMClient(model_type="ridge")
        tree = MockLLMClient(model_type="tree")
        self.assertEqual(tree.model_type, "tree")
        self.assertEqual(tree.get_decision(observation), ridge.get_decision(observation))
        self.assertEqual(json.loads(tree.get_decision(observation).raw_json)["action"], "RETRAIN_SMALL")


if __name__ == "__main__":
    unittest.main()
