import importlib.util
import unittest

import numpy as np


class ModelBenchmarkTests(unittest.TestCase):
    def test_nonlinear_data_is_reproducible_and_has_expected_shape(self):
        from scripts.bench_models import make_nonlinear_data

        first = make_nonlinear_data(train_rows=128, test_rows=64, n_features=8, seed=19)
        second = make_nonlinear_data(train_rows=128, test_rows=64, n_features=8, seed=19)
        for left, right in zip(first, second):
            np.testing.assert_array_equal(left, right)
        self.assertEqual(first[0].shape, (128, 8))
        self.assertEqual(first[1].shape, (128,))
        self.assertEqual(first[2].shape, (64, 8))
        self.assertEqual(first[3].shape, (64,))

    @unittest.skipUnless(importlib.util.find_spec("sklearn"), "Optional scikit-learn is not installed")
    def test_benchmark_compares_a_depth_three_tree_on_the_same_nonlinear_split(self):
        from scripts.bench_models import run_benchmark

        result = run_benchmark(train_rows=6000, test_rows=1500, n_features=8,
                               seed=20261108, max_depth=3, max_tree_seconds=3.0)
        self.assertEqual(result["dataset"]["seed"], 20261108)
        self.assertEqual(result["dataset"]["train_rows"], 6000)
        self.assertEqual(result["models"]["decision_tree"]["max_depth"], 3)
        self.assertEqual(result["models"]["decision_tree"]["thread_limit"], 1)
        self.assertLess(result["models"]["decision_tree"]["fit_seconds"], 3.0)
        self.assertLess(result["models"]["decision_tree"]["test_mse"],
                        result["models"]["ridge"]["test_mse"])
        self.assertTrue(np.isfinite(result["models"]["decision_tree"]["test_mse"]))
        self.assertTrue(np.isfinite(result["models"]["ridge"]["test_mse"]))


if __name__ == "__main__":
    unittest.main()
