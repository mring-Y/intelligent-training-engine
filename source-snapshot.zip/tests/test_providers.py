import csv
import hashlib
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path

import numpy as np

from ite.config import ExperimentConfig
from ite.controller import AdaptationController
from ite.data import InitialData, make_simulation
from ite.models import RidgeModel
from ite.runner import run_policy
from ite.tracking import JsonlLogger
from ite.training import BoundedTrainer

try:
    from ite.providers import ColumnMapping, CSVDataProvider, ParquetDataProvider, SimulationDataProvider
except ImportError:
    ColumnMapping = CSVDataProvider = ParquetDataProvider = SimulationDataProvider = None


class ProviderTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(CSVDataProvider, "Explicit official file provider is missing")
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.mapping = ColumnMapping(features=("a", "b"), target="y", sample_id="id", batch="batch")
        x = np.asarray([[-2., 0], [-1, 1], [1, 0], [2, 1]])
        self.initial = InitialData(x, np.array([0, 0, 1, 1]), x.copy(), np.array([0, 0, 1, 1]))
        self.rows = [dict(id=10, batch=0, a=-1, b=2, y=0),
                     dict(id=11, batch=0, a=1, b=3, y=1),
                     dict(id=12, batch=1, a=2, b=4, y=1),
                     dict(id=13, batch=2, a=-2, b=5, y=0)]

    def write_csv(self, name="stream.csv", rows=None):
        path = self.root / name
        rows = self.rows if rows is None else rows
        with path.open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        return path

    def provider(self, rows=None, **kwargs):
        return CSVDataProvider(self.write_csv(rows=rows), self.mapping, initial=self.initial,
                               label_delay=2, max_labels=3, **kwargs)

    def commit(self, provider, batch):
        provider.commit_predictions(batch.step, batch.sample_ids, np.zeros(len(batch.sample_ids)))

    def test_explicit_features_hide_targets_and_preserve_unequal_boundaries(self):
        provider = self.provider()
        self.assertEqual(provider.batch_sizes, (2, 1, 1))
        self.assertEqual(provider.n_features, 2)
        batches = []
        for batch in provider.iter_batches():
            self.assertFalse(hasattr(batch, "targets"))
            self.assertFalse(batch.features.flags.writeable)
            batches.append(batch)
            self.commit(provider, batch)
        self.assertEqual([b.step for b in batches], [0, 1, 2])
        np.testing.assert_array_equal(batches[0].features, [[-1, 2], [1, 3]])
        with self.assertRaises(RuntimeError):
            list(provider.iter_batches())

    def test_labels_require_prediction_commit_and_are_delayed_from_request_time(self):
        provider = self.provider()
        batches = provider.iter_batches()
        first = next(batches)
        with self.assertRaises(ValueError):
            provider.request_labels([10], 0)
        with self.assertRaises(ValueError):
            provider.release_labels(0)
        self.commit(provider, first)
        self.assertEqual(provider.request_labels([10, 11], 0), 2)
        self.assertEqual(provider.pending_schedule, ((0, 2), (0, 2)))
        self.assertIsNone(provider.release_labels(0))
        second = next(batches)
        self.commit(provider, second)
        self.assertIsNone(provider.release_labels(1))
        third = next(batches)
        with self.assertRaises(ValueError):
            provider.release_labels(2)
        self.commit(provider, third)
        released = provider.release_labels(2)
        np.testing.assert_array_equal(released.sample_ids, [10, 11])
        np.testing.assert_array_equal(released.targets, [0, 1])
        np.testing.assert_array_equal(released.source_steps, [0, 0])
        self.assertIsNone(provider.release_labels(2))

    def test_budget_duplicate_unknown_and_uncommitted_prediction_validation(self):
        provider = self.provider()
        iterator = provider.iter_batches()
        first = next(iterator)
        with self.assertRaises(ValueError):
            provider.commit_predictions(0, [10], [0])
        with self.assertRaises(ValueError):
            provider.commit_predictions(0, [10, 11], [0, np.nan])
        self.commit(provider, first)
        for ids in ([10, 10], [999], [12]):
            with self.subTest(ids=ids), self.assertRaises(ValueError):
                provider.request_labels(ids, 0)
        self.assertEqual(provider.request_labels([10, 11], 0), 2)
        with self.assertRaises(ValueError):
            provider.request_labels([10], 0)
        second = next(iterator)
        self.commit(provider, second)
        self.assertEqual(provider.request_labels([12], 1), 1)
        third = next(iterator)
        self.commit(provider, third)
        self.assertEqual(provider.request_labels([13], 2), 0)

    def test_cannot_advance_without_commit_or_request_with_wrong_clock(self):
        provider = self.provider()
        iterator = provider.iter_batches()
        first = next(iterator)
        with self.assertRaises(ValueError):
            provider.request_labels([10], 1)
        with self.assertRaises(ValueError):
            next(iterator)

    def test_strict_mapping_rejects_metadata_leakage_and_aliases(self):
        for changes in ({"features": ("a", "y")}, {"features": ("a", "a")},
                        {"sample_id": "batch"}, {"features": ()}):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                replace(self.mapping, **changes)

    def test_malformed_files_fail_before_streaming(self):
        cases = [dict(id=10), dict(batch=2), dict(id="1.5"), dict(batch="0.5")]
        for change in cases:
            rows = [dict(row) for row in self.rows]
            rows[1].update(change)
            with self.subTest(change=change), self.assertRaises(ValueError):
                self.provider(rows)

    def test_initial_data_is_validated_and_separate_files_are_supported(self):
        bad = replace(self.initial, train_x=np.ones((4, 3)))
        with self.assertRaises(ValueError):
            CSVDataProvider(self.write_csv(), self.mapping, initial=bad)
        initial_rows = [dict(id=i + 100, batch=0, a=x[0], b=x[1], y=y)
                        for i, (x, y) in enumerate(zip(self.initial.train_x, self.initial.train_y))]
        validation_rows = [dict(row, id=row["id"] + 100) for row in initial_rows]
        provider = CSVDataProvider(self.write_csv(), self.mapping,
                                   initial_train_path=self.write_csv("train.csv", initial_rows),
                                   initial_validation_path=self.write_csv("validation.csv", validation_rows))
        np.testing.assert_array_equal(provider.initial_data().train_y, [0, 0, 1, 1])
        with self.assertRaises(ValueError):
            CSVDataProvider(self.write_csv(), self.mapping, initial=self.initial,
                            initial_train_path=self.root / "train.csv")

    def test_capacity_uses_actual_future_batches_and_due_times(self):
        provider = self.provider()
        availability = provider.label_availability(remaining=20, per_batch=10)
        self.assertEqual(availability.capacity(frozen_at=0, step=0, deadline=2), 0)
        self.assertEqual(availability.capacity(frozen_at=-1, step=-1, deadline=2), 2)
        provider = CSVDataProvider(self.write_csv(), self.mapping, initial=self.initial, label_delay=0)
        availability = provider.label_availability(remaining=20, per_batch=1)
        self.assertEqual(availability.capacity(-1, -1, 2), 3)
        provider = CSVDataProvider(self.write_csv(), self.mapping, initial=self.initial,
                                   label_delay=0, max_labels=1)
        self.assertEqual(provider.label_availability(remaining=20, per_batch=10).capacity(-1, -1, 2), 1)

    def test_classification_runner_rejects_nonbinary_initial_and_released_targets(self):
        config = ExperimentConfig(n_features=2, initial_train=4, initial_validation=4,
                                  n_batches=3, label_delay=0, label_fraction=1, max_labels=10)
        for source in ("train", "validation", "released"):
            rows = [dict(row) for row in self.rows]
            initial = self.initial
            if source == "train":
                initial = replace(initial, train_y=np.array([0, 0, 2, 1]))
            elif source == "validation":
                initial = replace(initial, validation_y=np.array([0, 0, 2, 1]))
            else:
                rows[0]["y"] = 2
            provider = CSVDataProvider(self.write_csv(rows=rows), self.mapping, initial=initial, label_delay=0)
            with self.subTest(source=source), BoundedTrainer() as trainer, self.assertRaises(ValueError):
                run_policy(config, "drift", self.root / ("nonbinary-" + source), trainer, provider=provider)

    def test_csv_reads_rows_without_whole_file_loading(self):
        # A late dirty value must be recovered even beyond the reader chunk size.
        rows = [dict(id=i, batch=i // 2, a=1, b=2, y=i % 2) for i in range(100)]
        rows[-1]["a"] = "nan"
        provider = self.provider(rows, read_batch_size=3)
        last = None
        for batch in provider.iter_batches():
            self.commit(provider, batch)
            last = batch
        self.assertTrue(np.isfinite(last.features).all())
        self.assertEqual(provider.provenance()["data_quality"]["stream"]["feature_values_imputed"][0], 1)

    def test_initial_features_use_finite_training_medians_and_skip_missing_targets(self):
        initial = InitialData(
            train_x=np.asarray([[np.nan, 0.], [-2., 1.], [2., 3.], [np.inf, 5.], [100., 100.]]),
            train_y=np.asarray([0., 0., 1., 1., np.nan]),
            validation_x=np.asarray([[np.nan, 0.], [-1., 1.], [1., 0.], [2., 1.]]),
            validation_y=np.asarray([0., 0., 1., 1.]),
        )
        provider = CSVDataProvider(self.write_csv(), self.mapping, initial=initial)
        fitted = provider.initial_data()
        self.assertEqual(fitted.train_y.shape, (4,))
        np.testing.assert_allclose(fitted.train_x[0], [0., 0.])
        np.testing.assert_allclose(fitted.train_x[3], [0., 5.])
        np.testing.assert_allclose(fitted.validation_x[0], [0., 0.])
        self.assertTrue(np.isfinite(fitted.train_x).all())
        self.assertTrue(np.isfinite(fitted.validation_x).all())
        audit = provider.provenance()["data_quality"]
        self.assertEqual(audit["initial_train_medians"], [0., 2.])
        self.assertEqual(audit["initial"]["train"]["missing_targets_skipped"], 1)

    def test_missing_stream_target_is_not_requested_or_released(self):
        rows = [dict(row) for row in self.rows]
        rows[1]["y"] = ""
        rows.insert(2, dict(id=14, batch=0, a=3, b=5, y=1))
        provider = CSVDataProvider(self.write_csv(rows=rows), self.mapping,
                                   initial=self.initial, label_delay=0)
        iterator = provider.iter_batches()
        first = next(iterator)
        self.commit(provider, first)
        self.assertEqual(provider.request_labels([10, 11, 14], 0), 2)
        released = provider.release_labels(0)
        np.testing.assert_array_equal(released.sample_ids, [10, 14])
        np.testing.assert_array_equal(released.targets, [0., 1.])
        self.assertEqual(provider.request_labels([11], 0), 0)
        self.assertIsNone(provider.release_labels(0))

    @unittest.skipUnless(importlib.util.find_spec("pyarrow"), "Optional pyarrow==22.0.0 is not installed")
    def test_dirty_parquet_generator_survives_preflight_and_runner(self):
        script = Path(__file__).resolve().parents[1] / "scripts" / "make_dirty_data.py"
        output = self.root / "dirty-data"
        subprocess.run([sys.executable, str(script), "--output", str(output)],
                       check=True, capture_output=True, text=True)
        manifest = json.loads((output / "manifest.json").read_text(encoding="utf-8"))
        mapping = ColumnMapping(**manifest["mapping"])
        provider = ParquetDataProvider(
            output / manifest["files"]["stream"], mapping,
            initial_train_path=output / manifest["files"]["initial_train"],
            initial_validation_path=output / manifest["files"]["initial_validation"],
            label_delay=0,
        )
        audit = provider.provenance()["data_quality"]["stream"]
        self.assertEqual(audit["missing_targets"], 1)
        self.assertEqual(audit["feature_values_imputed"], [1, 1, 0])
        self.assertEqual(audit["float32_overflow_values"], [0, 0, 1])
        self.assertGreater(audit["max_abs_feature_values"][2], float(np.finfo(np.float32).max))
        self.assertTrue(any(name == "timestamp" for name in manifest["metadata_columns"]))
        self.assertFalse(manifest["cases"]["timestamp_is_monotonic"])

        overflow_probe = ParquetDataProvider(
            output / manifest["files"]["stream"], mapping,
            initial_train_path=output / manifest["files"]["initial_train"],
            initial_validation_path=output / manifest["files"]["initial_validation"],
            label_delay=0,
        )
        observed_overflow = None
        released_features, released_targets, released_steps = [], [], []
        for batch in overflow_probe.iter_batches():
            matching = np.flatnonzero(batch.sample_ids == manifest["cases"]["float32_overflow_value"])
            if matching.size:
                observed_overflow = batch.features[matching[0], 2]
            self.commit(overflow_probe, batch)
            overflow_probe.request_labels(batch.sample_ids, batch.step)
            released = overflow_probe.release_labels(batch.step)
            if released is not None:
                released_features.append(released.features)
                released_targets.append(released.targets)
                released_steps.append(released.source_steps)
        self.assertGreater(observed_overflow, float(np.finfo(np.float32).max))
        self.assertTrue(np.isfinite(observed_overflow))
        released_count = sum(len(targets) for targets in released_targets)
        self.assertEqual(released_count, 23)

        preflight_config = ExperimentConfig(
            task="classification", n_features=3, initial_train=64, initial_validation=32,
            n_batches=4, label_delay=0, max_labels=24, deployment_validation="future",
            training_preflight=True, history_windows=(18,), candidate_alphas=(1.0,),
            min_labeled=16, min_validation=4, max_experiments=1,
        )
        preflight_root = self.root / "dirty-preflight"
        preflight_root.mkdir()
        initial = overflow_probe.initial_data()
        model = RidgeModel("classification", alpha=1.0).fit(initial.train_x, initial.train_y)
        with BoundedTrainer() as trainer, JsonlLogger(
                preflight_root / "events.jsonl", "dirty-preflight") as logger:
            controller = AdaptationController(preflight_config, "periodic", model, 1.0, 1.0,
                                              logger, trainer, preflight_root)
            controller.history_x = np.concatenate(released_features)
            controller.history_y = np.concatenate(released_targets)
            controller.history_steps = np.concatenate(released_steps)
            controller.budget.record_labels(released_count)
            training_pool = controller.history_steps < 3
            self.assertGreater(np.max(controller.history_x[training_pool, 2]),
                               float(np.finfo(np.float32).max))
            controller._experiment(4, {"diagnosis": "dirty_feature_preflight"})
        preflight_events = [json.loads(line) for line in
                            (preflight_root / "events.jsonl").read_text().splitlines()]
        self.assertEqual(controller.budget.training_attempts, 1, preflight_events)
        self.assertEqual(controller.budget.labels, released_count)
        self.assertFalse(any(event["event"] == "training_preflight_skipped"
                             for event in preflight_events))
        candidate = next(event for event in preflight_events
                         if event["event"] == "candidate_evaluated")
        self.assertEqual(candidate["status"], "ok")
        self.assertEqual(candidate["train_samples"], 17)

        config = ExperimentConfig(task="classification", n_features=3, initial_train=64,
                                  initial_validation=32, n_batches=4, label_delay=0,
                                  max_labels=24, deployment_validation="future")
        with BoundedTrainer() as trainer:
            summary = run_policy(config, "static", self.root / "dirty-run", trainer, provider=provider)
        self.assertEqual(summary["stream_batches"], 4)
        events = [json.loads(line) for line in (self.root / "dirty-run/events.jsonl").read_text().splitlines()]
        start = next(event for event in events if event["event"] == "run_started")
        self.assertEqual(start["data_source"]["data_quality"]["stream"]["missing_targets"], 1)
        with np.load(self.root / "dirty-run/predictions.npz", allow_pickle=False) as saved:
            self.assertEqual(saved["predictions"].size, 24)
            self.assertEqual(saved["sample_ids"].shape, (24,))

        missing_column_provider = ParquetDataProvider(
            output / manifest["files"]["missing_feature_stream"], mapping,
            initial_train_path=output / manifest["files"]["initial_train"],
            initial_validation_path=output / manifest["files"]["initial_validation"],
            label_delay=0,
        )
        missing_audit = missing_column_provider.provenance()["data_quality"]["stream"]
        self.assertEqual(missing_audit["missing_feature_columns"], ["sensor_3"])
        self.assertEqual(missing_audit["feature_values_imputed"][2], 24)
        for batch in missing_column_provider.iter_batches():
            self.assertTrue(np.isfinite(batch.features).all())
            self.commit(missing_column_provider, batch)

    @unittest.skipUnless(importlib.util.find_spec("pyarrow"), "Optional pyarrow==22.0.0 is not installed")
    def test_real_parquet_matches_csv_with_row_groups_splitting_batches(self):
        import pyarrow as pa
        import pyarrow.parquet as pq
        path = self.root / "stream.parquet"
        pq.write_table(pa.Table.from_pylist(self.rows), path, row_group_size=1)
        parquet = ParquetDataProvider(path, self.mapping, initial=self.initial, read_batch_size=1,
                                      label_delay=0)
        csv_provider = CSVDataProvider(self.write_csv(), self.mapping, initial=self.initial, label_delay=0)
        for left, right in zip(parquet.iter_batches(), csv_provider.iter_batches()):
            np.testing.assert_array_equal(left.features, right.features)
            np.testing.assert_array_equal(left.sample_ids, right.sample_ids)
            for provider, batch in ((parquet, left), (csv_provider, right)):
                self.commit(provider, batch)
                provider.request_labels(batch.sample_ids, batch.step)
            np.testing.assert_array_equal(parquet.release_labels(left.step).targets,
                                          csv_provider.release_labels(right.step).targets)

    def test_runner_injection_omits_simulation_truth_and_saves_ragged_predictions(self):
        provider = self.provider()
        config = ExperimentConfig(n_features=2, initial_train=4, initial_validation=4,
                                  n_batches=3, batch_size=96, label_fraction=1,
                                  max_labels=3, label_delay=2, deployment_validation="future")
        with BoundedTrainer() as trainer:
            summary = run_policy(config, "drift", self.root / "run", trainer, provider=provider)
        self.assertEqual(summary["stream_batches"], 3)
        self.assertEqual(summary["labels_requested"], 3)
        self.assertEqual(summary["labels_released"], 2)
        self.assertIsNone(summary["mean_loss"])
        self.assertNotIn("missed_changes", summary)
        with np.load(self.root / "run/predictions.npz", allow_pickle=False) as saved:
            np.testing.assert_array_equal(saved["batch_offsets"], [0, 2, 3, 4])
            np.testing.assert_array_equal(saved["sample_ids"], [10, 11, 12, 13])
            self.assertEqual(saved["predictions"].shape, (4,))

    def test_runner_rejects_incompatible_provider_protocol(self):
        base = ExperimentConfig(n_features=2, n_batches=3, label_delay=2, max_labels=3)
        for changes in ({"n_features": 3}, {"n_batches": 2}, {"label_delay": 1}):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                run_policy(replace(base, **changes), "static", self.root / str(len(changes)) /
                           next(iter(changes)), None, provider=self.provider())

    def test_runner_caps_requests_by_its_budget_even_when_provider_is_unlimited(self):
        provider = CSVDataProvider(self.write_csv(), self.mapping, initial=self.initial, label_delay=0)
        config = ExperimentConfig(n_features=2, initial_train=4, initial_validation=4,
                                  n_batches=3, label_delay=0, label_fraction=1, max_labels=1)
        with BoundedTrainer() as trainer:
            summary = run_policy(config, "drift", self.root / "budget", trainer, provider=provider)
        self.assertEqual(summary["labels_requested"], 1)
        self.assertEqual(provider.total_requested, 1)

    def test_simulation_adapter_preserves_future_gate_and_default_predictions(self):
        config = ExperimentConfig(n_batches=14, drift_start=0, update_interval=3, cooldown=0,
                                  deployment_validation="future")
        with BoundedTrainer() as trainer:
            default = run_policy(config, "periodic", self.root / "default", trainer)
            trainer.close()
            adapter = SimulationDataProvider(make_simulation(config), config)
            injected = run_policy(config, "periodic", self.root / "injected", trainer,
                                  provider=adapter, offline_scorer=adapter.offline_scorer)
        self.assertEqual(default["mean_loss"], injected["mean_loss"])
        with np.load(self.root / "default/predictions.npz") as left, \
                np.load(self.root / "injected/predictions.npz") as right:
            np.testing.assert_array_equal(left["predictions"], right["predictions"])
        events = [json.loads(line) for line in (self.root / "injected/events.jsonl").read_text().splitlines()]
        deployed = [event for event in events if event["event"] == "deploy"]
        self.assertTrue(deployed)
        for event in deployed:
            self.assertGreater(event["gate_min_source_step"], event["frozen_at"])
            self.assertGreaterEqual(event["step"], event["gate_max_source_step"] + 2)

    def test_simulation_adapter_enforces_same_commit_boundary(self):
        config = ExperimentConfig(n_batches=3, label_delay=0)
        adapter = SimulationDataProvider(make_simulation(config), config)
        iterator = adapter.iter_batches()
        batch = next(iterator)
        with self.assertRaises(ValueError):
            adapter.release_labels(0)
        with self.assertRaises(ValueError):
            adapter.request_labels(batch.sample_ids[:1], 0)
        self.commit(adapter, batch)
        self.assertEqual(adapter.request_labels(batch.sample_ids[:1], 0), 1)
        self.assertEqual(len(adapter.release_labels(0).targets), 1)
        next(iterator)
        with self.assertRaises(ValueError):
            next(iterator)

    def test_real_csv_runner_deploys_only_on_independent_future_source_labels(self):
        rng = np.random.default_rng(91)
        rows = []
        for step in range(14):
            for offset, x in enumerate(rng.normal(size=(96, 2))):
                rows.append(dict(id=step * 96 + offset, batch=step, a=x[0], b=x[1],
                                 y=int(x[0] < 0)))
        provider = CSVDataProvider(self.write_csv(rows=rows), self.mapping, initial=self.initial,
                                   label_delay=2, max_labels=864)
        config = ExperimentConfig(n_features=2, initial_train=4, initial_validation=4,
                                  n_batches=14, deployment_validation="future", update_interval=3, cooldown=0)
        with BoundedTrainer() as trainer:
            summary = run_policy(config, "periodic", self.root / "csv-gate", trainer, provider=provider)
        self.assertGreater(summary["updates"], 0)
        events = [json.loads(line) for line in (self.root / "csv-gate/events.jsonl").read_text().splitlines()]
        for event in (e for e in events if e["event"] == "deploy"):
            self.assertGreater(event["gate_min_source_step"], event["frozen_at"])
            self.assertGreaterEqual(event["step"], event["gate_max_source_step"] + 2)

    def test_recorded_provider_provenance_tracks_changed_bytes_not_config_scenario(self):
        config = ExperimentConfig(n_features=2, initial_train=4, initial_validation=4,
                                  n_batches=3, label_delay=2, scenario="abrupt")
        hashes = []
        for revision in range(2):
            rows = [dict(row) for row in self.rows]
            rows[0]["a"] = -1 - revision
            path = self.write_csv(rows=rows)
            expected_sha = hashlib.sha256(path.read_bytes()).hexdigest()
            provider = CSVDataProvider(path, self.mapping, initial=self.initial, label_delay=2)
            output = self.root / f"provenance-{revision}"
            with BoundedTrainer() as trainer:
                run_policy(config, "static", output, trainer, provider=provider)
            event = json.loads((output / "events.jsonl").read_text().splitlines()[0])
            source = event["data_source"]
            self.assertEqual(source["kind"], "provider")
            self.assertEqual(source["class"], "CSVDataProvider")
            self.assertNotIn("scenario", source)
            self.assertEqual(source["stream"]["sha256"], expected_sha)
            self.assertEqual(source["stream"]["bytes"], path.stat().st_size)
            self.assertEqual(source["column_mapping"], {"features": ["a", "b"], "target": "y",
                                                       "sample_id": "id", "batch": "batch"})
            self.assertEqual(source["batch_sizes"], [2, 1, 1])
            self.assertEqual(source["label_delay"], 2)
            hashes.append(source["stream"]["sha256"])
        self.assertNotEqual(*hashes)

    def test_provenance_fingerprints_injected_initial_arrays_and_separate_files(self):
        provider = self.provider()
        original = provider.provenance()["initial_data"]
        self.assertEqual(original["kind"], "arrays")
        self.assertEqual(original["train_x"]["shape"], [4, 2])
        changed = replace(self.initial, validation_y=np.array([1, 0, 1, 1]))
        other = CSVDataProvider(self.write_csv(), self.mapping, initial=changed)
        self.assertNotEqual(original["validation_y"]["sha256"],
                            other.provenance()["initial_data"]["validation_y"]["sha256"])
        initial_rows = [dict(a=x[0], b=x[1], y=y)
                        for x, y in zip(self.initial.train_x, self.initial.train_y)]
        train = self.write_csv("provenance-train.csv", initial_rows)
        validation = self.write_csv("provenance-validation.csv", initial_rows)
        provider = CSVDataProvider(self.write_csv(), self.mapping,
                                   initial_train_path=train, initial_validation_path=validation)
        source = provider.provenance()["initial_data"]
        self.assertEqual(source["kind"], "files")
        self.assertEqual(source["train"]["sha256"], hashlib.sha256(train.read_bytes()).hexdigest())
        self.assertEqual(source["validation"]["sha256"], hashlib.sha256(validation.read_bytes()).hexdigest())
        simulation = make_simulation(ExperimentConfig(n_batches=3))
        adapter = SimulationDataProvider(simulation, ExperimentConfig(n_batches=3))
        self.assertEqual(adapter.provenance()["kind"], "provider")


if __name__ == "__main__":
    unittest.main()
