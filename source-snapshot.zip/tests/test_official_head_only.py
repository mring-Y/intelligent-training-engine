"""Actual official checkpoints must freeze parameters and Adam moments together."""

import io
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

from ite.official_model import OfficialModelAdapter
from ite.official_sft_data import load_public_package
from ite.training import BoundedTrainer


ROOT = Path(__file__).resolve().parents[1]
RUNTIME = Path(os.environ.get("ITE_OFFICIAL_RUNTIME_PYTHON", ROOT/".venv-official-a/Scripts/python.exe"))


def arrays(model):
    with np.load(io.BytesIO(model.checkpoint_bytes), allow_pickle=False) as cp:
        return {key: cp[key].copy() for key in cp.files}


@unittest.skipUnless(RUNTIME.is_file(), "official NumPy1.26.4 runtime is not provisioned")
class OfficialHeadOnlyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = {profile: load_public_package(profile) for profile in "ABC"}

    def model(self, profile="C"):
        return OfficialModelAdapter(self.data[profile]["task"], RUNTIME, profile_type=profile)

    def fit_head(self, model, x, y, epochs=1):
        try:
            return model.fit(x, y, epochs=epochs, trainable_policy="head_only")
        except TypeError as error:
            self.fail(f"Official adapter needs an explicit frozen-head policy: {error}")

    def test_real_abc_nonzero_adam_momentum_cannot_move_frozen_layer(self):
        for profile, parameters in (("A", 198), ("B", 25), ("C", 33)):
            with self.subTest(profile=profile):
                parent = self.model(profile)
                parent_bytes, before = parent.checkpoint_bytes, arrays(parent)
                self.assertTrue(np.any(before["adam_first_w1"] != 0))
                child = OfficialModelAdapter.from_state(parent.state())
                self.fit_head(child, self.data[profile]["x"][:32], self.data[profile]["y"][:32])
                after = arrays(child)
                self.assertEqual(parent.checkpoint_bytes, parent_bytes)
                for key in ("w1", "b1", "adam_first_w1", "adam_first_b1", "adam_second_w1",
                            "adam_second_b1", "mean", "scale"):
                    self.assertEqual(before[key].tobytes(), after[key].tobytes(), key)
                for key in ("w2", "b2", "adam_first_w2", "adam_second_w2"):
                    self.assertFalse(np.array_equal(before[key], after[key]), key)
                meta = json.loads(after["metadata"].item())
                old_meta = json.loads(before["metadata"].item())
                self.assertEqual(meta["epochs"], old_meta["epochs"] + 1)
                self.assertEqual(meta["steps"], old_meta["steps"] + 1)
                for key in ("learning_rate", "target_mean", "target_scale", "batch_size", "paths"):
                    self.assertEqual(meta[key], old_meta[key])
                self.assertEqual(child.last_fit_audit["trainable_parameters"], parameters)
                self.assertEqual(child.last_fit_audit["trainable_policy"], "head_only")
                self.assertEqual(child.last_fit_audit["max_parameter_delta"]["w1"], 0.)
                prediction = child.predict(self.data[profile]["x"][:4])
                self.assertTrue(np.isfinite(prediction).all())
                if profile == "A":
                    self.assertEqual(child.predict_proba(self.data[profile]["x"][:4]).shape, (4, 6))

    def test_regression_head_one_step_matches_current_adam_and_full_gradient_clipping(self):
        model = self.model()
        before = arrays(model)
        meta = json.loads(before["metadata"].item())
        x, y = self.data["C"]["x"][:24], self.data["C"]["y"][:24]
        order = np.random.default_rng(np.random.SeedSequence([meta["seed"], meta["epochs"]])).permutation(24)
        normalized = np.clip((x-before["mean"])/before["scale"], -10, 10)[order]
        hidden = np.tanh(normalized@before["w1"] + before["b1"])
        error = (hidden@before["w2"]+before["b2"])[:, 0] - (y[order]-meta["target_mean"])/meta["target_scale"]
        delta = (2*error/24)[:, None]
        hidden_delta = (delta@before["w2"].T)*(1-hidden**2)
        gradients = {"w2": hidden.T@delta, "b2": delta.sum(axis=0),
                     "w1": normalized.T@hidden_delta, "b1": hidden_delta.sum(axis=0)}
        norm = np.sqrt(sum(np.sum(g*g) for g in gradients.values()))
        expected = {}
        for key in ("w2", "b2"):
            g = gradients[key]*min(1., 5./max(norm, 1e-12))
            first = .9*before["adam_first_"+key] + .1*g
            second = .999*before["adam_second_"+key] + .001*g*g
            t = meta["steps"] + 1
            expected[key] = before[key] - meta["learning_rate"]*(first/(1-.9**t))/(np.sqrt(second/(1-.999**t))+1e-8)
        self.fit_head(model, x, y)
        after = arrays(model)
        for key in expected:
            np.testing.assert_allclose(after[key], expected[key], rtol=1e-12, atol=1e-12)

    def test_asymmetric_two_x_doubles_only_positive_residual_gradient(self):
        model = self.model()
        before = arrays(model)
        meta = json.loads(before["metadata"].item())
        x = self.data["C"]["x"][:24]
        base_y = self.data["C"]["y"][:24]
        order = np.random.default_rng(np.random.SeedSequence([meta["seed"], meta["epochs"]])).permutation(24)
        normalized = np.clip((x-before["mean"])/before["scale"], -10, 10)[order]
        hidden = np.tanh(normalized@before["w1"]+before["b1"])
        predicted = (hidden@before["w2"]+before["b2"])[:, 0]
        target = (base_y[order]-meta["target_mean"])/meta["target_scale"]
        # Exercise both branches in one vendor update without altering the model inputs.
        target[:12] = predicted[:12] - .25
        target[12:] = predicted[12:] + .25
        physical_y = np.empty_like(target)
        physical_y[order] = target*meta["target_scale"]+meta["target_mean"]
        residual = predicted-target
        delta = (2*residual*np.where(residual > 0, 2., 1.)/24)[:, None]
        hidden_delta = (delta@before["w2"].T)*(1-hidden**2)
        gradients = {"w2": hidden.T@delta, "b2": delta.sum(axis=0),
                     "w1": normalized.T@hidden_delta, "b1": hidden_delta.sum(axis=0)}
        norm = np.sqrt(sum(np.sum(g*g) for g in gradients.values()))
        expected = {}
        for key in ("w2", "b2"):
            gradient = gradients[key]*min(1., 5./max(norm, 1e-12))
            first = .9*before["adam_first_"+key]+.1*gradient
            second = .999*before["adam_second_"+key]+.001*gradient**2
            step = meta["steps"]+1
            expected[key] = before[key]-meta["learning_rate"]*(first/(1-.9**step))/(
                np.sqrt(second/(1-.999**step))+1e-8)
        model.fit(x, physical_y, epochs=1, trainable_policy="head_only", loss_policy="overestimate_2x")
        actual = arrays(model)
        for key in expected:
            np.testing.assert_allclose(actual[key], expected[key], rtol=1e-12, atol=1e-12)
        for key in ("w1", "b1", "adam_first_w1", "adam_second_w1"):
            self.assertEqual(actual[key].tobytes(), before[key].tobytes(), key)

    def test_asymmetric_loss_is_opt_in_and_rejected_for_full_or_classification(self):
        model = self.model()
        before = model.checkpoint_bytes
        with patch.object(model, "_invoke", side_effect=AssertionError("worker must not start")):
            for kwargs in ({"trainable_policy": "full", "loss_policy": "overestimate_2x"},
                           {"trainable_policy": "head_only", "loss_policy": "unknown"}):
                with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                    model.fit(self.data["C"]["x"][:8], self.data["C"]["y"][:8], **kwargs)
        self.assertEqual(model.checkpoint_bytes, before)
        gas = self.model("A")
        with patch.object(gas, "_invoke", side_effect=AssertionError("worker must not start")):
            with self.assertRaises(ValueError):
                gas.fit(self.data["A"]["x"][:8], self.data["A"]["y"][:8],
                        trainable_policy="head_only", loss_policy="overestimate_2x")
        bearing = self.model("B")
        with patch.object(bearing, "_invoke", side_effect=AssertionError("worker must not start")):
            with self.assertRaises(ValueError):
                bearing.fit(self.data["B"]["x"][:8], self.data["B"]["y"][:8],
                            trainable_policy="head_only", loss_policy="overestimate_2x")

    def test_segmented_head_resume_is_byte_identical_to_two_epochs(self):
        parent = self.model()
        x, y = self.data["C"]["x"][:32], self.data["C"]["y"][:32]
        continuous = OfficialModelAdapter.from_state(parent.state())
        self.fit_head(continuous, x, y, 2)
        split = OfficialModelAdapter.from_state(parent.state())
        self.fit_head(split, x, y)
        split = OfficialModelAdapter.from_state(split.state())
        self.fit_head(split, x, y)
        self.assertEqual(continuous.checkpoint_bytes, split.checkpoint_bytes)

    def test_head_checkpoint_loads_with_official_predict_and_switches_back_to_full(self):
        import zipfile
        model = self.model()
        data = self.data["C"]
        self.fit_head(model, data["x"][:32], data["y"][:32])
        frozen = arrays(model)
        with tempfile.TemporaryDirectory() as tmp:
            checkpoint = Path(tmp)/"head.npz"
            model.save(checkpoint)
            with zipfile.ZipFile(model.package_path) as archive:
                row = json.loads(archive.read("public/validation.jsonl").decode().splitlines()[0])
            env = {**os.environ, "PYTHONPATH": model.package_path, "BASELINE_CPU_THREADS": "1"}
            result = subprocess.run([str(RUNTIME), "-m", "baselines.predict", "--checkpoint", str(checkpoint)],
                input=json.dumps({"task": "regression", "inputs": row["inputs"]})+"\n",
                capture_output=True, text=True, env=env, check=True, timeout=10)
            self.assertLess(abs(json.loads(result.stdout)["outputs"]["value"]-model.predict(data["x"][:1])[0]), 1e-6)
        model.fit(data["x"][:32], data["y"][:32], epochs=1)
        self.assertFalse(np.array_equal(arrays(model)["w1"], frozen["w1"]))
        self.assertEqual(model.last_fit_audit["trainable_policy"], "full")

    def test_unknown_policy_is_rejected_before_worker_and_parent_unchanged(self):
        model = self.model()
        before = model.checkpoint_bytes
        with patch.object(model, "_invoke", side_effect=AssertionError("worker must not start")):
            for policy in ("low_lr", "HEAD_ONLY", None, True, {"layers": ["w2"]}):
                with self.subTest(policy=policy), self.assertRaises(ValueError):
                    model.fit(self.data["C"]["x"][:4], self.data["C"]["y"][:4], trainable_policy=policy)
        self.assertEqual(model.checkpoint_bytes, before)

    def test_bounded_trainer_passes_policy_and_enforces_same_parent_and_timeout(self):
        parent = self.model()
        with BoundedTrainer() as trainer:
            result = trainer.fit("regression", None, self.data["C"]["x"][:24], self.data["C"]["y"][:24], 5.,
                model_type="official_mlp", official_options={"parent_state": parent.state(), "trainable_policy": "head_only"})
            self.assertEqual(result.status, "ok", result.error)
            self.assertTrue(0 < result.wall_seconds <= 5.)
            self.assertEqual(arrays(parent)["w1"].tobytes(), arrays(result.model)["w1"].tobytes())
            timeout = trainer.fit("regression", None, self.data["C"]["x"][:24], self.data["C"]["y"][:24], 1e-6,
                model_type="official_mlp", official_options={"parent_state": parent.state(), "trainable_policy": "head_only"})
            self.assertEqual(timeout.status, "timeout")
            self.assertIsNone(timeout.model)

    def test_bounded_trainer_routes_asymmetric_loss_without_changing_frozen_parent(self):
        parent = self.model()
        parent_bytes = parent.checkpoint_bytes
        with BoundedTrainer() as trainer:
            result = trainer.fit("regression", None, self.data["C"]["x"][:32], self.data["C"]["y"][:32], 5.,
                model_type="official_mlp", official_options={"parent_state": parent.state(),
                    "trainable_policy": "head_only", "loss_policy": "overestimate_2x"})
        self.assertEqual(result.status, "ok", result.error)
        self.assertEqual(parent.checkpoint_bytes, parent_bytes)
        self.assertEqual(result.model.last_fit_audit["loss_policy"], "overestimate_2x")
        self.assertEqual(result.model.last_fit_audit["overestimate_penalty"], 2.)


if __name__ == "__main__":
    unittest.main()
