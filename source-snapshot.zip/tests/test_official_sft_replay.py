"""Replay uses current checkpoints and delayed, disjoint gate evidence."""

import importlib
import json
import tempfile
import unittest
import os
from pathlib import Path

import numpy as np


class ConstantModel:
    task = "regression"
    std = np.ones(2)
    mean = np.zeros(2)
    checkpoint_sha256 = "initial"
    steps = 10
    epochs = 1
    candidate_epochs = 1

    def predict(self, x):
        return np.zeros(len(x))

    def state(self):
        return {"checkpoint_sha256": self.checkpoint_sha256, "steps": self.steps}


class ConstantClassifier:
    task = "classification"
    mean = np.zeros(2)
    std = np.ones(2)
    steps = 10
    epochs = 1
    candidate_epochs = 1

    def __init__(self, label, checkpoint_sha256):
        self.label = label
        self.checkpoint_sha256 = checkpoint_sha256

    def predict(self, x):
        return np.full(len(x), self.label, dtype=int)

    def state(self):
        return {"checkpoint_sha256": self.checkpoint_sha256, "steps": self.steps}


class OfficialSFTReplayTests(unittest.TestCase):
    def module(self):
        try:
            return importlib.import_module("ite.official_sft_replay")
        except ImportError as error:
            self.fail(f"Bounded official replay missing: {error}")

    def data(self):
        return {"profile": "B", "task": "regression", "unit": "minutes", "loss_scale": 1.,
                "x": np.zeros((96, 2)), "y": np.ones(96) * 2,
                "ids": [f"r{i}" for i in range(96)], "groups": ["bearing"] * 96,
                "scale": np.ones(2), "reported_baseline": {"rmse": 10.}}

    def test_observation_never_contains_unreleased_targets_or_future_losses(self):
        m = self.module()
        seen = []
        def decide(context):
            seen.append(context)
            return {"action": "DO_NOTHING", "reason": "证据不足。", "source": "offline_mock"}
        with tempfile.TemporaryDirectory() as tmp:
            result = m.replay_partition(self.data(), list(range(96)), "train", "abrupt", Path(tmp)/"run",
                                        ConstantModel(), decide, decision_steps=(3, 7), trainer=None)
            events = [json.loads(s) for s in (Path(tmp)/"run/events.jsonl").read_text().splitlines()]
        self.assertEqual(len(seen), 2)
        for context in seen:
            observation = context["observation"]
            self.assertLessEqual(max(v["source_step"] for v in observation["loss_trend"]), context["step"] - 1)
            self.assertNotIn("target", json.dumps(observation))
            self.assertNotIn("reported_baseline", observation)
        predictions = [e for e in events if e["event"] == "prediction"]
        self.assertEqual(len(predictions), 12)
        self.assertEqual(result["updates"], 0)
        self.assertEqual(result["static_metrics"]["rmse"], 2.)

    def test_screening_reject_cannot_become_a_successful_teacher_label(self):
        m = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            result = m.replay_partition(self.data(), list(range(96)), "train", "stable", Path(tmp)/"run",
                ConstantModel(), lambda _: {"action": "RETRAIN_SMALL", "reason": "尝试候选。", "source": "teacher"},
                decision_steps=(3,), trainer=lambda *args: (ConstantModel(), .01))
        self.assertEqual(result["updates"], 0)
        self.assertFalse(result["records"][0]["qualified"])
        self.assertIn("selection", result["records"][0]["rejection"])

    def test_resume_parent_and_future_gate_are_strictly_separated(self):
        m = self.module()
        parents = []
        class Better(ConstantModel):
            checkpoint_sha256 = "candidate"
            steps = 11
            def predict(self, x):
                return np.full(len(x), 2.)
        def train(parent, x, y, allowance):
            parents.append((parent.checkpoint_sha256, len(y), allowance))
            return Better(), .02
        with tempfile.TemporaryDirectory() as tmp:
            result = m.replay_partition(self.data(), list(range(96)), "train", "stable", Path(tmp)/"run",
                ConstantModel(), lambda _: {"action": "RETRAIN_SMALL", "reason": "尝试候选。", "source": "teacher"},
                decision_steps=(3,), trainer=train)
            events = [json.loads(s) for s in (Path(tmp)/"run/events.jsonl").read_text().splitlines()]
        freeze = next(e for e in events if e["event"] == "candidate_frozen")
        deploy = next(e for e in events if e["event"] == "deploy")
        self.assertGreater(deploy["gate_min_source_step"], freeze["step"])
        self.assertEqual(parents[0][0], "initial")
        self.assertLessEqual(parents[0][2], 5.)
        self.assertFalse(result["records"][0]["qualified"])
        self.assertTrue(result["records"][0]["outcome_supported"])
        self.assertEqual(result["records"][0]["rejection"], "reason_audit_required")
        self.assertEqual(result["records"][0]["evidence"]["candidate_parent_checkpoint"], "initial")

    def test_lower_c_rmse_with_new_overestimates_is_not_qualified(self):
        m = self.module()
        class Overestimating(ConstantModel):
            checkpoint_sha256 = "overestimating"
            def predict(self, x):
                return np.full(len(x), 2.5)
        data = {**self.data(), "profile": "C", "unit": "cycles"}
        with tempfile.TemporaryDirectory() as tmp:
            result = m.replay_partition(data, list(range(96)), "train", "stable", Path(tmp)/"run",
                ConstantModel(), lambda _: {"action": "RETRAIN_LARGE", "reason": "评估候选。", "source": "teacher"},
                decision_steps=(3,), trainer=lambda *args: (Overestimating(), .01))
        self.assertGreater(result["paired_primary_gain"], 0)
        self.assertFalse(result["records"][0]["qualified"])
        self.assertEqual(result["records"][0]["rejection"], "c_overestimation_not_safe")

    def test_asymmetric_policy_is_forwarded_only_for_official_c_head_candidates(self):
        m = self.module()
        data = {**self.data(), "profile": "C", "unit": "cycles"}
        calls = []
        class Better(ConstantModel):
            checkpoint_sha256 = "asymmetric-candidate"
            def predict(self, x):
                return np.full(len(x), 2.)
        def train(parent, x, y, allowance, **options):
            calls.append((len(y), allowance, options))
            return Better(), .01
        with tempfile.TemporaryDirectory() as tmp:
            result = m.replay_partition(data, list(range(96)), "train", "stable", Path(tmp)/"run",
                ConstantModel(), lambda _: {"action": "RETRAIN_HEAD_ONLY", "reason": "固定损失消融。"},
                decision_steps=(3,), trainer=train, action_profile="official_finetune",
                candidate_loss_policy="overestimate_2x")
        self.assertEqual(calls[0][2], {"trainable_policy": "head_only", "loss_policy": "overestimate_2x"})
        self.assertEqual(result["records"][0]["evidence"]["loss_policy"], "overestimate_2x")
        self.assertEqual(result["records"][0]["evidence"]["fit_audit"], {})

        bearing = {**data, "profile": "B", "unit": "minutes"}
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp)/"run"
            with self.assertRaises(ValueError):
                m.replay_partition(bearing, list(range(96)), "train", "stable", output,
                    ConstantModel(), lambda _: None, action_profile="official_finetune",
                    candidate_loss_policy="overestimate_2x")
            self.assertFalse(output.exists())

    def test_a_replay_replaces_oldest_training_rows_without_touching_screen_or_future_gate(self):
        m = self.module()
        rows = 960
        data = {"profile": "A", "task": "classification", "unit": None, "loss_scale": 1.,
            "x": np.column_stack((np.arange(rows, dtype=float), np.zeros(rows))),
            "y": np.ones(rows, dtype=int), "ids": [f"online-{i}" for i in range(rows)],
            "groups": ["batch:1"] * rows, "scale": np.ones(2),
            "replay_reserve": {"x": np.column_stack((10000 + np.arange(48), np.zeros(48))),
                "y": np.full(48, 2, dtype=int), "ids": [f"official-{i}" for i in range(48)],
                "class_counts": dict.fromkeys(m.OFFICIAL_A_CLASSES, 8),
                "selection_policy": "sha256_ranked_8_per_class_v1"}}
        parent = ConstantClassifier(2, "initial-a")
        seen = {}
        def train(_parent, features, targets, allowance, **options):
            seen["x"], seen["y"], seen["allowance"], seen["options"] = (
                np.asarray(features).copy(), np.asarray(targets).copy(), allowance, options)
            return ConstantClassifier(1, "candidate-a"), .02
        with tempfile.TemporaryDirectory() as tmp:
            result = m.replay_partition(data, list(range(rows)), "train", "stable", Path(tmp)/"run",
                parent, lambda _: {"action": "RETRAIN_LARGE", "reason": "固定回放消融。"},
                decision_steps=(3,), trainer=train, a_replay_policy="class_balanced_official_train")
            events = [json.loads(line) for line in (Path(tmp)/"run/events.jsonl").read_text(encoding="utf-8").splitlines()]
        evaluated = next(event for event in events if event["event"] == "candidate_evaluated")
        gate = next(event for event in events if event["event"] == "deploy")
        self.assertEqual(evaluated["decision_id"], "A-train-stable-3")
        self.assertEqual(seen["x"].shape, (192, 2))
        np.testing.assert_array_equal(seen["x"][:48], data["replay_reserve"]["x"])
        np.testing.assert_array_equal(seen["x"][48:], data["x"][48:192])
        np.testing.assert_array_equal(seen["y"][:48], data["replay_reserve"]["y"])
        np.testing.assert_array_equal(seen["y"][48:], data["y"][48:192])
        self.assertEqual(seen["allowance"], 5.)
        self.assertEqual(seen["options"], {})
        self.assertEqual(evaluated["train_samples"], 192)
        self.assertEqual(evaluated["screening_samples"], 48)
        self.assertEqual(evaluated["replay_source_ids"], data["replay_reserve"]["ids"])
        self.assertEqual(evaluated["replaced_online_source_ids"], data["ids"][:48])
        self.assertEqual(evaluated["train_source_ids"],
                         data["replay_reserve"]["ids"] + data["ids"][48:192])
        self.assertEqual(evaluated["screening_source_ids"], data["ids"][192:240])
        self.assertEqual(gate["source_ids"], data["ids"][320:400])
        self.assertFalse(set(evaluated["replay_source_ids"]) & set(evaluated["screening_source_ids"]))
        self.assertFalse(set(evaluated["replay_source_ids"]) & set(gate["source_ids"]))
        self.assertEqual(result["updates"], 1)

    def test_real_official_worker_returns_wall_time_and_continues_current_adam_state(self):
        m = self.module()
        from ite.official_model import OfficialModelAdapter
        from ite.official_sft_data import load_public_package
        root = Path(__file__).resolve().parents[1]
        runtime = Path(os.environ.get("ITE_OFFICIAL_RUNTIME_PYTHON", root/".venv-official-a/Scripts/python.exe"))
        if not runtime.is_file():
            self.skipTest("Official isolated runtime is not provisioned")
        data = load_public_package("B")
        parent = OfficialModelAdapter("regression", runtime, profile_type="B")
        checkpoint, steps = parent.checkpoint_sha256, parent.steps
        candidate, seconds = m._bounded_fit(parent, data["x"][:24], data["y"][:24], 5.)
        self.assertGreater(candidate.steps, steps)
        self.assertEqual(parent.checkpoint_sha256, checkpoint)
        self.assertNotEqual(candidate.checkpoint_sha256, checkpoint)
        self.assertTrue(0 < seconds <= 5.)
        np.testing.assert_array_equal(candidate.mean, parent.mean)
        np.testing.assert_array_equal(candidate.std, parent.std)


if __name__ == "__main__":
    unittest.main()
