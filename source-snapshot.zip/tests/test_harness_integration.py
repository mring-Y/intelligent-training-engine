"""Small protocol runs, not a performance-selection or tuning matrix."""

import json
import tempfile
import unittest
from pathlib import Path

import numpy as np

from ite.config import ExperimentConfig
from ite.models import RidgeModel
from ite.runner import run_comparison
from test_harness_control import InlineTrainer


class HarnessIntegrationTests(unittest.TestCase):
    def test_example_config_enables_guard_and_report_identifies_simulated_cost(self):
        config = ExperimentConfig.load(Path(__file__).resolve().parents[1] / "configs/harness-mock.json")
        with tempfile.TemporaryDirectory() as directory:
            summary = run_comparison(config, directory, policies=("drift",), trainer=InlineTrainer())[0]
            self.assertEqual(summary["token_accounting_mode"], "mock")
            self.assertIn("模拟 Token", (Path(directory) / "report.html").read_text(encoding="utf-8"))

    def config(self, **overrides):
        return ExperimentConfig.from_dict({"harness_enabled": True, "deployment_validation": "future",
            "training_preflight": True, "candidate_feasibility": True, "max_tokens": 1000,
            **overrides})

    def events(self, root):
        return [json.loads(line) for line in (root / "events.jsonl").read_text().splitlines()]

    def test_fault_modes_continue_every_prediction_and_stop_all_future_spending(self):
        for mode, reason in (("invalid_json", "invalid_action"),
                             ("token_exhausted", "provider_token_exhausted")):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as directory:
                trainer = InlineTrainer()
                summary = run_comparison(self.config(harness_mock_mode=mode), directory,
                                         policies=("drift",), trainer=trainer)[0]
                root = Path(directory) / "drift"
                events = self.events(root)
                trip = next(e for e in events if e["event"] == "budget_guard_tripped")
                self.assertEqual(summary["harness_trip_reason"], reason)
                self.assertEqual(summary["harness_state"], "STATIC_FALLBACK")
                self.assertEqual((summary["llm_calls"], summary["mock_tokens"], summary["real_llm_tokens"]), (1, 8, 0))
                self.assertEqual(summary["labels_requested"], trip["labels_requested"])
                self.assertEqual(summary["updates"], 0)
                self.assertEqual(summary["stream_batches"], 36)
                self.assertEqual(len([e for e in events if e["event"] == "prediction"]), 36)
                self.assertEqual(trainer.calls, [])
                self.assertEqual(events[-1]["event"], "run_completed")
                np.testing.assert_array_equal(RidgeModel.load(root / "initial.npz").weights,
                                              RidgeModel.load(root / "deployed.npz").weights)

    def test_low_token_budget_trips_before_first_call_and_stops_labels(self):
        with tempfile.TemporaryDirectory() as directory:
            summary = run_comparison(self.config(max_tokens=10), directory,
                                     policies=("drift",), trainer=InlineTrainer())[0]
            events = self.events(Path(directory) / "drift")
            trip = next(e for e in events if e["event"] == "budget_guard_tripped")
            self.assertEqual(summary["llm_calls"], 0)
            self.assertEqual(summary["labels_requested"], trip["labels_requested"])
            self.assertEqual(summary["tokens"], 0)
            self.assertEqual(summary["stream_batches"], 36)

    def test_last_label_trips_guard_while_inflight_labels_still_release_for_audit(self):
        with tempfile.TemporaryDirectory() as directory:
            summary = run_comparison(self.config(max_labels=144), directory,
                                     policies=("drift",), trainer=InlineTrainer())[0]
            events = self.events(Path(directory) / "drift")
            trip = next(e for e in events if e["event"] == "budget_guard_tripped")
            self.assertEqual(summary["labels_requested"], 144)
            self.assertEqual(summary["labels_released"], 144)
            self.assertTrue(any(e["event"] == "labels_released" and e["step"] > trip["step"] for e in events))
            self.assertEqual(summary["stream_batches"], 36)
            self.assertFalse(any(e["event"] == "harness_call" and e["step"] >= trip["step"] for e in events))

    def test_stable_abrupt_gradual_run_real_worker_and_prospective_gate(self):
        for task in ("classification", "regression"):
            for scenario in ("stable", "abrupt", "gradual"):
                with self.subTest(task=task, scenario=scenario), tempfile.TemporaryDirectory() as directory:
                    summary = run_comparison(self.config(task=task, scenario=scenario), directory,
                                             policies=("drift",))[0]
                    root = Path(directory) / "drift"
                    events = self.events(root)
                    self.assertEqual(summary["stream_batches"], 36)
                    self.assertEqual(summary["real_llm_tokens"], 0)
                    self.assertLess(summary["mock_tokens"], 800)
                    self.assertTrue(any(e["event"] == "harness_observation" for e in events))
                    self.assertTrue(any(e["event"] == "harness_decision" for e in events))
                    if scenario == "stable":
                        self.assertEqual(summary["training_attempts"], 0)
                        self.assertEqual(summary["updates"], 0)
                    else:
                        self.assertGreater(summary["training_attempts"], 0)
                        self.assertGreater(summary["candidates_frozen"], 0)
                        self.assertGreater(summary["updates"], 0)
                        for event in events:
                            if event["event"] == "deploy":
                                self.assertGreater(event["gate_min_source_step"], event["frozen_at"])
                                self.assertGreaterEqual(event["gate_samples"], 32)
                                next_prediction = next(e for e in events if e["event"] == "prediction" and
                                                       e["step"] == event["step"] + 1)
                                self.assertEqual(next_prediction["model_version"], event["model_version"])

    def test_disabled_harness_and_static_policy_keep_old_behavior(self):
        with tempfile.TemporaryDirectory() as directory:
            summary = run_comparison(self.config(harness_mock_mode="invalid_json"), directory,
                                     policies=("static",), trainer=InlineTrainer())[0]
            events = self.events(Path(directory) / "static")
            self.assertEqual(summary["labels_requested"], 0)
            self.assertFalse(any(e["event"].startswith("harness_") for e in events))
        with tempfile.TemporaryDirectory() as directory:
            summary = run_comparison(ExperimentConfig(), directory, policies=("drift",),
                                     trainer=InlineTrainer())[0]
            self.assertEqual(summary["tokens"], 0)
            self.assertGreater(summary["updates"], 0)


if __name__ == "__main__":
    unittest.main()
