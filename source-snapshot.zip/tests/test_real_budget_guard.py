"""Real calls reserve durable worst-case tokens and yuan before transmission."""

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from ite.budget import ResourceBudget
from ite.config import ExperimentConfig
from ite.harness import LLMReply
from ite.tracking import JsonlLogger


class RealReplyClient:
    token_accounting_mode = "real"
    max_input_tokens = 2048
    max_output_tokens = 512
    input_price_per_million = "8.41"
    output_price_per_million = "25.29"

    def __init__(self, reply):
        self.reply, self.calls = reply, 0

    def get_decision(self, observation):
        self.calls += 1
        return self.reply


class RealBudgetGuardTests(unittest.TestCase):
    def test_parsed_action_remains_auditable_when_guard_blocks_execution(self):
        with tempfile.TemporaryDirectory() as root:
            guard, budget, logger, ledger = self.run_guard(root)
            observation = self.observation(budget)
            try:
                reply = LLMReply('{"action":"RETRAIN_SMALL","reason":"observed"}', 3600, "real", 3000, 600, "stop")
                self.assertIsNone(guard.get_decision(observation, RealReplyClient(reply), 5))
            finally:
                logger.close()
            events = [json.loads(line) for line in logger.path.read_text().splitlines()]
            call = next(e for e in events if e["event"] == "harness_call")
            self.assertEqual(call["parsed_action"], {"action": "RETRAIN_SMALL", "reason": "observed"})
            self.assertEqual(call["observation"], observation)
            self.assertEqual(guard.state, "STATIC_FALLBACK")

    def run_guard(self, root, name="ledger.json", **overrides):
        from ite.budget_guard import BudgetGuard
        from ite.llm_ledger import CallLedger
        config = ExperimentConfig(harness_enabled=True, deployment_validation="future",
            training_preflight=True, candidate_feasibility=True, max_tokens=40000,
            label_mode="provided", **overrides)
        budget = ResourceBudget(config)
        count = len(list(Path(root).glob("*.events.jsonl")))
        logger = JsonlLogger(Path(root) / f"{name}.{count}.events.jsonl", "real-test")
        ledger = CallLedger(Path(root) / name, identity="smoke-qwen38")
        return BudgetGuard(budget, logger, ledger=ledger), budget, logger, ledger

    def observation(self, budget):
        return {"loss_trend": [], "drift_alarm": True,
                "remaining_label_budget": None,
                "remaining_token_budget": budget.config.max_tokens - budget.tokens,
                "model_age_batches": 20}

    def test_actual_usage_settles_server_input_and_output_tokens(self):
        with tempfile.TemporaryDirectory() as root:
            guard, budget, logger, ledger = self.run_guard(root)
            try:
                client = RealReplyClient(LLMReply('{"action":"DO_NOTHING","reason":"observed"}',
                    150, "real", 137, 13, "stop"))
                decision = guard.get_decision(self.observation(budget), client, 23)
                self.assertEqual(decision.action, "DO_NOTHING")
                self.assertEqual((budget.tokens, guard.real_llm_tokens), (150, 150))
                state = ledger.snapshot()
                self.assertEqual((state["used_input_tokens"], state["used_output_tokens"]), (137, 13))
                self.assertEqual(state["estimated_cost_cny"], "0.00148094")
            finally:
                logger.close()

    def test_call_eleven_is_blocked_even_after_guard_process_restarts(self):
        with tempfile.TemporaryDirectory() as root:
            ledger_path = Path(root) / "shared.json"
            first, budget, logger, ledger = self.run_guard(root, "shared.json")
            try:
                for call in range(10):
                    observation = self.observation(budget)
                    first.get_decision(observation, RealReplyClient(
                        LLMReply('{"action":"DO_NOTHING","reason":"ok"}', 1, "real", 1, 0)), call)
            finally:
                logger.close()
            second, budget2, logger2, _ = self.run_guard(root, "shared.json")
            try:
                denied = RealReplyClient(LLMReply('{"action":"DO_NOTHING","reason":"ok"}', 1, "real", 1, 0))
                self.assertIsNone(second.get_decision(self.observation(budget2), denied, 11))
                self.assertEqual(denied.calls, 0)
                self.assertEqual(ledger_path, Path(root) / "shared.json")
                self.assertEqual(second.calls, 10)
                self.assertEqual(second.reason, "llm_call_limit")
            finally:
                logger2.close()

    def test_invalid_json_is_charged_from_actual_usage_then_frozen(self):
        with tempfile.TemporaryDirectory() as root:
            guard, budget, logger, ledger = self.run_guard(root)
            try:
                client = RealReplyClient(LLMReply("{broken", 42, "real", 35, 7, "stop"))
                self.assertIsNone(guard.get_decision(self.observation(budget), client, 4))
                self.assertEqual((budget.tokens, guard.real_llm_tokens, guard.reason), (42, 42, "invalid_action"))
                self.assertEqual(ledger.snapshot()["used_input_tokens"], 35)
            finally:
                logger.close()

    def test_provider_overage_keeps_actual_usage_and_freezes_before_action(self):
        with tempfile.TemporaryDirectory() as root:
            guard, budget, logger, ledger = self.run_guard(root)
            try:
                client = RealReplyClient(LLMReply('{"action":"RETRAIN_SMALL","reason":"ok"}',
                    3600, "real", 3000, 600, "stop"))
                self.assertIsNone(guard.get_decision(self.observation(budget), client, 4))
                self.assertEqual((budget.tokens, guard.real_llm_tokens), (3600, 3600))
                self.assertEqual(guard.reason, "provider_usage_exceeds_reservation")
                self.assertEqual(ledger.snapshot()["used_tokens"], 3600)
            finally:
                logger.close()

    def test_unsettled_reservation_on_restart_fails_closed_without_erasing_exposure(self):
        from ite.llm_ledger import CallLedger
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "interrupted.json"
            ledger = CallLedger(path, identity="smoke-qwen38")
            ledger.reserve(max_calls=10, max_input_tokens=2048, max_output_tokens=512,
                max_total_tokens=40000, max_cost_cny="0.50", input_price_per_million="8.41",
                output_price_per_million="25.29", step=7)
            recovered = CallLedger(path, identity="smoke-qwen38")
            state = recovered.snapshot()
            self.assertEqual((state["attempted_calls"], state["unknown_calls"], state["trip_reason"]),
                             (1, 1, "uncertain_inflight_call"))
            self.assertEqual(state["reserved_cost_cny"], "0.03017216")
            self.assertIsNone(recovered.reserve(max_calls=10, max_input_tokens=2048,
                max_output_tokens=512, max_total_tokens=40000, max_cost_cny="0.50",
                input_price_per_million="8.41", output_price_per_million="25.29", step=8))

    def test_reservation_stops_before_cost_or_eighty_percent_token_limit(self):
        from ite.llm_ledger import CallLedger
        with tempfile.TemporaryDirectory() as root:
            ledger = CallLedger(Path(root) / "guard.json", identity="smoke-qwen38")
            below = ledger.reserve(max_calls=10, max_input_tokens=2048, max_output_tokens=512,
                max_total_tokens=40000, max_cost_cny="0.50", input_price_per_million="8.41",
                output_price_per_million="25.29", step=0)
            ledger.settle(below["call_id"], input_tokens=137, output_tokens=13)
            self.assertIsNotNone(below)
            self.assertIsNone(ledger.reserve(max_calls=10, max_input_tokens=2048, max_output_tokens=512,
                max_total_tokens=40000, max_cost_cny="0.031", input_price_per_million="8.41",
                output_price_per_million="25.29", step=1))
            edge = CallLedger(Path(root) / "edge.json", identity="edge")
            self.assertIsNone(edge.reserve(max_calls=10, max_input_tokens=2048, max_output_tokens=512,
                max_total_tokens=3200, max_cost_cny="0.50", input_price_per_million="8.41",
                output_price_per_million="25.29", step=0))

    def test_corrupted_accounting_cannot_reset_attempts_or_hide_tokens(self):
        from ite.llm_ledger import CallLedger
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "corrupt.json"
            ledger = CallLedger(path, identity="test")
            reservation = ledger.reserve(max_calls=10, max_input_tokens=2048, max_output_tokens=512,
                max_total_tokens=40000, max_cost_cny="0.50", input_price_per_million="8.41",
                output_price_per_million="25.29", step=0)
            ledger.settle(reservation["call_id"], input_tokens=100, output_tokens=20)
            original = json.loads(path.read_text(encoding="utf-8"))
            for change in ({"attempted_calls": 0}, {"used_input_tokens": -1}, {"used_cost_cny": "0"}):
                path.write_text(json.dumps({**original, **change}), encoding="utf-8")
                with self.subTest(change=change), self.assertRaises(RuntimeError):
                    CallLedger(path, identity="test").snapshot()

    def test_timeout_holds_full_exposure_and_latches_after_restart(self):
        class TimeoutClient(RealReplyClient):
            def get_decision(self, observation):
                raise TimeoutError("request submitted, no receipt")
        with tempfile.TemporaryDirectory() as root:
            guard, budget, logger, ledger = self.run_guard(root)
            try:
                self.assertIsNone(guard.get_decision(self.observation(budget), TimeoutClient(None), 3))
                self.assertEqual((guard.calls, budget.tokens, guard.real_llm_tokens), (1, 2560, 0))
                self.assertEqual(guard.snapshot()["llm_reserved_cost_cny"], "0.03017216")
            finally:
                logger.close()
            recovered, _, logger2, _ = self.run_guard(root)
            try:
                self.assertEqual((recovered.state, recovered.reason), ("STATIC_FALLBACK", "client_timeout"))
            finally:
                logger2.close()

    def test_mock_explicit_call_cap_blocks_eleventh_attempt(self):
        from ite.budget_guard import BudgetGuard
        from ite.harness import MockLLMClient
        config = ExperimentConfig(max_tokens=40000, max_llm_calls=10, label_mode="provided")
        budget = ResourceBudget(config)
        with tempfile.TemporaryDirectory() as root:
            with JsonlLogger(Path(root) / "events.jsonl", "mock-cap") as logger:
                guard = BudgetGuard(budget, logger)
                for step in range(10):
                    self.assertIsNotNone(guard.get_decision(self.observation(budget), MockLLMClient(), step))
                self.assertIsNone(guard.get_decision(self.observation(budget), MockLLMClient(), 10))
                self.assertEqual((guard.calls, budget.tokens, guard.reason), (10, 80, "llm_call_limit"))

    def test_shared_ledger_trip_is_seen_before_any_pending_gate_can_deploy(self):
        from ite.llm_ledger import CallLedger
        with tempfile.TemporaryDirectory() as root:
            guard, budget, logger, ledger = self.run_guard(root)
            try:
                CallLedger(ledger.path, identity="smoke-qwen38").trip("client_timeout")
                self.assertFalse(guard.check(5))
                self.assertEqual((guard.state, guard.reason), ("STATIC_FALLBACK", "client_timeout"))
            finally:
                logger.close()

    def test_shared_trip_between_reservation_and_send_blocks_network(self):
        from ite.llm_ledger import CallLedger
        with tempfile.TemporaryDirectory() as root:
            guard, budget, logger, ledger = self.run_guard(root)
            original_reserve = ledger.reserve
            def reserve_then_trip(**kwargs):
                result = original_reserve(**kwargs)
                CallLedger(ledger.path, identity="smoke-qwen38").trip("concurrent_inflight_call")
                return result
            try:
                client = RealReplyClient(LLMReply('{"action":"DO_NOTHING","reason":"ok"}', 1, "real", 1, 0))
                with patch.object(ledger, "reserve", side_effect=reserve_then_trip):
                    self.assertIsNone(guard.get_decision(self.observation(budget), client, 5))
                self.assertEqual(client.calls, 0)
            finally:
                logger.close()


if __name__ == "__main__":
    unittest.main()
