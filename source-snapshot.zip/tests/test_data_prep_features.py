"""Signal fixtures with analytic, independently known feature expectations."""
import unittest

import numpy as np


class BearingFeatureTests(unittest.TestCase):
    def test_constant_signal_has_finite_degenerate_statistics(self):
        from scripts.data_prep.features import signal_features

        result = signal_features(np.full(256, 3.0), sample_rate=256)
        self.assertEqual(result["rms"], 3.0)
        self.assertEqual(result["peak_to_peak"], 0.0)
        self.assertEqual(result["kurtosis"], 0.0)
        self.assertEqual(result["envelope_peak_hz"], 0.0)

    def test_known_sinusoid_has_pearson_kurtosis(self):
        from scripts.data_prep.features import signal_features

        signal = 2.0 * np.sin(2 * np.pi * 32 * np.arange(1024) / 1024)
        result = signal_features(signal, sample_rate=1024)
        self.assertAlmostEqual(result["rms"], np.sqrt(2.0), places=12)
        self.assertAlmostEqual(result["peak_to_peak"], 4.0, places=12)
        self.assertAlmostEqual(result["kurtosis"], 1.5, places=12)

    def test_analytic_envelope_finds_modulation_not_carrier(self):
        from scripts.data_prep.features import signal_features

        time = np.arange(4096) / 4096
        signal = (1 + .4 * np.cos(2 * np.pi * 37 * time)) * np.cos(2 * np.pi * 600 * time)
        self.assertEqual(signal_features(signal, sample_rate=4096)["envelope_peak_hz"], 37.0)

    def test_channel_feature_names_and_values_are_separate(self):
        from scripts.data_prep.features import extract_features

        result = extract_features(np.column_stack((np.ones(128), np.full(128, 2.0))), sample_rate=128)
        self.assertEqual(len(result), 8)
        self.assertEqual(result["ch1_rms"], 1.0)
        self.assertEqual(result["ch2_rms"], 2.0)

    def test_resampling_suppresses_tone_above_new_nyquist(self):
        from scripts.data_prep.features import resample_signal

        time = np.arange(8000) / 8000
        source = np.sin(2 * np.pi * 100 * time) + np.sin(2 * np.pi * 2700 * time)
        result = resample_signal(source, source_rate=8000, target_rate=1000)
        self.assertEqual(result.shape, (1000,))
        frequencies = np.fft.rfftfreq(result.size, 1 / 1000)
        amplitudes = 2 * np.abs(np.fft.rfft(result)) / result.size
        self.assertGreater(amplitudes[np.flatnonzero(frequencies == 100)[0]], .98)
        self.assertLess(amplitudes[np.flatnonzero(frequencies == 300)[0]], .01)

    def test_invalid_signal_or_sampling_rate_is_rejected(self):
        from scripts.data_prep.features import signal_features, resample_signal

        for signal, rate in [(np.array([1.0, np.nan]), 100), (np.ones(8), 0)]:
            with self.assertRaises(ValueError):
                signal_features(signal, sample_rate=rate)
        with self.assertRaises(ValueError):
            resample_signal(np.ones(8), source_rate=8, target_rate=0)


if __name__ == "__main__":
    unittest.main()
