"""Training-only sources, excluded initialization groups, and guarded action labels."""

import copy
import hashlib
import importlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import numpy as np

from ite.official_model import default_package_path


class OfficialSFTCrossfitTests(unittest.TestCase):
    def module(self):
        try:
            return importlib.import_module("ite.official_sft_crossfit")
        except ImportError as error:
            self.fail(f"Cross-fit training-source helpers are missing: {error}")

    def test_training_sources_match_pinned_reports_and_never_read_validation(self):
        m = self.module()
        original = zipfile.ZipFile.read
        def training_only(archive, name, *args, **kwargs):
            if str(name).startswith("public/") and name != "public/train.jsonl":
                raise AssertionError("Training loader accessed non-training labels")
            return original(archive, name, *args, **kwargs)
        with patch.object(zipfile.ZipFile, "read", training_only):
            for profile, size, dimensions, groups in (("A", 445, 128, 1), ("B", 7032, 34, 9),
                                                       ("C", 113089, 24, 496)):
                with self.subTest(profile=profile):
                    data = m.load_public_training_source(profile)
                    self.assertEqual(data["x"].shape, (size, dimensions))
                    self.assertEqual(len(data["rows"]), size)
                    self.assertEqual(len(set(data["ids"])), size)
                    self.assertEqual(len(set(data["groups"])), groups)
                    self.assertEqual(len(data["source_clocks"]), size)
                    self.assertEqual(data["train_sha256"], data["training_report"]["train_sha256"])
                    self.assertTrue(np.isfinite(data["x"]).all())
                    if profile == "A":
                        self.assertEqual(data["y"][0], 1)

    def mutated_package(self, mutate_rows=None, mutate_report=None):
        with zipfile.ZipFile(default_package_path("A")) as archive:
            raw = archive.read("public/train.jsonl")
            report = json.loads(archive.read("training.json"))
        rows = [json.loads(line) for line in raw.splitlines()]
        if mutate_rows:
            mutate_rows(rows)
            raw = b"\n".join(json.dumps(row).encode() for row in rows) + b"\n"
            report["train_sha256"] = "sha256:" + hashlib.sha256(raw).hexdigest()
        if mutate_report:
            mutate_report(report)
        folder = tempfile.TemporaryDirectory()
        self.addCleanup(folder.cleanup)
        path = Path(folder.name) / "source.zip"
        with zipfile.ZipFile(path, "w") as archive:
            archive.writestr("public/train.jsonl", raw)
            archive.writestr("training.json", json.dumps(report))
        return path

    def test_loader_rejects_package_digest_before_loading_rows(self):
        m = self.module()
        with self.assertRaisesRegex(ValueError, "digest"):
            m.load_public_training_source("A", self.mutated_package())

    def test_loader_fails_closed_on_report_rows_features_labels_and_source_metadata(self):
        m = self.module()
        row_mutations = [
            lambda rows: rows[1].update(id=rows[0]["id"]),
            lambda rows: rows[0]["inputs"]["features"].__setitem__(0, float("nan")),
            lambda rows: rows[0]["inputs"].update(features=[0.] * 127),
            lambda rows: rows[1].update(inputs={"different": [0.] * 128}),
            lambda rows: rows[0].update(answer="unknown"),
            lambda rows: rows[1]["meta"].update(source_index=1),
            lambda rows: rows[0]["meta"].update(source_batch=2),
        ]
        report_mutations = [lambda report: report.update(profile="B"),
                            lambda report: report.update(task="regression"),
                            lambda report: report.update(train_rows=444),
                            lambda report: report.update(train_sha256="sha256:" + "0" * 64)]
        # The real digest check is tested above; bypass it only to reach malformed member validation.
        with patch.object(m, "_validate_package", return_value={}):
            for mutation in row_mutations:
                package = self.mutated_package(mutate_rows=mutation)
                with zipfile.ZipFile(package) as archive:
                    digest = hashlib.sha256(archive.read("public/train.jsonl")).hexdigest()
                with self.subTest(mutation=mutation), patch.dict(m._TRAIN, {"A": (445, digest)}), self.assertRaises(ValueError):
                    m.load_public_training_source("A", package)
            for mutation in report_mutations:
                with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                    m.load_public_training_source("A", self.mutated_package(mutate_report=mutation))

    def test_a_forward_folds_use_exact_prefixes_and_sixty_four_row_purges(self):
        m = self.module()
        data = m.load_public_training_source("A")
        folds = m.make_crossfit_folds("A", data)
        self.assertEqual(len(folds), 2)
        for fold, split, stop, start, end in zip(folds, ("train", "eval"), (120, 250),
                                                (184, 314), (314, 445)):
            self.assertEqual(fold["split"], split)
            self.assertEqual(fold["initialization_indices"], list(range(stop)))
            self.assertEqual(fold["purge_indices"], list(range(stop, start)))
            self.assertEqual(fold["replay_indices"], list(range(start, end)))
        bad = {**data, "ids": data["ids"][:-1]}
        with self.assertRaises(ValueError):
            m.make_crossfit_folds("A", bad)

    def test_group_folds_exclude_entire_entities_and_balance_each_source(self):
        m = self.module()
        for profile, count in (("B", 3), ("C", 6)):
            data = m.load_public_training_source(profile)
            folds = m.make_crossfit_folds(profile, data)
            self.assertEqual(folds, m.make_crossfit_folds(profile, data))
            self.assertEqual(len(folds), count)
            train_groups, eval_groups, excluded = set(), set(), []
            for number, fold in enumerate(folds):
                init = set(fold["initialization_indices"])
                held = set(fold["excluded_groups"])
                replay = set(fold["replay_indices"])
                self.assertTrue(fold["fold_id"] and fold["rule_id"])
                self.assertFalse(held & {data["groups"][i] for i in init})
                self.assertFalse(init & replay)
                self.assertEqual(init, {i for i, g in enumerate(data["groups"]) if g not in held})
                self.assertEqual({data["groups"][i] for i in replay}, set(fold["replay_groups"]))
                self.assertEqual(fold["split"], "train" if number < (2 if profile == "B" else 4) else "eval")
                (train_groups if fold["split"] == "train" else eval_groups).update(fold["replay_groups"])
                excluded.append(set(fold.get("heldout_groups", fold["excluded_groups"])))
                if profile == "B":
                    self.assertEqual(len(fold.get("heldout_groups", fold["excluded_groups"])), 3)
                else:
                    self.assertEqual(len(fold["replay_groups"]), 4)
                    self.assertEqual({g.split(":")[0] for g in fold["replay_groups"]},
                                     {"FD001", "FD002", "FD003", "FD004"})
            self.assertFalse(train_groups & eval_groups)
            global_eval = set.union(*(set(fold.get("heldout_groups", fold["excluded_groups"]))
                                      for fold in folds if fold["split"] == "eval"))
            for fold in folds:
                self.assertFalse(global_eval & {data["groups"][i] for i in fold["initialization_indices"]})
            self.assertEqual(sum(map(len, excluded)), len(set(data["groups"])))
            self.assertEqual(set.union(*excluded), set(data["groups"]))
            if profile == "C":
                for subset in ("FD001", "FD002", "FD003", "FD004"):
                    sizes = [sum(g.startswith(subset + ":") for g in held) for held in excluded]
                    self.assertLessEqual(max(sizes) - min(sizes), 1)

    def outcome(self, action, old, new, seconds=1):
        return {"action": action, "evidence": {"future_gate": {"accepted": True,
            "source_step": 8, "frozen_at": 7}, "deployment_version": 1, "train_seconds": seconds,
            "post_deployment_static": {"samples": 10, **old},
            "post_deployment_active": {"samples": 10, **new}}}

    def test_action_selector_enforces_all_package_guards(self):
        m = self.module()
        for profile, old, new, guard in (
            ("A", {"macro_f1": .5, "accuracy": .8}, {"macro_f1": .6, "accuracy": .8}, "accuracy"),
            ("B", {"rmse": 10., "mae": 8.}, {"rmse": 9., "mae": 8.}, "mae"),
            ("C", {"rmse": 10., "overestimate_rate": .3, "mean_overestimate": 2.},
             {"rmse": 9., "overestimate_rate": .3, "mean_overestimate": 2.}, "overestimate_rate"),
            ("C", {"rmse": 10., "overestimate_rate": .3, "mean_overestimate": 2.},
             {"rmse": 9., "overestimate_rate": .3, "mean_overestimate": 2.}, "mean_overestimate")):
            good = self.outcome("RETRAIN_LARGE", old, new)
            self.assertEqual(m.choose_counterfactual_action(profile, [good]), "RETRAIN_LARGE")
            bad = copy.deepcopy(good)
            bad["evidence"]["post_deployment_active"][guard] += (-.01 if profile == "A" else .01)
            self.assertEqual(m.choose_counterfactual_action(profile, [bad]), "DO_NOTHING")

    def test_action_selector_rejects_unpaired_missing_or_nonfuture_evidence(self):
        m = self.module()
        good = self.outcome("RETRAIN_LARGE", {"rmse": 10., "mae": 8.}, {"rmse": 9., "mae": 7.})
        mutations = [lambda e: e["future_gate"].update(accepted=False),
                     lambda e: e["future_gate"].update(source_step=7),
                     lambda e: e.pop("deployment_version"),
                     lambda e: e.pop("train_seconds"),
                     lambda e: e["post_deployment_active"].update(samples=9),
                     lambda e: e["post_deployment_active"].update(rmse=float("nan")),
                     lambda e: e["post_deployment_active"].update(rmse=10.)]
        for mutation in mutations:
            bad = copy.deepcopy(good)
            mutation(bad["evidence"])
            self.assertEqual(m.choose_counterfactual_action("B", [bad]), "DO_NOTHING")
        self.assertEqual(m.choose_counterfactual_action("B", []), "DO_NOTHING")

    def test_action_selector_ranks_gain_then_time_then_action_name(self):
        m = self.module()
        old = {"rmse": 10., "mae": 8.}
        large = self.outcome("RETRAIN_LARGE", old, {"rmse": 8., "mae": 7.}, 2.)
        head = self.outcome("RETRAIN_HEAD_ONLY", old, {"rmse": 9., "mae": 7.}, .5)
        self.assertEqual(m.choose_counterfactual_action("B", [head, large]), "RETRAIN_LARGE")
        head["evidence"]["post_deployment_active"]["rmse"] = 8.
        self.assertEqual(m.choose_counterfactual_action("B", [large, head]), "RETRAIN_HEAD_ONLY")
        head["evidence"]["train_seconds"] = 2.
        self.assertEqual(m.choose_counterfactual_action("B", [large, head]), "RETRAIN_HEAD_ONLY")

    def test_selector_rejects_incomplete_runs_and_unrecognized_contracts(self):
        m = self.module()
        for profile, outcomes in (("Z", []), ("A", [{"action": "UNKNOWN"}]),
                                  ("B", [{"action": "RETRAIN_LARGE", "status": "training_error"}])):
            with self.assertRaises(ValueError):
                m.choose_counterfactual_action(profile, outcomes)
        good = self.outcome("RETRAIN_LARGE", {"rmse": 10., "mae": 8.}, {"rmse": 9., "mae": 7.})
        good["evidence"]["train_seconds"] = -1
        self.assertEqual(m.choose_counterfactual_action("B", [good]), "DO_NOTHING")


if __name__ == "__main__":
    unittest.main()
