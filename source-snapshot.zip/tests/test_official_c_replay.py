"""C historical replay preserves entity provenance, fit size and future gates."""

import copy
import json
import tempfile
import unittest
import zipfile
from collections import Counter
from pathlib import Path

import numpy as np

from ite import official_sft_data as data_module
from ite.official_sft_replay import replay_partition


def training_fixture():
    return [{"id": f"{subset}-{unit}-{cycle}", "answer": 100. - cycle,
             "inputs": {"sensors": [unit + cycle / 10.] * 21, "settings": [1., 2., 3.]},
             "meta": {"source_subset": subset, "source_split": "train", "unit": unit, "cycle": cycle}}
            for subset in ("FD001", "FD002", "FD003", "FD004")
            for unit in range(1, 14) for cycle in (1, 2, 3)]


class CReserveTests(unittest.TestCase):
    def select(self, rows, ids=(), groups=(), **kwargs):
        selector = getattr(data_module, "select_c_replay_reserve", None)
        self.assertTrue(callable(selector), "C source-balanced reserve selector is missing")
        return selector(rows, ids, groups, **kwargs)

    def test_reserve_uses_distinct_engines_and_ignores_target_values_when_ranking(self):
        rows = training_fixture()
        reserve = self.select(rows)
        changed = copy.deepcopy(list(reversed(rows)))
        for row in changed:
            row["answer"] += 1000.
        again = self.select(changed)
        self.assertEqual(reserve["ids"], again["ids"])
        self.assertEqual(len(set(reserve["groups"])), 48)
        self.assertEqual(Counter(group.split(":")[0] for group in reserve["groups"]),
                         {"FD001": 12, "FD002": 12, "FD003": 12, "FD004": 12})
        np.testing.assert_array_equal(again["y"], reserve["y"] + 1000.)
        np.testing.assert_array_equal(again["x"], reserve["x"])
        lookup = {row["id"]: row for row in rows}
        for index, identity in enumerate(reserve["ids"]):
            row = lookup[identity]
            values, _ = data_module.flatten_features(row["inputs"])
            np.testing.assert_array_equal(reserve["x"][index], values)
            self.assertEqual(reserve["y"][index], row["answer"])

    def test_reserve_rejects_entity_or_id_overlap_and_missing_sources(self):
        rows = training_fixture()
        for ids, groups, subset in (([rows[0]["id"]], [], rows),
                                    ([], ["FD001:0001"], rows),
                                    ([], [], [r for r in rows if r["meta"]["source_subset"] != "FD004"]),
                                    ([], [], [r for r in rows if r["meta"]["unit"] < 12]),
                                    ([], [], rows + [rows[0]])):
            with self.subTest(ids=ids, groups=groups, rows=len(subset)), self.assertRaises(ValueError):
                self.select(subset, ids, groups)

    def test_reserve_rejects_nonfinite_labels_and_wrong_feature_identity(self):
        rows = training_fixture()
        for field, value in (("answer", float("nan")), ("answer", -1.),
                             ("inputs", {"different": [0.] * 24})):
            changed = copy.deepcopy(rows)
            for row in changed:
                row[field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                self.select(changed, feature_paths=["sensors[0]"] * 24)

    def test_actual_c_reserve_matches_immutable_package_rows_and_disjoint_entities(self):
        from ite.official_model import default_package_path
        data = data_module.load_public_package("C")
        self.assertTrue("replay_reserve" in data, "C loader does not expose historical replay provenance")
        reserve = data["replay_reserve"]
        self.assertEqual(reserve["x"].shape, (48, 24))
        self.assertEqual(reserve["subset_counts"], dict.fromkeys(("FD001", "FD002", "FD003", "FD004"), 12))
        self.assertEqual(len(set(reserve["groups"])), 48)
        self.assertFalse(set(reserve["ids"]) & set(data["ids"]))
        self.assertFalse(set(reserve["groups"]) & set(data["groups"]))
        with zipfile.ZipFile(default_package_path("C")) as archive:
            originals = {r["id"]: r for r in map(json.loads, archive.read("public/train.jsonl").decode().splitlines())}
        for index, identity in enumerate(reserve["ids"]):
            values, paths = data_module.flatten_features(originals[identity]["inputs"])
            self.assertEqual(paths, data["feature_paths"])
            np.testing.assert_array_equal(values, reserve["x"][index])
            self.assertEqual(originals[identity]["answer"], reserve["y"][index])


class ReplayModel:
    task = "regression"
    mean = np.zeros(24)
    std = np.ones(24)
    candidate_epochs = 5

    def __init__(self, prediction=0.):
        self.value = prediction
        self.checkpoint_sha256 = "initial" if prediction == 0. else "candidate"
        self.steps = 10 if prediction == 0. else 25

    def predict(self, x):
        return np.full(len(x), self.value)


class CReplayTests(unittest.TestCase):
    def data(self, rows=2400):
        reserve = {"x": np.full((48, 24), -100.), "y": np.full(48, 3.),
            "ids": [f"historical-{i}" for i in range(48)],
            "groups": [f"FD{subset:03d}:{unit:04d}" for subset in range(1, 5) for unit in range(1, 13)],
            "subset_counts": dict.fromkeys(("FD001", "FD002", "FD003", "FD004"), 12),
            "selection_policy": "sha256_ranked_12_engines_per_subset_v1"}
        return {"profile": "C", "task": "regression", "unit": "cycles", "loss_scale": 1.,
            "x": np.repeat(np.arange(rows, dtype=float)[:, None], 24, axis=1),
            "y": np.full(rows, 2.), "ids": [f"online-{i}" for i in range(rows)],
            "groups": ["FD004:0900"] * rows, "scale": np.ones(24), "replay_reserve": reserve}

    def run_replay(self, data, output, trainer, **kwargs):
        return replay_partition(data, list(range(len(data["ids"]))), "train", "abrupt", output,
            ReplayModel(), lambda _: {"action": "RETRAIN_HEAD_ONLY", "reason": "固定来源回放。"},
            decision_steps=(7,), trainer=trainer, action_profile="official_finetune",
            c_replay_policy="source_balanced_official_train", **kwargs)

    def test_replay_replaces_only_oldest_48_and_keeps_screen_gate_and_next_batch_deploy(self):
        data = self.data()
        calls = []
        def train(parent, x, y, allowance, **options):
            calls.append((x.copy(), y.copy(), allowance, options))
            return ReplayModel(2.), .01
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)/"run"
            summary = self.run_replay(data, out, train)
            events = [json.loads(s) for s in (out/"events.jsonl").read_text(encoding="utf-8").splitlines()]
            with np.load(out/"predictions.npz", allow_pickle=False) as arrays:
                self.assertTrue(np.all(arrays["versions"][:2000] == 0))
                self.assertTrue(np.all(arrays["versions"][2000:] == 1))
        self.assertEqual(len(calls), 1)
        x, y, allowance, options = calls[0]
        self.assertEqual(x.shape, (720, 24))
        np.testing.assert_array_equal(x[:48], data["replay_reserve"]["x"])
        np.testing.assert_array_equal(x[48:], data["x"][680:1352] + .75)
        np.testing.assert_array_equal(y, np.r_[np.full(48, 3.), np.full(672, 2.)])
        self.assertEqual((allowance, options), (5., {"trainable_policy": "head_only"}))
        candidate = next(e for e in events if e["event"] == "candidate_evaluated")
        self.assertEqual(candidate["screening_source_ids"], data["ids"][1352:1400])
        self.assertEqual(candidate["replaced_online_source_ids"], data["ids"][632:680])
        self.assertEqual(candidate["train_source_ids"], data["replay_reserve"]["ids"] + data["ids"][680:1352])
        self.assertEqual(candidate["c_replay_policy"], "source_balanced_official_train")
        gate = next(e for e in events if e["event"] == "deploy")
        self.assertEqual((gate["step"], gate["frozen_at"], gate["gate_min_source_step"]), (9, 7, 8))
        self.assertEqual(gate["source_ids"], data["ids"][1600:1800])
        self.assertFalse(set(gate["source_ids"]) & set(candidate["train_source_ids"]))
        self.assertEqual(summary["updates"], 1)
        np.testing.assert_array_equal(data["replay_reserve"]["x"], np.full((48, 24), -100.))

    def test_replay_refuses_future_ids_or_validation_entities_before_training(self):
        for field, value in (("ids", "online-2200"), ("groups", "FD004:0900")):
            data = self.data()
            data["replay_reserve"][field][0] = value
            with self.subTest(field=field), tempfile.TemporaryDirectory() as tmp:
                with self.assertRaises(ValueError):
                    self.run_replay(data, Path(tmp)/"run", None)

    def test_replay_refuses_other_profiles_and_loss_changes_before_creating_outputs(self):
        for change, options in (({"profile": "B"}, {}), ({}, {"candidate_loss_policy": "overestimate_2x"})):
            with self.subTest(change=change), tempfile.TemporaryDirectory() as tmp:
                out = Path(tmp)/"run"
                with self.assertRaises(ValueError):
                    self.run_replay({**self.data(), **change}, out, None, **options)
                self.assertFalse(out.exists())

    def test_short_history_fails_closed_without_supplementing_training_size(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = self.run_replay(self.data(1200), Path(tmp)/"run", None)
        self.assertEqual(result["training_attempts"], 0)
        self.assertEqual(result["updates"], 0)
        self.assertEqual(result["records"][0]["rejection"], "insufficient_online_train_rows_for_c_replay")


if __name__ == "__main__":
    unittest.main()
