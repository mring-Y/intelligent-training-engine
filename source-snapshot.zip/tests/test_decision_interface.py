import unittest

from ite.config import ExperimentConfig


class ReplyProvider:
    def __init__(self, reply=None, error=None):
        self.reply, self.error = reply, error

    def propose(self, context, max_tokens):
        if self.error:
            raise self.error
        return self.reply


class DecisionInterfaceTests(unittest.TestCase):
    def decide(self, provider, remaining=64):
        from ite.decision import DecisionAdvisor
        return DecisionAdvisor(provider).decide((192, 384), (.1, 10.),
            {"recent_loss": .4, "labeled_count": 100}, remaining)

    def test_valid_mock_advice_is_confined_to_permitted_search_space(self):
        result = self.decide(ReplyProvider({"windows": [192], "alphas": [.1], "usage_tokens": 8}))
        self.assertEqual(result.windows, (192,))
        self.assertEqual(result.alphas, (.1,))
        self.assertEqual(result.charged_tokens, 8)

    def test_invalid_out_of_range_or_service_failure_falls_back_to_rules(self):
        for provider in (
            ReplyProvider({"windows": [1], "alphas": [.1], "usage_tokens": 8}),
            ReplyProvider({"windows": [True], "alphas": [.1], "usage_tokens": 8}),
            ReplyProvider({"windows": [192], "alphas": [float("nan")], "usage_tokens": 8}),
            ReplyProvider({"windows": [192], "alphas": [.1], "usage_tokens": 999}),
            ReplyProvider("malformed"), ReplyProvider(error=OSError("offline"))):
            with self.subTest(provider=provider):
                result = self.decide(provider)
                self.assertEqual(result.windows, (192, 384))
                self.assertEqual(result.alphas, (.1, 10.))
                self.assertLessEqual(result.charged_tokens, 64)
                self.assertEqual(result.status, "fallback")

    def test_exhausted_tokens_do_not_call_provider_or_interrupt_local_decisions(self):
        result = self.decide(ReplyProvider(error=AssertionError("must not be called")), remaining=0)
        self.assertEqual(result.windows, (192, 384))
        self.assertEqual(result.charged_tokens, 0)

    def test_token_budget_refuses_overspend(self):
        from ite.budget import ResourceBudget
        budget = ResourceBudget(ExperimentConfig.from_dict({"max_tokens": 8}))
        budget.record_tokens(8)
        self.assertEqual(budget.snapshot()["tokens"], 8)
        with self.assertRaises(ValueError):
            budget.record_tokens(1)


if __name__ == "__main__":
    unittest.main()
