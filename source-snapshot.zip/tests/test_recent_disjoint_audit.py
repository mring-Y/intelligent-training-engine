"""Offline evidence tests: no trainer, fit, or online target access is needed."""
import csv
import importlib.util
import json
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

from ite.config import ExperimentConfig
from ite.data import make_simulation
from ite.models import RidgeModel
from ite.labeling import LabelScheduler
from ite.controller import AdaptationController
from ite.models import prediction_loss
from ite.tracking import JsonlLogger
from ite.training import TrainingResult

SCRIPT = Path(__file__).resolve().parents[1] / "scripts/analyze_recent_disjoint.py"


def audit_module():
    if not SCRIPT.exists():
        raise AssertionError("The approved offline audit implementation is missing")
    spec = importlib.util.spec_from_file_location("recent_audit", SCRIPT)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class RecentDisjointAuditTests(unittest.TestCase):
    def test_first_window_uses_prediction_version_after_deploy_not_curve_version(self):
        module = audit_module()
        events = [{"event": "prediction", "step": k, "model_version": int(k >= 3)} for k in range(7)]
        events.insert(3, {"event": "deploy", "step": 2, "model_version": 1})
        result = module.first_new_window(events, [20, 20, 20, 1, 2, 3, 99], [10] * 7)
        self.assertEqual(result["start"], 3)
        self.assertEqual(result["steps"], [3, 4, 5])
        self.assertEqual(result["new_loss"], 2)
        self.assertEqual(result["initial_loss"], 10)

    def test_never_deployed_is_explicit_missing_not_zero(self):
        result = audit_module().first_new_window(
            [{"event": "prediction", "step": 0, "model_version": 0}], [2], [2])
        self.assertEqual(result["status"], "not_deployed")
        self.assertIsNone(result["new_loss"])

    def test_two_remaining_batches_are_incomplete_not_three_batch_endpoint(self):
        result = audit_module().first_new_window(
            [{"event": "prediction", "step": k, "model_version": int(k > 0)} for k in range(3)],
            [20, 1, 3], [10] * 3)
        self.assertEqual(result["status"], "incomplete")
        self.assertEqual(result["observed_batches"], 2)
        self.assertIsNone(result["new_loss"])

    def test_deployment_at_last_batch_has_zero_observed_batches_and_incomplete_endpoint(self):
        result = audit_module().first_new_window([
            {"event": "prediction", "step": 0, "model_version": 0},
            {"event": "deploy", "step": 0, "model_version": 1}], [2], [2])
        self.assertEqual(result["status"], "incomplete")
        self.assertEqual(result["observed_batches"], 0)
        self.assertIsNone(result["new_loss"])

    def test_recent_indices_form_identity_complement_and_keep_latest(self):
        ids = np.arange(96)
        event = {"selection_history_indices": list(range(0, 95, 2))}
        train, validation = audit_module().partition_history(ids, event, "recent_disjoint", 96)
        self.assertEqual(len(train), 48)
        self.assertEqual(len(validation), 48)
        self.assertEqual(train[-1], 95)
        self.assertFalse(set(train) & set(validation))
        self.assertEqual(set(train) | set(validation), set(ids))

    def test_recent_corrupt_indices_and_duplicate_identity_fail_closed(self):
        module = audit_module()
        for indices in ([0, 0], [-1], [96], [95], [0.5], [True]):
            with self.subTest(indices=indices), self.assertRaises(ValueError):
                module.partition_history(np.arange(96), {"selection_history_indices": indices}, "recent_disjoint", 96)
        with self.assertRaises(ValueError):
            module.partition_history(np.array([1, 1, 3]), {"selection_history_indices": [0]}, "recent_disjoint", 96)

    def test_chronological_partition_keeps_whole_sources_separate(self):
        ids = np.arange(72)
        train, validation = audit_module().partition_history(ids, {}, "chronological", 24, requested=48)
        self.assertEqual(train.tolist(), list(range(24)))
        self.assertEqual(validation.tolist(), list(range(24, 72)))

    def test_task_specific_route_is_rederived_from_task_and_scenario(self):
        module = audit_module()
        class_config = ExperimentConfig(task="classification", scenario="gradual",
            selection_split="task_specific", deployment_validation="future")
        regression_config = ExperimentConfig(task="regression", scenario="abrupt",
            selection_split="task_specific", deployment_validation="future")
        recurring_config = ExperimentConfig(task="regression", scenario="recurring",
            selection_split="task_specific", deployment_validation="future")
        self.assertEqual(module.selection_rule(class_config), ("recent_disjoint", 24))
        self.assertEqual(module.selection_rule(regression_config), ("recent_disjoint", 48))
        self.assertEqual(module.selection_rule(recurring_config), ("chronological", 48))

    def test_task_specific_classification_partition_uses_latest_48_without_identity_overlap(self):
        module = audit_module()
        config = ExperimentConfig(task="classification", scenario="stable",
            selection_split="task_specific", deployment_validation="future")
        mode, requested = module.selection_rule(config)
        selected = list(range(64, 112, 2))
        train, validation = module.partition_history(np.arange(112),
            {"selection_history_indices": selected}, mode, 96, requested)
        self.assertEqual((len(train), len(validation)), (88, 24))
        self.assertEqual(validation.tolist(), selected)
        self.assertFalse(set(train) & set(validation))
        self.assertEqual(set(train) | set(validation), set(range(112)))

    def test_independent_weight_audit_detects_ess_corruption(self):
        module = audit_module()
        cfg = ExperimentConfig(training_weighting="exponential")
        # Source ages 4 and 0 produce weights 2/3 and 4/3, ESS 1.8.
        event = {"train_samples": 2, "train_min_step": 0, "train_max_step": 4,
                 "training_weighting": "exponential", "training_half_life_batches": 4,
                 "weight_reference_source_step": 9, "weight_min": 2 / 3,
                 "weight_max": 4 / 3, "weight_sum": 2, "effective_sample_size": 1.8}
        module.audit_weights(event, np.array([0, 4]), cfg, 9)
        with self.assertRaisesRegex(ValueError, "effective_sample_size"):
            module.audit_weights({**event, "effective_sample_size": 2}, np.array([0, 4]), cfg, 9)

    def static_fixture(self, root, policy="static", selection_split="chronological"):
        cfg = ExperimentConfig(task="regression", scenario="gradual", n_batches=96,
            deployment_validation="future", training_preflight=True, training_weighting="exponential",
            label_schedule="adaptive", monitor_min_labeled=32, selection_split=selection_split)
        sim = make_simulation(cfg)
        model = RidgeModel.from_state({"task": "regression", "alpha": .1,
            "mean": [0] * 8, "std": [1] * 8, "weights": [.1] * 8, "intercept": 0})
        model.save(root / "initial.npz")
        model.save(root / "deployed.npz")
        predictions = np.array([model.predict(batch.features) for batch in sim.batches])
        losses = sim.scorer.score(predictions)
        (root / "config.json").write_text(json.dumps({**cfg.to_dict(), "policy": policy}))
        events = [{"event": "run_started", "step": -1, "policy": policy, "config": cfg.to_dict(),
                   "source_commit": "a" * 40, "source_sha256": "b" * 64, "source_dirty": False}]
        rows = []
        scheduler = LabelScheduler(cfg)
        used = released = peak = 0
        requested = {}
        for step, loss in enumerate(losses):
            count = scheduler.count(step, used) if policy == "drift" else 0
            used += count
            requested[step] = count
            events.extend([{"event": "prediction", "step": step, "model_version": 0, "samples": 96},
                           {"event": "labels_requested", "step": step, "count": count, "total": used}])
            ready = requested.get(step - 2, 0)
            if ready:
                released += ready
                peak = min(released, 768)
                events.append({"event": "labels_released", "step": step, "count": ready,
                               "latest_source_step": step - 2})
            events.append({"event": "monitor", "step": step, "performance_drop": False})
            rows.append({"step": step, "model_version": 0, "loss": loss, "experiments": 0,
                         "training_attempts": 0, "labels_requested": used, "tokens": 0,
                         "adaptation_train_seconds": 0})
        summary = {"mean_loss": float(np.mean(losses)), "stream_batches": 96, "peak_label_history": peak,
                   "labels_requested": used, "labels_released": released, "remaining_prediction_cache": 0,
                   "experiments": 0, "training_attempts": 0, "training_ess_audit_count": 0,
                   "training_ess_min": None, "training_ess_mean": None, "training_ess_max": None}
        events.append({"event": "run_completed", "step": 96, **summary})
        (root / "events.jsonl").write_text("\n".join(map(json.dumps, events)))
        (root / "summary.json").write_text(json.dumps(summary))
        np.savez_compressed(root / "predictions.npz", predictions=predictions)
        with (root / "curve.csv").open("w", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=rows[0]); writer.writeheader(); writer.writerows(rows)
        return predictions

    def test_drift_ledger_bounds_history_and_rejects_wrong_release_source(self):
        module = audit_module()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.static_fixture(root, policy="drift", selection_split="recent_disjoint")
            run = module.audit_run(root)
            self.assertEqual(run["audit"]["peak_history"], 768)
            events = [json.loads(line) for line in (root / "events.jsonl").read_text().splitlines()]
            next(e for e in events if e["event"] == "labels_released")["latest_source_step"] = 1
            (root / "events.jsonl").write_text("\n".join(map(json.dumps, events)))
            with self.assertRaisesRegex(ValueError, "release source/count"):
                module.audit_run(root)

    def test_pair_analysis_uses_shared_samples_and_saved_first_model(self):
        module = audit_module()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.static_fixture(root)
            run = module.audit_run(root)
            state = run["models"][0].state()
            state["weights"] = [-w for w in state["weights"]]
            model = RidgeModel.from_state(state)
            a = {**run, "models": {**run["models"], 1: model},
                 "first_new_window": {"start": 23}}
            b = {**a, "first_new_window": {"start": 29}}
            result = module.analyze_pair(a, b)
            shared = result["same_samples"]["shared_first3"]
            self.assertEqual((shared["start"], shared["end"]), (29, 31))
            self.assertAlmostEqual(shared["arms"]["control"]["old_new_score_correlation"], -1.)
            self.assertEqual(shared["arms"]["control"]["first_model_loss"],
                             shared["arms"]["recent-disjoint"]["first_model_loss"])

    def test_cli_creates_reviewable_evidence_once_and_preserves_inputs(self):
        module = audit_module()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for arm, split in (("control", "chronological"), ("recent-disjoint", "recent_disjoint")):
                rows = []
                for policy in ("static", "drift"):
                    run_path = root / arm / "regression/gradual/seed-7" / policy
                    run_path.mkdir(parents=True)
                    self.static_fixture(run_path, policy, split)
                    summary = json.loads((run_path / "summary.json").read_text())
                    rows.append({"task": "regression", "scenario": "gradual", "seed": 7,
                                 "policy": policy, "mean_loss": summary["mean_loss"]})
                with (root / arm / "summary.csv").open("w", newline="") as stream:
                    writer = csv.DictWriter(stream, fieldnames=rows[0]); writer.writeheader(); writer.writerows(rows)
            legacy = root / "legacy.csv"
            legacy.write_text("task,scenario,seed,policy,mean_loss\nregression,gradual,7,drift,1\n")
            historical = root / "history"
            shutil.copytree(root / "control", historical)
            original = (root / "control/summary.csv").read_bytes()
            with patch.multiple(module, TASKS=("regression",), SCENARIOS=("gradual",), SEEDS=(7,)):
                self.assertEqual(module.main(["--root", str(root), "--legacy", str(legacy),
                                             "--historical-control", str(historical)]), 0)
                with self.assertRaisesRegex(ValueError, "overwrite"):
                    module.main(["--root", str(root), "--legacy", str(legacy)])
            self.assertEqual((root / "control/summary.csv").read_bytes(), original)
            assessment = json.loads((root / "assessment.json").read_text())
            self.assertFalse(assessment["candidate_passed"])
            self.assertEqual(len(assessment["paired"]), 1)
            self.assertTrue((root / "records/offline-audit.json").exists())
            fingerprints = json.loads((root / "records/offline-audit.json").read_text())["input_sha256"]
            self.assertIn(str(legacy), fingerprints)
            for policy in ("static", "drift"):
                for name in ("config.json", "summary.json", "predictions.npz"):
                    self.assertIn(str(historical / "regression/gradual/seed-7" / policy / name), fingerprints)

    def test_audit_reconstructs_saved_predictions_without_fitting_and_detects_corruption(self):
        module = audit_module()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            predictions = self.static_fixture(root)
            result = module.audit_run(root)
            self.assertEqual(result["audit"]["prediction_batches"], 96)
            self.assertEqual(result["audit"]["checkpoint_max_abs_error"], 0)
            self.assertEqual(result["first_new_window"]["status"], "not_deployed")
            predictions[10, 5] += 1
            np.savez_compressed(root / "predictions.npz", predictions=predictions)
            with self.assertRaisesRegex(ValueError, "checkpoint prediction"):
                module.audit_run(root)

    def test_cli_rejects_incomplete_matrix_without_partial_assessment(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with self.assertRaises((ValueError, FileNotFoundError)):
                audit_module().main(["--root", str(root), "--legacy", str(root / "legacy.csv")])
            self.assertFalse((root / "assessment.json").exists())

    def test_cli_rejects_directory_matrix_identity_mismatching_saved_run(self):
        # Full seed-7 payloads relabelled seed-19 previously passed the audit.
        for task, scenario, seed, swap_policy in (("regression", "gradual", 19, False),
                ("classification", "gradual", 7, False), ("regression", "abrupt", 7, False),
                ("regression", "gradual", 7, True)):
            with self.subTest(task=task, scenario=scenario, seed=seed, swap_policy=swap_policy):
                module = audit_module()
                with tempfile.TemporaryDirectory() as directory:
                    root = Path(directory)
                    for arm, split in (("control", "chronological"), ("recent-disjoint", "recent_disjoint")):
                        rows = []
                        for policy in ("static", "drift"):
                            run_path = root / arm / task / scenario / f"seed-{seed}" / policy
                            run_path.mkdir(parents=True)
                            actual_policy = ({"static": "drift", "drift": "static"}[policy]
                                             if swap_policy else policy)
                            self.static_fixture(run_path, actual_policy, split)
                            summary = json.loads((run_path / "summary.json").read_text())
                            rows.append({"task": task, "scenario": scenario, "seed": seed,
                                         "policy": policy, "mean_loss": summary["mean_loss"]})
                        with (root / arm / "summary.csv").open("w", newline="") as stream:
                            writer = csv.DictWriter(stream, fieldnames=rows[0]); writer.writeheader(); writer.writerows(rows)
                    legacy = root / "legacy.csv"
                    legacy.write_text("task,scenario,seed,policy,mean_loss\nregression,gradual,7,drift,1\n")
                    with patch.multiple(module, TASKS=(task,), SCENARIOS=(scenario,), SEEDS=(seed,)):
                        with self.assertRaisesRegex(ValueError, "run identity"):
                            module.main(["--root", str(root), "--legacy", str(legacy)])
                    self.assertFalse((root / "assessment.json").exists())

    def test_deploy_cannot_bypass_independent_gate_by_removing_or_changing_reason(self):
        module = audit_module()
        for reason in (None, "not_better_on_selection", "legacy"):
            with self.subTest(reason=reason), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                self.static_fixture(root)
                # A duplicate checkpoint and coherent version timeline made this
                # forged deployment pass before every deploy required a gate.
                RidgeModel.load(root / "initial.npz").save(root / "model-v1.npz")
                events = [json.loads(line) for line in (root / "events.jsonl").read_text().splitlines()]
                deploy = {"event": "deploy", "step": 0, "model_version": 1}
                if reason is not None:
                    deploy["reason"] = reason
                events.insert(4, deploy)
                for event in events:
                    if event["event"] == "prediction" and event["step"] > 0:
                        event["model_version"] = 1
                (root / "events.jsonl").write_text("\n".join(map(json.dumps, events)))
                with (root / "curve.csv").open(newline="") as stream:
                    rows = list(csv.DictReader(stream))
                for row in rows:
                    row["model_version"] = 1
                with (root / "curve.csv").open("w", newline="") as stream:
                    writer = csv.DictWriter(stream, fieldnames=rows[0]); writer.writeheader(); writer.writerows(rows)
                with self.assertRaisesRegex(ValueError, "deploy requires independent future gate"):
                    module.audit_run(root)

    def test_duplicate_prediction_cannot_forge_first_actual_new_model_window(self):
        module = audit_module()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.static_fixture(root)
            events = [json.loads(line) for line in (root / "events.jsonl").read_text().splitlines()]
            events.insert(2, {"event": "prediction", "step": 0, "model_version": 1, "samples": 96})
            (root / "events.jsonl").write_text("\n".join(map(json.dumps, events)))
            with self.assertRaisesRegex(ValueError, "exactly one prediction"):
                module.audit_run(root)

    def test_frozen_configuration_matches_preregistered_file_and_rejects_common_mutations(self):
        module = audit_module()
        expected = ExperimentConfig.load(SCRIPT.parent.parent / "configs/optimization-time-decay.json")
        self.assertTrue(hasattr(module, "FROZEN_CONFIG"), "independent preregistered configuration is missing")
        self.assertEqual(module.FROZEN_CONFIG.to_dict(), expected.to_dict())

    def test_shared_protocol_configuration_mutations_are_rejected(self):
        module = audit_module()
        for name, value in (("candidate_alphas", [.2, 20.]), ("min_gain", 0.),
                ("cooldown", 0), ("feature_threshold", .9), ("max_train_seconds", 40.),
                ("max_experiments", 24), ("error_increase", .3), ("min_validation", 48)):
            with self.subTest(name=name), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                self.static_fixture(root)
                config = json.loads((root / "config.json").read_text())
                config[name] = value
                (root / "config.json").write_text(json.dumps(config))
                events = [json.loads(line) for line in (root / "events.jsonl").read_text().splitlines()]
                events[0]["config"][name] = value
                (root / "events.jsonl").write_text("\n".join(map(json.dumps, events)))
                with self.assertRaisesRegex(ValueError, "frozen configuration"):
                    module.audit_run(root)

    def test_incomplete_shared_window_has_null_endpoint_means(self):
        module = audit_module()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.static_fixture(root)
            run = module.audit_run(root)
            run["models"][1] = run["models"][0]
            run["first_new_window"] = {"start": 94}
            shared = module.analyze_pair(run, run)["same_samples"]["shared_first3"]
            self.assertEqual(shared["status"], "incomplete")
            for arm in ("control", "recent-disjoint"):
                self.assertIsNone(shared["arms"][arm]["first_model_loss"])
                self.assertIsNone(shared["arms"][arm]["initial_loss"])
                self.assertIsNone(shared["arms"][arm]["actual_residual"])

    def lifecycle_fixture(self, root):
        """Use real controller/gate/oracle, returning saved models instead of fitting."""
        cfg = ExperimentConfig(task="regression", scenario="gradual", n_batches=96,
            deployment_validation="future", training_preflight=True, training_weighting="exponential",
            label_schedule="adaptive", monitor_min_labeled=32, selection_split="recent_disjoint")
        sim = make_simulation(cfg)
        weights = np.random.default_rng(cfg.seed).normal(size=8)
        weights[1] = 0
        weights /= np.linalg.norm(weights)
        state = {"task": "regression", "alpha": .1, "mean": [0] * 8, "std": [1] * 8,
                 "weights": weights.tolist(), "intercept": 0}
        initial = RidgeModel.from_state(state)

        class SavedCandidateTrainer:
            def fit(self, task, alpha, features, targets, timeout_seconds, **options):
                candidate = RidgeModel.from_state({**state, "alpha": alpha, "weights": (-weights).tolist()})
                return TrainingResult("ok", candidate, .001)

        initial.save(root / "initial.npz"); initial.save(root / "deployed.npz")
        (root / "config.json").write_text(json.dumps({**cfg.to_dict(), "policy": "drift"}))
        scale = float(np.var(sim.initial.validation_y))
        baseline = prediction_loss(cfg.task, sim.initial.validation_y, initial.predict(sim.initial.validation_x), scale)
        cache = {}; predictions = []; rows = []; released_count = peak = 0
        rng = np.random.default_rng(cfg.seed + 100_003)
        scheduler = LabelScheduler(cfg)
        with JsonlLogger(root / "events.jsonl", "drift") as logger:
            logger.event("run_started", -1, policy="drift", config=cfg.to_dict(),
                         source_commit="a" * 40, source_sha256="b" * 64, source_dirty=False)
            controller = AdaptationController(cfg, "drift", initial, baseline, scale, logger,
                                              SavedCandidateTrainer(), root)
            for batch in sim.batches:
                pred = controller.predict(batch.features)
                predictions.append(pred)
                logger.event("prediction", batch.step, model_version=controller.gate.version, samples=96)
                count = scheduler.count(batch.step, controller.budget.labels,
                    controller.performance_drop_active, controller.pending is not None)
                ids = rng.choice(batch.sample_ids, size=count, replace=False)
                accepted = sim.oracle.request(ids, batch.step)
                controller.budget.record_labels(accepted)
                cache.update((int(i), float(pred[int(i) % 96])) for i in ids)
                logger.event("labels_requested", batch.step, count=accepted, total=controller.budget.labels)
                released = sim.oracle.release(batch.step)
                if released is not None:
                    released_count += len(released.targets)
                    logger.event("labels_released", batch.step, count=len(released.targets),
                                 latest_source_step=int(max(released.source_steps)))
                controller.observe(batch, released, cache)
                peak = max(peak, len(controller.history_y))
                if released is not None:
                    for sample_id in released.sample_ids:
                        cache.pop(int(sample_id))
                rows.append({"step": batch.step, "model_version": controller.gate.version,
                             **controller.budget.snapshot()})
            controller.finish(96)
            losses = sim.scorer.score(predictions)
            summary = {"mean_loss": float(np.mean(losses)), "stream_batches": 96,
                "peak_label_history": peak, "labels_released": released_count,
                "remaining_prediction_cache": len(cache), "training_ess_audit_count": controller.training_ess_audit_count,
                "training_ess_min": controller.training_ess_min, "training_ess_mean":
                    controller.training_ess_sum / controller.training_ess_audit_count,
                "training_ess_max": controller.training_ess_max, **controller.budget.snapshot()}
            logger.event("run_completed", 96, **summary)
        for row, loss in zip(rows, losses):
            row["loss"] = loss
        (root / "summary.json").write_text(json.dumps(summary))
        np.savez_compressed(root / "predictions.npz", predictions=predictions)
        with (root / "curve.csv").open("w", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=rows[0]); writer.writeheader(); writer.writerows(rows)

    def test_real_frozen_candidate_future_gate_and_checkpoint_chain_pass(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.lifecycle_fixture(root)
            result = audit_module().audit_run(root)
            self.assertGreater(result["audit"]["counts"]["frozen"], 0)
            self.assertGreater(result["audit"]["counts"]["future_gates"], 0)
            self.assertGreater(result["audit"]["counts"]["deploys"], 0)
            deploy_step = next(e["step"] for e in result["events"] if e["event"] == "deploy")
            self.assertEqual(result["first_new_window"]["start"], deploy_step + 1)
            self.assertEqual(result["first_new_window"]["observed_batches"], 3)

    def test_real_future_gate_rejects_pre_freeze_sources_and_training_while_pending(self):
        for mutation in ("source", "pending_fit"):
            with self.subTest(mutation=mutation), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                self.lifecycle_fixture(root)
                events = [json.loads(line) for line in (root / "events.jsonl").read_text().splitlines()]
                if mutation == "source":
                    deploy = next(e for e in events if e["event"] == "deploy")
                    deploy["gate_min_source_step"] = deploy["frozen_at"]
                    message = "independent future gate"
                else:
                    started = next(e for e in events if e["event"] == "experiment_started")
                    frozen_index = next(i for i, e in enumerate(events) if e["event"] == "candidate_frozen")
                    events.insert(frozen_index + 1, {**started, "step": events[frozen_index]["step"]})
                    message = "no training while candidate pending"
                (root / "events.jsonl").write_text("\n".join(map(json.dumps, events)))
                with self.assertRaisesRegex(ValueError, message):
                    audit_module().audit_run(root)


if __name__ == "__main__":
    unittest.main()
