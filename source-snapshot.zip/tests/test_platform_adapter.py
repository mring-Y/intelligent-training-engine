"""External checkpoint, artifact and independent prediction contracts."""

import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import zipfile

import numpy as np

from ite.official_model import OfficialModelAdapter, default_package_path


ROOT = Path(__file__).resolve().parents[1]
RUNTIME = Path(os.environ.get("ITE_OFFICIAL_RUNTIME_PYTHON",
    ROOT / ".venv-official-a/Scripts/python.exe"))


def rows(profile, member, count=None):
    with zipfile.ZipFile(default_package_path(profile)) as archive:
        values = [json.loads(line) for line in archive.read(member).decode("utf-8").splitlines() if line]
    return values if count is None else values[:count]


def put_rows(path, values):
    path.write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in values), encoding="utf-8")
    return path


def fixture(root, profile, *, count=64):
    with zipfile.ZipFile(default_package_path(profile)) as archive:
        (root / "parent.npz").write_bytes(archive.read("checkpoint.npz"))
    return {"profile": profile, "parent": root / "parent.npz",
        "train": put_rows(root / "train.jsonl", rows(profile, "public/train.jsonl", count)),
        "validation": put_rows(root / "validation.jsonl", rows(profile, "public/validation.jsonl", count))}


class PlatformEntryAvailabilityTests(unittest.TestCase):
    def test_external_round_entry_exists_instead_of_requiring_the_comparison_runner(self):
        self.assertIsNotNone(importlib.util.find_spec("ite.continuation"),
            "A platform round must accept an external parent and explicit files")


class PlatformInputTests(unittest.TestCase):
    def test_platform_rejection_preserves_history_when_it_selects_the_recorded_parent(self):
        from ite.continuation import load_history
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "history.jsonl"
            history = {"event": "round_completed", "profile": "C", "stage_id": "round-1",
                "parent_checkpoint_sha256": "a" * 64, "checkpoint_sha256": "b" * 64,
                "validation_id_hashes": ["c" * 64]}
            start = {"event": "round_started", "profile": "C", "stage_id": "round-1",
                "parent_checkpoint_sha256": "a" * 64, "parent_history_sha256": None}
            path.write_text(json.dumps(start) + "\n" + json.dumps(history) + "\n")
            raw, entries, seen = load_history(path, "a" * 64, "C")
            self.assertEqual(raw, path.read_bytes())
            self.assertEqual(entries[-1]["checkpoint_sha256"], "b" * 64)
            self.assertIn("c" * 64, seen)
            with self.assertRaises(ValueError):
                load_history(path, "d" * 64, "C")

    def test_history_with_a_missing_prior_prefix_cannot_reset_consumed_ids(self):
        from ite.continuation import load_history
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "history.jsonl"
            missing = (json.dumps({"event": "round_completed", "profile": "C",
                "checkpoint_sha256": "a" * 64, "validation_id_hashes": ["c" * 64]}) + "\n").encode()
            kept = [{"event": "round_started", "profile": "C", "stage_id": "round-2",
                "parent_checkpoint_sha256": "a" * 64,
                "parent_history_sha256": hashlib.sha256(missing).hexdigest()},
                {"event": "round_completed", "profile": "C", "stage_id": "round-2",
                "parent_checkpoint_sha256": "a" * 64, "checkpoint_sha256": "b" * 64,
                "validation_id_hashes": ["d" * 64]}]
            path.write_text("".join(json.dumps(row) + "\n" for row in kept))
            with self.assertRaisesRegex(ValueError, "history|prefix"):
                load_history(path, "b" * 64, "C")

    def test_strict_reader_rejects_duplicate_keys_target_features_and_unknown_labels(self):
        from ite.platform_data import read_dataset
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "bad.jsonl"
            for text in ('{"id":"x","id":"y","inputs":{"x":1},"answer":1}\n',
                         '{"id":"x","inputs":{"true_rul":1},"answer":1}\n',
                         '{"id":"x","inputs":{"x":NaN},"answer":1}\n',
                         '{"id":"x","inputs":{"x":1},"answer":true}\n'):
                path.write_text(text, encoding="utf-8")
                with self.subTest(text=text), self.assertRaises(ValueError):
                    read_dataset(path, "B", None)
            bad = rows("A", "public/train.jsonl", 1)
            bad[0]["answer"] = "invented-class"
            put_rows(path, bad)
            with self.assertRaises(ValueError):
                read_dataset(path, "A", None)

    def test_reader_checks_official_schema_and_unique_ids(self):
        from ite.platform_data import read_dataset, checkpoint_metadata
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            data = fixture(root, "C")
            meta = checkpoint_metadata(data["parent"])
            actual = read_dataset(data["train"], "C", meta["paths"])
            self.assertEqual(actual["x"].shape, (64, 24))
            self.assertEqual(len(actual["ids"]), 64)
            bad = rows("C", "public/train.jsonl", 2)
            bad[1]["id"] = bad[0]["id"]
            put_rows(data["train"], bad)
            with self.assertRaisesRegex(ValueError, "unique|duplicate"):
                read_dataset(data["train"], "C", meta["paths"])
            put_rows(data["train"], rows("C", "public/train.jsonl", 1))
            with self.assertRaisesRegex(ValueError, "schema"):
                read_dataset(data["train"], "C", list(reversed(meta["paths"])))

    def test_artifact_limit_includes_every_file_and_rejects_symlinks(self):
        from ite.platform_data import check_artifacts
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "checkpoint.npz").write_bytes(b"model")
            (root / "training.json").write_bytes(b"123456")
            self.assertEqual(check_artifacts(root, limit=11), 11)
            with self.assertRaisesRegex(ValueError, "limit|64 MiB"):
                check_artifacts(root, limit=10)

    def test_published_contract_identifies_real_train_and_prediction_entries(self):
        contract_path = ROOT / "configs/continuation-contract.json"
        self.assertTrue(contract_path.is_file(), "The image must carry a discoverable invocation contract")
        contract = json.loads(contract_path.read_text(encoding="utf-8"))
        self.assertEqual(contract["artifact_limit_bytes"], 67108864)
        for command in (contract["training_command"], contract["prediction_command"]):
            result = subprocess.run([sys.executable, str(ROOT / command[1]), "--help"],
                text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr)


@unittest.skipUnless(RUNTIME.is_file(), "isolated official CPU runtime is required")
class PlatformRoundTests(unittest.TestCase):
    def test_initial_baseline_training_ids_are_not_independent_validation(self):
        from ite.continuation import run_round
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            data = fixture(root, "C", count=16)
            put_rows(data["validation"], rows("C", "public/train.jsonl")[64:128])
            report = run_round(**data, output=root / "first", stage_id="first", runtime_python=RUNTIME)
            self.assertEqual(report["fresh_validation_rows"], 0)
            self.assertEqual(report["training_attempts"], 0)

    def test_missing_ancestral_history_stays_closed_after_a_retention_round(self):
        from ite.continuation import run_round
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            data = fixture(root, "C", count=64)
            model = OfficialModelAdapter("regression", RUNTIME, profile_type="C", checkpoint_path=data["parent"])
            model.fit(np.zeros((8, 24)), np.arange(8, dtype=float), epochs=1, timeout_seconds=10)
            model.save(data["parent"])
            first = run_round(**data, output=root / "first", stage_id="first", runtime_python=RUNTIME)
            self.assertEqual(first["training_attempts"], 0)
            data["parent"] = root / "first/checkpoint.npz"
            put_rows(data["validation"], rows("C", "public/validation.jsonl")[64:128])
            second = run_round(**data, output=root / "second", stage_id="second", runtime_python=RUNTIME,
                parent_history=root / "first/history.jsonl")
            self.assertFalse(second["future_accounting_complete"])
            self.assertEqual(second["training_attempts"], 0)
            self.assertEqual(second["selection_reason"], "missing_parent_history_for_fresh_future_accounting")

    def test_previous_training_rows_cannot_become_future_labels_or_validation_gradients(self):
        from ite.continuation import run_round
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            data = fixture(root, "C", count=16)
            first = run_round(**data, output=root / "first", stage_id="first", runtime_python=RUNTIME)
            old_train = rows("C", "public/train.jsonl", 16)
            put_rows(data["train"], rows("C", "public/train.jsonl")[64:128])
            put_rows(data["validation"], old_train)
            data["parent"] = root / "first/checkpoint.npz"
            second = run_round(**data, output=root / "second", stage_id="second", runtime_python=RUNTIME,
                parent_history=root / "first/history.jsonl")
            self.assertEqual(second["fresh_validation_rows"], 0)
            self.assertEqual(second["training_attempts"], 0)
            put_rows(data["train"], rows("C", "public/validation.jsonl", 16))
            put_rows(data["validation"], rows("C", "public/validation.jsonl")[64:80])
            with self.assertRaisesRegex(ValueError, "validation|role"):
                run_round(**data, output=root / "role-change", stage_id="role-change", runtime_python=RUNTIME,
                    parent_history=root / "first/history.jsonl")

    def test_official_baseline_history_is_preserved_and_resume_without_round_history_is_closed(self):
        from ite.continuation import run_round
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            data = fixture(root, "C", count=16)
            with zipfile.ZipFile(default_package_path("C")) as archive:
                original_history = archive.read("history.jsonl")
            (root / "history.jsonl").write_bytes(original_history)
            report = run_round(**data, output=root / "first", stage_id="first", runtime_python=RUNTIME)
            self.assertTrue((root / "first/history.jsonl").read_bytes().startswith(original_history))
            self.assertEqual(report["parameter_count"], 833)
            self.assertEqual(report["numpy_version"], "1.26.4")
            # A later resume must not treat the same initial model and an old
            # baseline-only history as a fresh round with unknown validation use.
            put_rows(data["validation"], rows("C", "public/validation.jsonl", 64))
            result = subprocess.run([sys.executable, str(ROOT / "train.py"), "--profile", "C",
                "--resume", str(data["parent"]), "--train", str(data["train"]),
                "--validation", str(data["validation"]), "--output", str(root / "resume"),
                "--official-python", str(RUNTIME)], text=True, capture_output=True, timeout=40)
            self.assertEqual(result.returncode, 0, result.stderr)
            resumed = json.loads(result.stdout)
            self.assertEqual(resumed["training_attempts"], 0)
            self.assertEqual(resumed["selection_reason"], "missing_parent_history_for_fresh_future_accounting")

    def test_b_retains_external_parent_and_writes_truthful_standard_artifacts(self):
        from ite.continuation import run_round
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            data = fixture(root, "B")
            parent = OfficialModelAdapter("regression", RUNTIME, profile_type="B",
                checkpoint_path=data["parent"])
            parent.fit(np.zeros((8, 34)), np.arange(8, dtype=float), epochs=1, timeout_seconds=10)
            parent.save(data["parent"])
            parent_bytes = data["parent"].read_bytes()
            provenance = root / "labels.json"
            provenance.write_text(json.dumps({"status": "approved", "method": "published RUL minutes"}))
            report = run_round(**data, output=root / "round-1", stage_id="round-1",
                runtime_python=RUNTIME, label_provenance=provenance)
            self.assertEqual((root / "round-1/checkpoint.npz").read_bytes(), parent_bytes)
            self.assertEqual(report["parent_checkpoint_sha256"], hashlib.sha256(parent_bytes).hexdigest())
            self.assertEqual(report["initial_steps"], parent.steps)
            self.assertEqual(report["final_steps"], parent.steps)
            self.assertEqual(report["training_attempts"], 0)
            self.assertEqual(report["selection_reason"], "B_static_policy")
            self.assertLess(report["artifact_bytes"], 64 * 1024 * 1024)
            self.assertEqual(report["artifact_bytes"], sum(p.stat().st_size for p in (root / "round-1").iterdir()))
            audit_report = json.loads((root / "round-1.audit/round.json").read_text(encoding="utf-8"))
            self.assertEqual(audit_report["artifact_bytes"], report["artifact_bytes"])
            self.assertTrue((root / "round-1/training.json").is_file())
            history = [json.loads(line) for line in (root / "round-1/history.jsonl").read_text(encoding="utf-8").splitlines()]
            self.assertEqual(history[-1]["checkpoint_sha256"], report["checkpoint_sha256"])
            self.assertFalse(history[-1]["training_performed"])
            self.assertTrue((root / "round-1.audit").is_dir())
            self.assertFalse((root / "round-1/predictions.npz").exists())

    def test_second_round_uses_the_platform_parent_and_binds_prior_history(self):
        from ite.continuation import run_round
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            data = fixture(root, "C", count=16)
            first = run_round(**data, output=root / "round-1", stage_id="round-1", runtime_python=RUNTIME)
            data["parent"] = root / "round-1/checkpoint.npz"
            second = run_round(**data, output=root / "round-2", stage_id="round-2", runtime_python=RUNTIME,
                parent_history=root / "round-1/history.jsonl")
            self.assertEqual(second["parent_checkpoint_sha256"], first["checkpoint_sha256"])
            self.assertEqual(second["initial_steps"], first["final_steps"])
            first_history = (root / "round-1/history.jsonl").read_bytes()
            self.assertTrue((root / "round-2/history.jsonl").read_bytes().startswith(first_history))
            wrong = root / "wrong-history.jsonl"
            wrong.write_text(json.dumps({"event": "round_completed", "checkpoint_sha256": "0" * 64}) + "\n")
            with self.assertRaisesRegex(ValueError, "history|parent"):
                run_round(**data, output=root / "wrong-round", stage_id="wrong-round", runtime_python=RUNTIME,
                    parent_history=wrong)
            self.assertFalse((root / "wrong-round").exists())

    def test_a_real_candidate_uses_external_parent_then_round_two_honors_platform_rejection(self):
        from ite.continuation import run_round
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            data = fixture(root, "A", count=256)
            put_rows(data["train"], rows("A", "public/train.jsonl"))
            original = data["parent"].read_bytes()
            first = run_round(**data, output=root / "first", stage_id="first", runtime_python=RUNTIME)
            self.assertEqual(first["training_attempts"], 1)
            candidate = root / "first.audit/policy/candidate-step7.npz"
            self.assertTrue(candidate.is_file())
            with np.load(candidate, allow_pickle=False) as archive:
                trained = json.loads(str(archive["metadata"]))
            self.assertGreater(trained["steps"], first["initial_steps"])
            # Simulate the platform retaining the original parent. Never substitute
            # the previously produced candidate or the previously selected model.
            later = rows("A", "public/validation.jsonl")[300:556]
            put_rows(data["validation"], later)
            second = run_round(**data, output=root / "second", stage_id="second", runtime_python=RUNTIME)
            self.assertEqual(second["parent_checkpoint_sha256"], hashlib.sha256(original).hexdigest())
            self.assertEqual(second["initial_steps"], first["initial_steps"])
            self.assertEqual(data["parent"].read_bytes(), original)
            self.assertEqual(second["training_attempts"], 1)

    def test_reused_validation_is_not_reintroduced_as_independent_future_evidence(self):
        from ite.continuation import run_round
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            data = fixture(root, "C")
            first = run_round(**data, output=root / "first", stage_id="first", runtime_python=RUNTIME)
            data["parent"] = root / "first/checkpoint.npz"
            second = run_round(**data, output=root / "second", stage_id="second", runtime_python=RUNTIME,
                parent_history=root / "first/history.jsonl")
            self.assertEqual(second["fresh_validation_rows"], 0)
            self.assertEqual(second["training_attempts"], 0)
            self.assertEqual(second["checkpoint_sha256"], first["checkpoint_sha256"])
            self.assertEqual(second["selection_reason"], "insufficient_fresh_future_capacity")

    def test_bad_parent_wrong_schema_overlapping_ids_and_overwrite_fail_before_publication(self):
        from ite.continuation import run_round
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            data = fixture(root, "C", count=16)
            original = data["parent"].read_bytes()
            data["parent"].write_bytes(b"not a checkpoint")
            with self.assertRaises((ValueError, RuntimeError, zipfile.BadZipFile)):
                run_round(**data, output=root / "bad", stage_id="bad", runtime_python=RUNTIME)
            self.assertFalse((root / "bad").exists())
            data["parent"].write_bytes(original)
            data["validation"].write_bytes(data["train"].read_bytes())
            with self.assertRaisesRegex(ValueError, "overlap"):
                run_round(**data, output=root / "overlap", stage_id="overlap", runtime_python=RUNTIME)
            self.assertFalse((root / "overlap").exists())
            sentinel = root / "exists"
            sentinel.mkdir()
            (sentinel / "keep").write_text("keep")
            with self.assertRaises(FileExistsError):
                run_round(**data, output=sentinel, stage_id="exists", runtime_python=RUNTIME)
            self.assertEqual((sentinel / "keep").read_text(), "keep")

    def test_cli_requires_parent_and_exposes_official_argument_spelling(self):
        command = [sys.executable, str(ROOT / "train.py")]
        result = subprocess.run(command + ["--help"], text=True, capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        for option in ("--resume", "--from-baseline", "--train", "--validation", "--output", "--stage-id"):
            self.assertIn(option, result.stdout)
        result = subprocess.run(command + ["--profile", "C", "--train", "train.jsonl",
            "--validation", "validation.jsonl", "--output", "never-created"],
            text=True, capture_output=True)
        self.assertEqual(result.returncode, 2)
        self.assertIn("parent", result.stderr.lower())


@unittest.skipUnless(RUNTIME.is_file(), "isolated official CPU runtime is required")
class PlatformPredictionTests(unittest.TestCase):
    def test_standalone_prediction_matches_vendor_for_all_profiles_and_rejects_labels(self):
        for profile in "ABC":
            with self.subTest(profile=profile), tempfile.TemporaryDirectory() as temp:
                root = Path(temp)
                data = fixture(root, profile, count=4)
                requests = "".join(json.dumps({"inputs": row["inputs"]}) + "\n"
                    for row in rows(profile, "public/validation.jsonl", 4))
                command = [sys.executable, str(ROOT / "predict.py"), "--checkpoint", str(data["parent"]),
                    "--official-python", str(RUNTIME)]
                actual = subprocess.run(command, input=requests, text=True, capture_output=True, timeout=30)
                self.assertEqual(actual.returncode, 0, actual.stderr)
                env = os.environ.copy()
                env["PYTHONPATH"] = str(default_package_path(profile))
                expected = subprocess.run([str(RUNTIME), "-m", "baselines.predict", "--checkpoint",
                    str(data["parent"])], input=requests, text=True, capture_output=True, env=env, timeout=30)
                self.assertEqual(expected.returncode, 0, expected.stderr)
                self.assertEqual([json.loads(x) for x in actual.stdout.splitlines()],
                    [json.loads(x) for x in expected.stdout.splitlines()])
                forbidden = json.loads(requests.splitlines()[0])
                forbidden["answer"] = 999
                bad = subprocess.run(command, input=json.dumps(forbidden) + "\n", text=True,
                    capture_output=True, timeout=30)
                self.assertNotEqual(bad.returncode, 0)
                self.assertEqual(bad.stdout.strip(), "")

    def test_c_prediction_keeps_checkpoint_bound_safety_policy(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            data = fixture(root, "C", count=4)
            model = OfficialModelAdapter("regression", RUNTIME, profile_type="C", checkpoint_path=data["parent"])
            model.safety_margin = 1.25
            model.safety_calibration = {"samples": 48, "quantile": .9, "positive_residuals": 48}
            model.save(data["parent"])
            line = rows("C", "public/validation.jsonl", 1)[0]
            values = json.dumps({"inputs": line["inputs"]}) + "\n"
            result = subprocess.run([sys.executable, str(ROOT / "predict.py"), "--checkpoint", str(data["parent"]),
                "--official-python", str(RUNTIME)], input=values, text=True, capture_output=True, timeout=30)
            self.assertEqual(result.returncode, 0, result.stderr)
            from ite.official_sft_data import flatten_features
            expected = model.predict([flatten_features(line["inputs"])[0]])[0]
            self.assertEqual(json.loads(result.stdout)["outputs"]["value"], expected)


if __name__ == "__main__":
    unittest.main()
