import json
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

import numpy as np

from ite.config import ExperimentConfig

try:
    from ite.runner import run_comparison
except ImportError:
    run_comparison = None


class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(run_comparison, "The complete streaming runner is not implemented")

    def test_abrupt_drift_recovers_without_violating_temporal_split(self):
        config = ExperimentConfig(n_batches=38, drift_start=7, seed=7)
        with tempfile.TemporaryDirectory() as directory:
            results = run_comparison(config, Path(directory))
            by_policy = {item["policy"]: item for item in results}
            self.assertEqual(set(by_policy), {"static", "periodic", "drift"})
            self.assertGreater(by_policy["drift"]["updates"], 0)
            self.assertLess(by_policy["drift"]["mean_loss"], by_policy["static"]["mean_loss"] - 0.2)
            events = [json.loads(line) for line in (Path(directory) / "drift/events.jsonl").read_text().splitlines()]
            detections_after_first_deployment = [event for event in events
                                                  if event["event"] == "experiment_started"
                                                  and event["step"] > 10]
            self.assertTrue(detections_after_first_deployment,
                            "Poor updates must not turn historical candidate loss into a healthy baseline")
            for event in events:
                if event["event"] == "experiment_started":
                    self.assertLess(event["train_max_step"], event["validation_min_step"])
                    self.assertLessEqual(event["validation_min_step"], event["step"] - config.label_delay)
            self.assertTrue((Path(directory) / "report.html").is_file())
            self.assertTrue((Path(directory) / "summary.csv").is_file())
            finalized = [event for event in events if event["event"] == "comparison_finalized"]
            self.assertEqual(len(finalized), 1)
            self.assertAlmostEqual(finalized[0]["loss_gain_vs_static"], by_policy["drift"]["loss_gain_vs_static"])
            nested_summary = json.loads((Path(directory) / "drift" / "summary.json").read_text(encoding="utf-8"))
            self.assertEqual(nested_summary["curve_file"], "curve.csv")

    def test_zero_budgets_preserve_initial_predictions_and_record_experiment(self):
        config = ExperimentConfig(n_batches=6, drift_start=2, max_labels=0, max_train_seconds=0)
        with tempfile.TemporaryDirectory() as directory:
            results = run_comparison(config, Path(directory))
            self.assertTrue(all(item["updates"] == 0 for item in results))
            self.assertTrue(all(item["labels_requested"] == 0 for item in results))
            self.assertEqual(len({item["mean_loss"] for item in results}), 1)
            for item in results:
                events = [json.loads(line)["event"] for line in
                          (Path(directory) / item["policy"] / "events.jsonl").read_text().splitlines()]
                self.assertIn("initial_training", events)
                self.assertIn("run_completed", events)

    def test_prediction_is_unchanged_until_delayed_labels_are_available(self):
        config = ExperimentConfig(n_batches=5, drift_start=1, label_delay=10)
        with tempfile.TemporaryDirectory() as directory:
            run_comparison(config, Path(directory))
            with np.load(Path(directory) / "static/predictions.npz", allow_pickle=False) as baseline:
                with np.load(Path(directory) / "drift/predictions.npz", allow_pickle=False) as adaptive:
                    np.testing.assert_array_equal(baseline["predictions"], adaptive["predictions"])

    def test_existing_experiment_is_never_overwritten(self):
        config = ExperimentConfig(n_batches=4)
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "experiment"
            run_comparison(config, output, policies=("static",))
            with self.assertRaises(FileExistsError):
                run_comparison(config, output)

    def test_artifact_write_failure_never_claims_run_completed(self):
        config = ExperimentConfig(n_batches=4)
        with tempfile.TemporaryDirectory() as directory:
            with patch("ite.runner.write_rows", side_effect=OSError("simulated disk full")):
                with self.assertRaises(OSError):
                    run_comparison(config, Path(directory), policies=("static",))
            events = [json.loads(line)["event"] for line in
                      (Path(directory) / "static/events.jsonl").read_text().splitlines()]
            self.assertNotIn("run_completed", events)
            self.assertIn("run_failed", events)

    def test_exhausted_labels_do_not_repeat_experiments_on_the_same_validation_data(self):
        config = ExperimentConfig(n_batches=24, drift_start=1, label_delay=0, max_labels=96)
        with tempfile.TemporaryDirectory() as directory:
            results = run_comparison(config, Path(directory), policies=("periodic",))
            self.assertEqual(results[0]["experiments"], 1)

    def test_tiny_training_budget_refuses_work_and_stream_still_finishes(self):
        config = ExperimentConfig(n_batches=12, drift_start=1, max_train_seconds=1e-6)
        with tempfile.TemporaryDirectory() as directory:
            results = run_comparison(config, Path(directory), policies=("periodic",))
            self.assertEqual(results[0]["stream_batches"], 12)
            self.assertEqual(results[0]["updates"], 0)
            events = [json.loads(line) for line in (Path(directory) / "periodic/events.jsonl").read_text().splitlines()]
            candidates = [event for event in events if event["event"] == "candidate_evaluated"]
            skipped = [event for event in events if event["event"] == "experiment_skipped"]
            self.assertEqual(len(candidates), 0)
            self.assertTrue(skipped)
            self.assertTrue(all(event["reason"] == "budget_exhausted" for event in skipped))
            self.assertLessEqual(results[0]["adaptation_train_seconds"], config.max_train_seconds)


if __name__ == "__main__":
    unittest.main()
