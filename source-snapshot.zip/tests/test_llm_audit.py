"""Cost audit separates observed usage, unresolved exposure and projections."""

import unittest


class LLMAuditTests(unittest.TestCase):
    def test_projection_uses_observed_input_output_and_caps_calls_independently_of_batches(self):
        from ite.llm_audit import audit_cost
        ledger = {"identity": "test", "requests": [{"status": "settled", "input_tokens": 100,
            "output_tokens": 20, "input_price_per_million": "8.41", "output_price_per_million": "25.29",
            "cost_cny": "0.00134680"}]}
        report = audit_cost(ledger, [{"event": "harness_call", "latency_seconds": 2.5, "status": "ok"}],
                            batches=100, drift_calls=100)
        self.assertEqual((report["actual_input_tokens"], report["actual_output_tokens"]), (100, 20))
        self.assertEqual(report["actual_estimated_cost_cny"], "0.00134680")
        self.assertEqual(report["capped"]["calls"], 10)
        self.assertEqual(report["capped"]["projected_tokens"], 1200)
        self.assertEqual(report["capped"]["estimated_cost_cny"], "0.01346800")
        self.assertEqual(report["uncapped"]["projected_tokens"], 12000)
        self.assertEqual(report["latency_mean_seconds"], 2.5)

    def test_sparse_drift_and_unknown_calls_do_not_become_zero_cost_or_fake_observed_tokens(self):
        from ite.llm_audit import audit_cost
        ledger = {"identity": "test", "requests": [{"status": "reserved", "input_tokens": None,
            "output_tokens": None, "reserved_input_tokens": 2048, "reserved_output_tokens": 512,
            "reserved_cost_cny": "0.03017216", "input_price_per_million": "8.41",
            "output_price_per_million": "25.29"}]}
        report = audit_cost(ledger, [], batches=100, drift_calls=3)
        self.assertEqual(report["actual_total_tokens"], 0)
        self.assertEqual(report["unknown_calls"], 1)
        self.assertEqual(report["unresolved_reserved_cost_cny"], "0.03017216")
        self.assertIsNone(report["capped"])
        self.assertEqual(report["configured_upper_bound"]["calls"], 3)
        self.assertEqual(report["configured_upper_bound"]["tokens"], 7680)


if __name__ == "__main__":
    unittest.main()
