"""Contract tests catch leakage, arbitrary actions and ambiguous model responses."""

import copy
import json
import unittest


def observation():
    return {"loss_trend": [{"source_step": 10, "loss": .25, "labeled_samples": 12}],
            "drift_alarm": True, "remaining_label_budget": 720,
            "remaining_token_budget": 960, "model_age_batches": 15}


class HarnessContractTests(unittest.TestCase):
    def test_contract_accepts_empty_delayed_evidence_and_valid_nonnegative_losses(self):
        from ite.harness import validate_observation
        value = observation()
        validate_observation(value, task="classification")
        value["loss_trend"] = []
        validate_observation(value, task="regression")
        value["loss_trend"] = [{"source_step": 10, "loss": 3.5, "labeled_samples": 1}]
        validate_observation(value, task="regression")
        with self.assertRaises(ValueError):
            validate_observation(value, task="classification")

    def test_contract_rejects_extra_information_bad_counts_and_nonfinite_values(self):
        from ite.harness import validate_observation
        changes = [
            {"scenario": "abrupt"}, {"targets": [1]}, {"drift_alarm": 1},
            {"remaining_token_budget": True}, {"remaining_label_budget": -1},
            {"model_age_batches": 1.5}, {"loss_trend": None},
            {"loss_trend": [{"source_step": True, "loss": .2, "labeled_samples": 1}]},
            {"loss_trend": [{"source_step": 1, "loss": float("nan"), "labeled_samples": 1}]},
            {"loss_trend": [{"source_step": 1, "loss": float("inf"), "labeled_samples": 1}]},
            {"loss_trend": [{"source_step": 1, "loss": -.1, "labeled_samples": 1}]},
            {"loss_trend": [{"source_step": 1, "loss": .1, "labeled_samples": 0}]},
            {"loss_trend": [{"source_step": 1, "loss": .1, "labeled_samples": 1,
                             "target": 0}]},
            {"loss_trend": [{"source_step": 1, "loss": .1, "labeled_samples": 1}] * 6},
            {"loss_trend": [{"source_step": 2, "loss": .1, "labeled_samples": 1},
                            {"source_step": 1, "loss": .1, "labeled_samples": 1}]}
        ]
        for change in changes:
            with self.subTest(change=change), self.assertRaises(ValueError):
                validate_observation({**observation(), **change})
        value = observation()
        del value["drift_alarm"]
        with self.assertRaises(ValueError):
            validate_observation(value)

    def test_actions_cannot_smuggle_hyperparameters_or_code(self):
        from ite.harness import parse_action
        for action in ("DO_NOTHING", "RETRAIN_SMALL", "RETRAIN_LARGE", "ROLLBACK"):
            parsed = parse_action(json.dumps({"action": action, "reason": "已观察到退化。"}))
            self.assertEqual(parsed.action, action)
            self.assertEqual(parsed.reason, "已观察到退化。")
        for raw in (
            '{"action":"RETRAIN_SMALL","reason":"ok","alpha":0}',
            '{"action":"EXECUTE_CODE","reason":"ok"}',
            '{"action":"ROLLBACK","reason":"ok","model_path":"x"}',
            '{"action":true,"reason":"ok"}', '{}', '[]', 'null', '42',
            '{"action":"DO_NOTHING","reason":null}',
            '{"action":"DO_NOTHING","reason":"   "}',
            json.dumps({"action": "DO_NOTHING", "reason": "a\nb"}),
            json.dumps({"action": "DO_NOTHING", "reason": "a\rb"}),
            json.dumps({"action": "DO_NOTHING", "reason": "x" * 161}),
        ):
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                parse_action(raw)

    def test_json_parser_rejects_duplicate_keys_wrappers_trailing_data_and_constants(self):
        from ite.harness import parse_action
        good = '{"action":"DO_NOTHING","reason":"ok"}'
        for raw in (
            '{"action":"DO_NOTHING","action":"ROLLBACK","reason":"ok"}',
            '```json\n' + good + '\n```', good + good, good + " trailing",
            '{"action":"DO_NOTHING","reason":NaN}',
            '{"action":"DO_NOTHING","reason":Infinity}', "x" * 4097,
            '{"action":"DO_NOTHING","reason":"\\ud800"}',
            {"action": "DO_NOTHING", "reason": "ok"},
        ):
            with self.subTest(raw=str(raw)[:100]), self.assertRaises(ValueError):
                parse_action(raw)

    def test_json_repair_extracts_one_object_once_then_revalidates_strictly(self):
        from unittest.mock import patch
        from ite.harness import parse_action, parse_action_with_repair

        good = '{"action":"DO_NOTHING","reason":"证据不足，保持当前模型。"}'
        action, repaired = parse_action_with_repair("答复如下：\n```json\n" + good + "\n```\n")
        self.assertEqual(action.action, "DO_NOTHING")
        self.assertTrue(repaired)
        action, repaired = parse_action_with_repair(good)
        self.assertEqual(action.action, "DO_NOTHING")
        self.assertFalse(repaired)

        invalid = (
            "prefix " + good + " suffix {another object}",
            '```json\n{"action":"EXECUTE_CODE","reason":"bad"}\n```',
            '```json\n{"action":"DO_NOTHING","action":"ROLLBACK","reason":"bad"}\n```',
            'prefix {"action":"DO_NOTHING","reason":"truncated"',
        )
        for raw in invalid:
            with self.subTest(raw=raw), patch("ite.harness.parse_action", wraps=parse_action) as parse:
                with self.assertRaises(ValueError):
                    parse_action_with_repair(raw)
                self.assertLessEqual(parse.call_count, 2)

        with self.assertRaises(ValueError):
            parse_action_with_repair("x" * 4097)

    def test_mock_client_is_offline_deterministic_and_marks_usage_as_simulated(self):
        from ite.harness import BaseLLMClient, MockLLMClient, parse_action
        with self.assertRaises(TypeError):
            BaseLLMClient()
        value = observation()
        before = copy.deepcopy(value)
        client = MockLLMClient()
        reply = client.get_decision(value)
        self.assertEqual(parse_action(reply.raw_json).action, "RETRAIN_SMALL")
        self.assertEqual((reply.usage_tokens, reply.token_accounting_mode), (8, "mock"))
        self.assertEqual(value, before)
        value["drift_alarm"] = False
        self.assertEqual(parse_action(client.get_decision(value).raw_json).action, "DO_NOTHING")

    def test_mock_fault_modes_exercise_parse_failure_and_token_exhaustion(self):
        from ite.harness import MockLLMClient, TokenBudgetExceeded, parse_action
        with self.assertRaises(ValueError):
            parse_action(MockLLMClient("invalid_json").get_decision(observation()).raw_json)
        with self.assertRaises(TokenBudgetExceeded):
            MockLLMClient("token_exhausted").get_decision(observation())
        with self.assertRaises(ValueError):
            MockLLMClient("unknown")


if __name__ == "__main__":
    unittest.main()
