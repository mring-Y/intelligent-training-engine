import unittest
from pathlib import Path

import numpy as np

from ite.config import ExperimentConfig
from ite.models import RidgeModel
from ite.data import PublicBatch, ReleasedLabels

try:
    from ite.budget import ResourceBudget
    from ite.controller import AdaptationController, DeploymentGate, WindowPolicy
    from ite.monitor import DriftMonitor
    from ite.training import BoundedTrainer
except ImportError:
    AdaptationController = ResourceBudget = DeploymentGate = WindowPolicy = DriftMonitor = BoundedTrainer = None


class ControlTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(ResourceBudget, "The bounded controller is not implemented")

    def test_exhausted_budget_refuses_new_work_and_accounts_for_failed_training(self):
        budget = ResourceBudget(ExperimentConfig(max_train_seconds=2, max_experiments=1))
        self.assertTrue(budget.start_experiment())
        self.assertFalse(budget.start_experiment())
        budget.charge_training(2.01)
        self.assertEqual(budget.training_allowance(), 0)
        budget.record_labels(864)
        with self.assertRaises(ValueError):
            budget.record_labels(1)
        with self.assertRaises(ValueError):
            budget.charge_training(-1)

    def test_deploying_a_weak_candidate_cannot_relax_the_monitor_quality_target(self):
        monitor = DriftMonitor(ExperimentConfig(), np.zeros(3), np.ones(3), baseline_loss=0.05)
        monitor.reset()
        monitor.observe_losses(np.full(128, 0.8))
        self.assertTrue(monitor.evidence(0.0)["performance_drop"])
        self.assertEqual(monitor.baseline_loss, 0.05)

    def test_covariate_evidence_alone_does_not_trigger_model_updates(self):
        config = ExperimentConfig()
        monitor = DriftMonitor(config, np.zeros(3), np.ones(3), baseline_loss=0.05)
        distance = monitor.observe_features(np.full((128, 3), 5.0))
        monitor.observe_losses(np.zeros(128))
        evidence = monitor.evidence(distance)
        self.assertTrue(evidence["feature_shift"])
        self.assertFalse(evidence["performance_drop"])
        self.assertEqual(evidence["diagnosis"], "covariate_shift_without_observed_degradation")
        monitor.observe_losses(np.ones(128))
        self.assertTrue(monitor.evidence(distance)["performance_drop"])

    def test_gate_rejects_worse_model_and_rolls_back_only_on_postdeployment_labels(self):
        rng = np.random.default_rng(10)
        train, validation, future = (rng.normal(size=(200, 3)) for _ in range(3))
        target = lambda x: (x[:, 0] > 0).astype(int)
        original = RidgeModel().fit(train, target(train))
        opposite = RidgeModel().fit(train, 1 - target(train))
        gate = DeploymentGate(original, min_gain=0.02, rollback_margin=0.05, min_rollback_samples=32)
        self.assertFalse(gate.consider(opposite, validation, target(validation), step=2)["accepted"])
        self.assertTrue(gate.consider(opposite, validation, 1 - target(validation), step=3)["accepted"])
        self.assertIsNone(gate.check_rollback(future, target(future), np.full(200, 3), step=4))
        self.assertIsNotNone(gate.check_rollback(future, target(future), np.full(200, 4), step=5))
        self.assertGreater(np.mean(gate.model.predict(future) == target(future)), 0.95)
        self.assertEqual(gate.rollbacks, 1)

    def test_old_healthy_model_remains_available_when_an_operating_regime_returns(self):
        rng = np.random.default_rng(12)
        x = rng.normal(size=(300, 3))
        target = (x[:, 0] > 0).astype(int)
        original = RidgeModel().fit(x[:200], target[:200])
        opposite = RidgeModel().fit(x[:200], 1 - target[:200])
        gate = DeploymentGate(original, 0.02, 0.05, 32)
        self.assertTrue(gate.consider(opposite, x[200:], 1 - target[200:], step=1)["accepted"])
        # Long successful deployment must not discard the model for the original regime.
        for step in range(2, 7):
            self.assertIsNone(gate.check_rollback(x[200:], 1 - target[200:], np.full(100, step), step))
        outcome = None
        for step in range(7, 10):
            outcome = gate.check_rollback(x[200:], target[200:], np.full(100, step), step)
            if outcome is not None:
                break
        self.assertIsNotNone(outcome)
        self.assertGreater(np.mean(gate.model.predict(x[200:]) == target[200:]), 0.95)

    def test_periodic_baseline_never_enables_adaptive_window_search(self):
        rng = np.random.default_rng(123)
        x = rng.normal(size=(100, 3))
        model = RidgeModel().fit(x, (x[:, 0] > 0).astype(int))
        config = ExperimentConfig(n_features=3, strategy_adaptation=True)
        controller = AdaptationController(config, "periodic", model, 0.05, 1, None, None, Path("unused"))
        for window in config.history_windows:
            controller.window_policy.record(window, 0.1, 1)
        self.assertEqual(controller.window_policy.choose(), config.history_windows)

    def test_training_timeout_returns_control_and_normal_training_is_usable(self):
        x = np.arange(80, dtype=float).reshape(40, 2)
        y = (x[:, 0] > 30).astype(int)
        with BoundedTrainer() as trainer:
            timed_out = trainer.fit("classification", 1.0, x, y, timeout_seconds=1e-6)
            self.assertEqual(timed_out.status, "timeout")
            result = trainer.fit("classification", 1.0, x, y, timeout_seconds=8)
            self.assertEqual(result.status, "ok")
            self.assertGreater(np.mean(result.model.predict(x) == y), 0.9)
            self.assertGreater(result.wall_seconds, 0)

    def test_window_adaptation_remains_within_whitelist_and_retains_exploration(self):
        policy = WindowPolicy((192, 384, 768), enabled=True)
        self.assertEqual(set(policy.choose()), {192, 384, 768})
        for window, gain in ((192, 0.4), (384, 0.1), (768, -0.2)):
            policy.record(window, gain, 1)
        choices = policy.choose()
        self.assertEqual(choices[0], 192)
        self.assertLessEqual(len(choices), 2)
        self.assertTrue(set(choices) <= {192, 384, 768})


if __name__ == "__main__":
    unittest.main()
