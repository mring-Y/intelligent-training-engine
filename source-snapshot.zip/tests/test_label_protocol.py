"""Free labels remove a quota, never the chronological release boundary."""

import tempfile
import unittest
from pathlib import Path

from ite.budget import ResourceBudget
from ite.config import ExperimentConfig
from ite.data import make_simulation
from ite.harness import MockLLMClient, validate_observation
from ite.labeling import LabelAvailability, LabelScheduler
from ite.tracking import JsonlLogger


class LabelProtocolTests(unittest.TestCase):
    def provided(self, **kwargs):
        return ExperimentConfig(label_mode="provided", max_labels=0, **kwargs)

    def test_provided_labels_exceed_zero_legacy_quota_but_never_release_future_labels(self):
        config = self.provided(n_batches=4, label_delay=2)
        simulation = make_simulation(config)
        scheduler, budget = LabelScheduler(config), ResourceBudget(config)
        self.assertEqual(scheduler.count(0, 0), 96)
        with self.assertRaises(ValueError):
            simulation.oracle.request(simulation.batches[1].sample_ids, 0)
        self.assertEqual(simulation.oracle.request(simulation.batches[0].sample_ids, 0), 96)
        budget.record_labels(96)
        self.assertIsNone(budget.remaining_label_budget)
        self.assertIsNone(simulation.oracle.release(1))
        released = simulation.oracle.release(2)
        self.assertEqual(len(released.targets), 96)
        self.assertEqual(set(released.source_steps), {0})

    def test_unmetered_future_capacity_obeys_freeze_and_release_deadline(self):
        availability = LabelAvailability(None, 96, 9, 2, ((3, 5), (5, 7)))
        # One already requested label from source 5, plus 96 new source-5 labels.
        self.assertEqual(availability.capacity(4, 4, 7), 97)
        self.assertEqual(availability.capacity(4, 4, 5), 0)

    def test_null_quota_observation_and_guard_allow_actual_provided_labels(self):
        from ite.budget_guard import BudgetGuard
        config = self.provided(max_tokens=1000)
        budget = ResourceBudget(config)
        budget.record_labels(1000)
        value = {"loss_trend": [], "drift_alarm": True, "remaining_label_budget": None,
                 "remaining_token_budget": 1000, "model_age_batches": 1}
        validate_observation(value)
        with tempfile.TemporaryDirectory() as directory:
            with JsonlLogger(Path(directory) / "events.jsonl", "test") as log:
                guard = BudgetGuard(budget, log)
                self.assertEqual(guard.get_decision(value, MockLLMClient(), 0).action, "RETRAIN_SMALL")
                self.assertEqual(guard.state, "ACTIVE")

    def test_budgeted_labels_still_exhaust_and_provided_mode_must_be_explicit(self):
        config = ExperimentConfig(max_labels=1)
        budget = ResourceBudget(config)
        budget.record_labels(1)
        self.assertEqual(budget.remaining_label_budget, 0)
        with self.assertRaises(ValueError):
            budget.record_labels(1)
        with self.assertRaises(ValueError):
            ExperimentConfig(label_mode="unlimited-typo")


if __name__ == "__main__":
    unittest.main()
