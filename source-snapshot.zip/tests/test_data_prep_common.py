import importlib
import http.server
import json
import tempfile
import threading
import unittest
import zipfile
from pathlib import Path

import numpy as np

from ite.providers import ColumnMapping

try:
    common = importlib.import_module("scripts.data_prep.common")
except ImportError:
    common = None


class PackageExportTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(common, "A data package exporter is not implemented")
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def export(self, **overrides):
        values = dict(dataset="fixture", task="regression", features=["x"],
                      train_rows=[{"x": x, "target": i} for i, x in enumerate([1, 3, np.nan, 5])],
                      val_rows=[{"x": x, "target": 1} for x in [1000, np.nan, 4, 5]],
                      stream_rows=[{"x": np.inf, "target": 2}, {"x": 7, "target": 3}],
                      metadata={"target_unit": "cycles"}, batch_size=1)
        values.update(overrides)
        return common.export_dataset(self.root / "package", **values)

    def provider(self, manifest):
        from scripts.data_prep.provider import PreparedDataProvider
        mapping = ColumnMapping(**manifest["column_mapping"])
        return PreparedDataProvider(self.root / "package/test_stream.parquet", mapping,
                                   initial_train_path=self.root / "package/train.csv",
                                   initial_validation_path=self.root / "package/val.csv",
                                   label_delay=1, max_labels=None)

    def test_training_only_median_and_real_provider_round_trip(self):
        manifest = self.export()
        provider = self.provider(manifest)
        initial = provider.initial_data()
        np.testing.assert_array_equal(initial.train_x[:, 0], [1, 3, 3, 5])
        np.testing.assert_array_equal(initial.validation_x[:, 0], [1000, 3, 4, 5])
        observed = []
        for batch in provider.iter_batches():
            observed.extend(batch.features[:, 0])
            provider.commit_predictions(batch.step, batch.sample_ids, np.zeros(len(batch.sample_ids)))
        self.assertEqual(observed, [3, 7])
        self.assertEqual(manifest["quality"]["imputation_medians"], {"x": 3.0})
        self.assertEqual(manifest["splits"]["stream"]["rows"], 2)
        self.assertEqual(len({item["sha256"] for item in manifest["files"].values()}), 3)

    def test_invalid_targets_are_audited_and_never_imputed(self):
        manifest = self.export(stream_rows=[{"x": 1, "target": None},
                                            {"x": 2, "target": 7}, {"x": 3, "target": np.nan}])
        self.assertEqual(manifest["quality"]["stream"]["dropped_invalid_targets"], 2)
        self.assertEqual(manifest["splits"]["stream"]["rows"], 1)
        provider = self.provider(manifest)
        batch = next(provider.iter_batches())
        provider.commit_predictions(0, batch.sample_ids, np.array([0.]))
        provider.request_labels(batch.sample_ids, 0)
        self.assertEqual(provider.pending_schedule, ((0, 1),))

    def test_rejects_all_missing_training_feature_and_metadata_feature_alias(self):
        with self.assertRaises(ValueError):
            self.export(train_rows=[{"x": np.nan, "target": i} for i in range(4)])
        with self.assertRaises(ValueError):
            self.export(features=["target"])

    def test_ids_are_disjoint_and_existing_package_is_immutable(self):
        manifest = self.export()
        provider = self.provider(manifest)
        self.assertEqual(provider.batch_sizes, (1, 1))
        original = (self.root / "package/manifest.json").read_bytes()
        with self.assertRaises(FileExistsError):
            self.export()
        self.assertEqual((self.root / "package/manifest.json").read_bytes(), original)

    def test_zip_traversal_is_rejected_without_writing_outside_destination(self):
        archive = self.root / "bad.zip"
        with zipfile.ZipFile(archive, "w") as zipped:
            zipped.writestr("../escape.txt", "bad")
        with self.assertRaises(ValueError):
            common.extract_zip(archive, self.root / "extracted")
        self.assertFalse((self.root / "escape.txt").exists())

    def test_archive_and_download_preserve_bytes_and_source_receipt(self):
        source = self.root / "source.zip"
        with zipfile.ZipFile(source, "w") as zipped:
            zipped.writestr("nested/data.txt", "original")
        downloaded = common.download_file(source.as_uri(), self.root / "raw/copy.zip")
        self.assertEqual(downloaded.read_bytes(), source.read_bytes())
        receipt = json.loads(downloaded.with_suffix(".zip.source.json").read_text())
        self.assertEqual(receipt["sha256"], common.fingerprint(source)["sha256"])
        extracted = common.extract_zip(downloaded, self.root / "expanded")
        self.assertEqual((extracted / "nested/data.txt").read_text(), "original")
        with self.assertRaises(ValueError):
            common.download_file(source.as_uri(), self.root / "raw/too-large.zip", max_bytes=2)
        self.assertFalse((self.root / "raw/too-large.zip").exists())

    def test_truncated_http_response_is_not_finalized_as_a_raw_source(self):
        class Truncated(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                self.send_response(200)
                self.send_header("Content-Length", "10")
                self.end_headers()
                self.wfile.write(b"abc")

            def log_message(self, *args):
                pass

        server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Truncated)
        worker = threading.Thread(target=server.serve_forever, daemon=True)
        worker.start()
        try:
            target = self.root / "raw/truncated.bin"
            with self.assertRaises((ValueError, OSError)):
                common.download_file(f"http://127.0.0.1:{server.server_port}/file", target)
            self.assertFalse(target.exists())
            self.assertFalse(target.with_suffix(".bin.source.json").exists())
        finally:
            server.shutdown()
            server.server_close()
            worker.join()


if __name__ == "__main__":
    unittest.main()
