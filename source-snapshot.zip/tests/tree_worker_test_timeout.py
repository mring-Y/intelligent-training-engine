"""Test-only allowance for cold Tree worker startup; production budgets are untouched."""

from contextlib import contextmanager
from unittest.mock import patch

from ite.training import BoundedTrainer


@contextmanager
def tree_initial_timeout(seconds=10.0):
    original = BoundedTrainer.fit

    def fit(self, task, alpha, features, targets, timeout_seconds, model_family="ridge",
            sample_weight=None, **options):
        if options.get("model_type") == "tree" and options.get("candidate") is False:
            timeout_seconds = seconds
        return original(self, task, alpha, features, targets, timeout_seconds,
                        model_family, sample_weight, **options)

    with patch.object(BoundedTrainer, "fit", new=fit):
        yield
