"""Official Teacher decisions are bounded, immutable proposals until scored."""

import importlib
import json
import tempfile
import os
import sys
import unittest
from pathlib import Path

from ite.harness import LLMReply


def context():
    return {"profile": "B", "split": "train", "scenario": "abrupt", "step": 3,
            "remaining_train_seconds": 20., "feature_distance": .4,
            "observation": {"loss_trend": [{"source_step": 2, "loss": .5, "labeled_samples": 24}],
                "drift_alarm": True, "remaining_label_budget": None,
                "remaining_token_budget": 60000, "model_age_batches": 4}}


class OfficialSFTTeacherTests(unittest.TestCase):
    def module(self):
        try:
            return importlib.import_module("ite.official_sft_teacher")
        except ImportError as error:
            self.fail(f"Teacher pilot boundary missing: {error}")

    def test_official_prompt_contains_only_visible_context_and_correct_units(self):
        from ite.trio_client import build_messages
        try:
            messages = build_messages(context()["observation"], model_type="official_mlp",
                prompt_profile="official_sft", official_context={"profile": "B",
                "remaining_train_seconds": 20., "feature_distance": .4})
        except (ValueError, TypeError) as error:
            self.fail(f"Official model prompt not supported: {error}")
        self.assertIn("34", messages[0]["content"])
        self.assertIn("resume", messages[0]["content"])
        self.assertIn("分钟", messages[0]["content"])
        self.assertIn("null", messages[0]["content"])
        self.assertNotIn("target", messages[1]["content"])

    def test_timeout_latches_after_one_attempt_and_keeps_maximum_reserved_cost(self):
        m = self.module()
        class Slow:
            calls = 0
            def get_decision(self, observation):
                self.calls += 1
                raise TimeoutError("timeout")
        client = Slow()
        with tempfile.TemporaryDirectory() as tmp:
            session = m.TeacherSession(Path(tmp), client_factory=lambda _: client,
                                       input_counter=lambda _: 800)
            self.assertIsNone(session.decide(context()))
            self.assertIsNone(session.decide(context()))
            state = session.ledger.snapshot()
            self.assertEqual(client.calls, 1)
            self.assertEqual(state["attempted_calls"], 1)
            self.assertEqual(state["reserved_cost_cny"], "0.00717462")
            self.assertEqual(state["trip_reason"], "client_timeout")

    def test_usage_settlement_and_raw_json_are_kept_and_thirty_first_is_blocked(self):
        m = self.module()
        class Client:
            calls = 0
            def get_decision(self, observation):
                self.calls += 1
                return LLMReply('{"action":"DO_NOTHING","reason":"保持现有模型。"}', 42, "real", 30, 12, "stop")
        client = Client()
        with tempfile.TemporaryDirectory() as tmp:
            session = m.TeacherSession(Path(tmp), client_factory=lambda _: client, input_counter=lambda _: 800)
            for _ in range(30):
                self.assertEqual(session.decide(context())["action"], "DO_NOTHING")
            self.assertIsNone(session.decide(context()))
            state = session.ledger.snapshot()
            calls = [json.loads(s) for s in (Path(tmp)/"teacher-events.jsonl").read_text().splitlines()]
            self.assertEqual(client.calls, 30)
            self.assertEqual(state["used_tokens"], 1260)
            self.assertEqual(calls[0]["raw_response"], '{"action":"DO_NOTHING","reason":"保持现有模型。"}')
            self.assertTrue(all(c["latency_seconds"] >= 0 for c in calls))

    def test_oversized_input_is_rejected_before_reservation_or_network(self):
        m = self.module()
        with tempfile.TemporaryDirectory() as tmp:
            session = m.TeacherSession(Path(tmp), client_factory=lambda _: self.fail("network"),
                                       input_counter=lambda _: 1251)
            self.assertIsNone(session.decide(context()))
            self.assertEqual(session.ledger.snapshot()["attempted_calls"], 0)

    def test_invalid_json_is_billed_then_stops_and_never_creates_a_label(self):
        m = self.module()
        class Client:
            def get_decision(self, observation):
                return LLMReply('not json', 40, "real", 30, 10, "stop")
        with tempfile.TemporaryDirectory() as tmp:
            session = m.TeacherSession(Path(tmp), client_factory=lambda _: Client(), input_counter=lambda _: 800)
            self.assertIsNone(session.decide(context()))
            self.assertIsNone(session.decide(context()))
            self.assertEqual(session.ledger.snapshot()["used_tokens"], 40)
            self.assertEqual(session.ledger.snapshot()["attempted_calls"], 1)
            self.assertEqual(session.ledger.snapshot()["trip_reason"], "invalid_action")

    def test_observation_budget_tracks_provider_usage_and_evidence_files_are_exclusive(self):
        m = self.module()
        observed = []
        class Client:
            def get_decision(self, observation):
                observed.append(observation.copy())
                return LLMReply('{"action":"DO_NOTHING","reason":"证据不足。"}', 42, "real", 30, 12, "stop")
        with tempfile.TemporaryDirectory() as tmp:
            session = m.TeacherSession(Path(tmp), client_factory=lambda _: Client(), input_counter=lambda _: 800)
            session.decide(context())
            proposal = session.decide(context())
            self.assertEqual(observed[1]["remaining_token_budget"], 59958)
            self.assertEqual(json.loads(proposal["messages"][1]["content"]), observed[1])
            with self.assertRaises(FileExistsError):
                m.TeacherSession(Path(tmp), client_factory=lambda _: Client(), input_counter=lambda _: 800)

    def test_runtime_preflight_rejects_main_environment_without_system_site_isolation(self):
        m = self.module()
        with self.assertRaises(ValueError):
            m.verify_teacher_runtime(sys.executable)

    @unittest.skipUnless((Path(__file__).resolve().parents[1]/'.venv-sft/Scripts/python.exe').is_file(),
                         'host isolated Teacher runtime is not provisioned')
    def test_isolated_runtime_reports_metadata_versions_without_sdk_version_attribute(self):
        m = self.module()
        path = Path(__file__).resolve().parents[1]/'.venv-sft/Scripts/python.exe'
        report = m.verify_teacher_runtime(path)
        self.assertEqual(report["versions"]["pytrio"], "0.2.9")
        self.assertEqual(report["versions"]["numpy"], "2.3.5")
        self.assertFalse(report["system_site_packages"])


if __name__ == "__main__":
    unittest.main()
