import csv
import hashlib
import importlib
import json
import subprocess
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq

from scripts.data_prep.common import export_dataset, fingerprint

try:
    report = importlib.import_module("scripts.gas_harness_report")
except ImportError:
    report = None


class GasHarnessReportTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(report, "The isolated Gas post-run report is not implemented")
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def fixture(self, *, deployed=True, matrix=False):
        package, pair = self.root / "package", self.root / "pair"
        initial = [{"x": float(i), "target": i} for i in range(1, 7)]
        targets = [[1, 2], [1, 1, 2, 2], [3] * 6, [4] * 2]
        static = [[1, 2], [1, 1, 2, 2], [1] * 6, [4, 1]]
        drift = [[2, 2], [2] * 4, [3, 3, 3, 3, 1, 1], [4, 1]]
        if matrix:
            targets = [[1, 1]] * 4
            static = [[1, 1]] * 4
            drift = [[1, 1], [1, 2], [1, 2], [1, 1]]
        rows = [{"x": float(index), "target": label, "batch_id": step,
                 "source_batch": step + 2}
                for step, batch in enumerate(targets) for index, label in enumerate(batch)]
        export_dataset(package, dataset="uci_gas", task="multiclass", features=["x"],
                       train_rows=initial, val_rows=initial, stream_rows=rows,
                       metadata={"classes": [1, 2, 3, 4, 5, 6],
                                 "stream_source_batches": [2, 3, 4, 5]})
        ids = np.arange(12, 12 + len(rows))
        offsets = np.cumsum([0, *(len(batch) for batch in targets)])
        for policy, prediction in (("static", static), ("drift", drift)):
            directory = pair / policy
            directory.mkdir(parents=True)
            np.savez_compressed(directory / "predictions.npz",
                                predictions=np.asarray(prediction) if matrix else np.concatenate(prediction),
                                sample_ids=ids, batch_offsets=offsets)
            events = [{"event": "run_started", "step": -1, "policy": policy}]
            for step, batch in enumerate(targets):
                events.append({"event": "prediction", "step": step, "samples": len(batch),
                               "model_version": int(policy == "drift" and deployed and step > 1)})
                if policy == "drift" and step == 0:
                    events.extend([
                        {"event": "harness_observation", "step": 0,
                         "observation": {"released_loss": 0.875, "source_step": 0}},
                        {"event": "harness_decision", "step": 0, "action": "RETRAIN_SMALL",
                         "reason": "fixed Mock rule"},
                        {"event": "experiment_started", "step": 0, "diagnosis": "released loss"},
                        {"event": "candidate_evaluated", "step": 0, "status": "completed",
                         "train_samples": 192, "validation_loss": 0.25},
                        {"event": "candidate_frozen", "step": 0, "candidate_id": 1, "frozen_at": 0},
                    ])
                if policy == "drift" and deployed and step == 1:
                    events.append({"event": "deploy", "step": 1, "model_version": 1,
                                   "reason": "independent_future_labels", "candidate_id": 1, "accepted": True,
                                   "frozen_at": 0, "gate_min_source_step": 1, "gate_max_source_step": 1,
                                   "gate_samples": 4, "old_loss": 1.0, "new_loss": 0.0, "gain": 1.0})
            events.append({"event": "run_completed", "step": 4})
            self.write_events(pair, policy, events)
        return package, pair

    @staticmethod
    def write_events(pair, policy, events):
        (pair / policy / "events.jsonl").write_text(
            "".join(json.dumps(event, allow_nan=False) + "\n" for event in events), encoding="utf-8")

    @staticmethod
    def events(pair, policy="drift"):
        return [json.loads(line) for line in (pair / policy / "events.jsonl").read_text().splitlines()]

    @staticmethod
    def replace_npz(pair, policy="drift", **changes):
        path = pair / policy / "predictions.npz"
        with np.load(path, allow_pickle=False) as saved:
            values = {name: saved[name].copy() for name in saved.files}
        values.update(changes)
        np.savez_compressed(path, **values)

    @staticmethod
    def mutate_stream(package, mutate):
        path = package / "test_stream.parquet"
        rows = pq.read_table(path).to_pylist()
        mutate(rows)
        pq.write_table(pa.Table.from_pylist(rows), path)
        manifest = json.loads((package / "manifest.json").read_text())
        manifest["files"]["stream"] = {**fingerprint(path), "path": path.name}
        (package / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")

    @staticmethod
    def snapshot(root):
        return {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
                for path in root.rglob("*") if path.is_file()}

    def test_weighted_scores_use_every_sample_and_only_actual_updated_predictions(self):
        package, pair = self.fixture()
        output = self.root / "report"
        assessment = report.build_report(pair, package, output)
        self.assertEqual(assessment["full_stream"]["static"]["correct"], 7)
        self.assertEqual(assessment["full_stream"]["static"]["sample_weighted_accuracy"], 0.5)
        self.assertEqual(assessment["full_stream"]["drift"]["correct"], 8)
        self.assertEqual(assessment["full_stream"]["drift"]["sample_weighted_accuracy"], 4 / 7)
        post = assessment["post_deployment"]
        self.assertEqual((post["samples"], post["correct"]), (8, 5))
        self.assertEqual(post["sample_weighted_accuracy"], 0.625)
        self.assertEqual(post["static_same_samples"]["sample_weighted_accuracy"], 0.125)
        self.assertEqual(post["accuracy_gain_vs_static"], 0.5)
        self.assertTrue(assessment["target"]["passed"])
        self.assertEqual([row["source_batch"] for row in post["by_batch"]], [4, 5])
        with (output / "batch_metrics.csv").open(newline="", encoding="utf-8") as stream:
            rows = list(csv.DictReader(stream))
        self.assertEqual([int(row["source_batch"]) for row in rows], [2, 3, 4, 5])
        self.assertEqual([int(row["samples"]) for row in rows], [2, 4, 6, 2])
        self.assertEqual([int(row["drift_model_version"]) for row in rows], [0, 0, 1, 1])
        self.assertEqual(float(rows[-1]["drift_cumulative_accuracy"]), 4 / 7)
        self.assertEqual(float(rows[2]["drift_loss"]), 1 / 3)
        self.assertEqual(json.loads((output / "assessment.json").read_text()), assessment)
        svg = ET.parse(output / "curves.svg").getroot()
        series = next(node for node in svg.iter() if node.get("id") == "drift-cumulative")
        last_y = float(series.get("points").split()[-1].split(",")[1])
        self.assertAlmostEqual(last_y, 690 - 220 * (4 / 7), places=4)
        self.assertIn("Offline retrospective", (output / "report.html").read_text(encoding="utf-8"))

    def test_equal_sized_two_dimensional_predictions_are_scored_without_row_loss(self):
        package, pair = self.fixture(matrix=True)
        assessment = report.build_report(pair, package, self.root / "report")
        self.assertEqual(assessment["full_stream"]["drift"]["sample_weighted_accuracy"], 0.75)
        self.assertEqual(assessment["post_deployment"]["sample_weighted_accuracy"], 0.75)
        self.assertEqual(assessment["full_stream"]["static"]["correct"], 8)

    def test_no_deployment_cannot_pass_even_when_all_saved_predictions_are_correct(self):
        package, pair = self.fixture(deployed=False, matrix=True)
        self.replace_npz(pair, predictions=np.ones((4, 2), dtype=int))
        assessment = report.build_report(pair, package, self.root / "report")
        self.assertEqual(assessment["full_stream"]["drift"]["sample_weighted_accuracy"], 1.0)
        self.assertFalse(assessment["target"]["passed"])
        self.assertEqual(assessment["post_deployment"]["samples"], 0)
        self.assertIsNone(assessment["post_deployment"]["sample_weighted_accuracy"])
        self.assertIsNone(assessment["post_deployment"]["static_same_samples"]["sample_weighted_accuracy"])

    def test_final_batch_deployment_is_counted_but_has_no_post_deployment_predictions(self):
        package, pair = self.fixture(deployed=False)
        events = self.events(pair)
        events.insert(-1, {"event": "deploy", "step": 3, "model_version": 1, "accepted": True,
                           "reason": "independent_future_labels", "candidate_id": 1,
                           "frozen_at": 0, "gate_min_source_step": 1, "gate_max_source_step": 1,
                           "gate_samples": 4})
        self.write_events(pair, "drift", events)
        assessment = report.build_report(pair, package, self.root / "report")
        self.assertEqual(assessment["events"]["updates"], 1)
        self.assertEqual(assessment["post_deployment"]["by_batch"], [])
        self.assertFalse(assessment["target"]["passed"])
        log = json.loads((self.root / "report/event_log.json").read_text())
        self.assertIsNone(log["deployment_timeline"][0]["first_next_prediction"])

    def test_target_requires_strictly_more_than_half(self):
        package, pair = self.fixture()
        self.replace_npz(pair, predictions=np.array([2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 1, 1, 1, 1]))
        assessment = report.build_report(pair, package, self.root / "report")
        self.assertEqual(assessment["post_deployment"]["sample_weighted_accuracy"], 0.5)
        self.assertFalse(assessment["target"]["passed"])

    def test_all_updated_versions_are_included_and_each_deployment_links_next_prediction(self):
        package, pair = self.fixture()
        events = self.events(pair)
        freeze_location = next(i for i, event in enumerate(events)
                               if event["event"] == "prediction" and event["step"] == 2)
        events.insert(freeze_location, {"event": "candidate_frozen", "step": 1, "candidate_id": 2, "frozen_at": 1})
        location = next(i for i, event in enumerate(events)
                        if event["event"] == "prediction" and event["step"] == 3)
        events.insert(location, {"event": "deploy", "step": 2, "model_version": 2, "accepted": True,
                                 "reason": "independent_future_labels", "candidate_id": 2,
                                 "frozen_at": 1, "gate_min_source_step": 2, "gate_max_source_step": 2,
                                 "gate_samples": 6})
        events[location + 1]["model_version"] = 2
        self.write_events(pair, "drift", events)
        assessment = report.build_report(pair, package, self.root / "report")
        self.assertEqual(assessment["events"]["updates"], 2)
        self.assertEqual(assessment["post_deployment"]["sample_weighted_accuracy"], 0.625)
        log = json.loads((self.root / "report/event_log.json").read_text())
        self.assertEqual([item["first_next_prediction"]["step"] for item in log["deployment_timeline"]], [2, 3])
        self.assertEqual([item["first_next_prediction"]["model_version"]
                          for item in log["deployment_timeline"]], [1, 2])

    def test_prediction_versions_must_follow_deployment_after_its_same_batch_prediction(self):
        package, pair = self.fixture()
        original = self.events(pair)
        mutations = []
        same_batch = json.loads(json.dumps(original))
        next(event for event in same_batch if event["event"] == "prediction" and event["step"] == 1)["model_version"] = 1
        mutations.append(same_batch)
        stale = json.loads(json.dumps(original))
        next(event for event in stale if event["event"] == "prediction" and event["step"] == 2)["model_version"] = 0
        mutations.append(stale)
        early = json.loads(json.dumps(original))
        deployment = next(event for event in early if event["event"] == "deploy")
        early.remove(deployment)
        early.insert(next(i for i, event in enumerate(early)
                          if event["event"] == "prediction" and event["step"] == 1), deployment)
        mutations.append(early)
        for index, events in enumerate(mutations):
            self.write_events(pair, "drift", events)
            with self.subTest(index=index), self.assertRaises(ValueError):
                report.build_report(pair, package, self.root / f"bad-{index}")
            self.assertFalse((self.root / f"bad-{index}").exists())

    def test_sample_ids_offsets_and_event_counts_must_match_true_rows(self):
        package, pair = self.fixture()
        path = pair / "drift/predictions.npz"
        original_npz = path.read_bytes()
        original_events = self.events(pair)
        cases = [
            {"sample_ids": np.arange(25, 11, -1)},
            {"batch_offsets": np.array([0, 2, 7, 12, 14])},
            {"predictions": np.ones(13, dtype=int)},
            {"predictions": np.ones((2, 7), dtype=int)},
        ]
        for index, changes in enumerate(cases):
            path.write_bytes(original_npz)
            self.replace_npz(pair, **changes)
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                report.build_report(pair, package, self.root / f"bad-npz-{index}")
        path.write_bytes(original_npz)
        for key, value in (("samples", 100), ("step", 7)):
            events = json.loads(json.dumps(original_events))
            next(event for event in events if event["event"] == "prediction")[key] = value
            self.write_events(pair, "drift", events)
            with self.subTest(key=key), self.assertRaises(ValueError):
                report.build_report(pair, package, self.root / f"bad-event-{key}")

    def test_unknown_prediction_class_and_target_class_are_rejected(self):
        package, pair = self.fixture()
        path = pair / "drift/predictions.npz"
        original = path.read_bytes()
        for index, value in enumerate((7, 1.5, float("nan"), "1")):
            path.write_bytes(original)
            values = np.ones(14, dtype=str if isinstance(value, str) else float)
            values[0] = value
            self.replace_npz(pair, predictions=values)
            with self.subTest(value=value), self.assertRaises(ValueError):
                report.build_report(pair, package, self.root / f"bad-class-{index}")
        path.write_bytes(original)
        self.mutate_stream(package, lambda rows: rows[0].update(target=7.0))
        with self.assertRaises(ValueError):
            report.build_report(pair, package, self.root / "bad-target")

    def test_true_batch_and_source_batch_boundaries_cannot_be_relabelled(self):
        package, pair = self.fixture()
        self.mutate_stream(package, lambda rows: rows[2].update(batch_id=0))
        with self.assertRaises(ValueError):
            report.build_report(pair, package, self.root / "bad-boundary")
        self.mutate_stream(package, lambda rows: rows[2].update(batch_id=1, source_batch=7))
        with self.assertRaises(ValueError):
            report.build_report(pair, package, self.root / "bad-source")

    def test_source_hash_mismatch_fails_before_creating_report(self):
        package, pair = self.fixture()
        with (package / "train.csv").open("a") as stream:
            stream.write("unexpected bytes\n")
        with self.assertRaises(ValueError):
            report.build_report(pair, package, self.root / "bad-hash")
        self.assertFalse((self.root / "bad-hash").exists())

    def test_event_log_preserves_observations_gate_results_and_expiration_reasons(self):
        package, pair = self.fixture()
        events = self.events(pair)
        events.insert(-1, {"event": "experiment_rejected", "step": 3,
                           "reason": "independent_validation_deadline", "candidate_id": 2})
        self.write_events(pair, "drift", events)
        assessment = report.build_report(pair, package, self.root / "report")
        self.assertEqual((assessment["events"]["rejections"], assessment["events"]["expirations"]), (1, 1))
        log = json.loads((self.root / "report/event_log.json").read_text())
        self.assertEqual(log["drift"], events)
        deployment = log["deployment_timeline"][0]
        self.assertEqual(deployment["deploy"]["step"], 1)
        self.assertEqual(deployment["first_next_prediction"]["step"], 2)
        self.assertEqual(deployment["first_next_prediction"]["model_version"], 1)
        markdown = (self.root / "report/event_log.md").read_text(encoding="utf-8")
        for expected in ("0.875", "candidate_evaluated", "candidate_frozen", "independent_future_labels",
                         "independent_validation_deadline", "first next prediction", "released"):
            self.assertIn(expected, markdown)
        svg = (self.root / "report/curves.svg").read_text(encoding="utf-8")
        for marker in ("RETRAIN_SMALL", "Freeze", "Gate", "Deploy", "Next prediction"):
            self.assertIn(marker, svg)

    def test_invalid_future_gate_source_and_duplicate_predictions_are_rejected(self):
        package, pair = self.fixture()
        events = self.events(pair)
        next(event for event in events if event["event"] == "deploy")["gate_min_source_step"] = 0
        self.write_events(pair, "drift", events)
        with self.assertRaises(ValueError):
            report.build_report(pair, package, self.root / "bad-gate")
        events.remove(next(event for event in events if event["event"] == "deploy"))
        events.insert(2, dict(events[1]))
        self.write_events(pair, "drift", events)
        with self.assertRaises(ValueError):
            report.build_report(pair, package, self.root / "bad-duplicate")

    def test_incomplete_or_failed_runs_are_rejected_for_both_policies(self):
        package, pair = self.fixture()
        originals = {policy: self.events(pair, policy) for policy in ("static", "drift")}
        for policy in originals:
            original = originals[policy]
            missing = original[:-1]
            failed = [*original, {"event": "run_failed", "step": 4, "reason": "write failed"}]
            duplicate = [*original, original[-1]]
            early = [original[0], original[-1], *original[1:-1]]
            wrong_clock = [*original[:-1], {"event": "run_completed", "step": 3}]
            for index, events in enumerate((missing, failed, duplicate, early, wrong_clock)):
                self.write_events(pair, policy, events)
                output = self.root / f"bad-lifecycle-{policy}-{index}"
                with self.subTest(policy=policy, index=index), self.assertRaises(ValueError):
                    report.build_report(pair, package, output)
                self.assertFalse(output.exists())
            self.write_events(pair, policy, original)

    def test_accepted_deployment_requires_complete_positive_independent_future_gate_evidence(self):
        package, pair = self.fixture()
        original = self.events(pair)
        missing_fields = ("accepted", "reason", "frozen_at", "gate_min_source_step",
                          "gate_max_source_step", "gate_samples")
        for field in missing_fields:
            events = json.loads(json.dumps(original))
            next(event for event in events if event["event"] == "deploy").pop(field)
            self.write_events(pair, "drift", events)
            output = self.root / f"bad-gate-missing-{field}"
            with self.subTest(field=field), self.assertRaises(ValueError):
                report.build_report(pair, package, output)
            self.assertFalse(output.exists())
        invalid = (("accepted", "yes"), ("reason", "legacy_selection"), ("gate_samples", 0),
                   ("gate_min_source_step", 0), ("gate_max_source_step", 2),
                   ("gate_samples", 1.5), ("frozen_at", None))
        for index, (field, value) in enumerate(invalid):
            events = json.loads(json.dumps(original))
            next(event for event in events if event["event"] == "deploy")[field] = value
            self.write_events(pair, "drift", events)
            output = self.root / f"bad-gate-invalid-{index}"
            with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                report.build_report(pair, package, output)
            self.assertFalse(output.exists())

    def test_report_output_and_original_inputs_are_immutable(self):
        package, pair = self.fixture()
        inputs_before = (self.snapshot(package), self.snapshot(pair))
        output = self.root / "report"
        report.build_report(pair, package, output)
        output_before = self.snapshot(output)
        with self.assertRaises(FileExistsError):
            report.build_report(pair, package, output)
        self.assertEqual(self.snapshot(output), output_before)
        self.assertEqual((self.snapshot(package), self.snapshot(pair)), inputs_before)

    def test_cli_builds_saved_archive_without_training(self):
        package, pair = self.fixture()
        result = subprocess.run([sys.executable, "-m", "scripts.gas_harness_report", "--pair", str(pair),
                                 "--package", str(package), "--output", str(self.root / "cli")],
                                cwd=Path(__file__).resolve().parents[1], capture_output=True, text=True, timeout=30)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["post_deployment"]["sample_weighted_accuracy"], 0.625)


if __name__ == "__main__":
    unittest.main()
