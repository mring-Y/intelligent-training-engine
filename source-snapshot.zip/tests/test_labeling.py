import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from ite.config import ExperimentConfig
from ite.labeling import LabelScheduler
from ite.runner import run_comparison


class LabelSchedulingTests(unittest.TestCase):
    def run_schedule(self, schedule, **changes):
        config = ExperimentConfig.from_dict({
            "n_batches": 12, "batch_size": 16, "label_delay": 2,
            "max_labels": 24, "max_train_seconds": 0,
            "label_schedule": schedule, **changes})
        with tempfile.TemporaryDirectory() as directory:
            summary = run_comparison(config, Path(directory), policies=("periodic",))[0]
            events = [json.loads(line) for line in
                      (Path(directory) / "periodic/events.jsonl").read_text().splitlines()]
        return summary, events

    def test_uniform_budget_reaches_late_stream_and_is_released_before_end(self):
        summary, events = self.run_schedule("uniform")
        requests = [e for e in events if e["event"] == "labels_requested"]
        self.assertEqual(summary["labels_requested"], 24)
        self.assertEqual(summary["labels_released"], 24)
        self.assertGreater(requests[9]["count"], 0)
        self.assertEqual([e["count"] for e in requests[10:]], [0, 0])
        self.assertLessEqual(max(e["count"] for e in requests), 4)

    def test_adaptive_spends_same_total_and_keeps_monitoring_until_end(self):
        from ite.labeling import LabelScheduler
        config = ExperimentConfig.from_dict({"n_batches": 12, "batch_size": 16,
            "label_delay": 2, "max_labels": 24, "label_schedule": "adaptive"})
        scheduler, used, counts = LabelScheduler(config), 0, []
        for step in range(12):
            count = scheduler.count(step, used, performance_drop=2 <= step < 6)
            counts.append(count)
            used += count
        self.assertEqual(used, 24)
        self.assertGreater(counts[2], counts[0])
        self.assertGreater(counts[9], 0)
        self.assertEqual(counts[10:], [0, 0])
        self.assertLessEqual(max(counts), 4)

    def test_no_labels_are_requested_when_budget_or_release_horizon_is_zero(self):
        for changes in ({"max_labels": 0}, {"label_delay": 20}):
            summary, events = self.run_schedule("uniform", **changes)
            self.assertEqual(summary["labels_requested"], 0)
            self.assertEqual(summary["labels_released"], 0)

    def test_legacy_schedule_still_exhausts_budget_early(self):
        summary, events = self.run_schedule("frontloaded")
        counts = [e["count"] for e in events if e["event"] == "labels_requested"]
        self.assertEqual(counts, [4] * 6 + [0] * 6)
        self.assertEqual(summary["labels_requested"], 24)

    def test_only_requested_unreleased_predictions_are_retained_online(self):
        summary, _ = self.run_schedule("uniform", n_batches=96, max_labels=24)
        self.assertLessEqual(summary["peak_prediction_cache"], 3)
        self.assertEqual(summary["remaining_prediction_cache"], 0)

    def test_schedule_and_predictions_are_deterministic(self):
        outputs = []
        config = ExperimentConfig.from_dict({"n_batches": 8, "label_schedule": "adaptive",
                                            "max_train_seconds": 0})
        for _ in range(2):
            with tempfile.TemporaryDirectory() as directory:
                summary = run_comparison(config, Path(directory), policies=("drift",))[0]
                with np.load(Path(directory) / "drift/predictions.npz", allow_pickle=False) as data:
                    outputs.append((summary["labels_requested"], data["predictions"].copy()))
        self.assertEqual(outputs[0][0], outputs[1][0])
        np.testing.assert_array_equal(outputs[0][1], outputs[1][1])


class StartupLabelSchedulingTests(unittest.TestCase):
    def scheduler(self, startup=144, **changes):
        values = ExperimentConfig.from_dict({"n_batches": 96, "label_schedule": "adaptive",
                                             **changes}).to_dict()
        # A protocol fixture lets missing startup behavior fail on allocation,
        # independently of configuration-field support.
        return LabelScheduler(SimpleNamespace(**{**values, "label_startup_budget": startup}))

    def test_startup_supplies_training_and_selection_labels_in_first_six_batches(self):
        scheduler, used, counts = self.scheduler(), 0, []
        for step in range(10):
            count = scheduler.count(step, used)
            counts.append(count)
            used += count
        self.assertEqual(counts[:6], [24] * 6)
        self.assertEqual(counts[6:], [5, 4, 5, 4])
        self.assertEqual(used, 162)

    def test_partial_startup_stops_at_its_quota_without_an_extra_full_batch(self):
        scheduler = self.scheduler(startup=30)
        self.assertEqual(scheduler.count(0, 0), 24)
        self.assertEqual(scheduler.count(1, 24), 6)
        self.assertEqual(scheduler.count(2, 30), 4)

    def test_startup_and_continuous_degradation_preserve_late_monitoring_reserve(self):
        scheduler, used, counts = self.scheduler(), 0, []
        for step in range(96):
            count = scheduler.count(step, used, performance_drop=True, pending=True)
            self.assertGreaterEqual(count, 0)
            self.assertLessEqual(count, 24)
            used += count
            counts.append(count)
            self.assertLessEqual(used, 864)
            if step == 46:  # Half of the 94 label-producing batches remain.
                self.assertGreaterEqual(864 - used, 216)
        self.assertEqual(used, 864)
        self.assertGreater(counts[93], 0)
        self.assertEqual(counts[94:], [0, 0])

    def test_startup_obeys_small_budget_and_short_or_empty_release_horizon(self):
        cases = (({"max_labels": 0}, 0), ({"label_fraction": 0}, 0),
                 ({"label_delay": 96}, 0), ({"max_labels": 3}, 3),
                 ({"n_batches": 4, "label_delay": 2}, 48))
        for changes, expected in cases:
            with self.subTest(changes=changes):
                scheduler, used = self.scheduler(**changes), 0
                for step in range(scheduler.config.n_batches):
                    used += scheduler.count(step, used, performance_drop=True)
                self.assertEqual(used, expected)

    def test_zero_startup_retains_existing_allocation(self):
        scheduler = self.scheduler(startup=0)
        used, counts = 0, []
        for step in range(10):
            count = scheduler.count(step, used)
            used += count
            counts.append(count)
        self.assertEqual(counts, [4, 5, 4, 5, 4, 5, 5, 4, 5, 4])
        self.assertEqual(used, 45)

    def test_startup_configuration_roundtrips_and_rejects_invalid_or_ignored_values(self):
        try:
            config = ExperimentConfig.from_dict({"label_schedule": "adaptive", "label_startup_budget": 144})
        except ValueError as error:
            self.fail(f"Startup allocation configuration is missing: {error}")
        self.assertEqual(ExperimentConfig.from_dict(config.to_dict()), config)
        self.assertEqual(config.label_startup_budget, 144)
        self.assertEqual(ExperimentConfig().label_startup_budget, 0)
        for invalid in (-1, True, 1.5, None):
            with self.subTest(invalid=invalid), self.assertRaises(ValueError):
                ExperimentConfig(label_schedule="adaptive", label_startup_budget=invalid)
        for schedule in ("frontloaded", "uniform"):
            with self.subTest(schedule=schedule), self.assertRaises(ValueError):
                ExperimentConfig(label_schedule=schedule, label_startup_budget=144)

    def test_real_run_releases_startup_labels_only_after_delay_and_records_setting(self):
        try:
            summary, events = LabelSchedulingTests().run_schedule("adaptive", label_startup_budget=12)
        except ValueError as error:
            self.fail(f"Startup allocation cannot run: {error}")
        requests = [e for e in events if e["event"] == "labels_requested"]
        releases = [e for e in events if e["event"] == "labels_released"]
        self.assertEqual([e["count"] for e in requests[:3]], [4, 4, 4])
        self.assertEqual(releases[0]["step"], 2)
        self.assertEqual(releases[0]["latest_source_step"], 0)
        self.assertEqual(releases[0]["count"], 4)
        self.assertEqual(summary["labels_requested"], 24)
        self.assertEqual(summary["labels_released"], 24)
        self.assertEqual(summary["label_startup_budget"], 12)


if __name__ == "__main__":
    unittest.main()
