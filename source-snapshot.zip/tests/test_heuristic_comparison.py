"""The override experiment must not fit its validation labels."""

import json
import tempfile
import unittest
from pathlib import Path

import numpy as np

from tests.test_official_sft_replay import ConstantModel


class HeuristicComparisonTests(unittest.TestCase):
    def test_strict_training_loader_uses_only_public_train_and_excludes_a_reserve(self):
        from ite.heuristic_override import load_training_stream
        from ite.official_sft_data import load_public_package
        for profile in "ABC":
            data=load_public_package(profile)
            stream=load_training_stream(profile,exclude_a_reserve=True)
            self.assertFalse(set(stream["ids"]) & set(data["ids"]))
            if profile=="A":
                self.assertEqual(len(stream["ids"]),397)
                self.assertFalse(set(stream["ids"]) & set(data["replay_reserve"]["ids"]))
            self.assertEqual(stream["x"].shape[1],data["x"].shape[1])

    def test_rule_replay_trains_on_separate_ids_and_requires_future_gate(self):
        from ite.official_sft_replay import replay_partition
        n=1536
        y=np.repeat([1.,1.,1.,1.,1.,2.,1.9,1.9,1.9,1.9,1.9,1.9],128)
        data={"profile":"C","task":"regression","unit":"cycles","loss_scale":1.,
              "x":np.zeros((n,2)),"y":y,"ids":[f"val-{i}" for i in range(n)],
              "groups":["engine"]*n,"scale":np.ones(2)}
        stream={"x":np.zeros((n,2)),"y":np.full(n,7.),"ids":[f"train-{i}" for i in range(n)]}
        calls=[]
        class Candidate(ConstantModel):
            checkpoint_sha256="new";steps=11
            def predict(self,x):return np.full(len(x),1.)
            def save(self,path):np.savez_compressed(path,selected_marker=np.asarray(1))
        def train(parent,x,y,seconds,**kwargs):
            calls.append((y.copy(),kwargs))
            return Candidate(),.01
        with tempfile.TemporaryDirectory() as tmp:
            result=replay_partition(data,np.arange(n),"train","abrupt",Path(tmp)/"run",ConstantModel(),
                lambda _: {"action":"DO_NOTHING","reason":"NO control","source":"no_behavior_control"},
                decision_steps=(7,),trainer=train,action_profile="official_finetune",
                heuristic_override=True,training_stream=stream)
            events=[json.loads(s) for s in (Path(tmp)/"run/events.jsonl").read_text().splitlines()]
            with np.load(Path(tmp)/"run/selected.npz",allow_pickle=False) as checkpoint:
                self.assertEqual(checkpoint["selected_marker"].item(),1)
        self.assertEqual(len(calls),1)
        self.assertEqual(len(calls[0][0]),720)
        np.testing.assert_array_equal(calls[0][0],7.)
        self.assertEqual(calls[0][1],{"trainable_policy":"head_only"})
        fit=next(e for e in events if e["event"]=="candidate_evaluated")
        self.assertTrue(all(s.startswith("train-") for s in fit["train_source_ids"]))
        deploy=next(e for e in events if e["event"]=="deploy")
        self.assertGreater(deploy["gate_min_source_step"],deploy["frozen_at"])
        self.assertEqual(result["updates"],1)

    def test_override_requires_explicit_training_stream_and_rejects_overlap(self):
        from ite.official_sft_replay import replay_partition
        data={"profile":"C","task":"regression","x":np.zeros((96,2)),"y":np.ones(96),
              "ids":[f"v{i}" for i in range(96)],"groups":["engine"]*96,"scale":np.ones(2),
              "unit":"cycles","loss_scale":1.}
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(ValueError):
                replay_partition(data,np.arange(96),"train","stable",Path(tmp)/"missing",ConstantModel(),
                    None,heuristic_override=True)
            with self.assertRaises(ValueError):
                replay_partition(data,np.arange(96),"train","stable",Path(tmp)/"overlap",ConstantModel(),
                    None,heuristic_override=True,training_stream={"x":data["x"],"y":data["y"],"ids":data["ids"]})

    def test_acceptance_uses_registered_tolerances_and_never_hides_static_equivalence(self):
        from scripts.run_heuristic_comparison import assess_metrics
        a={"macro_f1":.50,"accuracy":.7}
        self.assertFalse(assess_metrics("A",a,a,"abrupt")["primary_improved"])
        self.assertTrue(assess_metrics("A",a,{"macro_f1":.51,"accuracy":.696},"abrupt")["passed"])
        self.assertFalse(assess_metrics("A",a,{"macro_f1":.51,"accuracy":.69},"abrupt")["passed"])
        c={"rmse":100.,"mae":80.,"overestimate_rate":.16,"mean_overestimate":5.}
        self.assertTrue(assess_metrics("C",c,{**c,"rmse":98.,"overestimate_rate":.179,"mean_overestimate":5.8},"abrupt")["passed"])
        self.assertFalse(assess_metrics("C",c,{**c,"rmse":98.,"overestimate_rate":.181},"abrupt")["passed"])


if __name__=="__main__":unittest.main()
