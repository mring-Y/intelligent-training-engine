import json
import io
import tempfile
import unittest
import zipfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from ite.tracking import source_metadata, upload_swanlab


class CalibrationArchiveTests(unittest.TestCase):
    def test_audit_archive_keeps_checkpoint_bound_policies_without_uploading(self):
        from ite.tracking import _audit_archive
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "events.jsonl").write_text('{"event":"run_completed","step":1}\n', encoding="utf-8")
            for filename in ("initial.npz", "deployed.npz", "model-v1.npz"):
                (root / filename).write_bytes(b"checkpoint")
                (root / (filename + ".policy.json")).write_text('{"safety_margin":5}', encoding="utf-8")
            archive, manifest, summaries = _audit_archive(root)
            with zipfile.ZipFile(archive) as bundle:
                for filename in ("initial.npz", "deployed.npz", "model-v1.npz"):
                    self.assertIn(filename + ".policy.json", bundle.namelist())


PROJECT_PATH = "mring-Y/Intelligent_Training_Engine"


class PublicResponse(io.BytesIO):
    status = 200
    headers = {"Content-Type": "application/json"}

    def __init__(self, payload=None):
        super().__init__(json.dumps(payload or {"name": "Intelligent_Training_Engine",
            "path": PROJECT_PATH, "visibility": "PUBLIC", "cuid": "project-1"}).encode())


def public_sdk(sdk, visibility="PUBLIC"):
    class Settings:
        Project = SimpleNamespace

        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    sdk.Settings = Settings
    project = SimpleNamespace(name="Intelligent_Training_Engine", path=PROJECT_PATH,
                              visibility=visibility, project_id="project-1")
    sdk.Api = lambda: SimpleNamespace(project=lambda path: project, username="mring-Y",
        _ctx=SimpleNamespace(api_host="https://api.swanlab.cn"))
    return sdk


class RecordingTests(unittest.TestCase):
    def setUp(self):
        self.anonymous = patch("urllib.request.urlopen", side_effect=lambda *a, **k: PublicResponse())
        self.anonymous.start()
        self.addCleanup(self.anonymous.stop)

    def test_source_metadata_rejects_a_falsely_claimed_container_hash(self):
        with patch.dict("os.environ", {"ITE_SOURCE_COMMIT": "abc123", "ITE_SOURCE_DIRTY": "false",
                                       "ITE_SOURCE_SHA256": "0" * 64}):
            with self.assertRaisesRegex(RuntimeError, "source hash mismatch"):
                source_metadata()

    def test_source_metadata_uses_embedded_commit_without_git(self):
        with patch.dict("os.environ", {"ITE_SOURCE_COMMIT": "abc123", "ITE_SOURCE_DIRTY": "true",
                                       "ITE_SOURCE_SHA256": source_metadata()["source_sha256"]}):
            with patch("ite.tracking.subprocess.run", side_effect=FileNotFoundError):
                metadata = source_metadata()
        self.assertEqual(metadata["source_commit"], "abc123")
        self.assertTrue(metadata["source_dirty"])

    def test_matrix_archive_contains_each_policy_audit_and_summaries(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for policy in ("static", "drift"):
                local = root / policy
                local.mkdir()
                (local / "config.json").write_text('{"task":"classification"}')
                (local / "events.jsonl").write_text('{"event":"run_completed","step":2}\n')
                (local / "summary.json").write_text(json.dumps({"policy": policy, "mean_loss": 0.2}))
            (root / ".env").write_text("must-never-upload")
            state = {"logged": [], "saved": []}

            class Run:
                url = "https://swanlab.cn/example/run"

                def log(self, metrics, step):
                    state["logged"].append(metrics)

                def save(self, path, **kwargs):
                    state["saved"].append(path)

                def finish(self):
                    pass

            sdk = public_sdk(SimpleNamespace(login=lambda **kwargs: True, init=lambda **kwargs: Run(), Text=lambda x: x))
            with patch("ite.tracking.importlib.import_module", return_value=sdk):
                result = upload_swanlab(root, "Intelligent_Training_Engine", "mring-Y", archive=True)
            self.assertEqual(result["policy_runs"], 2)
            with zipfile.ZipFile(state["saved"][0]) as bundle:
                self.assertIn("static/events.jsonl", bundle.namelist())
                self.assertIn("drift/events.jsonl", bundle.namelist())
                self.assertIn("manifest.json", bundle.namelist())
                self.assertNotIn(".env", bundle.namelist())

    def test_upload_reuses_account_and_preserves_complete_audit_events(self):
        with tempfile.TemporaryDirectory() as directory:
            run_dir = Path(directory) / "drift"
            run_dir.mkdir()
            (run_dir / "config.json").write_text('{"scenario":"abrupt"}', encoding="utf-8")
            event = {"event": "deploy", "step": 7, "accepted": True, "reason": "validation gain"}
            (run_dir / "events.jsonl").write_text(json.dumps(event), encoding="utf-8")
            state = {}

            class Run:
                def log(self, metrics, step):
                    state["metrics"], state["step"] = metrics, step

                def finish(self):
                    state["finished"] = True

            def initialize(**kwargs):
                state["init"] = kwargs
                return Run()

            sdk = public_sdk(SimpleNamespace(login=lambda **kwargs: state.setdefault("login", kwargs),
                                  init=initialize, Text=lambda value: {"text": value}))
            with patch("ite.tracking.importlib.import_module", return_value=sdk):
                result = upload_swanlab(run_dir, "Intelligent_Training_Engine", "mring-Y")

            self.assertEqual(state["login"], {"save": False})
            self.assertEqual(state["init"]["project"], "Intelligent_Training_Engine")
            self.assertEqual(state["init"]["workspace"], "mring-Y")
            self.assertEqual(state["init"]["mode"], "online")
            replayed = json.loads(state["metrics"]["audit/event_json"]["text"])
            self.assertEqual(replayed["reason"], "validation gain")
            self.assertTrue(state["finished"])
            self.assertEqual(result["project"], "Intelligent_Training_Engine")
            self.assertIn("settings", state["init"])
            self.assertTrue(state["init"]["settings"].project.public)
            self.assertEqual(result["visibility"], "PUBLIC")
            self.assertTrue(result["anonymous_access"]["verified"])

    def replay_fixture(self, root, events, visibility="PUBLIC", archive=False):
        local = root / "drift" if archive else root
        local.mkdir(exist_ok=True)
        (local / "config.json").write_text("{}", encoding="utf-8")
        (local / "events.jsonl").write_text("\n".join(json.dumps(e) for e in events), encoding="utf-8")
        state = {"logs": [], "initialized": False, "finished": False}

        class Run:
            url = "https://swanlab.cn/example/run"

            def log(self, metrics, step):
                state["logs"].append((step, metrics))

            def save(self, path, **kwargs):
                state["saved"] = path

            def finish(self):
                state["finished"] = True

        def initialize(**kwargs):
            state["initialized"] = True
            return Run()

        sdk = public_sdk(SimpleNamespace(login=lambda **kwargs: True, init=initialize, Text=lambda x: x), visibility)
        return sdk, state

    def test_private_or_unknown_visibility_fails_before_upload_and_receipt(self):
        for visibility in ("PRIVATE", "", None, "public"):
            with self.subTest(visibility=visibility), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                sdk, state = self.replay_fixture(root, [], visibility)
                with patch("ite.tracking.importlib.import_module", return_value=sdk):
                    with self.assertRaisesRegex(RuntimeError, "PUBLIC"):
                        upload_swanlab(root, "Intelligent_Training_Engine", "mring-Y")
                self.assertFalse(state["initialized"])
                self.assertFalse((root / "cloud-upload.json").exists())

    def test_anonymous_spa_and_wrong_identity_do_not_prove_public_access(self):
        for payload in ({"html": "SPA"}, {"path": "another/project", "name": "project", "visibility": "PUBLIC"},
                        {"path": PROJECT_PATH, "name": "Intelligent_Training_Engine", "visibility": "PRIVATE"}):
            with self.subTest(payload=payload), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                sdk, state = self.replay_fixture(root, [])
                with patch("urllib.request.urlopen", side_effect=lambda *a, **k: PublicResponse(payload)), patch(
                        "ite.tracking.importlib.import_module", return_value=sdk):
                    with self.assertRaisesRegex(RuntimeError, "anonymous"):
                        upload_swanlab(root, "Intelligent_Training_Engine", "mring-Y")
                self.assertFalse(state["initialized"])

    def test_each_action_and_linked_gate_is_visible_in_both_upload_modes(self):
        observation = {"metrics": {"loss": 0.4}}
        events = [
            {"event": "harness_observation", "step": 2, "observation": observation},
            {"event": "harness_decision", "step": 2, "action": "RETRAIN_SMALL", "reason": "loss up",
             "decision_id": "d1", "harness_state": "ACTIVE"},
            {"event": "candidate_frozen", "step": 2, "candidate_id": 1, "decision_id": "d1", "attempt_id": "a1"},
            {"event": "deploy", "step": 5, "candidate_id": 1, "decision_id": "d1", "attempt_id": "a1",
             "accepted": True, "reason": "independent_future_labels"},
            {"event": "harness_decision", "step": 6, "action": "DO_NOTHING", "reason": "steady",
             "observation": observation, "decision_id": "d2", "harness_state": "ACTIVE"},
            {"event": "harness_call", "step": 6, "decision_id": "d2", "parsed_action": {"action": "DO_NOTHING", "reason": "steady"},
             "observation": observation},
            {"event": "harness_call", "step": 7, "decision_id": "d3", "harness_state": "STATIC_FALLBACK",
             "parsed_action": {"action": "RETRAIN_SMALL", "reason": "intercepted by budget"}, "observation": observation},
        ]
        for archive in (False, True):
            with self.subTest(archive=archive), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                sdk, state = self.replay_fixture(root, events, archive=archive)
                with patch("ite.tracking.importlib.import_module", return_value=sdk):
                    upload_swanlab(root, "Intelligent_Training_Engine", "mring-Y", archive=archive)
                logs = [metrics for _, metrics in state["logs"]]
                actions = [json.loads(m["audit/action_json"]) for m in logs if "audit/action_json" in m]
                self.assertEqual([a["decision_id"] for a in actions], ["d1", "d2", "d3"])
                self.assertEqual([a["observation"] for a in actions], [observation] * 3)
                self.assertEqual([a["reason"] for a in actions], ["loss up", "steady", "intercepted by budget"])
                self.assertEqual(actions[0]["execution_state"], "deployed")
                self.assertEqual(actions[0]["attempt_id"], "a1")
                self.assertEqual(actions[1]["execution_state"], "DO_NOTHING")
                self.assertEqual(actions[2]["execution_state"], "STATIC_FALLBACK")
                gates = [json.loads(m["audit/gate_json"]) for m in logs if "audit/gate_json" in m]
                self.assertEqual(len(gates), 1)
                self.assertEqual(gates[0]["decision"]["decision_id"], "d1")
                self.assertEqual(gates[0]["decision"]["observation"], observation)
                self.assertEqual(gates[0]["outcome"]["step"], 5)
                self.assertEqual(len([m for m in logs if "audit/event_json" in m]), len(events))

    def test_archive_includes_approved_ledgers_but_rejects_embedded_credentials(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            sdk, state = self.replay_fixture(root, [{"event": "run_completed", "step": 1}], archive=True)
            for name in ("iteration-audit.json", "stream-manifest.json", "cost-audit.json", "paid-call-ledger.json", "source-freeze.json"):
                (root / name).write_text('{"calls": 1}', encoding="utf-8")
            (root / "credentials.json").write_text('{"api_key": "never-upload"}', encoding="utf-8")
            with patch("ite.tracking.importlib.import_module", return_value=sdk):
                upload_swanlab(root, "Intelligent_Training_Engine", "mring-Y", archive=True)
            with zipfile.ZipFile(state["saved"]) as bundle:
                self.assertIn("paid-call-ledger.json", bundle.namelist())
                self.assertIn("iteration-audit.json", bundle.namelist())
                self.assertIn("source-freeze.json", bundle.namelist())
                self.assertNotIn("credentials.json", bundle.namelist())
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            sdk, state = self.replay_fixture(root, [], archive=True)
            (root / "paid-call-ledger.json").write_text('{"nested": {"api_key": "never-upload"}}', encoding="utf-8")
            with patch("ite.tracking.importlib.import_module", return_value=sdk):
                with self.assertRaisesRegex(ValueError, "credential"):
                    upload_swanlab(root, "Intelligent_Training_Engine", "mring-Y", archive=True)
            self.assertFalse(state["initialized"])

    def test_anonymous_probe_carries_no_authentication_and_checks_again_after_finish(self):
        requests = []
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            sdk, state = self.replay_fixture(root, [])

            def probe(request, **kwargs):
                requests.append((request, state["finished"]))
                return PublicResponse()

            with patch("urllib.request.urlopen", side_effect=probe), patch("ite.tracking.importlib.import_module", return_value=sdk):
                receipt = upload_swanlab(root, "Intelligent_Training_Engine", "mring-Y")
            self.assertEqual([finished for _, finished in requests], [False, True])
            for request, _ in requests:
                self.assertEqual(request.full_url, "https://api.swanlab.cn/api/project/" + PROJECT_PATH)
                self.assertEqual(dict(request.header_items()), {"Accept": "application/json"})
            self.assertEqual(receipt["anonymous_access"]["authentication"], "none")

    def test_public_access_lost_after_upload_does_not_write_success_receipt(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            sdk, state = self.replay_fixture(root, [])
            responses = [PublicResponse(), PublicResponse({"visibility": "PRIVATE"})]
            with patch("urllib.request.urlopen", side_effect=responses), patch("ite.tracking.importlib.import_module", return_value=sdk):
                with self.assertRaisesRegex(RuntimeError, "anonymous"):
                    upload_swanlab(root, "Intelligent_Training_Engine", "mring-Y")
            self.assertTrue(state["finished"])
            self.assertFalse((root / "cloud-upload.json").exists())

    def test_archive_does_not_replay_hidden_credential_directory_events(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            sdk, state = self.replay_fixture(root, [{"event": "run_completed", "step": 1}], archive=True)
            hidden = root / ".credentials"
            hidden.mkdir()
            (hidden / "events.jsonl").write_text('{"event":"credential","step":0,"api_key":"never-upload"}')
            with patch("ite.tracking.importlib.import_module", return_value=sdk):
                receipt = upload_swanlab(root, "Intelligent_Training_Engine", "mring-Y", archive=True)
            self.assertEqual(receipt["policy_runs"], 1)
            events = [json.loads(m["audit/event_json"]) for _, m in state["logs"] if "audit/event_json" in m]
            self.assertEqual(events, [{"event": "run_completed", "step": 1}])

    def test_legacy_decision_has_step_local_observation_and_candidate_linked_gate(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            events = [
                {"event": "harness_observation", "step": 1, "observation": {"loss": 0.2}},
                {"event": "harness_decision", "step": 1, "action": "RETRAIN_SMALL", "reason": "drift"},
                {"event": "candidate_frozen", "step": 1, "candidate_id": 4},
                {"event": "experiment_rejected", "step": 4, "candidate_id": 4, "reason": "independent_future_labels", "accepted": False},
                {"event": "harness_decision", "step": 5, "action": "DO_NOTHING", "reason": "no observation"}]
            sdk, state = self.replay_fixture(root, events)
            with patch("ite.tracking.importlib.import_module", return_value=sdk):
                upload_swanlab(root, "Intelligent_Training_Engine", "mring-Y")
            actions = [json.loads(m["audit/action_json"]) for _, m in state["logs"] if "audit/action_json" in m]
            self.assertEqual(actions[0]["observation"], {"loss": 0.2})
            self.assertEqual(actions[0]["execution_state"], "rejected")
            self.assertFalse(actions[1]["observation_available"])
            self.assertIsNone(actions[1]["observation"])
            gates = [json.loads(m["audit/gate_json"]) for _, m in state["logs"] if "audit/gate_json" in m]
            self.assertEqual(gates[0]["outcome"]["candidate_id"], 4)


if __name__ == "__main__":
    unittest.main()
