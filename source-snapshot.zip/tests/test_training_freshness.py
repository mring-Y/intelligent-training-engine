import json
import tempfile
import unittest
from pathlib import Path

import numpy as np

from ite.config import ExperimentConfig
from ite.controller import AdaptationController
from ite.data import ReleasedLabels, make_simulation
from ite.models import RidgeModel, prediction_loss
from ite.runner import run_comparison
from ite.tracking import JsonlLogger
from ite.training import BoundedTrainer


class TrainingFreshnessTests(unittest.TestCase):
    def config(self, **overrides):
        return ExperimentConfig.from_dict({
            "task": "regression", "n_features": 3, "n_batches": 96,
            "deployment_validation": "future", "history_windows": [192],
            "candidate_alphas": [1.0], "min_gain": 0,
            "train_source_window_batches": 8, **overrides})

    def test_window_accepts_only_nonnegative_integers_and_roundtrips(self):
        config = self.config()
        self.assertEqual(ExperimentConfig.from_dict(json.loads(json.dumps(config.to_dict()))), config)
        self.assertEqual(ExperimentConfig().train_source_window_batches, 0)
        for value in (-1, True, False, 1.5, None, "8"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                self.config(train_source_window_batches=value)

    def test_inclusive_source_cutoff_preserves_selection_and_future_gate(self):
        rng = np.random.default_rng(811)
        x = rng.normal(size=(288, 3))
        y = 2 * x[:, 0] - x[:, 1]
        original = RidgeModel("regression").fit(x, -y)
        with tempfile.TemporaryDirectory() as directory, BoundedTrainer() as trainer:
            root = Path(directory)
            with JsonlLogger(root / "events.jsonl", "freshness") as logger:
                controller = AdaptationController(self.config(), "periodic", original, .01, 1,
                                                  logger, trainer, root)
                controller.history_x, controller.history_y = x, y
                controller.history_steps = np.repeat(np.arange(12), 24)
                # Processing clock 50 must not replace latest released source 11.
                controller._experiment(50, {"diagnosis": "performance"})
                self.assertIs(controller.gate.model, original)
                self.assertIsNotNone(controller.pending)
                expected = RidgeModel("regression", 1).fit(x[96:240], y[96:240])
                np.testing.assert_allclose(controller.pending["model"].predict(x), expected.predict(x))
                selection_loss = prediction_loss("regression", y[240:], expected.predict(x[240:]))
                self.assertAlmostEqual(controller.pending["spec"]["selection_loss"], selection_loss)
                ids = np.arange(48)
                # Even labels arriving after freeze cannot be reused if generated at freeze.
                controller._validate_pending(ReleasedLabels(ids, x[-48:], y[-48:], np.full(48, 50)), 52)
                self.assertIs(controller.gate.model, original)
                self.assertEqual(controller.pending["y"], [])
                controller._validate_pending(ReleasedLabels(ids, x[-48:], y[-48:], np.full(48, 51)), 53)
                self.assertEqual(controller.gate.updates, 1)
                np.testing.assert_array_equal(RidgeModel.load(root / "deployed.npz").predict(x),
                                              controller.predict(x))
            events = [json.loads(line) for line in (root / "events.jsonl").read_text().splitlines()]
            started = next(e for e in events if e["event"] == "experiment_started")
            self.assertEqual((started["train_min_step"], started["train_max_step"]), (4, 9))
            self.assertEqual((started["validation_min_step"], started["validation_samples"]), (10, 48))
            self.assertEqual(started["train_source_cutoff"], 4)
            self.assertEqual(started["train_samples_before_filter"], 240)
            self.assertEqual(started["train_samples"], 144)
            deploy = next(e for e in events if e["event"] == "deploy")
            self.assertEqual((deploy["gate_min_source_step"], deploy["gate_samples"]), (51, 48))

    def test_sparse_old_labels_skip_below_existing_sixteen_sample_floor(self):
        for recent_count in (0, 15, 16):
            with self.subTest(recent_count=recent_count):
                steps = np.concatenate((np.repeat(np.arange(3), 24), np.full(recent_count, 4), np.full(48, 11)))
                rng = np.random.default_rng(812)
                x = rng.normal(size=(len(steps), 3))
                y = 2 * x[:, 0] - x[:, 1]
                model = RidgeModel("regression").fit(x, -y)
                with tempfile.TemporaryDirectory() as directory, BoundedTrainer() as trainer:
                    root = Path(directory)
                    with JsonlLogger(root / "events.jsonl", "sparse") as logger:
                        controller = AdaptationController(self.config(), "periodic", model, .01, 1,
                                                          logger, trainer, root)
                        controller.history_x, controller.history_y, controller.history_steps = x, y, steps
                        before = controller.predict(x)
                        controller._experiment(13, {"diagnosis": "performance"})
                        np.testing.assert_array_equal(controller.predict(x), before)
                        self.assertEqual(controller.gate.updates, 0)
                        self.assertEqual(controller.budget.experiments, 1)
                    events = [json.loads(line) for line in (root / "events.jsonl").read_text().splitlines()]
                    candidates = [e for e in events if e["event"] == "candidate_evaluated"]
                    if recent_count < 16:
                        self.assertEqual(candidates, [])
                        self.assertEqual(controller.budget.train_seconds, 0)
                        skipped = next(e for e in events if e["event"] == "experiment_skipped")
                        self.assertEqual(skipped["reason"], "insufficient_temporally_separate_labels")
                        self.assertEqual(skipped["train_samples"], recent_count)
                        self.assertEqual(skipped["validation_samples"], 48)
                    else:
                        self.assertEqual(len(candidates), 1)
                        self.assertEqual(candidates[0]["train_samples"], 16)

    def test_zero_disables_time_filter_but_keeps_original_sample_window(self):
        rng = np.random.default_rng(813)
        x = rng.normal(size=(288, 3))
        y = x[:, 0] - x[:, 1]
        original = RidgeModel("regression").fit(x, -y)
        with tempfile.TemporaryDirectory() as directory, BoundedTrainer() as trainer:
            root = Path(directory)
            with JsonlLogger(root / "events.jsonl", "disabled") as logger:
                controller = AdaptationController(self.config(train_source_window_batches=0), "periodic",
                                                  original, .01, 1, logger, trainer, root)
                controller.history_x, controller.history_y = x, y
                controller.history_steps = np.repeat(np.arange(12), 24)
                controller._experiment(50, {"diagnosis": "performance"})
                expected = RidgeModel("regression", 1).fit(x[48:240], y[48:240])
                np.testing.assert_allclose(controller.pending["model"].predict(x), expected.predict(x))

    def test_real_delayed_stream_and_short_stream_preserve_gate_and_checkpoints(self):
        for batches, delay in ((18, 2), (8, 0)):
            with self.subTest(batches=batches):
                config = self.config(n_batches=batches, label_delay=delay, drift_start=0,
                                     update_interval=4 if delay else 8, cooldown=0)
                with tempfile.TemporaryDirectory() as directory:
                    root = Path(directory)
                    result = run_comparison(config, root, policies=("periodic", "static"))[0]
                    events = [json.loads(line) for line in (root / "periodic/events.jsonl").read_text().splitlines()]
                    self.assertEqual(result["stream_batches"], batches)
                    self.assertEqual(result["train_source_window_batches"], 8)
                    self.assertLessEqual(result["labels_requested"], config.max_labels)
                    self.assertEqual(result["labels_unreleased"], delay * 24)
                    if delay:
                        self.assertGreater(result["updates"], 0)
                        for e in events:
                            if e["event"] == "deploy":
                                self.assertGreater(e["gate_min_source_step"], e["frozen_at"])
                                self.assertLessEqual(e["gate_max_source_step"] + delay, e["step"])
                    else:
                        self.assertEqual(result["updates"], 0)
                        self.assertTrue(any(e.get("reason") == "stream_ended_before_independent_validation" for e in events))
                    simulation = make_simulation(config)
                    versions = [e["model_version"] for e in events if e["event"] == "prediction"]
                    with np.load(root / "periodic/predictions.npz", allow_pickle=False) as saved:
                        for batch, version, prediction in zip(simulation.batches, versions, saved["predictions"]):
                            path = f"model-v{version}.npz" if version else "initial.npz"
                            np.testing.assert_array_equal(RidgeModel.load(root / "periodic" / path).predict(batch.features), prediction)


if __name__ == "__main__":
    unittest.main()
