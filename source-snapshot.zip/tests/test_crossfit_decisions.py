"""Cross-fit runner contracts: fail closed, visible-only labels, real bootstrap."""

import copy
import importlib
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

from ite.official_sft_crossfit import load_public_training_source, make_crossfit_folds


class Predictor:
    task = "regression"
    mean = np.zeros(2)
    std = np.ones(2)
    checkpoint_sha256 = "initial"
    steps = 0
    safety_margin = 0.

    def __init__(self, value=0., checkpoint="initial"):
        self.value, self.checkpoint_sha256, self.calls = value, checkpoint, 0

    def predict(self, x):
        self.calls += 1
        return np.full(len(x), self.value)

    def state(self):
        return {"checkpoint_sha256": self.checkpoint_sha256}


class CrossfitDecisionsTests(unittest.TestCase):
    def module(self):
        try:
            return importlib.import_module("scripts.build_crossfit_decisions")
        except ImportError as error:
            self.fail(f"Cross-fit runner is missing: {error}")

    def data(self):
        return {"profile": "B", "task": "regression", "unit": "minutes",
                "loss_scale": 1., "scale": np.ones(2), "x": np.zeros((96, 2)),
                "y": np.full(96, 2.), "ids": [f"row{i}" for i in range(96)],
                "groups": ["bearing"] * 96}

    def case(self, folder, *, trainer=None):
        return self.module().run_decision_state(self.data(), list(range(96)),
            {"fold_id": "B-test", "split": "train", "initialization_ids": ["init"]},
            "bearing", "abrupt", 3, Path(folder) / "state", lambda: Predictor(),
            trainer=trainer or (lambda *a, **kw: (Predictor(2., "candidate"), .01)))

    def test_real_replay_arms_start_identical_and_deploy_next_batch(self):
        with tempfile.TemporaryDirectory() as folder:
            row = self.case(folder)
            self.assertEqual(row["target_action"], "RETRAIN_HEAD_ONLY")
            self.assertEqual(len(row["evidence"]["arms"]), 3)
            arm = Path(folder) / "state" / "RETRAIN_HEAD_ONLY"
            with np.load(arm / "predictions.npz") as p:
                np.testing.assert_array_equal(p["versions"][:48], np.zeros(48))
                np.testing.assert_array_equal(p["versions"][48:], np.ones(48))
            self.assertNotIn("reason", json.dumps(row["messages"]))
            self.assertNotIn("bearing", json.dumps(row["messages"]))
            self.assertIn("feature_distance", json.dumps(row["messages"]))

    def test_action_prompt_ignores_source_and_future_evidence(self):
        m = self.module()
        context = {"profile": "B", "observation": {"loss_trend": [{"source_step": 1,
            "loss": 2., "labeled_samples": 8}], "drift_alarm": True,
            "remaining_label_budget": None, "remaining_token_budget": 60000,
            "model_age_batches": 4}, "feature_distance": .75, "remaining_train_seconds": 20.}
        first = m.action_messages(context)
        context.update(source_ids=["SECRET"], scenario="abrupt", split="eval", target=999,
                       evidence={"future": "SECRET"})
        context["observation"]["future"] = "SECRET"
        self.assertEqual(first, m.action_messages(context))
        self.assertNotIn("SECRET", json.dumps(first))
        self.assertEqual([v["role"] for v in first], ["system", "user"])

    def test_cache_keys_checkpoint_features_and_margin_and_returns_copies(self):
        m, store = self.module(), {}
        p = Predictor()
        cached = m.CachedInitialModel(p, store)
        x = np.zeros((3, 2))
        cached.predict(x)[0] = 999
        np.testing.assert_array_equal(cached.predict(x), np.zeros(3))
        self.assertEqual(p.calls, 1)
        cached.predict(x + 1)
        self.assertEqual(p.calls, 2)
        q = Predictor(2., "changed")
        np.testing.assert_array_equal(m.CachedInitialModel(q, store).predict(x), np.full(3, 2.))
        self.assertEqual(q.calls, 1)
        p.safety_margin = 1.
        cached.predict(x)
        self.assertEqual(p.calls, 3)
        with self.assertRaises(ValueError):
            cached.predict(np.full((1, 2), np.nan))

    def test_engineering_training_error_is_review_without_action(self):
        def broken(*a, **kw):
            raise RuntimeError("controlled training fault")
        with tempfile.TemporaryDirectory() as folder:
            row = self.case(folder, trainer=broken)
            self.assertEqual(row["status"], "review")
            self.assertNotIn("target_action", row)
            self.assertTrue(row["review_issues"])

    def test_screening_rejection_is_complete_do_nothing(self):
        with tempfile.TemporaryDirectory() as folder:
            row = self.case(folder, trainer=lambda *a, **kw: (Predictor(), .01))
            self.assertEqual(row["target_action"], "DO_NOTHING")
            self.assertEqual(row["status"], "complete")

    def test_training_over_cap_is_review(self):
        with tempfile.TemporaryDirectory() as folder:
            row = self.case(folder, trainer=lambda *a, **kw: (Predictor(2., "candidate"), 5.01))
            self.assertEqual(row["status"], "review")
            self.assertNotIn("target_action", row)

    def test_audit_rejects_changed_ids_targets_static_and_incomplete_arrays(self):
        m = self.module()
        for key, value in (("source_ids", np.array(["bad"] * 96)),
                           ("targets", np.zeros(96)), ("static", np.ones(96)),
                           ("active", np.zeros(95)), ("versions", np.ones(96))):
            with self.subTest(key=key), tempfile.TemporaryDirectory() as folder:
                self.case(folder)
                root = Path(folder) / "state"
                arm = root / "RETRAIN_HEAD_ONLY"
                with np.load(arm / "predictions.npz") as p:
                    values = {k: p[k] for k in p.files}
                values[key] = value
                np.savez_compressed(arm / "predictions.npz", **values)
                with self.assertRaises(ValueError):
                    m.audit_counterfactual_arms(self.data(), list(range(96)), root, 3,
                                               "initial", ["init"])

    def test_audit_rejects_missing_freeze_gate_events_and_changed_observation(self):
        m = self.module()
        for event in ("candidate_frozen", "deploy", "run_completed", "harness_observation"):
            with self.subTest(event=event), tempfile.TemporaryDirectory() as folder:
                self.case(folder)
                root = Path(folder) / "state"
                path = root / "RETRAIN_HEAD_ONLY" / "events.jsonl"
                events = [json.loads(s) for s in path.read_text(encoding="utf-8").splitlines()]
                events = [e for e in events if e["event"] != event]
                path.write_text("\n".join(json.dumps(e) for e in events), encoding="utf-8")
                with self.assertRaises(ValueError):
                    m.audit_counterfactual_arms(self.data(), list(range(96)), root, 3,
                                               "initial", ["init"])

    def test_export_quarantines_input_conflict_cross_split_and_entity_split(self):
        m = self.module()
        def row(group, split, action="DO_NOTHING", visible="same"):
            return {"profile": "B", "source_group": group, "split": split, "status": "complete",
                    "messages": [{"role": "user", "content": visible}], "target_action": action}
        rows = [row("a", "train"), row("b", "train", "RETRAIN_LARGE"),
                row("c", "train", visible="cross"), row("d", "eval", visible="cross"),
                row("e", "train", visible="one"), row("e", "eval", visible="two"),
                row("f", "train", visible="valid"), row("f", "train", visible="valid")]
        with tempfile.TemporaryDirectory() as folder:
            manifest = m.export_dataset(rows, Path(folder) / "dataset")
            root = Path(folder) / "dataset"
            self.assertEqual(len((root / "train.jsonl").read_text().splitlines()), 1)
            self.assertEqual(len((root / "review.jsonl").read_text().splitlines()), 6)
            self.assertFalse(manifest["remote_training_ready"])
            self.assertEqual(manifest["qualified_source_groups"]["B"], {"train": 1, "eval": 0})
            with self.assertRaises(FileExistsError):
                m.export_dataset(rows, root)

    def test_actual_pinned_a_bootstrap_has_prefix_only_normalization_and_steps(self):
        m = self.module()
        data = load_public_training_source("A")
        fold = make_crossfit_folds("A", data)[0]
        with tempfile.TemporaryDirectory() as folder:
            report = m.bootstrap_fold(data, fold, Path(folder) / "bootstrap")
            self.assertEqual(report["status"], "ok", report)
            self.assertEqual(report["numpy_version"], "1.26.4")
            self.assertEqual(report["used_ids"], data["ids"][:120])
            self.assertEqual(report["epochs"], 20)
            self.assertEqual(report["steps"], 20)
            self.assertEqual(report["hidden"], 32)
            self.assertTrue(report["missing_initial_classes"])
            self.assertNotEqual("sha256:" + report["checkpoint_sha256"],
                                data["training_report"]["checkpoint_sha256"])
            self.assertGreater(report["process_seconds"], report["training_seconds"])
            with np.load(Path(folder) / "bootstrap" / "initial.npz") as checkpoint:
                np.testing.assert_array_equal(checkpoint["mean"], data["x"][:120].mean(axis=0))
                expected = data["x"][:120].std(axis=0)
                expected[expected < 1e-12] = 1.
                np.testing.assert_array_equal(checkpoint["scale"], expected)
                metadata = json.loads(str(checkpoint["metadata"]))
                self.assertEqual(metadata["profile"], "A")
            from ite.official_model import OfficialModelAdapter
            model = OfficialModelAdapter("classification", m.runtime_python(), data["package"],
                profile_type="A", checkpoint_path=Path(folder) / "bootstrap" / "initial.npz")
            self.assertEqual(model.predict(data["x"][:2]).shape, (2,))

    def test_worker_rejects_tampered_indices_and_source_hash(self):
        m = self.module()
        data = load_public_training_source("A")
        fold = make_crossfit_folds("A", data)[0]
        for field in ("indices", "hash"):
            altered_data, altered_fold = dict(data), copy.deepcopy(fold)
            if field == "indices":
                altered_fold["initialization_indices"][-1] = 184
            else:
                altered_data["train_sha256"] = "tampered"
            with self.subTest(field=field), tempfile.TemporaryDirectory() as folder:
                report = m.bootstrap_fold(altered_data, altered_fold, Path(folder) / "bootstrap")
                self.assertEqual(report["status"], "incomplete")
                self.assertFalse((Path(folder) / "bootstrap" / "initial.npz").exists())
                self.assertTrue((Path(folder) / "bootstrap" / "stderr.txt").read_text())

    def test_bootstrap_timeout_preserves_evidence_and_does_not_retry(self):
        import subprocess
        m = self.module()
        data = load_public_training_source("A")
        fold = make_crossfit_folds("A", data)[0]
        with tempfile.TemporaryDirectory() as folder, patch.object(m.subprocess, "run",
                side_effect=subprocess.TimeoutExpired("worker", 120, output=b"partial", stderr=b"timeout")) as run:
            report = m.bootstrap_fold(data, fold, Path(folder) / "bootstrap")
            self.assertEqual(report["status"], "incomplete")
            self.assertEqual(run.call_count, 1)
            self.assertEqual(run.call_args.kwargs["timeout"], 120.)
            self.assertEqual((Path(folder) / "bootstrap" / "stdout.txt").read_text(), "partial")

    def test_plan_counts_sources_not_scenario_variants(self):
        m = self.module()
        sources = {p: load_public_training_source(p) for p in "ABC"}
        plan = m.build_plan(sources)
        self.assertEqual(len(plan["states"]), 210)
        self.assertEqual(plan["physical_arm_replays"], 630)
        self.assertEqual(plan["state_counts"], {"A": 12, "B": 54, "C": 144})
        self.assertEqual(plan["source_group_counts"], {"A": 2, "B": 9, "C": 24})

    def test_audit_rejects_malformed_candidate_provenance_even_when_summary_retained(self):
        m = self.module()
        for mutate in ("candidate_ids", "future_loss", "future_decision", "release", "observation_loss"):
            with self.subTest(mutate=mutate), tempfile.TemporaryDirectory() as folder:
                self.case(folder)
                root = Path(folder) / "state"
                path = root / "RETRAIN_HEAD_ONLY" / "events.jsonl"
                events = [json.loads(s) for s in path.read_text(encoding="utf-8").splitlines()]
                for e in events:
                    if mutate == "candidate_ids" and e["event"] == "candidate_evaluated":
                        del e["train_source_ids"]
                    if mutate == "future_loss" and e["event"] == "deploy":
                        e["validation_gain"] = -1.
                    if mutate == "future_decision" and e["event"] == "deploy":
                        e["decision_id"] = "another-decision"
                    if mutate == "release" and e["event"] == "labels_released" and e["step"] == 2:
                        e["source_step"] = 3
                    if mutate == "observation_loss" and e["event"] == "harness_observation":
                        e["observation"]["loss_trend"][0]["loss"] = 999.
                path.write_text("\n".join(json.dumps(e) for e in events), encoding="utf-8")
                with self.assertRaises(ValueError):
                    m.audit_counterfactual_arms(self.data(), list(range(96)), root, 3, "initial", ["init"])

    def test_review_preserves_actual_failed_training_costs(self):
        with tempfile.TemporaryDirectory() as folder:
            row = self.case(folder, trainer=lambda *a, **kw: (Predictor(2., "candidate"), 5.01))
            self.assertEqual(row["costs"]["adaptation_train_seconds"], 10.02)

    def test_future_gate_rejection_is_completed_action_not_engineering_failure(self):
        class FailsFuture(Predictor):
            def predict(self, x):
                return np.where(x[:, 0] == 0, 2., 0.)
        data = self.data()
        # Screening (batch2) sees x=0; future batch4 sees x=1.
        data["x"][32:] = 1.
        with tempfile.TemporaryDirectory() as folder:
            row = self.module().run_decision_state(data, list(range(96)),
                {"fold_id": "test", "split": "train", "initialization_ids": ["init"]},
                "bearing", "stable", 3, Path(folder) / "state", lambda: Predictor(),
                trainer=lambda *a, **kw: (FailsFuture(checkpoint="candidate"), .01))
            self.assertEqual(row["status"], "complete", row)
            self.assertEqual(row["target_action"], "DO_NOTHING")
            self.assertEqual(row["evidence"]["outcomes"][1]["rejection"], "independent_future_gate_rejected")

    def test_plan_only_freezes_new_source_state_without_initialization(self):
        with tempfile.TemporaryDirectory() as folder:
            m = self.module()
            with patch.object(m, "bootstrap_fold", side_effect=AssertionError("plan must not train")):
                result = m.run(Path(folder) / "plan", profiles=("A",), plan_only=True)
            self.assertEqual(result["physical_arm_replays"], 36)
            freeze = json.loads((Path(folder) / "plan" / "freeze.json").read_text(encoding="utf-8"))
            self.assertEqual(len(freeze["source_manifests"]["A"]["ids"]), 445)
            self.assertIn("ite/official_crossfit_worker.py", freeze["code_hashes"])
            with self.assertRaises(FileExistsError):
                m.run(Path(folder) / "plan", profiles=("A",), plan_only=True)

    def test_bootstrap_adapter_error_finishes_review_export_instead_of_aborting(self):
        m = self.module()
        data = {**self.data(), "package": "test", "package_sha256": "test", "train_sha256": "test"}
        fold = {"fold_id": "B-test", "split": "train", "initialization_indices": [],
                "replay_indices": list(range(96)), "replay_groups": ["bearing"]}
        bootstrap = {"status": "ok", "scale": [1., 1.], "loss_scale": 1., "used_ids": ["init"],
                     "process_seconds": .02, "training_seconds": .01}
        progress = []
        with tempfile.TemporaryDirectory() as folder, patch.object(m, "load_public_training_source", return_value=data), \
                patch.object(m, "make_crossfit_folds", return_value=[fold]), \
                patch.object(m, "bootstrap_fold", return_value=bootstrap), \
                patch.object(m, "OfficialModelAdapter", side_effect=RuntimeError("adapter inspection fault")):
            report = m.run(Path(folder) / "run", profiles=("B",), progress=progress.append)
            self.assertFalse(report["engineering_complete"])
            self.assertEqual(report["dataset"]["counts"], {"train": 0, "eval": 0, "review": 6})
            self.assertEqual(progress[0]["event"], "bootstrap_completed")
            self.assertEqual(sum(p["event"] == "decision_completed" for p in progress), 6)
            self.assertEqual(progress[-1]["status"], "review")


if __name__ == "__main__":
    unittest.main()
