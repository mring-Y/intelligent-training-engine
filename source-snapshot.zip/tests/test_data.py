import unittest

import numpy as np

try:
    from ite.config import ExperimentConfig
    from ite.data import make_simulation
except ImportError:
    ExperimentConfig = make_simulation = None


class DataContractTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(ExperimentConfig, "The validated configuration is not implemented")
        self.assertIsNotNone(make_simulation, "The stream simulator is not implemented")

    def test_seed_reproduces_public_stream_and_initial_training(self):
        config = ExperimentConfig(seed=17, n_batches=8, drift_start=3)
        first, second = make_simulation(config), make_simulation(config)
        np.testing.assert_array_equal(first.initial.train_x, second.initial.train_x)
        np.testing.assert_array_equal(first.initial.train_y, second.initial.train_y)
        for left, right in zip(first.batches, second.batches):
            np.testing.assert_array_equal(left.features, right.features)
            self.assertFalse(hasattr(left, "targets"))
            self.assertFalse(hasattr(left, "labels"))

    def test_labels_are_delayed_and_duplicate_requests_do_not_consume_quota(self):
        simulation = make_simulation(ExperimentConfig(label_delay=2, max_labels=3))
        ids = simulation.batches[0].sample_ids
        oracle = simulation.oracle
        self.assertEqual(oracle.request(ids[:2], step=0), 2)
        self.assertEqual(oracle.request(ids[:2], step=0), 0)
        self.assertEqual(oracle.request(ids[2:6], step=0), 1)
        self.assertEqual(oracle.total_requested, 3)
        self.assertIsNone(oracle.release(step=1))
        released = oracle.release(step=2)
        self.assertEqual(len(released.targets), 3)
        self.assertEqual(released.source_steps.tolist(), [0, 0, 0])
        self.assertIsNone(oracle.release(step=3))

    def test_future_sample_cannot_be_requested(self):
        simulation = make_simulation(ExperimentConfig())
        with self.assertRaisesRegex(ValueError, "future"):
            simulation.oracle.request(simulation.batches[2].sample_ids[:1], step=0)
        self.assertEqual(simulation.oracle.total_requested, 0)

    def test_all_scenarios_have_finite_classification_and_regression_streams(self):
        for task in ("classification", "regression"):
            for scenario in ("stable", "abrupt", "gradual", "recurring", "covariate", "noise"):
                with self.subTest(task=task, scenario=scenario):
                    config = ExperimentConfig(task=task, scenario=scenario, n_batches=8, drift_start=3)
                    simulation = make_simulation(config)
                    self.assertEqual(len(simulation.batches), 8)
                    self.assertTrue(np.isfinite(simulation.initial.train_x).all())
                    self.assertTrue(all(np.isfinite(b.features).all() for b in simulation.batches))

    def test_invalid_budgets_and_unknown_fields_fail_early(self):
        for override in ({"label_fraction": 1.1}, {"label_delay": -1}, {"batch_size": 0},
                         {"candidate_timeout_seconds": 0}, {"scenario": "unknown"}):
            with self.subTest(override=override), self.assertRaises(ValueError):
                ExperimentConfig(**override)
        with self.assertRaises(ValueError):
            ExperimentConfig.from_dict({"misspelled_budget": 3})


if __name__ == "__main__":
    unittest.main()
