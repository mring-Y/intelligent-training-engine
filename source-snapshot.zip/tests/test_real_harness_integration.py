"""Controller eligibility and CLI scope prevent accidental paid matrices."""

import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

from ite.cli import main
from ite.config import ExperimentConfig
from ite.controller import AdaptationController
from ite.harness import LLMReply
from ite.labeling import LabelAvailability
from ite.models import RidgeModel
from ite.tracking import JsonlLogger


class NoTraining:
    def fit(self, *args, **kwargs):
        raise AssertionError("DO_NOTHING must not train")


class NothingClient:
    def __init__(self):
        self.calls = 0
    def get_decision(self, observation):
        self.calls += 1
        return LLMReply('{"action":"DO_NOTHING","reason":"evidence"}', 8)


class RealHarnessIntegrationTests(unittest.TestCase):
    def config(self, **overrides):
        return ExperimentConfig.from_dict({"harness_enabled": True, "deployment_validation": "future",
            "training_preflight": True, "candidate_feasibility": True, "max_tokens": 40000,
            "label_mode": "provided", "harness_drift_only": True, "n_batches": 96, **overrides})

    def test_only_drift_calls_client_and_do_nothing_also_cools_down(self):
        rng = np.random.default_rng(123)
        x = rng.normal(size=(192, 8))
        y = (x[:, 0] > 0).astype(int)
        with tempfile.TemporaryDirectory() as root:
            with JsonlLogger(Path(root) / "events.jsonl", "test") as logger:
                controller = AdaptationController(self.config(), "drift", RidgeModel("classification").fit(x, y),
                    .1, 1, logger, NoTraining(), Path(root))
                client = NothingClient()
                controller.llm_client = client
                controller.history_x, controller.history_y = x, y
                controller.history_steps = np.repeat(np.arange(2), 96)
                controller.label_availability = LabelAvailability(None, 96, 95, 2)
                controller._harness_decide(5, {"performance_drop": False})
                self.assertEqual(client.calls, 0)
                controller._harness_decide(6, {"performance_drop": True})
                self.assertEqual(client.calls, 1)
                controller._label_release_revision += 1
                controller._harness_decide(7, {"performance_drop": True})
                self.assertEqual(client.calls, 1)
                controller._harness_decide(10, {"performance_drop": True})
                self.assertEqual(client.calls, 2)

    def test_insufficient_future_capacity_does_not_spend_request(self):
        rng = np.random.default_rng(123)
        x = rng.normal(size=(192, 8))
        y = (x[:, 0] > 0).astype(int)
        with tempfile.TemporaryDirectory() as root:
            with JsonlLogger(Path(root) / "events.jsonl", "test") as logger:
                controller = AdaptationController(self.config(), "drift", RidgeModel("classification").fit(x, y),
                    .1, 1, logger, NoTraining(), Path(root))
                client = NothingClient()
                controller.llm_client = client
                controller.history_x, controller.history_y = x, y
                controller.history_steps = np.repeat(np.arange(2), 96)
                controller.label_availability = LabelAvailability(None, 96, 95, 2)
                controller._harness_decide(94, {"performance_drop": True})
                self.assertEqual(client.calls, 0)

    def test_real_matrix_and_implicit_multiple_policies_are_rejected_before_any_run(self):
        with tempfile.TemporaryDirectory() as root:
            config = Path(root) / "real.json"
            values = {"harness_enabled": True, "deployment_validation": "future",
                "training_preflight": True, "candidate_feasibility": True, "max_tokens": 40000,
                "harness_backend": "pytrio", "harness_drift_only": True,
                "n_batches": 96,
                "llm_ledger_path": str(Path(root) / "ledger.json")}
            config.write_text(json.dumps(values), encoding="utf-8")
            for command in ("matrix", "run"):
                output = Path(root) / command
                with self.subTest(command=command), contextlib.redirect_stderr(io.StringIO()):
                    self.assertEqual(main([command, "--config", str(config), "--output", str(output)]), 2)
                    self.assertFalse(output.exists())

    def test_real_client_inherits_public_contract(self):
        from ite.harness import BaseLLMClient
        from ite.trio_client import TrioLLMClient
        self.assertIsInstance(TrioLLMClient(), BaseLLMClient)

    def test_real_config_rejects_missing_guard_or_unbounded_retry_and_spend_values(self):
        base = {"harness_backend": "pytrio", "llm_ledger_path": "ledger.json", "harness_drift_only": True}
        for bad in ({"max_llm_calls": 0}, {"max_llm_calls": 11}, {"max_llm_cost_cny": "NaN"},
                    {"llm_timeout_seconds": float("inf")}, {"harness_drift_only": False},
                    {"llm_max_output_tokens": 513}, {"llm_ledger_path": ""}):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                self.config(**{**base, **bad})

    def test_real_configuration_refuses_expansion_beyond_approved_smoke(self):
        for change in ({"task": "regression"}, {"scenario": "gradual"}, {"seed": 19}, {"n_batches": 1000}):
            with self.subTest(change=change), self.assertRaises(ValueError):
                self.config(harness_backend="pytrio", llm_ledger_path="ledger.json", **change)

    def test_real_client_process_and_provided_stream_reach_future_gate_without_network(self):
        import sys
        from ite.runner import run_policy
        from ite.training import TrainingResult
        from ite.trio_client import TrioLLMClient

        class InlineFit:
            def fit(self, task, alpha, x, y, timeout_seconds, model_family="ridge", sample_weight=None):
                model = RidgeModel(task, alpha, model_family).fit(x, y, sample_weight=sample_weight)
                return TrainingResult("ok", model, .001)

        response = {"content": '{"action":"RETRAIN_SMALL","reason":"损失退化，请评估小规模候选。"}',
                    "input_tokens": 100, "output_tokens": 20, "finish_reason": "stop"}
        worker = [sys.executable, "-c", f"import sys; sys.stdin.read(); print({json.dumps(json.dumps(response))})"]
        with tempfile.TemporaryDirectory() as root:
            config = self.config(harness_backend="pytrio", n_batches=96, max_labels=0,
                llm_ledger_path=str(Path(root) / "ledger.json"))
            with patch("ite.trio_client.TrioLLMClient", return_value=TrioLLMClient(worker_command=worker)):
                summary = run_policy(config, "drift", Path(root) / "drift", InlineFit())
            events = [json.loads(line) for line in (Path(root) / "drift/events.jsonl").read_text(encoding="utf-8").splitlines()]
            self.assertEqual(summary["stream_batches"], 96)
            self.assertGreater(summary["training_attempts"], 0)
            self.assertGreater(summary["updates"], 0)
            self.assertEqual(summary["real_llm_tokens"], summary["llm_calls"] * 120)
            self.assertEqual(summary["mock_tokens"], 0)
            self.assertGreater(summary["labels_requested"], 864)
            for event in events:
                if event["event"] == "deploy":
                    self.assertGreater(event["gate_min_source_step"], event["frozen_at"])


if __name__ == "__main__":
    unittest.main()
