"""Official SFT inputs retain feature identity, source isolation and raw units."""

import importlib
import json
import tempfile
import unittest
from pathlib import Path

import numpy as np


class OfficialSFTDataTests(unittest.TestCase):
    def module(self):
        try:
            return importlib.import_module("ite.official_sft_data")
        except ImportError as error:
            self.fail(f"Official SFT data loader is missing: {error}")

    def test_actual_packages_preserve_dimensions_rows_and_target_units(self):
        m = self.module()
        for profile, rows, dims, unit in (("A", 1244, 128, None), ("B", 1679, 34, "minutes"),
                                          ("C", 23049, 24, "cycles")):
            with self.subTest(profile=profile):
                data = m.load_public_package(profile)
                self.assertEqual(data["x"].shape, (rows, dims))
                self.assertEqual(data["unit"], unit)
                self.assertEqual(len(data["feature_paths"]), dims)
                self.assertTrue(np.isfinite(data["x"]).all())
                self.assertEqual(len(set(data["ids"])), rows)
        b = m.load_public_package("B")
        self.assertEqual((b["y"].min(), b["y"].max()), (0, 1514))
        c = m.load_public_package("C")
        self.assertEqual(c["y"].max(), 434)

    def test_a_replay_reserve_is_deterministic_balanced_and_disjoint(self):
        m = self.module()
        first = m.load_public_package("A")
        second = m.load_public_package("A")
        reserve = first["replay_reserve"]
        again = second["replay_reserve"]
        self.assertEqual(reserve["x"].shape, (48, 128))
        self.assertEqual(reserve["y"].shape, (48,))
        self.assertEqual(len(reserve["ids"]), 48)
        self.assertEqual(len(set(reserve["ids"])), 48)
        self.assertEqual(reserve["class_counts"], {name: 8 for name in m.OFFICIAL_A_CLASSES})
        self.assertFalse(set(reserve["ids"]) & set(first["ids"]))
        np.testing.assert_array_equal(reserve["x"], again["x"])
        np.testing.assert_array_equal(reserve["y"], again["y"])
        self.assertEqual(reserve["ids"], again["ids"])

    def test_feature_order_follows_sorted_nested_paths_and_rejects_nonfinite(self):
        m = self.module()
        values, paths = m.flatten_features({"z": [3, 4], "a": {"b": 2, "a": 1}})
        self.assertEqual(values, [1., 2., 3., 4.])
        self.assertEqual(paths, ["a.a", "a.b", "z[0]", "z[1]"])
        for bad in (float("nan"), True, "2"):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                m.flatten_features({"a": bad})

    def test_source_groups_never_cross_splits_and_a_has_purge_gap(self):
        m = self.module()
        for profile in "ABC":
            data = m.load_public_package(profile)
            split = m.split_sources(data)
            self.assertTrue(split["train"] and split["eval"])
            self.assertFalse(set(split["train"]) & set(split["eval"]))
            if profile == "A":
                self.assertGreater(min(split["eval"]) - max(split["train"]), 64)
            else:
                train_groups = {data["groups"][i] for i in split["train"]}
                eval_groups = {data["groups"][i] for i in split["eval"]}
                self.assertFalse(train_groups & eval_groups)

    def test_drift_is_deterministic_and_changes_no_pre_drift_features(self):
        m = self.module()
        x = np.asarray([[1., 2.], [3., 4.]])
        scale = np.asarray([2., 4.])
        np.testing.assert_array_equal(m.transform_features(x, scale, "stable", 9), x)
        np.testing.assert_array_equal(m.transform_features(x, scale, "abrupt", 2), x)
        np.testing.assert_array_equal(m.transform_features(x, scale, "abrupt", 3), [[2.5, 5.], [4.5, 7.]])
        np.testing.assert_array_equal(m.transform_features(x, scale, "gradual", 3), [[1.375, 2.75], [3.375, 4.75]])
        np.testing.assert_array_equal(x, [[1., 2.], [3., 4.]])

    def test_regression_metrics_use_minutes_cycles_and_measure_overestimation(self):
        m = self.module()
        result = m.metrics("B", np.asarray([60., 120.]), np.asarray([50., 100.]))
        self.assertAlmostEqual(result["rmse"], np.sqrt(250.))
        self.assertEqual(result["mae"], 15.)
        result = m.metrics("C", np.asarray([10., 20.]), np.asarray([15., 17.]))
        self.assertEqual(result["overestimate_rate"], .5)
        self.assertEqual(result["mean_overestimate"], 2.5)
        self.assertNotIn("macro_f1", result)

    def test_export_quarantines_future_leaks_conflicts_and_unverified_teacher(self):
        m = self.module()
        observation = {"loss_trend": [], "drift_alarm": False, "remaining_label_budget": None,
                       "remaining_token_budget": 1000, "model_age_batches": 2}
        base = {"profile": "A", "split": "train", "source_ids": ["a"], "observation": observation,
                "messages": [{"role": "user", "content": json.dumps(observation)}],
                "action": "DO_NOTHING", "reason": "保持当前模型。", "qualified": True}
        second_observation = {**observation, "remaining_token_budget": 999}
        rows = [base, {**base}, {**base, "action": "RETRAIN_SMALL"},
                {**base, "observation": second_observation,
                 "messages": [{"role": "user", "content": json.dumps(second_observation)}],
                 "source_ids": ["b"], "qualified": False, "rejection": "unverified"}]
        with tempfile.TemporaryDirectory() as tmp:
            result = m.export_samples(rows, Path(tmp) / "data")
            self.assertEqual(result["train"], 0)
            self.assertGreaterEqual(result["review"], 2)
            with self.assertRaises(FileExistsError):
                m.export_samples(rows, Path(tmp) / "data")

    def test_export_rejects_forged_qualification_and_future_data_in_messages(self):
        m = self.module()
        from ite.trio_client import build_messages
        observation = {"loss_trend": [], "drift_alarm": False, "remaining_label_budget": None,
                       "remaining_token_budget": 1000, "model_age_batches": 2}
        row = {"profile": "B", "split": "train", "source_ids": ["a"], "observation": observation,
            "remaining_train_seconds": 20., "feature_distance": .4,
            "action": "RETRAIN_LARGE", "reason": "评估大窗口。", "teacher_source": "teacher", "qualified": True}
        row["messages"] = build_messages(observation, model_type="official_mlp", prompt_profile="official_sft",
            official_context={"profile": "B", "remaining_train_seconds": 20., "feature_distance": .4})
        leaked = {**row, "messages": [row["messages"][0], {"role": "user", "content": '{"future_targets":[2]}' }],
                  "source_ids": ["b"]}
        with tempfile.TemporaryDirectory() as tmp:
            result = m.export_samples([row, leaked], Path(tmp)/"data")
            self.assertEqual(result["train"], 0)
            self.assertEqual(result["review"], 2)
            reasons = {r["rejection"] for r in map(json.loads, (Path(tmp)/"data/review.jsonl").read_text().splitlines())}
            self.assertIn("input_not_visible_context", reasons)
            self.assertIn("missing_outcome_evidence", reasons)

    def test_supported_actions_require_a_digest_bound_reason_audit(self):
        import hashlib
        m = self.module()
        from ite.trio_client import build_messages
        observation = {"loss_trend": [], "drift_alarm": True, "remaining_label_budget": None,
                       "remaining_token_budget": 1000, "model_age_batches": 2}
        record = {"profile": "B", "remaining_train_seconds": 20., "feature_distance": .4,
            "observation": observation, "teacher_source": "teacher", "reason": "标签预算已经耗尽，但仍应重训大窗口。",
            "evidence": {"future_gate": {"accepted": True, "source_step": 5, "frozen_at": 3},
                "deployment_version": 1, "whole_flow_gain": .1,
                "post_deployment_static": {"rmse": 10.}, "post_deployment_active": {"rmse": 8.}}}
        record["messages"] = build_messages(observation, model_type="official_mlp", prompt_profile="official_sft",
                                            official_context=record)
        self.assertEqual(m._qualification_issue(record), "reason_audit_required")
        record["reason"] = "标签按协议提供，评估大窗口候选。"
        record["reason_audit"] = {"status": "approved", "auditor": "explicit_test_review",
            "reason_sha256": hashlib.sha256(record["reason"].encode()).hexdigest()}
        self.assertIsNone(m._qualification_issue(record))
        record["reason"] = "标签预算已经耗尽。"
        self.assertEqual(m._qualification_issue(record), "reason_audit_required")


if __name__ == "__main__":
    unittest.main()
