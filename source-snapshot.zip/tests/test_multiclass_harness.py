"""OVR bridge contracts: fixed labels, worker isolation and old checkpoints."""

import copy
import json
import tempfile
import unittest
from pathlib import Path

import numpy as np

from ite.config import ExperimentConfig
from ite.models import RidgeModel
from ite.training import BoundedTrainer
from scripts.data_prep.models import OneVsRestRidge as CompatibilityOVR

try:
    from ite.model_factory import load_model, make_model, model_from_state
    from ite.multiclass import OneVsRestRidge
except ImportError:
    load_model = make_model = model_from_state = OneVsRestRidge = None


class MulticlassHarnessTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(make_model, "The explicit six-class model factory is missing")
        self.x = np.repeat(np.eye(6), 4, axis=0)
        self.y = np.repeat(np.arange(1, 7), 4)

    def fit(self, **options):
        return make_model("classification", 1.0, "ovr_ridge", **options).fit(self.x, self.y)

    def test_explicit_ovr_keeps_six_labels_and_static_import_compatibility(self):
        # Catches silently selecting binary Ridge or changing the public import.
        model = self.fit()
        self.assertIsInstance(model, CompatibilityOVR)
        self.assertEqual((model.task, model.family), ("classification", "ovr_ridge"))
        np.testing.assert_array_equal(model.classes_, [1, 2, 3, 4, 5, 6])
        np.testing.assert_array_equal(model.predict(np.eye(6)), [1, 2, 3, 4, 5, 6])
        np.testing.assert_array_equal(model.mean, self.x.mean(axis=0))
        np.testing.assert_array_equal(model.std, self.x.std(axis=0))
        exposed = model.classes_
        exposed[0] = 99
        np.testing.assert_array_equal(model.classes_, [1, 2, 3, 4, 5, 6])

    def test_initial_training_requires_all_six_but_candidates_keep_absent_heads(self):
        # Catches remapping a partial candidate's universe to its observed labels.
        mask = np.isin(self.y, [1, 3, 6])
        with self.assertRaises(ValueError):
            make_model("classification", 1., "ovr_ridge").fit(self.x[mask], self.y[mask])
        candidate = make_model("classification", 1., "ovr_ridge", candidate=True)
        candidate.fit(self.x[mask], self.y[mask])
        self.assertEqual(candidate.decision_function(self.x).shape, (24, 6))
        np.testing.assert_array_equal(candidate.decision_function(self.x)[:, [1, 3, 4]], 0)
        np.testing.assert_array_equal(candidate.predict(np.eye(6)[[0, 2, 5]]), [1, 3, 6])
        # A whole source batch may contain only one known class.
        single = make_model("classification", 1., "ovr_ridge", candidate=True)
        single.fit(self.x[:4], self.y[:4])
        np.testing.assert_array_equal(single.predict(self.x), np.ones(24, dtype=int))
        np.testing.assert_array_equal(single.decision_function(self.x)[:, 1:], 0)

    def test_unknown_or_malformed_targets_are_never_fitted_as_binary_labels(self):
        for invalid in (0, 7, 1.5, np.nan, np.inf):
            targets = self.y.astype(float)
            targets[0] = invalid
            for candidate in (False, True):
                with self.subTest(invalid=invalid, candidate=candidate), self.assertRaises(ValueError):
                    make_model("classification", 1., "ovr_ridge", candidate=candidate).fit(self.x, targets)
        for targets in (self.y.reshape(-1, 1), self.y[:-1], self.y.astype(str), np.ones(24, dtype=bool)):
            with self.subTest(shape=targets.shape, dtype=str(targets.dtype)), self.assertRaises(ValueError):
                make_model("classification", 1., "ovr_ridge", candidate=True).fit(self.x, targets)

    def test_class_universe_and_alpha_cannot_be_changed_by_a_candidate(self):
        for classes in ([0, 1, 2, 3, 4, 5], [1, 2, 3], [1, 2, 3, 4, 5, 7],
                        [1, 2, 3, 4, 6, 5], [1, 2, 3, 4, 5, 5]):
            with self.subTest(classes=classes), self.assertRaises(ValueError):
                OneVsRestRidge(classes=classes)
        for alpha in (0, -1, np.nan, np.inf):
            with self.subTest(alpha=alpha), self.assertRaises(ValueError):
                make_model("classification", alpha, "ovr_ridge")

    def test_weighted_heads_agree_with_independent_weighted_ridge_arithmetic(self):
        # Catches dropping weights, weighting labels differently per head, or using
        # the binary threshold instead of the raw score in the OVR argmax.
        x = np.array([[-3, 2], [-2, -1], [-1, 3], [0, -2], [1, 0], [2, 1],
                      [-2, 0], [-1, 2], [0, -3], [1, 1], [2, -1], [3, 2]], dtype=float)
        y = np.array([1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6])
        weights = np.array([1, 2, 0, 4, 1, 3, 2, 1, 5, 0, 2, 4], dtype=float)
        alpha = 2.5
        model = make_model("classification", alpha, "ovr_ridge").fit(x, y, sample_weight=weights)
        normalized = weights * (len(weights) / weights.sum())
        mean = (normalized[:, None] * x).sum(axis=0) / len(x)
        std = np.sqrt((normalized[:, None] * (x - mean) ** 2).sum(axis=0) / len(x))
        design = (x - mean) / std
        for index, label in enumerate([1, 2, 3, 4, 5, 6]):
            target = (y == label).astype(float)
            intercept = (normalized * target).sum() / len(x)
            coefficients = np.linalg.solve(design.T @ (normalized[:, None] * design) + alpha * np.eye(2),
                                           design.T @ (normalized * (target - intercept)))
            expected = design @ coefficients + intercept
            np.testing.assert_allclose(model.decision_function(x)[:, index], expected, rtol=1e-12, atol=1e-12)
            binary = RidgeModel("classification", alpha).fit(x, target, sample_weight=weights)
            np.testing.assert_array_equal(model.decision_function(x)[:, index], binary._scores(x))
        np.testing.assert_allclose(model.mean, mean, rtol=1e-12, atol=1e-12)
        np.testing.assert_allclose(model.std, std, rtol=1e-12, atol=1e-12)

    def test_invalid_weights_and_nonfinite_features_fail_before_returning_a_model(self):
        for weights in (np.zeros(24), np.ones(23), np.full(24, -1), np.full(24, np.nan)):
            with self.subTest(weights=weights.tolist()), self.assertRaises(ValueError):
                make_model("classification", 1., "ovr_ridge").fit(self.x, self.y, sample_weight=weights)
        for x in (self.x[:, :0], np.full((24, 6), np.nan), self.x.reshape(24, 3, 2)):
            with self.subTest(shape=x.shape), self.assertRaises(ValueError):
                make_model("classification", 1., "ovr_ridge").fit(x, self.y)

    def test_json_state_round_trip_preserves_scores_and_monitor_scaling(self):
        model = self.fit()
        state = json.loads(json.dumps(model.state(), allow_nan=False))
        restored = model_from_state(state)
        self.assertIsInstance(restored, OneVsRestRidge)
        self.assertEqual(state["model_kind"], "ovr_ridge")
        np.testing.assert_array_equal(restored.decision_function(self.x), model.decision_function(self.x))
        np.testing.assert_array_equal(restored.mean, model.mean)
        np.testing.assert_array_equal(restored.std, model.std)

    def test_state_rejects_unknown_classes_head_count_and_inconsistent_head_contracts(self):
        state = self.fit().state()
        corruptions = (
            lambda s: s.update(classes=[0, 1, 2, 3, 4, 5]),
            lambda s: s.update(classes=[1, 2, 3]),
            lambda s: s.update(heads=s["heads"][:-1]),
            lambda s: s.update(task="regression"),
            lambda s: s.update(family="ridge"),
            lambda s: s.update(model_kind="unknown"),
            lambda s: s["heads"][1].update(task="regression"),
            lambda s: s["heads"][1].update(family="quadratic"),
            lambda s: s["heads"][1].update(alpha=2),
            lambda s: s["heads"][1]["mean"].__setitem__(0, 10),
            lambda s: s["heads"][1]["std"].__setitem__(0, 10),
            lambda s: s["heads"][1]["basis_mean"].__setitem__(0, 10),
            lambda s: s["heads"][1].update(weights=[0]),
            lambda s: s["heads"][1].update(intercept=float("nan")),
        )
        for index, corrupt in enumerate(corruptions):
            bad = copy.deepcopy(state)
            corrupt(bad)
            with self.subTest(case=index), self.assertRaises(ValueError):
                OneVsRestRidge.from_state(bad)

    def test_raw_scores_above_one_do_not_collapse_into_a_false_argmax_tie(self):
        state = self.fit().state()
        for head, score in zip(state["heads"], [1.1, 2.0, 0.0, 0.0, 0.0, 0.0]):
            head.update(weights=[0.] * 6, intercept=score)
        np.testing.assert_array_equal(model_from_state(state).predict(self.x[:2]), [2, 2])
        state["heads"][0]["intercept"] = 2.0
        np.testing.assert_array_equal(model_from_state(state).predict(self.x[:2]), [1, 1])

    def test_save_replaces_deployed_checkpoint_with_numeric_arrays(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "deployed.npz"
            first = self.fit()
            first.save(path)
            replacement = make_model("classification", 1., "ovr_ridge").fit(self.x, 7 - self.y)
            replacement.save(path)
            restored = load_model(path)
            np.testing.assert_array_equal(restored.predict(np.eye(6)), [6, 5, 4, 3, 2, 1])
            np.testing.assert_array_equal(restored.decision_function(self.x), replacement.decision_function(self.x))
            with np.load(path, allow_pickle=False) as archive:
                self.assertTrue(all(archive[name].dtype.kind != "O" for name in archive.files))
            self.assertEqual([p.name for p in Path(directory).iterdir()], ["deployed.npz"])

    def test_old_static_ovr_numeric_checkpoint_loads_through_both_public_paths(self):
        # Literal fixture uses the version-1 format shipped before the bridge.
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "old.npz"
            np.savez_compressed(path, format_version=1, model_kind="ovr_ridge", classes=np.arange(1, 7),
                                alpha=1., mean=np.zeros((6, 2)), std=np.ones((6, 2)),
                                weights=np.zeros((6, 2)), intercept=np.array([.1, .2, .3, .4, .5, .6]),
                                basis_mean=np.zeros((6, 2)))
            for loader in (load_model, CompatibilityOVR.load):
                restored = loader(path)
                np.testing.assert_array_equal(restored.predict([[9., -4.]]), [6])
                np.testing.assert_array_equal(restored.decision_function([[9., -4.]]), [[.1, .2, .3, .4, .5, .6]])

    def test_factory_preserves_original_ridge_and_quadratic_states_exactly(self):
        x = np.array([[-2., 1.], [-1., 2.], [0., 4.], [1., -2.], [2., 3.], [3., 0.]])
        for task, y in (("classification", np.array([0, 0, 1, 0, 1, 1])),
                        ("regression", np.array([-2., 0., 2., -1., 3., 4.]))):
            for family in ("ridge", "quadratic"):
                for weights in (None, np.array([1., 2., 0., 4., 2., 1.])):
                    with self.subTest(task=task, family=family, weighted=weights is not None):
                        old = RidgeModel(task, 1.2, family).fit(x, y, sample_weight=weights)
                        new = make_model(task, 1.2, family, candidate=True).fit(x, y, sample_weight=weights)
                        self.assertEqual(old.state(), new.state())
                        np.testing.assert_array_equal(model_from_state(new.state())._scores(x), old._scores(x))
        default = make_model("classification", 1.0).fit(x, [0, 0, 1, 0, 1, 1])
        self.assertIs(type(default), RidgeModel)

    def test_factory_loads_original_binary_checkpoint_and_legacy_state_without_family(self):
        old = RidgeModel("regression", .5).fit([[-2., 1.], [-1., 2.], [1., 0.], [2., 3.]], [0., 1., 2., 3.])
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "ridge.npz"
            old.save(path)
            self.assertEqual(load_model(path).state(), old.state())
        state = old.state()
        state.pop("family")
        state.pop("basis_mean")
        np.testing.assert_array_equal(model_from_state(state).predict([[3., 2.]]), old.predict([[3., 2.]]))
        with self.assertRaises(ValueError):
            model_from_state({**old.state(), "model_kind": "unknown"})

    def test_ovr_configuration_is_explicit_classification_and_excludes_paid_backend(self):
        config = ExperimentConfig(model_family="ovr_ridge")
        self.assertEqual(ExperimentConfig.from_dict(json.loads(json.dumps(config.to_dict()))), config)
        with self.assertRaises(ValueError):
            ExperimentConfig(task="regression", model_family="ovr_ridge")
        with self.assertRaises(ValueError):
            make_model("regression", 1., "ovr_ridge")
        paid = dict(n_batches=96, harness_backend="pytrio", harness_enabled=True, harness_drift_only=True,
                    llm_ledger_path="not-opened.json", deployment_validation="future", training_preflight=True,
                    candidate_feasibility=True)
        # This original binary profile is valid; only replacing its model is rejected.
        ExperimentConfig(**paid)
        with self.assertRaises(ValueError):
            ExperimentConfig(**paid, model_family="ovr_ridge")

    def test_real_spawn_worker_returns_six_head_model_after_timeout_and_error(self):
        # Uses the real killable worker: a timeout must not poison later fits.
        mask = np.isin(self.y, [1, 3, 6])
        x, y = self.x[mask], self.y[mask]
        weights = np.array([1., 2., 1., 3.] * 3)
        with BoundedTrainer() as trainer:
            timeout = trainer.fit("classification", 1., x, y, 1e-6, model_family="ovr_ridge")
            self.assertEqual(timeout.status, "timeout")
            self.assertIsNone(timeout.model)
            result = trainer.fit("classification", 1., x, y, 8., model_family="ovr_ridge", sample_weight=weights)
            self.assertEqual(result.status, "ok", result.error)
            self.assertIsInstance(result.model, OneVsRestRidge)
            direct = make_model("classification", 1., "ovr_ridge", candidate=True).fit(x, y, sample_weight=weights)
            np.testing.assert_array_equal(result.model.decision_function(self.x), direct.decision_function(self.x))
            invalid = trainer.fit("classification", 1., x, np.full(len(x), 7), 8., model_family="ovr_ridge")
            self.assertEqual(invalid.status, "error")
            self.assertIsNone(invalid.model)
            recovered = trainer.fit("classification", 1., x[:4], y[:4], 8., model_family="ovr_ridge")
            self.assertEqual(recovered.status, "ok", recovered.error)
            np.testing.assert_array_equal(recovered.model.predict(self.x), np.ones(24, dtype=int))


if __name__ == "__main__":
    unittest.main()
