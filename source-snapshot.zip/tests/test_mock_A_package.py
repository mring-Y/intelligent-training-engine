import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

import numpy as np


@unittest.skipUnless(importlib.util.find_spec("pyarrow"), "Optional pyarrow==22.0.0 is not installed")
class MockAPackageTests(unittest.TestCase):
    def test_industrial_proxy_package_survives_dirty_parquet_mock_harness_rehearsal(self):
        from ite.providers import ColumnMapping, ParquetDataProvider
        from scripts.make_mock_A_package import make_mock_a_package, run_mock_a_rehearsal

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            package = root / "mock-A"
            make_mock_a_package(package, seed=20261108, smoke_batches=10)
            manifest = json.loads((package / "manifest.json").read_text(encoding="utf-8"))
            datasets = manifest["datasets"]
            self.assertEqual(set(datasets), {"gas_sensor", "bearing", "engine_rul"})
            self.assertEqual(datasets["engine_rul"]["data_type"],
                             "proxy_stream_requires_official_mapping")
            self.assertEqual(datasets["engine_rul"]["sequence_batches"], 96)
            self.assertIn("proxy", datasets["engine_rul"]["limitations"].lower())

            expected_variants = {
                "gas_sensor": {"abrupt"},
                "bearing": {"gradual", "abrupt"},
                "engine_rul": {"gradual"},
            }
            for name, expected in expected_variants.items():
                item = datasets[name]
                self.assertEqual(set(item["streams"]), expected)
                self.assertEqual(item["task"], "classification" if name == "gas_sensor" else "regression")
                for scenario, stream in item["streams"].items():
                    self.assertFalse(stream["dirty_cases"]["timestamp_is_monotonic"])
                    self.assertEqual(stream["smoke_batches"], 10)
                    mapping = ColumnMapping(**item["mapping"])
                    provider = ParquetDataProvider(
                        package / stream["smoke_missing_channel"], mapping,
                        initial_train_path=package / item["initial_train"],
                        initial_validation_path=package / item["initial_validation"],
                        label_delay=2,
                    )
                    audit = provider.provenance()["data_quality"]["stream"]
                    self.assertEqual(len(provider.batch_sizes), 10)
                    self.assertEqual(audit["missing_targets"], 1)
                    self.assertEqual(audit["float32_overflow_values"][2], 1)
                    self.assertEqual(audit["missing_feature_columns"], [mapping.features[-1]])
                    self.assertEqual(audit["feature_values_imputed"][-1], sum(provider.batch_sizes))

            result = run_mock_a_rehearsal(package, root / "rehearsal", smoke_batches=10)
            self.assertEqual(len(result["runs"]), 4)
            for run in result["runs"]:
                self.assertEqual(run["stream_batches"], 10)
                self.assertGreater(run["mock_calls"], 0)
                self.assertGreater(run["decisions"], 0)
                output = root / "rehearsal" / run["output_dir"]
                events = [json.loads(line) for line in (output / "events.jsonl").read_text().splitlines()]
                self.assertEqual(sum(event["event"] == "prediction" for event in events), 10)
                self.assertTrue(any(event["event"] == "harness_decision" for event in events))
                with np.load(output / "predictions.npz", allow_pickle=False) as saved:
                    self.assertEqual(saved["predictions"].size, 10 * run["batch_size"])


if __name__ == "__main__":
    unittest.main()
