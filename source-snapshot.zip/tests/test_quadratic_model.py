import tempfile
import unittest
from pathlib import Path

import numpy as np

from ite.models import RidgeModel, prediction_loss
from ite.training import BoundedTrainer


class QuadraticModelTests(unittest.TestCase):
    def test_quadratic_baseline_learns_interaction_and_saves_original_feature_scaling(self):
        rng = np.random.default_rng(4)
        x = rng.normal(size=(800, 3))
        y = x[:, 0] * x[:, 2] + x[:, 0] ** 2 - 1
        model = RidgeModel("regression", .1, family="quadratic").fit(x[:600], y[:600])
        self.assertLess(prediction_loss("regression", y[600:], model.predict(x[600:])), .001)
        self.assertEqual(len(model.mean), 3)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "model.npz"
            model.save(path)
            restored = RidgeModel.load(path)
            np.testing.assert_array_equal(model.predict(x), restored.predict(x))

    def test_bounded_worker_trains_selected_model_family(self):
        rng = np.random.default_rng(4)
        x = rng.normal(size=(200, 3))
        y = x[:, 0] * x[:, 2]
        with BoundedTrainer() as trainer:
            result = trainer.fit("regression", .1, x, y, 8, model_family="quadratic")
            self.assertEqual(result.status, "ok")
            self.assertLess(prediction_loss("regression", y, result.model.predict(x)), .001)

    def test_old_checkpoint_without_family_remains_loadable(self):
        model = RidgeModel("regression", .1).fit(np.array([[0., 0.], [1., 1.]]), np.array([0., 1.]))
        state = model.state()
        state.pop("family", None)
        state.pop("basis_mean", None)
        np.testing.assert_array_equal(RidgeModel.from_state(state).predict([[.5, .5]]), model.predict([[.5, .5]]))


if __name__ == "__main__":
    unittest.main()
