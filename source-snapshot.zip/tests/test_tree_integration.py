"""Tree dispatch, worker containment and chronological integration contracts."""

import copy
import csv
import importlib
import json
import multiprocessing as mp
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

from ite.budget import ResourceBudget
from ite.config import ExperimentConfig
from ite.controller import AdaptationController
from ite.data import InitialData
from ite.model_factory import load_model, make_model, model_from_state
from ite.models import RidgeModel
from ite.providers import ColumnMapping, CSVDataProvider
from ite.runner import _validate_targets, run_policy
from ite.tracking import JsonlLogger
from ite.training import BoundedTrainer, TrainingResult


def _invalid_state_worker(connection):
    """A real IPC peer supplying a malformed numeric model, rather than an estimator."""
    try:
        connection.recv()
        connection.send(("ok", {"model_kind": "tree", "task": "regression", "unexpected": [1.]}, None))
    finally:
        connection.close()


class InvalidStateOnceTrainer(BoundedTrainer):
    def __init__(self):
        super().__init__()
        self.invalid_first = True

    def _start(self):
        if not self.invalid_first:
            return super()._start()
        self.invalid_first = False
        context = mp.get_context("spawn")
        self._connection, child = context.Pipe()
        self._process = context.Process(target=_invalid_state_worker, args=(child,), daemon=True)
        self._process.start()
        child.close()


class RecordingTrainer(BoundedTrainer):
    def __init__(self):
        super().__init__()
        self.calls = []

    def fit(self, task, alpha, features, targets, timeout_seconds, **options):
        result = super().fit(task, alpha, features, targets, timeout_seconds, **options)
        self.calls.append({"alpha": alpha, "timeout": timeout_seconds, **options,
                           "samples": len(targets), "result": result})
        return result


class FailedTrainer:
    def fit(self, *args, **options):
        return TrainingResult("timeout", None, .025, "injected initial worker deadline")


class TreeIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.x = np.repeat(np.eye(6), 12, axis=0)
        self.y = np.repeat(np.arange(1, 7), 12)

    def config(self, **changes):
        try:
            return ExperimentConfig.from_dict({"model_type": "tree", **changes})
        except (ValueError, TypeError) as error:
            self.fail(f"The approved Tree configuration must be accepted: {error}")

    def tree(self, task="classification", **options):
        try:
            return make_model(task, None, model_type="tree", **options)
        except TypeError as error:
            self.fail(f"Explicit Tree model dispatch is missing: {error}")

    def events(self, folder):
        return [json.loads(line) for line in (folder / "events.jsonl").read_text().splitlines()]

    def provider(self, *, steps=12, labels=None):
        labels = (self.y % 6) + 1 if labels is None else labels
        path = self.root / "stream.csv"
        with path.open("w", newline="", encoding="utf-8") as stream:
            writer = csv.writer(stream)
            writer.writerow(["id", "batch", *(f"x{i}" for i in range(6)), "target"])
            for step in range(steps):
                for index, (row, label) in enumerate(zip(self.x, labels)):
                    writer.writerow([step * len(self.x) + index, step, *row, label])
        initial = InitialData(self.x, self.y, self.x.copy(), self.y.copy())
        return CSVDataProvider(path, ColumnMapping(features=tuple(f"x{i}" for i in range(6)),
            target="target", sample_id="id", batch="batch"), initial=initial, label_delay=2)

    def runner_config(self, **changes):
        return self.config(n_features=6, class_labels=[1, 2, 3, 4, 5, 6], initial_train=72,
            initial_validation=72, n_batches=12, batch_size=72, label_fraction=1., label_mode="provided",
            deployment_validation="future", training_preflight=True, selection_split="recent_disjoint",
            candidate_feasibility=True, history_windows=[72], min_labeled=24, min_validation=12,
            monitor_min_labeled=24, update_interval=3, cooldown=0, min_gain=0., tree_timeout_seconds=5., **changes)

    def test_tree_configuration_roundtrips_seed_and_does_not_change_ridge_defaults(self):
        ridge = ExperimentConfig()
        self.assertEqual(getattr(ridge, "model_type", None), "ridge")
        config = self.config(seed=19, class_labels=[1, 2, 3, 4, 5, 6])
        self.assertEqual(config.tree_options(), {"max_depth": 6, "min_samples_leaf": 5,
                         "max_leaf_nodes": 64, "random_state": 19})
        self.assertEqual(config.class_labels, (1, 2, 3, 4, 5, 6))
        self.assertEqual(config.tree_timeout_seconds, 5.)
        self.assertEqual(config.tree_initial_timeout_seconds, 5.)
        self.assertEqual(ExperimentConfig.from_dict(json.loads(json.dumps(config.to_dict()))), config)

    def test_tree_configuration_rejects_conflicts_unknown_labels_and_paid_backend(self):
        for options in ({"model_type": "forest"}, {"model_family": "quadratic"},
                        {"model_family": "ovr_ridge"}, {"class_labels": [1, 2, 3]},
                        {"class_labels": [False, True]}, {"class_labels": [0., 1.]},
                        {"class_labels": [1, 2, 3, 4, 5, 7]},
                        {"task": "regression", "class_labels": [0, 1]},
                        {"tree_max_depth": 0}, {"tree_max_depth": True},
                        {"tree_min_samples_leaf": 0}, {"tree_max_leaf_nodes": 1},
                        {"tree_timeout_seconds": 0}, {"tree_timeout_seconds": float("nan")},
                        {"tree_timeout_seconds": 6.}):
            with self.subTest(options=options), self.assertRaises(ValueError):
                ExperimentConfig.from_dict({"model_type": "tree", **options})
        paid = dict(n_batches=96, harness_backend="pytrio", harness_enabled=True, harness_drift_only=True,
                    llm_ledger_path="never-created.json", deployment_validation="future",
                    training_preflight=True, candidate_feasibility=True)
        ExperimentConfig(**paid)
        with self.assertRaisesRegex(ValueError, "Tree|tree"):
            ExperimentConfig.from_dict({**paid, "model_type": "tree"})

    def test_tree_dependency_is_checked_without_importing_native_training_modules(self):
        with patch("importlib.util.find_spec", return_value=None):
            ExperimentConfig()
            with self.assertRaisesRegex((ImportError, ValueError), "scikit|sklearn|tree"):
                ExperimentConfig.from_dict({"model_type": "tree"})

    def test_tree_budget_uses_its_own_cap_and_preserves_total_adaptation_allowance(self):
        tree = ResourceBudget(self.config(tree_timeout_seconds=5.))
        ridge = ResourceBudget(ExperimentConfig())
        self.assertEqual((tree.training_allowance(), ridge.training_allowance()), (5., 3.))
        tree.charge_training(17.)
        self.assertEqual(tree.training_allowance(), 1.5)
        tree.charge_training(1.6)
        self.assertEqual(tree.training_allowance(), 0.)
        self.assertEqual(tree.snapshot()["adaptation_train_seconds"], 18.6)

    def test_factory_restores_tree_numeric_state_and_preserves_exact_legacy_ridge(self):
        model = self.tree(class_labels=[1, 2, 3, 4, 5, 6]).fit(self.x, self.y)
        np.testing.assert_array_equal(model_from_state(model.state()).predict(self.x), self.y)
        broken = copy.deepcopy(model.state())
        broken["unexpected"] = 1
        with self.assertRaises(ValueError):
            model_from_state(broken)
        for options in ({"model_type": "unknown"}, {"model_type": "tree", "family": "quadratic"},
                        {"model_type": "ridge", "class_labels": [1, 2, 3, 4, 5, 6]}):
            with self.subTest(options=options), self.assertRaises(ValueError):
                make_model("regression", 1., **options)
        with self.assertRaises(ValueError):
            make_model("regression", 1., model_type="tree")
        x, y = self.x[:, :2], np.linspace(-1., 1., len(self.x))
        self.assertEqual(make_model("regression", .4).fit(x, y).state(),
                         RidgeModel("regression", .4).fit(x, y).state())
        for fitted in (model, RidgeModel("regression", .4).fit(x, y)):
            path = self.root / "checkpoint.npz"
            fitted.save(path)
            np.testing.assert_array_equal(load_model(path).predict(self.x if fitted is model else x),
                                          fitted.predict(self.x if fitted is model else x))

    def test_unknown_checkpoint_members_are_rejected_before_numpy_load(self):
        path = self.root / "unknown.npz"
        np.savez_compressed(path, unknown_member=np.array([1.]))
        with patch("ite.model_factory.np.load", side_effect=AssertionError("unbounded probe")):
            with self.assertRaises(ValueError):
                load_model(path)

    def test_legacy_checkpoint_dispatch_uses_one_validated_file_handle(self):
        model = RidgeModel("regression", .4).fit(self.x[:, :2], np.linspace(-1., 1., len(self.x)))
        path = self.root / "swap.npz"
        model.save(path)
        # The factory must not validate one path and load a different replacement.
        original_load = np.load
        loaded = []
        def require_stream(source, *args, **kwargs):
            self.assertTrue(hasattr(source, "read"), "factory reopened the path after preflight")
            loaded.append(source)
            return original_load(source, *args, **kwargs)
        with patch("ite.model_factory.np.load", side_effect=require_stream):
            restored = load_model(path)
        self.assertEqual(len(loaded), 1)
        np.testing.assert_array_equal(restored.predict(self.x[:, :2]), model.predict(self.x[:, :2]))

    def test_worker_rejects_malformed_returned_state_and_recovers(self):
        with InvalidStateOnceTrainer() as trainer:
            bad = trainer.fit("regression", 1., self.x, self.y, 8.)
            self.assertEqual(bad.status, "error")
            self.assertIsNone(bad.model)
            self.assertIsNone(trainer._process)
            recovered = trainer.fit("regression", 1., self.x, self.y, 8.)
            self.assertEqual(recovered.status, "ok", recovered.error)

    def test_real_tree_worker_timeout_weighted_six_classes_error_and_recovery(self):
        mask = self.y != 6
        weights = np.tile([1., 3., 2., 0.], len(self.x) // 4)
        options = {"model_type": "tree", "class_labels": [1, 2, 3, 4, 5, 6],
                   "tree_options": {"max_depth": 6, "min_samples_leaf": 5,
                                    "max_leaf_nodes": 64, "random_state": 7}}
        with BoundedTrainer() as trainer:
            timeout = trainer.fit("classification", None, self.x, self.y, 1e-6, **options)
            self.assertEqual(timeout.status, "timeout")
            self.assertIsNone(timeout.model)
            result = trainer.fit("classification", None, self.x, self.y, 10.,
                                 sample_weight=weights, candidate=False, **options)
            self.assertEqual(result.status, "ok", result.error)
            self.assertEqual(result.model.family, "tree")
            self.assertEqual(result.model.state()["model_kind"], "tree")
            self.assertNotIn("estimator", result.model.state())
            np.testing.assert_array_equal(result.model.predict(self.x), self.y)
            self.assertTrue(all(np.isfinite(value) and value >= 0 for value in result.timings.values()))
            self.assertGreaterEqual(result.wall_seconds, result.timings["fit_seconds"])
            invalid = trainer.fit("classification", None, self.x, np.full(len(self.x), 7), 8., **options)
            self.assertEqual(invalid.status, "error")
            missing_initial = trainer.fit("classification", None, self.x[mask], self.y[mask], 8.,
                                          candidate=False, **options)
            self.assertEqual(missing_initial.status, "error")
            candidate = trainer.fit("classification", None, self.x[mask], self.y[mask], 8., **options)
            self.assertEqual(candidate.status, "ok", candidate.error)
            np.testing.assert_array_equal(candidate.model.classes_, np.arange(1, 7))
            np.testing.assert_array_equal(candidate.model.predict_proba(self.x)[:, 5], np.zeros(len(self.x)))

    def test_restore_over_deadline_is_rejected_and_charged_with_cleanup(self):
        with BoundedTrainer() as trainer:
            self.assertEqual(trainer.fit("regression", 1., self.x, self.y, 8.).status, "ok")
            original = model_from_state
            def slow_restore(state):
                time.sleep(.06)
                return original(state)
            with patch("ite.training.model_from_state", side_effect=slow_restore):
                result = trainer.fit("regression", 1., self.x, self.y, .04)
            self.assertEqual(result.status, "timeout")
            self.assertIsNone(result.model)
            self.assertGreaterEqual(result.wall_seconds, .06)
            self.assertIsNone(trainer._process)

    def test_tree_six_class_target_validation_and_provider_requirement(self):
        try:
            _validate_targets("classification", self.y, model_type="tree", class_labels=(1, 2, 3, 4, 5, 6))
        except TypeError as error:
            self.fail(f"Explicit Tree label validation missing: {error}")
        with self.assertRaises(ValueError):
            _validate_targets("classification", [1, 7], model_type="tree", class_labels=(1, 2, 3, 4, 5, 6))
        with self.assertRaisesRegex(ValueError, "provider|Provider"):
            run_policy(self.runner_config(), "static", self.root / "invalid-provider", None)
        self.assertFalse((self.root / "invalid-provider").exists())

    def test_initial_tree_worker_failure_aborts_before_stream_and_checkpoint(self):
        provider = self.provider()
        with self.assertRaisesRegex(RuntimeError, "initial|Initial"):
            run_policy(self.runner_config(), "static", self.root / "failed", FailedTrainer(), provider=provider)
        self.assertFalse(provider._started)
        self.assertFalse((self.root / "failed/initial.npz").exists())
        failures = self.events(self.root / "failed")
        self.assertTrue(any(e["event"] == "initial_training" and e["status"] == "timeout" for e in failures))

    def test_runner_tree_initial_is_bounded_and_initial_cost_is_outside_adaptation(self):
        config = self.runner_config(tree_initial_timeout_seconds=4.25)
        with RecordingTrainer() as trainer:
            warm = trainer.fit("classification", None, self.x, self.y, 15., model_type="tree",
                class_labels=config.class_labels, tree_options=config.tree_options(), candidate=False)
            self.assertEqual(warm.status, "ok", f"{warm.error}: {warm.timings}")
            trainer.calls.clear()
            result = run_policy(config, "static", self.root / "static", trainer, provider=self.provider())
        self.assertEqual(len(trainer.calls), 1)
        self.assertIs(trainer.calls[0]["candidate"], False)
        self.assertEqual(trainer.calls[0]["timeout"], config.tree_initial_timeout_seconds)
        self.assertEqual(result["adaptation_train_seconds"], 0.)
        self.assertGreaterEqual(result["initial_train_seconds"], trainer.calls[0]["result"].wall_seconds)
        self.assertGreater(result["initial_checkpoint_seconds"], 0.)
        self.assertEqual(result["adaptation_checkpoint_seconds"], 0.)
        event = next(e for e in self.events(self.root / "static") if e["event"] == "initial_training")
        self.assertIsNone(event["alpha"])
        self.assertEqual(event["tree_options"]["max_depth"], 6)
        self.assertGreater(event["checkpoint_seconds"], 0.)

    def test_tree_controller_fits_once_per_window_and_ignores_alpha_tie_policy(self):
        config = self.runner_config(candidate_alphas=[.1, 1., 10.], classification_tie_break="alpha_desc")
        with BoundedTrainer() as trainer, JsonlLogger(self.root / "events.jsonl", "tree-search") as logger:
            initial = trainer.fit("classification", None, self.x, (self.y % 6) + 1, 10., model_type="tree",
                                  class_labels=config.class_labels, tree_options=config.tree_options(), candidate=False)
            self.assertEqual(initial.status, "ok", initial.error)
            controller = AdaptationController(config, "periodic", initial.model, .01, 1., logger, trainer, self.root)
            controller.history_x = np.tile(self.x, (4, 1))
            controller.history_y = np.tile(self.y, 4)
            controller.history_steps = np.repeat(np.arange(4), len(self.x))
            controller._experiment(4, {"diagnosis": "fixture", "released_loss": 1., "feature_distance": 0.})
        evaluated = [e for e in self.events(self.root) if e["event"] == "candidate_evaluated"]
        self.assertEqual(len(evaluated), 1)
        self.assertIsNone(evaluated[0]["alpha"])
        self.assertEqual(evaluated[0]["tree_options"], config.tree_options())
        selection = next(e for e in self.events(self.root) if e["event"] == "candidate_selection")
        self.assertNotIn("alpha_desc", selection["decision_key"])

    def test_tree_runner_future_gate_and_probability_rows_follow_actual_prediction_version(self):
        config = self.runner_config(candidate_alphas=[.1, 10.])
        with RecordingTrainer() as trainer:
            warm = trainer.fit("classification", None, self.x, self.y, 15., model_type="tree",
                class_labels=config.class_labels, tree_options=config.tree_options(), candidate=False)
            self.assertEqual(warm.status, "ok", f"{warm.error}: {warm.timings}")
            trainer.calls.clear()
            result = run_policy(config, "periodic", self.root / "future", trainer, provider=self.provider())
        self.assertGreater(result["updates"], 0)
        events = self.events(self.root / "future")
        for deployment in (e for e in events if e["event"] == "deploy"):
            self.assertGreater(deployment["gate_min_source_step"], deployment["frozen_at"])
            same = next(e for e in events if e["event"] == "prediction" and e["step"] == deployment["step"])
            after = next(e for e in events if e["event"] == "prediction" and e["step"] == deployment["step"] + 1)
            self.assertLess(same["model_version"], deployment["model_version"])
            self.assertEqual(after["model_version"], deployment["model_version"])
        with np.load(self.root / "future/predictions.npz", allow_pickle=False) as saved:
            predictions = saved["predictions"].reshape(-1)
            self.assertEqual(saved["probabilities"].shape, (len(predictions), 6))
            np.testing.assert_array_equal(saved["class_labels"], np.arange(1, 7))
            np.testing.assert_array_equal(np.arange(1, 7)[saved["probabilities"].argmax(axis=1)], predictions)
            np.testing.assert_allclose(saved["probabilities"].sum(axis=1), 1.)
            for event in (e for e in events if e["event"] == "prediction"):
                version = event["model_version"]
                path = "initial.npz" if version == 0 else f"model-v{version}.npz"
                restored = load_model(self.root / "future" / path)
                start = event["step"] * len(self.x)
                np.testing.assert_array_equal(saved["probabilities"][start:start + len(self.x)],
                                              restored.predict_proba(self.x))
        self.assertEqual(result["accuracy"], None)  # This fixture deliberately supplies no retrospective labels.


if __name__ == "__main__":
    unittest.main()
