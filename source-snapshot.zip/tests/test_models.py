import tempfile
import unittest
from pathlib import Path

import numpy as np

try:
    from ite.models import RidgeModel, prediction_loss
except ImportError:
    RidgeModel = prediction_loss = None


class ModelTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(RidgeModel, "The lightweight model is not implemented")
        self.rng = np.random.default_rng(123)

    def test_classifier_learns_and_emits_bounded_probabilities(self):
        x = self.rng.normal(size=(800, 5))
        y = (x[:, 0] - 2 * x[:, 1] > 0).astype(int)
        model = RidgeModel(task="classification", alpha=1).fit(x[:600], y[:600])
        self.assertGreater(np.mean(model.predict(x[600:]) == y[600:]), 0.94)
        probabilities = model.predict_proba(x[600:])
        self.assertEqual(probabilities.shape, (200, 2))
        np.testing.assert_allclose(probabilities.sum(axis=1), 1)
        self.assertTrue(((probabilities >= 0) & (probabilities <= 1)).all())

    def test_regressor_and_training_only_normalization(self):
        x = self.rng.normal(size=(500, 4))
        x[:, 3] = 7
        y = 3 * x[:, 0] - x[:, 1] + 4
        model = RidgeModel(task="regression", alpha=0.01).fit(x[:400], y[:400])
        mean_before = model.mean.copy()
        self.assertLess(prediction_loss("regression", y[400:], model.predict(x[400:])), 0.0001)
        model.predict(x[400:] + 100)
        np.testing.assert_array_equal(model.mean, mean_before)
        self.assertTrue(np.isfinite(model.predict(x[400:])).all())

    def test_serialization_preserves_predictions_without_pickle(self):
        x = self.rng.normal(size=(80, 3))
        y = (x[:, 0] > 0).astype(int)
        model = RidgeModel(task="classification", alpha=2).fit(x, y)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "model.npz"
            model.save(path)
            restored = RidgeModel.load(path)
            np.testing.assert_allclose(restored.predict_proba(x), model.predict_proba(x))

    def test_loss_is_normalized_for_regression_and_error_rate_for_classification(self):
        self.assertEqual(prediction_loss("classification", np.array([0, 1, 1]), np.array([0, 0, 1])), 1 / 3)
        self.assertEqual(prediction_loss("regression", np.array([1., 3.]), np.array([3., 3.]), scale=2), 1)


if __name__ == "__main__":
    unittest.main()
