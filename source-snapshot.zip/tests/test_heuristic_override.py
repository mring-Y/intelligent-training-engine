"""A host rule may request a candidate; it never authorizes deployment."""

import json
import os
from pathlib import Path
import tempfile
import unittest

import numpy as np

from ite.harness import Action, LLMReply


def observation(losses=(.10, .25, .23)):
    return {"loss_trend": [{"source_step": i, "loss": v, "labeled_samples": 48}
                           for i, v in enumerate(losses)],
            "drift_alarm": True, "remaining_label_budget": None,
            "remaining_token_budget": 60000, "model_age_batches": 8}


class HeuristicRuleTests(unittest.TestCase):
    def choose(self, profile="C", obs=None, action=None, **options):
        from ite.heuristic_override import choose_heuristic_action
        return choose_heuristic_action(Action("DO_NOTHING", "Retain") if action is None else action,
            observation() if obs is None else obs, profile=profile,
            remaining_train_seconds=options.pop("remaining_train_seconds", 5.),
            experiments_remaining=options.pop("experiments_remaining", 4), **options)

    def test_only_official_a_and_c_no_actions_are_overridden(self):
        self.assertEqual(self.choose("A").action, "RETRAIN_REPLAY")
        self.assertEqual(self.choose("C").action, "RETRAIN_HEAD_ONLY")
        for profile in ("B", None, "ridge"):
            self.assertEqual(self.choose(profile).action, "DO_NOTHING")
        action = Action("RETRAIN_LARGE", "Already requested")
        self.assertIs(self.choose(action=action), action)

    def test_a_single_spike_flat_high_loss_and_missing_alarm_do_not_force_training(self):
        for losses in ((.1, .5, .1), (.5, .5, .5), (.1, .101, .102), (.1, .5), ()):
            with self.subTest(losses=losses):
                self.assertEqual(self.choose(obs=observation(losses)).action, "DO_NOTHING")
        obs = observation(); obs["drift_alarm"] = False
        self.assertEqual(self.choose(obs=obs).action, "DO_NOTHING")

    def test_disabled_rule_and_exhausted_budgets_keep_no(self):
        for options in ({"enabled":False}, {"remaining_train_seconds":0.},
                        {"experiments_remaining":0}):
            self.assertEqual(self.choose(**options).action, "DO_NOTHING")
        for key in ("remaining_label_budget", "remaining_token_budget"):
            obs = observation(); obs[key] = 0
            self.assertEqual(self.choose(obs=obs).action, "DO_NOTHING")

    def test_provider_failure_is_never_replaced_by_an_override(self):
        from ite.heuristic_override import choose_heuristic_action
        self.assertIsNone(choose_heuristic_action(None, observation(), profile="C",
                          remaining_train_seconds=5., experiments_remaining=4))

    def test_replay_remains_host_only_and_is_rejected_from_model_wire_actions(self):
        from ite.harness import parse_action
        for profile in ("default","official_finetune","official_c_calibration"):
            with self.subTest(profile=profile),self.assertRaises(ValueError):
                parse_action('{"action":"RETRAIN_REPLAY","reason":"bypass"}',action_profile=profile)

    def test_future_or_malformed_loss_evidence_cannot_enter_the_rule(self):
        obs = observation(); obs["loss_trend"][2]["source_step"] = 0
        with self.assertRaises(ValueError): self.choose(obs=obs)
        obs = observation(); obs["loss_trend"][1]["loss"] = float("nan")
        with self.assertRaises(ValueError): self.choose(obs=obs)

    def test_a_replay_replaces_exactly_oldest_48_rows_without_growing_training(self):
        from ite.heuristic_override import replace_a_replay
        x = np.arange(80*3, dtype=float).reshape(80, 3); y = np.ones(80, dtype=int)
        reserve = {"x":np.full((48,3), -1.), "y":np.repeat(np.arange(1,7),8),
                   "ids":[f"train-{i}" for i in range(48)]}
        a,b = replace_a_replay(x,y,reserve)
        self.assertEqual(a.shape,x.shape)
        np.testing.assert_array_equal(a[:48],reserve["x"])
        np.testing.assert_array_equal(a[48:],x[48:])
        np.testing.assert_array_equal(b[:48],reserve["y"])
        np.testing.assert_array_equal(x,np.arange(80*3).reshape(80,3))
        with self.assertRaises(ValueError):replace_a_replay(x[:47],y[:47],reserve)
        reserve["y"] = np.ones(48)
        with self.assertRaises(ValueError):replace_a_replay(x,y,reserve)

    def test_config_is_opt_in_and_requires_official_future_harness(self):
        from ite.config import ExperimentConfig
        self.assertFalse(ExperimentConfig().heuristic_override)
        options = dict(task="regression",n_features=24,model_type="official_mlp",official_profile="C",
            harness_enabled=True,deployment_validation="future",training_preflight=True,
            candidate_feasibility=True,max_tokens=60000,history_windows=[192,768],
            min_validation=48,heuristic_override=True)
        config = ExperimentConfig.from_dict(options)
        self.assertTrue(ExperimentConfig.from_dict(config.to_dict()).heuristic_override)
        for invalid in ({"heuristic_override":1}, {"harness_enabled":False},
                        {"deployment_validation":"legacy"}, {"official_candidate_epochs":4}):
            with self.subTest(invalid=invalid), self.assertRaises(ValueError):
                ExperimentConfig.from_dict({**options,**invalid})


RUNTIME = Path(os.environ.get("ITE_OFFICIAL_RUNTIME_PYTHON",
    Path(__file__).resolve().parents[1]/".venv-official-a/Scripts/python.exe"))


@unittest.skipUnless(RUNTIME.is_file(), "official isolated CPU runtime missing")
class HeuristicControllerTests(unittest.TestCase):
    def test_actual_a_controller_uses_48_balanced_replay_rows_and_full_resume(self):
        from ite.config import ExperimentConfig
        from ite.controller import AdaptationController
        from ite.heuristic_override import load_training_stream
        from ite.official_model import OfficialModelAdapter
        from ite.tracking import JsonlLogger
        from ite.training import BoundedTrainer
        cfg=ExperimentConfig.from_dict(dict(task="classification",n_features=128,model_type="official_mlp",
            official_profile="A",official_runtime_python=str(RUNTIME),harness_enabled=True,
            heuristic_override=True,deployment_validation="future",training_preflight=True,
            candidate_feasibility=True,max_tokens=60000,history_windows=[192,768],min_validation=48))
        parent=OfficialModelAdapter("classification",RUNTIME,profile_type="A",candidate_epochs=5)
        data=load_training_stream("A")
        x=np.tile(data["x"],(3,1))[:900];y=np.tile(data["y"],3)[:900]
        class NoClient:
            def get_decision(self,obs):return LLMReply('{"action":"DO_NOTHING","reason":"Retain"}',8)
        with tempfile.TemporaryDirectory() as tmp,BoundedTrainer() as trainer:
            root=Path(tmp)
            with JsonlLogger(root/"events.jsonl","a-override") as log:
                c=AdaptationController(cfg,"drift",parent,.01,1.,log,trainer,root)
                c.history_x=x;c.history_y=y;c.history_steps=np.repeat(np.arange(9),100)
                c.llm_client=NoClient()
                c._record_harness_losses(np.repeat([.1,.25,.23],48),np.repeat([6,7,8],48))
                c._harness_decide(10,{"performance_drop":True,"diagnosis":"test_degradation"})
            events=[json.loads(s) for s in (root/"events.jsonl").read_text().splitlines()]
            fit=next(e for e in events if e["event"]=="candidate_evaluated")
            self.assertEqual(fit["train_samples"],720)
            self.assertEqual(fit["replay_samples"],48)
            self.assertEqual(len(set(fit["replay_source_ids"])),48)
            self.assertEqual(fit["trainable_policy"],"full")
            self.assertEqual(c.budget.training_attempts,1)
            self.assertEqual(c.gate.version,0)

    def test_actual_c_head_training_freezes_then_requires_new_source_labels(self):
        from ite.config import ExperimentConfig
        from ite.controller import AdaptationController
        from ite.data import ReleasedLabels
        from ite.official_model import OfficialModelAdapter
        from ite.official_sft_data import load_public_package
        from ite.tracking import JsonlLogger
        from ite.training import BoundedTrainer
        cfg = ExperimentConfig.from_dict(dict(task="regression",n_features=24,model_type="official_mlp",
            official_profile="C",official_runtime_python=str(RUNTIME),harness_enabled=True,
            heuristic_override=True,deployment_validation="future",training_preflight=True,
            candidate_feasibility=True,max_tokens=60000,history_windows=[192,768],min_validation=48))
        model = OfficialModelAdapter("regression",RUNTIME,profile_type="C",candidate_epochs=5)
        x = load_public_package("C")["x"][:900]
        y = model.predict(x)+20.
        class NoClient:
            def get_decision(self, obs):return LLMReply('{"action":"DO_NOTHING","reason":"Retain"}',8)
        with tempfile.TemporaryDirectory() as tmp, BoundedTrainer() as trainer:
            path=Path(tmp)
            with JsonlLogger(path/"events.jsonl","override") as log:
                c=AdaptationController(cfg,"drift",model,.01,1.,log,trainer,path)
                c.history_x=x.copy();c.history_y=y.copy();c.history_steps=np.repeat(np.arange(9),100)
                c.llm_client=NoClient()
                c._record_harness_losses(np.repeat([.1,.25,.23],48),np.repeat([6,7,8],48))
                c._harness_decide(10,{"performance_drop":True,"diagnosis":"test_degradation"})
                self.assertEqual(c.budget.training_attempts,1)
                self.assertIsNotNone(c.pending)
                self.assertEqual(c.gate.version,0)
                same=ReleasedLabels(np.arange(1000,1060),x[:60],y[:60],np.full(60,10))
                c._validate_pending(same,11)
                self.assertIsNotNone(c.pending)
                fresh=ReleasedLabels(np.arange(1100,1160),x[60:120],y[60:120],np.full(60,11))
                c._validate_pending(fresh,12)
                self.assertEqual(c.gate.version,1)
            events=[json.loads(s) for s in (path/"events.jsonl").read_text().splitlines()]
            override=next(e for e in events if e["event"]=="heuristic_override")
            self.assertEqual(override["original_action"],"DO_NOTHING")
            self.assertEqual(override["effective_action"],"RETRAIN_HEAD_ONLY")
            fit=next(e for e in events if e["event"]=="candidate_evaluated")
            self.assertEqual(fit["train_samples"],720)
            self.assertEqual(fit["trainable_policy"],"head_only")
            gate=next(e for e in events if e["event"]=="deploy")
            self.assertGreater(gate["gate_min_source_step"],gate["frozen_at"])


if __name__ == "__main__": unittest.main()
