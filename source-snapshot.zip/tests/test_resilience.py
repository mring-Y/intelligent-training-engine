import json
import tempfile
import unittest
from pathlib import Path

import numpy as np

from ite.config import ExperimentConfig
from ite.models import RidgeModel
from ite.runner import run_comparison
from ite.training import BoundedTrainer, TrainingResult


class FailedTrainer:
    def fit(self, *args, **kwargs):
        return TrainingResult("error", None, .001, "injected worker failure")

    def close(self):
        pass


class ResilienceTests(unittest.TestCase):
    def test_malformed_checkpoint_is_rejected_before_producing_predictions(self):
        good = {"task": "regression", "alpha": 1., "mean": [0., 0.], "std": [1., 1.],
                "weights": [1., 1.], "intercept": 0.}
        for change in ({"std": [0., 1.]}, {"weights": [float("nan"), 1.]},
                       {"weights": [1.]}, {"intercept": float("inf")}):
            with self.subTest(change=change), self.assertRaises(ValueError):
                RidgeModel.from_state({**good, **change})

    def test_failed_candidates_preserve_predictions_and_stream_completion(self):
        config = ExperimentConfig(n_batches=12, drift_start=0, label_delay=0)
        with tempfile.TemporaryDirectory() as directory:
            results = run_comparison(config, Path(directory), trainer=FailedTrainer())
            self.assertTrue(all(r["stream_batches"] == 12 and r["updates"] == 0 for r in results))
            self.assertEqual(len({r["mean_loss"] for r in results}), 1)
            self.assertGreater(results[-1]["adaptation_train_seconds"], 0)

    def test_worker_recovers_from_invalid_data_on_next_request(self):
        with BoundedTrainer() as trainer:
            invalid = trainer.fit("regression", .1, np.full((20, 2), np.nan), np.ones(20), 8)
            self.assertEqual(invalid.status, "error")
            valid = trainer.fit("regression", .1, np.zeros((20, 2)), np.ones(20), 8)
            self.assertEqual(valid.status, "ok")
            np.testing.assert_allclose(valid.model.predict(np.zeros((2, 2))), [1., 1.])

    def test_long_stream_online_state_is_bounded_and_checkpoint_can_be_restored(self):
        config = ExperimentConfig.from_dict({"n_batches": 1024, "batch_size": 16,
            "label_schedule": "uniform", "max_labels": 128, "max_train_seconds": 0})
        with tempfile.TemporaryDirectory() as directory:
            results = run_comparison(config, Path(directory), policies=("drift",))
            result = results[0]
            self.assertEqual(result["labels_released"], 128)
            self.assertLessEqual(result["peak_prediction_cache"], 3)
            self.assertLessEqual(result["peak_label_history"], 768)
            self.assertEqual(result["remaining_prediction_cache"], 0)
            initial = RidgeModel.load(Path(directory) / "drift/initial.npz")
            restored = RidgeModel.load(Path(directory) / "drift/deployed.npz")
            np.testing.assert_array_equal(initial.predict([[0.] * 8]), restored.predict([[0.] * 8]))

    def test_offline_mock_advice_is_logged_and_cannot_exceed_token_quota(self):
        config = ExperimentConfig.from_dict({"decision_backend": "mock", "max_tokens": 8,
            "n_batches": 12, "drift_start": 0, "label_delay": 0})
        with tempfile.TemporaryDirectory() as directory:
            result = run_comparison(config, Path(directory), policies=("periodic",))[0]
            self.assertEqual(result["tokens"], 8)
            events = [json.loads(line) for line in
                      (Path(directory) / "periodic/events.jsonl").read_text().splitlines()]
            self.assertTrue(any(e["event"] == "decision_advice" for e in events))
            self.assertEqual(result["stream_batches"], 12)


if __name__ == "__main__":
    unittest.main()
