"""Regression tests for the approved recent, entity-disjoint selection split."""

import json
import tempfile
import unittest
from contextlib import contextmanager
from pathlib import Path

import numpy as np

from ite.config import ExperimentConfig
from ite.controller import AdaptationController
from ite.data import PublicBatch, ReleasedLabels
from ite.models import RidgeModel
from ite.tracking import JsonlLogger
from ite.training import BoundedTrainer


class RecordingTrainer(BoundedTrainer):
    """Record actual fit inputs while retaining the real killable worker."""

    def __init__(self):
        super().__init__()
        self.fits = []

    def fit(self, task, alpha, features, targets, timeout_seconds, **options):
        result = super().fit(task, alpha, features, targets, timeout_seconds, **options)
        weights = options.get("sample_weight")
        self.fits.append({"features": features.copy(), "targets": targets.copy(),
                          "weights": weights.copy() if weights is not None else None,
                          "model": result.model, "status": result.status})
        return result


class RecentDisjointConfigTests(unittest.TestCase):
    def test_old_configs_default_to_chronological_and_new_mode_roundtrips(self):
        self.assertEqual(ExperimentConfig().selection_split, "chronological")
        config = ExperimentConfig(selection_split="recent_disjoint", deployment_validation="future")
        self.assertEqual(ExperimentConfig.from_dict(json.loads(json.dumps(config.to_dict()))), config)

    def test_recent_disjoint_requires_independent_future_gate(self):
        with self.assertRaises(ValueError):
            ExperimentConfig(selection_split="recent_disjoint", deployment_validation="legacy")

    def test_invalid_selection_modes_are_rejected(self):
        for mode in (None, True, 0, [], {}, "recent", "task_specific_disjoint", "Chronological"):
            with self.subTest(mode=mode), self.assertRaises(ValueError):
                ExperimentConfig.from_dict({"selection_split": mode})

    def test_task_specific_split_roundtrips_and_only_accepts_registered_classification_pools(self):
        config = ExperimentConfig(selection_split="task_specific", deployment_validation="future",
                                  task_specific_classification_pool_samples=48)
        self.assertEqual(ExperimentConfig.from_dict(config.to_dict()), config)
        for pool in (16, 31, 33, 47, 49, 64, True):
            with self.subTest(pool=pool), self.assertRaises(ValueError):
                ExperimentConfig(selection_split="task_specific", deployment_validation="future",
                                 task_specific_classification_pool_samples=pool)

    def test_task_specific_split_requires_independent_future_gate(self):
        with self.assertRaises(ValueError):
            ExperimentConfig(selection_split="task_specific", deployment_validation="legacy")

    def test_task_specific_preregistration_changes_only_split_policy(self):
        root = Path(__file__).resolve().parents[1]
        control = ExperimentConfig.load(root / "configs/optimization-task-specific-control.json").to_dict()
        candidate = ExperimentConfig.load(root / "configs/optimization-task-specific-split.json").to_dict()
        previous = ExperimentConfig.load(root / "configs/optimization-recent-disjoint.json").to_dict()
        self.assertEqual(control, previous)
        self.assertEqual(control.pop("selection_split"), "recent_disjoint")
        self.assertEqual(candidate.pop("selection_split"), "task_specific")
        self.assertEqual(candidate, control)
        self.assertEqual(ExperimentConfig.load(
            root / "configs/optimization-task-specific-split.json").task_specific_classification_pool_samples, 48)

    def test_candidate_configuration_changes_only_selection_split(self):
        root = Path(__file__).resolve().parents[1]
        baseline = ExperimentConfig.load(root / "configs/optimization-time-decay.json").to_dict()
        candidate = ExperimentConfig.load(root / "configs/optimization-recent-disjoint.json").to_dict()
        self.assertEqual(baseline.pop("selection_split"), "chronological")
        self.assertEqual(candidate.pop("selection_split"), "recent_disjoint")
        self.assertEqual(candidate, baseline)


class RecentDisjointControllerTests(unittest.TestCase):
    @contextmanager
    def controller(self, steps=None, **overrides):
        steps = np.repeat(np.arange(24), 4) if steps is None else np.asarray(steps, dtype=int)
        rng = np.random.default_rng(981)
        x = rng.normal(size=(len(steps), 3))
        x[:, 0] = np.arange(len(steps))  # Unique entities visible at the real trainer boundary.
        y = .2 * x[:, 0] - 3 * x[:, 1] + x[:, 2]
        initial_x = x if len(x) >= 4 else rng.normal(size=(8, 3))
        initial_y = -.2 * initial_x[:, 0] + 3 * initial_x[:, 1] - initial_x[:, 2]
        model = RidgeModel("regression").fit(initial_x, initial_y)
        values = {"task": "regression", "n_features": 3, "n_batches": 256,
                  "deployment_validation": "future", "selection_split": "recent_disjoint",
                  "history_windows": [192], "candidate_alphas": [1.],
                  "training_preflight": True, "training_weighting": "exponential",
                  "training_half_life_batches": 4., "min_gain": 0, **overrides}
        with tempfile.TemporaryDirectory() as directory, RecordingTrainer() as trainer:
            root = Path(directory)
            with JsonlLogger(root / "events.jsonl", "recent-disjoint") as logger:
                c = AdaptationController(ExperimentConfig.from_dict(values), "periodic", model,
                                         .01, 1., logger, trainer, root)
                c.history_x, c.history_y, c.history_steps = x, y, steps
                yield c, root, trainer, x, y

    def events(self, root, kind=None):
        events = [json.loads(line) for line in (root / "events.jsonl").read_text().splitlines()]
        return [event for event in events if kind is None or event["event"] == kind]

    def test_latest_source_reaches_actual_fit_with_disjoint_hand_derived_entities(self):
        # Removing the new split must fail here on the actual old chronological behavior.
        with self.controller(np.arange(96)) as (c, root, trainer, x, y):
            c._experiment(100, {"diagnosis": "performance"})
            self.assertEqual(len(trainer.fits), 1)
            fit = trainer.fits[0]
            self.assertEqual(fit["status"], "ok")
            self.assertEqual(int(fit["features"][-1, 0]), 95)
            want_train = list(range(1, 96, 2))
            want_selection = list(range(0, 95, 2))
            np.testing.assert_array_equal(fit["features"], x[want_train])
            np.testing.assert_array_equal(fit["targets"], y[want_train])
            self.assertFalse(set(want_selection) & set(fit["features"][:, 0]))
            event = self.events(root, "experiment_started")[0]
            self.assertEqual(event["selection_history_indices"], want_selection)
            self.assertEqual((event["history_samples"], event["validation_samples"]), (96, 48))
            self.assertEqual((event["validation_min_step"], event["validation_max_step"]), (0, 94))
            self.assertEqual((event["latest_source_train_samples"], event["latest_source_validation_samples"]), (1, 0))
            self.assertEqual(event["selection_split"], "recent_disjoint")
            self.assertEqual(self.events(root, "candidate_frozen")[0]["selection_max_source_step"], 94)

    def test_same_source_batch_can_supply_both_roles_but_never_the_same_entity(self):
        with self.controller() as (c, root, trainer, x, _):
            c._experiment(100, {"diagnosis": "performance"})
            ids = trainer.fits[0]["features"][:, 0].astype(int)
            event = self.events(root, "experiment_started")[0]
            selected = event["selection_history_indices"]
            np.testing.assert_array_equal(ids, np.arange(1, 96, 2))
            self.assertFalse(set(ids) & set(selected))
            self.assertEqual((event["train_max_step"], event["validation_max_step"]), (23, 23))
            self.assertEqual((event["latest_source_train_samples"], event["latest_source_validation_samples"]), (2, 2))

    def test_task_specific_classification_pool_48_uses_24_disjoint_selection_entities(self):
        steps = np.repeat(np.arange(28), 4)
        with self.controller(steps, task="classification", scenario="gradual",
                             selection_split="task_specific",
                             task_specific_classification_pool_samples=48) as (c, root, trainer, x, _):
            c._experiment(100, {"diagnosis": "performance"})
            expected_selection = np.arange(64, 112, 2)
            expected_train = np.setdiff1d(np.arange(112), expected_selection)
            fit_ids = trainer.fits[0]["features"][:, 0].astype(int)
            np.testing.assert_array_equal(fit_ids, expected_train)
            event = self.events(root, "experiment_started")[0]
            self.assertEqual(event["selection_split"], "task_specific")
            self.assertEqual(event["selection_split_effective"], "recent_disjoint")
            self.assertEqual(event["selection_pool_samples"], 48)
            self.assertEqual(event["selection_history_indices"], expected_selection.tolist())
            self.assertEqual((event["train_samples"], event["validation_samples"]), (88, 24))
            self.assertFalse(set(fit_ids) & set(event["selection_history_indices"]))
            self.assertEqual((event["latest_source_train_samples"],
                              event["latest_source_validation_samples"]), (2, 2))

    def test_task_specific_regression_preserves_global_recent_disjoint_partition(self):
        steps = np.repeat(np.arange(28), 4)
        expected = None
        for mode in ("recent_disjoint", "task_specific"):
            with self.controller(steps, task="regression", scenario="abrupt",
                                 selection_split=mode) as (c, root, trainer, _, _):
                c._experiment(100, {"diagnosis": "performance"})
                event = self.events(root, "experiment_started")[0]
                outcome = (trainer.fits[0]["features"][:, 0].tolist(),
                           event["selection_history_indices"], event["validation_samples"])
                if expected is None:
                    expected = outcome
                else:
                    self.assertEqual(outcome, expected)
                    self.assertEqual(event["selection_split_effective"], "recent_disjoint")
                    self.assertEqual(event["selection_pool_samples"], 96)

    def test_task_specific_recurring_uses_chronological_batches_for_both_tasks(self):
        steps = np.repeat(np.arange(28), 4)
        for task in ("classification", "regression"):
            with self.subTest(task=task), self.controller(
                    steps, task=task, scenario="recurring", selection_split="task_specific") as (
                    c, root, trainer, _, _):
                c._experiment(100, {"diagnosis": "performance"})
                event = self.events(root, "experiment_started")[0]
                fit_steps = np.unique(trainer.fits[0]["features"][:, 0].astype(int) // 4)
                self.assertEqual(event["selection_split_effective"], "chronological")
                self.assertIsNone(event["selection_pool_samples"])
                self.assertFalse(set(fit_steps) & set(range(event["validation_min_step"], 28)))
                self.assertEqual((event["train_samples"], event["validation_samples"]), (64, 48))
                self.assertNotIn("selection_history_indices", event)

    def test_task_specific_classification_pool_32_routes_sixteen_each_from_recent_32(self):
        steps = np.repeat(np.arange(28), 4)
        with self.controller(steps, task="classification", scenario="abrupt",
                             selection_split="task_specific",
                             task_specific_classification_pool_samples=32) as (c, root, trainer, _, _):
            c._experiment(100, {"diagnosis": "performance"})
            event = self.events(root, "experiment_started")[0]
            self.assertEqual(event["selection_pool_samples"], 32)
            self.assertEqual(event["validation_samples"], 16)
            self.assertEqual(len(event["selection_history_indices"]), 16)
            self.assertEqual(len(trainer.fits[0]["targets"]), 96)
            fit_ids = set(trainer.fits[0]["features"][:, 0].astype(int))
            self.assertFalse(fit_ids & set(event["selection_history_indices"]))

    def test_task_specific_classification_preflight_preserves_attempt_and_cooldown_on_shortage(self):
        steps = np.repeat(np.arange(10), 4)[:-1]
        with self.controller(steps, task="classification", scenario="gradual",
                             selection_split="task_specific") as (c, root, trainer, x, _):
            before = c.predict(x)
            last_experiment, cooldown = c.last_experiment, c.cooldown_until
            c._experiment(100, {"diagnosis": "performance"})
            self.assertEqual((c.budget.experiments, c.budget.training_attempts), (0, 0))
            self.assertEqual((c.last_experiment, c.cooldown_until), (last_experiment, cooldown))
            self.assertEqual(trainer.fits, [])
            np.testing.assert_array_equal(c.predict(x), before)
            event = self.events(root, "training_preflight_skipped")[0]
            self.assertEqual((event["train_samples"], event["validation_samples"]), (15, 24))
            self.assertEqual(event["selection_split_effective"], "recent_disjoint")

    def test_recent_block_keeps_older_history_training_and_latest_singleton_training(self):
        steps = np.r_[np.repeat(np.arange(30), 4)[:-1], 30]
        with self.controller(steps) as (c, root, trainer, _, _):
            c._experiment(100, {"diagnosis": "performance"})
            want_selection = list(range(24, 119, 2))
            want_train = list(range(24)) + list(range(25, 120, 2))
            np.testing.assert_array_equal(trainer.fits[0]["features"][:, 0], want_train)
            event = self.events(root, "experiment_started")[0]
            self.assertEqual(event["selection_history_indices"], want_selection)
            self.assertEqual((event["latest_source_train_samples"], event["latest_source_validation_samples"]), (1, 0))

    def test_sixty_three_labels_skip_without_attempt_cooldown_or_prediction_change(self):
        with self.controller(np.arange(63)) as (c, root, trainer, x, _):
            before, clock = c.predict(x), c.last_experiment
            c._experiment(100, {"diagnosis": "performance"})
            self.assertEqual((c.budget.experiments, c.budget.training_attempts, c.budget.train_seconds), (0, 0, 0))
            self.assertEqual((c.last_experiment, c.last_experiment_source, c.cooldown_until), (clock, -1, 0))
            self.assertEqual(trainer.fits, [])
            self.assertIsNone(c.pending)
            np.testing.assert_array_equal(c.predict(x), before)
            event = self.events(root, "training_preflight_skipped")[0]
            self.assertEqual((event["train_samples"], event["validation_samples"]), (15, 48))
            self.assertEqual(event["history_samples"], 63)

    def test_sixty_four_labels_fit_sixteen_and_select_forty_eight(self):
        with self.controller(np.arange(64)) as (c, root, trainer, _, _):
            c._experiment(100, {"diagnosis": "performance"})
            self.assertEqual((c.budget.experiments, c.budget.training_attempts), (1, 1))
            self.assertEqual(len(trainer.fits[0]["features"]), 16)
            self.assertEqual(trainer.fits[0]["features"][-1, 0], 63)
            event = self.events(root, "experiment_started")[0]
            self.assertEqual((event["train_samples"], event["validation_samples"]), (16, 48))
            self.assertEqual(len(set(event["selection_history_indices"])), 48)

    def test_short_histories_never_duplicate_selection_entities_or_train_newest_in_selection(self):
        for count in (0, 1, 2, 17, 47, 48, 49):
            with self.subTest(count=count), self.controller(np.arange(count)) as (c, root, trainer, _, _):
                c._experiment(100, {"diagnosis": "performance"})
                event = self.events(root, "training_preflight_skipped")[0]
                selected = event["selection_history_indices"]
                self.assertEqual(len(set(selected)), min(48, max(0, count - 1)))
                self.assertEqual(event["validation_samples"], len(selected))
                self.assertNotIn(count - 1, selected)
                self.assertEqual(trainer.fits, [])
                self.assertEqual(c.budget.training_attempts, 0)

    def test_full_requested_selection_is_required_even_above_min_validation(self):
        # The approved target is 48, not merely the future gate's floor of 32.
        with self.controller(np.arange(47)) as (c, root, trainer, _, _):
            c._experiment(100, {"diagnosis": "performance"})
            event = self.events(root, "training_preflight_skipped")[0]
            self.assertEqual(event["validation_samples"], 46)
            self.assertEqual(trainer.fits, [])

    def test_allocation_ignores_feature_and_target_values(self):
        allocations = []
        for changed in (False, True):
            with self.controller() as (c, root, trainer, _, _):
                if changed:
                    c.history_x = c.history_x[::-1].copy() * -1000
                    c.history_y = c.history_y[::-1].copy() * 1000
                c._experiment(100, {"diagnosis": "performance"})
                allocations.append(self.events(root, "experiment_started")[0]["selection_history_indices"])
        self.assertEqual(allocations, [list(range(0, 95, 2))] * 2)

    def test_selection_values_do_not_leak_into_weighted_fit_and_loss_is_unweighted(self):
        states = []
        for changed in (False, True):
            with self.controller() as (c, root, trainer, x, _):
                if changed:
                    c.history_x[::2, 1:] += 1000
                    c.history_y[::2] -= 1000
                c._experiment(100, {"diagnosis": "performance"})
                fit = trainer.fits[0]
                states.append(fit["model"].state())
                event = self.events(root, "candidate_evaluated")[0]
                expected_loss = np.mean((c.history_y[::2] - fit["model"].predict(c.history_x[::2])) ** 2)
                self.assertAlmostEqual(event["validation_loss"], expected_loss)
        self.assertEqual(states[0], states[1])

    def test_every_candidate_slice_keeps_newest_and_h4_mean_one_weights(self):
        with self.controller(np.repeat(np.arange(192), 4), history_windows=[192, 384, 768]) as (c, root, trainer, x, y):
            c._experiment(200, {"diagnosis": "performance"})
            train_ids = np.r_[np.arange(672), np.arange(673, 768, 2)]
            selected = np.arange(672, 767, 2)
            events = self.events(root, "candidate_evaluated")
            self.assertEqual(len(events), 3)
            for fit, event, window in zip(trainer.fits, events, (192, 384, 768)):
                ids = train_ids[-window:]
                steps = ids // 4
                weights = 2. ** ((steps - 191) / 4.)
                weights *= len(weights) / weights.sum()
                np.testing.assert_array_equal(fit["features"], x[ids])
                np.testing.assert_array_equal(fit["targets"], y[ids])
                np.testing.assert_allclose(fit["weights"], weights, atol=1e-14)
                mean = np.average(x[ids], axis=0, weights=weights)
                std = np.sqrt(np.average((x[ids] - mean) ** 2, axis=0, weights=weights))
                design = np.column_stack(((x[ids] - mean) / std, np.ones(len(ids))))
                penalty = np.diag([1., 1., 1., 0.])
                beta = np.linalg.solve(design.T @ (weights[:, None] * design) + penalty,
                                       design.T @ (weights * y[ids]))
                query = np.column_stack(((x - mean) / std, np.ones(len(x))))
                np.testing.assert_allclose(fit["model"].predict(x), query @ beta, atol=1e-10)
                self.assertAlmostEqual(event["validation_loss"], np.mean((y[selected] - (query @ beta)[selected]) ** 2))
                self.assertEqual(event["train_max_step"], 191)
                self.assertEqual(event["weight_reference_source_step"], 191)
                self.assertEqual(event["training_half_life_batches"], 4.)
                self.assertAlmostEqual(event["weight_sum"], len(ids))

    def test_default_and_explicit_chronological_keep_old_fit_and_predictions_exactly(self):
        states = []
        for explicit in (False, True):
            with self.controller(selection_split="chronological") as (c, root, trainer, x, y):
                if not explicit:
                    values = c.config.to_dict()
                    values.pop("selection_split")
                    c.config = ExperimentConfig.from_dict(values)
                c._experiment(100, {"diagnosis": "performance"})
                fit = trainer.fits[0]
                np.testing.assert_array_equal(fit["features"], x[:48])
                weights = 2. ** ((c.history_steps[:48] - 23) / 4.)
                weights *= len(weights) / weights.sum()
                expected = RidgeModel("regression", 1.).fit(x[:48], y[:48], sample_weight=weights)
                np.testing.assert_array_equal(fit["model"].predict(x), expected.predict(x))
                states.append(fit["model"].state())
                self.assertNotIn("selection_history_indices", self.events(root, "experiment_started")[0])
        self.assertEqual(states[0], states[1])

    def test_bounded_stably_sorted_release_history_is_the_allocation_universe(self):
        with self.controller(np.arange(0)) as (c, root, trainer, _, _):
            c.policy = "static"
            for source in range(10):
                ids = np.arange(source * 24, (source + 1) * 24)
                x = np.column_stack((ids, np.ones(24), -np.ones(24))).astype(float)
                y = .2 * ids - 4.
                predictions = dict(zip(map(int, ids), c.predict(x)))
                c.observe(PublicBatch(source + 2, ids, x),
                          ReleasedLabels(ids, x, y, np.full(24, source)), predictions)
                self.assertLessEqual(len(c.history_y), 192)
            np.testing.assert_array_equal(c.history_x[:, 0], np.arange(48, 240))
            np.testing.assert_array_equal(c.history_steps, np.repeat(np.arange(2, 10), 24))
            c._experiment(100, {"diagnosis": "performance"})
            selected = self.events(root, "experiment_started")[0]["selection_history_indices"]
            self.assertEqual(selected, list(range(96, 191, 2)))
            self.assertEqual(trainer.fits[0]["features"][-1, 0], 239)

    def test_freeze_excludes_equal_source_and_requires_thirty_two_post_freeze_labels(self):
        with self.controller(update_interval=1, cooldown=0) as (c, root, trainer, x, y):
            original = c.gate.model
            c._experiment(100, {"diagnosis": "performance"})
            self.assertIsNotNone(c.pending)
            frozen_scores = c.pending["model"].predict(x)
            for source in (23, 100):
                c._validate_pending(ReleasedLabels(np.arange(48), x[:48], y[:48], np.full(48, source)), 102)
                self.assertEqual(c.pending["y"], [])
            c.policy = "periodic"
            # A newer released source would otherwise make another real search eligible.
            same_freeze = ReleasedLabels(np.array([10000]), x[:1], y[:1], np.array([100]))
            c.observe(PublicBatch(103, np.arange(96), x), same_freeze,
                      {10000: float(c.predict(x[:1])[0])})
            self.assertEqual(len(trainer.fits), 1)
            self.assertEqual(c.pending["y"], [])
            np.testing.assert_array_equal(c.pending["model"].predict(x), frozen_scores)
            c._validate_pending(ReleasedLabels(np.arange(31), x[:31], y[:31], np.full(31, 101)), 104)
            self.assertIs(c.gate.model, original)
            self.assertEqual(sum(map(len, c.pending["y"])), 31)
            c._validate_pending(ReleasedLabels(np.array([31]), x[31:32], y[31:32], np.array([101])), 105)
            self.assertEqual(c.gate.updates, 1)
            self.assertIsNone(c.pending)
            np.testing.assert_array_equal(c.predict(x), frozen_scores)
            np.testing.assert_array_equal(RidgeModel.load(root / "deployed.npz").predict(x), frozen_scores)
            event = self.events(root, "deploy")[0]
            self.assertEqual((event["gate_samples"], event["gate_min_source_step"], event["gate_max_source_step"]), (32, 101, 101))


if __name__ == "__main__":
    unittest.main()
