"""Official-only maintenance authority, frozen-head routing and future gates."""

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

from ite.budget import ResourceBudget
from ite.budget_guard import BudgetGuard
from ite.config import ExperimentConfig
from ite.controller import AdaptationController
from ite.harness import MockLLMClient, parse_action, parse_action_with_repair
from ite.official_sft_replay import replay_partition
from ite.tracking import JsonlLogger
from tests.test_harness_control import FixedClient
from tests.test_official_sft_replay import ConstantModel
from tests import test_official_sft_replay as replay_fixtures


def observation():
    return {"loss_trend": [], "drift_alarm": True, "remaining_label_budget": None,
            "remaining_token_budget": 1000, "model_age_batches": 7}


class OfficialFinetuneActionTests(unittest.TestCase):
    def test_new_schema_is_opt_in_and_cannot_inject_training_parameters(self):
        from ite.harness import ACTION_SCHEMA, OFFICIAL_ACTION_SCHEMA, action_schema
        raw = json.dumps({"action": "RETRAIN_HEAD_ONLY", "reason": "评估输出头。"})
        self.assertNotIn("RETRAIN_HEAD_ONLY", ACTION_SCHEMA["properties"]["action"]["enum"])
        self.assertIn("RETRAIN_HEAD_ONLY", OFFICIAL_ACTION_SCHEMA["properties"]["action"]["enum"])
        with self.assertRaises(ValueError):
            parse_action(raw)
        self.assertEqual(parse_action(raw, action_profile="official_finetune").action, "RETRAIN_HEAD_ONLY")
        repaired, yes = parse_action_with_repair("```json\n" + raw + "\n```", action_profile="official_finetune")
        self.assertTrue(yes)
        self.assertEqual(repaired.action, "RETRAIN_HEAD_ONLY")
        for extra in ({"epochs": 100}, {"lr": .1}, {"trainable_policy": "full"}, {"window": 4}):
            with self.subTest(extra=extra), self.assertRaises(ValueError):
                parse_action(json.dumps({"action": "RETRAIN_HEAD_ONLY", "reason": "test", **extra}),
                             action_profile="official_finetune")
        with self.assertRaises(ValueError):
            parse_action(raw, action_profile="unknown")
        calibrate = json.dumps({"action": "CALIBRATE_DOWN", "reason": "校准高估风险。"})
        self.assertNotIn("CALIBRATE_DOWN", OFFICIAL_ACTION_SCHEMA["properties"]["action"]["enum"])
        self.assertNotIn("CALIBRATE_DOWN", ACTION_SCHEMA["properties"]["action"]["enum"])
        self.assertEqual(parse_action(calibrate, action_profile="official_c_calibration").action,
                         "CALIBRATE_DOWN")
        with self.assertRaises(ValueError):
            parse_action(calibrate, action_profile="official_finetune")
        with self.assertRaises(ValueError):
            action_schema("unknown")

    def test_calibration_risk_observation_requires_a_valid_regression_pair(self):
        from ite.harness import validate_observation
        risk = {**observation(), "overestimate_rate": 0.5, "mean_overestimate": 3.25}
        validate_observation(risk, task="regression")
        for malformed in ({**observation(), "overestimate_rate": .5},
                           {**risk, "overestimate_rate": 1.1},
                           {**risk, "mean_overestimate": -1.},
                           {**risk, "mean_overestimate": float("nan")}):
            with self.subTest(malformed=malformed), self.assertRaises(ValueError):
                validate_observation(malformed, task="regression")
        with self.assertRaises(ValueError):
            validate_observation(risk, task="classification")

    def test_calibrate_down_mock_and_configuration_are_official_c_only(self):
        from ite.harness import MockLLMClient
        context = {"task": "regression", "n_features": 24, "model_type": "official_mlp",
                   "official_profile": "C", "official_runtime_python": "isolated-python",
                   "harness_enabled": True, "training_preflight": True, "candidate_feasibility": True,
                   "deployment_validation": "future", "max_tokens": 1000, "label_mode": "provided",
                   "harness_mock_mode": "calibrate_down"}
        config = ExperimentConfig.from_dict(context)
        client = MockLLMClient("calibrate_down", model_type="official_mlp", profile_type="C")
        self.assertEqual(parse_action(client.get_decision(observation()).raw_json,
                                      action_profile="official_c_calibration").action, "CALIBRATE_DOWN")
        for changes in ({"model_type": "ridge", "official_profile": ""},
                        {"official_profile": "B", "n_features": 34},
                        {"task": "classification", "official_profile": "A", "n_features": 128}):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                ExperimentConfig.from_dict({**context, **changes})
        for model_type, profile in (("official_mlp", "A"), ("official_mlp", "B"), ("ridge", "C")):
            with self.subTest(model_type=model_type, profile=profile), self.assertRaises(ValueError):
                MockLLMClient("calibrate_down", model_type=model_type, profile_type=profile)

    def test_guard_rejects_head_for_fallback_models_and_accepts_explicit_official_profile(self):
        for model_type, profile in (("ridge", "default"), ("tree", "default"),
                                    ("official_mlp", "official_finetune")):
            with self.subTest(model_type=model_type), tempfile.TemporaryDirectory() as tmp:
                config = ExperimentConfig(task="regression", label_mode="provided", max_tokens=1000)
                budget = ResourceBudget(config, model_type=model_type)
                with JsonlLogger(Path(tmp)/"events.jsonl", "test") as logger:
                    guard = BudgetGuard(budget, logger, action_profile=profile)
                    action = guard.get_decision(observation(), FixedClient("RETRAIN_HEAD_ONLY"), 7)
                self.assertEqual(action is not None, model_type == "official_mlp")
                self.assertEqual(guard.reason, None if model_type == "official_mlp" else "invalid_action")

    def test_official_mock_head_is_explicit_and_default_decision_is_unchanged(self):
        self.assertEqual(parse_action(MockLLMClient(model_type="official_mlp").get_decision(observation()).raw_json).action,
                         "RETRAIN_SMALL")
        client = MockLLMClient("head_only", model_type="official_mlp")
        self.assertEqual(parse_action(client.get_decision(observation()).raw_json,
            action_profile="official_finetune").action, "RETRAIN_HEAD_ONLY")
        self.assertEqual(parse_action(client.get_decision({**observation(), "drift_alarm": False}).raw_json).action,
                         "DO_NOTHING")
        for kind in ("tree", "ridge"):
            with self.assertRaises(ValueError):
                MockLLMClient("head_only", model_type=kind)

    def test_head_replay_preserves_window_sources_future_gate_and_next_batch_deploy(self):
        data = replay_fixtures.OfficialSFTReplayTests().data()
        data = {**data, "profile": "C", "unit": "cycles", "x": np.zeros((1200, 2)),
                "y": np.ones(1200)*2, "ids": [f"r{i}" for i in range(1200)], "groups": ["engine"]*1200}
        calls = []
        class Better(ConstantModel):
            checkpoint_sha256 = "head-candidate"
            steps = 25
            last_fit_audit = {"trainable_policy": "head_only", "trainable_parameters": 33,
                              "max_parameter_delta": {"w1": 0., "b1": 0., "w2": .1, "b2": .1}}
            def predict(self, x):
                return np.full(len(x), 2.)
        def train(parent, x, y, allowance, *, trainable_policy):
            calls.append((parent.checkpoint_sha256, len(y), allowance, trainable_policy))
            return Better(), .01
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)/"run"
            summary = replay_partition(data, list(range(1200)), "eval", "stable", root, ConstantModel(),
                lambda _: {"action": "RETRAIN_HEAD_ONLY", "reason": "测试冻结输出头。"},
                decision_steps=(7,), trainer=train, action_profile="official_finetune")
            events = [json.loads(line) for line in (root/"events.jsonl").read_text(encoding="utf-8").splitlines()]
            with np.load(root/"predictions.npz", allow_pickle=False) as predictions:
                self.assertTrue(np.all(predictions["versions"][:1000] == 0))
                self.assertTrue(np.all(predictions["versions"][1000:] == 1))
        # At step7 only700 released rows:48 screen +652 train; none from source7.
        self.assertEqual(calls, [("initial", 652, 5., "head_only")])
        evidence = summary["records"][0]["evidence"]
        self.assertFalse(set(evidence["train_source_ids"]) & set(evidence["screening_source_ids"]))
        self.assertEqual(evidence["trainable_policy"], "head_only")
        self.assertEqual(evidence["fit_audit"]["trainable_parameters"], 33)
        deploy = next(row for row in events if row["event"] == "deploy")
        self.assertEqual((deploy["step"], deploy["gate_min_source_step"], deploy["frozen_at"]), (9, 8, 7))

    def test_calibrated_replay_uses_disjoint_prior_source_before_screen_and_future_gate(self):
        data = replay_fixtures.OfficialSFTReplayTests().data()
        data = {**data, "profile": "C", "unit": "cycles", "x": np.zeros((12000, 2)),
                "y": np.ones(12000) * 2, "ids": [f"r{i}" for i in range(12000)],
                "groups": ["engine"] * 12000}
        calls, calibration = [], []

        class Calibrated(ConstantModel):
            checkpoint_sha256 = "calibrated-head"
            steps = 25
            last_fit_audit = {"trainable_policy": "head_only", "trainable_parameters": 33}
            safety_margin = 0.
            def predict_raw(self, x):
                return np.full(len(x), 2.5)
            def predict(self, x):
                return np.maximum(0., self.predict_raw(x) - self.safety_margin)
            def calibrate_down(self, x, y):
                calibration.append((len(y), x.copy(), y.copy()))
                self.safety_margin = .5
                return {"samples": len(y), "quantile": .9, "safety_margin": .5}

        def train(parent, x, y, allowance, *, trainable_policy):
            calls.append((parent.checkpoint_sha256, len(y), allowance, trainable_policy))
            return Calibrated(), .01

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "run"
            summary = replay_partition(data, list(range(12000)), "train", "abrupt", root,
                ConstantModel(), lambda _: {"action": "CALIBRATE_DOWN", "reason": "校准正向残差。"},
                decision_steps=(7,), trainer=train, action_profile="official_c_calibration")
            events = [json.loads(line) for line in (root / "events.jsonl").read_text(encoding="utf-8").splitlines()]
            with np.load(root / "predictions.npz", allow_pickle=False) as predictions:
                self.assertTrue(np.all(predictions["versions"][:10000] == 0))
                self.assertTrue(np.all(predictions["versions"][10000:] == 1))
        self.assertEqual(calls, [("initial", 720, 5., "head_only")])
        self.assertEqual(calibration[0][0], 48)
        record = summary["records"][0]
        evidence = record["evidence"]
        self.assertEqual(evidence["safety_margin"], .5)
        self.assertEqual(evidence["calibration_samples"], 48)
        self.assertEqual(evidence["calibration_source_step"], 5)
        self.assertTrue(set(evidence["calibration_source_ids"]).isdisjoint(evidence["train_source_ids"]))
        self.assertTrue(set(evidence["calibration_source_ids"]).isdisjoint(evidence["screening_source_ids"]))
        evaluated = next(row for row in events if row["event"] == "candidate_evaluated")
        self.assertEqual(evaluated["calibration_samples"], 48)
        frozen = next(row for row in events if row["event"] == "candidate_frozen")
        deployed = next(row for row in events if row["event"] == "deploy")
        self.assertEqual((frozen["step"], deployed["step"], deployed["gate_min_source_step"]), (7, 9, 8))

    def test_calibration_fails_closed_without_a_prior_source_window(self):
        data = replay_fixtures.OfficialSFTReplayTests().data()
        data = {**data, "profile": "C", "unit": "cycles"}
        trainer = unittest.mock.Mock(return_value=(ConstantModel(), .01))
        with tempfile.TemporaryDirectory() as temporary:
            summary = replay_partition(data, list(range(96)), "eval", "stable", Path(temporary) / "run",
                ConstantModel(), lambda _: {"action": "CALIBRATE_DOWN", "reason": "校准高估风险。"},
                decision_steps=(7,), trainer=trainer, action_profile="official_c_calibration")
        trainer.assert_not_called()
        self.assertEqual(summary["records"][0]["rejection"], "insufficient_independent_calibration_window")

    def test_controller_head_action_uses_only_largest_window_and_resets_profile_on_fallback(self):
        from ite.official_model import OfficialModelAdapter
        from tests.test_official_head_only import RUNTIME
        from ite.official_sft_data import load_public_package
        from ite.training import TrainingResult
        if not RUNTIME.is_file():
            self.skipTest("official runtime not provisioned")
        data = load_public_package("C")
        model = OfficialModelAdapter("regression", RUNTIME, profile_type="C")
        config = ExperimentConfig.from_dict({"task": "regression", "model_type": "official_mlp",
            "official_profile": "C", "n_features": 24, "official_runtime_python": str(RUNTIME),
            "harness_enabled": True, "training_preflight": True, "candidate_feasibility": True,
            "deployment_validation": "future", "max_tokens": 1000, "label_mode": "provided"})
        with tempfile.TemporaryDirectory() as tmp, JsonlLogger(Path(tmp)/"events.jsonl", "test") as logger:
            trainer = unittest.mock.Mock()
            trainer.fit.return_value = TrainingResult("error", None, .001, "test-no-candidate")
            controller = AdaptationController(config, "drift", model, .01, data["loss_scale"], logger,
                                              trainer, Path(tmp))
            controller.history_x, controller.history_y = data["x"][:1200], data["y"][:1200]
            controller.history_steps = np.repeat(np.arange(20), 60)
            controller.llm_client = FixedClient("RETRAIN_HEAD_ONLY")
            controller._harness_decide(21, {"performance_drop": True, "diagnosis": "test"})
            self.assertEqual(trainer.fit.call_count, 1)
            args, kwargs = trainer.fit.call_args
            self.assertEqual(len(args[3]), 720)
            np.testing.assert_array_equal(args[2], data["x"][432:1152])
            self.assertEqual(kwargs["official_options"]["trainable_policy"], "head_only")
            self.assertEqual(args[4], 5.)
            with self.assertRaises(ValueError):
                controller._experiment(19, {}, trainable_policy="low_lr")
            controller.activate_fallback(model, "tree", .01, 19, "test_failure", [])
            self.assertEqual(controller.budget_guard.action_profile, "default")

    def test_prompt_supports_new_action_without_rewriting_frozen_teacher_profile(self):
        from ite.trio_client import TrioLLMClient, build_messages
        visible = {"profile": "C", "remaining_train_seconds": 20., "feature_distance": .75}
        old = build_messages(observation(), model_type="official_mlp", prompt_profile="official_sft", official_context=visible)
        new = build_messages(observation(), model_type="official_mlp", prompt_profile="official_finetune", official_context=visible)
        self.assertNotIn("RETRAIN_HEAD_ONLY", old[0]["content"])
        for value in ("RETRAIN_HEAD_ONLY", "w1", "w2", "768", "5epoch", "model_age_batches", "不保证"):
            self.assertIn(value, new[0]["content"])
        self.assertEqual(old[1], new[1])
        client = TrioLLMClient(model_type="official_mlp", prompt_profile="official_finetune", official_context=visible)
        self.assertEqual(client.timeout_seconds, 15)
        # Fake the transport only; the real client must transmit the new Schema.
        response = {"content": '{"action":"RETRAIN_HEAD_ONLY","reason":"评估输出头。"}',
                    "input_tokens": 5, "output_tokens": 5, "finish_reason": "stop"}
        with patch("ite.trio_client.subprocess.Popen") as worker:
            worker.return_value.communicate.return_value = (json.dumps(response), "")
            worker.return_value.returncode = 0
            reply = client.get_decision(observation())
            wire = json.loads(worker.return_value.communicate.call_args.args[0])
        self.assertIn("RETRAIN_HEAD_ONLY", wire["messages"][0]["content"])
        self.assertEqual(parse_action(reply.raw_json, action_profile="official_finetune").action, "RETRAIN_HEAD_ONLY")

    def test_c_official_prompt_exposes_released_overestimation_and_calibration_action(self):
        from ite.trio_client import build_messages
        risk = {**observation(), "overestimate_rate": .25, "mean_overestimate": 2.5}
        messages = build_messages(risk, model_type="official_mlp", prompt_profile="official_finetune",
            official_context={"profile": "C", "remaining_train_seconds": 20., "feature_distance": .75})
        self.assertIn("CALIBRATE_DOWN", messages[0]["content"])
        self.assertIn("前一来源批次", messages[0]["content"])
        self.assertIn("90", messages[0]["content"])
        self.assertIn('"overestimate_rate":0.25', messages[1]["content"])

    def test_controller_observation_summarizes_only_recent_released_c_residuals(self):
        from ite.models import RidgeModel
        from ite.harness import validate_observation
        x = np.arange(48, dtype=float).reshape(24, 2)
        model = RidgeModel("regression").fit(x, np.arange(24.))
        model.profile_type = "C"
        config = ExperimentConfig(task="regression", model_type="official_mlp", official_profile="C",
            n_features=24, harness_enabled=True, training_preflight=True, candidate_feasibility=True,
            deployment_validation="future", max_tokens=1000, label_mode="provided")
        with tempfile.TemporaryDirectory() as temporary, JsonlLogger(Path(temporary) / "events.jsonl", "test") as logger:
            controller = AdaptationController(config, "drift", model, .01, 1., logger,
                                               unittest.mock.Mock(), Path(temporary), active_model_type="official_mlp")
            residuals = np.asarray([2., -1., 0., 4., -2.])
            controller._record_harness_losses(np.ones(5), np.arange(5), overestimation_residuals=residuals)
            value = controller.harness_observation(True)
        validate_observation(value, task="regression")
        self.assertEqual(value["overestimate_rate"], .4)
        self.assertEqual(value["mean_overestimate"], 1.2)

    def test_controller_calibrates_before_screen_and_preserves_future_gate(self):
        from ite.data import PublicBatch, ReleasedLabels
        from ite.official_model import OfficialModelAdapter
        from ite.training import TrainingResult

        class Parent(ConstantModel):
            profile_type = "C"
            candidate_epochs = 5
            mean, std = np.zeros(24), np.ones(24)
        class Candidate(Parent):
            checkpoint_sha256 = "head-calibrated"
            feature_count = 24
            safety_margin, safety_calibration = 0., None
            _validate_safety_policy = OfficialModelAdapter._validate_safety_policy
            calibrate_down = OfficialModelAdapter.calibrate_down
            def predict_raw(self, x):
                return np.full(len(x), 2.5)
            def predict(self, x):
                return np.maximum(0., self.predict_raw(x)-self.safety_margin)
            def save(self, path):
                Path(path).write_bytes(b"test-only-checkpoint")

        candidate, calls = Candidate(), []
        class Trainer:
            def fit(self, task, alpha, x, y, allowance, **options):
                calls.append((len(y), options["official_options"]["trainable_policy"]))
                return TrainingResult("ok", candidate, .01)

        config = ExperimentConfig(task="regression", model_type="official_mlp", official_profile="C",
            n_features=24, harness_enabled=True, training_preflight=True, candidate_feasibility=True,
            deployment_validation="future", max_tokens=1000, label_mode="provided")
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            with JsonlLogger(root/"events.jsonl", "test") as logger:
                controller = AdaptationController(config, "drift", Parent(), .01, 1., logger, Trainer(), root)
                with patch.object(controller, "_harness_decide"):
                    for source in range(7):
                        ids = np.arange(source*1000, (source+1)*1000)
                        features = np.zeros((1000, 24))
                        released = ReleasedLabels(ids, features, np.full(1000, 2.), np.full(1000, source))
                        controller.observe(PublicBatch(source+1, np.array([90000]), np.zeros((1, 24))),
                                           released, {int(i): 0. for i in ids})
                controller.llm_client = FixedClient("CALIBRATE_DOWN")
                controller._harness_decide(8, {"performance_drop": True, "diagnosis": "test"})
                self.assertEqual(calls, [(720, "head_only")])
                self.assertEqual(candidate.safety_margin, .5)
                self.assertIsNotNone(controller.pending)
                self.assertEqual(controller.gate.version, 0)
                spec = controller.pending["spec"]
                self.assertEqual(spec["calibration_source_step"], 5)
                self.assertEqual(spec["calibration_source_ids"], list(range(5952, 6000)))
                future = ReleasedLabels(np.arange(4), np.zeros((4,24)), np.full(4, 2.), np.full(4,9))
                # Insufficient independent future labels keep the candidate frozen.
                controller._validate_pending(future, 10)
                self.assertEqual(controller.gate.version, 0)
            events = [json.loads(line) for line in (root/"events.jsonl").read_text(encoding="utf-8").splitlines()]
        evaluated = next(row for row in events if row["event"] == "candidate_evaluated")
        self.assertEqual(evaluated["validation_loss"], 0.)
        self.assertEqual(evaluated["safety_margin"], .5)

    def test_controller_retains_prior_calibration_source_when_training_spans_sixteen_batches(self):
        from ite.data import PublicBatch, ReleasedLabels
        from ite.training import TrainingResult
        class Parent(ConstantModel):
            profile_type = "C"
            candidate_epochs = 5
            mean, std = np.zeros(24), np.ones(24)
        config = ExperimentConfig(task="regression", model_type="official_mlp", official_profile="C",
            n_features=24, harness_enabled=True, training_preflight=True, candidate_feasibility=True,
            deployment_validation="future", max_tokens=1000, label_mode="provided")
        with tempfile.TemporaryDirectory() as temporary, JsonlLogger(Path(temporary)/"events.jsonl", "test") as logger:
            trainer = unittest.mock.Mock()
            trainer.fit.return_value = TrainingResult("error", None, .01, "test-no-candidate")
            controller = AdaptationController(config, "drift", Parent(), .01, 1., logger, trainer, Path(temporary))
            with patch.object(controller, "_harness_decide"):
                for source in range(17):
                    ids = np.arange(source*48, (source+1)*48)
                    released = ReleasedLabels(ids, np.zeros((48,24)), np.full(48, 2.), np.full(48, source))
                    controller.observe(PublicBatch(source+1, np.array([90000]), np.zeros((1,24))),
                                       released, {int(i): 0. for i in ids})
            self.assertEqual(controller.history_steps.min(), 1)
            controller.llm_client = FixedClient("CALIBRATE_DOWN")
            controller._harness_decide(18, {"performance_drop": True, "diagnosis": "test"})
            self.assertEqual(trainer.fit.call_count, 1)
            self.assertEqual(len(trainer.fit.call_args.args[3]), 720)

    def test_calibration_cannot_use_legacy_same_window_deployment(self):
        class Parent(ConstantModel):
            profile_type = "C"
            candidate_epochs = 5
            mean, std = np.zeros(24), np.ones(24)
        config = ExperimentConfig(task="regression", model_type="official_mlp", official_profile="C",
                                  n_features=24, harness_enabled=False, deployment_validation="legacy")
        with tempfile.TemporaryDirectory() as temporary, JsonlLogger(Path(temporary)/"events.jsonl", "test") as logger:
            controller = AdaptationController(config, "drift", Parent(), .01, 1., logger,
                                               unittest.mock.Mock(), Path(temporary))
            with self.assertRaisesRegex(ValueError, "future"):
                controller._experiment(8, {}, trainable_policy="head_only", calibrate_down=True)

    def test_calibration_refuses_source_filter_that_shrinks_the_720_row_candidate(self):
        from ite.training import TrainingResult
        class Parent(ConstantModel):
            profile_type = "C"
            candidate_epochs = 5
            mean, std = np.zeros(24), np.ones(24)
        config = ExperimentConfig(task="regression", model_type="official_mlp", official_profile="C",
            n_features=24, harness_enabled=True, training_preflight=True, candidate_feasibility=True,
            deployment_validation="future", max_tokens=1000, label_mode="provided", train_source_window_batches=1)
        with tempfile.TemporaryDirectory() as temporary, JsonlLogger(Path(temporary)/"events.jsonl", "test") as logger:
            trainer = unittest.mock.Mock()
            trainer.fit.return_value = TrainingResult("error", None, .01, "test-no-candidate")
            controller = AdaptationController(config, "drift", Parent(), .01, 1., logger, trainer, Path(temporary))
            controller.history_x, controller.history_y = np.zeros((900,24)), np.full(900,2.)
            controller.history_steps = np.repeat(np.arange(9),100)
            controller._calibration_sources[0] = (np.zeros((48,24)), np.full(48,2.), np.arange(52,100))
            controller.llm_client = FixedClient("CALIBRATE_DOWN")
            controller._harness_decide(10, {"performance_drop": True, "diagnosis": "test"})
            trainer.fit.assert_not_called()

    def test_head_action_rejects_configs_that_expand_the_frozen_training_contract(self):
        from ite.official_model import OfficialModelAdapter
        from tests.test_official_head_only import RUNTIME
        if not RUNTIME.is_file():
            self.skipTest("official runtime not provisioned")
        parent = OfficialModelAdapter("regression", RUNTIME, profile_type="C")
        for change in ({"history_windows": [256, 512, 1024]}, {"official_candidate_epochs": 20},
                       {"min_validation": 64}, {"max_train_seconds": 21}):
            config = ExperimentConfig.from_dict({"task": "regression", "model_type": "official_mlp",
                "official_profile": "C", "n_features": 24, "official_runtime_python": str(RUNTIME),
                "harness_enabled": True, "training_preflight": True, "candidate_feasibility": True,
                "deployment_validation": "future", "max_tokens": 1000, "label_mode": "provided", **change})
            with self.subTest(change=change), tempfile.TemporaryDirectory() as tmp:
                with JsonlLogger(Path(tmp)/"events.jsonl", "test") as logger:
                    trainer = unittest.mock.Mock()
                    from ite.training import TrainingResult
                    trainer.fit.return_value = TrainingResult("error", None, .001, "test-no-candidate")
                    controller = AdaptationController(config, "drift", parent, .01, 1., logger, trainer, Path(tmp))
                    controller.history_x, controller.history_y = np.zeros((1200,24)), np.ones(1200)
                    controller.history_steps = np.repeat(np.arange(20),60)
                    controller.llm_client = FixedClient("RETRAIN_HEAD_ONLY")
                    controller._harness_decide(21, {"performance_drop": True, "diagnosis": "test"})
                    trainer.fit.assert_not_called()
                    self.assertIs(controller.gate.model, parent)
                events = [json.loads(line) for line in (Path(tmp)/"events.jsonl").read_text(encoding="utf-8").splitlines()]
                self.assertTrue(any(row.get("reason") == "official_head_profile_mismatch" for row in events))

    def test_replay_rejects_unrecognized_proposal_parameters_before_training(self):
        for extra in ({"epochs": 100}, {"lr": .1}, {"window": 2}):
            with self.subTest(extra=extra), tempfile.TemporaryDirectory() as tmp:
                trainer = unittest.mock.Mock(return_value=(ConstantModel(), .01))
                with self.assertRaises(ValueError):
                    replay_partition(replay_fixtures.OfficialSFTReplayTests().data(), list(range(96)),
                        "train", "stable", Path(tmp)/"run", ConstantModel(),
                        lambda _: {"action": "RETRAIN_HEAD_ONLY", "reason": "test", **extra},
                        decision_steps=(3,), trainer=trainer, action_profile="official_finetune")
                trainer.assert_not_called()

    def test_head_mock_disarms_on_initial_and_runtime_official_fallback(self):
        from ite.models import RidgeModel
        x = np.random.default_rng(8).normal(size=(24, 24))
        model = RidgeModel("regression").fit(x, np.arange(24.))
        config = ExperimentConfig.from_dict({"task": "regression", "model_type": "official_mlp",
            "official_profile": "C", "n_features": 24, "harness_enabled": True,
            "training_preflight": True, "candidate_feasibility": True, "deployment_validation": "future",
            "max_tokens": 1000, "label_mode": "provided", "harness_mock_mode": "head_only"})
        for active in ("tree", "ridge", "official_mlp"):
            with self.subTest(active=active), tempfile.TemporaryDirectory() as tmp:
                with JsonlLogger(Path(tmp)/"events.jsonl", "test") as logger:
                    controller = AdaptationController(config, "drift", model, .01, 1., logger,
                        unittest.mock.Mock(), Path(tmp), active_model_type=active)
                    if active == "official_mlp":
                        controller.activate_fallback(model, "ridge", .01, 7, "test", [])
                    self.assertEqual(controller.llm_client.mode, "normal")
                    self.assertEqual(controller.budget_guard.action_profile, "default")
                    raw = controller.llm_client.get_decision(observation()).raw_json
                    self.assertEqual(parse_action(raw).action, "RETRAIN_SMALL")
