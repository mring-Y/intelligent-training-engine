"""The PyTRiO boundary is single-shot, bounded and exposes server token usage."""

import json
import subprocess
import sys
import unittest
from pathlib import Path


def observation():
    return {"loss_trend": [{"source_step": 10, "loss": 0.25, "labeled_samples": 96}],
            "drift_alarm": True, "remaining_label_budget": None,
            "remaining_token_budget": 40000, "model_age_batches": 20}


class TrioLLMClientTests(unittest.TestCase):
    def test_default_worker_checks_tokenizer_lock_before_network_access(self):
        import tempfile
        from unittest.mock import patch
        from ite.trio_worker import SafeWorkerError, sample_chat
        with tempfile.TemporaryDirectory() as tmp:
            with patch("ite.tokenizer_assets.verify_tokenizer_provenance",
                       side_effect=ValueError("Tokenizer file hash mismatch")) as verify:
                with self.assertRaisesRegex(SafeWorkerError, "tokenizer_provenance"):
                    sample_chat({"model": "Qwen/Qwen3.5-4B", "tokenizer_path": tmp,
                                 "messages": [], "max_input_tokens": 1250, "max_output_tokens": 128},
                                token_provider=lambda: "unused")
                verify.assert_called_once_with(tmp, "Qwen/Qwen3.5-4B")

    def test_expired_deadline_does_not_send_after_tokenizer_loading(self):
        import time
        from ite.trio_worker import SafeWorkerError, sample_chat
        class Tokenizer:
            def apply_chat_template(self, *args, **kwargs):
                return "prompt"
            def encode(self, *args, **kwargs):
                return [1]
        class NeverHTTP:
            def post(self, *args, **kwargs):
                raise AssertionError("No request may start after deadline")
        with self.assertRaisesRegex(SafeWorkerError, "client_timeout"):
            sample_chat({"messages": [], "model": "Qwen/Qwen3.8-27B", "max_input_tokens": 2048,
                "max_output_tokens": 512, "deadline_monotonic": time.monotonic() - 1},
                tokenizer_loader=lambda _: Tokenizer(), http_client=NeverHTTP(), token_provider=lambda: "unused")

    def test_system_prompt_and_user_observation_use_separate_messages(self):
        from ite.trio_client import build_messages
        messages = build_messages(observation())
        self.assertEqual([item["role"] for item in messages], ["system", "user"])
        self.assertIn("工业模型漂移诊断专家", messages[0]["content"])
        self.assertIn('"remaining_label_budget":null', messages[1]["content"])
        self.assertNotIn("abrupt", json.dumps(messages, ensure_ascii=False))

    def test_few_shot_prompt_counts_under_input_budget_with_local_tokenizer(self):
        from transformers import AutoTokenizer
        from ite.harness import ACTION_SCHEMA
        from ite.trio_client import SYSTEM_PROMPT_BASE, build_messages

        tokenizer_path = Path(__file__).resolve().parents[1] / "deployment" / "tokenizer"
        tokenizer = AutoTokenizer.from_pretrained(
            str(tokenizer_path), local_files_only=True, trust_remote_code=False)
        value = observation()
        value["loss_trend"] = [
            {"source_step": step, "loss": .987, "labeled_samples": 96}
            for step in range(5)]
        messages = build_messages(value)
        baseline = [
            {"role": "system", "content": SYSTEM_PROMPT_BASE + "\nAction JSON Schema:\n" +
             json.dumps(ACTION_SCHEMA, ensure_ascii=False, separators=(",", ":"))},
            messages[1],
        ]
        render = lambda items: tokenizer.apply_chat_template(
            items, add_generation_prompt=True, tokenize=False, enable_thinking=False)
        baseline_tokens = len(tokenizer.encode(render(baseline), add_special_tokens=False))
        full_tokens = len(tokenizer.encode(render(messages), add_special_tokens=False))
        added_tokens = full_tokens - baseline_tokens
        self.assertIn("无法决定", messages[0]["content"])
        self.assertIn('"action":"DO_NOTHING"', messages[0]["content"])
        self.assertGreater(added_tokens, 0)
        self.assertLess(full_tokens, 2048)

    def test_successful_worker_reply_keeps_raw_json_and_separate_server_usage(self):
        from ite.trio_client import TrioLLMClient
        response = {"content": '{"action":"RETRAIN_SMALL","reason":"损失上升"}',
                    "input_tokens": 137, "output_tokens": 13, "finish_reason": "stop"}
        worker = [sys.executable, "-c", f"import sys; sys.stdin.read(); print({json.dumps(json.dumps(response))})"]
        reply = TrioLLMClient(worker_command=worker, timeout_seconds=5).get_decision(observation())
        self.assertEqual(reply.raw_json, response["content"])
        self.assertEqual((reply.usage_tokens, reply.input_tokens, reply.output_tokens), (150, 137, 13))
        self.assertEqual(reply.token_accounting_mode, "real")

    def test_worker_timeout_terminates_request_process(self):
        from ite.trio_client import TrioLLMClient
        worker = [sys.executable, "-c", "import time; time.sleep(30)"]
        client = TrioLLMClient(worker_command=worker, timeout_seconds=0.1)
        with self.assertRaises(TimeoutError):
            client.get_decision(observation())

    def test_reported_usage_above_reservation_is_preserved_for_guard_settlement(self):
        from ite.trio_client import TrioLLMClient
        response = {"content": '{"action":"DO_NOTHING","reason":"ok"}',
                    "input_tokens": 3000, "output_tokens": 600, "finish_reason": "stop"}
        worker = [sys.executable, "-c", f"import sys; sys.stdin.read(); print({json.dumps(json.dumps(response))})"]
        reply = TrioLLMClient(worker_command=worker, timeout_seconds=5).get_decision(observation())
        self.assertEqual((reply.input_tokens, reply.output_tokens), (3000, 600))

    def test_worker_error_never_returns_or_logs_credential_material(self):
        from ite.trio_client import TrioLLMClient
        worker = [sys.executable, "-c", "import sys; sys.stdin.read(); print('{\"error\":\"http_status\",\"status\":429}'); sys.exit(2)"]
        with self.assertRaisesRegex(RuntimeError, "http_status") as caught:
            TrioLLMClient(worker_command=worker, timeout_seconds=5).get_decision(observation())
        self.assertNotIn("api_key", str(caught.exception).lower())

    def test_client_rejects_malformed_worker_protocol(self):
        from ite.trio_client import TrioLLMClient
        for output in ("not-json", '{"content":"x","input_tokens":true,"output_tokens":1}'):
            with self.subTest(output=output):
                worker = [sys.executable, "-c", f"print({json.dumps(output)})"]
                with self.assertRaises(ValueError):
                    TrioLLMClient(worker_command=worker, timeout_seconds=5).get_decision(observation())

    def test_worker_posts_one_chat_request_with_hard_generation_limit_and_reports_usage(self):
        from ite.trio_worker import sample_chat

        class Tokenizer:
            def apply_chat_template(self, messages, **kwargs):
                self.messages = messages
                self.options = kwargs
                return "rendered system and user prompt without thinking"
            def encode(self, prompt, add_special_tokens):
                return [1, 2, 3]

        class Response:
            status_code = 200
            def json(self):
                return {"choices": [{"text": '{"action":"DO_NOTHING","reason":"ok"}',
                                     "finish_reason": "stop"}],
                        "usage": {"prompt_tokens": 3, "completion_tokens": 8}}

        class HTTPClient:
            def __init__(self):
                self.calls = []
            def post(self, url, *, headers, json):
                self.calls.append((url, headers, json))
                return Response()

        tokenizer, http = Tokenizer(), HTTPClient()
        result = sample_chat({"messages": [{"role": "system", "content": "strict"},
            {"role": "user", "content": "{}"}], "model": "Qwen/Qwen3.8-27B",
            "max_input_tokens": 2048, "max_output_tokens": 512},
            tokenizer_loader=lambda model: tokenizer, http_client=http,
            token_provider=lambda: "credential-never-logged")
        self.assertEqual(len(http.calls), 1)
        self.assertEqual(http.calls[0][0], "https://pytrio.com/api/openai/v1/completions")
        self.assertEqual(http.calls[0][2]["prompt"], "rendered system and user prompt without thinking")
        self.assertIs(tokenizer.options["enable_thinking"], False)
        self.assertEqual(http.calls[0][2]["max_tokens"], 512)
        self.assertEqual(http.calls[0][2]["temperature"], 0)
        self.assertNotIn("credential-never-logged", repr(result))
        self.assertEqual((result["input_tokens"], result["output_tokens"]), (3, 8))

    def test_worker_refuses_oversized_prompt_before_any_network_request(self):
        from ite.trio_worker import sample_chat

        class Tokenizer:
            def apply_chat_template(self, messages, **kwargs):
                return "rendered"
            def encode(self, prompt, add_special_tokens):
                return list(range(2049))

        class NeverHTTP:
            def post(self, *args, **kwargs):
                raise AssertionError("oversized prompt must fail before network access")

        with self.assertRaisesRegex(RuntimeError, "input_token_limit"):
            sample_chat({"messages": [{"role": "user", "content": "x"}],
                "model": "Qwen/Qwen3.8-27B", "max_input_tokens": 2048,
                "max_output_tokens": 512}, tokenizer_loader=lambda _: Tokenizer(),
                http_client=NeverHTTP(), token_provider=lambda: "unused")


if __name__ == "__main__":
    unittest.main()
