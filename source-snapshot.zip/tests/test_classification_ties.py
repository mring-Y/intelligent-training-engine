"""Selection contracts exercised through the real controller and future gate."""

import itertools
import copy
import json
import tempfile
import unittest
from contextlib import contextmanager
from pathlib import Path

import numpy as np

from ite.config import ExperimentConfig
from ite.controller import AdaptationController
from ite.data import ReleasedLabels
from ite.models import RidgeModel
from ite.tracking import JsonlLogger
from ite.training import TrainingResult


def linear_model(task, alpha, slope=1., intercept=.5):
    return RidgeModel.from_state({"task": task, "alpha": alpha, "family": "ridge",
        "mean": [0., 0.], "std": [1., 1.], "weights": [slope, 0.], "intercept": intercept})


class FixtureTrainer:
    """Replace worker execution only; predictions, selection and gating stay real."""
    def __init__(self, models=None, failed_alpha=None):
        self.models = models or {}
        self.failed_alpha = failed_alpha

    def fit(self, task, alpha, features, targets, timeout_seconds, **options):
        if alpha == self.failed_alpha:
            return TrainingResult("error", None, .001, "fixture worker failure")
        model = self.models.get((len(features), alpha))
        if model is None:
            model = linear_model(task, alpha, intercept=.5 if task == "classification" else 0.)
        return TrainingResult("ok", model, .001)


class ClassificationTieTests(unittest.TestCase):
    def config(self, **overrides):
        try:
            return ExperimentConfig.from_dict({"task": "classification", "n_features": 2,
                "n_batches": 96, "deployment_validation": "future", "selection_split": "recent_disjoint",
                "history_windows": [192, 384], "candidate_alphas": [.1, 10.],
                "training_preflight": True, "classification_tie_break": "alpha_desc", **overrides})
        except ValueError as error:
            self.fail(f"The approved tie policy must be configurable: {error}")

    @contextmanager
    def controller(self, models=None, failed_alpha=None, **overrides):
        cfg = self.config(**overrides)
        x = np.column_stack((np.tile([-2., -1., 1., 2.], 128), np.zeros(512)))
        y = (x[:, 0] > 0).astype(int) if cfg.task == "classification" else x[:, 0].copy()
        initial = linear_model(cfg.task, 1., slope=-1., intercept=.5 if cfg.task == "classification" else 0.)
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with JsonlLogger(root / "events.jsonl", "tie-test") as logger:
                c = AdaptationController(cfg, "drift", initial, .01, 1., logger,
                    FixtureTrainer(models, failed_alpha), root)
                c.history_x, c.history_y = x, y
                c.history_steps = np.repeat(np.arange(32), 16)
                yield c, root, x, y

    def events(self, root):
        return [json.loads(line) for line in (root / "events.jsonl").read_text().splitlines()]

    def test_policy_default_is_legacy_and_invalid_options_are_rejected(self):
        self.assertEqual(getattr(ExperimentConfig(), "classification_tie_break", None), "legacy")
        for mode in (None, True, 0, [], {}, "approximate", "ALPHA_DESC"):
            with self.subTest(mode=mode), self.assertRaises(ValueError):
                ExperimentConfig.from_dict({"classification_tie_break": mode})
        cfg = self.config()
        self.assertEqual(ExperimentConfig.from_dict(json.loads(json.dumps(cfg.to_dict()))), cfg)

    def test_candidate_order_permutations_select_same_alpha_and_fixed_window(self):
        # A first-wins comparator fails whenever the low alpha or large window is first.
        for windows in itertools.permutations((192, 384)):
            for alphas in itertools.permutations((.1, 10.)):
                with self.subTest(windows=windows, alphas=alphas), self.controller(
                        history_windows=windows, candidate_alphas=alphas) as (c, _, x, _):
                    c._experiment(34, {"diagnosis": "observed_prediction_degradation"})
                    self.assertIsNotNone(c.pending)
                    self.assertEqual(c.pending["spec"]["window"], 192)
                    self.assertEqual(c.pending["spec"]["alpha"], 10.)
                    self.assertEqual(c.pending["model"].alpha, 10.)
                    np.testing.assert_array_equal(c.pending["model"].predict(x), (x[:, 0] > 0).astype(int))

    def test_fewer_errors_always_beats_larger_alpha(self):
        bad = linear_model("classification", 10., slope=-1.)
        models = {(192, 10.): bad, (384, 10.): bad}
        with self.controller(models=models, candidate_alphas=[10., .1]) as (c, _, _, _):
            c._experiment(34, {"diagnosis": "observed_prediction_degradation"})
            self.assertEqual(c.pending["model"].alpha, .1)
            self.assertEqual(c.pending["spec"]["window"], 192)

    def test_failed_high_alpha_candidate_cannot_win(self):
        with self.controller(failed_alpha=10.) as (c, _, _, _):
            c._experiment(34, {"diagnosis": "observed_prediction_degradation"})
            self.assertEqual(c.pending["model"].alpha, .1)

    def test_disabled_policy_retains_original_first_winner(self):
        with self.controller(classification_tie_break="legacy", history_windows=[384, 192]) as (c, _, _, _):
            c._experiment(34, {"diagnosis": "observed_prediction_degradation"})
            self.assertEqual((c.pending["spec"]["window"], c.pending["model"].alpha), (384, .1))

    def test_regression_exact_ties_keep_first_winner_even_when_option_enabled(self):
        with self.controller(task="regression", history_windows=[384, 192], candidate_alphas=[.1, 10.]) as (c, _, _, _):
            c._experiment(34, {"diagnosis": "observed_prediction_degradation"})
            self.assertEqual((c.pending["spec"]["window"], c.pending["model"].alpha), (384, .1))

    def test_regression_near_ties_are_not_merged(self):
        models = {(w, a): linear_model("regression", a, slope=1. + (1e-9 if a == .1 else 2e-9), intercept=0.)
                  for w in (192, 384) for a in (.1, 10.)}
        with self.controller(task="regression", models=models, candidate_alphas=[10., .1]) as (c, _, _, _):
            c._experiment(34, {"diagnosis": "observed_prediction_degradation"})
            self.assertEqual(c.pending["model"].alpha, .1)

    def test_audit_identifies_legacy_and_final_winners_and_exact_tie_counts(self):
        with self.controller(history_windows=[384, 192]) as (c, root, _, _):
            c._experiment(34, {"diagnosis": "observed_prediction_degradation"})
            events = self.events(root)
            summaries = [e for e in events if e["event"] == "candidate_selection"]
            self.assertEqual(len(summaries), 1, "Every classification search needs a selection audit")
            event = summaries[0]
            self.assertEqual(event["policy"], "alpha_desc")
            self.assertEqual(event["best_error_count"], 0)
            self.assertEqual(event["best_tied_candidates"], 4)
            self.assertEqual(event["equal_error_comparisons"], 3)
            self.assertEqual((event["legacy_winner"]["window"], event["legacy_winner"]["alpha"]), (384, .1))
            self.assertEqual((event["selected_winner"]["window"], event["selected_winner"]["alpha"]), (192, 10.))
            self.assertEqual(event["decision_key"], ["validation_errors_asc", "alpha_desc", "window_asc"])
            self.assertEqual(event["reason"], "exact_error_tie_larger_alpha")
            candidates = [e for e in events if e["event"] == "candidate_evaluated"]
            self.assertEqual([e["validation_errors"] for e in candidates], [0, 0, 0, 0])

    def test_selected_candidate_waits_for_strictly_future_independent_labels(self):
        with self.controller() as (c, root, x, y):
            incumbent = c.gate.model
            c._experiment(34, {"diagnosis": "observed_prediction_degradation"})
            self.assertEqual(c.pending["model"].alpha, 10.)
            self.assertIs(c.gate.model, incumbent)
            for source in (33, 34):
                c._validate_pending(ReleasedLabels(np.arange(32), x[:32], y[:32], np.full(32, source)), 36)
                self.assertEqual(c.pending["y"], [])
                self.assertIs(c.gate.model, incumbent)
            c._validate_pending(ReleasedLabels(np.arange(32), x[:32], y[:32], np.full(32, 35)), 37)
            self.assertIsNone(c.pending)
            self.assertEqual(c.gate.model.alpha, 10.)
            deployed = next(e for e in self.events(root) if e["event"] == "deploy")
            self.assertGreater(deployed["gate_min_source_step"], deployed["frozen_at"])
            self.assertEqual(deployed["gate_samples"], 32)

    def test_independent_auditor_rejects_forged_counts_winner_and_fractional_errors(self):
        from scripts import analyze_recent_disjoint as audit
        verify = getattr(audit, "audit_classification_selection", None)
        self.assertTrue(callable(verify), "The independent selection auditor must be implemented")
        with self.controller() as (c, root, _, _):
            c._experiment(34, {"diagnosis": "observed_prediction_degradation"})
            events = self.events(root)
            candidates = [e for e in events if e["event"] == "candidate_evaluated"]
            summary = next(e for e in events if e["event"] == "candidate_selection")
            verify(candidates, summary, "alpha_desc", 48)
            for field, value in (("best_tied_candidates", 1), ("equal_error_comparisons", 0),
                                 ("reason", "legacy_first_minimum")):
                bad = copy.deepcopy(summary)
                bad[field] = value
                with self.subTest(field=field), self.assertRaises(ValueError):
                    verify(candidates, bad, "alpha_desc", 48)
            bad = copy.deepcopy(summary)
            bad["selected_winner"]["alpha"] = .1
            with self.assertRaises(ValueError):
                verify(candidates, bad, "alpha_desc", 48)
            bad_candidates = copy.deepcopy(candidates)
            bad_candidates[0]["validation_errors"] = .5
            with self.assertRaises(ValueError):
                verify(bad_candidates, summary, "alpha_desc", 48)

    def test_no_completed_candidates_records_empty_selection_and_keeps_model(self):
        with self.controller(candidate_alphas=[10.], failed_alpha=10.) as (c, root, _, _):
            original = c.gate.model
            c._experiment(34, {"diagnosis": "observed_prediction_degradation"})
            self.assertIs(c.gate.model, original)
            self.assertIsNone(c.pending)
            summary = next(e for e in self.events(root) if e["event"] == "candidate_selection")
            self.assertEqual(summary["candidates_completed"], 0)
            self.assertIsNone(summary["selected_winner"])
            self.assertEqual(summary["reason"], "no_completed_candidate")

    def test_matrix_configs_change_only_classification_tie_policy(self):
        root = Path(__file__).resolve().parents[1]
        names = ("optimization-classification-tie-control.json", "optimization-classification-tie-alpha.json")
        for name in names:
            self.assertTrue((root / "configs" / name).is_file(), "Approved paired configs must be preregistered")
        control, candidate = [ExperimentConfig.load(root / "configs" / name).to_dict() for name in names]
        self.assertEqual(control, ExperimentConfig.load(root / "configs/optimization-task-specific-split.json").to_dict())
        self.assertEqual(control.pop("classification_tie_break"), "legacy")
        self.assertEqual(candidate.pop("classification_tie_break"), "alpha_desc")
        self.assertEqual(control, candidate)

    def test_independent_pair_audit_rejects_extra_parameter_changes(self):
        from scripts import analyze_recent_disjoint as audit
        verify = getattr(audit, "audit_paired_configs", None)
        self.assertTrue(callable(verify))
        a = self.config(classification_tie_break="legacy").to_dict()
        b = self.config().to_dict()
        verify(a, b, "classification_tie_break")
        b["training_half_life_batches"] = 8.
        with self.assertRaises(ValueError):
            verify(a, b, "classification_tie_break")


if __name__ == "__main__":
    unittest.main()
