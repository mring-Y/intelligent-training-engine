import json
from dataclasses import replace
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from ite.decision_sft import encode_decision
from scripts.train_decision_sft import (
    TrainingConfig,
    build_datum,
    evaluate,
    execute,
    run_training,
)
from tests.test_decision_sft import FakeTokenizer, record


class FakeFuture:
    def __init__(self, value=None, error=None):
        self.value, self.error = value, error

    def result(self, timeout=None):
        if self.error:
            raise self.error
        return self.value


class FakeDatum:
    def __init__(self, model_input, loss_fn_inputs):
        self.model_input = model_input
        self.loss_fn_inputs = {k: SimpleNamespace(data=v) for k, v in loss_fn_inputs.items()}


class FakeSDK:
    ModelInput = SimpleNamespace(from_ints=lambda tokens: tokens)
    Datum = FakeDatum
    AdamParams = SimpleNamespace
    SamplingParams = SimpleNamespace


class FakeSampler:
    def __init__(self, fail=False):
        self.calls, self.fail = [], fail

    def sample(self, *, prompt, sampling_params, **kwargs):
        self.calls.append(prompt)
        if self.fail:
            return FakeFuture(error=TimeoutError("sampling deadline"))
        return FakeFuture({"input_tokens": len(prompt), "output_tokens": 1,
                           "prompt_logprobs": [-1.0] * len(prompt)})


class FakeTrainingClient:
    def __init__(self, fail_on=None):
        self.calls = []
        self.fail_on = fail_on

    def forward_backward(self, batch, loss_fn="cross_entropy", **kwargs):
        self.calls.append(("forward_backward", len(batch), loss_fn))
        if self.fail_on == len([c for c in self.calls if c[0] == "forward_backward"]):
            return FakeFuture(error=RuntimeError("provider training failure"))
        return FakeFuture({"metrics": {"loss": 0.5}, "loss_fn_outputs": [
            {"logprobs": SimpleNamespace(data=[-0.5] * len(d.model_input))} for d in batch]})

    def optim_step(self, params):
        self.calls.append(("optim_step", params.learning_rate))
        return FakeFuture({"step": len([c for c in self.calls if c[0] == "optim_step"])})

    def save_weights_for_sampler(self, name):
        self.calls.append(("save_weights_for_sampler", name))
        return FakeFuture(type("Saved", (), {"path": "trio://weights/final"})())

    def save_state(self, name):
        self.calls.append(("save_state", name))
        return FakeFuture(type("Saved", (), {"path": "trio://state/final"})())


class TrainingRunnerTests(unittest.TestCase):
    def _config(self, root, **changes):
        values = dict(
            train_path="train.jsonl", eval_path="eval.jsonl", train_sha256="train",
            eval_sha256="eval", output_dir=str(root / "run"), epochs=3, batch_size=16,
            max_seq_len=512, rank=8, learning_rate=0.0001, seed=7,
        )
        values.update(changes)
        return TrainingConfig(**values)

    def _write_dataset(self, root, rows=25):
        train = root / "train.jsonl"
        eval_path = root / "eval.jsonl"
        records = [record("DO_NOTHING" if i % 2 else "RETRAIN_LARGE") for i in range(rows)]
        train.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in records), encoding="utf-8")
        eval_path.write_text(json.dumps(records[0], ensure_ascii=False) + "\n", encoding="utf-8")
        return train, eval_path

    def test_build_datum_preserves_sparse_target_contract(self):
        tokenizer = FakeTokenizer()
        datum = build_datum(record("RETRAIN_LARGE"), tokenizer, max_seq_len=512, sdk=FakeSDK)
        self.assertEqual(datum.loss_fn_inputs["weights"].data.count(1.0), 1)
        self.assertEqual(datum.loss_fn_inputs["target_tokens"].data[datum.loss_fn_inputs["weights"].data.index(1.0)], 33)

    def test_all_rows_and_tail_batch_are_trained_once_per_epoch(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            train, evaluation = self._write_dataset(root, rows=25)
            config = self._config(root, train_path=str(train), eval_path=str(evaluation),
                                  train_sha256="ignored", eval_sha256="ignored")
            client = FakeTrainingClient()
            result = run_training(config, tokenizer=FakeTokenizer(), training_client=client,
                                  verify_hashes=False, sdk=FakeSDK)
            fwds = [c for c in client.calls if c[0] == "forward_backward"]
            self.assertEqual([c[1] for c in fwds], [16, 9] * 3)
            self.assertEqual(len([c for c in client.calls if c[0] == "optim_step"]), 6)
            self.assertEqual(result["global_steps"], 6)
            self.assertEqual(result["supervised_tokens"], 25 * 3)
            self.assertEqual(result["weights_path"], "trio://weights/final")

    def test_failure_stops_without_retry_or_saving_weights(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            train, evaluation = self._write_dataset(root, rows=3)
            client = FakeTrainingClient(fail_on=1)
            config = self._config(root, train_path=str(train), eval_path=str(evaluation),
                                  epochs=1, batch_size=16, train_sha256="ignored", eval_sha256="ignored")
            with self.assertRaisesRegex(RuntimeError, "provider training failure"):
                run_training(config, tokenizer=FakeTokenizer(), training_client=client,
                             verify_hashes=False, sdk=FakeSDK)
            self.assertEqual([c[0] for c in client.calls], ["forward_backward"])
    def test_hash_mismatch_fails_before_remote_client_is_used(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            train, evaluation = self._write_dataset(root, rows=1)
            config = self._config(root, train_path=str(train), eval_path=str(evaluation),
                                  train_sha256="wrong", eval_sha256="wrong")
            client = FakeTrainingClient()
            with self.assertRaisesRegex(ValueError, "sha256"):
                run_training(config, tokenizer=FakeTokenizer(), training_client=client,
                             verify_hashes=True, sdk=FakeSDK)
            self.assertEqual(client.calls, [])

    def test_unapproved_or_existing_claim_never_creates_service_client(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            config = self._config(root)
            calls = []
            factory = lambda: calls.append("service")
            with self.assertRaisesRegex(ValueError, "confirmed"):
                execute(config, approved=False, service_factory=factory)
            self.assertEqual(calls, [])
            state = root / "state"
            state.mkdir()
            (state / "run-claim.json").write_text('{}', encoding="utf-8")
            fixed = replace(TrainingConfig(), output_dir=str(root / "run"))
            with self.assertRaisesRegex(ValueError, "claim"):
                execute(fixed, approved=True, service_factory=factory, state_dir=state)
            self.assertEqual(calls, [])

    def test_approved_137_rows_produce_27_updates_and_411_supervised_positions(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            train, evaluation = self._write_dataset(root, rows=137)
            config = self._config(root, train_path=str(train), eval_path=str(evaluation))
            result = run_training(config, tokenizer=FakeTokenizer(), training_client=FakeTrainingClient(),
                                  verify_hashes=False, sdk=FakeSDK)
            rows = [json.loads(s) for s in (root / "run/train-metrics.jsonl").read_text(encoding="utf-8").splitlines()]
            self.assertEqual(result["global_steps"], 27)
            self.assertEqual(result["supervised_tokens"], 411)
            for epoch in (1, 2, 3):
                indices = [i for row in rows if row["epoch"] == epoch for i in row["row_indices"]]
                self.assertEqual(sorted(indices), list(range(137)))
                self.assertEqual([row["batch_rows"] for row in rows if row["epoch"] == epoch], [16] * 8 + [9])

    def test_eval_ignores_labels_and_only_reads_actual_candidate_logprobs(self):
        with tempfile.TemporaryDirectory() as temp:
            sampler = FakeSampler()
            rows = [record("DO_NOTHING"), record("RETRAIN_HEAD_ONLY")]
            result = evaluate(rows, tokenizer=FakeTokenizer(), sampler=sampler, sdk=FakeSDK,
                              output=Path(temp) / "predictions.jsonl", phase="base")
            self.assertEqual(len(sampler.calls), 6)
            self.assertEqual(sampler.calls[:3], sampler.calls[3:])
            self.assertEqual([row["action"] for row in result], ["DO_NOTHING"] * 2)

    def test_eval_failure_has_one_request_and_no_complete_prediction(self):
        with tempfile.TemporaryDirectory() as temp:
            sampler = FakeSampler(fail=True)
            with self.assertRaisesRegex(TimeoutError, "sampling deadline"):
                evaluate([record()], tokenizer=FakeTokenizer(), sampler=sampler, sdk=FakeSDK,
                         output=Path(temp) / "predictions.jsonl", phase="base")
            self.assertEqual(len(sampler.calls), 1)

    def test_missing_sample_usage_stops_and_keeps_full_reservation(self):
        from ite.decision_sft import BudgetLedger
        class MissingUsage(FakeSampler):
            def sample(self, **kwargs):
                self.calls.append(kwargs)
                return FakeFuture({"prompt_logprobs": []})
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            ledger = BudgetLedger(root / "ledger.json")
            sampler = MissingUsage()
            with self.assertRaisesRegex(ValueError, "usage"):
                evaluate([record()], tokenizer=FakeTokenizer(), sampler=sampler, sdk=FakeSDK,
                         output=root / "predictions.jsonl", phase="base", ledger=ledger)
            self.assertEqual(len(sampler.calls), 1)
            self.assertEqual(ledger.reserved_cny, "0.02")
            self.assertEqual(ledger.data["requests"]["base-000-0"]["state"], "unknown")

    def test_training_bad_loss_alignment_stops_before_optimizer(self):
        class BadLoss(FakeTrainingClient):
            def forward_backward(self, batch, loss_fn="cross_entropy", **kwargs):
                self.calls.append(("forward_backward",))
                return FakeFuture({"metrics": {}, "loss_fn_outputs": []})
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            train, evaluation = self._write_dataset(root, rows=2)
            config = self._config(root, train_path=str(train), eval_path=str(evaluation))
            client = BadLoss()
            with self.assertRaisesRegex(ValueError, "loss"):
                run_training(config, tokenizer=FakeTokenizer(), training_client=client,
                             verify_hashes=False, sdk=FakeSDK)
            self.assertEqual([c[0] for c in client.calls], ["forward_backward"])

