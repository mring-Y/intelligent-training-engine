import unittest

import numpy as np

from ite.config import ExperimentConfig
from ite.data import make_simulation
from ite.diagnostics import drift_diagnostics


class ExtendedSimulationTests(unittest.TestCase):
    def test_nonlinear_relationship_requires_a_nonlinear_predictor(self):
        config = ExperimentConfig.from_dict({"relationship": "nonlinear", "task": "regression",
                                            "initial_train": 2000, "initial_validation": 1000})
        initial = make_simulation(config).initial
        correlation = np.corrcoef(initial.train_x[:, 0] ** 2, initial.train_y)[0, 1]
        self.assertGreater(correlation, .6)
        self.assertLess(abs(np.corrcoef(initial.train_x[:, 0], initial.train_y)[0, 1]), .15)

    def test_class_threshold_produces_imbalanced_labels_without_exposing_targets(self):
        config = ExperimentConfig.from_dict({"class_threshold": 1.25, "initial_train": 4000})
        simulation = make_simulation(config)
        self.assertLess(simulation.initial.train_y.mean(), .15)
        self.assertGreater(simulation.initial.train_y.mean(), .05)
        self.assertFalse(hasattr(simulation.batches[0], "targets"))

    def test_sensor_outliers_are_reproducible_and_finite(self):
        config = ExperimentConfig.from_dict({"outlier_fraction": .1})
        left, right = make_simulation(config), make_simulation(config)
        np.testing.assert_array_equal(left.initial.train_x, right.initial.train_x)
        self.assertTrue(np.isfinite(left.initial.train_x).all())
        self.assertGreater(np.mean(np.max(abs(left.initial.train_x), axis=1) > 6), .05)

    def test_zero_drift_magnitude_preserves_stable_targets(self):
        changes = {"n_batches": 8, "drift_start": 1, "drift_magnitude": 0}
        stable = make_simulation(ExperimentConfig.from_dict({**changes, "scenario": "stable"}))
        abrupt = make_simulation(ExperimentConfig.from_dict({**changes, "scenario": "abrupt"}))
        predictions = [np.zeros(96) for _ in range(8)]
        self.assertEqual(stable.scorer.score(predictions), abrupt.scorer.score(predictions))

    def test_mixed_change_is_visible_only_to_offline_diagnostics(self):
        config = ExperimentConfig.from_dict({"scenario": "mixed", "n_batches": 8, "drift_start": 2})
        simulation = make_simulation(config)
        self.assertGreater(simulation.batches[3].features[:, 1].mean(), 2)
        diagnostics = drift_diagnostics(config, [0.] * 8, [4])
        self.assertEqual(diagnostics["drift_changes"], 1)
        self.assertEqual(diagnostics["mean_detection_delay_batches"], 2)


if __name__ == "__main__":
    unittest.main()
