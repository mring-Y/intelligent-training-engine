"""Fixed optional tree dependencies and a network-free delivery recipe."""

import hashlib
import json
import re
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class TreeDeliveryTests(unittest.TestCase):
    def test_tree_lock_pins_only_optional_dependencies_with_wheel_hashes(self):
        lock = ROOT / "requirements-tree.lock"
        self.assertTrue(lock.is_file(), "Tree dependencies must have a hash-locked file")
        lines = [line for line in lock.read_text(encoding="utf-8").splitlines()
                 if line and not line.startswith("#")]
        expected = {"scikit-learn": "1.7.2", "scipy": "1.16.3",
                    "joblib": "1.5.2", "threadpoolctl": "3.6.0"}
        parsed = {}
        for line in lines:
            match = re.fullmatch(r"([a-z-]+)==([0-9.]+)((?: --hash=sha256:[a-f0-9]{64})+)", line)
            self.assertIsNotNone(match, f"Unpinned or unhashed requirement: {line}")
            parsed[match[1]] = match[2]
        self.assertEqual(parsed, expected)
        self.assertIn("numpy==2.3.5", (ROOT / "requirements.txt").read_text())

    def test_wheel_manifest_covers_fixed_windows_and_linux_runtime(self):
        path = ROOT / "deployment/tree-wheel-manifest.json"
        self.assertTrue(path.is_file(), "Origin and hashes are required before offline installation")
        receipt = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(receipt["python_tag"], "cp312")
        self.assertEqual(receipt["existing_numpy"], "2.3.5")
        expected = {"scikit-learn", "scipy", "joblib", "threadpoolctl"}
        for platform in ("windows", "linux"):
            entries = receipt["platforms"][platform]
            self.assertEqual({e["package"] for e in entries}, expected)
            for entry in entries:
                self.assertTrue(entry["filename"].endswith(".whl"))
                self.assertTrue(entry["url"].startswith("https://files.pythonhosted.org/"))
                self.assertRegex(entry["sha256"], r"^[a-f0-9]{64}$")
                self.assertGreater(entry["bytes"], 0)
                line = next(line for line in (ROOT / "requirements-tree.lock").read_text().splitlines()
                            if line.startswith(entry["package"] + "=="))
                self.assertIn("==" + entry["version"] + " ", line)
                self.assertIn("--hash=sha256:" + entry["sha256"], line)

    def test_delivery_recipe_installs_only_fixed_local_wheels(self):
        path = ROOT / "scripts/Dockerfile.tree"
        self.assertTrue(path.is_file(), "Tree runtime needs a separate offline recipe")
        recipe = path.read_text(encoding="utf-8")
        for token in ("COPY --from=tree-wheels", "--no-index", "--no-deps", "--require-hashes",
                      "requirements-tree.lock", "ITE_SOURCE_SHA256", "source_metadata()"):
            self.assertIn(token, recipe)
        self.assertNotIn("-t ite-final:official-submit", recipe)

    def test_build_itself_checks_four_cpu_eight_gib_limits(self):
        recipe = (ROOT / "scripts/Dockerfile.tree").read_text(encoding="utf-8")
        for token in ("cpu.max", "memory.max", "400000 100000", "8589934592",
                      "tree-build-resource.json"):
            self.assertIn(token, recipe)


if __name__ == "__main__":
    unittest.main()
