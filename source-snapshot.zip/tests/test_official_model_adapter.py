"""Contracts for the isolated official CPU baseline backend."""

import unittest
import inspect
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

import numpy as np

from ite.config import ExperimentConfig
from ite.model_factory import load_model, make_model, model_from_state
from ite.official_model import OFFICIAL_A_CLASSES, default_package_path


ROOT = Path(__file__).resolve().parents[1]
PACKAGE = ROOT / "third_party" / "official_baselines" / "cpu-a-guide-20261110-v1.zip"
RUNTIME = Path(os.environ.get("ITE_OFFICIAL_RUNTIME_PYTHON",
    ROOT / ".venv-official-a" / "Scripts" / "python.exe"))


def _rows(member):
    with zipfile.ZipFile(PACKAGE) as archive:
        return [json.loads(line) for line in archive.read(member).decode("utf-8").splitlines() if line]


def _flatten(value):
    result = []
    def visit(item):
        if isinstance(item, dict):
            for key in sorted(item):
                visit(item[key])
        elif isinstance(item, list):
            for child in item:
                visit(child)
        else:
            result.append(float(item))
    visit(value)
    return result


def _official_options(checkpoint_path=None):
    return {"profile": "A", "runtime_python": str(RUNTIME), "package_path": str(PACKAGE),
            "checkpoint_path": str(checkpoint_path) if checkpoint_path else None,
            "classes": OFFICIAL_A_CLASSES, "class_labels": (1, 2, 3, 4, 5, 6), "candidate_epochs": 1}


class OfficialModelAdapterContractTests(unittest.TestCase):
    def test_config_accepts_only_explicit_official_gas_profile(self):
        try:
            config = ExperimentConfig.from_dict({
                "task": "classification",
                "model_type": "official",
                "n_features": 128,
                "official_profile": "A",
                "official_runtime_python": "isolated-python",
                "official_package_path": "baseline-a.zip",
                "official_checkpoint_path": "checkpoint.npz",
                "class_labels": [1, 2, 3, 4, 5, 6],
            })
        except (TypeError, ValueError) as error:
            self.fail(f"The explicit official A configuration must be accepted: {error}")

        self.assertEqual(config.model_type, "official")
        self.assertEqual(config.official_profile, "A")
        self.assertEqual(ExperimentConfig().model_type, "ridge")

    def test_model_factory_has_a_separate_official_adapter_option(self):
        self.assertIn("official_options", inspect.signature(make_model).parameters)
        self.assertEqual(make_model("classification", 1.0).family, "ridge")

    def test_official_mlp_config_accepts_b_and_c_regression_profiles(self):
        for profile, task, n_features in (("B", "regression", 34), ("C", "regression", 24)):
            with self.subTest(profile=profile):
                try:
                    config = ExperimentConfig.from_dict({
                        "task": task, "n_features": n_features, "model_type": "official_mlp",
                        "official_profile": profile, "official_runtime_python": "isolated-python",
                        "official_package_path": f"baseline-{profile}.zip",
                    })
                except Exception as error:
                    self.fail(f"Official profile {profile} config must be accepted: {error}")
                self.assertEqual(config.official_profile, profile)
                self.assertEqual(config.official_options()["profile_type"], profile)

    def test_official_mlp_profile_rejects_task_or_feature_mismatch(self):
        base = {"task": "regression", "n_features": 34, "model_type": "official_mlp",
                "official_profile": "B", "official_runtime_python": "isolated-python",
                "official_package_path": "baseline-B.zip"}
        with self.assertRaisesRegex(ValueError, "task|feature|profile"):
            ExperimentConfig.from_dict({**base, "n_features": 24})
        with self.assertRaisesRegex(ValueError, "task|feature|profile"):
            ExperimentConfig.from_dict({**base, "task": "classification"})

    def test_default_config_prefers_official_mlp_with_provider_profile_routing(self):
        config = ExperimentConfig.load(ROOT / "configs/default.json")
        self.assertEqual(config.model_type, "official_mlp")
        self.assertEqual(config.official_profile, "auto")


@unittest.skipUnless(PACKAGE.is_file() and RUNTIME.is_file(), "official A package/runtime is not provisioned")
class OfficialModelAdapterParityTests(unittest.TestCase):
    def test_c_down_calibration_uses_positive_residual_p90_and_persists_with_checkpoint(self):
        from ite.official_sft_data import load_public_package
        from ite.official_model import OfficialModelAdapter

        data = load_public_package("C")
        model = OfficialModelAdapter("regression", RUNTIME, profile_type="C")
        features = data["x"][:48]
        raw = model.predict_raw(features)
        targets = raw - np.arange(48, dtype=float)

        audit = model.calibrate_down(features, targets)

        self.assertEqual(audit["samples"], 48)
        self.assertEqual(audit["quantile"], 0.9)
        self.assertAlmostEqual(audit["safety_margin"], 42.3)
        np.testing.assert_allclose(model.predict(features), np.maximum(0., raw - 42.3), atol=1e-12, rtol=0)
        restored = model_from_state(model.state())
        self.assertAlmostEqual(restored.safety_margin, 42.3)
        np.testing.assert_array_equal(restored.predict(features), model.predict(features))
        with tempfile.TemporaryDirectory() as temporary:
            checkpoint = Path(temporary) / "deployed.npz"
            model.save(checkpoint)
            options = {"task": "regression", "profile_type": "C", "runtime_python": str(RUNTIME),
                       "package_path": str(default_package_path("C"))}
            loaded = load_model(checkpoint, model_type="official_mlp", official_options=options)
            self.assertAlmostEqual(loaded.safety_margin, 42.3)
            np.testing.assert_array_equal(loaded.predict(features), model.predict(features))
            sidecar = checkpoint.with_name(checkpoint.name + ".policy.json")
            values = json.loads(sidecar.read_text(encoding="utf-8"))
            self.assertEqual(values["checkpoint_sha256"], model.checkpoint_sha256)
            self.assertEqual(values["calibration"]["samples"], 48)
            # A policy from another checkpoint cannot silently change predictions.
            values["checkpoint_sha256"] = "0" * 64
            sidecar.write_text(json.dumps(values), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "checkpoint"):
                load_model(checkpoint, model_type="official_mlp", official_options=options)

        checkpoint_bytes = model.checkpoint_bytes
        model.calibrate_down(features, raw + 1.)
        self.assertEqual(model.safety_margin, 0.)
        self.assertEqual(model.checkpoint_bytes, checkpoint_bytes)
        np.testing.assert_array_equal(model.predict(features), raw)

    def test_down_calibration_rejects_non_c_profiles_and_invalid_residuals(self):
        from ite.official_model import OfficialModelAdapter
        from ite.official_sft_data import load_public_package

        data = load_public_package("C")
        c_model = OfficialModelAdapter("regression", RUNTIME, profile_type="C")
        with self.assertRaises(ValueError):
            c_model.calibrate_down(data["x"][:47], data["y"][:47])
        with self.assertRaises(ValueError):
            c_model.calibrate_down(data["x"][:48], data["y"][:47])
        gas = OfficialModelAdapter("classification", RUNTIME, profile_type="A")
        with self.assertRaises(ValueError):
            gas.calibrate_down(np.zeros((48, 128)), np.ones(48))

    def test_calibration_never_accumulates_margin_and_clamps_negative_rul(self):
        from ite.official_model import OfficialModelAdapter
        from ite.official_sft_data import load_public_package
        data = load_public_package("C")
        model = OfficialModelAdapter("regression", RUNTIME, profile_type="C")
        x = data["x"][:48]
        model.calibrate_down(x, np.zeros(48))
        first = model.safety_margin
        self.assertGreater(first, 0.)
        self.assertGreater(np.count_nonzero(model.predict(x) == 0.), 30)
        model.calibrate_down(x, np.zeros(48))
        self.assertEqual(model.safety_margin, first)
        state = model.state()
        with self.assertRaises(ValueError):
            model.calibrate_down(x, np.zeros(48), quantile=.5)
        self.assertEqual(model.state(), state)

    def test_forged_nonfinite_or_non_c_safety_state_is_rejected(self):
        from ite.official_model import OfficialModelAdapter
        model = OfficialModelAdapter("regression", RUNTIME, profile_type="C")
        for margin in (-1., float("nan"), float("inf"), True, "2.0"):
            with self.subTest(margin=margin), self.assertRaises(ValueError):
                model_from_state({**model.state(), "safety_margin": margin})
        gas = OfficialModelAdapter("classification", RUNTIME, profile_type="A")
        with self.assertRaises(ValueError):
            model_from_state({**gas.state(), "safety_margin": 1., "safety_calibration": {
                "samples": 48, "quantile": .9, "positive_residuals": 12}})

    def test_numpy_versions_are_isolated_and_checkpoint_state_is_bound(self):
        main_numpy_version = np.__version__
        model = make_model("classification", None, model_type="official", class_labels=[1, 2, 3, 4, 5, 6],
                           official_options=_official_options())
        self.assertEqual(model.runtime_numpy_version, "1.26.4")
        self.assertEqual(np.__version__, main_numpy_version)
        self.assertNotEqual(Path(model.runtime_python).resolve(), Path(sys.executable).resolve())
        restored = model_from_state(model.state())
        self.assertEqual(restored.checkpoint_sha256, model.checkpoint_sha256)
        self.assertEqual(restored.steps, model.steps)
        altered = model.state()
        altered["checkpoint_bytes"] = altered["checkpoint_bytes"][:-1] + b"x"
        with self.assertRaisesRegex(ValueError, "digest"):
            model_from_state(altered)

    def test_same_python_environment_is_rejected(self):
        options = _official_options()
        options["runtime_python"] = str(Path(sys.executable).resolve())
        with self.assertRaisesRegex(ValueError, "separate Python environment"):
            make_model("classification", None, model_type="official", class_labels=[1, 2, 3, 4, 5, 6],
                       official_options=options)

    def test_probabilities_match_the_packaged_predict_cli_exactly(self):
        rows = _rows("public/validation.jsonl")[:7]
        features = np.asarray([_flatten(row["inputs"]) for row in rows], dtype=np.float64)
        model = make_model("classification", None, model_type="official", class_labels=[1, 2, 3, 4, 5, 6],
                           official_options=_official_options())
        actual = model.predict_proba(features)
        with tempfile.TemporaryDirectory() as temporary:
            checkpoint = Path(temporary) / "checkpoint.npz"
            with zipfile.ZipFile(PACKAGE) as archive:
                checkpoint.write_bytes(archive.read("checkpoint.npz"))
                info = json.loads(archive.read("baseline-info.json"))
            self.assertEqual(hashlib.sha256(checkpoint.read_bytes()).hexdigest(),
                             info["checkpoint_sha256"].removeprefix("sha256:"))
            environment = os.environ.copy()
            environment["PYTHONPATH"] = str(PACKAGE) + os.pathsep + environment.get("PYTHONPATH", "")
            for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
                environment[key] = "1"
            requests = "".join(json.dumps({"task": "classification", "inputs": row["inputs"]}) + "\n"
                               for row in rows)
            completed = subprocess.run([str(RUNTIME), "-m", "baselines.predict", "--checkpoint", str(checkpoint)],
                input=requests, text=True, capture_output=True, env=environment, check=True)
        expected = np.asarray([[item["score"] for item in json.loads(line)["outputs"]]
                               for line in completed.stdout.splitlines()])
        np.testing.assert_array_equal(actual, expected)

    def test_resume_continuation_matches_official_cli_and_preserves_parent(self):
        train_rows = _rows("public/train.jsonl")[:16]
        validation_rows = _rows("public/validation.jsonl")[:12]
        x = np.asarray([_flatten(row["inputs"]) for row in train_rows], dtype=np.float64)
        y = np.asarray([OFFICIAL_A_CLASSES.index(row["answer"]) + 1 for row in train_rows], dtype=np.int64)
        model = make_model("classification", None, model_type="official", class_labels=[1, 2, 3, 4, 5, 6],
                           official_options=_official_options())
        parent = model.checkpoint_bytes
        parent_digest = model.checkpoint_sha256
        parent_steps = model.steps
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            vendor = root / "vendor"
            with zipfile.ZipFile(PACKAGE) as archive:
                archive.extractall(vendor)
            train_path, validation_path = root / "train.jsonl", root / "validation.jsonl"
            train_path.write_text("".join(json.dumps(row) + "\n" for row in train_rows), encoding="utf-8")
            validation_path.write_text("".join(json.dumps(row) + "\n" for row in validation_rows), encoding="utf-8")
            parent_path = root / "parent.npz"
            parent_path.write_bytes(parent)
            output = root / "official-round-1"
            environment = os.environ.copy()
            environment["BASELINE_CPU_THREADS"] = "1"
            cli = subprocess.run([str(RUNTIME), "-m", "baselines.train", "--profile", "A", "--train",
                str(train_path), "--validation", str(validation_path), "--resume", str(parent_path),
                "--epochs", "1", "--output", str(output), "--stage-id", "adapter-parity"],
                cwd=vendor, text=True, capture_output=True, env=environment, check=True)
            model.fit(x, y, epochs=1, timeout_seconds=5.0)
            expected_checkpoint = (output / "checkpoint.npz").read_bytes()

        self.assertEqual(model.checkpoint_bytes, expected_checkpoint)
        self.assertEqual(hashlib.sha256(parent).hexdigest(), parent_digest)
        self.assertEqual(model.steps, parent_steps + 1)


if __name__ == "__main__":
    unittest.main()
