"""Fixed engineering profile; success cannot be manufactured by counting selection rejects."""

import json
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

from ite.config import ExperimentConfig
from ite.data import make_simulation
from ite.models import RidgeModel
from ite.runner import run_policy
from ite.training import TrainingResult
from ite.trio_client import TrioLLMClient


class InlineFit:
    def fit(self, task, alpha, x, y, timeout_seconds, model_family="ridge", sample_weight=None):
        return TrainingResult("ok", RidgeModel(task, alpha, model_family).fit(x, y, sample_weight=sample_weight), .001)


def triple_config(**changes):
    return ExperimentConfig.from_dict(dict(scenario="triple_abrupt", n_batches=30, seed=7,
        harness_enabled=True, deployment_validation="future", training_preflight=True,
        candidate_feasibility=True, harness_drift_only=True, label_mode="provided",
        max_labels=0, max_llm_calls=5, max_llm_cost_cny="0.16", max_tokens=20000,
        llm_timeout_seconds=15, **changes))


class ThreeAbruptTests(unittest.TestCase):
    def test_paid_script_refuses_a_second_run_before_any_new_output(self):
        from ite.three_abrupt import run_three_abrupt
        import ite.three_abrupt as module
        with tempfile.TemporaryDirectory() as root:
            state = Path(root) / "durable"
            state.mkdir()
            (state / "run-claim.json").write_text("{}")
            path = Path(root) / "second"
            with patch.object(module, "PAID_STATE_ROOT", state), patch.object(module, "_validate_preflight"):
                with self.assertRaisesRegex(FileExistsError, "paid"):
                    run_three_abrupt(path, backend="pytrio", tokenizer_path="local-tokenizer")
            self.assertFalse(path.exists())

    def test_general_cli_cannot_run_triple_paid_profile_without_preflight(self):
        import contextlib
        import io
        from ite.cli import main
        with tempfile.TemporaryDirectory() as root:
            root = Path(root)
            config = triple_config(harness_backend="pytrio", llm_ledger_path=str(root / "ledger.json"))
            (root / "config.json").write_text(json.dumps(config.to_dict()))
            with contextlib.redirect_stderr(io.StringIO()):
                self.assertEqual(main(["run", "--config", str(root / "config.json"), "--policies", "drift",
                                       "--output", str(root / "real")]), 2)
            self.assertFalse((root / "real").exists())

    def test_runner_rejects_unclaimed_paid_profile_before_creating_output(self):
        with tempfile.TemporaryDirectory() as root:
            config = triple_config(harness_backend="pytrio", llm_ledger_path=str(Path(root) / "ledger.json"))
            with self.assertRaisesRegex(ValueError, "claim"):
                run_policy(config, "drift", Path(root) / "unclaimed", InlineFit())
            self.assertFalse((Path(root) / "unclaimed").exists())

    def test_paid_script_requires_matching_mock_evidence_before_creating_output(self):
        from ite.three_abrupt import run_three_abrupt
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "real"
            with self.assertRaisesRegex(ValueError, "preflight"):
                run_three_abrupt(path, backend="pytrio", tokenizer_path="local-tokenizer")
            self.assertFalse(path.exists())

    def test_fixed_stream_flips_target_relation_three_times_and_is_reproducible(self):
        config = triple_config()
        simulation = make_simulation(config)
        initial_model = RidgeModel("classification").fit(simulation.initial.train_x, simulation.initial.train_y)
        losses = simulation.scorer.score([initial_model.predict(b.features) for b in simulation.batches])
        self.assertEqual(len(losses), 30)
        for start, end, changed in ((0, 2, False), (2, 10, True), (10, 18, False), (18, 30, True)):
            self.assertLess(np.mean(losses[start:end]), .15) if not changed else self.assertGreater(np.mean(losses[start:end]), .85)
        other = make_simulation(config)
        np.testing.assert_array_equal(simulation.batches[-1].features, other.batches[-1].features)

    def test_fixed_profile_cannot_expand_paid_scope_or_call_cap(self):
        config = triple_config(harness_backend="pytrio", llm_ledger_path="ledger.json")
        self.assertEqual(config.n_batches, 30)
        for changes in ({"n_batches": 31}, {"seed": 19}, {"max_llm_calls": 6},
                        {"max_llm_calls": None}, {"max_llm_cost_cny": "0.17"}, {"max_tokens": 20001},
                        {"candidate_alphas": [999]}, {"history_windows": [96]}, {"min_gain": 0},
                        {"cooldown": 0}, {"drift_magnitude": 0}, {"selection_split": "recent_disjoint"}):
            values = config.to_dict() | changes
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                ExperimentConfig.from_dict(values)

    def test_default_deadline_is_fifteen_and_larger_or_nonfinite_values_are_rejected(self):
        self.assertEqual(TrioLLMClient().timeout_seconds, 15)
        self.assertEqual(ExperimentConfig().llm_timeout_seconds, 15)
        for value in (15.01, 60, float("inf"), float("nan"), True):
            with self.subTest(value=value), self.assertRaises(ValueError):
                TrioLLMClient(timeout_seconds=value)
            with self.subTest(config_value=value), self.assertRaises(ValueError):
                ExperimentConfig(llm_timeout_seconds=value)

    def test_mock_profile_has_three_linked_future_gate_chains_and_retains_selection_reject(self):
        from ite.iteration_audit import audit_iterations
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "mock"
            summary = run_policy(triple_config(), "drift", path, InlineFit())
            events = [json.loads(line) for line in (path / "events.jsonl").read_text(encoding="utf-8").splitlines()]
            audit = audit_iterations(events, expected_batches=30)
            self.assertEqual(summary["stream_batches"], 30)
            self.assertLessEqual(summary["llm_calls"], 5)
            self.assertGreaterEqual(audit["future_gate_chains"], 3)
            self.assertGreaterEqual(audit["selection_rejections"], 1)
            self.assertTrue(audit["engineering_target_met"])
            for event in events:
                if event["event"] == "harness_decision":
                    self.assertIn("decision_id", event)
                    self.assertIn("observation", event)
                if event["event"] == "candidate_frozen":
                    self.assertIn("attempt_id", event)
                    self.assertIn("decision_id", event)
            import copy
            for defect in ("reuse_selection_labels", "wrong_next_prediction", "duplicate_gate",
                           "too_few_labels", "same_decision_twice", "action_mismatch", "raw_action_mismatch",
                           "no_label_releases", "no_label_requests", "duplicate_label_releases", "no_completion"):
                broken = copy.deepcopy(events)
                outcome = next(e for e in broken if e["event"] == "deploy")
                if defect == "reuse_selection_labels":
                    outcome["gate_min_source_step"] = outcome["frozen_at"]
                elif defect == "wrong_next_prediction":
                    next(e for e in broken if e["event"] == "prediction" and e["step"] == outcome["step"] + 1)["model_version"] = -1
                elif defect == "duplicate_gate":
                    broken.append(outcome.copy())
                elif defect == "too_few_labels":
                    outcome["gate_samples"] = 1
                elif defect == "same_decision_twice":
                    other = next(e for e in broken if e["event"] == "candidate_frozen" and e["candidate_id"] != outcome["candidate_id"])
                    other["decision_id"] = outcome["decision_id"]
                elif defect == "action_mismatch":
                    next(e for e in broken if e["event"] == "harness_call")["parsed_action"]["action"] = "DO_NOTHING"
                elif defect == "raw_action_mismatch":
                    call = next(e for e in broken if e["event"] == "harness_call")
                    call["token_accounting_mode"] = "real"
                    call["raw_response"] = '{"action":"DO_NOTHING","reason":"mismatch"}'
                elif defect == "no_label_releases":
                    broken = [e for e in broken if e["event"] != "labels_released"]
                elif defect == "no_label_requests":
                    for e in broken:
                        if e["event"] == "labels_requested":
                            e["count"] = e["total"] = 0
                elif defect == "duplicate_label_releases":
                    i = next(i for i, e in enumerate(broken) if e["event"] == "labels_released")
                    broken.insert(i, broken[i].copy())
                elif defect == "no_completion":
                    broken = [e for e in broken if e["event"] != "run_completed"]
                with self.subTest(defect=defect), self.assertRaises(ValueError):
                    audit_iterations(broken, expected_batches=30)

    def test_timeout_latches_fallback_reaps_worker_and_runner_finishes_predictions(self):
        with tempfile.TemporaryDirectory() as root:
            real_config = triple_config(harness_backend="pytrio", llm_ledger_path=str(Path(root) / "ledger.json"))
            command = [sys.executable, "-c", "import time; time.sleep(30)"]
            real_popen = __import__("subprocess").Popen
            workers = []
            def record(*args, **kwargs):
                worker = real_popen(*args, **kwargs)
                if args[0] == command:
                    workers.append(worker)
                return worker
            client = TrioLLMClient(worker_command=command, timeout_seconds=.2)
            started = time.monotonic()
            with patch("ite.trio_client.subprocess.Popen", side_effect=record), patch("ite.trio_client.TrioLLMClient", return_value=client), patch("ite.three_abrupt.validate_paid_claim"):
                summary = run_policy(real_config, "drift", Path(root) / "timeout", InlineFit())
            self.assertLess(time.monotonic() - started, 10)
            self.assertEqual(summary["stream_batches"], 30)
            self.assertEqual(summary["harness_state"], "STATIC_FALLBACK")
            self.assertEqual(summary["harness_trip_reason"], "client_timeout")
            self.assertEqual(summary["llm_calls"], 1)
            self.assertEqual(summary["training_attempts"], 0)
            self.assertEqual(len(workers), 1)
            self.assertIsNotNone(workers[0].poll())
            events = [json.loads(line) for line in (Path(root) / "timeout/events.jsonl").read_text().splitlines()]
            trip_index = next(i for i, e in enumerate(events) if e["event"] == "budget_guard_tripped")
            self.assertFalse(any(e["event"] in ("harness_call", "candidate_frozen", "deploy", "experiment_started") for e in events[trip_index + 1:]))
            self.assertEqual(summary["llm_unknown_calls"], 1)
            self.assertGreater(summary["llm_reserved_tokens"], 0)


if __name__ == "__main__":
    unittest.main()
