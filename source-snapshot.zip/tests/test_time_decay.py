"""Behavioral coverage for the approved bounded-history exponential weighting."""

import json
import tempfile
import unittest
from contextlib import contextmanager
from pathlib import Path

import numpy as np

from ite.config import ExperimentConfig
from ite.controller import AdaptationController
from ite.data import PublicBatch, ReleasedLabels, make_simulation
from ite.models import RidgeModel, prediction_loss
from ite.runner import run_comparison
from ite.tracking import JsonlLogger
from ite.training import BoundedTrainer


def closed_form(x, y, weights, alpha, family="ridge", query=None):
    """Independent augmented normal equations; the intercept has zero penalty."""
    weights = np.asarray(weights, dtype=float)
    weights = weights / weights.max()
    weights = weights * (len(weights) / weights.sum())
    mean = np.average(x, axis=0, weights=weights)
    std = np.sqrt(np.average((x - mean) ** 2, axis=0, weights=weights))
    std = np.where(std < 1e-10, 1., std)

    def design(values):
        z = (values - mean) / std
        if family == "quadratic":
            z = np.column_stack((z, z ** 2, *[z[:, i] * z[:, j]
                for i in range(x.shape[1]) for j in range(i + 1, x.shape[1])]))
        return np.column_stack((z, np.ones(len(values))))

    a = design(x)
    penalty = np.eye(a.shape[1]) * alpha
    penalty[-1, -1] = 0
    coefficients = np.linalg.solve(a.T @ (weights[:, None] * a) + penalty,
                                   a.T @ (weights * y))
    return design(x if query is None else query) @ coefficients, mean, std


def decay_weights(steps, reference, half_life=4.):
    # Hand-specified source-age rule, independent of controller helpers.
    ages = reference - np.asarray(steps, dtype=float)
    with np.errstate(over="ignore", under="ignore"):
        weights = np.exp2(-(ages - ages.min()) / half_life)
    return weights * (len(weights) / weights.sum())


class WeightedRidgeTests(unittest.TestCase):
    def fixture(self):
        x = np.array([[-3., 2., 7.], [-1., -2., 7.], [0., 1., 7.],
                      [1., 3., 7.], [2., -1., 7.], [5., 2., 7.]])
        return x, np.array([8., -2., 1., 5., -3., 11.]), np.array([0., 1., 2., 1., 8., 3.])

    def test_weighted_fit_matches_independent_unpenalized_intercept_equations(self):
        x, y, weights = self.fixture()
        query = np.vstack((x, [[2.5, -.5, 7.]]))
        for family in ("ridge", "quadratic"):
            for task in ("regression", "classification"):
                with self.subTest(family=family, task=task):
                    targets = y if task == "regression" else (y > 2).astype(int)
                    want, mean, std = closed_form(x, targets, weights, 2.3, family, query)
                    model = RidgeModel(task, 2.3, family).fit(x, targets, sample_weight=weights)
                    np.testing.assert_allclose(model.mean, mean, atol=1e-13)
                    np.testing.assert_allclose(model.std, std, atol=1e-13)
                    np.testing.assert_allclose(model._scores(query), want, atol=1e-12)
                    self.assertAlmostEqual(model.intercept, np.average(targets, weights=weights))
                    self.assertEqual(model.std[-1], 1.)
                    if task == "classification":
                        np.testing.assert_array_equal(model.predict(query), want >= .5)
                        np.testing.assert_allclose(model.predict_proba(query)[:, 1], np.clip(want, 0, 1))

    def test_none_and_equal_weights_keep_legacy_state_exactly(self):
        x, y, _ = self.fixture()
        for family in ("ridge", "quadratic"):
            for task in ("regression", "classification"):
                targets = y if task == "regression" else (y > 2).astype(int)
                old = RidgeModel(task, 2.3, family).fit(x, targets)
                for weights in (None, np.ones(len(y)), np.full(len(y), 9.), np.full(len(y), 1e308)):
                    with self.subTest(family=family, task=task, weights=weights):
                        new = RidgeModel(task, 2.3, family).fit(x, targets, sample_weight=weights)
                        self.assertEqual(old.state(), new.state())

    def test_weight_scale_does_not_change_ridge_penalty_or_predictions(self):
        x, y, weights = self.fixture()
        first = RidgeModel("regression", 3., "quadratic").fit(x, y, sample_weight=weights)
        for scale in (1e-300, 1e300, 12.):
            with self.subTest(scale=scale):
                other = RidgeModel("regression", 3., "quadratic").fit(x, y, sample_weight=weights * scale)
                np.testing.assert_allclose(first.predict(x), other.predict(x), atol=1e-12)

    def test_invalid_weights_are_rejected_and_zero_weight_rows_are_allowed(self):
        x, y, valid = self.fixture()
        for weights in (1., np.ones((6, 1)), np.ones(5), np.zeros(6),
                        [1, 1, 1, -1, 1, 1], [1, 1, np.nan, 1, 1, 1],
                        [1, 1, np.inf, 1, 1, 1], [1, 1, -np.inf, 1, 1, 1]):
            with self.subTest(weights=weights), self.assertRaises(ValueError):
                RidgeModel("regression").fit(x, y, sample_weight=weights)
        model = RidgeModel("regression").fit(x, y, sample_weight=valid)
        self.assertTrue(np.isfinite(model.predict(x)).all())

    def test_weighted_quadratic_checkpoint_preserves_scores_and_old_state_loads(self):
        x, y, weights = self.fixture()
        with tempfile.TemporaryDirectory() as directory:
            model = RidgeModel("regression", 2., "quadratic").fit(x, y, sample_weight=weights)
            path = Path(directory) / "weighted.npz"
            model.save(path)
            np.testing.assert_array_equal(RidgeModel.load(path).predict(x), model.predict(x))
        old = RidgeModel("regression").fit(x, y)
        state = old.state()
        state.pop("family")
        state.pop("basis_mean")
        np.testing.assert_array_equal(RidgeModel.from_state(state).predict(x), old.predict(x))


class TimeDecayConfigTests(unittest.TestCase):
    def test_defaults_and_roundtrip_preserve_old_mode(self):
        config = ExperimentConfig()
        self.assertEqual(config.training_weighting, "none")
        self.assertEqual(config.training_half_life_batches, 4.)
        for mode in ("none", "exponential"):
            configured = ExperimentConfig(training_weighting=mode, training_half_life_batches=2.5)
            self.assertEqual(ExperimentConfig.from_dict(json.loads(json.dumps(configured.to_dict()))), configured)

    def test_weight_mode_half_life_and_mutually_exclusive_hard_window_are_strict(self):
        for mode in (True, None, "Exponential", "linear", 0, [], {}):
            with self.subTest(mode=mode), self.assertRaises(ValueError):
                ExperimentConfig.from_dict({"training_weighting": mode})
        for half_life in (True, False, 0, -1, None, "4", [], np.nan, np.inf):
            with self.subTest(half_life=half_life), self.assertRaises(ValueError):
                ExperimentConfig.from_dict({"training_half_life_batches": half_life})
        with self.assertRaises(ValueError):
            ExperimentConfig(training_weighting="exponential", train_source_window_batches=8)

    def test_candidate_config_changes_only_approved_temporal_evidence_mode(self):
        root = Path(__file__).resolve().parents[1]
        baseline = ExperimentConfig.load(root / "configs/optimization-training-preflight.json").to_dict()
        candidate = ExperimentConfig.load(root / "configs/optimization-time-decay.json").to_dict()
        self.assertEqual(baseline.pop("train_source_window_batches"), 8)
        self.assertEqual(candidate.pop("train_source_window_batches"), 0)
        self.assertEqual(baseline.pop("training_weighting"), "none")
        self.assertEqual(candidate.pop("training_weighting"), "exponential")
        self.assertTrue(candidate["training_preflight"])
        self.assertEqual(candidate["history_windows"], (192, 384, 768))
        self.assertEqual(candidate["training_half_life_batches"], 4.)
        self.assertEqual(candidate, baseline)


class TimeDecayControllerTests(unittest.TestCase):
    def config(self, **overrides):
        values = {"task": "regression", "n_features": 3, "n_batches": 96,
                  "deployment_validation": "future", "history_windows": [192],
                  "candidate_alphas": [1.], "training_preflight": True,
                  "min_gain": 0, "training_weighting": "exponential",
                  "training_half_life_batches": 4., **overrides}
        return ExperimentConfig.from_dict(values)

    @contextmanager
    def controller(self, steps=None, **overrides):
        steps = np.repeat(np.arange(16), 24) if steps is None else np.asarray(steps)
        rng = np.random.default_rng(904)
        x = rng.normal(size=(len(steps), 3))
        y = 2 * x[:, 0] - x[:, 1] + .04 * steps * x[:, 2]
        original = RidgeModel("regression").fit(x, -y)
        with tempfile.TemporaryDirectory() as directory, BoundedTrainer() as trainer:
            root = Path(directory)
            with JsonlLogger(root / "events.jsonl", "time-decay") as logger:
                controller = AdaptationController(self.config(**overrides), "periodic", original,
                                                  .01, 1, logger, trainer, root)
                controller.history_x, controller.history_y, controller.history_steps = x, y, steps
                yield controller, root, x, y

    def events(self, root):
        return [json.loads(line) for line in (root / "events.jsonl").read_text().splitlines()]

    def test_controller_weighted_prediction_matches_closed_form_not_unweighted_fit(self):
        # A behavioral assertion on existing controller/trainer, not a missing API.
        with self.controller() as (controller, root, x, y):
            controller._experiment(50, {"diagnosis": "performance"})
            self.assertIsNotNone(controller.pending)
            weights = decay_weights(np.repeat(np.arange(6, 14), 24), 15)
            want, _, _ = closed_form(x[144:336], y[144:336], weights, 1., query=x)
            np.testing.assert_allclose(controller.pending["model"].predict(x), want, atol=1e-12)

    def test_each_candidate_slice_uses_its_own_mean_one_weights_and_source_audit(self):
        with self.controller(history_windows=[192, 384, 768]) as (controller, root, x, y):
            controller._experiment(50, {"diagnosis": "performance"})
            events = self.events(root)
            candidates = [e for e in events if e["event"] == "candidate_evaluated"]
            self.assertEqual(len(candidates), 3)
            for event in candidates:
                size = min(event["window"], 336)
                lo = 336 - size
                steps = controller.history_steps[lo:336]
                weights = decay_weights(steps, 15)
                want, _, _ = closed_form(x[lo:336], y[lo:336], weights, 1., query=x[336:])
                self.assertAlmostEqual(event["validation_loss"], np.mean((y[336:] - want) ** 2))
                self.assertEqual(event["train_samples"], size)
                self.assertEqual(event["train_min_step"], int(steps.min()))
                self.assertEqual(event["train_max_step"], 13)
                self.assertEqual(event["training_weighting"], "exponential")
                self.assertEqual(event["weight_reference_source_step"], 15)
                self.assertEqual(event["training_half_life_batches"], 4.)
                self.assertAlmostEqual(event["weight_sum"], size)
                self.assertAlmostEqual(event["weight_min"], weights.min())
                self.assertAlmostEqual(event["weight_max"], weights.max())
                self.assertAlmostEqual(event["effective_sample_size"], weights.sum() ** 2 / (weights @ weights))
            started = next(e for e in events if e["event"] == "experiment_started")
            self.assertEqual(started["train_samples"], 336)
            self.assertIsNone(started["train_source_cutoff"])
            self.assertEqual(started["train_min_step"], 0)  # no old hard 8-batch cutoff
            self.assertEqual(started["validation_min_step"], 14)
            self.assertEqual(started["weight_reference_source_step"], 15)
            weights = decay_weights(controller.history_steps[:336], 15)
            self.assertAlmostEqual(started["effective_sample_size"], weights.sum() ** 2 / (weights @ weights))

    def test_half_life_changes_source_weights_and_extreme_ages_remain_finite(self):
        steps = np.r_[np.full(24, 0), np.full(24, 4), np.full(24, 8), np.full(48, 1000000)]
        for half_life in (2., 4., 1e-300, 5e-324):
            with self.subTest(half_life=half_life), self.controller(steps, training_half_life_batches=half_life) as (c, root, x, y):
                c._experiment(1000002, {"diagnosis": "performance"})
                self.assertIsNotNone(c.pending)
                event = next(e for e in self.events(root) if e["event"] == "candidate_evaluated")
                weights = decay_weights(steps[:72], 1000000, half_life)
                want, _, _ = closed_form(x[:72], y[:72], weights, 1., query=x)
                np.testing.assert_allclose(c.pending["model"].predict(x), want, atol=1e-8)
                self.assertTrue(np.isfinite(event["weight_min"]))
                self.assertAlmostEqual(event["weight_sum"], 72.)

    def test_selection_sources_never_train_and_future_gate_requires_sources_after_freeze(self):
        with self.controller() as (c, root, x, y):
            original = c.gate.model
            c._experiment(50, {"diagnosis": "performance"})
            self.assertIs(c.gate.model, original)
            pending_scores = c.pending["model"].predict(x)
            for source, clock in ((15, 52), (50, 53)):
                c._validate_pending(ReleasedLabels(np.arange(48), x[-48:], y[-48:], np.full(48, source)), clock)
                self.assertEqual(c.pending["y"], [])
                self.assertIs(c.gate.model, original)
                np.testing.assert_array_equal(c.pending["model"].predict(x), pending_scores)
            c._validate_pending(ReleasedLabels(np.arange(48), x[-48:], y[-48:], np.full(48, 51)), 54)
            self.assertEqual(c.gate.updates, 1)
            np.testing.assert_array_equal(RidgeModel.load(root / "deployed.npz").predict(x), c.predict(x))
            deploy = next(e for e in self.events(root) if e["event"] == "deploy")
            self.assertEqual((deploy["gate_min_source_step"], deploy["gate_max_source_step"]), (51, 51))

    def test_selection_values_cannot_change_training_and_validation_loss_is_unweighted(self):
        states = []
        for extreme in (False, True):
            with self.controller() as (c, root, x, y):
                if extreme:
                    c.history_x[336:] += 1000
                    c.history_y[336:] += 1000
                c._experiment(50, {"diagnosis": "performance"})
                # Candidate is saved in pending only if selection improves the old model.
                self.assertIsNotNone(c.pending)
                states.append(c.pending["model"].state())
                event = next(e for e in self.events(root) if e["event"] == "candidate_evaluated")
                self.assertAlmostEqual(event["validation_loss"], prediction_loss("regression", y[336:], c.pending["model"].predict(x[336:])))
        self.assertEqual(states[0], states[1])

    def test_raw_sixteen_floor_is_preserved_and_ess_is_only_an_audit(self):
        for count in (0, 15, 16):
            # Sixteen labels with ESS near one must train; no implicit ESS gate.
            steps = np.r_[np.arange(count), np.full(48, count)]
            with self.subTest(count=count), self.controller(steps, training_half_life_batches=.01) as (c, root, x, _):
                before, last = c.predict(x), c.last_experiment
                c._experiment(50, {"diagnosis": "performance"})
                np.testing.assert_array_equal(c.predict(x), before)
                self.assertEqual(c.budget.experiments, int(count == 16))
                self.assertEqual(c.budget.training_attempts, int(count == 16))
                if count < 16:
                    self.assertEqual(c.last_experiment, last)
                    self.assertEqual(c.cooldown_until, 0)
                    self.assertEqual(c.budget.train_seconds, 0)
                    self.assertIsNone(c.pending)
                else:
                    event = next(e for e in self.events(root) if e["event"] == "candidate_evaluated")
                    self.assertEqual(event["status"], "ok")
                    self.assertLess(event["effective_sample_size"], 1.01)

    def test_online_history_retains_only_bounded_released_labels(self):
        with self.controller(history_windows=[192, 384, 768]) as (c, root, _, _):
            c.policy = "static"  # real observation without fitting any model
            c.history_x, c.history_y, c.history_steps = np.empty((0, 3)), np.empty(0), np.empty(0, dtype=int)
            for step in range(40):
                x = np.tile([1., 0., 0.], (24, 1))
                ids = np.arange(step * 24, (step + 1) * 24)
                released = ReleasedLabels(ids, x, np.ones(24), np.full(24, step))
                predictions = dict(zip(map(int, ids), c.predict(x)))
                c.observe(PublicBatch(step + 2, ids, x), released, predictions)
                self.assertLessEqual(len(c.history_y), 768)
            self.assertEqual(len(c.history_y), 768)
            self.assertEqual((c.history_steps.min(), c.history_steps.max()), (8, 39))

    def test_none_mode_uses_original_unweighted_fit_and_source_window(self):
        with self.controller(training_weighting="none", train_source_window_batches=8) as (c, root, x, y):
            c._experiment(50, {"diagnosis": "performance"})
            want = RidgeModel("regression").fit(x[192:336], y[192:336])
            np.testing.assert_array_equal(c.pending["model"].predict(x), want.predict(x))
            event = next(e for e in self.events(root) if e["event"] == "candidate_evaluated")
            self.assertEqual(event["training_weighting"], "none")
            self.assertEqual(event["effective_sample_size"], 144)


class WeightedWorkerAndRunnerTests(unittest.TestCase):
    def test_worker_transmits_weights_for_both_model_families(self):
        rng = np.random.default_rng(905)
        x = rng.normal(size=(64, 3))
        y = x[:, 0] * x[:, 1] + x[:, 2]
        weights = np.linspace(.01, 4, len(y))
        with BoundedTrainer() as trainer:
            for family in ("ridge", "quadratic"):
                with self.subTest(family=family):
                    result = trainer.fit("regression", 2., x, y, 8., model_family=family, sample_weight=weights)
                    self.assertEqual(result.status, "ok", result.error)
                    want, _, _ = closed_form(x, y, weights, 2., family)
                    np.testing.assert_allclose(result.model.predict(x), want, atol=1e-12)

    def test_weighted_worker_timeout_error_and_recovery_preserve_legacy_calls(self):
        x = np.arange(80, dtype=float).reshape(40, 2)
        y = x[:, 0] / 10
        weights = np.linspace(.01, 3, 40)
        with BoundedTrainer() as trainer:
            exhausted = trainer.fit("regression", 1., x, y, 0, sample_weight=weights)
            self.assertEqual(exhausted.status, "budget_exhausted")
            timeout = trainer.fit("regression", 1., x, y, 1e-6, sample_weight=weights)
            self.assertEqual(timeout.status, "timeout")
            self.assertIsNone(timeout.model)
            failed = trainer.fit("regression", 1., x, y, 8, sample_weight=np.zeros(40))
            self.assertEqual(failed.status, "error")
            self.assertIsNone(failed.model)
            recovered = trainer.fit("regression", 1., x, y, 8, sample_weight=weights)
            self.assertEqual(recovered.status, "ok")
            want, _, _ = closed_form(x, y, weights, 1.)
            np.testing.assert_allclose(recovered.model.predict(x), want)
            legacy = trainer.fit("regression", 1., x, y, 8)
            self.assertEqual(legacy.status, "ok")
            self.assertEqual(legacy.model.state(), RidgeModel("regression").fit(x, y).state())

    def test_delayed_stream_summary_ess_audit_and_checkpoint_prediction_timing(self):
        config = ExperimentConfig(task="regression", n_features=3, n_batches=18, drift_start=0,
            deployment_validation="future", training_preflight=True, training_weighting="exponential",
            history_windows=(192,), candidate_alphas=(1.,), update_interval=4, cooldown=0, min_gain=0)
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            result = run_comparison(config, root, policies=("periodic", "static"))[0]
            events = [json.loads(line) for line in (root / "periodic/events.jsonl").read_text().splitlines()]
            candidates = [e for e in events if e["event"] == "candidate_evaluated"]
            self.assertGreater(len(candidates), 0)
            self.assertEqual(result["training_weighting"], "exponential")
            self.assertEqual(result["training_half_life_batches"], 4.)
            self.assertEqual(result["training_ess_audit_count"], len(candidates))
            self.assertAlmostEqual(result["training_ess_min"], min(e["effective_sample_size"] for e in candidates))
            self.assertAlmostEqual(result["training_ess_mean"], np.mean([e["effective_sample_size"] for e in candidates]))
            self.assertAlmostEqual(result["training_ess_max"], max(e["effective_sample_size"] for e in candidates))
            self.assertGreater(result["updates"], 0)
            self.assertLessEqual(result["peak_label_history"], 768)
            self.assertEqual(result["labels_unreleased"], 48)
            self.assertLessEqual(result["labels_requested"], config.max_labels)
            simulation = make_simulation(config)
            versions = [e["model_version"] for e in events if e["event"] == "prediction"]
            with np.load(root / "periodic/predictions.npz", allow_pickle=False) as saved:
                for batch, version, prediction in zip(simulation.batches, versions, saved["predictions"]):
                    checkpoint = f"model-v{version}.npz" if version else "initial.npz"
                    np.testing.assert_array_equal(RidgeModel.load(root / "periodic" / checkpoint).predict(batch.features), prediction)
            for event in events:
                if event["event"] == "deploy":
                    self.assertGreater(event["gate_min_source_step"], event["frozen_at"])
                    self.assertLessEqual(event["gate_max_source_step"] + 2, event["step"])
                    self.assertEqual(versions[event["step"] + 1], event["model_version"])
            static = json.loads((root / "static/summary.json").read_text())
            self.assertEqual(static["training_ess_audit_count"], 0)
            self.assertIsNone(static["training_ess_min"])

    def test_weighting_cannot_change_initial_static_model_predictions(self):
        predictions = []
        for mode in ("none", "exponential"):
            with tempfile.TemporaryDirectory() as directory:
                config = ExperimentConfig(n_batches=4, training_weighting=mode)
                run_comparison(config, directory, policies=("static",))
                with np.load(Path(directory) / "static/predictions.npz", allow_pickle=False) as saved:
                    predictions.append(saved["predictions"].copy())
        np.testing.assert_array_equal(*predictions)


if __name__ == "__main__":
    unittest.main()
