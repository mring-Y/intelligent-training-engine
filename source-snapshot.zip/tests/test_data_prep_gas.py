import csv
import importlib
import tempfile
import unittest
from pathlib import Path

import pyarrow.parquet as pq

try:
    gas = importlib.import_module("scripts.data_prep.gas")
except ImportError:
    gas = None


class GasPreparationTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(gas, "Six-class temporal Gas preparation is not implemented")
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.source = self.root / "source"
        self.source.mkdir()
        for batch in (1, 2, 3):
            lines = [f"{label} 1:{batch * 100 + label + i / 100} 128:{label}\n"
                     for label in range(1, 7) for i in range(10)]
            (self.source / f"batch{batch}.dat").write_text("".join(lines))

    def test_six_classes_and_source_time_batches_survive_export(self):
        manifest = gas.prepare_gas(self.source, self.root / "package", expected_batches=3)
        self.assertEqual(manifest["task"], "multiclass")
        self.assertEqual(len(manifest["column_mapping"]["features"]), 128)
        with (self.root / "package/train.csv").open() as stream:
            train = list(csv.DictReader(stream))
        with (self.root / "package/val.csv").open() as stream:
            validation = list(csv.DictReader(stream))
        online = pq.read_table(self.root / "package/test_stream.parquet").to_pylist()
        self.assertEqual(set(float(r["target"]) for r in train), {1, 2, 3, 4, 5, 6})
        self.assertEqual(set(float(r["target"]) for r in validation), {1, 2, 3, 4, 5, 6})
        self.assertEqual(set(int(r["source_batch"]) for r in train + validation), {1})
        self.assertEqual([r["batch_id"] for r in online], [0] * 60 + [1] * 60)
        self.assertEqual(set(r["source_batch"] for r in online), {2, 3})
        self.assertFalse(set(r["source_row"] for r in train) & set(r["source_row"] for r in validation))

    def test_unknown_classes_duplicate_indices_and_future_initial_data_fail(self):
        for malformed in ("7 1:2\n", "1 1:2 1:3\n", "1 129:2\n"):
            (self.source / "batch2.dat").write_text(malformed)
            with self.subTest(malformed=malformed), self.assertRaises(ValueError):
                gas.prepare_gas(self.source, self.root / "bad", expected_batches=3)

    def test_canonical_gas_package_requires_all_ten_source_batches(self):
        with self.assertRaises(ValueError):
            gas.prepare_gas(self.source, self.root / "incomplete")
        self.assertFalse((self.root / "incomplete").exists())

    def test_empty_source_batch_cannot_disappear_from_temporal_stream(self):
        (self.source / "batch2.dat").write_text("")
        with self.assertRaises(ValueError):
            gas.prepare_gas(self.source, self.root / "empty", expected_batches=3)


if __name__ == "__main__":
    unittest.main()
