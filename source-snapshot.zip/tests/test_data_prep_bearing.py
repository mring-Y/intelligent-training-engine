"""Whole-bearing partition, recorded-time RUL and waveform-tail contract."""
import csv
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np
import pyarrow.parquet as pq


def write_capture(path, values):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["Horizontal_vibration_signals", "Vertical_vibration_signals"])
        writer.writerows(values)


class BearingPreparationTests(unittest.TestCase):
    def prepare(self, source, output, *, captures=4, bearings=(1, 2, 3, 4, 5), **options):
        from scripts.data_prep.bearing import prepare_bearing

        return prepare_bearing(source, output, sample_rate=8, expected_capture_samples=10,
                               expected_capture_counts={f"Bearing1_{b}": captures for b in bearings}, **options)

    def make_source(self, root, bearings=(1, 2, 3, 4, 5), captures=4):
        for bearing in bearings:
            for capture in range(1, captures + 1):
                values = np.column_stack((np.full(10, bearing), np.full(10, bearing + 1)))
                write_capture(root / "35Hz12kN" / f"Bearing1_{bearing}" / f"{capture}.csv", values)

    def test_whole_lifecycles_seconds_to_last_window_and_tail_audit(self):
        from scripts.data_prep.bearing import prepare_bearing

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.make_source(root / "raw")
            manifest = self.prepare(root / "raw", root / "prepared")
            with (root / "prepared" / "train.csv").open(newline="") as handle:
                train = list(csv.DictReader(handle))
            with (root / "prepared" / "val.csv").open(newline="") as handle:
                val = list(csv.DictReader(handle))
            stream = pq.read_table(root / "prepared" / "test_stream.parquet").to_pylist()
            self.assertEqual(len(train), 12)
            self.assertEqual(len(val), 4)
            self.assertEqual(len(stream), 4)
            self.assertEqual({row["bearing_id"] for row in train}, {"Bearing1_1", "Bearing1_2", "Bearing1_3"})
            self.assertEqual({row["bearing_id"] for row in val}, {"Bearing1_4"})
            self.assertEqual({row["bearing_id"] for row in stream}, {"Bearing1_5"})
            self.assertEqual([float(row["target"]) for row in stream], [180., 120., 60., 0.])
            self.assertNotIn("capture_index", manifest["column_mapping"]["features"])
            self.assertNotIn("bearing_id", manifest["column_mapping"]["features"])
            audit = manifest["metadata"]["window_audit"]
            self.assertEqual(audit["dropped_tail_samples"], 40)
            self.assertEqual(audit["capture_files"], 20)
            self.assertEqual(manifest["metadata"]["target_unit"], "seconds")

    def test_explicit_three_bearing_partition_is_fixed_and_disjoint(self):
        from scripts.data_prep.bearing import prepare_bearing

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.make_source(root / "raw", bearings=(1, 2, 3))
            result = self.prepare(root / "raw", root / "out", bearings=(1, 2, 3),
                                     train_bearings=["Bearing1_1"], val_bearings=["Bearing1_2"], stream_bearings=["Bearing1_3"])
            self.assertEqual(result["metadata"]["split_bearings"], {
                "train": ["Bearing1_1"], "val": ["Bearing1_2"], "stream": ["Bearing1_3"]})
            with self.assertRaises(ValueError):
                self.prepare(root / "raw", root / "bad", bearings=(1, 2, 3),
                                train_bearings=["Bearing1_1"], val_bearings=["Bearing1_1"], stream_bearings=["Bearing1_3"])

    def test_acquisition_gaps_are_rejected_instead_of_shortening_rul(self):
        from scripts.data_prep.bearing import prepare_bearing

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.make_source(root / "raw")
            (root / "raw" / "35Hz12kN" / "Bearing1_5" / "2.csv").unlink()
            with self.assertRaisesRegex(ValueError, "contiguous"):
                self.prepare(root / "raw", root / "out")

    def test_invalid_waveform_window_is_counted_and_keeps_recorded_endpoint(self):
        from scripts.data_prep.bearing import prepare_bearing

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.make_source(root / "raw", captures=5)
            values = np.column_stack((np.full(10, 5.), np.full(10, 6.)))
            values[0, 0] = np.nan
            write_capture(root / "raw" / "35Hz12kN" / "Bearing1_5" / "2.csv", values)
            result = self.prepare(root / "raw", root / "out", captures=5)
            stream = pq.read_table(root / "out" / "test_stream.parquet").to_pylist()
            self.assertEqual([row["target"] for row in stream], [240., 120., 60., 0.])
            self.assertEqual(result["metadata"]["window_audit"]["invalid_windows_dropped"], 1)

    def test_overwrite_and_undocumented_capture_shape_are_rejected(self):
        from scripts.data_prep.bearing import prepare_bearing

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.make_source(root / "raw")
            with self.assertRaisesRegex(ValueError, "samples"):
                prepare_bearing(root / "raw", root / "out", sample_rate=8, expected_capture_samples=11,
                                expected_capture_counts={f"Bearing1_{b}": 4 for b in range(1, 6)})
            occupied = root / "occupied"
            occupied.mkdir()
            (occupied / "keep.txt").write_text("original")
            with self.assertRaises((ValueError, FileExistsError)):
                self.prepare(root / "raw", occupied)
            self.assertEqual((occupied / "keep.txt").read_text(), "original")

    def test_contiguous_but_truncated_lifecycle_is_not_a_complete_bearing(self):
        from scripts.data_prep.bearing import prepare_bearing

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.make_source(root / "raw")
            with self.assertRaisesRegex(ValueError, "complete"):
                prepare_bearing(root / "raw", root / "out", sample_rate=8, expected_capture_samples=10)

    def test_mirror_source_receipt_is_carried_into_prepared_provenance(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.make_source(root / "raw")
            capture = root / "raw" / "35Hz12kN" / "Bearing1_1" / "1.csv"
            content = capture.read_bytes()
            receipt = {"url": "https://public.example/mirror/1.csv", "bytes": len(content),
                       "sha256": hashlib.sha256(content).hexdigest()}
            capture.with_suffix(".csv.source.json").write_text(json.dumps(receipt), encoding="utf-8")
            result = self.prepare(root / "raw", root / "out")
            origin = result["metadata"]["source_files"][0]
            self.assertEqual(origin["acquisition_url"], "https://public.example/mirror/1.csv")
            self.assertEqual(len(origin["acquisition_receipt_sha256"]), 64)
            receipt["sha256"] = "0" * 64
            capture.with_suffix(".csv.source.json").write_text(json.dumps(receipt), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "receipt"):
                self.prepare(root / "raw", root / "untrusted")


if __name__ == "__main__":
    unittest.main()
