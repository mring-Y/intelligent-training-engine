"""The guard must prevent work, settle failures and latch before side effects."""

import unittest

from ite.budget import ResourceBudget
from ite.config import ExperimentConfig
from ite.harness import LLMReply, MockLLMClient


class EventLog:
    def __init__(self):
        self.events = []

    def event(self, event, step, **values):
        self.events.append({"event": event, "step": step, **values})


class ReplyClient:
    def __init__(self, reply=None, error=None):
        self.reply, self.error, self.calls = reply, error, 0

    def get_decision(self, observation):
        self.calls += 1
        if self.error:
            raise self.error
        return self.reply


class BudgetGuardTests(unittest.TestCase):
    def guard(self, tokens=100, labels=100, used=0):
        from ite.budget_guard import BudgetGuard
        budget = ResourceBudget(ExperimentConfig(max_tokens=tokens, max_labels=labels))
        budget.record_tokens(used)
        log = EventLog()
        return BudgetGuard(budget, log), budget, log

    def observation(self, budget):
        return {"loss_trend": [], "drift_alarm": True,
                "remaining_label_budget": budget.config.max_labels - budget.labels,
                "remaining_token_budget": budget.config.max_tokens - budget.tokens,
                "model_age_batches": 1}

    def test_eighty_percent_is_inclusive_and_latched_even_if_budget_is_reset(self):
        guard, budget, log = self.guard(used=79)
        self.assertTrue(guard.check(1))
        budget.record_tokens(1)
        self.assertFalse(guard.check(2))
        self.assertEqual((guard.state, guard.reason), ("STATIC_FALLBACK", "token_limit"))
        budget.tokens = 0
        self.assertFalse(guard.check(3))
        self.assertEqual(len(log.events), 1)

    def test_reservation_touching_redline_stops_call_without_charging(self):
        for used, expected_calls, expected_tokens in ((71, 1, 79), (72, 0, 72), (79, 0, 79)):
            with self.subTest(used=used):
                guard, budget, _ = self.guard(used=used)
                client = ReplyClient(LLMReply('{"action":"DO_NOTHING","reason":"ok"}', 8))
                result = guard.get_decision(self.observation(budget), client, 3)
                self.assertEqual(client.calls, expected_calls)
                self.assertEqual(budget.tokens, expected_tokens)
                self.assertEqual(result is not None, expected_calls == 1)

    def test_zero_and_small_budgets_fail_closed_without_division_or_overspend(self):
        for tokens, labels in ((0, 100), (100, 0), (10, 100)):
            with self.subTest(tokens=tokens, labels=labels):
                guard, budget, _ = self.guard(tokens=tokens, labels=labels)
                client = ReplyClient(error=AssertionError("must not be called"))
                self.assertIsNone(guard.get_decision(self.observation(budget), client, 0))
                self.assertEqual((client.calls, budget.tokens), (0, 0))
                self.assertEqual(guard.state, "STATIC_FALLBACK")

    def test_label_exhaustion_is_checked_independently_of_client_calls(self):
        guard, budget, _ = self.guard()
        budget.record_labels(99)
        self.assertTrue(guard.check(1))
        budget.record_labels(1)
        self.assertFalse(guard.check(2))
        self.assertEqual(guard.reason, "label_budget_exhausted")

    def test_bad_json_usage_exception_and_mock_faults_settle_once_then_stop(self):
        good = '{"action":"DO_NOTHING","reason":"ok"}'
        cases = [
            (ReplyClient(LLMReply("bad", 8)), "invalid_action"),
            (ReplyClient(LLMReply('{"action":"DO_NOTHING","reason":"\\ud800"}', 8)), "invalid_action"),
            (ReplyClient(LLMReply(good, 9)), "invalid_usage"),
            (ReplyClient(LLMReply(good, True)), "invalid_usage"),
            (ReplyClient(LLMReply(good, -1)), "invalid_usage"),
            (ReplyClient(LLMReply(good, 8, "real")), "invalid_usage"),
            (ReplyClient(None), "invalid_usage"),
            (ReplyClient(error=TimeoutError("blocked")), "client_timeout"),
            (ReplyClient(error=OSError("unavailable")), "client_error"),
            (MockLLMClient("invalid_json"), "invalid_action"),
            (MockLLMClient("token_exhausted"), "provider_token_exhausted")]
        for client, reason in cases:
            with self.subTest(reason=reason):
                guard, budget, log = self.guard()
                self.assertIsNone(guard.get_decision(self.observation(budget), client, 1))
                self.assertEqual((guard.state, guard.reason, budget.tokens),
                                 ("STATIC_FALLBACK", reason, 8))
                self.assertIsNone(guard.get_decision(self.observation(budget), client, 2))
                self.assertEqual((budget.tokens, guard.calls, guard.mock_tokens), (8, 1, 8))
                self.assertEqual(guard.real_llm_tokens, 0)
                self.assertEqual(sum(e["event"] == "budget_guard_tripped" for e in log.events), 1)

    def test_valid_usage_is_settled_and_action_cannot_mutate_budget_observation(self):
        guard, budget, _ = self.guard()
        client = ReplyClient(LLMReply('{"action":"ROLLBACK","reason":"ok"}', 3))
        result = guard.get_decision(self.observation(budget), client, 1)
        self.assertEqual((result.action, budget.tokens, guard.mock_tokens), ("ROLLBACK", 3, 3))
        self.assertEqual(guard.state, "ACTIVE")
        self.assertGreaterEqual(guard.llm_seconds, 0)

    def test_repaired_action_is_audited_and_settled_at_reported_usage(self):
        guard, budget, log = self.guard()
        raw = '建议：```json\n{"action":"DO_NOTHING","reason":"证据不足。"}\n```'
        client = ReplyClient(LLMReply(raw, 7))
        result = guard.get_decision(self.observation(budget), client, 1)
        event = next(event for event in log.events if event["event"] == "harness_call")
        self.assertEqual(result.action, "DO_NOTHING")
        self.assertTrue(event["action_repaired"])
        self.assertEqual((event["charged_tokens"], budget.tokens, client.calls), (7, 7, 1))
        self.assertEqual(guard.state, "ACTIVE")

    def test_invalid_or_stale_budget_observation_never_reaches_client(self):
        guard, budget, _ = self.guard()
        value = self.observation(budget)
        value["remaining_token_budget"] = 999
        client = ReplyClient(error=AssertionError("must not be called"))
        self.assertIsNone(guard.get_decision(value, client, 1))
        self.assertEqual((client.calls, budget.tokens, guard.reason), (0, 0, "invalid_observation"))


if __name__ == "__main__":
    unittest.main()
