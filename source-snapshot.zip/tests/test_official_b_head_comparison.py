"""B comparison keeps the trainable-parameter contrast paired and auditable."""

import importlib
import unittest

import numpy as np


class OfficialBHeadComparisonTests(unittest.TestCase):
    def module(self):
        try:
            return importlib.import_module("scripts.run_official_b_head_comparison")
        except ImportError as error:
            self.fail(f"Official B head comparison runner is missing: {error}")

    def test_plan_pairs_static_full_and_head_only_at_fixed_times(self):
        m = self.module()
        cases = m.case_plan()
        self.assertEqual(len(cases), 18)
        self.assertEqual(len({(row["scenario"], row["split"], row["arm"]) for row in cases}), 18)
        self.assertEqual({row["arm"] for row in cases}, {"static", "full", "head_only"})
        for row in cases:
            self.assertEqual(tuple(row["decision_steps"]), (3, 7) if row["split"] == "train" else (3,))
            decision = m.fixed_decision(row["arm"])
            self.assertEqual(decision({})["action"], {
                "static": "DO_NOTHING", "full": "RETRAIN_LARGE", "head_only": "RETRAIN_HEAD_ONLY"
            }[row["arm"]])
            self.assertEqual(decision({})["source"], "fixed_comparison")
        self.assertEqual(m.trainable_parameters("full"), 865)
        self.assertEqual(m.trainable_parameters("head_only"), 25)
        with self.assertRaises(ValueError):
            m.trainable_parameters("unexpected")

    def test_drift_requires_lower_rmse_and_no_mae_regression(self):
        m = self.module()
        targets = np.zeros(4)
        static = np.asarray([0., 0., 0., 100.])
        better_rmse_worse_mae = np.asarray([30., 30., 30., 30.])
        improved = np.asarray([0., 0., 0., 60.])
        rows = {arm: {"targets": targets, "source_ids": np.asarray(["a", "b", "c", "d"]),
                      "static": static, "active": values}
                for arm, values in (("static", static), ("full", better_rmse_worse_mae),
                                    ("head_only", improved))}
        result = m.summarize_paired(rows, "abrupt")
        self.assertLess(result["metrics"]["full"]["rmse"], result["metrics"]["static"]["rmse"])
        self.assertGreater(result["metrics"]["full"]["mae"], result["metrics"]["static"]["mae"])
        self.assertFalse(result["passes"]["full"])
        self.assertTrue(result["passes"]["head_only"])
        self.assertFalse(m.summarize_paired({arm: {**row, "active": static} for arm, row in rows.items()},
                                            "gradual")["passes"]["head_only"])
        self.assertTrue(m.summarize_paired({arm: {**row, "active": static} for arm, row in rows.items()},
                                           "stable")["passes"]["head_only"])

    def test_pairing_rejects_changed_ids_targets_or_static_predictions(self):
        m = self.module()
        static = np.asarray([1., 2., 3.])
        base = {"targets": np.zeros(3), "source_ids": np.asarray(["a", "b", "c"]),
                "static": static, "active": static}
        for key, value in (("source_ids", np.asarray(["a", "c", "d"])),
                           ("targets", np.asarray([0., 1., 0.])),
                           ("static", np.zeros(3))):
            with self.subTest(key=key), self.assertRaisesRegex(ValueError, "Unpaired"):
                m.summarize_paired({"static": base, "full": base,
                    "head_only": {**base, key: value}}, "stable")

    def test_summary_reports_rmse_mae_bias_and_dispersion_for_each_bearing(self):
        m = self.module()
        targets = np.asarray([0., 0., 10., 10.])
        static = np.asarray([2., 2., 12., 12.])
        candidate = np.asarray([1., 3., 9., 11.])
        ids = np.asarray(["a1", "a2", "b1", "b2"])
        rows = {arm: {"targets": targets, "source_ids": ids, "static": static, "active": predictions}
                for arm, predictions in (("static", static), ("full", candidate), ("head_only", candidate))}
        result = m.summarize_paired(rows, "abrupt", source_groups=np.asarray(["Bearing1_4"]*2+["Bearing3_4"]*2))
        self.assertEqual(set(result["bearing_metrics"]), {"Bearing1_4", "Bearing3_4"})
        bearing = result["bearing_metrics"]["Bearing1_4"]["full"]
        self.assertAlmostEqual(bearing["rmse"], np.sqrt(5.))
        self.assertEqual(bearing["mae"], 2.)
        self.assertEqual(bearing["bias"], 2.)
        self.assertEqual(bearing["residual_std"], 1.)

    def test_head_checkpoint_audit_rejects_changes_to_frozen_layer_or_adam_state(self):
        m = self.module()
        from ite.official_model import default_package_path
        import io
        import json
        import tempfile
        import zipfile
        from pathlib import Path

        with zipfile.ZipFile(default_package_path("B")) as archive:
            parent_bytes = archive.read("checkpoint.npz")
        with np.load(io.BytesIO(parent_bytes), allow_pickle=False) as archive:
            parent = {key: archive[key].copy() for key in archive.files}
        metadata = json.loads(parent["metadata"].item())

        def candidate_bytes(changed_key):
            candidate = {key: value.copy() for key, value in parent.items()}
            candidate["metadata"] = np.asarray(json.dumps({**metadata,
                "steps": metadata["steps"] + 5, "epochs": metadata["epochs"] + 5}))
            candidate["w2"] += .001
            candidate["adam_first_w2"] += .001
            candidate[changed_key] += .001
            output = io.BytesIO()
            np.savez(output, **candidate)
            return output.getvalue()

        with tempfile.TemporaryDirectory() as tmp:
            parent_path, candidate_path = Path(tmp)/"parent.npz", Path(tmp)/"candidate.npz"
            parent_path.write_bytes(parent_bytes)
            candidate_path.write_bytes(candidate_bytes("w1"))
            with self.assertRaisesRegex(ValueError, "Frozen"):
                m.audit_candidate(parent_path, candidate_path, "head_only")
            candidate_path.write_bytes(candidate_bytes("adam_second_b1"))
            with self.assertRaisesRegex(ValueError, "Frozen"):
                m.audit_candidate(parent_path, candidate_path, "head_only")
            candidate_path.write_bytes(candidate_bytes("b2"))
            audit = m.audit_candidate(parent_path, candidate_path, "head_only")
        self.assertEqual(audit["trainable_parameters"], 25)
        self.assertEqual(audit["trainable_policy"], "head_only")
        self.assertEqual(audit["changed_parameter_counts"]["w1"], 0)


if __name__ == "__main__":
    unittest.main()
