import tempfile
import unittest
from pathlib import Path

import numpy as np

from scripts.measure_tree_training import _measure


class TreeTimingTests(unittest.TestCase):
    def test_measurement_keeps_requested_cold_and_warm_run_counts(self):
        class Initial:
            train_x = np.repeat(np.eye(2), 4, axis=0)
            train_y = np.array([0, 0, 0, 0, 1, 1, 1, 1])
        options = {"max_depth": 2, "min_samples_leaf": 1, "max_leaf_nodes": 4, "random_state": 7}
        cold = _measure(Initial(), "classification", (0, 1), cold=True, runs=1,
                        timeout_seconds=10., options=options)
        warm = _measure(Initial(), "classification", (0, 1), cold=False, runs=2,
                        timeout_seconds=10., options=options)
        self.assertEqual(len(cold), 1)
        self.assertEqual(len(warm), 2)
        self.assertTrue(all(item["status"] == "ok" for item in (*cold, *warm)))


if __name__ == "__main__":
    unittest.main()
