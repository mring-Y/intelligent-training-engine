"""A single-use, narrowly budgeted live Qwen defense demonstration."""

import importlib
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from ite.config import ExperimentConfig
from ite.controller import AdaptationController
from ite.trio_client import build_messages


class CmapssLiveDemoTests(unittest.TestCase):
    def test_frozen_fd001_profile_is_real_tree_and_bounded_to_two_requests(self):
        config = ExperimentConfig.load(Path(__file__).resolve().parents[1] /
                                       "configs/cmapss-tree-qwen-demo.json")
        self.assertEqual((config.task, config.scenario, config.seed, config.n_batches),
                         ("regression", "abrupt", 7, 18))
        self.assertEqual((config.model_type, config.harness_backend, config.max_llm_calls),
                         ("tree", "pytrio", 2))
        self.assertEqual((config.llm_max_input_tokens, config.llm_max_output_tokens,
                          config.max_llm_cost_cny, config.llm_timeout_seconds),
                         (1250, 128, "0.03", 15.0))
        self.assertEqual(config.llm_model, "Qwen/Qwen3.5-4B")
        self.assertEqual((config.llm_input_price_per_million,
                          config.llm_output_price_per_million), ("1.49", "4.54"))
        self.assertEqual(config.llm_ledger_path,
                         "outputs/cmapss-tree-qwen-paid-state-20261112/call-ledger.json")
        self.assertEqual(config.llm_tokenizer_path,
                         "deployment/tokenizer-qwen3.5-4b")
        self.assertEqual(config.llm_prompt_profile, "cmapss_defense")
        self.assertEqual((config.tree_initial_timeout_seconds, config.tree_timeout_seconds), (8.0, 5.0))
        from ite.budget import ResourceBudget
        self.assertEqual(ResourceBudget(config).training_allowance(), 5.0)

    def test_paid_fd001_profile_rejects_expanded_or_weakened_bounds(self):
        values = ExperimentConfig.load(Path(__file__).resolve().parents[1] /
                                        "configs/cmapss-tree-qwen-demo.json").to_dict()
        for changes in ({"max_llm_calls": 3}, {"max_llm_cost_cny": "0.031"},
                        {"llm_max_input_tokens": 1251}, {"llm_max_output_tokens": 129},
                        {"llm_timeout_seconds": 15.01}, {"llm_prompt_profile": "default"},
                        {"tree_initial_timeout_seconds": 9.0}, {"tree_max_depth": 7},
                        {"history_windows": [192, 384]}):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                ExperimentConfig.from_dict({**values, **changes})

    def test_only_frozen_cmapss_demo_may_raise_initial_tree_startup_timeout(self):
        values = ExperimentConfig.load(Path(__file__).resolve().parents[1] /
                                        "configs/cmapss-tree-qwen-demo.json").to_dict()
        mock = {**values, "harness_backend": "mock", "llm_prompt_profile": "default",
                "llm_ledger_path": ""}
        with self.assertRaisesRegex(ValueError, "tree_initial_timeout_seconds"):
            ExperimentConfig.from_dict({**mock, "tree_initial_timeout_seconds": 8.0})

    def test_defensive_prompt_is_evidence_bounded_and_keeps_current_observation_separate(self):
        observation = {"loss_trend": [{"source_step": 4, "loss": .2343835496, "labeled_samples": 256},
            {"source_step": 5, "loss": .3209712609, "labeled_samples": 256},
            {"source_step": 6, "loss": .2146193415, "labeled_samples": 256},
            {"source_step": 7, "loss": .2055339893, "labeled_samples": 256},
            {"source_step": 8, "loss": .5449269695, "labeled_samples": 256}],
            "drift_alarm": True, "remaining_label_budget": None,
            "remaining_token_budget": 3600, "model_age_batches": 11}
        messages = build_messages(observation, model_type="tree", prompt_profile="cmapss_defense")
        system, user = messages[0]["content"], messages[1]["content"]
        self.assertIn("你当前的模型是树模型", system)
        self.assertIn("192 条训练样本", system)
        self.assertIn("29.77", system)
        self.assertIn("28.25", system)
        self.assertIn("不能证明小样本重训普遍过拟合", system)
        self.assertIn("feature_shift=false", system)
        self.assertIn("DO_NOTHING", system)
        self.assertNotIn("sensor_1", system)
        self.assertIn('"source_step":8', user)
        self.assertIn('"labeled_samples":256', user)

    def test_real_controller_forwards_the_defensive_profile_to_qwen_client(self):
        root = Path(__file__).resolve().parents[1]
        values = ExperimentConfig.load(root / "configs/cmapss-tree-qwen-demo.json").to_dict()
        with tempfile.TemporaryDirectory() as tmp:
            values["llm_ledger_path"] = str(Path(tmp) / "ledger.json")
            config = ExperimentConfig.from_dict(values)
            model = Mock()
            model.mean = model.std = [0.0, 1.0]
            model.family = "ridge"
            logger = Mock()
            with patch("ite.trio_client.TrioLLMClient") as client:
                AdaptationController(config, "drift", model, .3, 1.0, logger, Mock(), Path(tmp))
            self.assertEqual(client.call_args.kwargs["model_type"], "tree")
            self.assertEqual(client.call_args.kwargs["prompt_profile"], "cmapss_defense")
            self.assertEqual(client.call_args.kwargs["max_input_tokens"], 1250)
            self.assertEqual(client.call_args.kwargs["max_output_tokens"], 128)
            self.assertEqual(client.call_args.kwargs["timeout_seconds"], 15.0)
            self.assertEqual(client.call_args.kwargs.get("input_price_per_million"), "1.49")
            self.assertEqual(client.call_args.kwargs.get("output_price_per_million"), "4.54")

    def test_tokenizer_provenance_must_match_model_and_all_local_file_hashes(self):
        module = importlib.import_module("scripts.run_cmapss_qwen_demo")
        self.assertTrue(hasattr(module, "verify_tokenizer_provenance"))
        root = Path(__file__).resolve().parents[1]
        valid = module.verify_tokenizer_provenance(root / "deployment/tokenizer-qwen3.5-4b",
                                                   "Qwen/Qwen3.5-4B")
        self.assertEqual(valid["model"], "Qwen/Qwen3.5-4B")
        manifest = json.loads((root / "deployment/tokenizer-qwen3.5-4b/tokenizer-manifest.json")
                              .read_text(encoding="utf-8"))
        manifest["model"] = "Qwen/Qwen3.8-27B"
        with tempfile.TemporaryDirectory() as tmp:
            local_dir = Path(tmp)
            (local_dir / "tokenizer-manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            for entry in manifest["files"]:
                source = root / "deployment/tokenizer-qwen3.5-4b" / entry["name"]
                (local_dir / entry["name"]).write_bytes(source.read_bytes())
            with self.assertRaisesRegex(ValueError, "model mismatch"):
                module.verify_tokenizer_provenance(local_dir, "Qwen/Qwen3.5-4B")
            manifest["model"] = "Qwen/Qwen3.5-4B"
            (local_dir / "tokenizer-manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            (local_dir / "chat_template.jinja").write_text("tampered", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "hash mismatch"):
                module.verify_tokenizer_provenance(local_dir, "Qwen/Qwen3.5-4B")

    def test_tokenizer_preflight_counts_frozen_observation_and_blocks_oversized_request(self):
        from types import SimpleNamespace
        module = importlib.import_module("scripts.run_cmapss_qwen_demo")
        config = ExperimentConfig.load(module.DEFAULT_CONFIG)
        manifest, _ = module._manifest(module.DEFAULT_PACKAGE)
        observation = module._verify_reference(module.REFERENCE_EVENTS, manifest)["observation"]
        tokenizer_dir = module.ROOT / config.llm_tokenizer_path
        result = module.tokenizer_preflight(tokenizer_dir, config.llm_model, observation, config)
        self.assertEqual(result["local_tokenizer_input_tokens"], 960)
        self.assertLessEqual(result["local_tokenizer_input_tokens"], 1250)
        with self.assertRaisesRegex(ValueError, "input_token_limit"):
            module.tokenizer_preflight(tokenizer_dir, config.llm_model, observation,
                SimpleNamespace(model_type="tree", llm_prompt_profile="cmapss_defense", llm_max_input_tokens=959))

    def test_live_report_preserves_history_and_reads_actual_json_usage_and_latency(self):
        try:
            module = importlib.import_module("scripts.run_cmapss_qwen_demo")
        except ImportError as error:
            self.fail(f"Single-use C-MAPSS live demonstration missing: {error}")
        with tempfile.TemporaryDirectory() as root:
            root = Path(root)
            run = root / "run"
            run.mkdir()
            (run / "drift").mkdir()
            response = '{"action":"DO_NOTHING","reason":"筛选证据不足，保持当前模型。"}'
            events = [
                {"event": "harness_observation", "step": 10, "observation":
                 {"loss_trend": [{"source_step": 8, "loss": .54, "labeled_samples": 256}]}},
                {"event": "harness_call", "step": 10, "status": "ok", "call_id": 1,
                 "token_accounting_mode": "real",
                 "raw_response": response, "parsed_action": {"action": "DO_NOTHING",
                 "reason": "筛选证据不足，保持当前模型。"}, "usage_known": True,
                 "latency_seconds": 2.75, "llm_input_tokens": 811, "llm_output_tokens": 19,
                 "llm_estimated_cost_cny": "0.0073"},
                {"event": "run_completed", "step": 18, "stream_batches": 18}]
            (run / "drift/events.jsonl").write_text("\n".join(json.dumps(x, ensure_ascii=False) for x in events),
                                                    encoding="utf-8")
            ledger = {"attempted_calls": 1, "used_input_tokens": 811, "used_output_tokens": 19,
                      "used_cost_cny": "0.0073", "trip_reason": None,
                      "requests": [{"call_id": 1, "step": 10, "status": "settled",
                          "input_tokens": 811, "output_tokens": 19, "cost_cny": "0.0073"}]}
            (run / "paid-call-ledger.json").write_text(json.dumps(ledger), encoding="utf-8")
            (run / "summary.json").write_text(json.dumps({"training_attempts": 0, "updates": 0,
                "rollbacks": 0, "harness_state": "STATIC_FALLBACK"}), encoding="utf-8")
            report = root / "Qwen_Live_Decision.md"
            report.write_text("# Previous round\n\nNOT EXECUTED\n", encoding="utf-8")
            rendered = module.append_live_report(run, report)
            text = report.read_text(encoding="utf-8")
            self.assertTrue(text.startswith("# Previous round"))
            self.assertIn(response, text)
            self.assertIn("筛选证据不足，保持当前模型。", text)
            self.assertIn("811", text)
            self.assertIn("19", text)
            self.assertIn("2.75", text)
            self.assertIn("0.0073", text)
            self.assertIn("训练尝试/部署/回滚：0/0/0", text)
            self.assertEqual(rendered["decision_count"], 1)

    def test_timeout_report_keeps_provider_usage_unknown_and_never_claims_zero(self):
        try:
            module = importlib.import_module("scripts.run_cmapss_qwen_demo")
        except ImportError as error:
            self.fail(f"Single-use C-MAPSS live demonstration missing: {error}")
        with tempfile.TemporaryDirectory() as root:
            root = Path(root)
            run = root / "run"
            run.mkdir()
            (run / "drift").mkdir()
            events = [{"event": "harness_call", "step": 10, "status": "client_timeout",
                "token_accounting_mode": "real",
                "call_id": 1, "raw_response": None, "parsed_action": None, "usage_known": False,
                "latency_seconds": 15.0, "llm_unknown_calls": 1,
                "llm_reserved_cost_cny": "0.01374962"},
                {"event": "run_completed", "step": 18}]
            (run / "drift/events.jsonl").write_text("\n".join(json.dumps(x) for x in events), encoding="utf-8")
            ledger = {"attempted_calls": 1, "used_input_tokens": 0, "used_output_tokens": 0,
                "used_cost_cny": "0", "trip_reason": "client_timeout", "requests": [
                    {"call_id": 1, "step": 10, "status": "reserved", "reserved_cost_cny": "0.01374962",
                     "input_tokens": None, "output_tokens": None, "cost_cny": None}]}
            (run / "paid-call-ledger.json").write_text(json.dumps(ledger), encoding="utf-8")
            report = root / "Qwen_Live_Decision.md"
            module.append_live_report(run, report)
            text = report.read_text(encoding="utf-8")
            self.assertIn("Token用量未知", text)
            self.assertIn("client_timeout", text)
            self.assertIn("没有响应JSON", text)
            self.assertIn("0.01374962", text)
            self.assertIn("最终扣费未知", text)
            self.assertIn("已结算费用", text)
            self.assertNotIn("真实Token：0", text)

    def test_live_report_does_not_invent_a_qwen_reason_from_mock_decisions(self):
        try:
            module = importlib.import_module("scripts.run_cmapss_qwen_demo")
        except ImportError as error:
            self.fail(f"Single-use C-MAPSS live demonstration missing: {error}")
        with tempfile.TemporaryDirectory() as root:
            root = Path(root)
            run = root / "run"
            run.mkdir()
            (run / "drift").mkdir()
            events = [{"event": "harness_call", "step": 10, "status": "client_timeout",
                       "token_accounting_mode": "real", "parsed_action": None, "raw_response": None,
                       "usage_known": False, "latency_seconds": 15.0},
                      {"event": "harness_decision", "step": 10, "action": "RETRAIN_SMALL",
                       "reason": "Observed degradation; request bounded training."},
                      {"event": "run_completed", "step": 18}]
            (run / "drift/events.jsonl").write_text("\n".join(json.dumps(x) for x in events), encoding="utf-8")
            (run / "paid-call-ledger.json").write_text(json.dumps({"attempted_calls": 1,
                "used_input_tokens": 0, "used_output_tokens": 0, "used_cost_cny": "0",
                "trip_reason": "client_timeout", "requests": [{"call_id": 1, "status": "reserved",
                    "reserved_cost_cny": "0.01374962"}]}), encoding="utf-8")
            report = root / "report.md"
            module.append_live_report(run, report)
            self.assertNotIn("Observed degradation", report.read_text(encoding="utf-8"))

    def test_paid_profile_claim_cannot_be_recreated_after_failure(self):
        module = importlib.import_module("scripts.run_cmapss_qwen_demo")
        root = Path(__file__).resolve().parents[1]
        config = ExperimentConfig.load(root / "configs/cmapss-tree-qwen-demo.json")
        manifest = root / "outputs/a-package-20261110/prepared/cmapss_fd001/manifest.json"
        with tempfile.TemporaryDirectory() as tmp:
            state = Path(tmp) / "state"
            output = Path(tmp) / "output"
            module.claim_single_run(state, output, config, manifest)
            self.assertTrue((state / "run-claim.json").is_file())
            with self.assertRaisesRegex(FileExistsError, "single-use"):
                module.claim_single_run(state, output, config, manifest)

    def test_new_paid_run_uses_a_distinct_single_use_claim_and_ledger(self):
        module = importlib.import_module("scripts.run_cmapss_qwen_demo")
        config = ExperimentConfig.load(Path(__file__).resolve().parents[1] /
                                       "configs/cmapss-tree-qwen-demo.json")
        manifest = Path(__file__).resolve().parents[1] / "outputs/a-package-20261110/prepared/cmapss_fd001/manifest.json"
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            state = root / "fresh-4b-state"
            output = root / "fresh-4b-output"
            module.claim_single_run(state, output, config, manifest)
            claim = json.loads((state / "run-claim.json").read_text(encoding="utf-8"))
            self.assertEqual(claim["profile"], "cmapss-fd001-tree-defense-qwen35-4b-v1")
            self.assertEqual(Path(claim["output"]), output.resolve())

    def test_step_ten_reference_matches_the_same_prepared_fd001_stream(self):
        module = importlib.import_module("scripts.run_cmapss_qwen_demo")
        package = Path(__file__).resolve().parents[1] / "outputs/a-package-20261110/prepared/cmapss_fd001"
        manifest, _ = module._manifest(package)
        reference = module._verify_reference(module.REFERENCE_EVENTS, manifest)
        self.assertEqual(reference["decision"]["action"], "RETRAIN_SMALL")
        self.assertEqual(reference["candidate"]["train_samples"], 192)
        mismatched = json.loads(json.dumps(manifest))
        mismatched["files"]["stream"]["sha256"] = "0" * 64
        with self.assertRaisesRegex(ValueError, "reference evidence"):
            module._verify_reference(module.REFERENCE_EVENTS, mismatched)


if __name__ == "__main__":
    unittest.main()
