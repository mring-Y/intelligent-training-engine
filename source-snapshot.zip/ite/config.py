"""Validated local simulation settings, independent of the future official SDK."""

import json
import importlib.util
import math
import os
from dataclasses import asdict, dataclass, fields
from pathlib import Path
from decimal import Decimal, InvalidOperation

SCENARIOS = ("stable", "abrupt", "gradual", "recurring", "covariate", "noise")
ALL_SCENARIOS = (*SCENARIOS, "mixed", "triple_abrupt")
POLICIES = ("static", "periodic", "drift")
DEFAULT_LLM_MODEL = "Qwen/Qwen3.5-4B"
DEFAULT_LLM_INPUT_PRICE_PER_MILLION = "1.49"
DEFAULT_LLM_OUTPUT_PRICE_PER_MILLION = "4.54"
HEURISTIC_C_EPOCHS = (1, 2, 3, 5)


@dataclass(frozen=True)
class ExperimentConfig:
    seed: int = 7
    task: str = "classification"
    scenario: str = "abrupt"
    n_features: int = 8
    initial_train: int = 512
    initial_validation: int = 256
    n_batches: int = 36
    batch_size: int = 96
    drift_start: int = 10
    drift_width: int = 8
    label_delay: int = 2
    label_fraction: float = 0.25
    max_labels: int = 864
    max_train_seconds: float = 20.0
    max_experiments: int = 12
    candidate_timeout_seconds: float = 3.0
    candidate_startup_reserve_seconds: float = 1.5
    candidate_alphas: tuple = (0.1, 10.0)
    history_windows: tuple = (192, 384, 768)
    min_labeled: int = 96
    min_validation: int = 32
    feature_threshold: float = 0.65
    error_increase: float = 0.13
    min_gain: float = 0.02
    rollback_margin: float = 0.05
    cooldown: int = 3
    update_interval: int = 6
    strategy_adaptation: bool = False
    deployment_validation: str = "legacy"
    monitor_min_labeled: int | None = None
    reuse_history: bool = False
    label_schedule: str = "frontloaded"
    label_startup_budget: int = 0
    train_source_window_batches: int = 0
    training_preflight: bool = False
    training_weighting: str = "none"
    training_half_life_batches: float = 4.0
    selection_split: str = "chronological"
    task_specific_classification_pool_samples: int = 48
    classification_tie_break: str = "legacy"
    candidate_max_wait_batches: int | None = None
    candidate_feasibility: bool = False
    model_family: str = "ridge"
    model_type: str = "ridge"
    official_profile: str = ""
    official_runtime_python: str = ""
    official_package_path: str = ""
    official_checkpoint_path: str = ""
    official_candidate_epochs: int = 5
    official_timeout_seconds: float = 5.0
    class_labels: tuple | None = None
    tree_max_depth: int = 6
    tree_min_samples_leaf: int = 5
    tree_max_leaf_nodes: int = 64
    tree_timeout_seconds: float = 5.0
    tree_initial_timeout_seconds: float = 5.0
    relationship: str = "linear"
    class_threshold: float = 0.0
    outlier_fraction: float = 0.0
    drift_magnitude: float = 1.0
    decision_backend: str = "rules"
    max_tokens: int = 0
    harness_enabled: bool = False
    heuristic_override: bool = False
    harness_mock_mode: str = "normal"
    label_mode: str = "budgeted"
    harness_backend: str = "mock"
    harness_drift_only: bool = False
    max_llm_calls: int | None = None
    max_llm_cost_cny: str = "0.50"
    llm_model: str = DEFAULT_LLM_MODEL
    llm_input_price_per_million: str | None = None
    llm_output_price_per_million: str | None = None
    llm_prompt_profile: str = "default"
    llm_max_input_tokens: int = 2048
    llm_max_output_tokens: int = 512
    llm_timeout_seconds: float = 15.0
    llm_ledger_path: str = ""
    llm_tokenizer_path: str = ""

    def __post_init__(self):
        if self.task not in ("classification", "regression") or self.scenario not in ALL_SCENARIOS:
            raise ValueError("Unsupported task or scenario")
        positive_ints = ("n_features", "initial_train", "initial_validation", "n_batches", "batch_size",
                         "drift_width", "min_labeled", "min_validation", "update_interval")
        nonnegative_ints = ("seed", "drift_start", "label_delay", "max_labels", "max_experiments", "cooldown",
                            "max_tokens", "label_startup_budget", "train_source_window_batches")
        for name in positive_ints + nonnegative_ints:
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value < (1 if name in positive_ints else 0):
                raise ValueError(f"{name} must be a valid integer")
        if self.n_features < 2 or self.initial_train < 4 or self.initial_validation < 4:
            raise ValueError("At least two features and four initial training/validation samples are required")
        if self.min_labeled <= self.min_validation:
            raise ValueError("min_labeled must exceed min_validation")
        for name in ("label_fraction", "max_train_seconds", "candidate_timeout_seconds",
                     "candidate_startup_reserve_seconds", "feature_threshold",
                     "error_increase", "min_gain", "rollback_margin"):
            value = getattr(self, name)
            if not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
                raise ValueError(f"{name} must be finite and nonnegative")
        if self.label_fraction > 1 or self.candidate_timeout_seconds <= 0:
            raise ValueError("Invalid label fraction or candidate timeout")
        if not self.candidate_alphas or any(not math.isfinite(a) or a <= 0 for a in self.candidate_alphas):
            raise ValueError("candidate_alphas must contain positive finite numbers")
        if not self.history_windows or any(isinstance(w, bool) or not isinstance(w, int) or
                                           w < self.min_labeled for w in self.history_windows):
            raise ValueError("history_windows must be integers at least min_labeled")
        if not isinstance(self.strategy_adaptation, bool):
            raise ValueError("strategy_adaptation must be a boolean")
        if self.deployment_validation not in ("legacy", "future"):
            raise ValueError("deployment_validation must be legacy or future")
        if self.monitor_min_labeled is not None and (isinstance(self.monitor_min_labeled, bool) or
                not isinstance(self.monitor_min_labeled, int) or self.monitor_min_labeled < 1):
            raise ValueError("monitor_min_labeled must be a positive integer or null")
        if not isinstance(self.reuse_history, bool):
            raise ValueError("reuse_history must be a boolean")
        if self.reuse_history and self.deployment_validation != "future":
            raise ValueError("reuse_history requires independent future deployment validation")
        if self.label_schedule not in ("frontloaded", "uniform", "adaptive"):
            raise ValueError("Unsupported label_schedule")
        if self.label_mode not in ("budgeted", "provided"):
            raise ValueError("label_mode must be budgeted or provided")
        if self.label_mode == "provided" and self.label_startup_budget:
            raise ValueError("Provided labels do not use a startup allocation")
        if self.label_startup_budget and self.label_schedule != "adaptive":
            raise ValueError("label_startup_budget requires the adaptive label schedule")
        if not isinstance(self.training_preflight, bool):
            raise ValueError("training_preflight must be a boolean")
        if self.training_weighting not in ("none", "exponential"):
            raise ValueError("training_weighting must be none or exponential")
        half_life = self.training_half_life_batches
        if (isinstance(half_life, bool) or not isinstance(half_life, (int, float)) or
                not math.isfinite(half_life) or half_life <= 0):
            raise ValueError("training_half_life_batches must be finite and positive")
        if self.training_weighting == "exponential" and self.train_source_window_batches:
            raise ValueError("Exponential training weights cannot be combined with a hard source window")
        if self.selection_split not in ("chronological", "recent_disjoint", "task_specific"):
            raise ValueError("selection_split must be chronological, recent_disjoint, or task_specific")
        if self.selection_split in ("recent_disjoint", "task_specific") and self.deployment_validation != "future":
            raise ValueError("disjoint selection requires independent future deployment validation")
        if self.classification_tie_break not in ("legacy", "alpha_desc"):
            raise ValueError("classification_tie_break must be legacy or alpha_desc")
        class_pool = self.task_specific_classification_pool_samples
        if isinstance(class_pool, bool) or not isinstance(class_pool, int) or class_pool not in (32, 48):
            raise ValueError("task_specific_classification_pool_samples must be 32 or 48")
        if self.candidate_max_wait_batches is not None and (
                isinstance(self.candidate_max_wait_batches, bool) or
                not isinstance(self.candidate_max_wait_batches, int) or self.candidate_max_wait_batches < 1):
            raise ValueError("candidate_max_wait_batches must be a positive integer or null")
        if not isinstance(self.candidate_feasibility, bool):
            raise ValueError("candidate_feasibility must be a boolean")
        if (self.candidate_feasibility or self.candidate_max_wait_batches is not None) and self.deployment_validation != "future":
            raise ValueError("Candidate governance requires future validation")
        if self.model_family not in ("ridge", "quadratic", "ovr_ridge") or self.relationship not in ("linear", "nonlinear"):
            raise ValueError("Unsupported model family or synthetic relationship")
        if self.model_type not in ("ridge", "tree", "official", "official_mlp"):
            raise ValueError("Unsupported model type")
        if self.llm_prompt_profile not in ("default", "cmapss_defense"):
            raise ValueError("Unsupported LLM prompt profile")
        for name, lower, upper in (("tree_max_depth", 1, 16), ("tree_min_samples_leaf", 1, 1_000_000),
                                   ("tree_max_leaf_nodes", 2, 4096)):
            value = getattr(self, name)
            if type(value) is not int or not lower <= value <= upper:
                raise ValueError(f"{name} must be an integer in [{lower}, {upper}]")
        timeout = self.tree_timeout_seconds
        if (isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or
                not math.isfinite(timeout) or not 0 < timeout <= 5):
            raise ValueError("tree_timeout_seconds must be finite and in (0, 5]")
        initial_timeout = self.tree_initial_timeout_seconds
        cmapss_defense_profile = (self.task == "regression" and self.scenario == "abrupt"
                                  and self.seed == 7 and self.n_batches == 18 and self.model_type == "tree"
                                  and self.harness_backend == "pytrio"
                                  and self.llm_prompt_profile == "cmapss_defense")
        initial_limit = 8 if cmapss_defense_profile else 5
        if (isinstance(initial_timeout, bool) or not isinstance(initial_timeout, (int, float))
                or not math.isfinite(initial_timeout) or not 0 < initial_timeout <= initial_limit):
            raise ValueError(f"tree_initial_timeout_seconds must be finite and in (0, {initial_limit}]")
        if self.class_labels is not None:
            labels = self.class_labels
            if (self.task != "classification" or not isinstance(labels, (tuple, list)) or
                    any(type(label) is not int for label in labels) or
                    tuple(labels) not in ((0, 1), (1, 2, 3, 4, 5, 6))):
                raise ValueError("class_labels must be the fixed integer binary or six-class IDs")
            labels = tuple(labels)
            expected = (1, 2, 3, 4, 5, 6) if self.model_family == "ovr_ridge" else (0, 1)
            if self.model_type == "ridge" and labels != expected:
                raise ValueError("Ridge class_labels conflict with its model family")
            object.__setattr__(self, "class_labels", labels)
        official = self.model_type in ("official", "official_mlp")
        if official:
            if (self.model_family != "ridge" or self.harness_backend != "mock" or
                    self.training_weighting != "none"):
                raise ValueError("Official CPU MLP requires the fixed Ridge-family Mock training path")
            if self.official_profile not in ("A", "B", "C", "auto"):
                raise ValueError("official_profile must be A, B, C or auto")
            profile_contracts = {"A": ("classification", 128), "B": ("regression", 34),
                                 "C": ("regression", 24)}
            if self.official_profile in profile_contracts:
                expected_task, expected_features = profile_contracts[self.official_profile]
                if self.task != expected_task or self.n_features != expected_features:
                    raise ValueError(f"Official profile {self.official_profile} task or feature count mismatch")
            if (not isinstance(self.official_runtime_python, str) or
                    not isinstance(self.official_package_path, str) or
                    not isinstance(self.official_checkpoint_path, str)):
                raise ValueError("Official runtime and package paths must be strings")
            if self.official_profile == "A":
                if self.class_labels is None:
                    object.__setattr__(self, "class_labels", (1, 2, 3, 4, 5, 6))
                elif self.class_labels != (1, 2, 3, 4, 5, 6):
                    raise ValueError("Official A requires class labels 1..6")
            elif self.official_profile in ("B", "C") and self.class_labels is not None:
                raise ValueError("Official B/C regression profiles do not accept class labels")
            if type(self.official_candidate_epochs) is not int or not 1 <= self.official_candidate_epochs <= 20:
                raise ValueError("official_candidate_epochs must be in 1..20")
            timeout = self.official_timeout_seconds
            if (isinstance(timeout, bool) or not isinstance(timeout, (float, int)) or
                    not math.isfinite(timeout) or not 0 < timeout <= 5):
                raise ValueError("official_timeout_seconds must be finite and in (0, 5]")
        elif any((self.official_profile, self.official_runtime_python, self.official_package_path,
                  self.official_checkpoint_path)):
            raise ValueError("Official model paths require model_type='official_mlp'")
        if self.model_type == "tree":
            if self.model_family != "ridge":
                raise ValueError("Tree model_type cannot be combined with an OVR or quadratic family")
            if self.harness_backend != "mock" and not (
                    self.harness_backend == "pytrio" and self.llm_prompt_profile == "cmapss_defense"):
                raise ValueError("Tree real calls require the fixed C-MAPSS defense profile")
            if self.seed > 2**32 - 1:
                raise ValueError("Tree random seed must be in [0, 2**32 - 1]")
            if self.task == "classification" and self.class_labels is None:
                object.__setattr__(self, "class_labels", (0, 1))
            if importlib.util.find_spec("sklearn") is None:
                raise ValueError("Tree training requires the pinned scikit-learn tree dependencies")
        if self.model_family == "ovr_ridge" and (self.task != "classification" or self.harness_backend != "mock"):
            raise ValueError("One-vs-Rest Ridge requires classification and the local Mock backend")
        if self.relationship == "nonlinear" and self.n_features < 3:
            raise ValueError("Nonlinear simulation needs at least three features")
        for name in ("outlier_fraction", "drift_magnitude"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value) or not 0 <= value <= 1:
                raise ValueError(f"{name} must be in [0, 1]")
        if isinstance(self.class_threshold, bool) or not isinstance(self.class_threshold, (float, int)) or not math.isfinite(self.class_threshold):
            raise ValueError("class_threshold must be finite")
        if self.decision_backend not in ("rules", "mock"):
            raise ValueError("Only local rules and offline mock decision backends are available")
        if not isinstance(self.harness_enabled, bool):
            raise ValueError("harness_enabled must be a boolean")
        if self.harness_mock_mode not in ("normal", "token_exhausted", "invalid_json", "head_only", "calibrate_down"):
            raise ValueError("Unsupported Harness mock mode")
        if self.harness_mock_mode == "head_only" and not official:
            raise ValueError("Frozen-head Mock requires an official MLP")
        if self.harness_mock_mode == "calibrate_down" and not (
                official and self.task == "regression" and self.n_features == 24 and
                self.official_profile in ("C", "auto")):
            raise ValueError("Calibration Mock requires official C regression")
        if self.harness_backend not in ("mock", "pytrio") or not isinstance(self.harness_drift_only, bool):
            raise ValueError("Invalid Harness backend or drift-only flag")
        if self.max_llm_calls is not None and (type(self.max_llm_calls) is not int or not 1 <= self.max_llm_calls <= 10):
            raise ValueError("max_llm_calls must be null or an integer from 1 to 10")
        for name, upper in (("llm_max_input_tokens", 2048), ("llm_max_output_tokens", 512)):
            if type(getattr(self, name)) is not int or not 1 <= getattr(self, name) <= upper:
                raise ValueError(f"{name} exceeds the smoke limit")
        if (isinstance(self.llm_timeout_seconds, bool) or not isinstance(self.llm_timeout_seconds, (int, float)) or
                not math.isfinite(self.llm_timeout_seconds) or not 0 < self.llm_timeout_seconds <= 15):
            raise ValueError("llm_timeout_seconds must be finite and in (0, 15]")
        try:
            cost = Decimal(str(self.max_llm_cost_cny))
        except InvalidOperation:
            raise ValueError("max_llm_cost_cny must be a finite positive decimal") from None
        if not cost.is_finite() or not 0 < cost <= Decimal("0.50"):
            raise ValueError("max_llm_cost_cny must be in (0, 0.50]")
        if not isinstance(self.llm_ledger_path, str):
            raise ValueError("llm_ledger_path must be a string")
        for name, default in (("llm_input_price_per_million", DEFAULT_LLM_INPUT_PRICE_PER_MILLION),
                               ("llm_output_price_per_million", DEFAULT_LLM_OUTPUT_PRICE_PER_MILLION)):
            value = getattr(self, name)
            if value is None:
                if self.llm_model != DEFAULT_LLM_MODEL:
                    raise ValueError("Nondefault LLM models require explicit input and output prices")
                value = default
            try:
                price = Decimal(str(value))
            except (InvalidOperation, ValueError):
                raise ValueError(f"{name} must be a finite positive decimal") from None
            if not price.is_finite() or price <= 0:
                raise ValueError(f"{name} must be a finite positive decimal")
            object.__setattr__(self, name, str(price))
        if self.harness_backend == "pytrio":
            if not self.harness_enabled or not self.harness_drift_only or not self.llm_ledger_path.strip():
                raise ValueError("Real Harness requires enabled drift-only mode and an explicit durable ledger")
            if self.llm_model not in ("Qwen/Qwen3.5-4B", "Qwen/Qwen3.8-27B"):
                raise ValueError("Real requests require a supported Qwen model")
            profile = (self.task, self.scenario, self.seed, self.n_batches)
            cmapss_defense = (profile == ("regression", "abrupt", 7, 18)
                              and self.model_type == "tree"
                              and self.llm_prompt_profile == "cmapss_defense")
            if (profile not in (("classification", "abrupt", 7, 96),
                                ("classification", "triple_abrupt", 7, 30)) and not cmapss_defense):
                raise ValueError("Paid smoke must match an explicitly approved profile")
            if cmapss_defense:
                fixed = dict(n_features=24, initial_train=11942, initial_validation=4196, batch_size=256,
                    drift_start=0, label_delay=2, max_labels=864, max_train_seconds=20.0,
                    max_experiments=12, candidate_timeout_seconds=3.0, candidate_startup_reserve_seconds=1.5,
                    candidate_alphas=(1.0,), history_windows=(192, 384, 768), min_labeled=96,
                    min_validation=32, error_increase=.13, min_gain=.02, rollback_margin=.05, cooldown=3,
                    monitor_min_labeled=96, selection_split="recent_disjoint", training_weighting="none",
                    train_source_window_batches=0, reuse_history=False, candidate_feasibility=True,
                    training_preflight=True, deployment_validation="future", model_family="ridge",
                    model_type="tree", harness_enabled=True, harness_drift_only=True,
                    tree_max_depth=6, tree_min_samples_leaf=5, tree_max_leaf_nodes=64,
                    tree_initial_timeout_seconds=8.0,
                    harness_mock_mode="normal", label_mode="provided", max_llm_calls=2,
                    max_llm_cost_cny="0.03", max_tokens=3600, llm_max_input_tokens=1250,
                    llm_max_output_tokens=128, llm_timeout_seconds=15.0,
                    llm_model="Qwen/Qwen3.5-4B", llm_input_price_per_million="1.49",
                    llm_output_price_per_million="4.54")
                if (any(getattr(self, key) != value for key, value in fixed.items())
                        or cost > Decimal("0.03") or self.max_tokens > 3600):
                    raise ValueError("C-MAPSS defense demo must keep its fixed stream, model and two-call budget")
            if self.scenario == "triple_abrupt":
                if (self.max_llm_calls is None or self.max_llm_calls > 5 or cost > Decimal("0.16") or
                        self.max_tokens > 20000 or self.label_delay != 2 or self.label_mode != "provided"):
                    raise ValueError("Triple abrupt smoke exceeds its approved budget or label protocol")
                fixed = dict(n_features=8, initial_train=512, initial_validation=256, batch_size=96,
                    candidate_alphas=(.1, 10.0), history_windows=(192, 384, 768), min_labeled=96,
                    min_validation=32, min_gain=.02, rollback_margin=.05, cooldown=3,
                    error_increase=.13, monitor_min_labeled=None, selection_split="chronological",
                    training_weighting="none", train_source_window_batches=0, reuse_history=False,
                    classification_tie_break="legacy", model_family="ridge", relationship="linear",
                    class_threshold=0.0, drift_magnitude=1.0, outlier_fraction=0.0,
                    max_experiments=12, max_train_seconds=20.0, candidate_max_wait_batches=None)
                if any(getattr(self, key) != value for key, value in fixed.items()):
                    raise ValueError("Triple abrupt smoke must keep the approved evidence and model rules")
        if type(self.heuristic_override) is not bool:
            raise ValueError("heuristic_override must be a boolean")
        heuristic_epochs = HEURISTIC_C_EPOCHS if self.official_profile == "C" else (5,)
        if self.heuristic_override and (not official or not self.harness_enabled or
                self.official_candidate_epochs not in heuristic_epochs or max(self.history_windows) != 768 or
                max(self.min_validation, min(self.history_windows)//4) != 48 or self.max_train_seconds > 20):
            raise ValueError("Heuristic override requires the official 768/48/20second Harness and approved epochs")
        if self.harness_enabled:
            if self.deployment_validation != "future" or not self.training_preflight or not self.candidate_feasibility:
                raise ValueError("Harness requires future validation, training preflight and candidate feasibility")
            if self.decision_backend != "rules" or self.strategy_adaptation or self.selection_split == "task_specific":
                raise ValueError("Harness uses fixed whitelists, one client and no simulator-scenario routing")

    def to_dict(self):
        return asdict(self)

    def tree_options(self):
        return {"max_depth": self.tree_max_depth, "min_samples_leaf": self.tree_min_samples_leaf,
                "max_leaf_nodes": self.tree_max_leaf_nodes, "random_state": self.seed}

    def official_options(self):
        if self.model_type not in ("official", "official_mlp"):
            raise ValueError("Official options require model_type='official_mlp'")
        profile_type = self.official_profile
        if profile_type not in ("A", "B", "C"):
            raise ValueError("An explicit A/B/C profile is required before constructing an official model")
        from .official_model import OFFICIAL_PROFILES, default_package_path
        contract = OFFICIAL_PROFILES[profile_type]
        runtime = self.official_runtime_python or os.environ.get("ITE_OFFICIAL_RUNTIME_PYTHON", "").strip()
        if not runtime:
            runtime = str(Path(__file__).resolve().parents[1] / ".venv-official-a" / "Scripts" / "python.exe")
        return {"profile_type": profile_type, "runtime_python": runtime,
                "package_path": self.official_package_path or str(default_package_path(profile_type)),
                "checkpoint_path": self.official_checkpoint_path or None,
                "classes": contract["classes"], "class_labels": contract["class_labels"],
                "candidate_epochs": self.official_candidate_epochs}

    @classmethod
    def from_dict(cls, values):
        unknown = set(values) - {field.name for field in fields(cls)}
        if unknown:
            raise ValueError(f"Unknown configuration fields: {sorted(unknown)}")
        values = dict(values)
        for name in ("candidate_alphas", "history_windows"):
            if name in values:
                values[name] = tuple(values[name])
        return cls(**values)

    @classmethod
    def load(cls, path):
        return cls.from_dict(json.loads(Path(path).read_text(encoding="utf-8")))
