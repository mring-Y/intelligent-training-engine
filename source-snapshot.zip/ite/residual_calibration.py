"""A bounded linear correction learned from a preceding released C train batch."""

import hashlib

import numpy as np

from .engine_balance import POLICY as SAMPLER_POLICY, select_indices


MODULE = "input_gate_residual_calibration_v1"
ROWS = SAMPLER_POLICY["rows"]
WIDTH = 37
RIDGE = .01
POLICY = {
    "kind": MODULE,
    "features": ["gated_mlp_hidden_32", "mlp_normalized_current_settings_3", "scaled_uplift", "intercept"],
    "target": "scaled_positive_residual_capped_at_uplift",
    "ridge_average_squared_loss": RIDGE,
    "penalize_intercept": False,
    "source": "preceding_released_official_train_batch_excluding_gradient_engines",
    "maximum_rows": ROWS,
}
SOURCE_FIELDS = {"source_step", "gradient_source_step", "rows", "engines",
                 "ids_sha256", "inputs_sha256", "targets_sha256", "train_sha256"}


def array_digest(array):
    return hashlib.sha256(np.asarray(array, dtype="<f8").tobytes()).hexdigest()


def validate_source(source):
    if not isinstance(source, dict) or set(source) != SOURCE_FIELDS:
        raise ValueError("incomplete residual calibration provenance")
    step, gradient = source["source_step"], source["gradient_source_step"]
    rows, engines = source["rows"], source["engines"]
    if (type(step) is not int or type(gradient) is not int or step < 0 or gradient != step + 1
            or type(rows) is not int or type(engines) is not int
            or not 0 <= engines <= rows <= ROWS or (engines == 0) != (rows == 0)):
        raise ValueError("invalid residual calibration source steps or counts")
    for key in ("ids_sha256", "inputs_sha256", "targets_sha256", "train_sha256"):
        digest = source[key]
        if not isinstance(digest, str) or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
            raise ValueError("invalid residual calibration provenance digest")


def prepare_source(batch, gradient_ids, group_for_id, train_sha256):
    if not isinstance(batch, dict) or set(batch) != {"x", "y", "ids", "source_step", "gradient_source_step"}:
        raise ValueError("residual calibration requires the preceding released train batch")
    x, y, ids = np.asarray(batch["x"], dtype=np.float64), np.asarray(batch["y"], dtype=np.float64), batch["ids"]
    if (not isinstance(ids, (list, tuple)) or x.shape != (len(ids), 24) or y.shape != (len(ids),)
            or not np.isfinite(x).all() or not np.isfinite(y).all() or np.any(y < 0)
            or any(not isinstance(i, str) or i not in group_for_id for i in ids) or len(set(ids)) != len(ids)):
        raise ValueError("residual calibration rows must be distinct, finite locked official train rows")
    excluded = {group_for_id[i] for i in gradient_ids}
    chosen = np.asarray([i for i, identity in enumerate(ids) if group_for_id[identity] not in excluded], dtype=int)
    if len(chosen) > ROWS:
        balanced, _ = select_indices([ids[i] for i in chosen], group_for_id)
        chosen = chosen[balanced]
    x, y, ids = x[chosen], y[chosen], [ids[i] for i in chosen]
    audit = {
        "source_step": batch["source_step"], "gradient_source_step": batch["gradient_source_step"],
        "rows": len(ids), "engines": len({group_for_id[i] for i in ids}),
        "ids_sha256": hashlib.sha256("\n".join(ids).encode()).hexdigest(),
        "inputs_sha256": array_digest(x), "targets_sha256": array_digest(y), "train_sha256": train_sha256,
    }
    validate_source(audit)
    return {"x": x, "y": y, "ids": ids}, audit


def design_matrix(hidden, settings, scaled_uplift):
    return np.column_stack((hidden, settings, scaled_uplift, np.ones(len(hidden))))


def correction_targets(parent, adapted, targets, target_scale):
    parent, adapted, targets = (np.asarray(v, dtype=np.float64) for v in (parent, adapted, targets))
    return np.clip(adapted - targets, 0., np.maximum(adapted - parent, 0.)) / target_scale


class ResidualCalibration:
    def __init__(self, coefficients, provenance, positive_rows):
        validate_source(provenance)
        self.coefficients = np.asarray(coefficients, dtype=np.float64).copy()
        if (self.coefficients.shape != (WIDTH,) or not np.isfinite(self.coefficients).all()
                or type(positive_rows) is not int or not 0 <= positive_rows <= provenance["rows"]
                or (positive_rows == 0 and np.any(self.coefficients))):
            raise ValueError("invalid residual calibration coefficients or supervision count")
        self.coefficients.flags.writeable = False
        self.audit = {**provenance, "policy": dict(POLICY), "positive_target_rows": positive_rows,
                      "coefficients_sha256": array_digest(self.coefficients)}

    @classmethod
    def fit(cls, design, targets, provenance):
        design, targets = np.asarray(design, dtype=np.float64), np.asarray(targets, dtype=np.float64)
        validate_source(provenance)
        rows = provenance["rows"]
        if (design.shape != (rows, WIDTH) or targets.shape != (rows,) or not np.isfinite(design).all()
                or not np.isfinite(targets).all() or np.any(targets < 0) or np.any(design[:, -1] != 1.)):
            raise ValueError("invalid residual calibration design or targets")
        positive = int(np.count_nonzero(targets))
        coefficients = np.zeros(WIDTH)
        if positive:
            penalty = np.eye(WIDTH) * (RIDGE * rows)
            penalty[-1, -1] = 0.
            coefficients = np.linalg.solve(design.T @ design + penalty, design.T @ targets)
        return cls(coefficients, provenance, positive)

    def apply(self, hidden, settings, parent, adapted, target_scale):
        uplift = adapted - parent
        if uplift <= 0 or not self.audit["positive_target_rows"]:
            return adapted
        terms = design_matrix(hidden.reshape(1, 32), settings.reshape(1, 3), [uplift / target_scale])
        adjustment = float((terms @ self.coefficients)[0]) * target_scale
        if adjustment <= 0.:
            return adapted
        if adjustment >= uplift:
            return parent
        return max(parent, adapted - adjustment)
