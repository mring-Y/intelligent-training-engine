"""Explicit file mappings and a predict-before-label streaming boundary.

File providers retain one bounded feature batch and requested pending labels.
The validation pass retains an O(samples) ID set and O(batches) sizes; it never
retains the full feature/target stream. Initial fitting data is materialized,
with a configurable row limit. No offline scorer is attached to file providers.
"""

import csv
import hashlib
import json
from abc import ABC, abstractmethod
from copy import deepcopy
from dataclasses import asdict, dataclass
from itertools import groupby
from pathlib import Path
from typing import Protocol

import numpy as np

from .data import InitialData, PublicBatch, ReleasedLabels
from .labeling import LabelAvailability


@dataclass(frozen=True)
class ColumnMapping:
    features: tuple
    target: str
    sample_id: str
    batch: str

    def __post_init__(self):
        object.__setattr__(self, "features", tuple(self.features))
        columns = (*self.features, self.target, self.sample_id, self.batch)
        if (not self.features or any(not isinstance(c, str) or not c.strip() for c in columns)
                or len(set(columns)) != len(columns)):
            raise ValueError("Features, target, id and batch must be explicit distinct columns")


@dataclass(frozen=True)
class FileLabelAvailability(LabelAvailability):
    batch_sizes: tuple = ()
    labelable_batch_sizes: tuple | None = None

    def capacity(self, frozen_at, step, deadline):
        end = min(deadline, self.last_step)
        in_flight = sum(source > frozen_at and due <= end for source, due in self.outstanding)
        first = max(0, step + 1, frozen_at + 1)
        last = end - self.delay
        sizes = self.batch_sizes if self.labelable_batch_sizes is None else self.labelable_batch_sizes
        available = sum(min(size, self.per_batch) for size in sizes[first:last + 1]) if last >= first else 0
        return in_flight + (available if self.remaining is None else min(self.remaining, available))


class OfflineScorer(Protocol):
    """Optional isolated evaluator, supplied separately after online execution.

    Classification evaluators additionally return integer tp/tn/fp/fn counts.
    Targets and drift truth from this interface never enter the controller.
    """

    def score(self, predictions): ...

    def classification_counts(self, predictions): ...


class OfficialDataProvider(ABC):
    """Online interface. Scoring is a separate, optional Runner argument.

    Public metadata: n_features, batch_sizes, label_delay, max_labels, and
    pending_schedule. IDs are unique nonnegative int64 values. Steps are dense,
    zero-based, ordered batches. Requests apply to the current committed batch.
    A provider is single-use, and must not reveal the next batch before commit.
    """

    @abstractmethod
    def initial_data(self):
        pass

    @abstractmethod
    def iter_batches(self):
        pass

    @abstractmethod
    def commit_predictions(self, step, sample_ids, predictions):
        pass

    @abstractmethod
    def request_labels(self, sample_ids, step):
        pass

    @abstractmethod
    def release_labels(self, step):
        pass

    @property
    @abstractmethod
    def pending_schedule(self):
        pass

    def label_availability(self, remaining, per_batch):
        own_remaining = None if self.max_labels is None else max(0, self.max_labels - self.total_requested)
        if own_remaining is not None:
            remaining = own_remaining if remaining is None else min(remaining, own_remaining)
        return FileLabelAvailability(remaining, per_batch, len(self.batch_sizes) - 1,
                                     self.label_delay, self.pending_schedule, self.batch_sizes,
                                     getattr(self, "label_batch_sizes", None))

    def provenance(self):
        """Offline audit metadata, never part of controller observations.

        Custom providers inherit this minimal description and may add their
        own immutable source fingerprints. Injection always remains provider
        kind, including an explicitly injected simulation adapter.
        """
        return {"kind": "provider", "class": type(self).__name__, "n_features": self.n_features,
                "batch_sizes": list(self.batch_sizes), "label_delay": self.label_delay,
                "max_labels": self.max_labels}


class SimulationDataProvider(OfficialDataProvider):
    """Compatibility adapter: legacy RNG, oracle and scoring remain unchanged."""

    def __init__(self, simulation, config):
        self._simulation = simulation
        self.n_features = config.n_features
        self.batch_sizes = tuple(len(b.sample_ids) for b in simulation.batches)
        self.label_delay = config.label_delay
        self.max_labels = config.max_labels if config.label_mode == "budgeted" else None
        self.offline_scorer = simulation.scorer
        self._current, self._committed, self._started = None, False, False

    def initial_data(self):
        return self._simulation.initial

    def iter_batches(self):
        if self._started:
            raise RuntimeError("A simulation provider can only be consumed once")
        self._started = True
        for batch in self._simulation.batches:
            self._current, self._committed = batch, False
            yield batch
            if not self._committed:
                raise ValueError("Predictions must be committed before advancing the stream")

    def commit_predictions(self, step, sample_ids, predictions):
        if (self._current is None or step != self._current.step or self._committed
                or not np.array_equal(sample_ids, self._current.sample_ids)
                or np.shape(predictions) != (len(self._current.sample_ids),)
                or not np.isfinite(predictions).all()):
            raise ValueError("Commit must contain finite predictions for the current batch")
        self._committed = True

    def _check_commit(self, step):
        if self._current is None or self._current.step != step or not self._committed:
            raise ValueError("Predictions must be committed at the current stream clock")

    def request_labels(self, sample_ids, step):
        self._check_commit(step)
        return self._simulation.oracle.request(sample_ids, step)

    def release_labels(self, step):
        self._check_commit(step)
        return self._simulation.oracle.release(step)

    @property
    def pending_schedule(self):
        return self._simulation.oracle.pending_schedule

    @property
    def total_requested(self):
        return self._simulation.oracle.total_requested


def _integer(value, name):
    # String parsing prevents silent float truncation and int64 overflow.
    if isinstance(value, (bool, np.bool_)):
        raise ValueError(f"Invalid {name}")
    try:
        parsed = int(str(value))
    except (TypeError, ValueError):
        raise ValueError(f"{name} must be a nonnegative integer") from None
    if not 0 <= parsed <= np.iinfo(np.int64).max:
        raise ValueError(f"{name} must fit nonnegative int64")
    return parsed


def _file_fingerprint(path):
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
            size += len(block)
    return {"path": str(path.resolve()), "sha256": digest.hexdigest(), "bytes": size}


def _array_fingerprint(array):
    array = np.ascontiguousarray(array)
    header = {"dtype": array.dtype.str, "shape": list(array.shape)}
    digest = hashlib.sha256(json.dumps(header, sort_keys=True, separators=(",", ":")).encode("utf-8"))
    digest.update(memoryview(array).cast("B"))
    return {**header, "sha256": digest.hexdigest(), "bytes": array.nbytes}


class _FileDataProvider(OfficialDataProvider):
    def __init__(self, path, mapping, *, initial=None, initial_train_path=None,
                 initial_validation_path=None, label_delay=2, max_labels=None,
                 read_batch_size=1024, max_batch_rows=100000, max_initial_rows=1000000):
        if not isinstance(mapping, ColumnMapping):
            raise ValueError("An explicit ColumnMapping is required")
        for name, value, minimum in (("label_delay", label_delay, 0),
                                     ("read_batch_size", read_batch_size, 1),
                                     ("max_batch_rows", max_batch_rows, 1),
                                     ("max_initial_rows", max_initial_rows, 4)):
            if type(value) is not int or value < minimum:
                raise ValueError(f"Invalid {name}")
        if max_labels is not None and (type(max_labels) is not int or max_labels < 0):
            raise ValueError("max_labels must be nonnegative or None")
        self.path, self.mapping = Path(path), mapping
        self.n_features = len(mapping.features)
        self.label_delay, self.max_labels = label_delay, max_labels
        self.read_batch_size = read_batch_size
        self._max_batch_rows, self._max_initial_rows = max_batch_rows, max_initial_rows
        self._seen_ids = set()
        self._quality_audit = {
            "imputation_method": "finite_initial_train_median",
            "initial_train_medians": [],
            "initial": {"train": self._empty_quality_bucket(),
                        "validation": self._empty_quality_bucket()},
            "stream": self._empty_quality_bucket(),
        }
        self._missing_stream_features = []
        files = (initial_train_path, initial_validation_path)
        if initial is not None:
            if any(p is not None for p in files):
                raise ValueError("Choose injected initial data or separate initial files")
            raw_initial_fingerprints = {
                name: _array_fingerprint(getattr(initial, name))
                for name in ("train_x", "train_y", "validation_x", "validation_y")}
            initial = self._prepare_injected_initial(initial)
        elif any(p is None for p in files):
            raise ValueError("Both separate initial training and validation files are required")
        else:
            resolved = [self.path.resolve(), *(Path(p).resolve() for p in files)]
            if len(set(resolved)) != 3:
                raise ValueError("Training, validation and stream files must be separate")
            train_x, train_y, train_reasons = self._load_initial(
                Path(initial_train_path), self._quality_audit["initial"]["train"])
            self._fit_feature_medians(train_x)
            train_x = self._impute_features(train_x, train_reasons,
                                            self._quality_audit["initial"]["train"])
            validation_x, validation_y, validation_reasons = self._load_initial(
                Path(initial_validation_path), self._quality_audit["initial"]["validation"])
            validation_x = self._impute_features(validation_x, validation_reasons,
                                                 self._quality_audit["initial"]["validation"])
            initial = InitialData(train_x, train_y, validation_x, validation_y)
            raw_initial_fingerprints = None
        self._initial = self._validate_initial(initial)
        self._quality_audit["initial_train_medians"] = self._feature_medians.tolist()
        if all(p is not None for p in files):
            self._initial_provenance = {"kind": "files", "train": _file_fingerprint(Path(files[0])),
                                        "validation": _file_fingerprint(Path(files[1]))}
        else:
            self._initial_provenance = {"kind": "arrays", **raw_initial_fingerprints}
        sizes, label_sizes = [], []
        for sample_id, step, _, target in self._parsed_rows(
                self.path, audit=self._quality_audit["stream"]):
            if sample_id in self._seen_ids:
                raise ValueError(f"Duplicate sample id {sample_id}")
            self._seen_ids.add(sample_id)
            if step == len(sizes):
                sizes.append(0)
                label_sizes.append(0)
            if step != len(sizes) - 1:
                raise ValueError("Batches must be contiguous, ordered and zero-based")
            sizes[-1] += 1
            if target is not None:
                label_sizes[-1] += 1
            if sizes[-1] > max_batch_rows:
                raise ValueError("Stream batch exceeds max_batch_rows")
        if not sizes:
            raise ValueError("Stream must contain at least one batch")
        self.batch_sizes = tuple(sizes)
        self.label_batch_sizes = tuple(label_sizes)
        self._quality_audit["stream"]["missing_feature_columns"] = list(self._missing_stream_features)
        self._stream_provenance = _file_fingerprint(self.path)
        stat = self.path.stat()
        self._file_stat = (stat.st_size, stat.st_mtime_ns)
        self._started = False
        self._current = None
        self._current_records = {}
        self._committed = False
        self._requested, self._pending = set(), []

    def provenance(self):
        return {**super().provenance(), "column_mapping": {
            **asdict(self.mapping), "features": list(self.mapping.features)},
                "stream": deepcopy(self._stream_provenance),
                "initial_data": deepcopy(self._initial_provenance),
                "data_quality": deepcopy(self._quality_audit)}

    def _empty_quality_bucket(self):
        return {"rows": 0, "missing_targets": 0, "missing_targets_skipped": 0,
                "feature_values_imputed": [0] * self.n_features,
                "missing_feature_values": [0] * self.n_features,
                "nonfinite_feature_values": [0] * self.n_features,
                "invalid_feature_values": [0] * self.n_features,
                "float32_overflow_values": [0] * self.n_features,
                "max_abs_feature_values": [0.0] * self.n_features}

    @staticmethod
    def _coerce_target(value):
        if value is None or (isinstance(value, str) and not value.strip()):
            return None
        try:
            target = float(value)
        except (TypeError, ValueError, OverflowError):
            return None
        return target if np.isfinite(target) else None

    def _raw_features(self, row):
        values, reasons = [], []
        for column in self.mapping.features:
            value = row.get(column)
            if value is None or (isinstance(value, str) and not value.strip()):
                values.append(np.nan)
                reasons.append("missing")
                continue
            try:
                value = float(value)
            except (TypeError, ValueError, OverflowError):
                values.append(np.nan)
                reasons.append("invalid")
                continue
            if not np.isfinite(value):
                values.append(np.nan)
                reasons.append("nonfinite")
            else:
                values.append(value)
                reasons.append(None)
        return np.asarray(values, dtype=float), reasons

    def _fit_feature_medians(self, features):
        features = np.asarray(features, dtype=float)
        if features.ndim != 2 or features.shape[1] != self.n_features:
            raise ValueError("Initial training features have invalid dimensions")
        medians = []
        for index, name in enumerate(self.mapping.features):
            finite = features[np.isfinite(features[:, index]), index]
            if finite.size == 0:
                raise ValueError(f"Initial training has no finite values for feature {name}")
            median = float(np.median(finite))
            if not np.isfinite(median):
                raise ValueError(f"Cannot derive finite median for feature {name}")
            medians.append(median)
        self._feature_medians = np.asarray(medians, dtype=float)

    def _impute_features(self, features, reasons, audit=None):
        values = np.asarray(features, dtype=float).copy()
        if audit is not None:
            for index in range(self.n_features):
                finite_values = values[:, index][np.isfinite(values[:, index])]
                if finite_values.size:
                    audit["max_abs_feature_values"][index] = max(
                        audit["max_abs_feature_values"][index], float(np.max(np.abs(finite_values))))
                    audit["float32_overflow_values"][index] += int(
                        np.count_nonzero(np.abs(finite_values) > np.finfo(np.float32).max))
        for row_index, row_reasons in enumerate(reasons):
            for index, reason in enumerate(row_reasons):
                if reason is None:
                    continue
                if audit is not None:
                    audit["feature_values_imputed"][index] += 1
                    if reason == "missing":
                        audit["missing_feature_values"][index] += 1
                    elif reason == "nonfinite":
                        audit["nonfinite_feature_values"][index] += 1
                    else:
                        audit["invalid_feature_values"][index] += 1
                values[row_index, index] = self._feature_medians[index]
        return values

    def _prepare_injected_initial(self, initial):
        if not isinstance(initial, InitialData):
            raise ValueError("InitialData is required")
        raw_splits = []
        for name, raw_x, raw_y in (("train", initial.train_x, initial.train_y),
                                   ("validation", initial.validation_x, initial.validation_y)):
            x, y = np.asarray(raw_x, dtype=float), np.asarray(raw_y, dtype=float)
            if x.ndim != 2 or x.shape[1] != self.n_features or y.ndim != 1 or len(x) != len(y):
                raise ValueError("Initial data must have aligned feature and target shapes")
            audit = self._quality_audit["initial"][name]
            audit["rows"] = len(y)
            valid_targets = np.isfinite(y)
            audit["missing_targets_skipped"] = int(np.count_nonzero(~valid_targets))
            x, y = x[valid_targets], y[valid_targets]
            reasons = [[None if np.isfinite(value) else "nonfinite" for value in row] for row in x]
            raw_splits.append((x, y, reasons, audit))
        self._fit_feature_medians(raw_splits[0][0])
        prepared = []
        for x, y, reasons, audit in raw_splits:
            prepared.append((self._impute_features(x, reasons, audit), y))
        return InitialData(prepared[0][0], prepared[0][1], prepared[1][0], prepared[1][1])

    def _validate_initial(self, initial):
        if not isinstance(initial, InitialData):
            raise ValueError("InitialData is required")
        arrays = []
        for x, y in ((initial.train_x, initial.train_y), (initial.validation_x, initial.validation_y)):
            x, y = np.asarray(x, dtype=float), np.asarray(y, dtype=float)
            if (x.ndim != 2 or x.shape[1] != self.n_features or y.ndim != 1 or len(x) != len(y)
                    or not 4 <= len(y) <= self._max_initial_rows or not np.isfinite(x).all()
                    or not np.isfinite(y).all()):
                raise ValueError("Initial data must have finite aligned features and targets")
            x, y = x.copy(), y.copy()
            x.setflags(write=False)
            y.setflags(write=False)
            arrays.extend((x, y))
        return InitialData(*arrays)

    def _load_initial(self, path, audit):
        features, reasons, targets = [], [], []
        for row in self._read_rows(path, initial=True):
            audit["rows"] += 1
            if audit["rows"] > self._max_initial_rows:
                raise ValueError("Initial split exceeds max_initial_rows")
            if self.mapping.sample_id in row:
                sample_id = _integer(row[self.mapping.sample_id], "sample id")
                if sample_id in self._seen_ids:
                    raise ValueError(f"Duplicate initial sample id {sample_id}")
                self._seen_ids.add(sample_id)
            target = self._coerce_target(row.get(self.mapping.target))
            if target is None:
                audit["missing_targets_skipped"] += 1
                continue
            values, row_reasons = self._raw_features(row)
            features.append(values)
            reasons.append(row_reasons)
            targets.append(target)
        return (np.asarray(features, dtype=float).reshape((-1, self.n_features)),
                np.asarray(targets, dtype=float), reasons)

    def _parsed_rows(self, path, initial=False, audit=None):
        for row in self._read_rows(path, initial=initial):
            if audit is not None:
                audit["rows"] += 1
            raw_features, reasons = self._raw_features(row)
            features = self._impute_features(raw_features.reshape(1, -1), [reasons], audit)[0]
            target = self._coerce_target(row.get(self.mapping.target))
            if audit is not None and target is None:
                audit["missing_targets"] += 1
            sample_id = (_integer(row.get(self.mapping.sample_id), "sample id")
                         if not initial else
                         (_integer(row[self.mapping.sample_id], "sample id")
                          if self.mapping.sample_id in row else None))
            step = 0 if initial else _integer(row.get(self.mapping.batch), "batch")
            yield sample_id, step, features, target

    def _required_columns(self, initial):
        return (*self.mapping.features, self.mapping.target) if initial else (
            self.mapping.sample_id, self.mapping.batch)

    def initial_data(self):
        return self._initial

    def iter_batches(self):
        if self._started:
            raise RuntimeError("A file provider can only be consumed once")
        self._started = True
        stat = self.path.stat()
        if (stat.st_size, stat.st_mtime_ns) != self._file_stat:
            raise ValueError("Stream changed after validation")
        for step, rows in groupby(self._parsed_rows(self.path), key=lambda row: row[1]):
            records = []
            for row in rows:
                records.append(row)
                if len(records) > self._max_batch_rows:
                    raise ValueError("Stream batch exceeds max_batch_rows")
            ids = np.asarray([r[0] for r in records], dtype=np.int64)
            features = np.asarray([r[2] for r in records])
            ids.setflags(write=False)
            features.setflags(write=False)
            self._current = PublicBatch(step, ids, features)
            self._current_records = {r[0]: (step, r[2], r[3]) for r in records}
            self._committed = False
            yield self._current
            if not self._committed:
                raise ValueError("Predictions must be committed before advancing the stream")
        self._current_records = {}

    def _check_current(self, step, require_commit=True):
        if self._current is None or step != self._current.step:
            raise ValueError("Operation must use the current stream clock")
        if require_commit and not self._committed:
            raise ValueError("Predictions must be committed before requesting or releasing labels")

    def commit_predictions(self, step, sample_ids, predictions):
        self._check_current(step, require_commit=False)
        ids = [_integer(i, "sample id") for i in sample_ids]
        values = np.asarray(predictions)
        if (self._committed or ids != self._current.sample_ids.tolist()
                or values.shape != (len(ids),) or not np.isfinite(values).all()):
            raise ValueError("Commit must contain one finite prediction for each current ID in order")
        self._committed = True

    def request_labels(self, sample_ids, step):
        self._check_current(step)
        ids = [_integer(i, "sample id") for i in sample_ids]
        if (len(ids) != len(set(ids)) or any(i in self._requested for i in ids)
                or any(i not in self._current_records for i in ids)):
            raise ValueError("Requested IDs must be unique, new and in the current committed batch")
        available = len(ids) if self.max_labels is None else max(0, self.max_labels - self.total_requested)
        accepted = []
        for sample_id in ids:
            if len(accepted) >= available:
                break
            if self._current_records[sample_id][2] is None:
                continue
            accepted.append(sample_id)
        for sample_id in accepted:
            self._requested.add(sample_id)
            self._pending.append((step + self.label_delay, sample_id, self._current_records[sample_id]))
        return len(accepted)

    def release_labels(self, step):
        self._check_current(step)
        ready = [record for record in self._pending if record[0] <= step]
        self._pending = [record for record in self._pending if record[0] > step]
        if not ready:
            return None
        return ReleasedLabels(np.asarray([r[1] for r in ready]), np.asarray([r[2][1] for r in ready]),
                              np.asarray([r[2][2] for r in ready]), np.asarray([r[2][0] for r in ready]))

    @property
    def total_requested(self):
        return len(self._requested)

    @property
    def pending_schedule(self):
        return tuple((record[0], due) for due, _, record in self._pending)


class CSVDataProvider(_FileDataProvider):
    def _read_rows(self, path, initial=False):
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            columns = reader.fieldnames or []
            if len(set(columns)) != len(columns) or not set(self._required_columns(initial)).issubset(columns):
                raise ValueError("Missing or duplicate mapped CSV columns")
            if not initial:
                self._missing_stream_features = [name for name in self.mapping.features if name not in columns]
            for row in reader:
                if None in row:
                    raise ValueError("CSV row has missing or extra values")
                yield row


class ParquetDataProvider(_FileDataProvider):
    def _read_rows(self, path, initial=False):
        try:
            import pyarrow.parquet as pq
        except ImportError:
            raise ImportError("Parquet requires optional pyarrow==22.0.0 (requirements-data.txt)") from None
        parquet = pq.ParquetFile(path)
        try:
            columns = parquet.schema_arrow.names
            if len(set(columns)) != len(columns) or not set(self._required_columns(initial)).issubset(columns):
                raise ValueError("Missing or duplicate mapped Parquet columns")
            selected = list(self._required_columns(initial))
            if initial and self.mapping.sample_id in columns:
                selected.append(self.mapping.sample_id)
            if not initial:
                self._missing_stream_features = [name for name in self.mapping.features if name not in columns]
                selected.extend(name for name in self.mapping.features if name in columns)
                if self.mapping.target in columns:
                    selected.append(self.mapping.target)
            for batch in parquet.iter_batches(batch_size=self.read_batch_size, columns=selected, use_threads=False):
                yield from batch.to_pylist()
        finally:
            parquet.close()
