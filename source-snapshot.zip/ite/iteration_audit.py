"""Offline causal audit of decisions and independent future gates, never a controller input."""

from .harness import parse_action, validate_observation
import json


def audit_iterations(events, *, expected_batches=30):
    starts = [e for e in events if e["event"] == "run_started"]
    completions = [e for e in events if e["event"] == "run_completed"]
    if len(starts) != 1 or len(completions) != 1 or completions[0].get("stream_batches") != expected_batches:
        raise ValueError("A complete run requires one start and one completion")
    config = starts[0]["config"]
    min_validation, delay = config["min_validation"], config["label_delay"]
    predictions = [e for e in events if e["event"] == "prediction"]
    if [e["step"] for e in predictions] != list(range(expected_batches)):
        raise ValueError("Prediction batches are incomplete, duplicated or out of order")
    prediction_versions = {e["step"]: e["model_version"] for e in predictions}
    decisions, frozen, outcomes, attempts, calls = {}, {}, {}, {}, {}
    released_sources, requested_sources, claimed_decisions = {}, {}, set()
    requested_total = 0
    selection_rejections = 0
    for e in events:
        kind = e["event"]
        if kind == "harness_call":
            identifier = e["decision_id"]
            if identifier in calls:
                raise ValueError("Duplicate call for decision")
            calls[identifier] = e
            if e.get("token_accounting_mode") == "real" and e.get("status") == "ok":
                action = parse_action(e["raw_response"])
                if e.get("parsed_action") != {"action": action.action, "reason": action.reason}:
                    raise ValueError("Provider raw JSON differs from its parsed action")
        elif kind == "labels_requested":
            count = e["count"]
            if type(count) is not int or not 0 <= count <= predictions[e["step"]]["samples"] or e["step"] in requested_sources:
                raise ValueError("Invalid requested label count or duplicate request batch")
            requested_total += count
            if e["total"] != requested_total:
                raise ValueError("Requested label total is inconsistent")
            requested_sources[e["step"]] = count
        elif kind == "labels_released":
            sources = e.get("sources", [])
            if sum(s["count"] for s in sources) != e["count"]:
                raise ValueError("Missing source breakdown of released labels")
            for source in sources:
                if (type(source["count"]) is not int or source["count"] <= 0 or
                        source["source_step"] < 0 or source["source_step"] + delay > e["step"]):
                    raise ValueError("Labels released before their protocol delay")
                key = source["source_step"]
                released_sources[key] = released_sources.get(key, 0) + source["count"]
                if released_sources[key] > requested_sources.get(key, 0):
                    raise ValueError("Released labels exceed requests for their source batch")
        elif kind == "harness_decision":
            identifier = e["decision_id"]
            if identifier in decisions:
                raise ValueError("Duplicate decision ID")
            parse_action(json.dumps({"action": e["action"], "reason": e["reason"]}, ensure_ascii=False))
            validate_observation(e["observation"])
            call = calls.get(identifier)
            if (call is None or call.get("status") != "ok" or
                    call.get("parsed_action") != {"action": e["action"], "reason": e["reason"]} or
                    call.get("observation") != e["observation"] or call["step"] != e["step"]):
                raise ValueError("Decision does not match the recorded provider action")
            decisions[identifier] = e
        elif kind == "experiment_started" and "decision_id" in e:
            if e["decision_id"] not in decisions or not e.get("attempt_id") or e["attempt_id"] in attempts:
                raise ValueError("Experiment has no preceding decision or attempt ID")
            attempts[e["attempt_id"]] = e["decision_id"]
        elif kind == "candidate_frozen":
            identifier = e["candidate_id"]
            if (identifier in frozen or e.get("decision_id") not in decisions or
                    attempts.get(e.get("attempt_id")) != e.get("decision_id") or
                    e["decision_id"] in claimed_decisions or e["frozen_at"] != e["step"] or
                    e["selection_max_source_step"] + delay > e["frozen_at"]):
                raise ValueError("Candidate is not linked to a unique decision/attempt")
            if decisions[e["decision_id"]]["action"] == "DO_NOTHING":
                raise ValueError("DO_NOTHING cannot freeze a model")
            frozen[identifier] = e
            claimed_decisions.add(e["decision_id"])
        elif kind in ("deploy", "experiment_rejected") and e.get("reason") == "independent_future_labels":
            identifier = e["candidate_id"]
            candidate = frozen.get(identifier)
            if (candidate is None or identifier in outcomes or
                    e.get("decision_id") != candidate["decision_id"] or
                    e.get("attempt_id") != candidate["attempt_id"] or
                    not candidate["frozen_at"] < e["gate_min_source_step"] <= e["gate_max_source_step"] <= e["step"] or
                    e["frozen_at"] != candidate["frozen_at"] or e["gate_samples"] < min_validation or
                    e["gate_max_source_step"] + delay > e["step"] or
                    e["gate_samples"] > sum(count for source, count in released_sources.items()
                        if e["gate_min_source_step"] <= source <= e["gate_max_source_step"])):
                raise ValueError("Future gate lacks independent labels or matching causal IDs")
            if kind == "deploy" and (not e["accepted"] or
                    e["step"] + 1 < expected_batches and prediction_versions[e["step"] + 1] != e["model_version"]):
                raise ValueError("Deployment does not match next-batch prediction version")
            if kind == "experiment_rejected" and e["accepted"]:
                raise ValueError("Rejected gate cannot be accepted")
            outcomes[identifier] = e
        elif kind == "experiment_rejected" and e.get("reason") == "not_better_on_selection":
            selection_rejections += 1
    chains = [{"decision_id": candidate["decision_id"], "attempt_id": candidate["attempt_id"],
               "candidate_id": identifier, "action": decisions[candidate["decision_id"]]["action"],
               "decision_step": decisions[candidate["decision_id"]]["step"],
               "frozen_at": candidate["frozen_at"], "gate_step": outcome["step"],
               "gate_min_source_step": outcome["gate_min_source_step"],
               "gate_max_source_step": outcome["gate_max_source_step"],
               "gate_samples": outcome["gate_samples"], "accepted": outcome["accepted"]}
              for identifier, outcome in outcomes.items() for candidate in (frozen[identifier],)]
    if len(calls) != completions[0].get("llm_calls") or len(calls) > (config.get("max_llm_calls") or 10):
        raise ValueError("Call count does not match completion or its configured cap")
    return {"prediction_batches": len(predictions), "decisions": len(decisions), "training_or_rollback_attempts": len(attempts),
            "selection_rejections": selection_rejections, "candidates_frozen": len(frozen),
            "future_gate_chains": len(chains), "engineering_target_met": len(chains) >= 3,
            "official_eligibility_verified": False, "chains": chains,
            "all_decisions": [{key: e[key] for key in ("decision_id", "step", "action", "reason")}
                              for e in decisions.values()]}
