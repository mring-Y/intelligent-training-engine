"""External-parent CPU rounds and a separate JSONL prediction entry point."""

import argparse
from datetime import datetime, timezone
from functools import lru_cache
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import zipfile

import numpy as np

from .a_acetaldehyde_gate import (
    POLICY as A_CORRECTION_POLICY, continuation_trainer, frozen_template, is_acetaldehyde_checkpoint,
)
from .official_finetune import A_THREE_CLASS_HEAD
from .official_model import OfficialModelAdapter, OFFICIAL_PROFILES, default_package_path
from .official_sft_data import metrics, select_a_replay_reserve
from .official_sft_replay import replay_partition
from .platform_data import ARTIFACT_LIMIT, check_artifacts, checkpoint_metadata, json_value, read_dataset
from .tracking import source_metadata


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def runtime_default():
    return os.environ.get("ITE_OFFICIAL_RUNTIME_PYTHON", str(
        Path(__file__).resolve().parents[1] / ".venv-official-a/Scripts/python.exe"))


@lru_cache(maxsize=3)
def baseline_train_hashes(profile):
    # The adapter has already verified this exact package's pinned digest.
    # These identities anchor prior gradient use, never supply new gradients.
    with zipfile.ZipFile(default_package_path(profile)) as package:
        return frozenset(hashlib.sha256(json.loads(line)["id"].encode("utf-8")).hexdigest()
            for line in package.read("public/train.jsonl").decode("utf-8").splitlines() if line.strip())


def load_history(path, parent_digest, profile, *, baseline_history=None):
    if path is None:
        return b"", [], set()
    path = Path(path)
    if path.is_symlink() or not path.is_file() or path.stat().st_size > ARTIFACT_LIMIT:
        raise ValueError("parent history must be a bounded regular JSONL")
    raw = path.read_bytes()
    entries = [json_value(line) for line in raw.decode("utf-8").splitlines() if line.strip()]
    if baseline_history is not None and raw == baseline_history:
        return raw, entries, set()
    if (not entries or any(not isinstance(row, dict) for row in entries) or
            entries[-1].get("event") != "round_completed" or
            parent_digest not in (entries[-1].get("checkpoint_sha256"), entries[-1].get("parent_checkpoint_sha256")) or
            entries[-1].get("profile") != profile):
        raise ValueError("parent history does not bind the supplied parent checkpoint and profile")
    prefix, opened, last = bytearray(), None, None
    for line in raw.splitlines(keepends=True):
        if line.strip():
            row = json_value(line.decode("utf-8"))
            if row.get("event") == "round_started":
                if opened is not None:
                    raise ValueError("parent history has an unfinished round")
                expected = hashlib.sha256(prefix).hexdigest() if prefix else None
                if row.get("parent_history_sha256") != expected:
                    raise ValueError("parent history prefix digest mismatch or truncated history")
                if row.get("profile") != profile or (last is not None and
                        row.get("parent_checkpoint_sha256") not in
                        (last.get("checkpoint_sha256"), last.get("parent_checkpoint_sha256"))):
                    raise ValueError("parent history checkpoint chain mismatch")
                opened = row
            elif row.get("event") == "round_completed":
                if (opened is None or row.get("stage_id") != opened.get("stage_id") or
                        row.get("profile") != profile or
                        row.get("parent_checkpoint_sha256") != opened.get("parent_checkpoint_sha256")):
                    raise ValueError("parent history has an unbound round completion")
                last, opened = row, None
        prefix.extend(line)
    if opened is not None:
        raise ValueError("parent history ends before round completion")
    seen = set()
    for row in entries:
        for key in ("validation_id_hashes", "train_id_hashes", "baseline_training_id_hashes"):
            values = row.get(key, [])
            if not isinstance(values, list) or any(not isinstance(x, str) or len(x) != 64 for x in values):
                raise ValueError("invalid parent history source identities")
            seen.update(values)
    return raw, entries, seen


def run_round(profile, train, validation, parent, output, stage_id, runtime_python,
              *, parent_history=None, audit_output=None, label_provenance=None, require_parent_history=False,
              allow_training=True, a_trainable_policy="full", a_gate_template=None, c_module_policy=None):
    """Run the configured policy on explicitly provided data with no synthetic drift."""
    output = Path(output)
    audit = Path(audit_output) if audit_output is not None else output.with_name(output.name + ".audit")
    if output.exists() or output.is_symlink() or audit.exists() or audit.is_symlink():
        raise FileExistsError("round output and audit output must be new directories")
    if output.resolve().is_relative_to(audit.resolve()) or audit.resolve().is_relative_to(output.resolve()):
        raise ValueError("model artifacts and detailed audit directories must be separate")
    if profile not in OFFICIAL_PROFILES or not isinstance(stage_id, str) or not stage_id.strip() or len(stage_id) > 128:
        raise ValueError("an official profile and bounded nonempty stage ID are required")
    if type(allow_training) is not bool:
        raise ValueError("allow_training must be an explicit boolean")
    if a_trainable_policy != "full" and (profile != "A" or a_trainable_policy != A_THREE_CLASS_HEAD):
        raise ValueError("Unsupported A continuation policy")
    meta = checkpoint_metadata(parent)
    if meta["profile"] != profile:
        raise ValueError("parent checkpoint profile does not match the requested dataset")
    a_parent_gate = profile == "A" and is_acetaldehyde_checkpoint(Path(parent).read_bytes())
    use_a_correction = a_parent_gate or a_gate_template is not None
    if use_a_correction and (profile != "A" or a_trainable_policy != "full"):
        raise ValueError("A correction is restricted to full official A continuation")
    a_trainer = (continuation_trainer(frozen_template(Path(a_gate_template)))
                 if allow_training and a_gate_template is not None and not a_parent_gate else None)
    from .c_rbf_model import CRBFModel, fit_rbf_candidate, is_composite
    from .c_adapter_model import CInputAdapterModel, fit_adapter_candidate, is_input_adapter
    from .c_gate_model import (CGatedInputModel, GATE_MODULE, GATE_POLICIES, LOW_RUL_MODULE, STABLE_POLICIES,
                               fit_balanced_stable_head_candidate, fit_gated_candidate,
                               fit_low_rul_stable_head_candidate,
                               fit_residual_calibrated_candidate, fit_stable_head_candidate,
                               fit_supported_candidate, gate_policy, is_gated)
    from .c_stable_head import BALANCED_MODULE, MODULE as STABLE_MODULE, REPORT_CLOCKS, ROUND_POLICIES
    from .operating_support import MODULE as SUPPORT_MODULE
    from .residual_calibration import MODULE as RESIDUAL_MODULE
    module_policy = c_module_policy if c_module_policy is not None else os.environ.get("ITE_C_MODULE", "none")
    if not isinstance(module_policy, str) or module_policy not in (
            "none", "compact_rbf_v1", "input_adapter_v1", *GATE_POLICIES):
        raise ValueError("unsupported C module experiment")
    c_checkpoint = Path(parent).read_bytes() if profile == "C" else None
    gate_parent = c_checkpoint is not None and is_gated(c_checkpoint)
    adapter_parent = c_checkpoint is not None and is_input_adapter(c_checkpoint)
    rbf_parent = c_checkpoint is not None and not gate_parent and not adapter_parent and is_composite(c_checkpoint)
    if (gate_parent and module_policy not in ("none", *GATE_POLICIES)) or (adapter_parent and module_policy=="compact_rbf_v1") or (rbf_parent and module_policy in ("input_adapter_v1", *GATE_POLICIES)):
        raise ValueError("C input and residual modules cannot be combined")
    use_gate = profile == "C" and (module_policy in GATE_POLICIES or gate_parent)
    gated_policy = gate_policy(c_checkpoint, module_policy) if use_gate else None
    use_support = gated_policy == SUPPORT_MODULE
    use_stable_head = gated_policy in (*STABLE_POLICIES, LOW_RUL_MODULE)
    use_residual = use_stable_head or gated_policy == RESIDUAL_MODULE
    requires_balance = use_support or use_residual
    use_adapter = profile == "C" and not use_gate and (module_policy=="input_adapter_v1" or adapter_parent)
    use_rbf = profile == "C" and (module_policy=="compact_rbf_v1" or rbf_parent)
    loss_policy = os.environ.get("ITE_C_LOSS", "squared") if profile == "C" else "squared"
    if loss_policy not in ("squared", "official_anchor_l2"):
        raise ValueError("unsupported C loss experiment")
    if (use_rbf or use_adapter or use_gate) and loss_policy != "squared":
        raise ValueError("C module and loss experiments cannot be combined")
    from .engine_balance import NAME as BALANCED_SAMPLER
    gradient_sampler=os.environ.get("ITE_C_GRADIENT_SAMPLER", BALANCED_SAMPLER if requires_balance else "none") if profile=="C" else "none"
    if gradient_sampler not in ("none",BALANCED_SAMPLER) or (gradient_sampler!="none" and not use_gate):
        raise ValueError("gradient sampler requires the input gate module")
    if use_support and gradient_sampler != BALANCED_SAMPLER:
        raise ValueError("operating support requires the same-batch balanced gradient sampler")
    if use_residual and gradient_sampler != BALANCED_SAMPLER:
        raise ValueError("residual calibration requires the same-batch balanced gradient sampler")
    from .official_finetune import C_REFERENCE_SHA256
    reference_digest = C_REFERENCE_SHA256 if loss_policy == "official_anchor_l2" else None
    model = (CGatedInputModel.load(parent,runtime_python) if use_gate else CInputAdapterModel.load(parent,runtime_python) if use_adapter else CRBFModel.load(parent,runtime_python) if use_rbf else
        OfficialModelAdapter(OFFICIAL_PROFILES[profile]["task"], runtime_python,
            profile_type=profile, checkpoint_path=parent, candidate_epochs=2 if profile == "C" else 5))
    gate_reference_preparation=None
    if use_gate and allow_training:
        from .gate_reference import load_reference
        tick=time.perf_counter()
        reference=load_reference(model.package_path)
        gate_reference_preparation={"wall_seconds":time.perf_counter()-tick,
            "train_jsonl_sha256":reference.source_sha256,"selected_rows":len(reference.samples),
            "train_engines":len(set(reference.group_for_id.values())),"uses_targets":False}
    parent_digest = model.checkpoint_sha256
    is_official_start = parent_digest == model.package_info["checkpoint_sha256"].removeprefix("sha256:")
    with zipfile.ZipFile(model.package_path) as package:
        baseline_history = package.read("history.jsonl") if is_official_start else None
        profile_digest = hashlib.sha256(package.read(f"baselines/configs/{profile}.json")).hexdigest()
    if parent_history is None:
        sibling = Path(parent).with_name("history.jsonl")
        if sibling.is_file():
            parent_history = sibling
    history_raw, previous, seen = load_history(parent_history, parent_digest, profile, baseline_history=baseline_history)
    has_round_history = bool(previous and previous[-1].get("event") == "round_completed")
    if not history_raw and baseline_history is not None:
        # These are exact existing official epoch records, not reconstructed logs.
        history_raw = baseline_history
    anchor = baseline_train_hashes(profile)
    seen.update(anchor)
    if history_raw and not history_raw.endswith(b"\n"):
        history_raw += b"\n"
    accounting_complete = (previous[-1].get("future_accounting_complete") is True if has_round_history else
                           is_official_start and not require_parent_history)
    if any(row.get("event") == "round_completed" and row.get("stage_id") == stage_id for row in previous):
        raise ValueError("stage ID already exists in the supplied parent history")
    training = read_dataset(train, profile, meta["paths"])
    valid = read_dataset(validation, profile, meta["paths"])
    if set(training["ids"]) & set(valid["ids"]):
        raise ValueError("training and validation IDs overlap")
    train_hashes = [hashlib.sha256(identity.encode("utf-8")).hexdigest() for identity in training["ids"]]
    past_validation = {identity for row in previous for identity in row.get("validation_id_hashes", [])}
    if set(train_hashes) & past_validation:
        raise ValueError("previous validation identities cannot change role and enter training gradients")
    provenance = None
    if profile == "B":
        if label_provenance is None:
            raise ValueError("B requires explicit label provenance for the supplied RUL targets")
        path = Path(label_provenance)
        if path.is_symlink() or not path.is_file() or path.stat().st_size > 65536:
            raise ValueError("label provenance must be a bounded regular JSON file")
        declaration = json_value(path.read_text(encoding="utf-8"))
        if (not isinstance(declaration, dict) or declaration.get("status") not in ("draft", "approved") or
                not isinstance(declaration.get("method"), str) or not declaration["method"].strip()):
            raise ValueError("label provenance requires status and a nonempty method")
        provenance = {"sha256": digest(path), "declaration": declaration,
                      "approval_verified_by_this_adapter": False}
    hashed_ids = [hashlib.sha256(identity.encode("utf-8")).hexdigest() for identity in valid["ids"]]
    fresh = [i for i, identity in enumerate(hashed_ids) if identity not in seen]
    selected, reason = model, "independent_gate_retained_parent"
    summary = {"training_attempts": 0, "train_seconds": 0., "updates": 0, "records": []}
    source = source_metadata()
    reserve = None
    reserve_error = False
    if profile == "A":
        try:
            reserve = select_a_replay_reserve(training["rows"], valid["ids"])
        except ValueError:
            reserve_error = True
    excluded = set(reserve["ids"]) if reserve is not None else set()
    train_indices = np.asarray([i for i, identity in enumerate(training["ids"]) if identity not in excluded], dtype=int)
    audit.parent.mkdir(parents=True, exist_ok=True)
    audit.mkdir(exist_ok=False)
    try:
        if not allow_training:
            reason = "model_requested_retain"
        elif profile == "B":
            reason = "B_static_policy"
        elif not accounting_complete:
            reason = "missing_parent_history_for_fresh_future_accounting"
        elif len(fresh) < 48 or len(train_indices) < 12:
            reason = "insufficient_fresh_future_capacity"
        elif reserve_error:
            reason = "insufficient_class_balanced_replay_reserve"
        else:
            indices = np.asarray(fresh, dtype=int)
            data = {"profile": profile, "task": model.task, "unit": model.target_unit,
                "x": valid["x"][indices], "y": valid["y"][indices],
                "ids": [valid["ids"][i] for i in fresh], "groups": ["explicit_validation"] * len(fresh),
                "scale": model.std, "loss_scale": 1. if profile == "A" else max(float(np.var(training["y"])), 1e-12)}
            if reserve is not None:
                data["replay_reserve"] = reserve
            stream = {"x": training["x"][train_indices], "y": training["y"][train_indices],
                "ids": [training["ids"][i] for i in train_indices], "role": "explicit_platform_train"}
            initial = (CGatedInputModel.from_bytes(model.checkpoint_bytes,runtime_python) if use_gate else CInputAdapterModel.from_bytes(model.checkpoint_bytes,runtime_python) if use_adapter else
                CRBFModel.from_bytes(model.checkpoint_bytes,runtime_python) if use_rbf else OfficialModelAdapter.from_state(model.state()))
            gated_trainers = {GATE_MODULE:fit_gated_candidate, SUPPORT_MODULE:fit_supported_candidate,
                              RESIDUAL_MODULE:fit_residual_calibrated_candidate, STABLE_MODULE:fit_stable_head_candidate,
                              BALANCED_MODULE:fit_balanced_stable_head_candidate,
                              LOW_RUL_MODULE:fit_low_rul_stable_head_candidate}
            trainer_options = {"trainer":gated_trainers[gated_policy]} if use_gate else {"trainer":fit_adapter_candidate} if use_adapter else {"trainer":fit_rbf_candidate} if use_rbf else {}
            if a_trainer is not None:
                trainer_options["trainer"] = a_trainer
            summary = replay_partition(data, list(range(len(fresh))), "train", "stable", audit / "policy",
                initial,
                lambda _: {"action": "RETRAIN_LARGE" if profile == "A" else "DO_NOTHING",
                    "reason": "已确认A step7回放或C规则候选；仍须独立未来门控。", "source": "approved_host_policy"},
                decision_steps=(7,) if profile == "A" else tuple(range(3, 10)),
                action_profile="official_finetune", heuristic_override=profile == "C",
                a_replay_policy="class_balanced_official_train" if profile == "A" else "none",
                training_stream=stream, candidate_loss_policy=loss_policy, c_gradient_sampler=gradient_sampler,
                a_trainable_policy=a_trainable_policy, **trainer_options)
            selected = (CGatedInputModel.load(audit / "policy/selected.npz",runtime_python) if use_gate else CInputAdapterModel.load(audit / "policy/selected.npz",runtime_python) if use_adapter else
                CRBFModel.load(audit / "policy/selected.npz",runtime_python) if use_rbf else
                OfficialModelAdapter(model.task, runtime_python, profile_type=profile,
                    checkpoint_path=audit / "policy/selected.npz", candidate_epochs=model.candidate_epochs))
            if summary["updates"]:
                reason = "independent_future_gate_accepted"
        if digest(parent) != parent_digest:
            raise ValueError("supplied parent checkpoint changed during the round")
        before = metrics(profile, valid["y"], model.predict(valid["x"]))
        after = metrics(profile, valid["y"], selected.predict(valid["x"]))
        if len(fresh) >= 48:
            fresh_indices = np.asarray(fresh, dtype=int)
            fresh_before = metrics(profile, valid["y"][fresh_indices], model.predict(valid["x"][fresh_indices]))
            fresh_after = metrics(profile, valid["y"][fresh_indices], selected.predict(valid["x"][fresh_indices]))
        else:
            fresh_before = fresh_after = None
        completed = {"event": "round_completed", "stage_id": stage_id, "profile": profile,
            "gradient_sampler":gradient_sampler,
            "loss_policy":loss_policy, "reference_checkpoint_sha256":reference_digest,
            "parent_checkpoint_sha256": parent_digest, "checkpoint_sha256": selected.checkpoint_sha256,
            "initial_steps": model.steps, "final_steps": selected.steps,
            "initial_epochs": model.epochs, "final_epochs": selected.epochs,
            "training_performed": summary["training_attempts"] > 0,
            "training_attempts": summary["training_attempts"], "accepted_updates": summary["updates"],
            "selection_reason": reason, "validation_id_hashes": [hashed_ids[i] for i in fresh],
            "train_id_hashes": train_hashes,
            "baseline_training_id_hashes": sorted(anchor) if not has_round_history else [],
            "future_accounting_complete": accounting_complete,
            "train_sha256": training["sha256"], "validation_sha256": valid["sha256"],
            "source": source, "created_at": datetime.now(timezone.utc).isoformat()}
        if use_adapter or use_gate:
            completed.update(initial_module_steps=model.module.steps if model.module is not None else 0,
                final_module_steps=selected.module.steps if selected.module is not None else 0,
                initial_module_epochs=model.module.epochs if model.module is not None else 0,
                final_module_epochs=selected.module.epochs if selected.module is not None else 0)
        if use_stable_head:
            previous_head = getattr(model, "stable_head", None)
            stable_head = getattr(selected, "stable_head", None)
            completed.update(initial_stable_head_steps=(previous_head or model).steps,
                             final_stable_head_steps=(stable_head or selected).steps,
                             initial_stable_head_epochs=(previous_head or model).epochs,
                             final_stable_head_epochs=(stable_head or selected).epochs)
        current = [{"event": "round_started", "stage_id": stage_id, "profile": profile,
            "parent_checkpoint_sha256": parent_digest,
            "parent_history_sha256": hashlib.sha256(history_raw).hexdigest() if history_raw else None}]
        for record in summary["records"]:
            evidence = record.get("evidence", {})
            current.append({"event": "maintenance_decision", "stage_id": stage_id,
                "decision_id": record["decision_id"], "step": record["step"], "action": record["action"],
                "rejection": record.get("rejection"),
                "parent_checkpoint_sha256": evidence.get("candidate_parent_checkpoint"),
                "candidate_checkpoint_sha256": evidence.get("candidate_checkpoint"),
                "experiment": {k: evidence[k] for k in ("train_samples", "screening_samples", "train_seconds",
                    "trainable_policy", "parent_adam_steps", "candidate_adam_steps", "fit_audit",
                    "selection_loss", "incumbent_loss") if k in evidence},
                "future_gate": {k: v for k, v in evidence.get("future_gate", {}).items() if k != "source_ids"}})
        current.append(completed)
        report = {"format": "ite.cpu-continuation-report.v1", "profile": profile, "task": model.task,
            "stage_id": stage_id, "device": "cpu", "source": source,
            "parameter_count": model.parameter_count, "input_features": model.feature_count,
            "seed": meta["seed"], "learning_rate": meta["learning_rate"], "batch_size": meta["batch_size"],
            "numpy_version": model.runtime_numpy_version, "orchestrator_python_version": sys.version.split()[0],
            "cpu_threads_requested": 1, "profile_sha256": profile_digest,
            "parent_checkpoint_sha256": parent_digest, "checkpoint_sha256": selected.checkpoint_sha256,
            "initial_steps": model.steps, "final_steps": selected.steps,
            "initial_epochs": model.epochs, "final_epochs": selected.epochs,
            "training_attempts": summary["training_attempts"], "accepted_updates": summary["updates"],
            "training_seconds": summary["train_seconds"], "selection_reason": reason,
            "train_rows": len(training["ids"]), "validation_rows": len(valid["ids"]),
            "fresh_validation_rows": len(fresh), "train_sha256": training["sha256"],
            "validation_sha256": valid["sha256"], "validation_before": before, "validation_after": after,
            "validation_metrics_use_final_checkpoint": True, "label_provenance": provenance,
            "parent_history_supplied": parent_history is not None, "parent_round_history_bound": has_round_history,
            "future_accounting_complete": accounting_complete,
            "platform_retained_previous_parent": bool(has_round_history and
                parent_digest != previous[-1]["checkpoint_sha256"]),
            "official_baseline_history_preserved": baseline_history is not None, "cpu_engine_model_calls": 0,
            "fresh_validation_before": fresh_before, "fresh_validation_after": fresh_after,
            "policy": (ROUND_POLICIES[gated_policy] if use_stable_head else
                "C_frozen_mlp_input_gate_residual_calibration_epoch2_v1" if use_residual else
                "C_frozen_mlp_input_gate_operating_support_epoch2_v1" if use_support else
                "C_frozen_mlp_input_gate_epoch2_v1" if use_gate else "C_frozen_mlp_input_adapter_epoch2_v1" if use_adapter else "C_head_only_epoch2_compact_rbf_v1" if use_rbf else
                "C_head_only_epoch2_official_anchor_l2" if reference_digest else
                A_CORRECTION_POLICY if use_a_correction else
                A_THREE_CLASS_HEAD if a_trainable_policy == A_THREE_CLASS_HEAD else "A_step7_replay_B_static_C_head_only_epoch2"),
            "loss_policy":loss_policy, "reference_checkpoint_sha256":reference_digest,
            "module_policy": (A_CORRECTION_POLICY if use_a_correction else gated_policy if use_gate else
                              "input_adapter_v1" if use_adapter else "compact_rbf_v1" if use_rbf else "none"),
            "gradient_sampler":gradient_sampler,
            "gate_reference_preparation":gate_reference_preparation,
            "module_numeric_state_count": (int(selected.module.centers.size+selected.module.radii.size+selected.module.coefficients.size)
                if use_rbf and selected.module is not None else 686 if use_gate and selected.gate is not None else 660 if use_adapter and selected.module is not None else 0),
            "release_protocol": "12_ordered_batches_predict_then_release_previous_labels",
            "synthetic_drift_added": False, "platform_protocol_verified": False,
            "audit_directory": str(audit.resolve()), "artifact_bytes": 0,
            "history_granularity": "actual_round_and_maintenance_decisions; detailed events in audit; no fabricated epoch losses"}
        if use_adapter or use_gate:
            report.update({k:completed[k] for k in ("initial_module_steps","final_module_steps","initial_module_epochs","final_module_epochs")})
            report.update(parameter_count=selected.parameter_count,backbone_parameter_count=833,
                module_parameter_count=220 if selected.module is not None else 0)
            if use_gate:report.update(gate_parameter_count=26 if selected.gate is not None else 0,gate_fits=selected.gate_fits)
        if use_support:
            support = selected.gate.operating_support if selected.gate is not None else None
            support_count = support.points.size + 1 if support is not None else 0
            report.update(operating_support_numeric_state_count=support_count,
                          operating_support=support.audit if support is not None else None)
            report["module_numeric_state_count"] += support_count
        if use_residual:
            head = selected.gate.residual_calibration if selected.gate is not None else None
            head_count = len(head.coefficients) if head is not None else 0
            report.update(residual_calibration_parameter_count=head_count,
                          residual_calibration=head.audit if head is not None else None)
            report["module_numeric_state_count"] += head_count
        if use_stable_head:
            report.update({key: completed[key] for key in REPORT_CLOCKS})
            report.update(stable_head_parameter_count=33 if stable_head is not None else 0,
                          stable_head=stable_head.audit if stable_head is not None else None)
            if stable_head is not None:
                report["module_numeric_state_count"] += sum(value.size for value in stable_head.arrays().values())
        if gated_policy == LOW_RUL_MODULE:
            low_rul_head = selected.gate.low_rul_residual if selected.gate is not None else None
            low_rul_count = len(low_rul_head.coefficients) if low_rul_head is not None else 0
            report.update(low_rul_parameter_count=low_rul_count,
                          low_rul_residual=low_rul_head.audit if low_rul_head is not None else None)
            report["module_numeric_state_count"] += low_rul_count
        output.parent.mkdir(parents=True, exist_ok=True)
        # Exclusive destination reservation avoids replacing even an empty existing round.
        output.mkdir(exist_ok=False)
        with tempfile.TemporaryDirectory(prefix=".ite-round-", dir=output.parent) as temporary:
            staging = Path(temporary)
            selected.save(staging / "checkpoint.npz")
            with (staging / "history.jsonl").open("xb") as history:
                history.write(history_raw)
                if history_raw and not history_raw.endswith(b"\n"):
                    history.write(b"\n")
                for record in current:
                    history.write((json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8"))
            for _ in range(4):
                (staging / "training.json").write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
                size = check_artifacts(staging)
                if report["artifact_bytes"] == size:
                    break
                report["artifact_bytes"] = size
            if report["artifact_bytes"] != check_artifacts(staging):
                raise ValueError("artifact size accounting did not converge")
            (audit / "round.json").write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
            # Publish the model last: a checkpoint is visible only after its history/report.
            for path in sorted(staging.iterdir(), key=lambda p: p.name == "checkpoint.npz"):
                os.replace(path, output / path.name)
        return report
    except Exception as error:
        (audit / "failure.json").write_text(json.dumps({"error": type(error).__name__, "message": str(error),
            "parent_checkpoint_sha256": parent_digest, "stage_id": stage_id}, ensure_ascii=False), encoding="utf-8")
        raise


def prediction_main(argv=None):
    parser = argparse.ArgumentParser(description="Independent official CPU JSONL prediction; no labels accepted")
    parser.add_argument("--checkpoint", required=True, type=Path)
    parser.add_argument("--profile", choices=tuple(OFFICIAL_PROFILES))
    parser.add_argument("--official-python", default=runtime_default())
    args = parser.parse_args(argv)
    try:
        profile = args.profile or checkpoint_metadata(args.checkpoint)["profile"]
        from .c_rbf_model import CRBFModel, is_composite
        from .c_adapter_model import CInputAdapterModel,is_input_adapter
        from .c_gate_model import CGatedInputModel,is_gated
        model = (CGatedInputModel.load(args.checkpoint,args.official_python) if profile=="C" and is_gated(args.checkpoint.read_bytes()) else
            CInputAdapterModel.load(args.checkpoint,args.official_python) if profile=="C" and is_input_adapter(args.checkpoint.read_bytes()) else
            CRBFModel.load(args.checkpoint,args.official_python) if profile=="C" and is_composite(args.checkpoint.read_bytes()) else
            OfficialModelAdapter(OFFICIAL_PROFILES[profile]["task"], args.official_python,
                profile_type=profile, checkpoint_path=args.checkpoint))
        worker = Path(__file__).with_name("platform_predict_worker.py")
        return subprocess.run([args.official_python, str(worker), model.package_path,
            str(args.checkpoint.resolve()), profile, str(model.safety_margin)], check=False).returncode
    except (ValueError, OSError, RuntimeError) as error:
        print(f"prediction: {error}", file=sys.stderr)
        return 2


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] == "predict":
        return prediction_main(argv[1:])
    if argv and argv[0] == "train":
        argv = argv[1:]
    parser = argparse.ArgumentParser(description="Continue the supplied CPU parent; explicit train/validation only")
    parser.add_argument("--profile", choices=tuple(OFFICIAL_PROFILES), default=os.environ.get("ITE_PROFILE"))
    parser.add_argument("--train", type=Path, default=os.environ.get("ITE_TRAIN"))
    parser.add_argument("--validation", type=Path, default=os.environ.get("ITE_VALIDATION"))
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--resume", type=Path)
    group.add_argument("--from-baseline", type=Path)
    parser.add_argument("--output", type=Path, default=os.environ.get("ITE_OUTPUT"))
    parser.add_argument("--stage-id", default=os.environ.get("ITE_STAGE_ID", "round-1"))
    parser.add_argument("--parent-history", type=Path, default=os.environ.get("ITE_PARENT_HISTORY"))
    parser.add_argument("--label-provenance", type=Path, default=os.environ.get("ITE_LABEL_PROVENANCE"))
    parser.add_argument("--audit-output", type=Path)
    parser.add_argument("--official-python", default=runtime_default())
    args = parser.parse_args(argv)
    parent = args.resume or args.from_baseline or os.environ.get("ITE_PARENT_CHECKPOINT")
    if not parent:
        parser.error("an external parent is required: --resume, --from-baseline or ITE_PARENT_CHECKPOINT")
    if any(getattr(args, name) is None for name in ("profile", "train", "validation", "output")):
        parser.error("profile, train, validation and output must be explicitly provided")
    try:
        result = run_round(args.profile, args.train, args.validation, parent, args.output, args.stage_id,
            args.official_python, parent_history=args.parent_history, audit_output=args.audit_output,
            label_provenance=args.label_provenance, require_parent_history=args.from_baseline is None)
        print(json.dumps(result, ensure_ascii=False, allow_nan=False))
        return 0
    except (ValueError, OSError, RuntimeError) as error:
        print(f"continuation: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
