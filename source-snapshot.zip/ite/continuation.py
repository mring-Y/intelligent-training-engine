"""External-parent CPU rounds and a separate JSONL prediction entry point."""

import argparse
from datetime import datetime, timezone
from functools import lru_cache
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

import numpy as np

from .official_model import OfficialModelAdapter, OFFICIAL_PROFILES, default_package_path
from .official_sft_data import metrics, select_a_replay_reserve
from .official_sft_replay import replay_partition
from .platform_data import ARTIFACT_LIMIT, check_artifacts, checkpoint_metadata, json_value, read_dataset
from .tracking import source_metadata


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def runtime_default():
    return os.environ.get("ITE_OFFICIAL_RUNTIME_PYTHON", str(
        Path(__file__).resolve().parents[1] / ".venv-official-a/Scripts/python.exe"))


@lru_cache(maxsize=3)
def baseline_train_hashes(profile):
    # The adapter has already verified this exact package's pinned digest.
    # These identities anchor prior gradient use, never supply new gradients.
    with zipfile.ZipFile(default_package_path(profile)) as package:
        return frozenset(hashlib.sha256(json.loads(line)["id"].encode("utf-8")).hexdigest()
            for line in package.read("public/train.jsonl").decode("utf-8").splitlines() if line.strip())


def load_history(path, parent_digest, profile, *, baseline_history=None):
    if path is None:
        return b"", [], set()
    path = Path(path)
    if path.is_symlink() or not path.is_file() or path.stat().st_size > ARTIFACT_LIMIT:
        raise ValueError("parent history must be a bounded regular JSONL")
    raw = path.read_bytes()
    entries = [json_value(line) for line in raw.decode("utf-8").splitlines() if line.strip()]
    if baseline_history is not None and raw == baseline_history:
        return raw, entries, set()
    if (not entries or any(not isinstance(row, dict) for row in entries) or
            entries[-1].get("event") != "round_completed" or
            parent_digest not in (entries[-1].get("checkpoint_sha256"), entries[-1].get("parent_checkpoint_sha256")) or
            entries[-1].get("profile") != profile):
        raise ValueError("parent history does not bind the supplied parent checkpoint and profile")
    prefix, opened, last = bytearray(), None, None
    for line in raw.splitlines(keepends=True):
        if line.strip():
            row = json_value(line.decode("utf-8"))
            if row.get("event") == "round_started":
                if opened is not None:
                    raise ValueError("parent history has an unfinished round")
                expected = hashlib.sha256(prefix).hexdigest() if prefix else None
                if row.get("parent_history_sha256") != expected:
                    raise ValueError("parent history prefix digest mismatch or truncated history")
                if row.get("profile") != profile or (last is not None and
                        row.get("parent_checkpoint_sha256") not in
                        (last.get("checkpoint_sha256"), last.get("parent_checkpoint_sha256"))):
                    raise ValueError("parent history checkpoint chain mismatch")
                opened = row
            elif row.get("event") == "round_completed":
                if (opened is None or row.get("stage_id") != opened.get("stage_id") or
                        row.get("profile") != profile or
                        row.get("parent_checkpoint_sha256") != opened.get("parent_checkpoint_sha256")):
                    raise ValueError("parent history has an unbound round completion")
                last, opened = row, None
        prefix.extend(line)
    if opened is not None:
        raise ValueError("parent history ends before round completion")
    seen = set()
    for row in entries:
        for key in ("validation_id_hashes", "train_id_hashes", "baseline_training_id_hashes"):
            values = row.get(key, [])
            if not isinstance(values, list) or any(not isinstance(x, str) or len(x) != 64 for x in values):
                raise ValueError("invalid parent history source identities")
            seen.update(values)
    return raw, entries, seen


def run_round(profile, train, validation, parent, output, stage_id, runtime_python,
              *, parent_history=None, audit_output=None, label_provenance=None, require_parent_history=False,
              allow_training=True):
    """Run the unchanged policy on explicitly provided data with no synthetic drift."""
    output = Path(output)
    audit = Path(audit_output) if audit_output is not None else output.with_name(output.name + ".audit")
    if output.exists() or output.is_symlink() or audit.exists() or audit.is_symlink():
        raise FileExistsError("round output and audit output must be new directories")
    if output.resolve().is_relative_to(audit.resolve()) or audit.resolve().is_relative_to(output.resolve()):
        raise ValueError("model artifacts and detailed audit directories must be separate")
    if profile not in OFFICIAL_PROFILES or not isinstance(stage_id, str) or not stage_id.strip() or len(stage_id) > 128:
        raise ValueError("an official profile and bounded nonempty stage ID are required")
    if type(allow_training) is not bool:
        raise ValueError("allow_training must be an explicit boolean")
    meta = checkpoint_metadata(parent)
    if meta["profile"] != profile:
        raise ValueError("parent checkpoint profile does not match the requested dataset")
    model = OfficialModelAdapter(OFFICIAL_PROFILES[profile]["task"], runtime_python,
        profile_type=profile, checkpoint_path=parent, candidate_epochs=2 if profile == "C" else 5)
    parent_digest = model.checkpoint_sha256
    is_official_start = parent_digest == model.package_info["checkpoint_sha256"].removeprefix("sha256:")
    with zipfile.ZipFile(model.package_path) as package:
        baseline_history = package.read("history.jsonl") if is_official_start else None
        profile_digest = hashlib.sha256(package.read(f"baselines/configs/{profile}.json")).hexdigest()
    if parent_history is None:
        sibling = Path(parent).with_name("history.jsonl")
        if sibling.is_file():
            parent_history = sibling
    history_raw, previous, seen = load_history(parent_history, parent_digest, profile, baseline_history=baseline_history)
    has_round_history = bool(previous and previous[-1].get("event") == "round_completed")
    if not history_raw and baseline_history is not None:
        # These are exact existing official epoch records, not reconstructed logs.
        history_raw = baseline_history
    anchor = baseline_train_hashes(profile)
    seen.update(anchor)
    if history_raw and not history_raw.endswith(b"\n"):
        history_raw += b"\n"
    accounting_complete = (previous[-1].get("future_accounting_complete") is True if has_round_history else
                           is_official_start and not require_parent_history)
    if any(row.get("event") == "round_completed" and row.get("stage_id") == stage_id for row in previous):
        raise ValueError("stage ID already exists in the supplied parent history")
    training = read_dataset(train, profile, meta["paths"])
    valid = read_dataset(validation, profile, meta["paths"])
    if set(training["ids"]) & set(valid["ids"]):
        raise ValueError("training and validation IDs overlap")
    train_hashes = [hashlib.sha256(identity.encode("utf-8")).hexdigest() for identity in training["ids"]]
    past_validation = {identity for row in previous for identity in row.get("validation_id_hashes", [])}
    if set(train_hashes) & past_validation:
        raise ValueError("previous validation identities cannot change role and enter training gradients")
    provenance = None
    if profile == "B":
        if label_provenance is None:
            raise ValueError("B requires explicit label provenance for the supplied RUL targets")
        path = Path(label_provenance)
        if path.is_symlink() or not path.is_file() or path.stat().st_size > 65536:
            raise ValueError("label provenance must be a bounded regular JSON file")
        declaration = json_value(path.read_text(encoding="utf-8"))
        if (not isinstance(declaration, dict) or declaration.get("status") not in ("draft", "approved") or
                not isinstance(declaration.get("method"), str) or not declaration["method"].strip()):
            raise ValueError("label provenance requires status and a nonempty method")
        provenance = {"sha256": digest(path), "declaration": declaration,
                      "approval_verified_by_this_adapter": False}
    hashed_ids = [hashlib.sha256(identity.encode("utf-8")).hexdigest() for identity in valid["ids"]]
    fresh = [i for i, identity in enumerate(hashed_ids) if identity not in seen]
    selected, reason = model, "independent_gate_retained_parent"
    summary = {"training_attempts": 0, "train_seconds": 0., "updates": 0, "records": []}
    source = source_metadata()
    reserve = None
    reserve_error = False
    if profile == "A":
        try:
            reserve = select_a_replay_reserve(training["rows"], valid["ids"])
        except ValueError:
            reserve_error = True
    excluded = set(reserve["ids"]) if reserve is not None else set()
    train_indices = np.asarray([i for i, identity in enumerate(training["ids"]) if identity not in excluded], dtype=int)
    audit.parent.mkdir(parents=True, exist_ok=True)
    audit.mkdir(exist_ok=False)
    try:
        if not allow_training:
            reason = "model_requested_retain"
        elif profile == "B":
            reason = "B_static_policy"
        elif not accounting_complete:
            reason = "missing_parent_history_for_fresh_future_accounting"
        elif len(fresh) < 48 or len(train_indices) < 12:
            reason = "insufficient_fresh_future_capacity"
        elif reserve_error:
            reason = "insufficient_class_balanced_replay_reserve"
        else:
            indices = np.asarray(fresh, dtype=int)
            data = {"profile": profile, "task": model.task, "unit": model.target_unit,
                "x": valid["x"][indices], "y": valid["y"][indices],
                "ids": [valid["ids"][i] for i in fresh], "groups": ["explicit_validation"] * len(fresh),
                "scale": model.std, "loss_scale": 1. if profile == "A" else max(float(np.var(training["y"])), 1e-12)}
            if reserve is not None:
                data["replay_reserve"] = reserve
            stream = {"x": training["x"][train_indices], "y": training["y"][train_indices],
                "ids": [training["ids"][i] for i in train_indices], "role": "explicit_platform_train"}
            summary = replay_partition(data, list(range(len(fresh))), "train", "stable", audit / "policy",
                OfficialModelAdapter.from_state(model.state()),
                lambda _: {"action": "RETRAIN_LARGE" if profile == "A" else "DO_NOTHING",
                    "reason": "已确认A step7回放或C规则候选；仍须独立未来门控。", "source": "approved_host_policy"},
                decision_steps=(7,) if profile == "A" else tuple(range(3, 10)),
                action_profile="official_finetune", heuristic_override=profile == "C",
                a_replay_policy="class_balanced_official_train" if profile == "A" else "none",
                training_stream=stream)
            selected = OfficialModelAdapter(model.task, runtime_python, profile_type=profile,
                checkpoint_path=audit / "policy/selected.npz", candidate_epochs=model.candidate_epochs)
            if summary["updates"]:
                reason = "independent_future_gate_accepted"
        if digest(parent) != parent_digest:
            raise ValueError("supplied parent checkpoint changed during the round")
        before = metrics(profile, valid["y"], model.predict(valid["x"]))
        after = metrics(profile, valid["y"], selected.predict(valid["x"]))
        if len(fresh) >= 48:
            fresh_indices = np.asarray(fresh, dtype=int)
            fresh_before = metrics(profile, valid["y"][fresh_indices], model.predict(valid["x"][fresh_indices]))
            fresh_after = metrics(profile, valid["y"][fresh_indices], selected.predict(valid["x"][fresh_indices]))
        else:
            fresh_before = fresh_after = None
        completed = {"event": "round_completed", "stage_id": stage_id, "profile": profile,
            "parent_checkpoint_sha256": parent_digest, "checkpoint_sha256": selected.checkpoint_sha256,
            "initial_steps": model.steps, "final_steps": selected.steps,
            "initial_epochs": model.epochs, "final_epochs": selected.epochs,
            "training_performed": summary["training_attempts"] > 0,
            "training_attempts": summary["training_attempts"], "accepted_updates": summary["updates"],
            "selection_reason": reason, "validation_id_hashes": [hashed_ids[i] for i in fresh],
            "train_id_hashes": train_hashes,
            "baseline_training_id_hashes": sorted(anchor) if not has_round_history else [],
            "future_accounting_complete": accounting_complete,
            "train_sha256": training["sha256"], "validation_sha256": valid["sha256"],
            "source": source, "created_at": datetime.now(timezone.utc).isoformat()}
        current = [{"event": "round_started", "stage_id": stage_id, "profile": profile,
            "parent_checkpoint_sha256": parent_digest,
            "parent_history_sha256": hashlib.sha256(history_raw).hexdigest() if history_raw else None}]
        for record in summary["records"]:
            evidence = record.get("evidence", {})
            current.append({"event": "maintenance_decision", "stage_id": stage_id,
                "decision_id": record["decision_id"], "step": record["step"], "action": record["action"],
                "rejection": record.get("rejection"),
                "parent_checkpoint_sha256": evidence.get("candidate_parent_checkpoint"),
                "candidate_checkpoint_sha256": evidence.get("candidate_checkpoint"),
                "experiment": {k: evidence[k] for k in ("train_samples", "screening_samples", "train_seconds",
                    "trainable_policy", "parent_adam_steps", "candidate_adam_steps", "fit_audit",
                    "selection_loss", "incumbent_loss") if k in evidence},
                "future_gate": {k: v for k, v in evidence.get("future_gate", {}).items() if k != "source_ids"}})
        current.append(completed)
        report = {"format": "ite.cpu-continuation-report.v1", "profile": profile, "task": model.task,
            "stage_id": stage_id, "device": "cpu", "source": source,
            "parameter_count": model.parameter_count, "input_features": model.feature_count,
            "seed": meta["seed"], "learning_rate": meta["learning_rate"], "batch_size": meta["batch_size"],
            "numpy_version": model.runtime_numpy_version, "orchestrator_python_version": sys.version.split()[0],
            "cpu_threads_requested": 1, "profile_sha256": profile_digest,
            "parent_checkpoint_sha256": parent_digest, "checkpoint_sha256": selected.checkpoint_sha256,
            "initial_steps": model.steps, "final_steps": selected.steps,
            "initial_epochs": model.epochs, "final_epochs": selected.epochs,
            "training_attempts": summary["training_attempts"], "accepted_updates": summary["updates"],
            "training_seconds": summary["train_seconds"], "selection_reason": reason,
            "train_rows": len(training["ids"]), "validation_rows": len(valid["ids"]),
            "fresh_validation_rows": len(fresh), "train_sha256": training["sha256"],
            "validation_sha256": valid["sha256"], "validation_before": before, "validation_after": after,
            "validation_metrics_use_final_checkpoint": True, "label_provenance": provenance,
            "parent_history_supplied": parent_history is not None, "parent_round_history_bound": has_round_history,
            "future_accounting_complete": accounting_complete,
            "platform_retained_previous_parent": bool(has_round_history and
                parent_digest != previous[-1]["checkpoint_sha256"]),
            "official_baseline_history_preserved": baseline_history is not None, "cpu_engine_model_calls": 0,
            "fresh_validation_before": fresh_before, "fresh_validation_after": fresh_after,
            "policy": "A_step7_replay_B_static_C_head_only_epoch2",
            "release_protocol": "12_ordered_batches_predict_then_release_previous_labels",
            "synthetic_drift_added": False, "platform_protocol_verified": False,
            "audit_directory": str(audit.resolve()), "artifact_bytes": 0,
            "history_granularity": "actual_round_and_maintenance_decisions; detailed events in audit; no fabricated epoch losses"}
        output.parent.mkdir(parents=True, exist_ok=True)
        # Exclusive destination reservation avoids replacing even an empty existing round.
        output.mkdir(exist_ok=False)
        with tempfile.TemporaryDirectory(prefix=".ite-round-", dir=output.parent) as temporary:
            staging = Path(temporary)
            selected.save(staging / "checkpoint.npz")
            with (staging / "history.jsonl").open("xb") as history:
                history.write(history_raw)
                if history_raw and not history_raw.endswith(b"\n"):
                    history.write(b"\n")
                for record in current:
                    history.write((json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8"))
            for _ in range(4):
                (staging / "training.json").write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
                size = check_artifacts(staging)
                if report["artifact_bytes"] == size:
                    break
                report["artifact_bytes"] = size
            if report["artifact_bytes"] != check_artifacts(staging):
                raise ValueError("artifact size accounting did not converge")
            (audit / "round.json").write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
            # Publish the model last: a checkpoint is visible only after its history/report.
            for path in sorted(staging.iterdir(), key=lambda p: p.name == "checkpoint.npz"):
                os.replace(path, output / path.name)
        return report
    except Exception as error:
        (audit / "failure.json").write_text(json.dumps({"error": type(error).__name__, "message": str(error),
            "parent_checkpoint_sha256": parent_digest, "stage_id": stage_id}, ensure_ascii=False), encoding="utf-8")
        raise


def prediction_main(argv=None):
    parser = argparse.ArgumentParser(description="Independent official CPU JSONL prediction; no labels accepted")
    parser.add_argument("--checkpoint", required=True, type=Path)
    parser.add_argument("--profile", choices=tuple(OFFICIAL_PROFILES))
    parser.add_argument("--official-python", default=runtime_default())
    args = parser.parse_args(argv)
    try:
        profile = args.profile or checkpoint_metadata(args.checkpoint)["profile"]
        model = OfficialModelAdapter(OFFICIAL_PROFILES[profile]["task"], args.official_python,
            profile_type=profile, checkpoint_path=args.checkpoint)
        worker = Path(__file__).with_name("platform_predict_worker.py")
        return subprocess.run([args.official_python, str(worker), model.package_path,
            str(args.checkpoint.resolve()), profile, str(model.safety_margin)], check=False).returncode
    except (ValueError, OSError, RuntimeError) as error:
        print(f"prediction: {error}", file=sys.stderr)
        return 2


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] == "predict":
        return prediction_main(argv[1:])
    if argv and argv[0] == "train":
        argv = argv[1:]
    parser = argparse.ArgumentParser(description="Continue the supplied CPU parent; explicit train/validation only")
    parser.add_argument("--profile", choices=tuple(OFFICIAL_PROFILES), default=os.environ.get("ITE_PROFILE"))
    parser.add_argument("--train", type=Path, default=os.environ.get("ITE_TRAIN"))
    parser.add_argument("--validation", type=Path, default=os.environ.get("ITE_VALIDATION"))
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--resume", type=Path)
    group.add_argument("--from-baseline", type=Path)
    parser.add_argument("--output", type=Path, default=os.environ.get("ITE_OUTPUT"))
    parser.add_argument("--stage-id", default=os.environ.get("ITE_STAGE_ID", "round-1"))
    parser.add_argument("--parent-history", type=Path, default=os.environ.get("ITE_PARENT_HISTORY"))
    parser.add_argument("--label-provenance", type=Path, default=os.environ.get("ITE_LABEL_PROVENANCE"))
    parser.add_argument("--audit-output", type=Path)
    parser.add_argument("--official-python", default=runtime_default())
    args = parser.parse_args(argv)
    parent = args.resume or args.from_baseline or os.environ.get("ITE_PARENT_CHECKPOINT")
    if not parent:
        parser.error("an external parent is required: --resume, --from-baseline or ITE_PARENT_CHECKPOINT")
    if any(getattr(args, name) is None for name in ("profile", "train", "validation", "output")):
        parser.error("profile, train, validation and output must be explicitly provided")
    try:
        result = run_round(args.profile, args.train, args.validation, parent, args.output, args.stage_id,
            args.official_python, parent_history=args.parent_history, audit_output=args.audit_output,
            label_provenance=args.label_provenance, require_parent_history=args.from_baseline is None)
        print(json.dumps(result, ensure_ascii=False, allow_nan=False))
        return 0
    except (ValueError, OSError, RuntimeError) as error:
        print(f"continuation: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
