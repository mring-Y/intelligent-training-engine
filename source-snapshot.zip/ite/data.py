"""Synthetic streams, a delayed label gateway, and a separate retrospective scorer."""

from dataclasses import dataclass

import numpy as np

from .models import prediction_loss


@dataclass(frozen=True)
class PublicBatch:
    step: int
    sample_ids: np.ndarray
    features: np.ndarray


@dataclass(frozen=True)
class InitialData:
    train_x: np.ndarray
    train_y: np.ndarray
    validation_x: np.ndarray
    validation_y: np.ndarray


@dataclass(frozen=True)
class ReleasedLabels:
    sample_ids: np.ndarray
    features: np.ndarray
    targets: np.ndarray
    source_steps: np.ndarray


class LabelOracle:
    def __init__(self, batches, targets, delay, max_labels):
        self._records = {int(sample_id): (batch.step, row.copy(), target)
                         for batch, y in zip(batches, targets)
                         for sample_id, row, target in zip(batch.sample_ids, batch.features, y)}
        self._delay, self._limit = delay, max_labels
        self._requested, self._pending = set(), []

    @property
    def total_requested(self):
        return len(self._requested)

    @property
    def pending_schedule(self):
        return tuple((self._records[sample_id][0], due) for due, sample_id in self._pending)

    def request(self, sample_ids, step):
        ids = [int(value) for value in sample_ids]
        for sample_id in ids:
            if sample_id not in self._records:
                raise ValueError(f"Unknown sample id {sample_id}")
            if self._records[sample_id][0] > step:
                raise ValueError("Cannot request a future sample")
        accepted = 0
        for sample_id in ids:
            if self._limit is not None and self.total_requested >= self._limit:
                break
            if sample_id in self._requested:
                continue
            self._requested.add(sample_id)
            self._pending.append((step + self._delay, sample_id))
            accepted += 1
        return accepted

    def release(self, step):
        ready = [sample_id for due, sample_id in self._pending if due <= step]
        self._pending = [(due, sample_id) for due, sample_id in self._pending if due > step]
        if not ready:
            return None
        records = [self._records[sample_id] for sample_id in ready]
        return ReleasedLabels(np.asarray(ready), np.asarray([record[1] for record in records]),
                              np.asarray([record[2] for record in records]),
                              np.asarray([record[0] for record in records]))


class RetrospectiveScorer:
    """Called after the policy finishes, never supplied to its update controller."""

    def __init__(self, task, targets, scale):
        self._task, self._targets, self._scale = task, targets, scale

    def score(self, predictions):
        if len(predictions) != len(self._targets):
            raise ValueError("Scoring requires one prediction vector per stream batch")
        return [prediction_loss(self._task, y, pred, self._scale)
                for y, pred in zip(self._targets, predictions)]

    def regression_metrics(self, predictions):
        if self._task != "regression" or len(predictions) != len(self._targets):
            raise ValueError("Raw-unit regression metrics require matching regression predictions")
        targets = np.concatenate([np.asarray(values, dtype=float) for values in self._targets])
        predicted = np.concatenate([np.asarray(values, dtype=float) for values in predictions])
        if (targets.shape != predicted.shape or not targets.size or
                not np.isfinite(targets).all() or not np.isfinite(predicted).all()):
            raise ValueError("Regression metrics require matching finite predictions and targets")
        residual = predicted - targets
        return {"rmse": float(np.sqrt(np.mean(residual ** 2))),
                "mae": float(np.mean(np.abs(residual)))}

    def classification_counts(self, predictions):
        y, pred = np.concatenate(self._targets), np.concatenate(predictions)
        return {"tp": int(np.sum((y == 1) & (pred == 1))), "tn": int(np.sum((y == 0) & (pred == 0))),
                "fp": int(np.sum((y == 0) & (pred == 1))), "fn": int(np.sum((y == 1) & (pred == 0)))}


@dataclass(frozen=True)
class Simulation:
    initial: InitialData
    batches: tuple
    oracle: LabelOracle
    scorer: RetrospectiveScorer


def make_simulation(config):
    rng = np.random.default_rng(config.seed)
    weights = rng.normal(size=config.n_features)
    # The covariate scenario shifts an irrelevant feature without changing P(y | x).
    weights[1] = 0
    weights /= np.linalg.norm(weights)

    def sample(count, progress=0.0, shift=0.0, noisy=False):
        x = rng.normal(size=(count, config.n_features))
        x[:, 1] += shift
        current_weights = (1 - 2 * progress * config.drift_magnitude) * weights
        if config.relationship == "nonlinear":
            signal = .8 * (x[:, 0] ** 2 - 1) / np.sqrt(2) + .6 * x[:, 0] * x[:, 2]
            latent = (1 - 2 * progress * config.drift_magnitude) * signal + rng.normal(scale=.15, size=count)
        else:
            latent = x @ current_weights + rng.normal(scale=0.15, size=count)
        if config.task == "classification":
            y = (latent >= config.class_threshold).astype(int)
            if noisy:
                y = np.where(rng.random(count) < 0.35, 1 - y, y)
        else:
            y = latent + (rng.normal(scale=1.5, size=count) if noisy else 0)
        if config.outlier_fraction:
            # Sensor corruption after generating y: contaminated measurements,
            # without providing a corruption flag to the online policy.
            corrupt = rng.random(count) < config.outlier_fraction
            x[corrupt] += rng.normal(scale=8, size=(int(corrupt.sum()), config.n_features))
        return x, y

    train_x, train_y = sample(config.initial_train)
    val_x, val_y = sample(config.initial_validation)
    initial = InitialData(train_x, train_y, val_x, val_y)
    batches, targets = [], []
    for step in range(config.n_batches):
        progress, shift = 0.0, 0.0
        if config.scenario == "abrupt":
            progress = float(step >= config.drift_start)
        elif config.scenario == "triple_abrupt":
            progress = float(2 <= step < 10 or step >= 18)
        elif config.scenario in ("gradual", "mixed"):
            progress = float(np.clip((step - config.drift_start + 1) / config.drift_width, 0, 1))
        elif config.scenario == "recurring" and step >= config.drift_start:
            # The first changed regime begins at drift_start, then alternates.
            progress = float(((step - config.drift_start) // config.drift_width + 1) % 2)
        elif config.scenario == "covariate" and step >= config.drift_start:
            shift = 2.5
        if config.scenario == "mixed" and step >= config.drift_start:
            shift = 2.5
        noisy = config.scenario in ("noise", "mixed") and config.drift_start <= step < config.drift_start + 2
        x, y = sample(config.batch_size, progress, shift, noisy)
        ids = np.arange(step * config.batch_size, (step + 1) * config.batch_size)
        x.setflags(write=False)
        ids.setflags(write=False)
        batches.append(PublicBatch(step, ids, x))
        targets.append(y)
    scale = max(float(np.var(val_y)), 1e-8) if config.task == "regression" else 1.0
    limit = config.max_labels if config.label_mode == "budgeted" else None
    oracle = LabelOracle(batches, targets, config.label_delay, limit)
    return Simulation(initial, tuple(batches), oracle, RetrospectiveScorer(config.task, targets, scale))
