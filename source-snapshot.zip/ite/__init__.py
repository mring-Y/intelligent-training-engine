"""CPU-first experiments for controlled model adaptation on drifting streams."""

__version__ = "0.1.0"
