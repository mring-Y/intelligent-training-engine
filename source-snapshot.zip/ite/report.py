"""Portable CSV/JSON summaries and a dependency-free offline HTML report."""

import csv
import html
import json
from collections import defaultdict
from pathlib import Path

import numpy as np

from .tracking import write_json


def write_rows(path, rows):
    if not rows:
        return
    with Path(path).open("w", encoding="utf-8", newline="") as stream:
        columns = list(dict.fromkeys(key for row in rows for key in row))
        writer = csv.DictWriter(stream, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def render_report(output_dir, results, title="模拟漂移流实验"):
    output_dir = Path(output_dir)
    write_json(output_dir / "summary.json", results)
    write_rows(output_dir / "summary.csv", results)
    columns = ("experiment_group", "task", "scenario", "seed", "policy", "model_family", "strategy_adaptation", "mean_loss", "accuracy",
               "loss_gain_vs_static", "updates", "rollbacks", "labels_requested", "adaptation_train_seconds",
               "experiments", "history_reuses", "labels_released", "candidate_wait_max_batches",
               "prediction_seconds", "mean_detection_delay_batches", "missed_changes", "false_alarms", "tokens")
    if any(result.get("harness_enabled") for result in results):
        columns += ("token_accounting_mode", "mock_tokens", "real_llm_tokens", "harness_state")
    headings = {"experiment_group": "实验组", "task": "任务", "scenario": "场景", "seed": "种子", "policy": "策略",
                "strategy_adaptation": "策略改进", "mean_loss": "平均损失↓", "accuracy": "准确率↑",
                "model_family": "模型",
                "loss_gain_vs_static": "相对静态损失改善↑", "updates": "上线数", "rollbacks": "回滚数",
                "labels_requested": "标注数", "adaptation_train_seconds": "增量训练秒",
                "experiments": "实验轮数", "tokens": "Token", "history_reuses": "历史复用",
                "labels_released": "已释放标签", "candidate_wait_max_batches": "最长候选等待/批",
                "prediction_seconds": "预测秒", "token_accounting_mode": "Token口径",
                "mock_tokens": "模拟 Token", "real_llm_tokens": "真实大模型Token",
                "harness_state": "Harness状态",
                "mean_detection_delay_batches": "检测延迟/批", "missed_changes": "漏检变化", "false_alarms": "误报"}
    header = "".join(f"<th>{headings[key]}</th>" for key in columns)
    body = []
    for result in results:
        cells = []
        for key in columns:
            value = result.get(key)
            text = "—" if value is None else (f"{value:.4f}" if isinstance(value, float) else str(value))
            cells.append(f"<td>{html.escape(text)}</td>")
        body.append("<tr>" + "".join(cells) + "</tr>")
    curves = []
    for result in results:
        curve_path = output_dir / result["curve_file"]
        with curve_path.open(encoding="utf-8") as stream:
            rows = list(csv.DictReader(stream))
        curves.append({"label": f"{result['task']}/{result['scenario']}/s{result['seed']}/{result['policy']}"
                                f"/adaptive={result['strategy_adaptation']}",
                       "loss": [float(row["loss"]) for row in rows]})
    encoded = json.dumps(curves, ensure_ascii=False).replace("<", "\\u003c")
    template = """<!doctype html><html lang="zh-CN"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>__TITLE__</title>
<style>body{font-family:system-ui,sans-serif;max-width:1500px;margin:36px auto;padding:0 24px;color:#17263a;background:#f5f7fa}
h1{font-size:27px}p{line-height:1.7}.panel{background:white;padding:24px;border-radius:12px;margin:20px 0;overflow:auto}
table{border-collapse:collapse;font-size:13px;width:100%}th,td{padding:10px;text-align:right;border-bottom:1px solid #e0e5eb;white-space:nowrap}
th{background:#eef3fa}select{padding:8px;width:min(100%,720px)}svg{width:100%;height:290px}a{color:#1459a5}</style>
<h1>__TITLE__</h1><p>本页使用合成数值特征，验证自动更新工程机制。所有分数均为本地代理指标，不能视为官方成绩。
分类损失为错误率；回归损失为以初始验证集目标方差归一化的 MSE。各任务损失不合并为一个官方分数。
规则模式不调用大模型；Mock 的 Token 为模拟用量，不代表真实服务账单。Harness 的模拟和真实大模型用量分列。
训练耗时包含增量候选进程开销；初始训练成本单独保存在 CSV/JSON。</p>
<div class="panel"><label for="curve">查看逐批损失：</label><select id="curve"></select><svg id="plot" viewBox="0 0 1100 290" role="img" aria-label="逐批损失曲线"></svg>
<p>横轴为流批次，纵轴为损失（越低越好）。回滚功能另有确定性测试；场景未出现回滚不等于该功能缺失。</p></div>
<div class="panel"><table><thead><tr>__HEADER__</tr></thead><tbody>__BODY__</tbody></table></div>
<p><a href="summary.csv">下载汇总 CSV</a> · <a href="summary.json">查看完整 JSON</a>。各策略目录包含事件、预测和模型检查点。</p>
<script>const data=__DATA__;const select=document.querySelector('#curve'),plot=document.querySelector('#plot');
data.forEach((v,i)=>{const o=document.createElement('option');o.value=i;o.textContent=v.label;select.append(o)});
function draw(){const ys=data[+select.value].loss,max=Math.max(.1,...ys)*1.1;
const points=ys.map((y,i)=>`${55+i*1010/Math.max(1,ys.length-1)},${245-y*210/max}`).join(' ');
plot.innerHTML=`<path d="M55 25V245H1065" fill="none" stroke="#8091a5"/><polyline points="${points}" fill="none" stroke="#1768b5" stroke-width="2.5"/>
<text x="6" y="35" font-size="14">${max.toFixed(2)}</text><text x="25" y="250" font-size="14">0</text>
<text x="55" y="275" font-size="14">批次 0</text><text x="990" y="275" font-size="14">批次 ${ys.length-1}</text>`;}select.onchange=draw;if(data.length)draw();</script></html>"""
    output_dir.joinpath("report.html").write_text(template.replace("__TITLE__", html.escape(title))
        .replace("__HEADER__", header).replace("__BODY__", "".join(body)).replace("__DATA__", encoded), encoding="utf-8")


def aggregate_results(results):
    groups = defaultdict(list)
    for result in results:
        groups[(result.get("experiment_group", "comparison"), result["task"], result["scenario"],
                result["policy"], result["strategy_adaptation"])].append(result)
    aggregates = []
    for (group, task, scenario, policy, adaptive), items in groups.items():
        losses = [item["mean_loss"] for item in items]
        aggregates.append({"experiment_group": group, "task": task, "scenario": scenario, "policy": policy,
                           "strategy_adaptation": adaptive, "n_seeds": len(items),
                           "mean_loss": float(np.mean(losses)), "loss_std": float(np.std(losses)),
                           "mean_loss_gain": (float(np.mean([i["loss_gain_vs_static"] for i in items]))
                                              if all(i["loss_gain_vs_static"] is not None for i in items) else None),
                           "mean_updates": float(np.mean([i["updates"] for i in items])),
                           "mean_train_seconds": float(np.mean([i["adaptation_train_seconds"] for i in items])),
                           "mean_history_reuses": float(np.mean([i.get("history_reuses", 0) for i in items])),
                           "mean_false_alarms": float(np.mean([i.get("false_alarms", 0) for i in items])),
                           "mean_missed_changes": float(np.mean([i.get("missed_changes", 0) for i in items]))})
        for name in ("labels_requested", "labels_released", "prediction_seconds", "model_evaluation_seconds",
                     "candidate_wait_mean_batches", "candidate_wait_max_batches", "pending_expired",
                     "pending_uncollectable", "label_infeasible_skips", "peak_prediction_cache"):
            aggregates[-1][f"mean_{name}"] = float(np.mean([i.get(name, 0) for i in items]))
    return aggregates
