"""Explicit JSONL and artifact boundaries matching the pinned CPU baselines."""

import io
import json
import math
from pathlib import Path
import re
import zipfile

import numpy as np

from .official_model import MAX_CHECKPOINT_BYTES, OFFICIAL_PROFILES


ARTIFACT_LIMIT = 64 * 1024 * 1024
DATA_LIMIT = 128 * 1024 * 1024
FORBIDDEN_FEATURES = {"truerul", "normalizedrul", "remainingusefullife", "rul", "totalsnapshots"}


def json_value(raw):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("duplicate JSON key")
            result[key] = value
        return result

    def nonfinite(_):
        raise ValueError("nonfinite JSON number")

    return json.loads(raw, object_pairs_hook=unique, parse_constant=nonfinite)


def flatten(inputs):
    """Use the official JSON-encoded key/index paths, not just feature count."""
    paths, values = [], []

    def visit(value, path, depth):
        if depth > 16:
            raise ValueError("input nesting exceeds limit")
        if isinstance(value, dict):
            for key in sorted(value):
                if re.sub(r"[^a-z0-9]", "", key.lower()) in FORBIDDEN_FEATURES:
                    raise ValueError("target-derived input field is not allowed")
                visit(value[key], path + [("key", key)], depth + 1)
        elif isinstance(value, list):
            for index, child in enumerate(value):
                visit(child, path + [("index", index)], depth + 1)
        elif type(value) in (int, float) and math.isfinite(value):
            paths.append(json.dumps(path, ensure_ascii=False, separators=(",", ":")))
            values.append(float(value))
        else:
            raise ValueError("model inputs require finite numeric features")

    visit(inputs, [], 0)
    if not 1 <= len(values) <= 4096:
        raise ValueError("expected 1..4096 numeric features")
    return paths, values


def checkpoint_metadata(path):
    path = Path(path)
    if path.is_symlink() or not path.is_file() or not 1 <= path.stat().st_size <= MAX_CHECKPOINT_BYTES:
        raise ValueError("parent checkpoint must be a regular NPZ no larger than 16 MiB")
    try:
        with zipfile.ZipFile(path) as archive:
            entries = archive.infolist()
            if (len(entries) != 15 or len({x.filename for x in entries}) != len(entries) or
                    sum(x.file_size for x in entries) > MAX_CHECKPOINT_BYTES):
                raise ValueError("invalid official checkpoint archive")
            raw = archive.read("metadata.npy")
        metadata = np.load(io.BytesIO(raw), allow_pickle=False)
        if metadata.shape != () or metadata.dtype.kind != "U":
            raise ValueError("invalid checkpoint metadata")
        result = json_value(str(metadata))
        if not isinstance(result, dict) or result.get("profile") not in OFFICIAL_PROFILES:
            raise ValueError("checkpoint must declare official profile A/B/C")
        return result
    except (zipfile.BadZipFile, KeyError, UnicodeError, json.JSONDecodeError) as error:
        raise ValueError("invalid official parent checkpoint") from error


def read_dataset(path, profile, expected_paths):
    path = Path(path)
    if path.is_symlink() or not path.is_file() or path.stat().st_size > DATA_LIMIT:
        raise ValueError("dataset must be an explicit regular JSONL no larger than 128 MiB")
    contract = OFFICIAL_PROFILES[profile]
    raw = path.read_bytes()
    rows, ids, features, targets = [], [], [], []
    seen, paths = set(), expected_paths
    for line in raw.decode("utf-8-sig").splitlines():
        if not line.strip():
            continue
        row = json_value(line)
        if not isinstance(row, dict) or not {"id", "inputs", "answer"} <= set(row):
            raise ValueError("dataset rows require id, inputs and answer")
        identity = row["id"]
        if not isinstance(identity, str) or not identity or identity in seen:
            raise ValueError("sample IDs must be nonempty and unique")
        current, values = flatten(row["inputs"])
        paths = current if paths is None else paths
        if current != paths or len(values) != contract["n_features"]:
            raise ValueError("feature schema differs from the parent checkpoint")
        answer = row["answer"]
        if profile == "A":
            if not isinstance(answer, str) or answer not in contract["classes"]:
                raise ValueError("label is outside the official class list")
            target = contract["classes"].index(answer) + 1
        else:
            if type(answer) not in (int, float) or not math.isfinite(answer) or answer < 0:
                raise ValueError("RUL target must be finite and nonnegative")
            target = float(answer)
        seen.add(identity)
        ids.append(identity)
        rows.append(row)
        features.append(values)
        targets.append(target)
    if not ids:
        raise ValueError("dataset is empty")
    import hashlib
    return {"x": np.asarray(features, dtype=float), "y": np.asarray(targets),
            "ids": ids, "rows": rows, "paths": paths, "sha256": hashlib.sha256(raw).hexdigest()}


def check_artifacts(root, *, limit=ARTIFACT_LIMIT):
    total = 0
    for path in Path(root).rglob("*"):
        if path.is_symlink():
            raise ValueError("artifact directory cannot contain symlinks")
        if path.is_file():
            total += path.stat().st_size
    if total > limit:
        raise ValueError("artifact total exceeds the 64 MiB limit")
    return total
