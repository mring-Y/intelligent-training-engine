"""Offline Token/CNY audit; projections never pretend batches are API calls."""

import argparse
import json
from decimal import Decimal
from pathlib import Path


def _money(value):
    return format(value.quantize(Decimal("0.00000001")), "f")


def audit_cost(ledger, events, *, batches=100, drift_calls=10, max_calls=10,
               max_input_tokens=2048, max_output_tokens=512,
               input_price_per_million=None, output_price_per_million=None):
    if any(type(value) is not int or value < 0 for value in (batches, drift_calls, max_calls)):
        raise ValueError("Projection counts must be nonnegative integers")
    if drift_calls > batches:
        raise ValueError("At most one drift request opportunity per batch")
    if (input_price_per_million is None) != (output_price_per_million is None):
        raise ValueError("Input and output projection prices must be supplied together")
    known = [entry for entry in ledger["requests"] if entry["status"] == "settled"]
    unknown = [entry for entry in ledger["requests"] if entry["status"] == "reserved"]
    inputs = sum(entry["input_tokens"] for entry in known)
    outputs = sum(entry["output_tokens"] for entry in known)
    known_cost = sum((Decimal(entry["cost_cny"]) for entry in known), Decimal(0))
    reserved_cost = sum((Decimal(entry["reserved_cost_cny"]) for entry in unknown), Decimal(0))
    latencies = [entry["latency_seconds"] for entry in events
                 if entry.get("event") == "harness_call" and "latency_seconds" in entry]
    prices = []
    for key, configured in (("input_price_per_million", input_price_per_million),
                            ("output_price_per_million", output_price_per_million)):
        values = ([Decimal(str(configured))] if configured is not None else
                  [Decimal(entry[key]) for entry in ledger["requests"]])
        if any(not value.is_finite() or value <= 0 for value in values):
            raise ValueError("Projection prices must be finite positive decimals")
        prices.append(max(values) if values else None)
    in_price, out_price = prices

    def projection(calls):
        if not known:
            return None
        return {"calls": calls, "projected_tokens": float(Decimal(inputs + outputs) * calls / len(known)),
                "estimated_cost_cny": _money(known_cost * calls / len(known))}

    calls = min(drift_calls, max_calls)
    return {"identity": ledger.get("identity"), "batches": batches, "assumed_drift_call_opportunities": drift_calls,
            "known_calls": len(known), "unknown_calls": len(unknown),
            "actual_input_tokens": inputs, "actual_output_tokens": outputs,
            "actual_total_tokens": inputs + outputs, "actual_estimated_cost_cny": _money(known_cost),
            "unresolved_reserved_cost_cny": _money(reserved_cost),
            "total_cost_exposure_cny": _money(known_cost + reserved_cost),
            "latency_mean_seconds": sum(latencies) / len(latencies) if latencies else None,
            "latency_max_seconds": max(latencies, default=None),
            "measured_max_tokens_per_call": max((entry["input_tokens"] + entry["output_tokens"] for entry in known), default=None),
            "uncapped": projection(drift_calls), "capped": projection(calls),
            "configured_upper_bound": {"calls": calls, "tokens": calls * (max_input_tokens + max_output_tokens),
                "estimated_cost_cny": (_money(calls * (max_input_tokens * in_price + max_output_tokens * out_price) / 1_000_000)
                                       if in_price is not None and out_price is not None else None)},
            "notes": ["Local estimate uses input/output public prices, without assuming cache discounts.",
                      "Actual billed amount requires a provider billing receipt; unresolved requests retain exposure.",
                      "Small smoke sample does not establish tail latency or hidden-stream model quality."]}


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--ledger", type=Path, required=True)
    parser.add_argument("--events", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--batches", type=int, default=100)
    parser.add_argument("--drift-calls", type=int, default=100)
    parser.add_argument("--input-price-per-million")
    parser.add_argument("--output-price-per-million")
    args = parser.parse_args(argv)
    if (args.input_price_per_million is None) != (args.output_price_per_million is None):
        parser.error("--input-price-per-million and --output-price-per-million must be used together")
    ledger = json.loads(args.ledger.read_text(encoding="utf-8"))
    events = [json.loads(line) for line in args.events.read_text(encoding="utf-8").splitlines()]
    prices = dict(input_price_per_million=args.input_price_per_million,
                  output_price_per_million=args.output_price_per_million)
    result = audit_cost(ledger, events, batches=args.batches, drift_calls=args.drift_calls, **prices)
    result["scenarios"] = {str(k): audit_cost(ledger, events, batches=100, drift_calls=k, **prices)["capped"]
                           for k in (0, 1, 3, 10, 100)}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
