"""One fixed triple-change engineering run; real execution needs matching Mock evidence."""

import argparse
import json
import shutil
from pathlib import Path

from .config import ExperimentConfig
from .iteration_audit import audit_iterations
from .runner import run_policy
from .tracking import source_metadata, write_json
from .training import BoundedTrainer

PAID_STATE_ROOT = Path(__file__).resolve().parents[1] / "outputs" / "three-abrupt-paid-state"


def validate_paid_claim(config, output, *, injected=False):
    """Shared Runner boundary: a paid triple run can consume its claim once."""
    try:
        claim = json.loads((PAID_STATE_ROOT / "run-claim.json").read_text(encoding="utf-8"))
        valid = (not injected and claim["output"] == str(Path(output).resolve().parent) and
                 claim["source_sha256"] == source_metadata()["source_sha256"] and
                 Path(config.llm_ledger_path).resolve() == (PAID_STATE_ROOT / "paid-call-ledger.json").resolve())
    except (OSError, ValueError, KeyError, TypeError):
        valid = False
    if not valid:
        raise ValueError("Paid triple Runner requires the dedicated frozen preflight and durable run claim")
    try:
        with (PAID_STATE_ROOT / "execution-started.json").open("x", encoding="utf-8") as stream:
            json.dump({"output": str(Path(output).resolve())}, stream)
    except FileExistsError:
        raise ValueError("Paid triple execution claim was already consumed") from None


def profile_config(backend="mock", *, ledger_path="", tokenizer_path=""):
    return ExperimentConfig(scenario="triple_abrupt", n_batches=30, seed=7,
        harness_enabled=True, deployment_validation="future", training_preflight=True,
        candidate_feasibility=True, harness_drift_only=True, label_mode="provided", max_labels=0,
        max_llm_calls=5, max_llm_cost_cny="0.16", max_tokens=20000, llm_timeout_seconds=15,
        harness_backend=backend, llm_ledger_path=str(ledger_path), llm_tokenizer_path=str(tokenizer_path))


def _read_events(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]


def _validate_preflight(path, config):
    if path is None:
        raise ValueError("Real triple run requires a matching Mock preflight directory")
    path = Path(path)
    events = _read_events(path / "drift/events.jsonl")
    audit = audit_iterations(events)
    started = next(e for e in events if e["event"] == "run_started")
    expected = config.to_dict()
    previous = dict(started["config"])
    # These select the transport and local paths, not evidence or update rules.
    for key in ("harness_backend", "llm_ledger_path", "llm_tokenizer_path"):
        expected.pop(key)
        previous.pop(key)
    expected = json.loads(json.dumps(expected))
    if (not audit["engineering_target_met"] or previous != expected or
            started["config"]["harness_backend"] != "mock" or
            started["source_sha256"] != source_metadata()["source_sha256"] or
            started.get("data_source", {}).get("kind") != "synthetic" or
            started.get("data_source", {}).get("scenario") != "triple_abrupt" or
            any(e["event"] == "harness_call" and e.get("token_accounting_mode") != "mock" for e in events)):
        raise ValueError("Mock preflight source/configuration does not match the frozen real profile")


def run_three_abrupt(output, *, backend="mock", tokenizer_path="", preflight=None):
    output = Path(output)
    config = profile_config(backend, ledger_path=PAID_STATE_ROOT / "paid-call-ledger.json" if backend == "pytrio" else "",
                            tokenizer_path=tokenizer_path)
    if backend == "pytrio":
        _validate_preflight(preflight, config)
        if output.exists():
            raise FileExistsError("Refusing to overwrite a paid experiment")
        PAID_STATE_ROOT.mkdir(parents=True, exist_ok=True)
        # A profile-wide exclusive claim prevents another output directory from
        # silently creating a new paid allowance after a failure or restart.
        try:
            with (PAID_STATE_ROOT / "run-claim.json").open("x", encoding="utf-8") as stream:
                json.dump({"profile": "triple-abrupt-v1", "output": str(output.resolve()),
                           "source_sha256": source_metadata()["source_sha256"]}, stream)
        except FileExistsError:
            raise FileExistsError("This paid profile already has a durable run claim; no automatic second run") from None
    output.mkdir(parents=True, exist_ok=False)
    write_json(output / "config.json", config.to_dict())
    write_json(output / "stream-manifest.json", {"batches": 30, "seed": 7,
        "changes_zero_based": [2, 10, 18], "regimes": [[0, 2, "A"], [2, 10, "B"], [10, 18, "A"], [18, 30, "B"]],
        "truth_use": "offline audit only", **source_metadata()})
    trainer = BoundedTrainer()
    try:
        summary = run_policy(config, "drift", output / "drift", trainer)
    finally:
        trainer.close()
        if backend == "pytrio" and Path(config.llm_ledger_path).is_file():
            shutil.copyfile(config.llm_ledger_path, output / "paid-call-ledger.json")
    audit = audit_iterations(_read_events(output / "drift/events.jsonl"))
    write_json(output / "iteration-audit.json", audit)
    return {"summary": summary, "audit": audit}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--backend", choices=("mock", "pytrio"), default="mock")
    parser.add_argument("--tokenizer", default="")
    parser.add_argument("--preflight", type=Path)
    args = parser.parse_args(argv)
    result = run_three_abrupt(args.output, backend=args.backend, tokenizer_path=args.tokenizer, preflight=args.preflight)
    print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
    return 0 if result["audit"]["engineering_target_met"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
