"""Pre-registered 144-run Mock matrix; real providers are explicitly rejected."""

import argparse
import json
from pathlib import Path

from .config import ExperimentConfig, SCENARIOS
from .report import render_report
from .runner import run_policy
from .tracking import source_metadata, write_json
from .training import BoundedTrainer


def matrix_cases(base=None):
    base = base or ExperimentConfig(harness_enabled=True, deployment_validation="future",
        training_preflight=True, candidate_feasibility=True, max_tokens=40000,
        max_llm_calls=10, label_mode="provided", harness_drift_only=True)
    if base.harness_backend != "mock":
        raise ValueError("Harness stress matrices must use Mock only")
    cases = []
    for task in ("classification", "regression"):
        for scenario in SCENARIOS:
            for seed in (7, 19, 43):
                for group, mode, policies in (("normal", "normal", ("static", "drift")),
                                              ("invalid-json", "invalid_json", ("drift",)),
                                              ("token-exhausted", "token_exhausted", ("drift",))):
                    config = ExperimentConfig.from_dict({**base.to_dict(), "task": task, "scenario": scenario,
                        "seed": seed, "n_batches": 96, "harness_mock_mode": mode})
                    for policy in policies:
                        cases.append((f"{group}/{task}/{scenario}/seed-{seed}/{policy}", config, policy))
    return cases


def audit_protocol(events, result, *, batches=96):
    predictions = [entry for entry in events if entry["event"] == "prediction"]
    if len(predictions) != batches or result.get("real_llm_tokens", 0) != 0:
        raise RuntimeError("Invalid Mock completion")
    trip_index = next((index for index, entry in enumerate(events)
                       if entry["event"] == "budget_guard_tripped"), None)
    tripped = events[trip_index] if trip_index is not None else None
    if tripped is not None:
        after = events[trip_index + 1:]
        forbidden = ("deploy", "rollback", "harness_call", "experiment_started", "candidate_frozen",
                     "candidate_evaluated", "candidate_selection")
        if (any(entry["event"] in forbidden for entry in after) or
                any(entry["event"] == "labels_requested" and entry["count"] > 0 for entry in after)):
            raise RuntimeError("Work continued after fallback")
    return {"prediction_batches": len(predictions), "llm_calls": result.get("llm_calls", 0),
            "fault_triggered": bool(tripped), "trip_reason": tripped.get("reason") if tripped else None}


def run_matrix(output, base=None):
    cases = matrix_cases(base)
    root = Path(output)
    root.mkdir(parents=True, exist_ok=False)
    write_json(root / "provenance.json", {"runs": len(cases), "scope": "mock_protocol_stress",
                                           "real_requests": 0, **source_metadata()})
    results, audit = [], []
    for index, (name, config, policy) in enumerate(cases, 1):
        print(f"[{index}/{len(cases)}] {name}", flush=True)
        with BoundedTrainer() as trainer:
            result = run_policy(config, policy, root / name, trainer)
        event_path = root / name / "events.jsonl"
        events = [json.loads(line) for line in event_path.read_text(encoding="utf-8").splitlines()]
        checks = audit_protocol(events, result)
        result["experiment_group"] = name.split("/")[0]
        result["curve_file"] = f"{name}/curve.csv"
        results.append(result)
        audit.append({"run": name, **checks,
            "note": "No eligible drift means fault was not invoked" if policy == "drift" and not result.get("llm_calls") else None})
    render_report(root, results, title="144 次 Mock Harness 工程压力验证")
    write_json(root / "protocol-audit.json", {"runs": len(audit), "real_requests": 0, "checks": audit})
    return results


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    run_matrix(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
