"""Paired held-out gates for experimental deployment policies."""

import csv
from pathlib import Path

TASKS = ("classification", "regression")
SCENARIOS = ("stable", "abrupt", "gradual", "recurring", "covariate", "noise")
POLICIES = ("static", "periodic", "drift")


def _read_matrix(path):
    rows = {}
    with Path(path).open(encoding="utf-8", newline="") as stream:
        for row in csv.DictReader(stream):
            key = (row["task"], row["scenario"], int(row["seed"]), row["policy"])
            if key in rows:
                raise ValueError(f"Duplicate matrix row: {key}")
            rows[key] = float(row["mean_loss"])
    return rows


def _missing(rows, seeds, policies):
    return [(task, scenario, seed, policy)
            for task in TASKS for scenario in SCENARIOS for seed in seeds for policy in policies
            if (task, scenario, seed, policy) not in rows]


def _mean(rows, task, scenario, seeds, policy):
    return sum(rows[(task, scenario, seed, policy)] for seed in seeds) / len(seeds)


def _evaluate(baseline, candidate, seeds, policies, reference_static):
    missing = [{"task": t, "scenario": s, "seed": seed, "policy": p}
               for t, s, seed, p in _missing(baseline, seeds, POLICIES)
               + _missing(candidate, seeds, policies)]
    failures = [{"task": item["task"], "scenario": item["scenario"], "reason": "missing_seed_or_policy",
                 "seed": item["seed"], "policy": item["policy"]} for item in missing]
    groups = []
    if not failures:
        for task in TASKS:
            for scenario in SCENARIOS:
                candidate_loss = _mean(candidate, task, scenario, seeds, "drift")
                reference_loss = (_mean(reference_static, task, scenario, seeds, "static")
                                  if reference_static is not None else None)
                baseline_loss = _mean(baseline, task, scenario, seeds, "drift")
                if scenario == "recurring":
                    passed = candidate_loss <= reference_loss + 1e-12
                    limit, reason = reference_loss, "recurring_above_static"
                else:
                    tolerance = 0.005 if task == "classification" else 0.01
                    passed = candidate_loss - baseline_loss <= tolerance + 1e-12
                    limit, reason = tolerance, "regression_tolerance_exceeded"
                groups.append({"task": task, "scenario": scenario, "candidate_drift_loss": candidate_loss,
                               "baseline_drift_loss": baseline_loss, "comparison_static_loss": reference_loss,
                               "threshold": limit, "passed": passed})
                if not passed:
                    failures.append({"task": task, "scenario": scenario, "reason": reason,
                                     "candidate_drift_loss": candidate_loss,
                                     "baseline_drift_loss": baseline_loss,
                                     "comparison_static_loss": reference_loss, "threshold": limit})
    return {"passed": not failures, "failure_count": len(failures), "failures": failures,
            "groups": groups, "seeds": list(seeds)}


def assess_deployment(baseline_csv, prospective_csv, history_csv=None, seeds=(101, 103, 107, 109, 113)):
    seeds = tuple(seeds)
    if not seeds or len(set(seeds)) != len(seeds):
        raise ValueError("Specify at least one unique independent seed")
    baseline, prospective = _read_matrix(baseline_csv), _read_matrix(prospective_csv)
    candidate = _evaluate(baseline, prospective, seeds, POLICIES, prospective)
    result = {"candidate_passed": candidate["passed"], "failure_count": candidate["failure_count"],
              "failures": candidate["failures"], "candidate_groups": candidate["groups"],
              "seeds": list(seeds),
              "criteria": {"recurring": "candidate drift mean loss <= same-matrix static loss for both tasks",
                           "other_classification": "paired-seed mean loss regression <= 0.005",
                           "other_regression": "paired-seed mean normalized MSE regression <= 0.01"}}
    if history_csv is not None:
        history = _read_matrix(history_csv)
        evaluated = _evaluate(baseline, history, seeds, ("drift",), prospective)
        result["history_reuse_passed"] = evaluated["passed"]
        result["history_reuse_failure_count"] = evaluated["failure_count"]
        result["history_reuse_failures"] = evaluated["failures"]
        result["history_reuse_groups"] = evaluated["groups"]
    else:
        result["history_reuse_passed"] = None
    return result
