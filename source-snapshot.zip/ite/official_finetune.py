"""Reviewed NumPy head updates; the vendor full-fit path remains untouched."""

import math

import numpy as np

LOSS_POLICIES = ("squared", "overestimate_2x", "official_anchor_l2")
A_THREE_CLASS_HEAD = "a_three_class_head"
A_HEAD_CLASSES = ("Ethanol", "Acetaldehyde", "Acetone")
C_REFERENCE_SHA256 = "98ec6e30e38aee56ca15b7d624a8f412226d46fe97b170667a567601c700bc4e"


def fit_head_only(model, features, targets, epochs, *, loss_policy="squared", reference=None,
                  columns=slice(None)):
    """Match vendor shuffling, loss, full gradient clipping and shared Adam clock."""
    if loss_policy not in LOSS_POLICIES:
        raise ValueError("Unsupported official loss_policy")
    if loss_policy != "squared" and model.meta["task"] != "regression":
        raise ValueError("Alternative head losses are restricted to regression")
    anchored = loss_policy == "official_anchor_l2"
    if anchored and reference is None:
        raise ValueError("Fixed official reference is required")
    anchor_gradient_steps = 0
    x = model.normalized(features)
    target = ((targets-model.meta["target_mean"])/model.meta["target_scale"]
              if model.meta["task"] == "regression" else targets)
    for _ in range(epochs):
        order = np.random.default_rng(np.random.SeedSequence(
            [model.meta["seed"], model.meta["epochs"]])).permutation(len(x))
        for start in range(0, len(order), model.meta["batch_size"]):
            indices = order[start:start+model.meta["batch_size"]]
            batch, expected = x[indices], target[indices]
            hidden, logits = model.forward(batch)
            if model.meta["task"] == "classification":
                logits -= logits.max(axis=1, keepdims=True)
                delta = np.exp(logits)
                delta /= delta.sum(axis=1, keepdims=True)
                delta[np.arange(len(indices)), expected] -= 1
                delta /= len(indices)
            else:
                residual = logits[:, 0]-expected
                penalty = 2. if loss_policy == "overestimate_2x" else 1.
                delta = (2*residual*np.where(residual > 0, penalty, 1.)/len(indices))[:, None]
            gradients = {"w2": hidden.T@delta, "b2": delta.sum(axis=0)}
            hidden_delta = (delta@model.params["w2"].T)*(1-hidden**2)
            gradients.update(w1=batch.T@hidden_delta, b1=hidden_delta.sum(axis=0))
            if anchored:
                correction = {name: 2*(model.params[name]-reference.params[name]) for name in ("w2", "b2")}
                anchor_gradient_steps += int(any(np.any(value != 0) for value in correction.values()))
                for name, value in correction.items():
                    gradients[name] += value
            # Retain the vendor norm across all gradients: only the update mask changes.
            norm = math.sqrt(sum(float(np.sum(g*g)) for g in gradients.values()))
            if not math.isfinite(norm):
                raise ValueError("nonfinite gradient")
            model.meta["steps"] += 1
            for name in ("w2", "b2"):
                index = (..., columns)
                gradient = gradients[name][index]
                gradient *= min(1., 5./max(norm, 1e-12))
                first_moment = .9*model.first[name][index] + .1*gradient
                second_moment = .999*model.second[name][index] + .001*gradient**2
                model.first[name][index] = first_moment
                model.second[name][index] = second_moment
                first = first_moment/(1-.9**model.meta["steps"])
                second = second_moment/(1-.999**model.meta["steps"])
                model.params[name][index] -= model.meta["learning_rate"]*first/(np.sqrt(second)+1e-8)
            if not all(np.isfinite(value).all() for value in model.params.values()):
                raise ValueError("nonfinite model state")
        model.meta["epochs"] += 1
    model.validate()
    return anchor_gradient_steps


def fit_with_audit(model, features, targets, epochs, policy, loss_policy="squared", *, reference=None,
                   reference_sha256=None):
    if policy not in ("full", "head_only", A_THREE_CLASS_HEAD):
        raise ValueError("Unsupported official trainable_policy")
    columns = slice(None)
    if policy == A_THREE_CLASS_HEAD:
        if model.meta["task"] != "classification" or model.meta.get("profile", "A") != "A":
            raise ValueError("The three-class head is restricted to A")
        classes = model.meta["classes"]
        columns = [classes.index(label) for label in A_HEAD_CLASSES]
    if loss_policy not in LOSS_POLICIES:
        raise ValueError("Unsupported official loss_policy")
    if loss_policy != "squared" and (policy != "head_only" or model.meta["task"] != "regression" or
                                      model.meta.get("profile") != "C"):
        raise ValueError("Alternative losses are restricted to C head_only regression")
    anchored = loss_policy == "official_anchor_l2"
    if anchored:
        if reference is None or reference_sha256 != C_REFERENCE_SHA256:
            raise ValueError("Fixed official reference checkpoint digest is required")
        if (any(model.meta[key] != reference.meta[key] for key in
                ("profile", "task", "paths", "target_mean", "target_scale")) or
                any(not np.array_equal(model.params[key], reference.params[key]) for key in ("w1", "b1")) or
                any(not np.array_equal(getattr(model, key), getattr(reference, key)) for key in ("mean", "scale"))):
            raise ValueError("Parent is incompatible with the fixed official reference")
        distance_before = sum(float(np.sum((model.params[k]-reference.params[k])**2)) for k in ("w2", "b2"))
    before = {name: value.copy() for name, value in model.params.items()}
    moments = {group: {name: getattr(model, group)[name].copy() for name in ("w1", "b1")}
               for group in ("first", "second")}
    if policy == "full":
        model.fit(features, targets, epochs)
    else:
        active_steps = fit_head_only(model, features, targets, epochs, loss_policy=loss_policy,
                                     reference=reference, columns=columns)
        if any(before[name].tobytes() != model.params[name].tobytes() for name in ("w1", "b1")) or any(
                moments[group][name].tobytes() != getattr(model, group)[name].tobytes()
                for group in moments for name in ("w1", "b1")):
            raise ValueError("Frozen official parameters or Adam state changed")
    audit = {"trainable_policy": policy,
            "trainable_parameters": (sum(value.size for value in model.params.values()) if policy == "full" else
                                     sum(model.params[name][..., columns].size for name in ("w2", "b2"))),
            "max_parameter_delta": {name: float(np.max(np.abs(model.params[name]-value)))
                                    for name, value in before.items()},
            "learning_rate": model.meta["learning_rate"], "batch_size": model.meta["batch_size"],
            "epochs_added": epochs, "loss_policy": loss_policy,
            "overestimate_penalty": 2. if loss_policy == "overestimate_2x" else 1.,
            "adam_clock": "vendor_shared_steps"}
    if policy == A_THREE_CLASS_HEAD:
        audit["trainable_classes"] = list(A_HEAD_CLASSES)
    if anchored:
        audit.update(reference_checkpoint_sha256=reference_sha256, anchor_lambda=1.,
            anchor_normalization="sum_head_parameter_squares; standardized_target_mean_squared_error",
            anchor_squared_distance_before=distance_before,
            anchor_squared_distance_after=sum(float(np.sum((model.params[k]-reference.params[k])**2)) for k in ("w2", "b2")),
            anchor_gradient_steps=active_steps, anchor_applied_before_gradient_clipping=True)
    return audit
