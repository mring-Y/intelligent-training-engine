"""Reviewed NumPy head updates; the vendor full-fit path remains untouched."""

import math

import numpy as np


def fit_head_only(model, features, targets, epochs, *, loss_policy="squared"):
    """Match vendor shuffling, loss, full gradient clipping and shared Adam clock."""
    if loss_policy not in ("squared", "overestimate_2x"):
        raise ValueError("Unsupported official loss_policy")
    if loss_policy != "squared" and model.meta["task"] != "regression":
        raise ValueError("Asymmetric overestimation loss is restricted to regression")
    x = model.normalized(features)
    target = ((targets-model.meta["target_mean"])/model.meta["target_scale"]
              if model.meta["task"] == "regression" else targets)
    for _ in range(epochs):
        order = np.random.default_rng(np.random.SeedSequence(
            [model.meta["seed"], model.meta["epochs"]])).permutation(len(x))
        for start in range(0, len(order), model.meta["batch_size"]):
            indices = order[start:start+model.meta["batch_size"]]
            batch, expected = x[indices], target[indices]
            hidden, logits = model.forward(batch)
            if model.meta["task"] == "classification":
                logits -= logits.max(axis=1, keepdims=True)
                delta = np.exp(logits)
                delta /= delta.sum(axis=1, keepdims=True)
                delta[np.arange(len(indices)), expected] -= 1
                delta /= len(indices)
            else:
                residual = logits[:, 0]-expected
                penalty = 2. if loss_policy == "overestimate_2x" else 1.
                delta = (2*residual*np.where(residual > 0, penalty, 1.)/len(indices))[:, None]
            gradients = {"w2": hidden.T@delta, "b2": delta.sum(axis=0)}
            hidden_delta = (delta@model.params["w2"].T)*(1-hidden**2)
            gradients.update(w1=batch.T@hidden_delta, b1=hidden_delta.sum(axis=0))
            # Retain the vendor norm across all gradients: only the update mask changes.
            norm = math.sqrt(sum(float(np.sum(g*g)) for g in gradients.values()))
            if not math.isfinite(norm):
                raise ValueError("nonfinite gradient")
            model.meta["steps"] += 1
            for name in ("w2", "b2"):
                gradient = gradients[name]
                gradient *= min(1., 5./max(norm, 1e-12))
                model.first[name] = .9*model.first[name] + .1*gradient
                model.second[name] = .999*model.second[name] + .001*gradient**2
                first = model.first[name]/(1-.9**model.meta["steps"])
                second = model.second[name]/(1-.999**model.meta["steps"])
                model.params[name] -= model.meta["learning_rate"]*first/(np.sqrt(second)+1e-8)
            if not all(np.isfinite(value).all() for value in model.params.values()):
                raise ValueError("nonfinite model state")
        model.meta["epochs"] += 1
    model.validate()


def fit_with_audit(model, features, targets, epochs, policy, loss_policy="squared"):
    if policy not in ("full", "head_only"):
        raise ValueError("Unsupported official trainable_policy")
    if loss_policy not in ("squared", "overestimate_2x"):
        raise ValueError("Unsupported official loss_policy")
    if loss_policy != "squared" and (policy != "head_only" or model.meta["task"] != "regression" or
                                      model.meta.get("profile") != "C"):
        raise ValueError("Asymmetric overestimation loss is restricted to C head_only regression")
    before = {name: value.copy() for name, value in model.params.items()}
    moments = {group: {name: getattr(model, group)[name].copy() for name in ("w1", "b1")}
               for group in ("first", "second")}
    if policy == "full":
        model.fit(features, targets, epochs)
    else:
        fit_head_only(model, features, targets, epochs, loss_policy=loss_policy)
        if any(before[name].tobytes() != model.params[name].tobytes() for name in ("w1", "b1")) or any(
                moments[group][name].tobytes() != getattr(model, group)[name].tobytes()
                for group in moments for name in ("w1", "b1")):
            raise ValueError("Frozen official parameters or Adam state changed")
    return {"trainable_policy": policy,
            "trainable_parameters": sum(model.params[name].size for name in
                (("w2", "b2") if policy == "head_only" else model.params)),
            "max_parameter_delta": {name: float(np.max(np.abs(model.params[name]-value)))
                                    for name, value in before.items()},
            "learning_rate": model.meta["learning_rate"], "batch_size": model.meta["batch_size"],
            "epochs_added": epochs, "loss_policy": loss_policy,
            "overestimate_penalty": 2. if loss_policy == "overestimate_2x" else 1.,
            "adam_clock": "vendor_shared_steps"}
