"""Hard-deadline process boundary for one PyTRiO-compatible chat request."""

import json
import math
import subprocess
import sys
import time
from decimal import Decimal, InvalidOperation

from .config import (DEFAULT_LLM_MODEL, DEFAULT_LLM_INPUT_PRICE_PER_MILLION,
                     DEFAULT_LLM_OUTPUT_PRICE_PER_MILLION)
from .harness import (ACTION_SCHEMA, OFFICIAL_ACTION_SCHEMA, OFFICIAL_C_CALIBRATION_ACTION_SCHEMA,
                      BaseLLMClient, LLMReply, validate_observation)


SYSTEM_PROMPT_BASE = """你是一名工业模型漂移诊断专家。请依据当前已揭晓的损失趋势、漂移报警和预算，提出一个受控的维护建议。

Observation 中剩余标签预算为 null 表示平台按协议提供标签，不代表可以查看未揭晓标签。只依据 JSON 中已观察的信息。证据不足、无漂移或预算风险较高时选择 DO_NOTHING。漂移报警不保证重训会改善模型。

如果当前证据不足、动作无法决定或建议超出白名单，必须返回 DO_NOTHING。

RETRAIN_SMALL 和 RETRAIN_LARGE 仅表示请求宿主执行已配置的白名单候选；不得生成 window、alpha 或其他超参数。ROLLBACK 仅请求评估上一部署模型。所有建议都必须经过宿主资源检查及冻结后新标签构成的独立未来门控。reason 只作审计记录，不会执行为指令。

只输出单个符合下方 JSON Schema 的对象，不要包含 Markdown、代码围栏、分析过程或 JSON 以外的文字。reason 使用一句不超过 160 字符的中文单行说明。
"""
FEW_SHOT_EXAMPLES = """格式示例：
Observation: {"loss_trend":[],"drift_alarm":false,"remaining_label_budget":null,"remaining_token_budget":8000,"model_age_batches":0}
Action: {"action":"DO_NOTHING","reason":"当前没有漂移证据，保持现有模型。"}

Observation: {"loss_trend":[{"source_step":12,"loss":0.92,"labeled_samples":96},{"source_step":13,"loss":0.95,"labeled_samples":96}],"drift_alarm":true,"remaining_label_budget":384,"remaining_token_budget":8000,"model_age_batches":20}
Action: {"action":"RETRAIN_SMALL","reason":"连续已标注批次损失上升，可评估白名单小规模候选。"}

动作无法决定时必须返回 DO_NOTHING；示例不授权任何额外参数。
"""
SYSTEM_PROMPT = SYSTEM_PROMPT_BASE + "\n" + FEW_SHOT_EXAMPLES
TREE_MODEL_PROMPT = ("当前使用的是非线性树模型。在处理渐变/突变时，可以适当增加重训的窗口大小，"
                     "以获取更丰富的分支路径。这里只能通过 RETRAIN_LARGE 请求宿主已配置的窗口白名单；"
                     "不得生成窗口、树深度等额外参数，也不得跳过预算检查或独立未来门控。"
                     "更大窗口可能混入旧概念，不保证改善。")
CMAPSS_DEFENSE_PROMPT = """你当前的模型是树模型，已发现性能波动。请谨慎决策；不恰当的小样本更新可能破坏现有模型。

当前 Observation 仅含最近已释放标签的 Loss 趋势和每来源样本数，不含原始传感器向量或当前样本的传感器统计量。不要声称当前输入显示了剧烈特征漂移。

同一 FD001 流的既往筛选记录显示：192 条训练样本得到的候选，在与训练样本隔离的 48 条筛选样本上 RMSE 为 29.77 周期，现模型为 28.25，候选因此在筛选阶段被拒绝，未进入独立未来门控。该单次结果提示候选风险，但不能证明小样本重训普遍过拟合。

同流既往 step10 审计的 feature_shift=false；这是历史审计上下文，不是当前 Observation 里的字段。若没有足够的新证据，DO_NOTHING 是有效选择。任何重训建议仍会经过宿主候选筛选和独立未来标签门控。
"""


def build_messages(observation, *, model_type="ridge", prompt_profile="default", official_context=None):
    validate_observation(observation)
    if model_type == "official_mlp" and prompt_profile in ("official_sft", "official_finetune"):
        context = official_context or {}
        profile = context.get("profile")
        if profile not in ("A", "B", "C"):
            raise ValueError("Official SFT requires an explicit A/B/C profile")
        visible = {key: context[key] for key in ("remaining_train_seconds", "feature_distance")}
        if any(isinstance(v, bool) or not isinstance(v, (int, float)) or
               not math.isfinite(v) or v < 0 for v in visible.values()):
            raise ValueError("Invalid visible official context")
        dimensions, objective = {"A": (128, "6类气体分类，提高Macro-F1"),
                                 "B": (34, "轴承RUL回归，降低分钟RMSE和MAE"),
                                 "C": (24, "发动机RUL回归，降低循环RMSE及寿命高估")}[profile]
        prompt = (f"你的目标是辅助官方CPU模型（A/B/C分别为128/34/24维输入），在检测到漂移时通过续训（resume）挽救其性能。"
            f"当前为{profile}包、{dimensions}维输入的官方NumPy MLP；目标为{objective}，争取超过同流官方静态检查点。"
            "候选必须从当前部署检查点resume，保留Adam与标准化状态。"
            "只依据已揭晓Loss和当前可见证据。Loss为分类错误率或按训练集目标方差归一化的MSE。"
            "remaining_label_budget=null表示协议提供标签，绝非预算耗尽；remaining_token_budget才是剩余Token。"
            "feature_distance是当前特征均值相对初始标准化统计的距离，不保证存在概念漂移。"
            "RETRAIN_SMALL/LARGE仅请求宿主最近192/768条已释放样本（另留筛选集）；单候选最多5秒、每流总训练20秒。"
            "小窗口可能破坏已有分布，大窗口也可能混入旧分布。ROLLBACK本试验不支持；证据不足请选择DO_NOTHING。"
            "所有候选仍须通过隔离筛选与冻结后独立未来标签门控，不能保证上线或改善。"
            "只返回单个JSON对象，不输出分析过程；reason为一句不超过160字符的中文单行理由，不得添加参数。\n"
            + json.dumps({"profile": profile, **visible}, ensure_ascii=False, separators=(",", ":"))
            + "\nAction JSON Schema:\n" + json.dumps(ACTION_SCHEMA, ensure_ascii=False, separators=(",", ":")))
        if prompt_profile == "official_finetune":
            prompt = prompt[:prompt.index("\nAction JSON Schema:")] + (
                "\nRETRAIN_HEAD_ONLY请求最近768条已释放样本（另留筛选），仅更新w2/b2输出头，"
                "冻结w1/b1及其Adam一二阶矩；固定原学习率与5epoch，不得指定额外参数。"
                "full续训由原SMALL/LARGE动作请求。冻结底层不保证降低RMSE或寿命高估，仍须未来门控。"
                "model_age_batches仅为部署年龄；当前是预训练静态检查点，Loss变化不表示模型正在学习。")
            schema = OFFICIAL_ACTION_SCHEMA
            if profile == "C":
                prompt += ("C包还可选择CALIBRATE_DOWN：宿主用最近已揭晓历史残差报告高估率和幅度，"
                    "从训练窗之前的前一来源批次取独立48条标签，取原始预测减标签残差的经验90分位数，"
                    "再用max(0,该分位数)设安全裕度；"
                    "该动作同时请求固定720条head_only续训，校准后的候选先筛选，再由独立未来标签门控。"
                    "训练/筛选/校准来源必须互斥，证据缺失则宿主拒绝；此动作不保证整体RMSE改善。")
                schema = OFFICIAL_C_CALIBRATION_ACTION_SCHEMA
            prompt += ("\nAction JSON Schema:\n" + json.dumps(schema, ensure_ascii=False, separators=(",", ":")))
        return [{"role": "system", "content": prompt}, {"role": "user", "content": json.dumps(
            observation, ensure_ascii=False, allow_nan=False, separators=(",", ":"))}]
    if model_type not in ("ridge", "tree"):
        raise ValueError("Unsupported prediction model type")
    if prompt_profile not in ("default", "cmapss_defense"):
        raise ValueError("Unsupported LLM prompt profile")
    if prompt_profile == "cmapss_defense" and model_type != "tree":
        raise ValueError("C-MAPSS defense prompt is restricted to the tree model")
    tree_prompt = (CMAPSS_DEFENSE_PROMPT if prompt_profile == "cmapss_defense" else TREE_MODEL_PROMPT)
    context = SYSTEM_PROMPT + ("\n" + tree_prompt if model_type == "tree" else "")
    prompt = (context + "\nAction JSON Schema:\n" +
              json.dumps(ACTION_SCHEMA, ensure_ascii=False, separators=(",", ":")))
    user = json.dumps(observation, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
    return [{"role": "system", "content": prompt}, {"role": "user", "content": user}]


class TrioLLMClient(BaseLLMClient):
    """Use the PyTRiO OpenAI-compatible endpoint in a killable one-shot worker."""

    token_accounting_mode = "real"
    def __init__(self, model=DEFAULT_LLM_MODEL, max_input_tokens=2048,
                 max_output_tokens=512, timeout_seconds=15, worker_command=None, tokenizer_path="",
                 model_type="ridge", prompt_profile="default",
                 input_price_per_million=None, output_price_per_million=None, official_context=None):
        for name, value, default in (("input_price_per_million", input_price_per_million,
                                     DEFAULT_LLM_INPUT_PRICE_PER_MILLION),
                                    ("output_price_per_million", output_price_per_million,
                                     DEFAULT_LLM_OUTPUT_PRICE_PER_MILLION)):
            if value is None:
                if model != DEFAULT_LLM_MODEL:
                    raise ValueError("Nondefault LLM models require explicit input and output prices")
                value = default
            try:
                price = Decimal(str(value))
            except (InvalidOperation, ValueError):
                raise ValueError(f"{name} must be a finite positive decimal") from None
            if not price.is_finite() or price <= 0:
                raise ValueError(f"{name} must be a finite positive decimal")
            setattr(self, name, str(price))
        official = model_type == "official_mlp" and prompt_profile in ("official_sft", "official_finetune")
        if model_type not in ("ridge", "tree") and not official:
            raise ValueError("Unsupported prediction model type")
        self.model_type = model_type
        if not official and (prompt_profile not in ("default", "cmapss_defense") or (
                prompt_profile == "cmapss_defense" and model_type != "tree")):
            raise ValueError("Invalid LLM prompt profile for model type")
        self.prompt_profile = prompt_profile
        self.official_context = official_context
        self.model = model
        self.max_input_tokens = max_input_tokens
        self.max_output_tokens = max_output_tokens
        self.timeout_seconds = timeout_seconds
        self.worker_command = worker_command or [sys.executable, "-X", "utf8", "-m", "ite.trio_worker"]
        self.tokenizer_path = tokenizer_path
        if (not isinstance(model, str) or not model or type(max_input_tokens) is not int or
                max_input_tokens < 1 or type(max_output_tokens) is not int or max_output_tokens < 1 or
                isinstance(timeout_seconds, bool) or not isinstance(timeout_seconds, (int, float)) or
                not math.isfinite(timeout_seconds) or not 0 < timeout_seconds <= 15):
            raise ValueError("Invalid PyTRiO request limits")

    def get_decision(self, observation):
        messages = build_messages(observation, model_type=self.model_type,
                                  prompt_profile=self.prompt_profile, official_context=self.official_context)
        return self.get_messages(messages)

    def get_messages(self, messages):
        """Transport explicit tool conversations with the same deadline and usage checks."""
        if (not isinstance(messages, list) or not messages or len(messages) > 16 or
                any(not isinstance(m, dict) or set(m) != {"role", "content"} or
                    m["role"] not in ("system", "user", "assistant") or not isinstance(m["content"], str)
                    for m in messages)):
            raise ValueError("Explicit messages must contain bounded role/content records")
        deadline = time.monotonic() + self.timeout_seconds
        request = {"model": self.model, "messages": messages,
                   "max_input_tokens": self.max_input_tokens,
                   "max_output_tokens": self.max_output_tokens, "tokenizer_path": self.tokenizer_path,
                   "deadline_monotonic": deadline}
        try:
            worker = subprocess.Popen(self.worker_command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                      stderr=subprocess.DEVNULL, text=True, encoding="utf-8")
        except OSError as error:
            raise RuntimeError("worker_start_failed") from None
        try:
            stdout, _ = worker.communicate(json.dumps(request, ensure_ascii=False),
                                           timeout=max(0, deadline - time.monotonic()))
        except subprocess.TimeoutExpired:
            worker.kill()
            worker.communicate()
            raise TimeoutError("PyTRiO request exceeded its hard deadline") from None
        try:
            result = json.loads(stdout)
        except (ValueError, TypeError):
            raise ValueError("Malformed PyTRiO worker response") from None
        if worker.returncode != 0 or not isinstance(result, dict) or "error" in result:
            code = result.get("error", "worker_failed") if isinstance(result, dict) else "worker_failed"
            if code == "client_timeout":
                raise TimeoutError("PyTRiO request exceeded its hard deadline")
            raise RuntimeError(str(code))
        expected = {"content", "input_tokens", "output_tokens", "finish_reason"}
        if set(result) != expected:
            raise ValueError("Malformed PyTRiO worker response fields")
        inputs, outputs, content, stop_reason = (result["input_tokens"], result["output_tokens"],
                                                  result["content"], result["finish_reason"])
        if (type(inputs) is not int or inputs < 0 or
                type(outputs) is not int or outputs < 0 or
                not isinstance(content, str) or not isinstance(stop_reason, str)):
            raise ValueError("Invalid PyTRiO response usage")
        return LLMReply(content, inputs + outputs, "real", inputs, outputs, stop_reason)
