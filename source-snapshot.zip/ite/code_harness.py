"""CPU-only optimization tools with an intentionally small executable-code grammar.

Model code is a checked wrapper around a supplied capability, never arbitrary
Python. Validation labels and checkpoint selection remain host responsibilities.
"""

import ast
import hashlib
import json
from pathlib import Path
import time
import zipfile

import numpy as np

from .controller import DeploymentGate
from .models import prediction_loss
from .official_model import OfficialModelAdapter
from .official_sft_data import flatten_features, load_public_package, metrics, transform_features
from .official_sft_replay import _bounded_fit


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_new(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n")


def candidate_source(epochs, policy):
    return ("def train_candidate(train, parent, x, y, seconds):\n"
            f"    return train(parent, x, y, seconds, epochs={epochs!r}, trainable_policy={policy!r})\n")


def compile_candidate(source, *, previous, seen, parent):
    if not isinstance(source, str) or len(source.encode("utf-8")) > 2048:
        raise ValueError("Candidate code must be bounded Python source")
    try:
        tree = ast.parse(source)
    except (SyntaxError, ValueError):
        raise ValueError("Candidate code has invalid syntax") from None
    # Compare the entire AST against ten tiny programs. Imports, attributes,
    # globals, extra statements and alternative call targets cannot execute.
    for epochs in range(1, 6):
        for policy in ("full", "head_only"):
            expected = ast.parse(candidate_source(epochs, policy))
            if ast.dump(tree) != ast.dump(expected):
                continue
            config = {"epochs": epochs, "trainable_policy": policy}
            if sum(config[k] != previous[k] for k in config) != 1:
                raise ValueError("Each proposal must change exactly one permitted factor")
            if (parent, epochs, policy) in seen:
                raise ValueError("Duplicate configuration for the same parent checkpoint")
            namespace = {"__builtins__": {}}
            exec(compile(tree, "<checked-candidate>", "exec"), namespace)
            return config, namespace["train_candidate"]
    raise ValueError("Candidate code is outside the executable whitelist")


def round_blocks(count):
    if type(count) is not int or count < 84:
        raise ValueError("Ten rounds require 21 disjoint blocks of at least four rows")
    return [part.astype(int) for part in np.array_split(np.arange(count), 21)]


def load_round_data(profile, package_path=None):
    data = load_public_package(profile, package_path)
    with zipfile.ZipFile(data["package"]) as archive:
        training = [json.loads(line) for line in archive.read("public/train.jsonl").decode("utf-8").splitlines() if line]
        documents = {name: archive.read(name).decode("utf-8") for name in ("TASK.md", "TRAINING_GUIDE.md")}
    # Fixed before any model calls or validation scoring; no validation rows
    # or source-specific outcome statistics influence gradient membership.
    indices = np.linspace(0, len(training)-1, min(720, len(training)), dtype=int)
    features, targets, ids = [], [], []
    classes = ("Ethanol", "Ethylene", "Ammonia", "Acetaldehyde", "Acetone", "Toluene")
    for index in indices:
        row = training[int(index)]
        values, paths = flatten_features(row["inputs"])
        if paths != data["feature_paths"]:
            raise ValueError("Training feature paths do not match the official checkpoint contract")
        features.append(values)
        targets.append(classes.index(row["answer"])+1 if profile == "A" else float(row["answer"]))
        ids.append(row["id"])
    if set(ids) & set(data["ids"]) or len(set(ids)) != len(ids):
        raise ValueError("Gradient data must be unique official training IDs")
    data.update(train_x=np.asarray(features, dtype=float), train_y=np.asarray(targets), train_ids=ids,
                documents=documents, training_selection="ordered_linspace_max720_v1")
    return data


def bounded_train(parent, x, y, seconds, *, epochs, trainable_policy):
    candidate_parent = OfficialModelAdapter.from_state(parent.state())
    candidate_parent.candidate_epochs = epochs
    return _bounded_fit(candidate_parent, x, y, seconds, trainable_policy=trainable_policy)


class TenRoundRun:
    def __init__(self, output, data, model, *, trainer=bounded_train):
        self.output = Path(output)
        self.output.mkdir(parents=True, exist_ok=False)
        self.data, self.model, self.initial, self.trainer = data, model, model, trainer
        self.blocks = round_blocks(len(data["ids"]))
        if (len(set(data["ids"])) != len(data["ids"]) or
                set(data["train_ids"]) & set(data["ids"])):
            raise ValueError("Training and validation IDs must be unique and disjoint")
        self.previous = {"epochs": 5, "trainable_policy": "full"}
        self.source = candidate_source(5, "full")
        self.seen, self.history, self.pending = set(), [], None
        self.trained_seconds, self.attempts, self.completed_rounds, self.version = 0., 0, 0, 0
        model.save(self.output / "initial.npz")
        manifest = {"profile": data["profile"], "development_only": True,
            "initial_checkpoint": model.checkpoint_sha256, "train_ids": data["train_ids"],
            "training_selection": data.get("training_selection", "test_fixture"),
            "validation_blocks": [[data["ids"][i] for i in part] for part in self.blocks],
            "total_rounds": 10, "candidate_seconds": 5., "package_train_seconds": 20.,
            "no_validation_gradients": True, "hidden_test_evaluated": False,
            "data_notice": "Previously seen public development data; no independent or hidden-set claim."}
        if "package_sha256" in data:
            manifest["package_sha256"] = data["package_sha256"]
        write_new(self.output / "manifest.json", manifest)

    def event(self, name, **fields):
        record = {"event": name, "round": self.attempts, "monotonic": time.monotonic(), **fields}
        with (self.output / "events.jsonl").open("a", encoding="utf-8", newline="\n") as stream:
            stream.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n")

    def context(self):
        options = [{"epochs": e, "trainable_policy": p} for e in range(1, 6) for p in ("full", "head_only")
            if sum({"epochs": e, "trainable_policy": p}[k] != self.previous[k] for k in self.previous) == 1
            and (self.model.checkpoint_sha256, e, p) not in self.seen]
        return {"profile": self.data["profile"], "completed_rounds": self.completed_rounds,
            "selected_checkpoint": self.model.checkpoint_sha256, "previous_proposal": self.previous,
            "allowed_next_configs": options, "history": self.history[-2:],
            "remaining_train_seconds": max(0., 20.-self.trained_seconds)}

    def read_public(self, paths):
        allowed = {**self.data["documents"], "training.py": self.source,
                   "history.json": json.dumps(self.context(), ensure_ascii=False)}
        if (not isinstance(paths, list) or not paths or len(paths) != len(set(paths)) or
                any(type(p) is not str or p not in allowed for p in paths)):
            raise ValueError("Only explicitly named public documents, training.py and history.json may be read")
        self.event("tool_read_public", paths=paths)
        return {p: allowed[p] for p in paths}

    def experiment(self, source, hypothesis):
        if self.attempts >= 10 or self.pending is not None:
            raise ValueError("Ten real trials maximum; select the pending result before another trial")
        if not isinstance(hypothesis, str) or not hypothesis.strip() or len(hypothesis) > 512:
            raise ValueError("A bounded nonempty experimental hypothesis is required")
        parent = self.model.checkpoint_sha256
        config, function = compile_candidate(source, previous=self.previous, seen=self.seen, parent=parent)
        allowance = min(5., 20.-self.trained_seconds)
        if allowance <= 0:
            raise RuntimeError("Package CPU training quota exhausted")
        self.attempts += 1
        directory = self.output / f"round-{self.attempts:02d}"
        directory.mkdir(exist_ok=False)
        (directory / "training.py").write_text(source, encoding="utf-8")
        write_new(directory / "history-before.json", self.context())
        write_new(directory / "proposal.json", {"hypothesis": hypothesis, "config": config, "parent": parent,
                                               "source_sha256": digest(directory / "training.py")})
        # Test the actual compiled code using a capability with no external
        # effects before providing the real, resource-bounded training tool.
        calls = []
        token = object()
        probe = function(lambda *a, **kw: calls.append((a, kw)) or token, token, "x", "y", allowance)
        passed = probe is token and calls == [((token, "x", "y", allowance), config)]
        write_new(directory / "code-test.json", {"passed": passed, "grammar": "single_training_call_v1"})
        if not passed:
            raise RuntimeError("Model-written training code failed its capability contract")
        self.event("tool_test_candidate", passed=True, config=config, parent=parent)
        self.seen.add((parent, config["epochs"], config["trainable_policy"]))
        self.previous, self.source = config, source
        started = time.perf_counter()
        try:
            candidate, seconds = function(self.trainer, self.model, self.data["train_x"],
                                           self.data["train_y"], allowance)
        except Exception as error:
            self.trained_seconds += time.perf_counter()-started
            self.event("training_failed", error=type(error).__name__)
            raise
        self.trained_seconds += seconds
        if (not np.isfinite(seconds) or seconds < 0 or seconds > allowance or self.trained_seconds > 20. or
                candidate.steps <= self.model.steps or self.model.checkpoint_sha256 != parent):
            self.event("training_failed", error="resource_or_parent_contract")
            raise RuntimeError("CPU resource, optimizer progress or immutable-parent contract failed")
        candidate.save(directory / "candidate.npz")
        screen, future = self.blocks[2*(self.attempts-1):2*self.attempts]
        x, y = self.data["x"], self.data["y"]
        old_screen, new_screen = self.model.predict(x[screen]), candidate.predict(x[screen])
        old_loss = prediction_loss(self.model.task, y[screen], old_screen, self.data["loss_scale"])
        new_loss = prediction_loss(self.model.task, y[screen], new_screen, self.data["loss_scale"])
        screened = new_loss < old_loss
        result = {"round": self.attempts, "config": config, "hypothesis": hypothesis,
            "parent_checkpoint": parent, "candidate_checkpoint": candidate.checkpoint_sha256,
            "parent_adam_steps": self.model.steps, "candidate_adam_steps": candidate.steps,
            "train_seconds": seconds, "train_ids": self.data["train_ids"],
            "screen_ids": [self.data["ids"][i] for i in screen],
            "gate_ids": [self.data["ids"][i] for i in future],
            "screen_incumbent": metrics(self.data["profile"], y[screen], old_screen),
            "screen_candidate": metrics(self.data["profile"], y[screen], new_screen),
            "screen_passed": bool(screened), "gate_passed": False}
        self.event("candidate_evaluated", parent=parent, candidate=candidate.checkpoint_sha256,
                   screening_passed=bool(screened), train_seconds=seconds)
        if screened:
            self.event("candidate_frozen", checkpoint=candidate.checkpoint_sha256,
                       train_ids=result["train_ids"], screen_ids=result["screen_ids"])
            # Access this round's fresh validation labels only after freeze.
            self.event("future_labels_released", gate_ids=result["gate_ids"])
            gate = DeploymentGate(self.model, 0., .05, 4, self.data["loss_scale"])
            outcome = gate.consider(candidate, x[future], y[future], self.attempts)
            result.update(gate_passed=outcome["accepted"], gate=outcome,
                gate_incumbent=metrics(self.data["profile"], y[future], self.model.predict(x[future])),
                gate_candidate=metrics(self.data["profile"], y[future], candidate.predict(x[future])))
        np.savez_compressed(directory / "screen-predictions.npz", source_ids=np.asarray(result["screen_ids"]),
                            targets=y[screen], incumbent=old_screen, candidate=new_screen)
        if screened:
            np.savez_compressed(directory / "gate-predictions.npz", source_ids=np.asarray(result["gate_ids"]),
                targets=y[future], incumbent=self.model.predict(x[future]), candidate=candidate.predict(x[future]))
        write_new(directory / "experiment.json", result)
        self.pending = {"candidate": candidate, "result": result, "directory": directory}
        return result

    @staticmethod
    def visible_result(result):
        return {k: v for k, v in result.items() if k not in ("train_ids", "screen_ids", "gate_ids")}

    def select(self, choice, reason):
        if self.pending is None or choice not in ("incumbent", "candidate") or not isinstance(reason, str) or not reason.strip() or len(reason) > 512:
            raise ValueError("A pending experiment and explicit bounded selection reason are required")
        result = self.pending["result"]
        if choice == "candidate" and not result["gate_passed"]:
            self.event("selection_refused", reason="independent_future_gate_not_passed")
            raise ValueError("Candidate selection is forbidden without screening and independent future gain")
        if choice == "candidate":
            self.model = self.pending["candidate"]
            self.version += 1
        decision = {"round": self.attempts, "choice": choice, "reason": reason,
            "selected_checkpoint": self.model.checkpoint_sha256, "version": self.version,
            "effective_from_round": self.attempts+1}
        self.model.save(self.pending["directory"] / "selected.npz")
        write_new(self.pending["directory"] / "decision.json", decision)
        self.history.append({**self.visible_result(result), "decision": decision})
        self.completed_rounds += 1
        self.event("checkpoint_selected", **{k:v for k,v in decision.items() if k != "round"})
        self.pending = None
        return decision

    def finish(self):
        final = self.blocks[-1]
        data, profile = self.data, self.data["profile"]
        scores = {}
        for scenario in ("stable", "abrupt", "gradual"):
            features = transform_features(data["x"][final], data["scale"], scenario, 7)
            static, selected = self.initial.predict(features), self.model.predict(features)
            scores[scenario] = {"static": metrics(profile, data["y"][final], static),
                                "selected": metrics(profile, data["y"][final], selected)}
            scores[scenario]["delta_selected_minus_static"] = {
                key: value-scores[scenario]["static"][key]
                for key,value in scores[scenario]["selected"].items() if type(value) in (int,float)}
            np.savez_compressed(self.output / f"final-{scenario}.npz", source_ids=np.asarray([data["ids"][i] for i in final]),
                                targets=data["y"][final], static=static, selected=selected)
        self.model.save(self.output / "selected.npz")
        result = {"profile": profile, "completed_rounds": self.completed_rounds, "training_attempts": self.attempts,
            "ten_rounds_complete": self.completed_rounds == 10 and self.pending is None,
            "train_seconds": self.trained_seconds, "initial_checkpoint": self.initial.checkpoint_sha256,
            "selected_checkpoint": self.model.checkpoint_sha256, "accepted_updates": self.version,
            "development_only": True, "hidden_test_evaluated": False, "final_development_metrics": scores}
        write_new(self.output / "summary.json", result)
        return result
