"""Explicit model dispatch shared by the Runner and its bounded worker."""

from pathlib import Path

import numpy as np

from .models import RidgeModel
from .multiclass import OneVsRestRidge
from .official_model import is_official_model_type


_LEGACY_FIELDS = {"task", "alpha", "family", "mean", "std", "weights", "intercept", "basis_mean",
                  "format_version", "model_kind", "classes"}


def make_model(task, alpha, family="ridge", *, candidate=False, model_type="ridge", tree_options=None,
               class_labels=None, official_options=None):
    if is_official_model_type(model_type):
        if family != "ridge" or alpha is not None or tree_options is not None:
            raise ValueError("Official models do not accept Ridge, quadratic or tree options")
        if not isinstance(official_options, dict):
            raise ValueError("Official model options are required")
        allowed = {"profile", "profile_type", "runtime_python", "package_path", "checkpoint_path",
                   "checkpoint_bytes", "classes", "class_labels", "candidate_epochs"}
        if set(official_options) - allowed:
            raise ValueError("Unsupported official model options")
        from .official_model import OfficialModelAdapter
        options = dict(official_options)
        profile_type = options.get("profile_type", options.get("profile", "A"))
        options.setdefault("profile_type", profile_type)
        options.setdefault("classes", OfficialModelAdapter.default_classes(profile_type))
        return OfficialModelAdapter(task, **options)
    if model_type == "tree":
        if family != "ridge":
            raise ValueError("Tree model_type conflicts with the requested model family")
        if alpha is not None:
            raise ValueError("Tree models do not accept Ridge alpha")
        from .tree_model import TreeModel
        options = {} if tree_options is None else tree_options
        if not isinstance(options, dict) or set(options) - {
                "max_depth", "min_samples_leaf", "max_leaf_nodes", "random_state"}:
            raise ValueError("Unsupported tree options")
        return TreeModel(task, **options, class_labels=class_labels, allow_missing_classes=candidate)
    if model_type != "ridge":
        raise ValueError("Unsupported model type")
    if tree_options is not None:
        raise ValueError("Tree options require model_type='tree'")
    expected = (1, 2, 3, 4, 5, 6) if family == "ovr_ridge" else (0, 1)
    if class_labels is not None and (task != "classification" or
            not isinstance(class_labels, (tuple, list)) or any(type(label) is not int for label in class_labels)
            or tuple(class_labels) != expected):
        raise ValueError("Class labels conflict with the Ridge model family")
    if family == "ovr_ridge":
        if task != "classification":
            raise ValueError("One-vs-Rest Ridge requires classification")
        return OneVsRestRidge(alpha, allow_missing_classes=candidate)
    return RidgeModel(task, alpha, family)


def model_from_state(state):
    if not isinstance(state, dict):
        raise ValueError("Model state must be a mapping")
    kind = state.get("model_kind")
    if kind == "tree":
        from .tree_model import TreeModel
        return TreeModel.from_state(state)
    if kind == "official":
        from .official_model import OfficialModelAdapter
        return OfficialModelAdapter.from_state(state)
    if kind == "ovr_ridge":
        return OneVsRestRidge.from_state(state)
    if kind is not None:
        raise ValueError("Unsupported model checkpoint kind")
    return RidgeModel.from_state(state)


def load_model(path, *, model_type="ridge", official_options=None):
    if is_official_model_type(model_type):
        if not isinstance(official_options, dict):
            raise ValueError("Official model options are required to load an official checkpoint")
        from .official_model import OfficialModelAdapter
        profile_type = official_options.get("profile_type", official_options.get("profile", "A"))
        from .official_model import OFFICIAL_PROFILES
        contract = OFFICIAL_PROFILES.get(profile_type)
        if contract is None:
            raise ValueError("Official model loading requires profile_type A, B or C")
        return OfficialModelAdapter(task=official_options.get("task", contract["task"]),
            runtime_python=official_options["runtime_python"], package_path=official_options["package_path"],
            profile_type=profile_type,
            classes=official_options.get("classes", OfficialModelAdapter.default_classes(profile_type)),
            class_labels=official_options.get("class_labels", contract["class_labels"]),
            checkpoint_path=path)
    if model_type != "ridge":
        raise ValueError("Unsupported model type for checkpoint loading")
    from .tree_model import TreeModel, preflight_npz
    with Path(path).open("rb") as stream:
        fields = preflight_npz(stream, allow_text=True)
        if "tree_format" in fields or "tree_kind" in fields:
            return TreeModel.load_stream(stream)
        if fields - _LEGACY_FIELDS:
            raise ValueError("Unknown model checkpoint fields")
        with np.load(stream, allow_pickle=False) as archive:
            values = {name: archive[name].copy() for name in archive.files}
    if "model_kind" in values:
        kind = values["model_kind"]
        if kind.shape != () or kind.item() != "ovr_ridge":
            raise ValueError("Unsupported model checkpoint kind")
        if set(values) != {"format_version", "model_kind", "classes", "alpha", "mean", "std",
                           "weights", "intercept", "basis_mean"}:
            raise ValueError("Unknown One-vs-Rest checkpoint fields")
        if (values["format_version"].shape != () or values["format_version"].dtype.kind not in "iu"
                or values["format_version"].item() != 1 or values["alpha"].shape != ()
                or any(values[name].ndim == 0 or len(values[name]) != 6
                       for name in ("mean", "std", "weights", "intercept", "basis_mean"))):
            raise ValueError("Malformed One-vs-Rest checkpoint")
        alpha = values["alpha"].item()
        state = {"model_kind": "ovr_ridge", "task": "classification", "family": "ovr_ridge",
                 "classes": values["classes"].tolist(), "alpha": alpha,
                 "heads": [{"task": "classification", "family": "ridge", "alpha": alpha,
                             **{name: values[name][index].tolist() for name in
                                ("mean", "std", "weights", "intercept", "basis_mean")}}
                            for index in range(6)]}
        return OneVsRestRidge.from_state(state)
    return RidgeModel.from_state({name: values[name].tolist() for name in values})
