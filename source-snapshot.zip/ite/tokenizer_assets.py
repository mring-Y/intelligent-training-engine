"""Verify the model identity and hashes of offline tokenizer assets."""

import hashlib
import json
from pathlib import Path


def verify_tokenizer_provenance(tokenizer_dir, model):
    tokenizer_dir = Path(tokenizer_dir)
    manifest_path = tokenizer_dir / "tokenizer-manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("model") != model:
        raise ValueError("Tokenizer model mismatch")
    required = {"chat_template.jinja", "config.json", "tokenizer.json", "tokenizer_config.json"}
    entries = manifest.get("files", [])
    if (not manifest.get("revision") or len(entries) != len(required)
            or {entry.get("name") for entry in entries} != required):
        raise ValueError("Tokenizer provenance requires a revision and the four locked assets")
    for entry in entries:
        payload = (tokenizer_dir / entry["name"]).read_bytes()
        if hashlib.sha256(payload).hexdigest() != entry["sha256"] or len(payload) != entry["bytes"]:
            raise ValueError("Tokenizer file hash mismatch")
    return {**manifest, "manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest()}
