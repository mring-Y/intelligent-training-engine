"""Isolated public-development replay of official MLP maintenance proposals."""

import json
from pathlib import Path
import time

import numpy as np

from .controller import DeploymentGate
from .harness import parse_action, validate_observation
from .models import prediction_loss
from .official_sft_data import B_REPLAY_BEARINGS, C_REPLAY_SUBSETS, NOTICE, OFFICIAL_A_CLASSES, metrics, transform_features, reason_reviewed
from .tracking import JsonlLogger
from .training import BoundedTrainer


def _gain(profile, old, new):
    return (new["macro_f1"] - old["macro_f1"] if profile == "A" else old["rmse"] - new["rmse"])


def _bounded_fit(parent, features, targets, allowance, *, trainable_policy="full", loss_policy="squared"):
    with BoundedTrainer() as trainer:
        options = {"parent_state": parent.state(), "trainable_policy": trainable_policy}
        if loss_policy != "squared":
            options["loss_policy"] = loss_policy
        result = trainer.fit(parent.task, None, features, targets, allowance,
            model_type="official_mlp", official_options=options)
    if result.status != "ok":
        raise RuntimeError(f"official_candidate_{result.status}: {result.error}")
    return result.model, result.wall_seconds


def replay_partition(data, indices, split, scenario, output_dir, model, decide, *,
                     decision_steps=None, trainer=_bounded_fit, action_profile="default",
                     candidate_loss_policy="squared", a_replay_policy="none", c_replay_policy="none",
                     b_replay_policy="none",
                     heuristic_override=False, training_stream=None):
    if type(heuristic_override) is not bool:
        raise ValueError("Heuristic override must be explicit boolean")
    if heuristic_override and training_stream is None:
        raise ValueError("Heuristic experiments require a separate official training stream")
    if training_stream is not None:
        tx,ty=np.asarray(training_stream["x"]),np.asarray(training_stream["y"])
        tids=training_stream["ids"]
        if (tx.ndim!=2 or tx.shape[1]!=data["x"].shape[1] or ty.shape!=(len(tx),) or
                len(tids)!=len(tx) or len(set(tids))!=len(tids) or len(tx)<12 or
                set(tids)&set(data["ids"]) or not np.isfinite(tx).all() or not np.isfinite(ty).all()):
            raise ValueError("Training must be finite and disjoint from all validation IDs")
    if b_replay_policy not in ("none", "source_balanced_official_train") or (
            b_replay_policy != "none" and (data.get("profile") != "B" or
                data.get("task") != "regression" or action_profile != "official_finetune" or
                candidate_loss_policy != "squared" or a_replay_policy != "none" or
                c_replay_policy != "none" or heuristic_override)):
        raise ValueError("B replay is restricted to ordinary official B head training")
    if c_replay_policy not in ("none", "source_balanced_official_train") or (
            c_replay_policy != "none" and (data.get("profile") != "C" or
                data.get("task") != "regression" or action_profile != "official_finetune" or
                candidate_loss_policy != "squared" or a_replay_policy != "none")):
        raise ValueError("C replay is restricted to ordinary official C head training")
    if a_replay_policy not in ("none", "class_balanced_official_train") or (
            a_replay_policy != "none" and data.get("profile") != "A"):
        raise ValueError("Unsupported A replay policy for this partition")
    if candidate_loss_policy not in ("squared", "overestimate_2x") or (
            candidate_loss_policy != "squared" and (data.get("profile") != "C" or
                data.get("task") != "regression" or action_profile != "official_finetune")):
        raise ValueError("Unsupported candidate loss policy for this replay")
    if action_profile == "official_c_calibration" and (data.get("profile") != "C" or
            data.get("task") != "regression" or candidate_loss_policy != "squared"):
        raise ValueError("Calibration replay is restricted to official C squared head training")
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=False)
    profile, task, scale = data["profile"], data["task"], data["loss_scale"]
    indices = np.asarray(indices, dtype=int)
    if len(indices) < 48 or len(set(indices.tolist())) != len(indices):
        raise ValueError("Replay needs at least 48 disjoint ordered source rows")
    batches = [np.asarray(values) for values in np.array_split(indices, 12)]
    gradient_batches = np.array_split(np.arange(len(training_stream["y"])),12) if training_stream is not None else None
    gradient_history=[]
    decision_steps = tuple(decision_steps or ((3, 7) if split == "train" else (3,)))
    if any(step < 2 or step >= 10 for step in decision_steps):
        raise ValueError("Decision times must leave independent future capacity")
    initial = model
    gate = DeploymentGate(model, .0, .05, 4, scale)
    pending, history, trend, records = None, [], [], []
    static_predictions, active_predictions, versions, targets, all_ids = [], [], [], [], []
    trained_seconds, attempts, last_deploy = 0., 0, -1
    calibration_loss = None
    with JsonlLogger(output / "events.jsonl", f"{profile}-{scenario}-{split}") as log:
        log.event("run_started", -1, profile=profile, split=split, scenario=scenario,
                  batches=12, rows=len(indices), notice=NOTICE,
                  parent_checkpoint=model.checkpoint_sha256, task=task, unit=data["unit"],
                  a_replay_policy=a_replay_policy, c_replay_policy=c_replay_policy,
                  b_replay_policy=b_replay_policy)
        for step, source in enumerate(batches):
            x = transform_features(data["x"][source], data["scale"], scenario, step)
            y = data["y"][source]
            static_p, active_p = initial.predict(x), gate.model.predict(x)
            static_predictions.append(static_p)
            active_predictions.append(active_p)
            versions.extend([gate.version] * len(source))
            targets.append(y)
            all_ids.extend(data["ids"][int(i)] for i in source)
            log.event("prediction", step, model_version=gate.version, samples=len(source),
                      source_ids=[data["ids"][int(i)] for i in source])
            # Only after predicting step k may labels from k-1 be released.
            if step:
                if training_stream is not None:
                    gs=gradient_batches[step-1]
                    gradient_history.append((step-1,gs,
                        transform_features(training_stream["x"][gs],data["scale"],scenario,step-1),
                        training_stream["y"][gs]))
                released_source = batches[step - 1]
                released_x = transform_features(data["x"][released_source], data["scale"], scenario, step - 1)
                released_y = data["y"][released_source]
                released_p = active_predictions[step - 1]
                loss = prediction_loss(task, released_y, released_p, scale)
                if calibration_loss is None:
                    calibration_loss = loss
                history.append((step - 1, released_source, released_x, released_y))
                trend.append({"source_step": step - 1, "loss": loss, "labeled_samples": len(released_y)})
                log.event("labels_released", step, source_step=step - 1, samples=len(released_y), loss=loss)
                if pending is not None and step - 1 > pending["frozen_at"]:
                    candidate, record = pending["model"], pending["record"]
                    result = gate.consider(candidate, released_x, released_y, step)
                    log.event("deploy" if result["accepted"] else "experiment_rejected", step,
                        reason="independent_future_labels", gate_min_source_step=step - 1,
                        frozen_at=pending["frozen_at"], decision_id=record["decision_id"],
                        candidate_replay_source_ids=record["evidence"].get("replay_source_ids", []),
                        source_ids=[data["ids"][int(i)] for i in released_source], **result)
                    record["evidence"]["future_gate"] = {**result, "source_step": step - 1,
                        "frozen_at": pending["frozen_at"],
                        "source_ids": [data["ids"][int(i)] for i in released_source]}
                    if result["accepted"]:
                        last_deploy = step
                        record["evidence"]["deployment_version"] = gate.version
                        record["evidence"]["deployed_at"] = step
                    else:
                        record["rejection"] = "independent_future_gate_rejected"
                    pending = None
            if step not in decision_steps or pending is not None:
                continue
            feature_distance = float(np.sqrt(np.mean(((x.mean(axis=0) - initial.mean) / initial.std) ** 2)))
            current_loss = float(np.mean([item["loss"] for item in trend[-3:]]))
            alarm = feature_distance >= .65 or current_loss > calibration_loss + .13
            observation = {"loss_trend": trend[-5:], "drift_alarm": bool(alarm),
                "remaining_label_budget": None, "remaining_token_budget": 60000,
                "model_age_batches": step - last_deploy}
            if action_profile == "official_c_calibration":
                residuals = (active_predictions[step - 1] - history[-1][3])[-48:]
                observation.update(overestimate_rate=float(np.mean(residuals > 0)),
                                   mean_overestimate=float(np.mean(np.maximum(residuals, 0))))
            validate_observation(observation, task=task)
            context = {"profile": profile, "split": split, "scenario": scenario, "step": step,
                "observation": observation, "feature_distance": feature_distance,
                "remaining_train_seconds": max(0., 20. - trained_seconds),
                "source_ids": [data["ids"][int(i)] for _, rows, _, _ in history for i in rows],
                "source_groups": sorted({data["groups"][int(i)] for i in indices})}
            proposal = decide(context)
            log.event("harness_observation", step, observation=context["observation"], feature_distance=feature_distance,
                      remaining_train_seconds=context["remaining_train_seconds"])
            if proposal is None:
                continue  # A latched Teacher session never falls back to invented labels.
            if action_profile in ("official_finetune", "official_c_calibration") and (
                    not isinstance(proposal, dict) or
                    set(proposal) - {"action", "reason", "messages", "source", "reason_audit", "call_id"}):
                raise ValueError("Unrecognized official maintenance proposal parameters")
            parsed = parse_action(json.dumps({"action": proposal["action"], "reason": proposal["reason"]}, ensure_ascii=False),
                                  action_profile=action_profile)
            original_action=parsed.action
            if heuristic_override:
                from .heuristic_override import choose_heuristic_action
                effective=choose_heuristic_action(parsed,observation,profile=profile,
                    remaining_train_seconds=max(0.,20.-trained_seconds-1.5),experiments_remaining=4-attempts)
                if effective is not parsed:
                    log.event("heuristic_override",step,original_action=parsed.action,
                        effective_action=effective.action,observation=observation,
                        remaining_train_seconds=context["remaining_train_seconds"])
                parsed=effective
            if c_replay_policy != "none" and parsed.action not in ("DO_NOTHING", "RETRAIN_HEAD_ONLY"):
                raise ValueError("C replay requires the ordinary head-only action")
            if b_replay_policy != "none" and parsed.action not in ("DO_NOTHING", "RETRAIN_HEAD_ONLY"):
                raise ValueError("B replay requires the ordinary head-only action")
            record = {**context, "action": parsed.action, "reason": parsed.reason,"original_action":original_action,
                "messages": proposal.get("messages", []), "teacher_source": proposal.get("source", "offline_mock"),
                "qualified": False, "outcome_supported": False, "reason_audit": proposal.get("reason_audit", {}),
                "teacher_call_id": proposal.get("call_id"), "decision_id": f"{profile}-{split}-{scenario}-{step}",
                "evidence": {"candidate_parent_checkpoint": gate.model.checkpoint_sha256},
                "rejection": "unverified"}
            records.append(record)
            log.event("harness_decision", step, decision_id=record["decision_id"],
                      action=parsed.action, reason=parsed.reason, source=record["teacher_source"])
            if parsed.action == "DO_NOTHING":
                record["rejection"] = "retained_static_unverified_optimality"
                continue
            if parsed.action == "ROLLBACK":
                record["rejection"] = "rollback_not_supported_in_pilot"
                continue
            available = max(0., min(5., 20. - trained_seconds - 1.5))
            if available <= 0 or attempts >= 4:
                record["rejection"] = "training_budget_exhausted"
                continue
            released_x = np.concatenate([entry[2] for entry in history])
            released_y = np.concatenate([entry[3] for entry in history])
            released_steps = np.concatenate([np.full(len(entry[3]), entry[0]) for entry in history])
            released_ids = [data["ids"][int(i)] for _, rows, _, _ in history for i in rows]
            window = 192 if parsed.action == "RETRAIN_SMALL" else 768
            calibration = None
            if parsed.action == "CALIBRATE_DOWN":
                start = max(0, len(released_y) - window)
                source_step = int(released_steps[start]) - 1
                prior = [entry for entry in history if entry[0] == source_step]
                if len(released_y) < 768 or not prior or len(prior[0][3]) < 48:
                    record["rejection"] = "insufficient_independent_calibration_window"
                    log.event("experiment_rejected", step, reason=record["rejection"])
                    continue
                previous = prior[0]
                calibration = {"x": previous[2][-48:], "y": previous[3][-48:],
                    "source_step": source_step, "ids": [data["ids"][int(i)] for i in previous[1][-48:]]}
            released_x, released_y = released_x[-window:], released_y[-window:]
            selection_size = max(4, min(48, len(released_y) // 4))
            if len(released_y) - selection_size < 8:
                record["rejection"] = "insufficient_released_samples"
                continue
            # Newest labels screen the candidate, never enter the training array.
            train_x, selection_x = released_x[:-selection_size], released_x[-selection_size:]
            train_y, selection_y = released_y[:-selection_size], released_y[-selection_size:]
            online_train_ids = released_ids[-window:][:-selection_size]
            if training_stream is not None:
                # Validation stays screening-only. Gradients come exclusively
                # from a separately released, clocked official train stream.
                train_x=np.concatenate([e[2] for e in gradient_history])[-(window-48):]
                train_y=np.concatenate([e[3] for e in gradient_history])[-(window-48):]
                online_train_ids=[training_stream["ids"][int(i)] for _,gs,_,_ in gradient_history for i in gs][-(window-48):]
            replay_source_ids, replaced_online_source_ids = [], []
            if a_replay_policy == "class_balanced_official_train" and (
                    not heuristic_override or parsed.action=="RETRAIN_REPLAY"):
                reserve = data.get("replay_reserve")
                if (not isinstance(reserve, dict) or set(reserve) !=
                        {"x", "y", "ids", "class_counts", "selection_policy"}):
                    raise ValueError("A replay reserve is required and must be ID-auditable")
                reserve_x, reserve_y = np.asarray(reserve["x"], dtype=float), np.asarray(reserve["y"])
                replay_source_ids = list(reserve["ids"])
                if (reserve_x.shape != (48, data["x"].shape[1]) or reserve_y.shape != (48,) or
                        len(replay_source_ids) != 48 or len(set(replay_source_ids)) != 48 or
                        reserve["selection_policy"] != "sha256_ranked_8_per_class_v1" or
                        reserve["class_counts"] != {name: 8 for name in OFFICIAL_A_CLASSES}):
                    raise ValueError("A replay reserve must contain eight finite rows per official class")
                if (not np.isfinite(reserve_x).all() or not np.isfinite(reserve_y).all() or
                        not np.isin(reserve_y, np.arange(1, 7)).all() or
                        set(replay_source_ids) & set(data["ids"])):
                    raise ValueError("A replay reserve has invalid labels or overlaps online validation IDs")
                if len(train_y) < 48:
                    record["rejection"] = "insufficient_online_train_rows_for_a_replay"
                    log.event("experiment_rejected", step, reason=record["rejection"],
                              train_samples=len(train_y), replay_samples=48)
                    continue
                replaced_online_source_ids = online_train_ids[:48]
                train_x = np.concatenate((reserve_x, train_x[48:]), axis=0)
                train_y = np.concatenate((reserve_y, train_y[48:]), axis=0)
                train_source_ids = replay_source_ids + online_train_ids[48:]
            else:
                train_source_ids = online_train_ids
            if b_replay_policy == "source_balanced_official_train":
                if len(train_y) < 48:
                    record["rejection"] = "insufficient_online_train_rows_for_b_replay"
                    log.event("experiment_rejected", step, reason=record["rejection"], train_samples=len(train_y))
                    continue
                reserve = data.get("replay_reserve")
                if (not isinstance(reserve, dict) or set(reserve) !=
                        {"x", "y", "ids", "groups", "bearing_counts", "condition_counts", "selection_policy"}):
                    raise ValueError("B replay reserve must retain historical bearing provenance")
                reserve_x, reserve_y = np.asarray(reserve["x"], dtype=float), np.asarray(reserve["y"], dtype=float)
                replay_source_ids, replay_groups = list(reserve["ids"]), list(reserve["groups"])
                bearing_counts = {group: replay_groups.count(group) for group in B_REPLAY_BEARINGS}
                condition_counts = {f"Bearing{i}": sum(g.startswith(f"Bearing{i}_") for g in replay_groups)
                                    for i in (1, 2, 3)}
                if (reserve_x.shape != (48, data["x"].shape[1]) or reserve_y.shape != (48,) or
                        len(replay_source_ids) != 48 or len(set(replay_source_ids)) != 48 or
                        len(replay_groups) != 48 or set(replay_groups) != set(B_REPLAY_BEARINGS) or
                        sorted(bearing_counts.values()) != [5] * 6 + [6] * 3 or
                        condition_counts != {f"Bearing{i}": 16 for i in (1, 2, 3)} or
                        reserve["bearing_counts"] != bearing_counts or reserve["condition_counts"] != condition_counts or
                        reserve["selection_policy"] != "sha256_ranked_5_or_6_per_bearing_48_v1" or
                        not np.isfinite(reserve_x).all() or not np.isfinite(reserve_y).all() or
                        np.any(reserve_y < 0) or set(replay_source_ids) & set(data["ids"]) or
                        set(replay_groups) & set(data["groups"]) or
                        set(replay_source_ids) & set(online_train_ids)):
                    raise ValueError("B replay reserve is invalid, unbalanced or shares validation evidence")
                replaced_online_source_ids = online_train_ids[:48]
                train_x = np.concatenate((reserve_x, train_x[48:]), axis=0)
                train_y = np.concatenate((reserve_y, train_y[48:]), axis=0)
                train_source_ids = replay_source_ids + online_train_ids[48:]
            if c_replay_policy == "source_balanced_official_train":
                if len(train_y) != 720 or selection_size != 48:
                    record["rejection"] = "insufficient_online_train_rows_for_c_replay"
                    log.event("experiment_rejected", step, reason=record["rejection"], train_samples=len(train_y))
                    continue
                reserve = data.get("replay_reserve")
                if (not isinstance(reserve, dict) or set(reserve) !=
                        {"x", "y", "ids", "groups", "subset_counts", "selection_policy"}):
                    raise ValueError("C replay reserve must retain historical entity provenance")
                reserve_x, reserve_y = np.asarray(reserve["x"], dtype=float), np.asarray(reserve["y"], dtype=float)
                replay_source_ids, replay_groups = list(reserve["ids"]), list(reserve["groups"])
                subset_counts = {subset: sum(group.startswith(subset + ":") for group in replay_groups)
                                 for subset in C_REPLAY_SUBSETS}
                if (reserve_x.shape != (48, data["x"].shape[1]) or reserve_y.shape != (48,) or
                        len(replay_source_ids) != 48 or len(set(replay_source_ids)) != 48 or
                        len(replay_groups) != 48 or len(set(replay_groups)) != 48 or
                        not np.isfinite(reserve_x).all() or not np.isfinite(reserve_y).all() or
                        np.any(reserve_y < 0) or subset_counts != dict.fromkeys(C_REPLAY_SUBSETS, 12) or
                        reserve["subset_counts"] != subset_counts or
                        reserve["selection_policy"] != "sha256_ranked_12_engines_per_subset_v1" or
                        set(replay_source_ids) & set(data["ids"]) or set(replay_groups) & set(data["groups"])):
                    raise ValueError("C replay reserve must be finite, source-balanced and disjoint from validation")
                replaced_online_source_ids = online_train_ids[:48]
                train_x = np.concatenate((reserve_x, train_x[48:]), axis=0)
                train_y = np.concatenate((reserve_y, train_y[48:]), axis=0)
                train_source_ids = replay_source_ids + online_train_ids[48:]
            attempts += 1
            started = time.perf_counter()
            trainable_policy = "head_only" if parsed.action in ("RETRAIN_HEAD_ONLY", "CALIBRATE_DOWN") else "full"
            try:
                options = {"trainable_policy": trainable_policy} if trainable_policy == "head_only" else {}
                if candidate_loss_policy != "squared":
                    if trainable_policy != "head_only":
                        raise ValueError("Asymmetric loss requires RETRAIN_HEAD_ONLY")
                    options["loss_policy"] = candidate_loss_policy
                candidate, elapsed = trainer(gate.model, train_x, train_y, available, **options)
            except Exception as error:
                elapsed = time.perf_counter() - started
                trained_seconds += elapsed
                record["rejection"] = "candidate_training_error"
                log.event("training_failed", step, error=f"{type(error).__name__}: {error}"[:1024], seconds=elapsed)
                continue
            trained_seconds += elapsed
            if calibration is not None:
                try:
                    audit = candidate.calibrate_down(calibration["x"], calibration["y"])
                except Exception as error:
                    record["rejection"] = "candidate_calibration_error"
                    log.event("experiment_rejected", step, reason=record["rejection"], error=str(error)[:1024])
                    continue
                record["evidence"].update(safety_margin=candidate.safety_margin,
                    calibration_samples=len(calibration["y"]), calibration_source_step=calibration["source_step"],
                    calibration_source_ids=calibration["ids"], calibration_audit=audit)
                log.event("candidate_calibrated", step, decision_id=record["decision_id"], **record["evidence"])
            incumbent_loss = prediction_loss(task, selection_y, gate.model.predict(selection_x), scale)
            candidate_loss = prediction_loss(task, selection_y, candidate.predict(selection_x), scale)
            record["evidence"].update(train_samples=len(train_y), screening_samples=len(selection_y),
                train_max_source_step=step - 1, selection_loss=candidate_loss, incumbent_loss=incumbent_loss,
                train_seconds=elapsed, candidate_checkpoint=candidate.checkpoint_sha256,
                trainable_policy=trainable_policy, fit_audit=getattr(candidate, "last_fit_audit", {}),
                loss_policy=candidate_loss_policy,
                parent_adam_steps=gate.model.steps, candidate_adam_steps=candidate.steps,
                a_replay_policy=a_replay_policy, c_replay_policy=c_replay_policy,
                b_replay_policy=b_replay_policy, train_source_ids=train_source_ids,
                online_train_source_ids=online_train_ids, replay_source_ids=replay_source_ids,
                replaced_online_source_ids=replaced_online_source_ids,
                screening_source_ids=released_ids[-window:][-selection_size:])
            if hasattr(candidate, "save"):
                candidate.save(output / f"candidate-step{step}.npz")
            log.event("candidate_evaluated", step, decision_id=record["decision_id"], **record["evidence"])
            if elapsed > available or trained_seconds > 20. or candidate_loss >= incumbent_loss:
                record["rejection"] = "not_better_on_selection" if candidate_loss >= incumbent_loss else "training_over_budget"
                log.event("experiment_rejected", step, reason=record["rejection"])
                continue
            record["rejection"] = "awaiting_independent_future_gate"
            pending = {"model": candidate, "frozen_at": step, "record": record}
            log.event("candidate_frozen", step, decision_id=record["decision_id"],
                      candidate_checkpoint=candidate.checkpoint_sha256)
        y = np.concatenate(targets)
        static_p, active_p = np.concatenate(static_predictions), np.concatenate(active_predictions)
        old, new = metrics(profile, y, static_p), metrics(profile, y, active_p)
        for record in records:
            evidence = record["evidence"]
            evidence["whole_flow_gain"] = _gain(profile, old, new)
            version = evidence.get("deployment_version")
            if version is not None:
                mask = np.asarray(versions) == version
                if mask.any():
                    before, after = metrics(profile, y[mask], static_p[mask]), metrics(profile, y[mask], active_p[mask])
                    evidence["post_deployment_static"] = before
                    evidence["post_deployment_active"] = after
                    if _gain(profile, before, after) > 0 and _gain(profile, old, new) >= 0:
                        c_safe = profile != "C" or all(after[key] <= before[key] and new[key] <= old[key]
                            for key in ("overestimate_rate", "mean_overestimate"))
                        record["outcome_supported"] = c_safe
                        record["qualified"] = record["teacher_source"] == "teacher" and c_safe and reason_reviewed(record)
                        record["rejection"] = ("c_overestimation_not_safe" if not c_safe else
                            "offline_mock_not_teacher" if record["teacher_source"] != "teacher" else
                            None if record["qualified"] else "reason_audit_required")
                    else:
                        record["rejection"] = "no_sustained_paired_gain"
            # Conservative retention is evidence of safety, not action optimality;
            # keep it in review rather than fabricate a counterfactual success.
        np.savez_compressed(output / "predictions.npz", targets=y, static=static_p, active=active_p,
                            versions=np.asarray(versions), source_ids=np.asarray(all_ids))
        if training_stream is not None and hasattr(gate.model,"save"):
            gate.model.save(output/"selected.npz")
        summary = {"profile": profile, "split": split, "scenario": scenario, "notice": NOTICE,
            "static_metrics": old, "active_metrics": new, "paired_primary_gain": _gain(profile, old, new),
            "updates": gate.updates, "training_attempts": attempts, "train_seconds": trained_seconds,
            "outcome_supported_examples": sum(row["outcome_supported"] for row in records),
            "qualified_examples": sum(row["qualified"] for row in records), "records": records}
        log.event("run_completed", 12, **{k: v for k, v in summary.items() if k != "records"})
    (output / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    return summary
