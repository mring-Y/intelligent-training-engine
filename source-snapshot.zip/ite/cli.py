"""Local CPU experiment and explicit audit upload commands."""

import argparse
import json
import sys
from pathlib import Path

from .config import ALL_SCENARIOS, ExperimentConfig, POLICIES, SCENARIOS
from .report import aggregate_results, render_report, write_rows
from .runner import run_comparison
from .tracking import source_metadata, upload_swanlab, write_json
from .validation import assess_deployment


def _parser():
    parser = argparse.ArgumentParser(prog="ite", description="模拟漂移数据流上的受控更新实验")
    subparsers = parser.add_subparsers(dest="command", required=True)
    run = subparsers.add_parser("run", help="运行三种策略并生成报告")
    run.add_argument("--config", type=Path)
    run.add_argument("--output", type=Path, default=Path("outputs/local"))
    run.add_argument("--seed", type=int)
    run.add_argument("--task", choices=("classification", "regression"))
    run.add_argument("--scenario", choices=ALL_SCENARIOS)
    run.add_argument("--batches", type=int)
    run.add_argument("--adapt-strategy", action="store_true")
    run.add_argument("--policies", nargs="+", choices=POLICIES)
    matrix = subparsers.add_parser("matrix", help="运行任务、场景、种子和策略消融矩阵")
    matrix.add_argument("--config", type=Path)
    matrix.add_argument("--output", type=Path, default=Path("outputs/matrix"))
    matrix.add_argument("--tasks", nargs="+", choices=("classification", "regression"),
                        default=None)
    matrix.add_argument("--scenarios", nargs="+", choices=ALL_SCENARIOS)
    matrix.add_argument("--seeds", type=int, nargs="+")
    matrix.add_argument("--batches", type=int)
    matrix.add_argument("--ablation", action="store_true")
    matrix.add_argument("--policies", nargs="+", choices=POLICIES)
    assess = subparsers.add_parser("assess", help="按配对的独立种子评估策略晋级门槛")
    assess.add_argument("--baseline", type=Path, required=True, help="当前 legacy 矩阵 summary.csv")
    assess.add_argument("--candidate", type=Path, required=True, help="future 候选矩阵 summary.csv")
    assess.add_argument("--history", type=Path, help="启用历史模型复用的独立矩阵 summary.csv")
    assess.add_argument("--seeds", type=int, nargs="+", default=(101, 103, 107, 109, 113))
    assess.add_argument("--output", type=Path, required=True)
    upload = subparsers.add_parser("upload-swanlab", help="显式将单个策略日志上传至 SwanLab 云端")
    upload.add_argument("--run-dir", type=Path, required=True)
    upload.add_argument("--project", default="Intelligent_Training_Engine")
    upload.add_argument("--workspace", default="mring-Y")
    upload.add_argument("--archive", action="store_true", help="归档目录内所有实验的日志、配置、结果和检查点")
    return parser


def _configured_run(args):
    config = ExperimentConfig.load(args.config) if args.config else ExperimentConfig()
    overrides = {name: value for name, value in (("seed", args.seed), ("task", args.task),
                                                  ("scenario", args.scenario), ("n_batches", args.batches),
                                                  ("strategy_adaptation", args.adapt_strategy))
                 if value is not None and (name != "strategy_adaptation" or value)}
    if overrides:
        config = ExperimentConfig.from_dict({**config.to_dict(), **overrides})
    if config.harness_backend == "pytrio" and config.scenario == "triple_abrupt":
        raise ValueError("Use python -m ite.three_abrupt with matching Mock preflight for the paid triple profile")
    results = run_comparison(config, args.output, policies=args.policies or POLICIES)
    print(json.dumps({"output": str(args.output.resolve()), "results": results}, ensure_ascii=False, indent=2))
    return 0


def _matrix(args):
    base = ExperimentConfig.load(args.config) if args.config else ExperimentConfig()
    if base.harness_backend == "pytrio":
        raise ValueError("Paid PyTRiO requests are prohibited in matrix mode")
    # A file describes a complete experiment; without a file retain the old matrix defaults.
    tasks = args.tasks or ([base.task] if args.config else ("classification", "regression"))
    scenarios = args.scenarios or ([base.scenario] if args.config else SCENARIOS)
    seeds = args.seeds or ([base.seed] if args.config else (7, 19, 43))
    batches = args.batches if args.batches is not None else (base.n_batches if args.config else 28)
    base = ExperimentConfig.from_dict({**base.to_dict(), "n_batches": batches})
    root = args.output
    root.mkdir(parents=True, exist_ok=True)
    if any(root.iterdir()):
        raise FileExistsError(f"Refusing to overwrite an existing matrix: {root}")
    results, total = [], len(tasks) * len(scenarios) * len(seeds)
    if args.ablation:
        total += len(seeds)
    index = 0

    policies = args.policies or POLICIES

    def collect(output, rows, group):
        for row in rows:
            copy = dict(row)
            copy["experiment_group"] = group
            copy["curve_file"] = (output / row["curve_file"]).relative_to(root).as_posix()
            results.append(copy)

    for task in tasks:
        for scenario in scenarios:
            for seed in seeds:
                index += 1
                print(f"[{index}/{total}] {task}/{scenario}/seed-{seed}", flush=True)
                config = ExperimentConfig.from_dict({**base.to_dict(), "task": task, "scenario": scenario, "seed": seed})
                output = root / task / scenario / f"seed-{seed}"
                collect(output, run_comparison(config, output, policies=policies), "comparison")
    if args.ablation:
        for seed in seeds:
            index += 1
            print(f"[{index}/{total}] policy-ablation/seed-{seed}", flush=True)
            config = ExperimentConfig.from_dict({**base.to_dict(), "seed": seed, "strategy_adaptation": False})
            static_dir, fixed_dir, adaptive_dir = (root / "ablation" / name / f"seed-{seed}"
                                                    for name in ("static", "fixed", "adaptive"))
            static_rows = run_comparison(config, static_dir, policies=("static",))
            baseline_loss = static_rows[0]["mean_loss"]
            fixed_rows = run_comparison(config, fixed_dir, policies=("drift",), reference_static_loss=baseline_loss)
            adaptive = ExperimentConfig.from_dict({**config.to_dict(), "strategy_adaptation": True})
            adaptive_rows = run_comparison(adaptive, adaptive_dir, policies=("drift",),
                                           reference_static_loss=baseline_loss)
            for output, rows in ((static_dir, static_rows), (fixed_dir, fixed_rows), (adaptive_dir, adaptive_rows)):
                for row in rows:
                    row["loss_gain_vs_static"] = baseline_loss - row["mean_loss"]
                collect(output, rows, "strategy_ablation")
    write_json(root / "config.json", {"tasks": tasks, "scenarios": scenarios,
                                       "seeds": seeds, "batches": batches, "base_config": base.to_dict(),
                                       "ablation": args.ablation, **source_metadata()})
    write_rows(root / "summary.csv", results)
    write_rows(root / "aggregates.csv", aggregate_results(results))
    render_report(root, results, title="模拟漂移流对照与策略消融")
    print(json.dumps({"output": str(root.resolve()), "runs": len(results),
                      "aggregated_groups": len(aggregate_results(results))}, ensure_ascii=False))
    return 0


def main(argv=None):
    args = _parser().parse_args(argv)
    try:
        if args.command == "run":
            return _configured_run(args)
        if args.command == "matrix":
            return _matrix(args)
        if args.command == "assess":
            result = assess_deployment(args.baseline, args.candidate, args.history, args.seeds)
            write_json(args.output, result)
            print(json.dumps({"output": str(args.output.resolve()), **result}, ensure_ascii=False, indent=2))
            return 0 if result["candidate_passed"] and result["history_reuse_passed"] is not False else 1
        result = upload_swanlab(args.run_dir, args.project, args.workspace, archive=args.archive)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (ValueError, FileExistsError, OSError, RuntimeError, json.JSONDecodeError) as error:
        print(f"ite: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
