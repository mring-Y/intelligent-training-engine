"""Pinned-runtime fitting/prediction for frozen MLP plus input adapter."""

import base64
import hashlib
import json
import os
from pathlib import Path
import sys
import time

for name in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):os.environ[name]="1"
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))


def load_model(raw,package):
    import numpy as np
    from ite.c_adapter_model import is_input_adapter,unpack_checkpoint
    from official_worker import _model,_validate_model,PROFILES
    core,module=unpack_checkpoint(raw)[:2] if is_input_adapter(raw) else (raw,None)
    model=_model(Path(package),core);_validate_model(model,"C",PROFILES["C"])
    if np.__version__!="1.26.4":raise ValueError("input adapter requires pinned NumPy1.26.4")
    if module is not None and any(getattr(module,k)!=model.meta[k] for k in ("seed","learning_rate","batch_size")):
        raise ValueError("module optimizer contract differs from original parent")
    return model,module,core


def predict_values(model,module,x):
    import numpy as np
    if module is None:return np.asarray([model.predict(row.reshape(1,-1))[0] for row in x],dtype=np.float64)
    predictions=[]
    for row in x:
        z=module.transform(model.normalized(row.reshape(1,-1)))
        _,logits=model.forward(z)
        predictions.append(max(0.,float(logits[0,0]*model.meta["target_scale"]+model.meta["target_mean"])))
    return np.asarray(predictions,dtype=np.float64)


def handle(request,package):
    import numpy as np
    from ite.compact_rbf import matrix
    from ite.input_adapter import InputAdapter
    from ite.c_adapter_model import pack_checkpoint
    from ite.c_rbf_worker import peak_memory_bytes
    raw=base64.b64decode(request["checkpoint"],validate=True)
    model,module,core=load_model(raw,package)
    x=matrix(request["features"],24)
    if request["operation"]=="predict":return {"predictions":predict_values(model,module,x).tolist()}
    if request["operation"]!="fit":raise ValueError("unknown input adapter worker operation")
    started=time.perf_counter();allowance=float(request["allowance"])
    if not 0<allowance<=5:raise ValueError("invalid input adapter allowance")
    y=np.asarray(request["targets"],dtype=np.float64)
    if y.shape!=(len(x),) or len(y)<2 or not np.isfinite(y).all() or np.any(y<0):raise ValueError("invalid C training targets")
    if module is None:module=InputAdapter.initial(**{k:model.meta[k] for k in ("seed","learning_rate","batch_size")})
    before_steps,before_epochs=module.steps,module.epochs
    initial={k:v.copy() for k,v in module.params.items()}
    loss=module.fit(model.normalized(x),(y-model.meta["target_mean"])/model.meta["target_scale"],model.params,2,deadline=started+allowance)
    parent_digest=hashlib.sha256(raw).hexdigest()
    checkpoint=pack_checkpoint(core,module,parent_digest)
    audit={"trainable_policy":"input_adapter_only","trainable_parameters":220,"mlp_parameters":833,"mlp_frozen_exact_bytes":True,
        "parent_mlp_sha256":hashlib.sha256(core).hexdigest(),"parent_checkpoint_sha256":parent_digest,
        "parent_module_steps":before_steps,"candidate_module_steps":module.steps,"parent_module_epochs":before_epochs,"candidate_module_epochs":module.epochs,
        "learning_rate":module.learning_rate,"batch_size":module.batch_size,"epochs_added":2,"loss_policy":"squared",
        "module_adam_clock":"separate_module_steps","mlp_steps":model.meta["steps"],"mlp_epochs":model.meta["epochs"],
        "max_parameter_delta":{k:float(np.max(np.abs(v-initial[k]))) for k,v in module.params.items()},
        "first_batch_loss":loss[0],"last_batch_loss":loss[-1],"worker_peak_memory_bytes":peak_memory_bytes()}
    return {"checkpoint":base64.b64encode(checkpoint).decode("ascii"),"fit_audit":audit}


if __name__=="__main__":
    try:
        raw=sys.stdin.buffer.read(32*1024*1024+1)
        if len(raw)>32*1024*1024:raise ValueError("input adapter worker request too large")
        print(json.dumps({"ok":True,**handle(json.loads(raw),sys.argv[1])},allow_nan=False),flush=True)
    except Exception as error:
        print(f"{type(error).__name__}: {error}",file=sys.stderr);raise SystemExit(2)
