"""Candidate fitting in a killable worker, with elapsed wall time including overhead."""

import multiprocessing as mp
import importlib
import math
import os
import threading
import time
from dataclasses import dataclass

from .model_factory import make_model, model_from_state
from .official_model import is_official_model_type


_REQUEST_FIELDS = {"request_version", "task", "alpha", "features", "targets", "family", "sample_weight",
                   "model_type", "tree_options", "class_labels", "candidate"}
_THREAD_ENVIRONMENT = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS")


def _decode_request(request):
    if isinstance(request, tuple) and len(request) == 6:
        task, alpha, x, y, family, sample_weight = request
        return task, alpha, x, y, family, sample_weight, {}
    if (not isinstance(request, dict) or set(request) != _REQUEST_FIELDS or
            request["request_version"] != 1 or type(request["candidate"]) is not bool):
        raise ValueError("Unsupported training request format or options")
    return (request["task"], request["alpha"], request["features"], request["targets"], request["family"],
            request["sample_weight"], {name: request[name] for name in
                                     ("model_type", "tree_options", "class_labels", "candidate")})


def _worker(connection):
    try:
        while True:
            request = connection.recv()
            if request is None:
                return
            timings = {}
            try:
                task, alpha, x, y, family, sample_weight, options = _decode_request(request)
                if options.get("model_type") == "tree":
                    started = time.perf_counter()
                    importlib.import_module("sklearn.tree")
                    timings["import_seconds"] = time.perf_counter() - started
                started = time.perf_counter()
                model = make_model(task, alpha, family, **({"candidate": True} if not options else options))
                model.fit(x, y, sample_weight=sample_weight)
                timings["fit_seconds"] = time.perf_counter() - started
                started = time.perf_counter()
                state = model.state()
                timings["export_seconds"] = time.perf_counter() - started
                response = ("ok", state, None)
            except Exception as error:
                response = ("error", None, f"{type(error).__name__}: {error}"[:2048])
            connection.send((*response, timings) if isinstance(request, dict) else response)
    except (EOFError, BrokenPipeError):
        return
    finally:
        connection.close()


@dataclass(frozen=True)
class TrainingResult:
    status: str
    model: object
    wall_seconds: float
    error: str = ""
    timings: dict | None = None


class BoundedTrainer:
    def __init__(self):
        self._process = self._connection = None
        self._tree_worker = False

    def _start(self):
        context = mp.get_context("spawn")
        self._connection, child = context.Pipe()
        self._process = context.Process(target=_worker, args=(child,), daemon=True)
        # Spawn inherits these limits before NumPy/SciPy can initialize native pools.
        previous = {name: os.environ.get(name) for name in _THREAD_ENVIRONMENT}
        try:
            if self._tree_worker:
                os.environ.update({name: "1" for name in _THREAD_ENVIRONMENT})
            self._process.start()
        finally:
            if self._tree_worker:
                for name, value in previous.items():
                    if value is None:
                        os.environ.pop(name, None)
                    else:
                        os.environ[name] = value
        child.close()

    def fit(self, task, alpha, features, targets, timeout_seconds, model_family="ridge", sample_weight=None,
            *, model_type="ridge", tree_options=None, class_labels=None, official_options=None, candidate=True):
        started = time.perf_counter()
        timings = {"startup_seconds": 0., "import_seconds": 0., "fit_seconds": 0., "export_seconds": 0.,
                   "ipc_seconds": 0., "restore_seconds": 0., "cleanup_seconds": 0.}

        def result(status, model=None, error=""):
            elapsed = time.perf_counter() - started
            return TrainingResult(status, model, elapsed, error, {**timings, "wall_seconds": elapsed})

        def stop():
            cleanup = time.perf_counter()
            self.close()
            timings["cleanup_seconds"] += time.perf_counter() - cleanup

        def timeout():
            stop()
            return result("timeout", error="Training exceeded its wall-time allowance including IPC and restoration")

        try:
            if (isinstance(timeout_seconds, bool) or not isinstance(timeout_seconds, (int, float)) or
                    not math.isfinite(timeout_seconds)):
                raise ValueError("Training timeout must be finite")
            if timeout_seconds <= 0:
                return TrainingResult("budget_exhausted", None, 0.0, timings=timings)
            if is_official_model_type(model_type):
                self.close()
                if (task not in ("classification", "regression") or alpha is not None or model_family != "ridge" or
                        not isinstance(official_options, dict) or "parent_state" not in official_options or
                        set(official_options) - {"parent_state", "trainable_policy", "loss_policy"}):
                    raise ValueError("Official training requires a regression/classification parent checkpoint state")
                from .official_model import OfficialModelAdapter, OfficialModelTimeout
                model = OfficialModelAdapter.from_state(official_options["parent_state"])
                policy = official_options.get("trainable_policy", "full")
                loss_policy = official_options.get("loss_policy", "squared")
                if loss_policy not in ("squared", "overestimate_2x", "official_anchor_l2"):
                    raise ValueError("Unsupported official loss_policy")
                if loss_policy != "squared" and (policy != "head_only" or task != "regression" or
                                                  model.profile_type != "C"):
                    raise ValueError("Alternative loss requires official C head_only regression")
                started_worker = time.perf_counter()
                try:
                    model.fit(features, targets, sample_weight=sample_weight,
                              timeout_seconds=min(float(timeout_seconds), 5.0), trainable_policy=policy,
                              loss_policy=loss_policy)
                except OfficialModelTimeout as error:
                    timings["ipc_seconds"] = time.perf_counter() - started_worker
                    timings["cleanup_seconds"] = 0.0
                    return result("timeout", error=str(error))
                timings["ipc_seconds"] = time.perf_counter() - started_worker
                timings["fit_seconds"] = timings["ipc_seconds"]
                return result("ok", model)
            if model_type == "tree" and self._process is not None and not self._tree_worker:
                stop()
            self._tree_worker = model_type == "tree"
            startup = time.perf_counter()
            if self._process is None or not self._process.is_alive():
                self.close()
                self._start()
            timings["startup_seconds"] = time.perf_counter() - startup
            request = (task, alpha, features, targets, model_family, sample_weight)
            if model_type != "ridge" or tree_options is not None or class_labels is not None or not candidate:
                request = dict(request_version=1, task=task, alpha=alpha, features=features, targets=targets,
                               family=model_family, sample_weight=sample_weight, model_type=model_type,
                               tree_options=tree_options, class_labels=class_labels, candidate=candidate)
            connection = self._connection
            replies, completed = [], threading.Event()

            def exchange():
                try:
                    connection.send(request)
                    replies.append((True, connection.recv()))
                except Exception as error:
                    replies.append((False, error))
                finally:
                    completed.set()

            # A blocking send or a partially received state must also obey the deadline.
            ipc_started = time.perf_counter()
            threading.Thread(target=exchange, name="ite-training-ipc", daemon=True).start()
            remaining = max(0.0, timeout_seconds - (time.perf_counter() - started))
            finished = remaining > 0 and completed.wait(remaining)
            timings["ipc_seconds"] = time.perf_counter() - ipc_started
            if not finished:
                return timeout()
            success, response = replies[0]
            if not success:
                raise response
            if not isinstance(response, tuple) or len(response) not in (3, 4):
                raise ValueError("Malformed training worker response")
            status, state, error = response[:3]
            if len(response) == 4:
                measured = response[3]
                if (not isinstance(measured, dict) or set(measured) - {"import_seconds", "fit_seconds", "export_seconds"}
                        or any(isinstance(value, bool) or not isinstance(value, (int, float)) or
                               not math.isfinite(value) or value < 0 for value in measured.values())):
                    raise ValueError("Malformed training worker timings")
                timings.update(measured)
            if status not in ("ok", "error") or (status == "ok") != (state is not None):
                raise ValueError("Training worker status and model disagree")
            if status == "error":
                stop()
                return result("error", error=str(error or "Worker fitting failed")[:2048])
            restore_started = time.perf_counter()
            model = model_from_state(state)
            timings["restore_seconds"] = time.perf_counter() - restore_started
            expected_kind = "tree" if model_type == "tree" else ("ovr_ridge" if model_family == "ovr_ridge" else None)
            if state.get("model_kind") != expected_kind or model.task != task:
                raise ValueError("Training worker returned a different model contract")
            if time.perf_counter() - started >= timeout_seconds:
                return timeout()
            return result("ok", model)
        except Exception as error:
            stop()
            return result("error", error=f"{type(error).__name__}: {error}"[:2048])

    def close(self):
        if self._process is not None:
            if self._process.is_alive():
                self._process.terminate()
            self._process.join(timeout=1)
            if self._process.is_alive():
                self._process.kill()
                self._process.join(timeout=3)
            if self._process.is_alive():
                raise RuntimeError("The operating system could not stop the candidate worker")
            self._process.close()
        if self._connection is not None:
            self._connection.close()
        self._process = self._connection = None

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
