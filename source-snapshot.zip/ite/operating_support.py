"""Operating-setting coverage of one released official C gradient window."""

import hashlib
import math

import numpy as np

from .engine_balance import POLICY as SAMPLER_POLICY


MODULE = "input_gate_operating_support_v1"
ROWS = SAMPLER_POLICY["rows"]
DIMENSIONS = 3
POLICY = {
    "kind": MODULE,
    "settings_count": DIMENSIONS,
    "window_rows": ROWS,
    "reference_grouping": "nearest_integer_first_setting",
    "reference_scale": "median_nearest_normalized_group_median",
    "full_support_fraction": .5,
}


def reference_distance(settings, mean, std):
    """Get the reference distance from input clusters in frozen MLP units."""
    settings = np.asarray(settings, dtype=np.float64)
    mean, std = np.asarray(mean), np.asarray(std)
    if (settings.ndim != 2 or settings.shape[1] != DIMENSIONS or not np.isfinite(settings).all()
            or mean.shape != (DIMENSIONS,) or not np.isfinite(mean).all()
            or std.shape != (DIMENSIONS,) or not np.isfinite(std).all() or np.any(std <= 0)):
        raise ValueError("invalid reference operating settings or parent scaling")
    groups = np.rint(settings[:, 0])
    centers = np.asarray([np.median(settings[groups == group], axis=0) for group in np.unique(groups)])
    if len(centers) < 2:
        raise ValueError("operating reference requires at least two clusters")
    centers = np.unique(np.clip((centers - mean) / std, -10., 10.), axis=0)
    if len(centers) < 2:
        raise ValueError("operating reference has no separation in parent units")
    distances = np.linalg.norm(centers[:, None, :] - centers[None, :, :], axis=2)
    np.fill_diagonal(distances, np.inf)
    return float(np.median(distances.min(axis=1)))


class OperatingSupport:
    def __init__(self, points, distance, gradient_ids_sha256, reference_sha256):
        self.points = np.asarray(points, dtype=np.float64).copy()
        self.distance = float(distance)
        if (self.points.shape != (ROWS, DIMENSIONS) or not np.isfinite(self.points).all()
                or np.any(np.abs(self.points) > 10.) or not math.isfinite(self.distance) or self.distance <= 0
                or self.distance > 20 * math.sqrt(DIMENSIONS)):
            raise ValueError("invalid operating support state")
        for digest in (gradient_ids_sha256, reference_sha256):
            if not isinstance(digest, str) or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
                raise ValueError("invalid operating support source digest")
        raw = self.points.astype("<f8", copy=False).tobytes() + np.asarray(self.distance, dtype="<f8").tobytes()
        self.audit = {
            "policy": dict(POLICY),
            "gradient_ids_sha256": gradient_ids_sha256,
            "reference_sha256": reference_sha256,
            "state_sha256": hashlib.sha256(raw).hexdigest(),
            "rows": ROWS,
            "distance_scale": self.distance,
        }
        self.points.flags.writeable = False

    def apply(self, settings, parent, gated):
        if gated <= parent:
            return gated
        offsets = self.points - settings
        distance = math.sqrt(float(np.einsum("ij,ij->i", offsets, offsets).min()))
        if distance <= self.distance / 2:
            return gated
        if distance >= self.distance:
            return parent
        weight = 2 * (1 - distance / self.distance)
        return parent + weight * (gated - parent)
