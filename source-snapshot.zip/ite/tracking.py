"""Append-only local experiment logs and an explicitly invoked cloud replay adapter."""

import hashlib
import importlib
import json
import platform
import os
import subprocess
import sys
import zipfile
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

import numpy as np


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def source_metadata():
    root = Path(__file__).resolve().parent.parent
    digest = hashlib.sha256()
    for path in sorted((root / "ite").glob("*.py")):
        digest.update(path.name.encode())
        digest.update(path.read_bytes())
    actual_hash = digest.hexdigest()
    embedded_commit = os.environ.get("ITE_SOURCE_COMMIT")
    expected_hash = os.environ.get("ITE_SOURCE_SHA256")
    if embedded_commit:
        if not expected_hash or expected_hash != actual_hash:
            raise RuntimeError("Embedded source hash mismatch; image provenance is invalid")
        dirty_value = os.environ.get("ITE_SOURCE_DIRTY", "unknown").lower()
        dirty = None if dirty_value == "unknown" else dirty_value == "true"
        commit = embedded_commit
    else:
        try:
            commit = subprocess.run(["git", "-C", str(root), "rev-parse", "HEAD"], capture_output=True,
                                    text=True, timeout=5, check=True).stdout.strip()
            dirty = bool(subprocess.run(["git", "-C", str(root), "status", "--porcelain"],
                                       capture_output=True, text=True, timeout=5, check=True).stdout.strip())
        except (OSError, subprocess.SubprocessError):
            commit, dirty = "unavailable", None
    return {"source_commit": commit, "source_dirty": dirty, "source_sha256": actual_hash,
            "python": sys.version.split()[0], "numpy": np.__version__, "platform": platform.platform()}


class JsonlLogger:
    def __init__(self, path, run_id, append=False):
        self.path, self.run_id = Path(path), run_id
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._stream = self.path.open("a" if append else "x", encoding="utf-8")

    def event(self, event, step, **values):
        record = {"run_id": self.run_id, "event": event, "step": step,
                  "timestamp_utc": datetime.now(timezone.utc).isoformat(), **values}
        self._stream.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n")
        self._stream.flush()

    def close(self):
        self._stream.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


def _reject_credentials(value):
    """Fail before upload when a whitelisted structured artifact contains secrets."""
    if isinstance(value, dict):
        for key, child in value.items():
            normalized = str(key).lower().replace("-", "_")
            if normalized in {"api_key", "apikey", "authorization", "password", "secret", "client_secret",
                              "access_token", "refresh_token", "cookie", "cookies", "credentials"} or normalized.endswith("_api_key"):
                raise ValueError("Refusing to upload an artifact containing credential fields")
            _reject_credentials(child)
    elif isinstance(value, list):
        for child in value:
            _reject_credentials(child)


def _check_artifact(path):
    if path.suffix == ".json":
        _reject_credentials(json.loads(path.read_text(encoding="utf-8")))
    elif path.suffix == ".jsonl":
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                _reject_credentials(json.loads(line))


def _audit_archive(root):
    allowed_names = {"events.jsonl", "config.json", "summary.json", "summary.csv", "aggregates.csv",
                     "curve.csv", "report.html", "initial.npz", "deployed.npz", "predictions.npz",
                     "diagnostics.json", "provenance.json", "selection.json", "assessment.json",
                     "acceptance-freeze.json", "robustness-summary.json", "checksums.json",
                     "iteration-audit.json", "stream-manifest.json", "cost-audit.json",
                     "paid-call-ledger.json", "source-freeze.json"}
    files = sorted(path for path in root.rglob("*") if path.is_file() and not path.is_symlink()
             and path.resolve().is_relative_to(root.resolve())
             and not any(parent.is_symlink() for parent in path.parents if parent != root and parent.is_relative_to(root))
             and not any(part.startswith(".") or part.lower() in {"credentials", "secrets"}
                         for part in path.relative_to(root).parts[:-1])
             and (path.name in allowed_names or path.match("model-v*.npz") or
                  ((path.name in {"initial.npz.policy.json", "deployed.npz.policy.json"} or
                    path.match("model-v*.npz.policy.json")) and
                   path.with_name(path.name.removesuffix(".policy.json")).is_file() and
                   not path.with_name(path.name.removesuffix(".policy.json")).is_symlink())))
    event_paths = [path for path in files if path.name == "events.jsonl"]
    if not event_paths:
        raise ValueError("No experiment events.jsonl files found under the archive directory")
    for path in files:
        _check_artifact(path)
    manifest = {"policy_runs": len(event_paths), "created_utc": datetime.now(timezone.utc).isoformat(),
                "files": [{"path": path.relative_to(root).as_posix(),
                           "sha256": hashlib.sha256(path.read_bytes()).hexdigest()} for path in files]}
    archive_path = root / "swanlab-audit.zip"
    with zipfile.ZipFile(archive_path, "x", compression=zipfile.ZIP_DEFLATED) as bundle:
        bundle.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
        for path in files:
            bundle.write(path, path.relative_to(root).as_posix())
    summaries = []
    for event_path in event_paths:
        summary = event_path.with_name("summary.json")
        if summary.is_file():
            value = json.loads(summary.read_text(encoding="utf-8"))
            value["local_run"] = event_path.parent.relative_to(root).as_posix()
            summaries.append(value)
    return archive_path, manifest, summaries


def _public_project(sdk, project, workspace):
    """Inspect the existing project; init(public=True) cannot change its visibility."""
    try:
        api = sdk.Api()
        workspace = workspace or api.username
        path = f"{workspace}/{project}"
        remote = api.project(path)
        if remote.visibility != "PUBLIC" or remote.path != path or remote.name != project:
            raise ValueError("project identity or visibility mismatch")
        project_id = remote.project_id
        api_host = api._ctx.api_host
    except Exception as error:
        raise RuntimeError("SwanLab project must already have verified PUBLIC visibility") from error
    return path, project_id, api_host


def _anonymous_public_project(api_host, path, project_id):
    """A separate HTTP request carries no SDK session, cookies or authorization."""
    url = api_host.rstrip("/") + "/api/project/" + urllib.parse.quote(path, safe="/")
    try:
        request = urllib.request.Request(url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(request, timeout=15) as response:
            content_type = response.headers.get("Content-Type", "").lower()
            if response.status != 200 or "application/json" not in content_type:
                raise ValueError("Expected project JSON")
            body = response.read(1048577)
            if len(body) > 1048576:
                raise ValueError("Oversized project response")
            data = json.loads(body)
        if (not isinstance(data, dict) or data.get("path") != path or
                data.get("name") != path.split("/")[1] or data.get("visibility") != "PUBLIC" or
                not project_id or data.get("cuid") != project_id):
            raise ValueError("Project identity or visibility mismatch")
    except Exception as error:
        raise RuntimeError("SwanLab anonymous PUBLIC project verification failed") from error
    return {"verified": True, "url": url, "http_status": 200, "project_path": path,
            "project_id": project_id, "visibility": "PUBLIC", "authentication": "none",
            "checked_utc": datetime.now(timezone.utc).isoformat()}


def _action_records(events, local_run):
    """Expand decision records, retaining old step-local observations without inventing data."""
    explicit_ids = {e.get("decision_id") for e in events if e["event"] == "harness_decision"}
    observations, actions = {}, []
    for index, event in enumerate(events):
        kind, step = event["event"], event.get("step")
        if kind == "harness_observation":
            observations[(event.get("decision_id"), step)] = event.get("observation")
        fallback = (kind == "harness_call" and isinstance(event.get("parsed_action"), dict) and
                    (not event.get("decision_id") or event["decision_id"] not in explicit_ids))
        if kind != "harness_decision" and not fallback:
            continue
        decision_id = event.get("decision_id") or f"legacy-decision-{index}"
        parsed = event["parsed_action"] if fallback else event
        observation = event.get("observation", observations.get((event.get("decision_id"), step),
                                                               observations.get((None, step))))
        related = [e for e in events[index + 1:] if
                   (e.get("decision_id") == decision_id or
                    (not event.get("decision_id") and not e.get("decision_id") and e.get("step") == step))
                   and e["event"] not in {"harness_decision", "harness_call", "harness_observation"}]
        candidate_ids = {e["candidate_id"] for e in related if e["event"] == "candidate_frozen"}
        for outcome in events[index + 1:]:
            if (outcome.get("candidate_id") in candidate_ids and outcome not in related and
                    outcome["event"] in {"deploy", "experiment_rejected", "candidate_cancelled"}):
                related.append(outcome)
        attempts = [e.get("attempt_id") for e in related if e.get("attempt_id")]
        state = event.get("harness_state", "recorded")
        if parsed.get("action") == "DO_NOTHING":
            state = "DO_NOTHING"
        elif related:
            last = related[-1]
            state = {"deploy": "deployed", "candidate_frozen": "frozen",
                     "harness_action_rejected": "action_rejected", "experiment_rejected": "rejected",
                     "experiment_started": "started", "candidate_cancelled": "cancelled"}.get(last["event"], state)
            if last.get("reason") == "not_better_on_selection":
                state = "selection_rejected"
        actions.append({"local_run": local_run, "decision_id": decision_id,
                        "attempt_id": event.get("attempt_id") or (attempts[0] if attempts else None),
                        "step": step, "action": parsed.get("action"), "reason": parsed.get("reason"),
                        "observation": observation, "observation_available": observation is not None,
                        "execution_state": state, "source_event": kind, "outcomes": related})
    return actions


def _replay_events(run, sdk, event_path, local_run, start):
    events = [json.loads(line) for line in event_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    actions = _action_records(events, local_run)
    index = start
    for event in events:
        metrics = {f"{event['event']}/{key}": value for key, value in event.items()
                   if isinstance(value, (int, float)) and not isinstance(value, bool)}
        metrics["audit/event_json"] = sdk.Text(json.dumps(event, ensure_ascii=False))
        if local_run != ".":
            metrics["audit/local_run"] = sdk.Text(local_run)
        run.log(metrics, step=index)
        index += 1
    for action in actions:
        run.log({"audit/action_json": sdk.Text(json.dumps(action, ensure_ascii=False))}, step=index)
        index += 1
        for outcome in action["outcomes"]:
            if outcome.get("reason") == "independent_future_labels" and outcome["event"] in {"deploy", "experiment_rejected"}:
                run.log({"audit/gate_json": sdk.Text(json.dumps({"decision": action, "outcome": outcome},
                                                               ensure_ascii=False))}, step=index)
                index += 1
    return index


def upload_swanlab(run_dir, project, workspace=None, archive=False):
    """Transmit only when the user explicitly runs the upload subcommand."""
    run_dir = Path(run_dir).resolve()
    receipt_path = run_dir / "cloud-upload.json"
    if receipt_path.exists():
        raise FileExistsError("Refusing to overwrite an existing cloud upload receipt")
    bundle = manifest = summaries = None
    if archive:
        bundle, manifest, summaries = _audit_archive(run_dir)
        config = {"audit_policy_runs": manifest["policy_runs"], "audit_files": len(manifest["files"])}
    else:
        config = json.loads((run_dir / "config.json").read_text(encoding="utf-8"))
        events = run_dir / "events.jsonl"
        if not events.is_file():
            raise ValueError("Specify a single policy directory, or use --archive for an experiment matrix")
        _check_artifact(run_dir / "config.json")
        _check_artifact(events)
    try:
        swanlab = importlib.import_module("swanlab")
    except ImportError as error:
        raise RuntimeError("SwanLab SDK is not installed; install the optional tracking dependency first") from error
    try:
        swanlab.login(save=False)
    except Exception as error:
        raise RuntimeError(f"SwanLab authentication failed ({type(error).__name__}); use the CLI login or set SWANLAB_API_KEY locally") from error
    path, project_id, api_host = _public_project(swanlab, project, workspace)
    _anonymous_public_project(api_host, path, project_id)
    kwargs = {"project": project, "experiment_name": run_dir.name, "config": config, "mode": "online",
              "settings": swanlab.Settings(project=swanlab.Settings.Project(public=True))}
    if workspace:
        kwargs["workspace"] = workspace
    run = swanlab.init(**kwargs)
    try:
        if archive:
            run.save(str(bundle), base_path=str(run_dir), policy="now")
            for index, summary in enumerate(summaries):
                metrics = {f"summary/{key}": value for key, value in summary.items()
                           if isinstance(value, (int, float)) and not isinstance(value, bool)}
                metrics["audit/run_summary"] = swanlab.Text(json.dumps(summary, ensure_ascii=False))
                run.log(metrics, step=index)
            replay_index = len(summaries)
            for entry in manifest["files"]:
                event_path = run_dir / entry["path"]
                if event_path.name != "events.jsonl":
                    continue
                replay_index = _replay_events(run, swanlab, event_path,
                    event_path.parent.relative_to(run_dir).as_posix(), replay_index)
        else:
            _replay_events(run, swanlab, events, ".", 0)
    finally:
        run.finish()
    path, project_id, api_host = _public_project(swanlab, project, workspace)
    anonymous_access = _anonymous_public_project(api_host, path, project_id)
    receipt = {"project": project, "workspace": workspace, "source": str(run_dir),
               "visibility": "PUBLIC", "project_path": path, "project_id": project_id,
               "anonymous_access": anonymous_access,
               "url": getattr(run, "url", None), "policy_runs": manifest["policy_runs"] if archive else 1,
               "archive_sha256": hashlib.sha256(bundle.read_bytes()).hexdigest() if archive else None,
               "note": "Cloud upload completed; official experiment-record format still needs alignment"}
    with receipt_path.open("x", encoding="utf-8") as stream:
        json.dump(receipt, stream, ensure_ascii=False, indent=2, allow_nan=False)
    return receipt
