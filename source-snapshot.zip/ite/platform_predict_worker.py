"""Persistent predictor under the pinned official NumPy interpreter."""

import math
from pathlib import Path
import sys


def main():
    if len(sys.argv) != 5:
        raise ValueError("expected pinned baseline ZIP, checkpoint, profile and validated margin")
    package, checkpoint, profile, margin = sys.argv[1:]
    sys.path.insert(0, package)
    import json
    import numpy as np
    from baselines.data import json_value
    from baselines.model import Model
    from baselines.predict import predict
    from official_worker import PROFILES, _validate_model

    if np.__version__ != "1.26.4":
        raise ValueError("independent prediction requires the pinned NumPy 1.26.4 runtime")
    model = Model.load(Path(checkpoint))
    _validate_model(model, profile, PROFILES[profile])
    margin = float(margin)
    if not math.isfinite(margin) or margin < 0 or (profile != "C" and margin != 0):
        raise ValueError("invalid safety margin")
    while True:
        line = sys.stdin.readline(4 * 1024 * 1024 + 1)
        if not line:
            break
        if len(line.encode("utf-8")) > 4 * 1024 * 1024:
            raise ValueError("prediction request exceeds the size limit")
        if not line.strip():
            continue
        request = json_value(line)
        if (not isinstance(request, dict) or "inputs" not in request or set(request) - {"task", "inputs"} or
                request.get("task", model.meta["task"]) != model.meta["task"]):
            raise ValueError("prediction request accepts only matching task and inputs, never labels")
        response = predict(model, request["inputs"])
        if profile == "C" and margin:
            response["outputs"]["value"] = max(0., response["outputs"]["value"] - margin)
        print(json.dumps(response, ensure_ascii=False, allow_nan=False), flush=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, OSError, KeyError) as error:
        print(f"prediction: {error}", file=sys.stderr)
        raise SystemExit(2)
