"""Persistent predictor under the pinned official NumPy interpreter."""

import math
from pathlib import Path
import sys


def main():
    if len(sys.argv) != 5:
        raise ValueError("expected pinned baseline ZIP, checkpoint, profile and validated margin")
    package, checkpoint, profile, margin = sys.argv[1:]
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
    sys.path.insert(0, package)
    import json
    import numpy as np
    from baselines.data import json_value
    from baselines.model import Model
    from baselines.predict import predict
    from official_worker import PROFILES, _validate_model

    if np.__version__ != "1.26.4":
        raise ValueError("independent prediction requires the pinned NumPy 1.26.4 runtime")
    from ite.a_acetaldehyde_gate import is_acetaldehyde_checkpoint, predict_scores, unpack_checkpoint
    from ite.c_rbf_model import is_composite
    from ite.c_rbf_worker import load_model, predict_values
    from ite.c_adapter_model import is_input_adapter
    from ite.c_gate_model import is_gated
    raw = Path(checkpoint).read_bytes()
    a_correction = is_acetaldehyde_checkpoint(raw)
    gated = is_gated(raw)
    composite = not a_correction and (gated or is_composite(raw))
    adapted = is_input_adapter(raw)
    module = None
    if a_correction:
        from official_worker import _model
        if profile != "A":
            raise ValueError("A correction checkpoint requires profile A")
        native, a_state, a_threshold = unpack_checkpoint(raw)
        model = _model(package, native)
    elif composite:
        if profile != "C":
            raise ValueError("composite checkpoint is restricted to official C")
        if gated:
            from ite.c_gate_worker import load_model as load_gate,predict_values as gated_predict
            model,module,gate,_,_,stable_head,_=load_gate(raw,package)
            def predict_values(m,mod,x):return gated_predict(m,mod,gate,x,stable_head)
        elif adapted:
            from ite.c_adapter_worker import load_model as load_adapter, predict_values
            model,module,_ = load_adapter(raw,package)
        else:
            model,module = load_model(raw,package)
    else:
        model = Model.load(Path(checkpoint))
    _validate_model(model, profile, PROFILES[profile])
    margin = float(margin)
    if not math.isfinite(margin) or margin < 0 or (profile != "C" and margin != 0):
        raise ValueError("invalid safety margin")
    while True:
        line = sys.stdin.readline(4 * 1024 * 1024 + 1)
        if not line:
            break
        if len(line.encode("utf-8")) > 4 * 1024 * 1024:
            raise ValueError("prediction request exceeds the size limit")
        if not line.strip():
            continue
        request = json_value(line)
        if (not isinstance(request, dict) or "inputs" not in request or set(request) - {"task", "inputs"} or
                request.get("task", model.meta["task"]) != model.meta["task"]):
            raise ValueError("prediction request accepts only matching task and inputs, never labels")
        if composite or a_correction:
            from ite.platform_data import flatten
            paths,values = flatten(request["inputs"])
            if paths != model.meta["paths"]:
                raise ValueError("prediction features differ from the official parent schema")
            features = np.asarray([values])
            if a_correction:
                scores = predict_scores(model, features, a_state, a_threshold)[0]
                response = {"outputs": [{"label": label, "score": float(score)}
                                        for label, score in zip(model.meta["classes"], scores)]}
            else:
                response = {"outputs":{"value":float(predict_values(model,module,features)[0])}}
        else:
            response = predict(model, request["inputs"])
        if profile == "C" and margin:
            response["outputs"]["value"] = max(0., response["outputs"]["value"] - margin)
        print(json.dumps(response, ensure_ascii=False, allow_nan=False), flush=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, OSError, KeyError) as error:
        print(f"prediction: {error}", file=sys.stderr)
        raise SystemExit(2)
