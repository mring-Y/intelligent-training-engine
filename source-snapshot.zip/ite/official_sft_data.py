"""Pinned official CPU data, source partitions and evidence-qualified SFT export."""

import hashlib
import io
import json
from pathlib import Path
import zipfile

import numpy as np

from .harness import parse_action, validate_observation
from .official_model import OFFICIAL_PROFILES, _validate_package, default_package_path


NOTICE = "当前测试流为公开验证集的时序模拟，不代表官方隐藏测试集的真实表现。"
OFFICIAL_A_CLASSES = OFFICIAL_PROFILES["A"]["classes"]
SCENARIOS = ("stable", "abrupt", "gradual")
DRIFT = {"kind": "simulated_covariate_shift", "start_batch": 3, "width": 4,
         "magnitude_checkpoint_std": .75, "labels_unchanged": True}
C_REPLAY_SUBSETS = ("FD001", "FD002", "FD003", "FD004")
B_REPLAY_BEARINGS = tuple(f"Bearing{condition}_{bearing}"
                         for condition in (1, 2, 3) for bearing in (1, 2, 3))


def flatten_features(value, prefix=""):
    values, paths = [], []
    if isinstance(value, dict):
        children = ((value[key], f"{prefix}.{key}" if prefix else key) for key in sorted(value))
    elif isinstance(value, list):
        children = ((item, f"{prefix}[{index}]") for index, item in enumerate(value))
    else:
        if type(value) not in (int, float) or not np.isfinite(value):
            raise ValueError("Official features must be finite numeric values")
        return [float(value)], [prefix]
    for child, path in children:
        numbers, names = flatten_features(child, path)
        values.extend(numbers)
        paths.extend(names)
    return values, paths


def select_a_replay_reserve(training_rows, validation_ids, *, feature_paths=None, per_class=8):
    """Select a stable, class-balanced subset from the supplied A training split."""
    classes = OFFICIAL_PROFILES["A"]["classes"]
    if type(per_class) is not int or per_class < 1:
        raise ValueError("A replay rows per class must be a positive integer")
    validation_ids = set(validation_ids)
    observed_ids, paths, parsed, by_class = set(), None, [], {name: [] for name in classes}
    for index, row in enumerate(training_rows):
        identity, label = row.get("id"), row.get("answer")
        if not isinstance(identity, str) or not identity or identity in observed_ids or identity in validation_ids:
            raise ValueError("A replay training IDs must be unique and disjoint from validation")
        if label not in by_class:
            raise ValueError("A replay training row has an unknown class label")
        values, names = flatten_features(row["inputs"])
        if (len(values) != OFFICIAL_PROFILES["A"]["n_features"] or
                (paths is not None and names != paths) or (feature_paths is not None and names != feature_paths)):
            raise ValueError("A replay training feature paths or dimensions changed")
        paths = names if paths is None else paths
        if not np.isfinite(values).all():
            raise ValueError("A replay training features must be finite")
        parsed_row = {"index": index, "id": identity, "label": label,
                      "target": classes.index(label) + 1, "x": values}
        observed_ids.add(identity)
        parsed.append(parsed_row)
        by_class[label].append(parsed_row)
    if any(len(by_class[name]) < per_class for name in classes):
        raise ValueError("A replay training split has too few rows for a balanced reserve")
    selected_indices = set()
    for label in classes:
        ranked = sorted(by_class[label], key=lambda row: (
            hashlib.sha256(f"ite-official-a-replay-v1:{label}:{row['id']}".encode("utf-8")).digest(),
            row["id"]))
        selected_indices.update(row["index"] for row in ranked[:per_class])
    selected = [row for row in parsed if row["index"] in selected_indices]
    counts = {name: sum(row["label"] == name for row in selected) for name in classes}
    return {"x": np.asarray([row["x"] for row in selected], dtype=float),
            "y": np.asarray([row["target"] for row in selected], dtype=np.int64),
            "ids": [row["id"] for row in selected], "class_counts": counts,
            "selection_policy": "sha256_ranked_8_per_class_v1"}


def select_c_replay_reserve(training_rows, validation_ids, validation_groups, *, feature_paths=None):
    """Choose one original row from each of twelve hashed engines per C source."""
    validation_ids, validation_groups = set(validation_ids), set(validation_groups)
    observed_ids, engines = set(), {}
    for row in training_rows:
        identity, meta, target = row.get("id"), row.get("meta", {}), row.get("answer")
        subset, unit = meta.get("source_subset"), meta.get("unit")
        if (not isinstance(identity, str) or not identity or identity in observed_ids or
                identity in validation_ids or subset not in C_REPLAY_SUBSETS or
                type(unit) is not int or unit < 1 or meta.get("source_split") != "train" or
                type(target) not in (int, float) or not np.isfinite(target) or target < 0):
            raise ValueError("C replay requires unique historical training IDs and valid source/target metadata")
        group = f"{subset}:{unit:04d}"
        if group in validation_groups:
            raise ValueError("C replay training engines must be disjoint from validation")
        observed_ids.add(identity)
        engines.setdefault(group, []).append(row)
    selected = []
    for subset in C_REPLAY_SUBSETS:
        groups = [group for group in engines if group.startswith(subset + ":")]
        if len(groups) < 12:
            raise ValueError("C replay needs twelve distinct training engines per source subset")
        ranked = sorted(groups, key=lambda group: (
            hashlib.sha256(f"ite-official-c-replay-v1:engine:{group}".encode()).digest(), group))
        for group in ranked[:12]:
            row = min(engines[group], key=lambda row: (
                hashlib.sha256(f"ite-official-c-replay-v1:row:{row['id']}".encode()).digest(), row["id"]))
            selected.append((group, row))
    selected.sort(key=lambda entry: (entry[0], entry[1]["id"]))
    features, paths = [], None
    for _, row in selected:
        values, names = flatten_features(row["inputs"])
        if (len(values) != OFFICIAL_PROFILES["C"]["n_features"] or
                (paths is not None and names != paths) or (feature_paths is not None and names != feature_paths)):
            raise ValueError("C replay feature paths or dimensions changed")
        paths = names if paths is None else paths
        features.append(values)
    return {"x": np.asarray(features, dtype=float),
            "y": np.asarray([row["answer"] for _, row in selected], dtype=float),
            "ids": [row["id"] for _, row in selected], "groups": [group for group, _ in selected],
            "subset_counts": dict.fromkeys(C_REPLAY_SUBSETS, 12),
            "selection_policy": "sha256_ranked_12_engines_per_subset_v1"}


def select_b_replay_reserve(training_rows, validation_ids, validation_groups, *, feature_paths=None):
    """Keep 5–6 original rows per bearing and sixteen per operating condition."""
    validation_ids, validation_groups = set(validation_ids), set(validation_groups)
    seen, paths = set(), None
    bearings = {group: [] for group in B_REPLAY_BEARINGS}
    for row in training_rows:
        identity, meta, target = row.get("id"), row.get("meta", {}), row.get("answer")
        group, snapshot = meta.get("bearing"), meta.get("snapshot")
        if (not isinstance(identity, str) or not identity or identity in seen or
                identity in validation_ids or group not in bearings or group in validation_groups or
                type(snapshot) is not int or snapshot < 1 or
                type(target) not in (int, float) or not np.isfinite(target) or target < 0):
            raise ValueError("B replay requires unique historical IDs, disjoint bearings and valid targets")
        values, names = flatten_features(row["inputs"])
        if (len(values) != OFFICIAL_PROFILES["B"]["n_features"] or
                (paths is not None and names != paths) or
                (feature_paths is not None and names != feature_paths)):
            raise ValueError("B replay feature paths or dimensions changed")
        paths = names if paths is None else paths
        seen.add(identity)
        bearings[group].append({"id": identity, "group": group, "x": values, "y": target})
    if any(len(rows) < 6 for rows in bearings.values()):
        raise ValueError("B replay needs at least six historical rows in every training bearing")
    selected = []
    for condition in (1, 2, 3):
        groups = [group for group in B_REPLAY_BEARINGS if group.startswith(f"Bearing{condition}_")]
        extra = min(groups, key=lambda group: (
            hashlib.sha256(f"ite-official-b-replay-v1:extra:{group}".encode()).digest(), group))
        for group in groups:
            ranked = sorted(bearings[group], key=lambda row: (
                hashlib.sha256(f"ite-official-b-replay-v1:row:{row['id']}".encode()).digest(), row["id"]))
            selected.extend(ranked[:6 if group == extra else 5])
    selected.sort(key=lambda row: (row["group"], row["id"]))
    groups = [row["group"] for row in selected]
    return {"x": np.asarray([row["x"] for row in selected], dtype=float),
            "y": np.asarray([row["y"] for row in selected], dtype=float),
            "ids": [row["id"] for row in selected], "groups": groups,
            "bearing_counts": {group: groups.count(group) for group in B_REPLAY_BEARINGS},
            "condition_counts": {f"Bearing{i}": 16 for i in (1, 2, 3)},
            "selection_policy": "sha256_ranked_5_or_6_per_bearing_48_v1"}


def load_public_package(profile, package_path=None):
    if profile not in OFFICIAL_PROFILES:
        raise ValueError("Unknown official profile")
    contract = OFFICIAL_PROFILES[profile]
    package = Path(package_path or default_package_path(profile)).resolve()
    info = _validate_package(package, profile)
    with zipfile.ZipFile(package) as archive:
        rows = [json.loads(line) for line in archive.read("public/validation.jsonl").decode("utf-8").splitlines() if line]
        training_rows = [json.loads(line) for line in archive.read("public/train.jsonl").decode("utf-8").splitlines() if line]
        training_targets = [row["answer"] for row in training_rows]
        report = json.loads(archive.read("training.json"))
        with np.load(io.BytesIO(archive.read("checkpoint.npz")), allow_pickle=False) as checkpoint:
            scale = checkpoint["scale"].copy()
    x, y, ids, groups, paths = [], [], [], [], None
    previous_times = {}
    for row in rows:
        values, names = flatten_features(row["inputs"])
        if paths is None:
            paths = names
        if names != paths or len(values) != contract["n_features"]:
            raise ValueError("Official feature paths or dimensions changed")
        meta = row["meta"]
        group = (f"batch:{meta['source_batch']}" if profile == "A" else
                 meta["bearing"] if profile == "B" else f"{meta['source_subset']}:{meta['unit']:04d}")
        clock = meta["source_index"] if profile == "A" else meta["snapshot"] if profile == "B" else meta["cycle"]
        if type(clock) is not int or clock <= previous_times.get(group, 0):
            raise ValueError("Official source time must increase within each entity")
        previous_times[group] = clock
        target = (contract["classes"].index(row["answer"]) + 1 if profile == "A" else float(row["answer"]))
        if not np.isfinite(target) or target < 0:
            raise ValueError("Invalid official target")
        x.append(values)
        y.append(target)
        ids.append(row["id"])
        groups.append(group)
    if len(set(ids)) != len(ids) or not len(ids):
        raise ValueError("Official validation IDs must be unique and nonempty")
    data = {"profile": profile, "task": contract["task"], "unit": contract["target_unit"],
            "package": str(package), "package_sha256": contract["sha256"], "metadata": info,
            "reported_baseline": report["validation_after"], "feature_paths": paths,
            "x": np.asarray(x, dtype=float), "y": np.asarray(y), "ids": ids, "groups": groups,
            "scale": scale, "loss_scale": (1. if profile == "A" else max(float(np.var(training_targets)), 1e-12))}
    if profile == "A":
        data["replay_reserve"] = select_a_replay_reserve(training_rows, ids, feature_paths=paths)
    elif profile == "B":
        data["replay_reserve"] = select_b_replay_reserve(training_rows, ids, groups, feature_paths=paths)
    elif profile == "C":
        data["replay_reserve"] = select_c_replay_reserve(training_rows, ids, groups, feature_paths=paths)
    return data


def split_sources(data):
    count, profile = len(data["ids"]), data["profile"]
    if profile == "A":
        cut = count * 3 // 4
        if count < 128:
            raise ValueError("A requires enough source rows for a temporal purge")
        return {"train": list(range(cut - 32)), "eval": list(range(cut + 32, count)),
                "purged": list(range(cut - 32, cut + 32)), "rule": "75_percent_time_boundary_with_64_row_purge"}
    groups = sorted(set(data["groups"]))
    heldout = {groups[0]} if profile == "B" else set(groups[::5])
    return {"train": [i for i, g in enumerate(data["groups"]) if g not in heldout],
            "eval": [i for i, g in enumerate(data["groups"]) if g in heldout], "purged": [],
            "rule": "first_sorted_bearing_holdout" if profile == "B" else "every_fifth_sorted_engine_holdout"}


def transform_features(features, scale, scenario, step):
    x, scale = np.asarray(features, dtype=float), np.asarray(scale, dtype=float)
    if (scenario not in SCENARIOS or type(step) is not int or step < 0 or x.ndim != 2
            or scale.shape != (x.shape[1],) or not np.isfinite(x).all()
            or not np.isfinite(scale).all() or np.any(scale <= 0)):
        raise ValueError("Invalid frozen drift inputs")
    strength = 0. if scenario == "stable" or step < 3 else (1. if scenario == "abrupt" else min(1., (step - 2) / 4))
    return x + .75 * strength * scale


def metrics(profile, targets, predictions):
    y, p = np.asarray(targets), np.asarray(predictions)
    if y.ndim != 1 or y.shape != p.shape or not len(y) or not np.isfinite(y).all() or not np.isfinite(p).all():
        raise ValueError("Metrics require finite matching vectors")
    if profile == "A":
        from scripts.run_official_gas import classification_metrics
        return classification_metrics(y, p)
    if profile not in ("B", "C"):
        raise ValueError("Unknown official profile")
    residual = p - y
    return {"samples": len(y), "rmse": float(np.sqrt(np.mean(residual ** 2))),
            "mae": float(np.mean(np.abs(residual))), "overestimate_rate": float(np.mean(residual > 0)),
            "mean_overestimate": float(np.mean(np.maximum(residual, 0))), "unit": "minutes" if profile == "B" else "cycles"}


def reason_reviewed(record):
    audit = record.get("reason_audit", {})
    return (audit.get("status") == "approved" and bool(audit.get("auditor")) and
            audit.get("reason_sha256") == hashlib.sha256(record.get("reason", "").encode("utf-8")).hexdigest())


def _qualification_issue(record):
    from .trio_client import build_messages
    try:
        visible = {key: record[key] for key in ("profile", "remaining_train_seconds", "feature_distance")}
        expected = build_messages(record["observation"], model_type="official_mlp", prompt_profile="official_sft",
                                  official_context=visible)
        if record["messages"] != expected:
            return "input_not_visible_context"
    except (KeyError, ValueError, TypeError):
        return "input_not_visible_context"
    evidence = record.get("evidence", {})
    gate = evidence.get("future_gate", {})
    if (record.get("teacher_source") != "teacher" or not gate.get("accepted") or
            gate.get("source_step", -1) <= gate.get("frozen_at", -1) or
            not evidence.get("deployment_version") or
            "post_deployment_static" not in evidence or "post_deployment_active" not in evidence or
            evidence.get("whole_flow_gain", -1) < 0):
        return "missing_outcome_evidence"
    old, new = evidence["post_deployment_static"], evidence["post_deployment_active"]
    gain = new["macro_f1"] - old["macro_f1"] if record["profile"] == "A" else old["rmse"] - new["rmse"]
    if gain <= 0:
        return "no_sustained_paired_gain"
    if record["profile"] == "C" and any(new[key] > old[key] for key in ("overestimate_rate", "mean_overestimate")):
        return "c_overestimation_not_safe"
    if not reason_reviewed(record):
        return "reason_audit_required"
    return None


def export_samples(records, output_dir):
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=False)
    buckets = {name: [] for name in ("train", "eval", "review")}
    grouped, source_splits = {}, {}
    for record in records:
        validate_observation(record["observation"])
        key = json.dumps({"profile": record["profile"], "messages": record["messages"]}, sort_keys=True, ensure_ascii=False)
        grouped.setdefault(key, []).append(record)
        for identity in record["source_ids"]:
            source_splits.setdefault((record["profile"], identity), set()).add(record["split"])
    for key, items in sorted(grouped.items()):
        actions = {r.get("action") for r in items}
        record = dict(items[0])
        lineage = [{"decision_id": row.get("decision_id"), "split": row["split"],
                    "source_ids": row["source_ids"], "evidence": row.get("evidence", {})} for row in items]
        overlap = (len({row["split"] for row in items}) > 1 or any(
            len(source_splits[(row["profile"], identity)]) > 1 for row in items for identity in row["source_ids"]))
        reason = ("conflicting_actions" if len(actions) > 1 else "source_split_overlap" if overlap else
                  "duplicate_has_unverified_outcome" if any(not row.get("qualified") for row in items) and len(items) > 1 else
                  (record.get("rejection") or "unverified") if not record.get("qualified") else
                  next((issue for row in items if (issue := _qualification_issue(row))), None))
        try:
            raw = json.dumps({"action": record["action"], "reason": record["reason"]}, ensure_ascii=False)
            parse_action(raw)
        except (ValueError, KeyError):
            reason = reason or "invalid_action"
            raw = None
        record["sample_id"] = hashlib.sha256(key.encode("utf-8")).hexdigest()
        record["duplicate_count"] = len(items)
        record["lineage"] = lineage
        record["messages"] = [*record["messages"], *([{"role": "assistant", "content": raw}] if raw else [])]
        destination = "review" if reason else record["split"]
        if destination not in ("train", "eval", "review"):
            raise ValueError("Unknown dataset split")
        record["rejection"] = reason
        buckets[destination].append(record)
    for name, rows in buckets.items():
        with (output / f"{name}.jsonl").open("x", encoding="utf-8", newline="\n") as stream:
            for row in rows:
                stream.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
    counts = {key: len(value) for key, value in buckets.items()}
    (output / "manifest.json").write_text(json.dumps({"counts": counts, "notice": NOTICE,
        "teacher_proposals_are_not_ground_truth": True}, ensure_ascii=False, indent=2), encoding="utf-8")
    return counts
