"""Fail-closed, run-local protection around Mock Harness decisions and spending."""

import json
import time

from .harness import (LLMReply, TokenBudgetExceeded, action_schema, parse_action_with_repair,
                      validate_observation)


class BudgetGuard:
    # A fixed upper bound for the offline mock, not a real-provider token estimate.
    CALL_RESERVATION = 8

    def __init__(self, budget, logger, ledger=None, *, action_profile="default"):
        action_schema(action_profile)
        if action_profile in ("official_finetune", "official_c_calibration") and budget.model_type not in ("official", "official_mlp"):
            raise ValueError("Official actions require an official MLP budget")
        if action_profile == "official_c_calibration" and (budget.config.task != "regression" or
                budget.config.official_profile not in ("C", "auto")):
            raise ValueError("C calibration requires an official C budget")
        self.action_profile = action_profile
        self.budget, self.logger = budget, logger
        self.ledger = ledger
        self._ledger_state = None
        self.state, self.reason, self.tripped_at = "ACTIVE", None, None
        self.calls = self.mock_tokens = self.real_llm_tokens = 0
        self.llm_seconds = 0.0
        if ledger is not None:
            try:
                self._sync_ledger()
                if self._ledger_state["trip_reason"]:
                    self.trip(-1, self._ledger_state["trip_reason"])
            except (OSError, RuntimeError, ValueError, KeyError, TypeError):
                self.state, self.reason, self.tripped_at = "STATIC_FALLBACK", "llm_ledger_error", -1

    def _sync_ledger(self):
        self._ledger_state = self.ledger.snapshot()
        self.calls = self._ledger_state["attempted_calls"]
        self.real_llm_tokens = self._ledger_state["used_tokens"]
        self.budget.tokens = self._ledger_state["used_tokens"] + self._ledger_state["reserved_tokens"]

    def trip(self, step, reason):
        if self.state == "ACTIVE":
            self.state, self.reason, self.tripped_at = "STATIC_FALLBACK", reason, step
            if self.ledger is not None:
                try:
                    self.ledger.trip(reason)
                    self._sync_ledger()
                except (OSError, RuntimeError, ValueError, KeyError, TypeError):
                    pass  # Local latch still prevents all work if the disk is unavailable.
            self.logger.event("budget_guard_tripped", step, reason=reason,
                              **self.snapshot(), **self.budget.snapshot())
        return False

    def check(self, step):
        if self.state != "ACTIVE":
            return False
        if self.ledger is not None:
            try:
                self._sync_ledger()
            except (OSError, RuntimeError, ValueError, KeyError, TypeError):
                return self.trip(step, "llm_ledger_error")
            if self._ledger_state["trip_reason"]:
                return self.trip(step, self._ledger_state["trip_reason"])
        if self.budget.remaining_label_budget == 0:
            return self.trip(step, "label_budget_exhausted")
        if self.budget.tokens * 5 >= self.budget.config.max_tokens * 4:
            return self.trip(step, "token_limit")
        return True

    def get_decision(self, observation, client, step):
        if not self.check(step):
            return None
        try:
            validate_observation(observation, task=self.budget.config.task)
            if (observation["remaining_token_budget"] != self.budget.config.max_tokens - self.budget.tokens or
                    observation["remaining_label_budget"] != self.budget.remaining_label_budget):
                raise ValueError("Observation budgets do not match the ledger")
        except ValueError:
            self.trip(step, "invalid_observation")
            return None
        if getattr(client, "token_accounting_mode", "mock") == "real":
            return self._get_real_decision(observation, client, step)
        if self.budget.config.max_llm_calls is not None and self.calls >= self.budget.config.max_llm_calls:
            self.trip(step, "llm_call_limit")
            return None
        reserved = self.CALL_RESERVATION
        if (self.budget.tokens + reserved) * 5 >= self.budget.config.max_tokens * 4:
            self.trip(step, "token_reservation_limit")
            return None
        # The call is synchronous, with no retries. Hold the reservation locally;
        # settle once even if the client fails or the response cannot be parsed.
        self.calls += 1
        charge, action, failure, action_repaired = reserved, None, None, False
        started = time.perf_counter()
        try:
            reply = client.get_decision(json.loads(json.dumps(observation, allow_nan=False)))
            if (not isinstance(reply, LLMReply) or type(reply.usage_tokens) is not int or
                    not 0 <= reply.usage_tokens <= reserved or reply.token_accounting_mode != "mock"):
                failure = "invalid_usage"
            else:
                try:
                    action, action_repaired = parse_action_with_repair(reply.raw_json, action_profile=self.action_profile)
                    charge = reply.usage_tokens
                except ValueError:
                    failure = "invalid_action"
        except TokenBudgetExceeded:
            failure = "provider_token_exhausted"
        except TimeoutError:
            failure = "client_timeout"
        except Exception:
            failure = "client_error"
        finally:
            self.llm_seconds += time.perf_counter() - started
            self.budget.record_tokens(charge)
            self.mock_tokens += charge
            self.logger.event("harness_call", step, status=failure or "ok",
                              charged_tokens=charge,
                              observation=observation,
                              parsed_action=({"action": action.action, "reason": action.reason} if action else None),
                              action_repaired=action_repaired,
                              reserved_tokens=reserved, **self.snapshot(), **self.budget.snapshot())
        if failure:
            self.trip(step, failure)
            return None
        return action if self.check(step) else None

    def _get_real_decision(self, observation, client, step):
        if self.ledger is None:
            self.trip(step, "real_ledger_required")
            return None
        try:
            reserved = self.ledger.reserve(
                max_calls=getattr(self.budget.config, "max_llm_calls", None) or 10,
                max_input_tokens=client.max_input_tokens,
                max_output_tokens=client.max_output_tokens,
                max_total_tokens=self.budget.config.max_tokens,
                max_cost_cny=getattr(self.budget.config, "max_llm_cost_cny", "0.50"),
                input_price_per_million=client.input_price_per_million,
                output_price_per_million=client.output_price_per_million, step=step,
                model=getattr(client, "model", None))
            self._sync_ledger()
        except (OSError, RuntimeError, ValueError, KeyError, TypeError, AttributeError):
            self.trip(step, "llm_ledger_error")
            return None
        if reserved is None:
            self.trip(step, self._ledger_state["trip_reason"] or "llm_reservation_failed")
            return None
        if self._ledger_state["trip_reason"]:
            self.trip(step, self._ledger_state["trip_reason"])
            return None
        started = time.perf_counter()
        action, failure, raw_json, known, action_repaired = None, None, None, False, False
        try:
            reply = client.get_decision(json.loads(json.dumps(observation, allow_nan=False)))
            if (not isinstance(reply, LLMReply) or reply.token_accounting_mode != "real" or
                    type(reply.input_tokens) is not int or reply.input_tokens < 0 or
                    type(reply.output_tokens) is not int or reply.output_tokens < 0 or
                    type(reply.usage_tokens) is not int or
                    reply.usage_tokens != reply.input_tokens + reply.output_tokens):
                failure = "invalid_usage"
            else:
                self.ledger.settle(reserved["call_id"], input_tokens=reply.input_tokens,
                                   output_tokens=reply.output_tokens)
                known = True
                raw_json = reply.raw_json if isinstance(reply.raw_json, str) else None
                try:
                    action, action_repaired = parse_action_with_repair(reply.raw_json, action_profile=self.action_profile)
                    if reply.stop_reason not in (None, "stop", "eos"):
                        failure = "incomplete_action"
                except ValueError:
                    failure = "invalid_action"
        except TimeoutError:
            failure = "client_timeout"
        except Exception:
            failure = "client_error"
        finally:
            elapsed = time.perf_counter() - started
            self.llm_seconds += elapsed
            try:
                if not known:
                    self.ledger.mark_unknown(reserved["call_id"], failure or "invalid_usage")
                self._sync_ledger()
            except (OSError, RuntimeError, ValueError, KeyError, TypeError):
                failure = "llm_ledger_error"
            # Response is bounded and contains no credentials; keep raw text for format audits.
            safe_raw = raw_json[:4096] if raw_json is not None else None
            if safe_raw is not None:
                safe_raw = safe_raw.encode("utf-8", errors="replace").decode("utf-8")
            self.logger.event("harness_call", step, status=failure or "ok", call_id=reserved["call_id"],
                observation=observation,
                parsed_action=({"action": action.action, "reason": action.reason} if action else None),
                action_repaired=action_repaired,
                reserved_tokens=reserved["reserved_tokens"], usage_known=known,
                raw_response=safe_raw, latency_seconds=elapsed, **self.snapshot(), **self.budget.snapshot())
        if failure:
            self.trip(step, failure)
            return None
        if self._ledger_state["trip_reason"]:
            self.trip(step, self._ledger_state["trip_reason"])
            return None
        return action if self.check(step) else None

    def snapshot(self):
        return {"harness_state": self.state, "harness_trip_reason": self.reason,
                "harness_tripped_at": self.tripped_at, "llm_calls": self.calls,
                "token_accounting_mode": "real" if self.ledger is not None else "mock", "mock_tokens": self.mock_tokens,
                "real_llm_tokens": self.real_llm_tokens, "llm_seconds": self.llm_seconds,
                **({"llm_input_tokens": self._ledger_state["used_input_tokens"],
                    "llm_output_tokens": self._ledger_state["used_output_tokens"],
                    "llm_unknown_calls": self._ledger_state["unknown_calls"],
                    "llm_reserved_tokens": self._ledger_state["reserved_tokens"],
                    "llm_estimated_cost_cny": self._ledger_state["estimated_cost_cny"],
                    "llm_reserved_cost_cny": self._ledger_state["reserved_cost_cny"]}
                   if self._ledger_state is not None else {})}
