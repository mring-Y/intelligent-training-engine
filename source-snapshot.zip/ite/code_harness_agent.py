"""PyTRiO tool conversation, persistent paid budget, and strict response grammar."""

from decimal import Decimal, InvalidOperation
import json
from pathlib import Path
import sys
import time

from .code_harness import digest, write_new, TenRoundRun, candidate_source
from .decision_sft import BudgetLedger
from .trio_client import TrioLLMClient


MODEL = "Qwen/Qwen3.5-4B"
INPUT_PRICE, OUTPUT_PRICE = "1.49", "4.54"
INPUT_LIMIT, OUTPUT_LIMIT = 4096, 768
MODEL_SETTINGS = {
    MODEL: {"input_price": INPUT_PRICE, "output_price": OUTPUT_PRICE,
            "tokenizer": "deployment/tokenizer-qwen3.5-4b"},
    "Qwen/Qwen3.8-27B": {"input_price": "3.15", "output_price": "25.29",
                         "tokenizer": "deployment/tokenizer"},
}
PUBLIC_PATHS = ["TASK.md", "TRAINING_GUIDE.md", "training.py", "history.json"]
SYSTEM = """你是工业CPU模型的受控训练代码助手。只调用本轮指定工具，返回一个JSON对象，禁止代码围栏和多余文字。
目标：每包完成10次真实候选实验，读历史、写训练代码、检查结果、选定下一轮检查点。没有改善应保留incumbent，不能强迫上线。
首轮父配置是官方起点epochs=5、trainable_policy='full'；首轮也必须真正改变一个字段，严禁原样重复该配置。只能从当前消息的allowed_next_configs选择；若列表中没有想做的配置，仍选择列表内的一项，不能自行返回父配置。
CPU训练使用官方public/train.jsonl；验证只筛选及独立未来门控。你不接触目标原值或隐藏数据。
你能写的完整Python函数模板为：
def train_candidate(train, parent, x, y, seconds):
    return train(parent, x, y, seconds, epochs=4, trainable_policy='full')
epochs只允许1..5，trainable_policy只允许full或head_only。每次相对previous_proposal恰好改变一个字段；必须选择allowed_next_configs中的配置。禁止导入、额外语句、其他函数和参数。
上一候选gate_passed为false时只能选incumbent；为true也可保留incumbent。依据实际RMSE或Macro-F1和保护指标决策，C尤其注意高估。
read阶段格式：{"tool":"read_public","paths":["TASK.md","TRAINING_GUIDE.md","training.py","history.json"]}
experiment阶段格式：{"tool":"select_and_experiment","selection":"incumbent","selection_reason":"选定续训所用的父检查点","source":"完整Python函数源码，换行用JSON转义","hypothesis":"候选必须相对previous_proposal改变一个参数"}
selection只选择父检查点，source才定义候选参数；二者不是同一件事。首轮selection必须incumbent，但source绝不能原样使用epochs=5且full。可以从allowed_next_configs中选择epochs=4且full作为首候选。
experiment先选定上一轮结果，再写单因素候选代码、执行测试和真实CPU训练。收到tool_error说明候选尚未启动训练，请根据错误和当前allowed_next_configs修正；committed_selection若非null，父检查点选择已记录，本次不得改变该selection。
每次工具结果都是已完成实验的历史，下一调用必须据此决策。
finish阶段格式：{"tool":"finish","selection":"incumbent","reason":"依据第十轮实际结果选定模型的理由"}
不重复同父检查点的配置。禁止把DO_NOTHING、批次、epoch、调用当作一次实验。只输出工具JSON。
"""


def parse_tool(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("Duplicate tool field")
            result[key] = value
        return result
    def constant(_):
        raise ValueError("Nonfinite JSON constant")
    if not isinstance(raw, str) or len(raw.encode("utf-8")) > 8192:
        raise ValueError("Invalid tool response size")
    try:
        value = json.loads(raw, object_pairs_hook=pairs, parse_constant=constant)
    except (TypeError, json.JSONDecodeError):
        raise ValueError("Tool response must be strict JSON") from None
    if not isinstance(value, dict) or not isinstance(value.get("tool"), str):
        raise ValueError("A tool object is required")
    return value


def _cumulative_limit(renewal_cny):
    if renewal_cny is None:
        return Decimal("10.00")
    try:
        limit = Decimal(str(renewal_cny))
    except (InvalidOperation, ValueError):
        raise ValueError("Renewed budget must be a finite amount strictly below thirty CNY") from None
    if not limit.is_finite() or not 0 < limit < 30:
        raise ValueError("Renewed budget must be a finite amount strictly below thirty CNY")
    return limit


def remaining_budget(previous_ledger, additional_ledgers=(), *, renewal_cny=None):
    limit = _cumulative_limit(renewal_cny)
    ledgers = (previous_ledger, *additional_ledgers) if isinstance(previous_ledger, (str, Path)) else tuple(previous_ledger)
    if len(set(map(str, ledgers))) != len(ledgers):
        raise ValueError("Cumulative paid ledgers must be distinct")
    amounts = []
    for ledger in ledgers:
        data = json.loads(Path(ledger).read_text(encoding="utf-8"))
        if not isinstance(data.get("requests"), dict):
            raise ValueError("Prior paid ledger must retain all request reservations")
        if renewal_cny is None and (data.get("stopped") or any(
                row.get("state") in ("unknown", "reserved") for row in data["requests"].values())):
            raise ValueError("Unresolved prior paid requests forbid a new session")
        amounts.extend(Decimal(row["reserved_cny"]) for row in data["requests"].values())
    if any(not amount.is_finite() or amount < 0 for amount in amounts):
        raise ValueError("Invalid prior cost reservation")
    remaining = limit-sum(amounts, Decimal(0))
    if remaining <= 0:
        raise ValueError("Cumulative paid budget exhausted")
    return remaining


def run_agent(run, ask, *, max_proposal_corrections=0):
    if type(max_proposal_corrections) is not int or max_proposal_corrections not in (0,2):
        raise ValueError("Proposal corrections must be explicitly zero or two")
    feedback = None
    for correction in range(max_proposal_corrections+1):
        payload = {"context": run.context()}
        if feedback is not None:
            payload["tool_error"] = {"message":feedback,"correction":correction}
        request = ask("read", payload)
        try:
            if (set(request) != {"tool", "paths"} or request["tool"] != "read_public" or
                    not isinstance(request["paths"], list) or any(type(p) is not str for p in request["paths"]) or
                    sorted(request["paths"]) != sorted(PUBLIC_PATHS)):
                raise ValueError("Read stage only allows read_public of TASK.md, TRAINING_GUIDE.md, training.py and history.json; no experiments yet")
            files = run.read_public(request["paths"])
            break
        except ValueError as error:
            if correction >= max_proposal_corrections:
                raise
            feedback = str(error)[:512]
            run.event("tool_proposal_rejected",stage="read",error=feedback,correction=correction)
    last_result = None
    for number in range(10):
        feedback, committed = None, "incumbent" if number==0 else None
        for correction in range(max_proposal_corrections+1):
            payload = {"context": run.context(), "last_result": last_result}
            if number == 0:
                payload["files"] = files
            if feedback is not None:
                payload["tool_error"] = {"message": feedback, "correction": correction,
                                         "committed_selection": committed}
            # Network, provider, JSON and unknown-usage failures never enter
            # the host-tool correction branch, nor repeat the same request.
            response = ask("experiment", payload)
            before = getattr(run,"attempts",None)
            try:
                required = {"tool", "selection", "selection_reason", "source", "hypothesis"}
                if set(response) != required or response["tool"] != "select_and_experiment":
                    raise ValueError("Only a single-factor code experiment can count as an optimization round")
                if number and committed is None:
                    run.select(response["selection"], response["selection_reason"])
                    committed = response["selection"]
                elif response["selection"] != committed:
                    raise ValueError("The already selected parent checkpoint cannot change during proposal correction")
                result = run.experiment(response["source"], response["hypothesis"])
                break
            except ValueError as error:
                if (correction >= max_proposal_corrections or before is None or
                        getattr(run,"attempts",None) != before):
                    raise
                feedback = str(error)[:512]
                run.event("tool_proposal_rejected",error=feedback,correction=correction,
                          committed_selection=committed)
        last_result = TenRoundRun.visible_result(result)
    feedback = None
    for correction in range(max_proposal_corrections+1):
        payload = {"context":run.context(),"last_result":last_result}
        if feedback is not None:
            payload["tool_error"] = {"message":feedback,"correction":correction}
        response = ask("finish",payload)
        try:
            if set(response) != {"tool", "selection", "reason"} or response["tool"] != "finish":
                raise ValueError("Finish stage only allows finish with selection and reason; all ten candidate fits are already done")
            run.select(response["selection"], response["reason"])
            break
        except ValueError as error:
            if correction >= max_proposal_corrections:
                raise
            feedback = str(error)[:512]
            run.event("tool_proposal_rejected",stage="finish",error=feedback,correction=correction)
    return run.finish()


class PaidToolSession:
    """One process, one exclusive claim, no retries or automatic format repair."""
    def __init__(self, output, state_dir, previous_ledger, *, additional_ledgers=(), runtime_python=None,
                 renewal_cny=None, max_proposal_corrections=0, model=MODEL):
        if model not in MODEL_SETTINGS:
            raise ValueError("Unsupported code Harness model")
        self.model = model
        settings = MODEL_SETTINGS[model]
        self.input_price, self.output_price = settings["input_price"], settings["output_price"]
        if type(max_proposal_corrections) is not int or max_proposal_corrections not in (0,2):
            raise ValueError("Proposal corrections must be explicitly zero or two")
        self.max_calls = 36+36*max_proposal_corrections
        self.output, self.state = Path(output), Path(state_dir)
        self.previous = tuple(map(Path, (previous_ledger, *additional_ledgers))) if isinstance(
            previous_ledger, (str, Path)) else tuple(map(Path, previous_ledger))
        self.previous_hashes = [digest(path) for path in self.previous]
        self.total_budget_cny = _cumulative_limit(renewal_cny)
        self.remaining = remaining_budget(self.previous, renewal_cny=renewal_cny)
        reserve = Decimal(BudgetLedger.rounded_request_cost(INPUT_LIMIT, OUTPUT_LIMIT,
                                                           self.input_price, self.output_price))
        if self.max_calls*reserve > self.remaining:
            raise ValueError("Bounded tool calls exceed the cumulative remaining budget")
        self.output.mkdir(parents=True, exist_ok=False)
        self.state.mkdir(parents=True, exist_ok=True)
        write_new(self.state / "claim.json", {"output": str(self.output.resolve()),
            "prior_ledger_sha256": self.previous_hashes,
            "prior_reserved_cny": str(self.total_budget_cny-self.remaining),
            "cumulative_limit_cny": str(self.total_budget_cny), "renewed_budget": renewal_cny is not None,
            "incremental_limit_cny": str(self.remaining), "maximum_calls": self.max_calls,
            "max_proposal_corrections": max_proposal_corrections,
            "model": self.model, "input_limit": INPUT_LIMIT, "output_limit": OUTPUT_LIMIT,
            "input_price_per_million": self.input_price, "output_price_per_million": self.output_price,
            "reservation_per_call_cny": str(reserve)})
        self.ledger = BudgetLedger(self.state / "request-ledger.json", total_cny=str(self.remaining))
        self.reserve = str(reserve)
        self.client = TrioLLMClient(model=self.model, max_input_tokens=INPUT_LIMIT, max_output_tokens=OUTPUT_LIMIT,
            timeout_seconds=15, tokenizer_path=str(Path(__file__).resolve().parents[1] / settings["tokenizer"]),
            worker_command=[str(runtime_python or sys.executable), "-X", "utf8", "-m", "ite.trio_worker"],
            input_price_per_million=self.input_price, output_price_per_million=self.output_price)
        self.tokenizer = None
        self.calls = 0

    def ask(self, stage, payload):
        if [digest(path) for path in self.previous] != self.previous_hashes:
            raise RuntimeError("Prior paid ledger changed; cumulative budget cannot be trusted")
        if self.calls >= self.max_calls or self.ledger.data["stopped"]:
            raise RuntimeError("Tool session is stopped or request cap reached")
        task = {"stage": stage, **payload}
        if stage=="experiment":
            task["candidate_requirement"] = ("selection只选择父检查点；source必须从context.allowed_next_configs"
                "中选一项并写成候选函数，不能抄写父配置。若有tool_error请修正它，尚未启动CPU训练。")
        task["required_tool_now"] = {"read":"read_public","experiment":"select_and_experiment",
                                     "finish":"finish"}[stage]
        if stage=="read":
            task["required_paths_now"] = PUBLIC_PATHS
            task["stage_requirement"] = "只读取这四个公开文件。现在不能提出训练代码，后续experiment阶段才会给出文件内容。"
        elif stage=="finish":
            task["stage_requirement"] = "十次候选训练已经完成，现在只选定最后checkpoint，禁止再提实验。"
        messages = [{"role": "system", "content": SYSTEM}, {"role": "user", "content": json.dumps(
            task, ensure_ascii=False, allow_nan=False, separators=(",", ":"))}]
        if self.tokenizer is None:
            from .tokenizer_assets import verify_tokenizer_provenance
            from transformers import AutoTokenizer
            if self.model == MODEL:
                verify_tokenizer_provenance(self.client.tokenizer_path, self.model)
            else:
                # The historical 27B manifest has frozen hashes but no revision;
                # preserve that evidence and use its existing verifier unchanged.
                from .official_sft_teacher import verify_teacher_tokenizer
                verify_teacher_tokenizer()
            self.tokenizer = AutoTokenizer.from_pretrained(self.client.tokenizer_path, local_files_only=True,
                                                          trust_remote_code=False)
        rendered = self.tokenizer.apply_chat_template(messages, add_generation_prompt=True,
                                                      tokenize=False, enable_thinking=False)
        tokens = len(self.tokenizer.encode(rendered, add_special_tokens=False))
        if tokens > INPUT_LIMIT:
            raise ValueError("Tool conversation exceeds the frozen input token budget")
        self.calls += 1
        identity = f"tool-{self.calls:03d}"
        self.ledger.reserve(identity, self.reserve, purpose="code-tool", stage=stage,
                            model=self.model, input_limit=INPUT_LIMIT, output_limit=OUTPUT_LIMIT)
        record = {"id": identity, "stage": stage, "profile": payload["context"]["profile"],
                  "messages": messages, "local_input_tokens": tokens, "model": self.model}
        started = time.perf_counter()
        try:
            reply = self.client.get_messages(messages)
            record.update(raw=reply.raw_json, input_tokens=reply.input_tokens, output_tokens=reply.output_tokens,
                          finish_reason=reply.stop_reason)
            self.ledger.settle(identity, input_tokens=reply.input_tokens, output_tokens=reply.output_tokens,
                               input_price=self.input_price, output_price=self.output_price)
            if (reply.stop_reason != "stop" or reply.token_accounting_mode != "real" or
                    reply.input_tokens > INPUT_LIMIT or reply.output_tokens > OUTPUT_LIMIT):
                raise ValueError("Incomplete or unaccounted tool response")
            parsed = parse_tool(reply.raw_json)
            record.update(status="ok", parsed=parsed)
            return parsed
        except Exception as error:
            record["status"] = "timeout" if isinstance(error, TimeoutError) else "failed"
            record["error_type"] = type(error).__name__
            if self.ledger.data["requests"][identity]["state"] == "reserved":
                self.ledger.mark_unknown(identity, reason=record["status"])
            else:
                self.ledger.data["stopped"] = True
                from .decision_sft import write_json
                write_json(self.ledger.path, self.ledger.data)
            raise
        finally:
            record["wall_seconds"] = time.perf_counter()-started
            with (self.output / "provider-events.jsonl").open("a", encoding="utf-8", newline="\n") as stream:
                stream.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n")


class RehearsalActor:
    """Deterministic offline tool exercise; never represented as a real LLM."""
    configurations = [(4,"full"),(3,"full"),(2,"full"),(1,"full"),(1,"head_only"),
                      (2,"head_only"),(3,"head_only"),(4,"head_only"),(5,"head_only"),(5,"full")]
    def __init__(self):
        self.index = 0

    def __call__(self, stage, payload):
        if stage == "read":
            return {"tool": "read_public", "paths": PUBLIC_PATHS}
        choice = "candidate" if (payload.get("last_result") or {}).get("gate_passed") else "incumbent"
        if stage == "finish":
            return {"tool": "finish", "selection": choice, "reason": "Offline deterministic gate decision."}
        epochs, policy = self.configurations[self.index]
        self.index += 1
        return {"tool": "select_and_experiment", "selection": choice,
                "selection_reason": "Offline deterministic gate decision.",
                "source": candidate_source(epochs, policy), "hypothesis": "Offline single-factor tool exercise."}
