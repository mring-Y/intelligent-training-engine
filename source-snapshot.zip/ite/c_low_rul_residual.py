"""Signed residual fit for low C predictions within the existing drift gate."""

import numpy as np

from .residual_calibration import array_digest


WIDTH = 33
CEILING_CYCLES = 30.
RIDGE = .01
POLICY = {
    "kind": "drift_low_rul_residual_v1",
    "features": "gated_mlp_hidden_32_and_intercept",
    "target": "signed_residual_in_official_target_units",
    "ceiling_cycles": CEILING_CYCLES,
    "max_uplift_cycles": CEILING_CYCLES,
    "ridge_average_squared_loss": RIDGE,
    "source": "same_released_official_train_gradient_window",
}
SOURCE_FIELDS = {"rows", "source_step", "ids_sha256", "inputs_sha256", "targets_sha256", "train_sha256"}


def validate_source(source):
    if (not isinstance(source, dict) or set(source) != SOURCE_FIELDS
            or type(source["rows"]) is not int or not 1 <= source["rows"] <= 720
            or type(source["source_step"]) is not int or source["source_step"] < 0):
        raise ValueError("invalid low-RUL residual source")
    for key in SOURCE_FIELDS - {"rows", "source_step"}:
        digest = source[key]
        if not isinstance(digest, str) or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
            raise ValueError("invalid low-RUL residual source digest")


class LowRulResidual:
    def __init__(self, coefficients, source, fit_rows):
        validate_source(source)
        values = np.asarray(coefficients, dtype=np.float64)
        if (values.shape != (WIDTH,) or not np.isfinite(values).all()
                or type(fit_rows) is not int or not 0 <= fit_rows <= source["rows"]
                or (fit_rows == 0 and np.any(values))):
            raise ValueError("invalid low-RUL residual state")
        self.coefficients = values.copy()
        self.coefficients.flags.writeable = False
        self.audit = {**source, "policy": dict(POLICY), "fit_rows": fit_rows,
                      "coefficients_sha256": array_digest(values)}

    @classmethod
    def fit(cls, hidden, predictions, targets, gate_weights, target_scale, source):
        validate_source(source)
        hidden, predictions, targets, weights = (
            np.asarray(values, dtype=np.float64) for values in (hidden, predictions, targets, gate_weights))
        rows = source["rows"]
        if (hidden.shape != (rows, WIDTH - 1) or any(v.shape != (rows,) for v in (predictions, targets, weights))
                or not all(np.isfinite(v).all() for v in (hidden, predictions, targets, weights))
                or np.any(predictions < 0) or np.any(targets < 0)
                or np.any((weights < 0) | (weights > 1)) or not np.isfinite(target_scale) or target_scale <= 0):
            raise ValueError("invalid low-RUL residual fit window")
        eligible = (weights > 0) & (predictions < CEILING_CYCLES)
        count = int(np.count_nonzero(eligible))
        if not count:
            return cls(np.zeros(WIDTH), source, 0)
        design = np.column_stack((hidden[eligible], np.ones(count)))
        residual = (targets[eligible] - predictions[eligible]) / target_scale
        penalty = np.eye(WIDTH) * (RIDGE * count)
        penalty[-1, -1] = 0.
        coefficients = np.linalg.solve(design.T @ design + penalty, design.T @ residual)
        return cls(coefficients, source, count)

    def apply(self, hidden, prediction, target_scale):
        if prediction >= CEILING_CYCLES or not self.audit["fit_rows"]:
            return prediction
        estimate = float(hidden @ self.coefficients[:-1] + self.coefficients[-1]) * target_scale
        if estimate <= 0.:
            return prediction
        fraction = min(estimate / CEILING_CYCLES, 1.)
        return prediction + (CEILING_CYCLES - prediction) * fraction
