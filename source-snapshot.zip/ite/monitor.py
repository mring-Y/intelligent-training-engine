"""Describe observed drift evidence without assuming that feature shift implies failure."""

from collections import deque

import numpy as np


class DriftMonitor:
    def __init__(self, config, reference_mean, reference_std, baseline_loss):
        self.config = config
        self.mean = np.asarray(reference_mean)
        self.std = np.maximum(np.asarray(reference_std), 1e-8)
        self.baseline_loss = float(baseline_loss)
        self.min_evidence = config.monitor_min_labeled or config.min_labeled
        self.losses = deque(maxlen=max(self.min_evidence, 128))

    def observe_features(self, features):
        return float(np.sqrt(np.mean(((np.mean(features, axis=0) - self.mean) / self.std) ** 2)))

    def observe_losses(self, losses):
        self.losses.extend(float(value) for value in losses)

    def reset(self):
        # Historical candidate validation is selection evidence, not a new health target.
        self.losses.clear()

    def evidence(self, feature_distance):
        recent = float(np.mean(self.losses)) if self.losses else None
        feature_shift = feature_distance >= self.config.feature_threshold
        performance_drop = (len(self.losses) >= self.min_evidence and
                            recent > self.baseline_loss + self.config.error_increase)
        if performance_drop:
            diagnosis = "observed_prediction_degradation"
        elif feature_shift:
            diagnosis = "covariate_shift_without_observed_degradation"
        else:
            diagnosis = "no_actionable_drift"
        return {"feature_distance": feature_distance, "feature_shift": bool(feature_shift),
                "performance_drop": bool(performance_drop), "released_loss": recent,
                "labeled_evidence_count": len(self.losses), "diagnosis": diagnosis}
