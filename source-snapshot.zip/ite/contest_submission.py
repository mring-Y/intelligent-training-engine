"""Workspace v2 bridge to the verified, externally parented CPU continuation.

The model decides whether to run the frozen experiment and reads the actual
results before choosing. The SDK owns model identity, transport and receipts;
this module has no model network client, credential or local price gate.
"""

import atexit
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys

from .continuation import digest, run_round, runtime_default
from .official_model import OFFICIAL_PROFILES, OfficialModelAdapter
from .platform_data import checkpoint_metadata, json_value
from .tracking import source_metadata

TASKS = ("classification", "regression")
PREDICT_ARGV = ["python3", "/app/harness.py", "predict"]
POLICY = "A_step7_replay_B_static_C_head_only_epoch2"
_PREDICTORS = {}


def _write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n", encoding="utf-8")


def _json_excerpt(value, limit=14000):
    text = json.dumps(value, ensure_ascii=False, allow_nan=False)
    return text if len(text) <= limit else text[:limit] + " [truncated visible context]"


def _ask(rnd, context, actions):
    tool_name = "run_frozen_experiment" if context["phase"] == "read_history_and_propose" else "select_candidate"
    messages = [{"role": "system", "content": (
        "You operate the official CPU baseline continuation harness. Read the supplied real history, "
        "frozen experiment policy and results. Do not invent measurements or change hyperparameters. "
        "Use exactly one required function tool to make the decision. Do not answer in free text. "
        "The independent future gate and resource limits remain mandatory. Allowed actions in this phase: " +
        ", ".join(actions) + ".")},
        {"role": "user", "content": _json_excerpt(context, 26000)}]
    tool = {"type": "function", "function": {"name": tool_name,
        "description": "Submit one bounded Harness decision; this does not bypass CPU or safety gates.",
        "parameters": {"type": "object", "additionalProperties": False,
            "properties": {"action": {"type": "string", "enum": list(actions)},
                "reason": {"type": "string", "minLength": 1, "maxLength": 2400}},
            "required": ["action", "reason"]}}}
    receipt = rnd.model(messages, tools=[tool],
        tool_choice={"type": "function", "function": {"name": tool_name}},
        max_tokens=min(512, rnd.max_output_tokens), temperature=0)
    try:
        calls = receipt.response["choices"][0]["message"]["tool_calls"]
        if len(calls) != 1 or calls[0]["type"] != "function" or calls[0]["function"]["name"] != tool_name:
            raise ValueError("model did not return the required Harness function")
        decision = json_value(calls[0]["function"]["arguments"])
        if (not isinstance(decision, dict) or set(decision) != {"action", "reason"} or
                decision["action"] not in actions or not isinstance(decision["reason"], str) or
                not decision["reason"].strip() or len(decision["reason"].encode()) > 2400):
            raise ValueError("model decision outside the frozen action contract")
        decision = {**decision, "valid": True}
    except (KeyError, IndexError, ValueError, TypeError):
        decision = {"action": "RETAIN", "reason": "invalid_model_decision", "valid": False}
    return {"call_id": receipt.call_id, "model_name": rnd.model_name,
            "tool_name": tool_name, "raw_response": receipt.response,
            "decision": decision, "messages": messages}


def _parent(rnd):
    # Check every declared file, not merely an unused baseline attachment.
    paths = {name: rnd.parent.path(name) for name in rnd.parent.declared_paths()}
    checkpoints = rnd.parent.descriptor["checkpoint_paths"]
    npzs = [name for name in checkpoints if name.endswith(".npz")]
    if len(npzs) != 1:
        raise ValueError("exactly one declared official NPZ checkpoint is required")
    parent = paths[npzs[0]]
    expected = rnd.parent.checkpoint_sha256.removeprefix("sha256:")
    if digest(parent) != expected:
        raise ValueError("platform parent checkpoint digest differs from the declared NPZ")
    meta = checkpoint_metadata(parent)
    if (meta["profile"] != rnd.dataset_key or
            rnd.task.get("task") != OFFICIAL_PROFILES[rnd.dataset_key]["task"]):
        raise ValueError("platform task/profile does not match the official parent checkpoint")
    sidecar = Path(str(parent) + ".policy.json")
    if sidecar.exists() and sidecar not in paths.values():
        raise ValueError("parent safety sidecar must be declared and digest verified")
    history = next((path for name, path in paths.items() if name == "history.jsonl"), None)
    return parent, meta, history


def _number(metrics, name):
    value = metrics.get(name) if isinstance(metrics, dict) else None
    return value if type(value) in (int, float) and math.isfinite(value) and value >= 0 else None


def safe_candidate_selection(profile, before, after):
    """Require a paired fresh-label gain and every preapproved guard metric."""
    if not isinstance(before, dict) or not isinstance(after, dict):
        return False
    if profile == "A":
        old, new = _number(before, "macro_f1"), _number(after, "macro_f1")
        old_acc, new_acc = _number(before, "accuracy"), _number(after, "accuracy")
        return (old is not None and new is not None and new >= old + .005 and
                old_acc is not None and new_acc is not None and new_acc >= old_acc - .005)
    if profile != "C":
        return False
    old_rmse, new_rmse = _number(before, "rmse"), _number(after, "rmse")
    old_mae, new_mae = _number(before, "mae"), _number(after, "mae")
    old_rate, new_rate = _number(before, "overestimate_rate"), _number(after, "overestimate_rate")
    old_bias, new_bias = _number(before, "mean_overestimate"), _number(after, "mean_overestimate")
    return (old_rmse is not None and new_rmse is not None and new_rmse < old_rmse and
            old_mae is not None and new_mae is not None and new_mae <= old_mae * 1.02 and
            old_rate is not None and new_rate is not None and new_rate <= old_rate + .02 and
            old_bias is not None and new_bias is not None and new_bias <= old_bias + 1.)


def _decision_report(report):
    fields = ("profile", "stage_id", "parent_checkpoint_sha256", "checkpoint_sha256",
        "initial_steps", "final_steps", "initial_epochs", "final_epochs", "training_attempts",
        "accepted_updates", "training_seconds", "selection_reason", "fresh_validation_rows",
        "fresh_validation_before", "fresh_validation_after", "validation_metrics_use_final_checkpoint",
        "train_sha256", "validation_sha256", "future_accounting_complete", "platform_retained_previous_parent")
    return {key: report[key] for key in fields}


def selection_history(raw, candidate_selected, decision):
    """Preserve experiment evidence while recording actual model selection."""
    if candidate_selected:
        return raw
    lines = raw.splitlines(keepends=True)
    populated = [(index, json_value(line.decode("utf-8"))) for index, line in enumerate(lines) if line.strip()]
    starts = [(index, row) for index, row in populated if row.get("event") == "round_started"]
    if not starts or not populated or populated[-1][1].get("event") != "round_completed":
        raise ValueError("cannot bind model selection to a complete CPU round history")
    start, opened = starts[-1]
    current = [dict(row) for index, row in populated if index >= start]
    completed = current[-1]
    if completed.get("stage_id") != opened.get("stage_id"):
        raise ValueError("CPU history round boundaries do not match")
    completed.update(candidate_checkpoint_sha256=completed["checkpoint_sha256"],
        candidate_final_steps=completed["final_steps"], candidate_final_epochs=completed["final_epochs"],
        candidate_training_attempts=completed["training_attempts"], candidate_accepted_updates=completed["accepted_updates"],
        checkpoint_sha256=completed["parent_checkpoint_sha256"], final_steps=completed["initial_steps"],
        final_epochs=completed["initial_epochs"], accepted_updates=0,
        selection_reason="model_retained_platform_parent", model_selection=decision)
    return b"".join(lines[:start]) + b"".join((json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8") for row in current)


def _host_selection(profile, parent_summary, candidate_summary, local_before):
    after = candidate_summary.get("metrics", {}) if isinstance(candidate_summary, dict) else {}
    before = parent_summary.get("metrics", {}) if isinstance(parent_summary, dict) else {}
    # The candidate measurement is always the returned host summary. A local
    # reference is explicitly identified as CPU scoring on the same public
    # projection; it is never relabelled as a platform score.
    required = ("macro_f1", "accuracy") if profile == "A" else ("rmse", "mae", "overestimate_rate", "mean_overestimate")
    reference = before if all(_number(before, key) is not None for key in required) else local_before
    if not safe_candidate_selection(profile, reference, after):
        return False
    primary = "macro_f1" if profile == "A" else "rmse"
    old, new = _number(before, primary), _number(after, primary)
    if new is None:
        return False
    # No paired host reference is invented. The complete local paired check
    # remains required, and any available authoritative host regression vetoes.
    if old is not None and (new < old if profile == "A" else new > old):
        return False
    for key, mode, limit in (("accuracy", "min", .005), ("mae", "relative", 1.02),
            ("overestimate_rate", "add", .02), ("mean_overestimate", "add", 1.)):
        if profile == "A" and key != "accuracy" or profile != "A" and key == "accuracy":
            continue
        a, b = _number(before, key), _number(after, key)
        if a is not None and b is not None:
            if (b < a - limit if mode == "min" else b > a * limit if mode == "relative" else b > a + limit):
                return False
    return True


def train(rnd):
    parent, meta, parent_history = _parent(rnd)
    work = Path(os.environ.get("CONTEST_WORK", "/workspace"))
    work.mkdir(parents=True, exist_ok=True)
    # Both destinations must be fresh; do not silently reuse an interrupted run.
    state = rnd.state_workspace(work / "native-state")
    history_file = state / "history.jsonl"
    if history_file.is_file():
        parent_history = history_file
    history = rnd.history()
    training_rows = 0
    preview = []
    for row in rnd.data.training_rows():
        training_rows += 1
        if len(preview) < 2:
            preview.append(row)
    context = {"phase": "read_history_and_propose", "dataset_key": rnd.dataset_key,
        "round_index": rnd.round_index, "model_name": rnd.model_name,
        "parent_artifact_id": rnd.parent.artifact_id,
        "parent_checkpoint_sha256": rnd.parent.checkpoint_sha256,
        "parent_steps": meta["steps"], "parent_epochs": meta["epochs"],
        "training_rows": training_rows, "public_training_preview": preview,
        "history": history[-10:], "policy": POLICY,
        "approved_experiment": {"A": "step7, 48 original class-balanced replay rows, full 5 epochs",
            "B": "retain the actual parent; source-balanced experiment failed",
            "C": "existing drift+loss trigger, head_only 2 epochs"}[rnd.dataset_key],
        "limits": {"candidate_seconds": 5, "total_train_seconds": 20, "attempts": 4},
        "instructions": "Read the history, then choose EXPERIMENT or RETAIN. B can only retain. "
            "EXPERIMENT executes only the frozen policy, which may reject all candidates. "
            "Current validation labels have not been provided to this proposal call."}
    proposal = _ask(rnd, context, ("RETAIN",) if rnd.dataset_key == "B" else ("EXPERIMENT", "RETAIN"))
    attempted = proposal["decision"]["action"] == "EXPERIMENT" and rnd.dataset_key != "B"
    provenance = None
    if rnd.dataset_key == "B":
        provenance = work / "public-label-provenance.json"
        _write(provenance, {"status": "draft", "method": "Answers in the authorized platform public projection; "
            "retain-only, no gradients or independent approval claimed.", "task_contract": rnd.task})
    local = work / "cpu-result"
    report = run_round(rnd.dataset_key, rnd.data.train_path, rnd.data.validation_path,
        parent, local, f"platform-round-{rnd.round_index}", runtime_default(),
        parent_history=parent_history, audit_output=work / "cpu-audit",
        label_provenance=provenance, require_parent_history=rnd.round_index != 1,
        allow_training=attempted)
    # CPU-only logs keep their own scope. The wrapper records actual SDK calls
    # separately; a candidate is submitted after the proposal call, before the
    # result/selection call exists.
    _write(local / "sdk-model-access.json", {"model_access": "host_gateway_rpc",
        "model_name": rnd.model_name, "model_call_ids_at_submission": list(rnd.call_ids),
        "scope": "proposal call before candidate submission; final calls and selection are in native state"})
    configuration = {"policy": POLICY, "model_name": rnd.model_name,
        "parent_checkpoint_sha256": rnd.parent.checkpoint_sha256,
        "proposal_call_id": proposal["call_id"], "proposal": proposal["decision"],
        "round_index": rnd.round_index, "training_attempts": report["training_attempts"],
        "accepted_updates": report["accepted_updates"], "source": source_metadata()}
    hypothesis = proposal["decision"]["reason"]
    change = ("CPU continuation of the supplied official parent using the unchanged " + POLICY
              if report["accepted_updates"] else "No accepted CPU update; keep the supplied official parent.")
    submitted = None
    if report["accepted_updates"] and report["final_steps"] > report["initial_steps"]:
        _write(local / "model-proposal.json", proposal)
        # Declare history and safety policy too; these will be verified next round.
        code = sorted(p.name for p in local.iterdir() if p.is_file() and p.name != "checkpoint.npz")
        submitted = rnd.submit_candidate(local, hypothesis=hypothesis, change_summary=change,
            configuration=configuration, seed=meta["seed"], checkpoint_paths=["checkpoint.npz"],
            code_paths=code, predict_argv=PREDICT_ARGV)
    public_summary = submitted.get("summary", {}) if submitted else {}
    parent_summary = rnd.frame.get("current_validation", {})
    local_safe = safe_candidate_selection(rnd.dataset_key,
        report["fresh_validation_before"], report["fresh_validation_after"])
    host_safe = _host_selection(rnd.dataset_key, parent_summary, public_summary, report["validation_before"])
    allowed = bool(submitted and local_safe and host_safe)
    result_context = {"phase": "read_experiment_and_decide", "dataset_key": rnd.dataset_key,
        "round_index": rnd.round_index, "proposal": proposal["decision"],
        "actual_cpu_report": _decision_report(report), "platform_candidate_receipt": submitted,
        "platform_parent_validation": parent_summary,
        "candidate_selectable": allowed, "candidate_artifact_id": submitted["artifact_id"] if submitted else None,
        "instructions": "Read the real CPU experiment on fresh, previously unused validation IDs. "
            "The candidate remains selectable only if the independent future gate and every paired metric guard passed. "
            "Platform summaries are included as returned; never infer missing values or replace the CPU report. "
            "Select SELECT_CANDIDATE only if candidate_selectable=true; otherwise RETAIN."}
    # Never echo checkpoint/base64 payloads; the response is a receipt/summary.
    decision = _ask(rnd, result_context, ("SELECT_CANDIDATE", "RETAIN"))
    selected = submitted["artifact_id"] if allowed and decision["decision"]["action"] == "SELECT_CANDIDATE" else rnd.parent.artifact_id
    selected_candidate = bool(submitted and selected == submitted["artifact_id"])
    configuration.update(decision_call_id=decision["call_id"], selected_candidate=selected_candidate,
        local_safety_passed=local_safe, platform_summary_passed=host_safe)
    reason = decision["decision"]["reason"]
    if decision["decision"]["action"] == "SELECT_CANDIDATE" and not allowed:
        reason = "Safety rules retained the parent after model selection: " + reason
    if digest(parent) != rnd.parent.checkpoint_sha256.removeprefix("sha256:"):
        raise ValueError("platform parent changed during round")
    history_file.write_bytes(selection_history((local / "history.jsonl").read_bytes(),
        selected_candidate, decision["decision"]))
    # The SDK state carries all rounds even when the selected artifact is the
    # older parent. It is distinct from the candidate's CPU-only lineage.
    log = state / "model-decisions.jsonl"
    with log.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps({"round_index": rnd.round_index, "dataset_key": rnd.dataset_key,
            "model_name": rnd.model_name, "history_ids": list(rnd.history_ids),
            "proposal": proposal, "decision": decision, "cpu_report": report,
            "platform_candidate_receipt": submitted, "selected_artifact_id": selected,
            "model_call_ids": list(rnd.call_ids)}, ensure_ascii=False, allow_nan=False) + "\n")
    _write(state / "last-round.json", {"round_index": rnd.round_index, "dataset_key": rnd.dataset_key,
        "selected_artifact_id": selected, "selected_checkpoint_sha256": report["checkpoint_sha256"]
            if selected_candidate else report["parent_checkpoint_sha256"],
        "model_call_ids": list(rnd.call_ids), "configuration": configuration})
    rnd.save_state(state)
    rnd.finish(selected_artifact_id=selected, hypothesis=hypothesis,
        change_summary=change if selected_candidate else "Retained the supplied platform parent; no deployed weight change.",
        reason=reason, configuration=configuration, seed=meta["seed"],
        history_ids=list(rnd.history_ids), model_call_ids=list(rnd.call_ids))


class _Predictor:
    def __init__(self, checkpoint, profile):
        self.profile = profile
        self.model = OfficialModelAdapter(OFFICIAL_PROFILES[profile]["task"], runtime_default(),
            profile_type=profile, checkpoint_path=checkpoint)
        worker = Path(__file__).with_name("platform_predict_worker.py")
        self.process = subprocess.Popen([self.model.runtime_python, str(worker), self.model.package_path,
            str(checkpoint), profile, str(self.model.safety_margin)], stdin=subprocess.PIPE,
            stdout=subprocess.PIPE, stderr=sys.stderr, text=True, encoding="utf-8", bufsize=1)

    def predict(self, task, inputs):
        if task != self.model.task:
            raise ValueError("prediction task differs from the selected official checkpoint")
        self.process.stdin.write(json.dumps({"task": task, "inputs": inputs}, ensure_ascii=False, allow_nan=False) + "\n")
        self.process.stdin.flush()
        line = self.process.stdout.readline()
        if not line:
            raise RuntimeError("official persistent predictor closed without a prediction")
        result = json_value(line)["outputs"]
        if task == "classification":
            top = max(item["score"] for item in result)
            ties = [item for item in result if item["score"] == top]
            for item in ties[1:]:
                item["score"] = math.nextafter(top, 0.)
        return result

    def close(self):
        if self.process.poll() is None:
            self.process.stdin.close()
            try:
                self.process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()
        self.process.stdout.close()


def _close_predictors():
    for predictor in _PREDICTORS.values():
        predictor.close()
    _PREDICTORS.clear()


atexit.register(_close_predictors)


def predict(sample, model_dir):
    root = Path(model_dir).resolve()
    checkpoint = Path(os.environ.get("CONTEST_ARTIFACT_PATH", str(root / "checkpoint.npz")))
    if (checkpoint.is_symlink() or not checkpoint.resolve().is_relative_to(root) or
            any(path.is_symlink() for path in checkpoint.parents if path.is_relative_to(root))):
        raise ValueError("prediction checkpoint must be inside the selected model artifact")
    checkpoint = checkpoint.resolve()
    meta = checkpoint_metadata(checkpoint)
    profile = meta["profile"]
    if sample.task != OFFICIAL_PROFILES[profile]["task"] or (
            sample.dataset_key is not None and sample.dataset_key != profile):
        raise ValueError("prediction task/context does not match the selected checkpoint")
    predictor = _PREDICTORS.get(checkpoint)
    if predictor is None:
        if len(_PREDICTORS) >= 4:
            key = next(iter(_PREDICTORS))
            _PREDICTORS.pop(key).close()
        predictor = _Predictor(checkpoint, profile)
        _PREDICTORS[checkpoint] = predictor
    return predictor.predict(sample.task, sample.inputs)
