"""Deterministic, label-free engine quotas inside one observed train batch."""

import hashlib

import numpy as np

NAME="latest_batch_engine_balanced_v1"
POLICY={"kind":NAME,"rows":720,"scope":"latest_released_training_batch",
        "engine_order":"sorted","within_engine":"sha256_id_then_id","output_order":"observed_batch"}


def select_indices(identities,group_for_id):
    if (len(identities)<720 or len(set(identities))!=len(identities) or
            any(not isinstance(i,str) or i not in group_for_id for i in identities)):
        raise ValueError("engine sampler requires at least720 distinct locked train identities")
    grouped={}
    for index,identity in enumerate(identities):
        grouped.setdefault(group_for_id[identity],[]).append(index)
    for rows in grouped.values():rows.sort(key=lambda i:(hashlib.sha256(identities[i].encode()).digest(),identities[i]))
    selected=[];counts={g:0 for g in sorted(grouped)}
    while len(selected)<720:
        for group,count in counts.items():
            if count<len(grouped[group]):
                selected.append(grouped[group][count]);counts[group]+=1
                if len(selected)==720:break
    indices=np.asarray(sorted(selected),dtype=int)
    audit={"policy":dict(POLICY),"pool_rows":len(identities),"pool_engines":len(grouped),
        "selected_engine_counts":{g:n for g,n in counts.items() if n},
        "pool_ids_sha256":hashlib.sha256("\n".join(identities).encode()).hexdigest(),
        "selected_ids_sha256":hashlib.sha256("\n".join(identities[int(i)] for i in indices).encode()).hexdigest(),
        "selection_uses_targets":False}
    return indices,audit
