"""Public training-only cross-fit sources and finite-horizon action labels.

DO_NOTHING means best only among the supplied tested candidates and horizon;
it is not a claim of global action optimality. No rationale is generated here.
"""

import hashlib
import json
from pathlib import Path
import re
import zipfile

import numpy as np

from .official_model import OFFICIAL_PROFILES, _validate_package, default_package_path
from .official_sft_data import C_REPLAY_SUBSETS, flatten_features


_TRAIN = {
    "A": (445, "c724014feb2c968d144e167f4997d2ad2125df3825abf4306c9c87c8f08de6c0"),
    "B": (7032, "71b2663fffd3d7ef6dca8a7b3feb31c3feb96c57f385335d03041a5fa431054a"),
    "C": (113089, "fcfaeaf1e50a0cc01766dfba5fd34c7369f1fe14bf583111837e847865fac281"),
}
_BEARINGS = {f"Bearing{i}_{j}" for i in range(1, 4) for j in range(1, 4)}
_ACTIONS = {"DO_NOTHING", "RETRAIN_LARGE", "RETRAIN_HEAD_ONLY"}


def _contract(profile):
    if profile not in OFFICIAL_PROFILES:
        raise ValueError("Unknown official profile")
    return OFFICIAL_PROFILES[profile]


def _source(profile, row):
    meta, identity = row["meta"], row["id"]
    if profile == "A":
        clock = meta.get("source_index")
        if type(meta.get("source_batch")) is not int or meta["source_batch"] != 1:
            raise ValueError("A training source must be batch 1")
        group, expected = "batch:1", f"gas_b01_{clock:06d}" if type(clock) is int else None
    elif profile == "B":
        group, clock = meta.get("bearing"), meta.get("snapshot")
        source = meta.get("source")
        if group not in _BEARINGS or not isinstance(source, str) or not source.endswith(f"/{group}/{clock}.csv"):
            raise ValueError("Invalid B bearing source metadata")
        expected = f"xjtu_{group}_s{clock:06d}" if type(clock) is int else None
    else:
        subset, unit, clock = meta.get("source_subset"), meta.get("unit"), meta.get("cycle")
        if (subset not in C_REPLAY_SUBSETS or type(unit) is not int or unit < 1 or
                meta.get("source_split") != "train" or meta.get("window_size") != 1):
            raise ValueError("Invalid C historical engine source metadata")
        group = f"{subset}:{unit:04d}"
        expected = f"{subset.lower()}_train_u{unit:04d}_c{clock:05d}" if type(clock) is int else None
    if type(clock) is not int or clock < 1 or identity != expected:
        raise ValueError("Invalid official source clock or ID")
    return group, clock


def load_public_training_source(profile, package_path=None):
    """Read only public/train.jsonl labels, preserving source and report provenance."""
    contract = _contract(profile)
    package = Path(package_path or default_package_path(profile)).resolve()
    metadata = _validate_package(package, profile)
    try:
        with zipfile.ZipFile(package) as archive:
            raw = archive.read("public/train.jsonl")
            report = json.loads(archive.read("training.json"))
        rows = [json.loads(line) for line in raw.decode("utf-8").splitlines() if line]
        digest = "sha256:" + hashlib.sha256(raw).hexdigest()
        if (report.get("profile") != profile or report.get("task") != contract["task"] or
                type(report.get("train_rows")) is not int or report["train_rows"] != len(rows) or
                report.get("input_features") != contract["n_features"] or
                report.get("train_sha256") != digest or len(rows) != _TRAIN[profile][0] or
                digest != "sha256:" + _TRAIN[profile][1]):
            raise ValueError("Official training report profile/task/rows/features/hash mismatch")
        x, y, ids, groups, clocks, paths, previous = [], [], [], [], [], None, {}
        for row in rows:
            identity, target = row["id"], row["answer"]
            if not isinstance(identity, str) or not identity:
                raise ValueError("Official training IDs must be nonempty strings")
            values, names = flatten_features(row["inputs"])
            if paths is None:
                paths = names
            if names != paths or len(values) != contract["n_features"]:
                raise ValueError("Official training feature order or dimension changed")
            group, clock = _source(profile, row)
            if clock <= previous.get(group, 0):
                raise ValueError("Official training source clocks must increase within entities")
            previous[group] = clock
            if profile == "A":
                if target not in contract["classes"]:
                    raise ValueError("Unknown official class label")
                target = contract["classes"].index(target) + 1
            elif type(target) not in (int, float) or not np.isfinite(target) or target < 0:
                raise ValueError("Official regression targets must be finite and nonnegative")
            x.append(values)
            y.append(target)
            ids.append(identity)
            groups.append(group)
            clocks.append(clock)
        if len(set(ids)) != len(ids):
            raise ValueError("Official training IDs must be unique")
        return {"profile": profile, "task": contract["task"], "unit": contract["target_unit"],
                "package": str(package), "package_sha256": contract["sha256"], "metadata": metadata,
                "training_report": report, "train_sha256": digest, "rows": rows,
                "x": np.asarray(x, dtype=float), "y": np.asarray(y), "ids": ids,
                "groups": groups, "source_clocks": clocks, "feature_paths": paths}
    except (KeyError, TypeError, UnicodeError, json.JSONDecodeError, zipfile.BadZipFile) as error:
        raise ValueError("Official training source is incomplete or malformed") from error


def _rank(profile, group):
    return hashlib.sha256(f"ite-official-crossfit-v1:{profile}:{group}".encode()).digest(), group


def make_crossfit_folds(profile, data):
    """Plan initialization exclusions without inspecting outcomes or changing source order."""
    contract = _contract(profile)
    count = len(data["ids"])
    if (data.get("profile") != profile or count != _TRAIN[profile][0] or
            data.get("train_sha256") != "sha256:" + _TRAIN[profile][1] or
            len(set(data["ids"])) != count or len(data["groups"]) != count or
            len(data["source_clocks"]) != count or
            np.shape(data["x"]) != (count, contract["n_features"]) or len(data["y"]) != count):
        raise ValueError("Cross-fit requires the complete pinned training source")
    folds = []
    if profile == "A":
        if set(data["groups"]) != {"batch:1"} or data["source_clocks"] != list(range(1, 446)):
            raise ValueError("A cross-fit requires the original chronological source")
        for number, (stop, start, end) in enumerate(((120, 184, 314), (250, 314, 445))):
            folds.append({"fold_id": f"A-{number}", "split": "train" if number == 0 else "eval",
                "initialization_indices": list(range(stop)), "replay_indices": list(range(start, end)),
                "replay_groups": [f"batch:1:rows:{start}:{end}"],
                "excluded_groups": [f"batch:1:rows:{stop}:445"], "purge_indices": list(range(stop, start)),
                "rule_id": "a_forward_prefix_64_row_purge_v1"})
        return folds
    groups = set(data["groups"])
    if profile == "B":
        if groups != _BEARINGS:
            raise ValueError("B cross-fit requires all nine pinned bearings")
        assigned = [set() for _ in range(3)]
        for number, group in enumerate(sorted(groups, key=lambda g: _rank(profile, g))):
            assigned[number % 3].add(group)
    else:
        assigned = [set() for _ in range(6)]
        for subset, expected in zip(C_REPLAY_SUBSETS, (70, 182, 70, 174)):
            members = [g for g in groups if re.fullmatch(subset + r":\d{4}", g)]
            if len(members) != expected:
                raise ValueError("C cross-fit requires all pinned engines in each subset")
            for number, group in enumerate(sorted(members, key=lambda g: _rank(profile, g))):
                assigned[number % 6].add(group)
        if set.union(*assigned) != groups:
            raise ValueError("Unknown C training source group")
    global_eval = set.union(*assigned[2 if profile == "B" else 4:])
    for number, held in enumerate(assigned):
        excluded = held | global_eval
        replay_groups = sorted(held)
        if profile == "C":
            replay_groups = [min((g for g in held if g.startswith(subset + ":")),
                                 key=lambda g: _rank(profile, g)) for subset in C_REPLAY_SUBSETS]
        replay_set = set(replay_groups)
        folds.append({"fold_id": f"{profile}-{number}",
            "split": "train" if number < (2 if profile == "B" else 4) else "eval",
            "initialization_indices": [i for i, g in enumerate(data["groups"]) if g not in excluded],
            "replay_indices": [i for i, g in enumerate(data["groups"]) if g in replay_set],
            "replay_groups": replay_groups, "heldout_groups": sorted(held),
            "excluded_groups": sorted(excluded), "purge_indices": [],
            "rule_id": f"{profile.lower()}_sha256_round_robin_entity_holdout_v1"})
    return folds


def _number(value):
    return type(value) in (int, float) and np.isfinite(value)


def choose_counterfactual_action(profile, outcomes):
    """Choose best supplied tested action on its horizon; never generate rationale text."""
    _contract(profile)
    qualified = []
    for record in outcomes:
        action = record.get("action")
        if action not in _ACTIONS:
            raise ValueError("Unknown tested counterfactual action")
        if record.get("status") in ("training_error", "incomplete", "error") or record.get("rejection") in (
                "candidate_training_error", "training_budget_exhausted"):
            raise ValueError("Incomplete counterfactual cannot supply an action label")
        if action == "DO_NOTHING":
            continue
        evidence = record.get("evidence", {})
        gate = evidence.get("future_gate", {})
        old, new = evidence.get("post_deployment_static", {}), evidence.get("post_deployment_active", {})
        keys = ("macro_f1", "accuracy") if profile == "A" else ("rmse", "mae") if profile == "B" else (
            "rmse", "overestimate_rate", "mean_overestimate")
        time = evidence.get("train_seconds")
        if (gate.get("accepted") is not True or type(gate.get("source_step")) is not int or
                type(gate.get("frozen_at")) is not int or gate["source_step"] <= gate["frozen_at"] or
                type(evidence.get("deployment_version")) is not int or evidence["deployment_version"] < 1 or
                not _number(time) or time < 0 or type(old.get("samples")) is not int or
                old["samples"] < 1 or old.get("samples") != new.get("samples") or
                any(not _number(metric.get(key)) or metric[key] < 0 for metric in (old, new) for key in keys)):
            continue
        if profile == "A":
            gain, safe = new["macro_f1"] - old["macro_f1"], new["accuracy"] >= old["accuracy"]
        else:
            gain = old["rmse"] - new["rmse"]
            safe = all(new[key] <= old[key] for key in keys[1:])
        if gain > 0 and safe:
            qualified.append((-gain, time, action))
    return min(qualified)[2] if qualified else "DO_NOTHING"
