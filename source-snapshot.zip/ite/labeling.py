"""Label allocation using only protocol facts and previously observed evidence."""

import math
from dataclasses import dataclass


class LabelScheduler:
    def __init__(self, config):
        self.config = config
        self.per_batch = (config.batch_size if config.label_mode == "provided" else
                          math.ceil(config.label_fraction * config.batch_size))
        self.horizon = max(0, config.n_batches - config.label_delay)
        self.limit = min(config.max_labels, self.horizon * self.per_batch)

    def count(self, step, used, performance_drop=False, pending=False):
        if self.config.label_mode == "provided":
            return self.per_batch
        if self.config.label_schedule == "frontloaded":
            return min(self.per_batch, max(0, self.config.max_labels - used))
        slots = self.horizon - step
        remaining = max(0, self.limit - used)
        if slots <= 0 or not remaining:
            return 0
        if self.config.label_schedule == "uniform":
            return min(self.per_batch, math.ceil(remaining / slots))
        # Half the quota funds continuing surveillance. Bursts can use the other
        # half, but may never spend future batches' reserved surveillance labels.
        monitor_budget = self.limit // 2
        before = monitor_budget * step // self.horizon
        after = monitor_budget * (step + 1) // self.horizon
        reserve = monitor_budget - after
        needed_to_finish = remaining - self.per_batch * (slots - 1)
        desired = self.per_batch if performance_drop or pending else after - before
        startup_remaining = max(0, self.config.label_startup_budget - used)
        if startup_remaining:
            desired = min(self.per_batch, startup_remaining)
        # Startup uses the same quota and cannot spend the future reserve.
        return max(0, min(self.per_batch, remaining - reserve, max(desired, needed_to_finish)))


@dataclass(frozen=True)
class LabelAvailability:
    """Public request metadata, never features or hidden targets."""

    remaining: int | None
    per_batch: int
    last_step: int
    delay: int
    outstanding: tuple = ()  # (source_step, due_step), one entry per requested label

    def capacity(self, frozen_at, step, deadline):
        end = min(deadline, self.last_step)
        in_flight = sum(source > frozen_at and due <= end for source, due in self.outstanding)
        first_source = max(step + 1, frozen_at + 1)
        last_source = end - self.delay
        slots = max(0, last_source - first_source + 1)
        available = self.per_batch * slots
        return in_flight + (available if self.remaining is None else min(self.remaining, available))
