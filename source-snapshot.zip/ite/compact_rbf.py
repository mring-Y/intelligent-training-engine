"""Deterministic compact-support residuals; no global intercept or label gate."""

import time

import numpy as np

POLICY = {"centers": 8, "neighbor_rank": 64, "ridge_lambda": 1.,
          "shrinkage": .2, "maximum_correction_cycles": 10.,
          "kernel": "wendland_c2", "normalization": "parent_clipped_standardization"}


def matrix(features, width=None):
    x = np.asarray(features, dtype=np.float64)
    if x.ndim != 2 or not 1 <= x.shape[1] <= 4096 or (width is not None and x.shape[1] != width) or not np.isfinite(x).all():
        raise ValueError("compact residual requires a finite feature matrix with the declared width")
    return x


class CompactRBF:
    def __init__(self, centers, radii, coefficients):
        self.centers = matrix(centers).copy()
        self.radii = np.asarray(radii, dtype=np.float64).copy()
        self.coefficients = np.asarray(coefficients, dtype=np.float64).copy()
        n = len(self.centers)
        if (not 1 <= n <= 8 or self.radii.shape != (n,) or self.coefficients.shape != (n,) or
                not np.isfinite(self.radii).all() or np.any(self.radii < 0) or not np.isfinite(self.coefficients).all()):
            raise ValueError("invalid compact residual parameters")

    def basis(self, features):
        x = matrix(features, self.centers.shape[1])
        columns = []
        for center, radius in zip(self.centers, self.radii):
            with np.errstate(over="ignore"):
                distance = np.sqrt(np.sum((x-center)**2, axis=1))
            values = np.zeros(len(x), dtype=np.float64)
            if radius > 0:
                inside = distance < radius
                t = distance[inside]/radius
                values[inside] = (1.-t)**4*(4.*t+1.)
            columns.append(values)
        return np.column_stack(columns)

    def predict(self, features):
        return self.basis(features) @ self.coefficients

    @classmethod
    def fit(cls, features, residuals, *, deadline=None):
        x = matrix(features)
        y = np.asarray(residuals, dtype=np.float64)
        if len(x) < 64 or y.shape != (len(x),) or not np.isfinite(y).all():
            raise ValueError("compact residual fit needs at least 64 finite paired training rows")

        def check():
            if deadline is not None and time.perf_counter() >= deadline:
                raise TimeoutError("compact residual exhausted the original candidate budget")

        check()
        selected, nearest = [], np.full(len(x), np.inf)
        index = 0
        radii = []
        for _ in range(8):
            check()
            distance_squared = np.sum((x-x[index])**2, axis=1)
            if not np.isfinite(distance_squared).all():
                raise ValueError("training feature distances overflowed")
            selected.append(index)
            radii.append(float(np.sqrt(np.partition(distance_squared, 63)[63])))
            nearest = np.minimum(nearest, distance_squared)
            index = int(np.argmax(nearest))
            if nearest[index] <= 0:
                break
        provisional = cls(x[selected], radii, np.zeros(len(selected)))
        phi = provisional.basis(x)
        coefficients = np.linalg.solve(phi.T @ phi + np.eye(len(selected)), phi.T @ y)
        check()
        return cls(provisional.centers, radii, coefficients)
