"""Deterministic reference inputs from locked official train; labels excluded."""

from functools import lru_cache
import hashlib
import json
from pathlib import Path
import zipfile

import numpy as np


class GateReference:
    def __init__(self,package):
        from .official_model import _validate_package
        from .official_sft_data import flatten_features
        _validate_package(Path(package),"C")
        with zipfile.ZipFile(package) as z:
            raw=z.read("public/train.jsonl")
        self.source_sha256=hashlib.sha256(raw).hexdigest()
        grouped={};self.group_for_id={}
        for line in raw.decode("utf8").splitlines():
            row=json.loads(line)
            group=f"{row['meta']['source_subset']}:{row['meta']['unit']:04d}"
            self.group_for_id[row["id"]]=group
            grouped.setdefault(group,[]).append((row["id"],row["inputs"]))
        self.samples=[]
        for index,group in enumerate(sorted(grouped)):
            rows=sorted(grouped[group],key=lambda r:hashlib.sha256(r[0].encode()).digest())[:4]
            self.samples.extend((identity,group,"calibration" if index%5==0 else "fit",flatten_features(inputs)[0]) for identity,inputs in rows)

    def for_sources(self,identities):
        if (not identities or len(set(identities))!=len(identities) or any(i not in self.group_for_id for i in identities)):
            raise ValueError("gate current sources must be distinct locked official train IDs")
        current={self.group_for_id[i] for i in identities}
        result={"source_sha256":self.source_sha256,"current_groups":sorted(current),
            "current_ids_sha256":hashlib.sha256("\n".join(identities).encode()).hexdigest()}
        for role in ("fit","calibration"):
            rows=[r for r in self.samples if r[2]==role and r[1] not in current]
            result[role+"_x"]=np.asarray([r[3] for r in rows],dtype=np.float64)
            result[role+"_ids"]=[r[0] for r in rows]
            result[role+"_groups"]=[r[1] for r in rows]
        if len(result["fit_x"])<64 or len(result["calibration_x"])<32:
            raise ValueError("insufficient disjoint historical gate reference")
        return result


@lru_cache(maxsize=2)
def load_reference(package):
    return GateReference(package)
