"""Complete single-NPZ C MLP/RBF artifacts and bounded pinned-runtime fitting."""

import base64
import hashlib
import io
import json
from pathlib import Path
import subprocess
import time
import zipfile

import numpy as np

from .compact_rbf import CompactRBF, POLICY, matrix

FORMAT = "ite.c-mlp-compact-rbf.v1"
LIMIT = 16 * 1024 * 1024
FIELDS = {"metadata", "mlp_checkpoint", "rbf_centers", "rbf_radii", "rbf_coefficients"}


def npz_bytes(arrays):
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w", compression=zipfile.ZIP_STORED) as archive:
        for name in sorted(arrays):
            value = io.BytesIO()
            np.lib.format.write_array(value, np.asarray(arrays[name]), allow_pickle=False)
            entry = zipfile.ZipInfo(name+".npy", date_time=(1980,1,1,0,0,0))
            entry.create_system = 3
            entry.external_attr = 0o600 << 16
            archive.writestr(entry, value.getvalue())
    return stream.getvalue()


def is_composite(raw):
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            return "mlp_checkpoint.npy" in archive.namelist()
    except zipfile.BadZipFile as error:
        raise ValueError("invalid checkpoint NPZ") from error


def unpack_checkpoint(raw):
    if not isinstance(raw, bytes) or not 1 <= len(raw) <= LIMIT:
        raise ValueError("composite checkpoint exceeds the bounded NPZ contract")
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            entries = archive.infolist()
            if (len(entries) != len(FIELDS) or {e.filename for e in entries} != {k+".npy" for k in FIELDS} or
                    sum(e.file_size for e in entries) > LIMIT):
                raise ValueError("complete composite checkpoint tensors are required")
        with np.load(io.BytesIO(raw), allow_pickle=False) as archive:
            meta_array = archive["metadata"]
            if meta_array.shape != () or meta_array.dtype.kind != "U":
                raise ValueError("invalid composite metadata")
            from .platform_data import json_value
            meta = json_value(str(meta_array))
            if (not isinstance(meta, dict) or set(meta) != {"format","profile","policy","parent_checkpoint_sha256","mlp_sha256"} or
                    meta["format"] != FORMAT or meta["profile"] != "C" or meta["policy"] != POLICY):
                raise ValueError("unsupported composite model format or policy")
            for key in ("parent_checkpoint_sha256", "mlp_sha256"):
                value = meta[key]
                if not isinstance(value, str) or len(value) != 64 or any(c not in "0123456789abcdef" for c in value):
                    raise ValueError("invalid composite parent or MLP digest")
            embedded = archive["mlp_checkpoint"]
            if embedded.ndim != 1 or embedded.dtype != np.dtype("uint8") or not len(embedded):
                raise ValueError("missing actual MLP optimizer checkpoint")
            mlp = embedded.tobytes()
            if hashlib.sha256(mlp).hexdigest() != meta["mlp_sha256"] or is_composite(mlp):
                raise ValueError("embedded official MLP digest or structure mismatch")
            tensors = [archive[k].copy() for k in ("rbf_centers","rbf_radii","rbf_coefficients")]
            if any(a.dtype != np.dtype("float64") for a in tensors):
                raise ValueError("residual tensors must be float64")
            module = CompactRBF(*tensors)
            if module.centers.shape[1] != 24:
                raise ValueError("C residual feature schema mismatch")
        return mlp, module, meta
    except (zipfile.BadZipFile, KeyError, TypeError) as error:
        raise ValueError("invalid complete composite checkpoint") from error


def pack_checkpoint(mlp, module, parent_digest):
    meta = {"format":FORMAT,"profile":"C","policy":dict(POLICY),
            "parent_checkpoint_sha256":parent_digest,"mlp_sha256":hashlib.sha256(mlp).hexdigest()}
    raw = npz_bytes({"metadata":np.array(json.dumps(meta,sort_keys=True,separators=(",",":"),allow_nan=False)),
        "mlp_checkpoint":np.frombuffer(mlp,dtype=np.uint8),"rbf_centers":module.centers,
        "rbf_radii":module.radii,"rbf_coefficients":module.coefficients})
    unpack_checkpoint(raw)
    return raw


class CRBFModel:
    def __init__(self, mlp, module=None, *, parent_digest=None, checkpoint=None):
        from .official_model import OfficialModelAdapter
        if (not isinstance(mlp, OfficialModelAdapter) or mlp.profile_type != "C" or mlp.safety_margin != 0 or
                (module is not None and (not isinstance(module,CompactRBF) or module.centers.shape[1] != 24))):
            raise ValueError("compact residual requires the actual uncalibrated official C MLP")
        self.mlp, self.module = mlp, module
        self.parent_digest = parent_digest or mlp.checkpoint_sha256
        self.checkpoint_bytes = (checkpoint if checkpoint is not None else
            mlp.checkpoint_bytes if module is None else pack_checkpoint(mlp.checkpoint_bytes,module,self.parent_digest))
        self.checkpoint_sha256 = hashlib.sha256(self.checkpoint_bytes).hexdigest()

    def __getattr__(self, name):
        return getattr(self.mlp, name)

    def _invoke_rbf(self, operation, features, timeout=30., **options):
        request = {"operation":operation,"checkpoint":base64.b64encode(self.checkpoint_bytes).decode("ascii"),
                   "features":matrix(features,24).tolist(),**options}
        command = [self.mlp.runtime_python,"-B","-X","utf8",str(Path(__file__).with_name("c_rbf_worker.py")),self.mlp.package_path]
        result = subprocess.run(command,input=json.dumps(request,allow_nan=False),capture_output=True,
                                text=True,encoding="utf-8",timeout=timeout)
        if result.returncode:
            raise RuntimeError("compact CPU worker failed: "+result.stderr[-1500:])
        response = json.loads(result.stdout)
        if response.get("ok") is not True:
            raise RuntimeError("compact CPU worker returned an invalid response")
        return response

    def predict(self, features):
        x = matrix(features,24)
        if self.module is None:
            return self.mlp.predict(x)
        response = self._invoke_rbf("predict",x)
        values = np.asarray(response["predictions"],dtype=np.float64)
        if values.shape != (len(x),) or not np.isfinite(values).all() or np.any(values<0):
            raise ValueError("invalid complete model predictions")
        return values

    def save(self, path):
        with Path(path).open("xb") as stream:
            stream.write(self.checkpoint_bytes)

    @classmethod
    def from_bytes(cls, raw, runtime_python):
        from .official_model import OfficialModelAdapter
        if is_composite(raw):
            base, module, meta = unpack_checkpoint(raw)
            parent = meta["parent_checkpoint_sha256"]
        else:
            base, module, parent = raw, None, hashlib.sha256(raw).hexdigest()
        mlp = OfficialModelAdapter("regression",runtime_python,profile_type="C",checkpoint_bytes=base,candidate_epochs=2)
        return cls(mlp,module,parent_digest=parent,checkpoint=raw)

    @classmethod
    def load(cls, path, runtime_python):
        path = Path(path)
        if path.is_symlink() or not path.is_file() or not 1 <= path.stat().st_size <= LIMIT:
            raise ValueError("checkpoint must be a bounded regular NPZ")
        return cls.from_bytes(path.read_bytes(),runtime_python)


def fit_rbf_candidate(parent, features, targets, allowance, *, trainable_policy="head_only"):
    from .official_model import OfficialModelAdapter
    if isinstance(parent,OfficialModelAdapter):
        parent = CRBFModel(parent)
    if (not isinstance(parent,CRBFModel) or trainable_policy != "head_only" or parent.candidate_epochs != 2 or
            not 0 < float(allowance) <= 5.):
        raise ValueError("RBF experiment preserves C2 head-only and the original five-second budget")
    started = time.perf_counter()
    response = parent._invoke_rbf("fit",features,timeout=allowance,targets=np.asarray(targets,dtype=float).tolist(),
                                  allowance=float(allowance))
    candidate = CRBFModel.from_bytes(base64.b64decode(response["checkpoint"],validate=True),parent.runtime_python)
    elapsed = time.perf_counter()-started
    if elapsed > allowance:
        raise TimeoutError("complete RBF continuation exceeded the original candidate allowance")
    candidate.last_fit_audit = response["fit_audit"]
    return candidate, elapsed
