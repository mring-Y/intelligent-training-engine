"""Action-only SFT encoding, exact candidate scoring and conservative cost accounting."""

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_CEILING
import json
import math
import os
from pathlib import Path
import tempfile


MODEL = "Qwen/Qwen3.5-4B"
ACTIONS = ("DO_NOTHING", "RETRAIN_LARGE", "RETRAIN_HEAD_ONLY")
SYMBOLS = ("A", "B", "C")
LEGEND = ("\nDecision code map: A=DO_NOTHING; B=RETRAIN_LARGE; C=RETRAIN_HEAD_ONLY. "
          "Return the code in the action field.")
SKELETON = '{"action":"decision"}'


def _decimal(value):
    try:
        result = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError("Invalid cost") from None
    if not result.is_finite() or result < 0:
        raise ValueError("Cost must be finite and nonnegative")
    return result


def _money(value):
    return format(_decimal(value).quantize(Decimal("0.01"), rounding=ROUND_CEILING), ".2f")


def _integer(value, name, minimum=0):
    if type(value) is not int or value < minimum:
        raise ValueError(f"Invalid {name}")
    return value


def write_json(path, value, *, exclusive=False):
    """Write JSON atomically; exclusive artifacts are never replaced."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(value, ensure_ascii=False, allow_nan=False, sort_keys=True, indent=2) + "\n"
    if exclusive:
        with path.open("x", encoding="utf-8", newline="\n") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        return
    descriptor, temporary = tempfile.mkstemp(prefix=path.name + ".", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


@dataclass
class ActionDatum:
    model_input: list
    target_tokens: list
    weights: list
    marker_index: int
    input_token_count: int
    action: str | None
    input_ids: list | None = None
    rendered_prompt: str = ""
    marker_token_id: int = -1
    target_token_id: int | None = None

    def __post_init__(self):
        n = len(self.model_input)
        if (not n or len(self.target_tokens) != n or len(self.weights) != n or
                self.input_token_count != n or not 1 <= self.marker_index <= n or
                any(type(i) is not int or i < 0 for i in self.model_input + self.target_tokens) or
                any(type(w) not in (int, float) or not math.isfinite(w) or w not in (0, 1)
                    for w in self.weights) or sum(self.weights) != 1 or
                self.weights[self.marker_index - 1] != 1):
            raise ValueError("Invalid sparse action supervision")


@dataclass(frozen=True)
class CandidatePrompt:
    action: str
    token_id: int
    token_index: int
    input_ids: list


@dataclass(frozen=True)
class CandidateScores:
    actions: tuple
    logprobs: tuple
    probabilities: tuple
    action: str


def _visible_messages(record):
    messages = record.get("messages")
    if (not isinstance(messages, list) or len(messages) != 2 or
            [m.get("role") for m in messages if isinstance(m, dict)] != ["system", "user"] or
            any(set(m) != {"role", "content"} or not isinstance(m["content"], str)
                for m in messages)):
        raise ValueError("Expected only visible system/user messages")
    return [{"role": "system", "content": messages[0]["content"] + LEGEND},
            dict(messages[1])]


def encode_decision(record, tokenizer, *, max_seq_len=512, include_target=True):
    """Locate the assistant value by character offsets, never by global marker search."""
    symbol_ids = [tokenizer.encode(symbol, add_special_tokens=False) for symbol in SYMBOLS]
    marker_ids = tokenizer.encode("decision", add_special_tokens=False)
    if (any(len(ids) != 1 for ids in symbol_ids) or len(marker_ids) != 1 or
            len({ids[0] for ids in symbol_ids}) != 3):
        raise ValueError("Action symbols and marker must each be a single token")
    messages = _visible_messages(record)
    rendered = tokenizer.apply_chat_template(
        messages + [{"role": "assistant", "content": SKELETON}],
        tokenize=False, add_generation_prompt=False, enable_thinking=False)
    prefix = tokenizer.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True, enable_thinking=False)
    if not isinstance(rendered, str) or not rendered.startswith(prefix):
        raise ValueError("Assistant template prefix is inconsistent")
    assistant = rendered[len(prefix):]
    offset = assistant.find(SKELETON)
    if offset < 0 or assistant.count(SKELETON) != 1:
        raise ValueError("Assistant decision skeleton missing or ambiguous")
    character_start = len(prefix) + offset + SKELETON.index("decision")
    character_end = character_start + len("decision")
    tokenized = tokenizer(rendered, add_special_tokens=False, return_offsets_mapping=True)
    ids = list(tokenized["input_ids"])
    if not 2 <= len(ids) <= max_seq_len:
        raise ValueError("Decision sequence exceeds the sequence length limit")
    positions = [index for index, span in enumerate(tokenized["offset_mapping"])
                 if tuple(span) == (character_start, character_end)]
    if len(positions) != 1 or ids[positions[0]] != marker_ids[0]:
        raise ValueError("Assistant decision marker must be one exact token")
    marker_index = positions[0]
    if not 0 < marker_index < len(ids) - 1:
        raise ValueError("Marker has no valid causal supervision position")
    action = record.get("target_action") if include_target else None
    if include_target and action not in ACTIONS:
        raise ValueError("Unknown target action")
    target = symbol_ids[ACTIONS.index(action)][0] if include_target else marker_ids[0]
    targets, weights = ids[1:], [0.0] * (len(ids) - 1)
    targets[marker_index - 1] = target
    weights[marker_index - 1] = 1.0
    return ActionDatum(ids[:-1], targets, weights, marker_index, len(ids) - 1, action,
                       ids, rendered, marker_ids[0], target)


def candidate_prompt(record, action, tokenizer):
    if action not in ACTIONS:
        raise ValueError("Unknown candidate action")
    encoded = encode_decision(record, tokenizer, include_target=False)
    token_id = tokenizer.encode(SYMBOLS[ACTIONS.index(action)], add_special_tokens=False)[0]
    ids = list(encoded.input_ids)
    ids[encoded.marker_index] = token_id
    return CandidatePrompt(action, token_id, encoded.marker_index, ids)


def score_candidate_logprobs(prompts, responses):
    values = []
    if len(prompts) != len(responses):
        raise ValueError("Missing candidate logprob responses")
    for prompt, response in zip(prompts, responses):
        def get(name):
            return response.get(name) if isinstance(response, dict) else getattr(response, name, None)
        logs = get("prompt_logprobs")
        if (get("input_tokens") != len(prompt.input_ids) or type(get("output_tokens")) is not int or
                not 0 <= get("output_tokens") <= 1 or not isinstance(logs, list) or
                len(logs) != len(prompt.input_ids) or prompt.input_ids[prompt.token_index] != prompt.token_id):
            raise ValueError("Missing or misaligned candidate logprob / usage")
        value = logs[prompt.token_index]
        if type(value) not in (int, float) or not math.isfinite(value) or value > 0:
            raise ValueError("Missing or nonfinite candidate logprob")
        values.append(float(value))
    if tuple(p.action for p in prompts) != ACTIONS:
        raise ValueError("Incomplete candidate logprob set")
    prefixes = [p.input_ids[:p.token_index] for p in prompts]
    if not all(prefix == prefixes[0] for prefix in prefixes):
        raise ValueError("Candidate logprob prefixes differ")
    exps = [math.exp(value - max(values)) for value in values]
    probabilities = tuple(value / sum(exps) for value in exps)
    return CandidateScores(ACTIONS, tuple(values), probabilities,
                           ACTIONS[max(range(3), key=lambda i: probabilities[i])])


@dataclass(frozen=True)
class PlanEstimate:
    train_reserved_cny: str
    eval_reserved_cny: str
    total_reserved_cny: str
    unallocated_cny: str


class BudgetLedger:
    """Single-owner durable exposure ledger. Even settled reservations stay occupied."""

    def __init__(self, path, *, total_cny="10.00"):
        self.path = Path(path)
        total = _money(total_cny)
        if self.path.exists():
            self.data = json.loads(self.path.read_text(encoding="utf-8"))
            if (self.data.get("total_cny") != total or self.data.get("version") != 1 or
                    not isinstance(self.data.get("requests"), dict)):
                raise ValueError("Invalid existing budget ledger")
            for request in self.data["requests"].values():
                if request.get("state") not in ("reserved", "settled", "unknown"):
                    raise ValueError("Invalid budget request state")
                _decimal(request["reserved_cny"])
            if _decimal(self.reserved_cny) > _decimal(total):
                raise ValueError("Existing budget ledger exceeds total")
        else:
            self.data = {"version": 1, "total_cny": total, "requests": {}, "stopped": False}
            write_json(self.path, self.data, exclusive=True)

    @staticmethod
    def fen_per_million_to_cny(value):
        return _money(_decimal(value) / 100)

    @staticmethod
    def rounded_request_cost(inputs, outputs, input_price, output_price):
        _integer(inputs, "input tokens")
        _integer(outputs, "output tokens")
        cost = (_decimal(_money(Decimal(inputs) * _decimal(input_price) / 1_000_000)) +
                _decimal(_money(Decimal(outputs) * _decimal(output_price) / 1_000_000)))
        return _money(cost)

    @staticmethod
    def estimate_plan(*, train_rows, epochs, batch_size, max_seq_len, eval_rows, candidates):
        for value in (train_rows, epochs, batch_size, max_seq_len, eval_rows, candidates):
            _integer(value, "plan count", 1)
        train = Decimal(0)
        for offset in range(0, train_rows, batch_size):
            tokens = min(batch_size, train_rows - offset) * (max_seq_len - 1)
            train += _decimal(BudgetLedger.rounded_request_cost(tokens, 0, "4.54", "0"))
        train *= epochs
        evaluation = eval_rows * candidates * 2 * _decimal(
            BudgetLedger.rounded_request_cost(max_seq_len, 1, "1.49", "4.54"))
        if train + evaluation > Decimal(10):
            raise ValueError("Full plan exceeds budget")
        return PlanEstimate(_money(train), _money(evaluation), _money(train + evaluation),
                            _money(Decimal(10) - train - evaluation))

    @property
    def reserved_cny(self):
        return _money(sum((_decimal(row["reserved_cny"]) for row in self.data["requests"].values()),
                          Decimal(0)))

    @property
    def available_cny(self):
        return _money(_decimal(self.data["total_cny"]) - _decimal(self.reserved_cny))

    def reserve(self, request_id, amount_cny, *, purpose, **metadata):
        if request_id in self.data["requests"]:
            raise ValueError("Request already reserved")
        if self.data["stopped"]:
            raise ValueError("budget ledger stopped")
        if _decimal(amount_cny) > _decimal(self.available_cny):
            raise ValueError("Request exceeds budget")
        self.data["requests"][request_id] = {
            "state": "reserved", "reserved_cny": _money(amount_cny), "purpose": purpose,
            "metadata": metadata,
        }
        write_json(self.path, self.data)

    def mark_unknown(self, request_id, *, reason):
        self.data["requests"][request_id].update(state="unknown", reason=reason)
        self.data["stopped"] = True
        write_json(self.path, self.data)

    def settle(self, request_id, *, input_tokens, output_tokens, input_price, output_price,
               usage_source="provider", **details):
        row = self.data["requests"][request_id]
        if row["state"] != "reserved":
            raise ValueError("Request cannot be settled twice or after unknown usage")
        amount = self.rounded_request_cost(input_tokens, output_tokens, input_price, output_price)
        row.update(state="settled", input_tokens=input_tokens, output_tokens=output_tokens,
                   rounded_cost_estimate_cny=amount, usage_source=usage_source, details=details)
        if _decimal(amount) > _decimal(row["reserved_cny"]):
            self.data["stopped"] = True
        write_json(self.path, self.data)
        if self.data["stopped"]:
            raise ValueError("Provider usage exceeded budget reservation")
