"""One-shot, pinned NumPy bootstrap of a NEW public-training-only surrogate.

This worker never loads a checkpoint. It independently reconstructs the frozen
source/fold plan before importing the supplied baseline Model and flatten code.
"""

import hashlib
import json
import os
from pathlib import Path
import sys
import time


def initialize(request):
    import numpy as np
    if np.__version__ != "1.26.4":
        raise ValueError("Cross-fit bootstrap requires NumPy 1.26.4")
    from ite.official_sft_crossfit import load_public_training_source, make_crossfit_folds
    from ite.official_model import OFFICIAL_PROFILES
    profile = request["profile"]
    data = load_public_training_source(profile, request["package"])
    if (request["package_sha256"] != data["package_sha256"] or
            request["train_sha256"] != data["train_sha256"]):
        raise ValueError("Bootstrap package/train hash mismatch")
    fold = request["fold"]
    expected = next((f for f in make_crossfit_folds(profile, data)
                     if f["fold_id"] == fold.get("fold_id")), None)
    if expected is None or fold != expected:
        raise ValueError("Bootstrap indices/exclusion metadata differ from frozen fold plan")
    indices = fold["initialization_indices"]
    if not indices or len(set(indices)) != len(indices) or indices != sorted(indices):
        raise ValueError("Initialization indices must be unique and preserve source order")
    held_ids = {data["ids"][i] for i in fold["replay_indices"] + fold["purge_indices"]}
    used_ids = [data["ids"][i] for i in indices]
    if set(used_ids) & held_ids or (profile != "A" and
            {data["groups"][i] for i in indices} & set(fold["excluded_groups"])):
        raise ValueError("Initialization leaks excluded IDs/groups")
    sys.path.insert(0, data["package"])
    from baselines.data import flatten
    from baselines.model import Model
    rows = [data["rows"][i] for i in indices]
    flattened = [flatten(row["inputs"]) for row in rows]
    paths = flattened[0][0]
    if any(p != paths for p, _ in flattened):
        raise ValueError("Official feature schema changed")
    x = np.asarray([values for _, values in flattened], dtype=np.float64)
    classes = OFFICIAL_PROFILES[profile]["classes"]
    y = np.asarray([classes.index(row["answer"]) if profile == "A" else row["answer"]
                    for row in rows], dtype=np.int64 if profile == "A" else np.float64)
    config = data["training_report"]["configuration"]
    epochs = 20 if profile == "A" else 15
    model = Model(data["task"], paths, classes, x, y, hidden=config["hidden"],
        seed=data["training_report"]["seed"], learning_rate=config["learning_rate"],
        batch_size=config["batch_size"])
    model.meta["profile"] = profile
    if profile == "B":
        model.meta["target_unit"] = "minutes"
    started = time.perf_counter()
    model.fit(x, y, epochs)
    training_seconds = time.perf_counter() - started
    output = Path(request["checkpoint_output"])
    model.save(output)
    return {"status": "ok", "model_kind": "cross_fit_surrogate", "profile": profile,
        "fold_id": fold["fold_id"], "numpy_version": np.__version__,
        "python_version": sys.version.split()[0], "training_seconds": training_seconds,
        "epochs": model.meta["epochs"], "steps": model.meta["steps"],
        "hidden": model.meta["hidden"], "seed": model.meta["seed"],
        "learning_rate": model.meta["learning_rate"], "batch_size": model.meta["batch_size"],
        "target_mean": model.meta["target_mean"], "target_scale": model.meta["target_scale"],
        "loss_scale": 1. if profile == "A" else max(float(y.var()), 1e-12),
        "mean": model.mean.tolist(), "scale": model.scale.tolist(),
        "used_rows": len(indices), "used_ids": used_ids,
        "used_ids_sha256": hashlib.sha256(json.dumps(used_ids, separators=(",", ":")).encode()).hexdigest(),
        "used_groups": sorted({data["groups"][i] for i in indices}),
        "excluded_groups": fold["excluded_groups"],
        "missing_initial_classes": [c for i, c in enumerate(classes) if i not in set(y.tolist())],
        "checkpoint_sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
        "package_sha256": data["package_sha256"], "train_sha256": data["train_sha256"],
        "official_acceptance": False}


def main():
    for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                "NUMEXPR_NUM_THREADS", "BASELINE_CPU_THREADS"):
        os.environ[key] = "1"
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    try:
        raw = sys.stdin.buffer.read(32 * 1024 * 1024 + 1)
        if len(raw) > 32 * 1024 * 1024:
            raise ValueError("Bootstrap request exceeds size limit")
        report = initialize(json.loads(raw))
        sys.stdout.write(json.dumps(report, allow_nan=False))
    except Exception as error:
        sys.stderr.write(f"{type(error).__name__}: {error}\n")
        raise SystemExit(2)


if __name__ == "__main__":
    main()
