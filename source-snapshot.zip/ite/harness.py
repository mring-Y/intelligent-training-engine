"""Offline Harness contracts; only a validated action can leave this boundary.

The published schemas describe the wire format. Runtime validation uses only
the standard library and adds chronological, task and finite-number checks.
No client receives labels, models, simulator state or an execution capability.
"""

import json
import math
from copy import deepcopy
from abc import ABC, abstractmethod
from dataclasses import dataclass


ACTIONS = ("DO_NOTHING", "RETRAIN_SMALL", "RETRAIN_LARGE", "ROLLBACK")
OBSERVATION_SCHEMA = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "title": "HarnessObservationV1", "type": "object", "additionalProperties": False,
    "required": ["loss_trend", "drift_alarm", "remaining_label_budget",
                 "remaining_token_budget", "model_age_batches"],
    "properties": {
        "loss_trend": {"type": "array", "maxItems": 5, "items": {
            "type": "object", "additionalProperties": False,
            "required": ["source_step", "loss", "labeled_samples"],
            "properties": {"source_step": {"type": "integer", "minimum": 0},
                           "loss": {"type": "number", "minimum": 0},
                           "labeled_samples": {"type": "integer", "minimum": 1}}}},
        "drift_alarm": {"type": "boolean"},
        "remaining_label_budget": {"type": "integer", "minimum": 0},
        "remaining_token_budget": {"type": "integer", "minimum": 0},
        "model_age_batches": {"type": "integer", "minimum": 0}}}
ACTION_SCHEMA = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "title": "HarnessActionV1", "type": "object", "additionalProperties": False,
    "required": ["action", "reason"],
    "properties": {"action": {"type": "string", "enum": list(ACTIONS)},
                   "reason": {"type": "string", "minLength": 1, "maxLength": 160,
                              "pattern": r"^[^\r\n]*\S[^\r\n]*$"}}}

OFFICIAL_ACTION_SCHEMA = deepcopy(ACTION_SCHEMA)
OFFICIAL_ACTION_SCHEMA["title"] = "HarnessOfficialFinetuneActionV1"
OFFICIAL_ACTION_SCHEMA["properties"]["action"]["enum"].append("RETRAIN_HEAD_ONLY")
OFFICIAL_C_CALIBRATION_ACTION_SCHEMA = deepcopy(OFFICIAL_ACTION_SCHEMA)
OFFICIAL_C_CALIBRATION_ACTION_SCHEMA["title"] = "HarnessOfficialCCalibrationActionV1"
OFFICIAL_C_CALIBRATION_ACTION_SCHEMA["properties"]["action"]["enum"].append("CALIBRATE_DOWN")


def action_schema(action_profile="default"):
    if action_profile not in ("default", "official_finetune", "official_c_calibration"):
        raise ValueError("Unsupported action profile")
    if action_profile == "official_c_calibration":
        return OFFICIAL_C_CALIBRATION_ACTION_SCHEMA
    return OFFICIAL_ACTION_SCHEMA if action_profile == "official_finetune" else ACTION_SCHEMA


# V1 remains available for historical finite-quota consumers. V2 uses null
# explicitly for protocol-provided labels; zero still means an exhausted quota.
OBSERVATION_SCHEMA_V1 = deepcopy(OBSERVATION_SCHEMA)
OBSERVATION_SCHEMA["title"] = "HarnessObservationV2"
OBSERVATION_SCHEMA["properties"]["remaining_label_budget"]["type"] = ["integer", "null"]
OBSERVATION_SCHEMA["properties"].update({
    "overestimate_rate": {"type": "number", "minimum": 0, "maximum": 1},
    "mean_overestimate": {"type": "number", "minimum": 0}})
OBSERVATION_SCHEMA["dependentRequired"] = {
    "overestimate_rate": ["mean_overestimate"], "mean_overestimate": ["overestimate_rate"]}


def validate_observation(value, *, task=None):
    required, risk = set(OBSERVATION_SCHEMA["required"]), {"overestimate_rate", "mean_overestimate"}
    if (not isinstance(value, dict) or not required.issubset(value) or
            set(value) not in (required, required | risk)):
        raise ValueError("Observation must contain the public fields and an optional complete C risk pair")
    if type(value["drift_alarm"]) is not bool:
        raise ValueError("drift_alarm must be a boolean")
    if risk.issubset(value):
        rate, magnitude = value["overestimate_rate"], value["mean_overestimate"]
        if (task not in (None, "regression") or any(type(number) not in (int, float) or not math.isfinite(number)
                                        for number in (rate, magnitude)) or not 0 <= rate <= 1 or magnitude < 0):
            raise ValueError("C overestimation evidence must be a finite regression risk pair")
    for name in ("remaining_label_budget", "remaining_token_budget", "model_age_batches"):
        if name == "remaining_label_budget" and value[name] is None:
            continue
        if type(value[name]) is not int or value[name] < 0:
            raise ValueError(f"{name} must be a nonnegative integer")
    trend = value["loss_trend"]
    if not isinstance(trend, list) or len(trend) > 5:
        raise ValueError("loss_trend must be a list of at most five source batches")
    previous_step = -1
    for item in trend:
        if not isinstance(item, dict) or set(item) != {"source_step", "loss", "labeled_samples"}:
            raise ValueError("Invalid loss trend fields")
        source, count, loss = item["source_step"], item["labeled_samples"], item["loss"]
        if type(source) is not int or source <= previous_step or source < 0:
            raise ValueError("Loss sources must be nonnegative and strictly increasing")
        if type(count) is not int or count < 1:
            raise ValueError("Loss evidence needs a positive sample count")
        try:
            valid_loss = (type(loss) in (int, float) and math.isfinite(loss) and loss >= 0)
        except OverflowError:
            valid_loss = False
        if not valid_loss or (task == "classification" and loss > 1):
            raise ValueError("Loss must be finite, nonnegative and valid for the task")
        previous_step = source


@dataclass(frozen=True)
class Action:
    action: str
    reason: str


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON field")
        result[key] = value
    return result


def _reject_constant(value):
    raise ValueError("Nonfinite JSON constant")


def parse_action(raw_json, *, action_profile="default"):
    actions = action_schema(action_profile)["properties"]["action"]["enum"]
    if not isinstance(raw_json, str):
        raise ValueError("Action must be raw JSON text")
    try:
        if len(raw_json.encode("utf-8")) > 4096:
            raise ValueError("Action exceeds the response byte limit")
        value = json.loads(raw_json, object_pairs_hook=_unique_object, parse_constant=_reject_constant)
    except (UnicodeError, RecursionError) as error:
        raise ValueError("Invalid JSON response") from error
    if not isinstance(value, dict) or set(value) != {"action", "reason"}:
        raise ValueError("Action must contain exactly action and reason")
    action, reason = value["action"], value["reason"]
    if not isinstance(action, str) or action not in actions:
        raise ValueError("Action is outside the whitelist")
    if (not isinstance(reason, str) or not reason.strip() or len(reason) > 160 or
            "\r" in reason or "\n" in reason):
        raise ValueError("reason must be one nonblank line of at most 160 characters")
    try:
        reason.encode("utf-8")
    except UnicodeError as error:
        raise ValueError("reason must contain valid Unicode") from error
    return Action(action, reason)


def parse_action_with_repair(raw_json, *, action_profile="default"):
    """Try strict JSON first, then make one bounded outer-text extraction."""
    try:
        return parse_action(raw_json, action_profile=action_profile), False
    except ValueError as strict_error:
        if not isinstance(raw_json, str):
            raise
        try:
            if len(raw_json.encode("utf-8")) > 4096:
                raise strict_error
        except UnicodeError:
            raise strict_error
        start, end = raw_json.find("{"), raw_json.rfind("}")
        if start < 0 or end < start or (start == 0 and end == len(raw_json) - 1):
            raise strict_error
        # Exactly one substring is considered; it must still pass the full strict parser.
        return parse_action(raw_json[start:end + 1], action_profile=action_profile), True


@dataclass(frozen=True)
class LLMReply:
    raw_json: str
    usage_tokens: int
    token_accounting_mode: str = "mock"
    input_tokens: int | None = None
    output_tokens: int | None = None
    stop_reason: str | None = None


class TokenBudgetExceeded(RuntimeError):
    """Client reports a depleted provider quota; the reservation is still charged."""


class BaseLLMClient(ABC):
    @abstractmethod
    def get_decision(self, observation):
        """Return LLMReply. An adapter must bound/cancel its own blocking calls."""


class MockLLMClient(BaseLLMClient):
    """Deterministic local client with explicit, reproducible fault injection."""

    def __init__(self, mode="normal", *, model_type="ridge", profile_type=None):
        if mode not in ("normal", "token_exhausted", "invalid_json", "head_only", "calibrate_down"):
            raise ValueError("Unsupported mock Harness mode")
        if model_type not in ("ridge", "tree", "official", "official_mlp"):
            raise ValueError("Unsupported prediction model type")
        if profile_type not in (None, "A", "B", "C"):
            raise ValueError("Unsupported official profile type")
        if mode == "head_only" and model_type not in ("official", "official_mlp"):
            raise ValueError("Frozen-head Mock is restricted to official MLP")
        if mode == "calibrate_down" and (model_type not in ("official", "official_mlp") or profile_type != "C"):
            raise ValueError("Calibration Mock is restricted to official C")
        self.mode = mode
        self.model_type = model_type
        self.profile_type = profile_type

    def get_decision(self, observation):
        validate_observation(observation)
        if self.mode == "token_exhausted":
            raise TokenBudgetExceeded("Mock provider quota exhausted")
        if self.mode == "invalid_json":
            return LLMReply('{"action":', 8)
        action = "RETRAIN_SMALL" if observation["drift_alarm"] else "DO_NOTHING"
        if self.mode == "head_only" and observation["drift_alarm"]:
            action = "RETRAIN_HEAD_ONLY"
        if self.mode == "calibrate_down" and observation["drift_alarm"]:
            action = "CALIBRATE_DOWN"
        reason = "Observed degradation; request bounded training." if observation["drift_alarm"] else "No observed degradation."
        return LLMReply(json.dumps({"action": action, "reason": reason}), 8)
