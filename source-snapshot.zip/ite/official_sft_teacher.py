"""Single-session, fail-closed Teacher proposals for the approved official pilot."""

import hashlib
import json
from pathlib import Path
import sys
import subprocess
import time

from .harness import parse_action
from .llm_ledger import CallLedger
from .trio_client import TrioLLMClient, build_messages


MODEL = "Qwen/Qwen3.8-27B"
# Official /api/model-prices, checked 2026-11-12 (prices are in fen).
INPUT_PRICE, OUTPUT_PRICE = "3.15", "25.29"
LIMITS = {"max_calls": 30, "max_input_tokens": 1250, "max_output_tokens": 128,
          "max_total_tokens": 60000, "max_cost_cny": "0.50"}
ROOT = Path(__file__).resolve().parents[1]


def verify_teacher_runtime(python):
    python = Path(python).resolve()
    config = python.parent.parent / "pyvenv.cfg"
    if python == Path(sys.executable).resolve() or not python.is_file() or not config.is_file():
        raise ValueError("Teacher must run in a separate Python virtual environment")
    options = dict(line.split("=", 1) for line in config.read_text(encoding="utf-8").splitlines() if "=" in line)
    system_site = next((value.strip().lower() for key, value in options.items()
                        if key.strip() == "include-system-site-packages"), None)
    if system_site != "false":
        raise ValueError("Teacher virtual environment must disable system site packages")
    command = ("import json,importlib.metadata as m,numpy,pytrio,transformers,tokenizers,httpx; "
        "print(json.dumps({name:m.version(name) for name in "
        "['numpy','pytrio','transformers','tokenizers','httpx']}))")
    process = subprocess.run([str(python), "-X", "utf8", "-c", command], capture_output=True,
                             encoding="utf-8", timeout=15)
    expected = {"numpy": "2.3.5", "pytrio": "0.2.9", "transformers": "5.22.2",
                "tokenizers": "0.23.3", "httpx": "0.28.1"}
    if process.returncode or json.loads(process.stdout) != expected:
        raise ValueError("Isolated Teacher dependencies do not match the pinned versions")
    return {"python": str(python), "system_site_packages": False, "versions": expected}


def verify_teacher_tokenizer():
    manifest = json.loads((ROOT / "deployment/tokenizer-manifest.json").read_text(encoding="utf-8"))
    directory = ROOT / "deployment/tokenizer"
    if manifest.get("model") != MODEL:
        raise ValueError("Teacher tokenizer model mismatch")
    for entry in manifest["files"]:
        path = directory / entry["name"]
        if (Path(entry["name"]).name != entry["name"] or path.is_symlink() or
                path.stat().st_size != entry["bytes"] or
                hashlib.sha256(path.read_bytes()).hexdigest() != entry["sha256"]):
            raise ValueError("Teacher tokenizer digest mismatch")
    return manifest


class TeacherSession:
    def __init__(self, output_dir, *, client_factory=None, input_counter=None, runtime_python=None):
        self.output = Path(output_dir)
        self.output.mkdir(parents=True, exist_ok=True)
        if (self.output / "teacher-events.jsonl").exists() or (self.output / "call-ledger.json").exists():
            raise FileExistsError("Teacher evidence is single-use")
        (self.output / "teacher-events.jsonl").touch(exist_ok=False)
        self.ledger = CallLedger(self.output / "call-ledger.json", identity="official-sft-27b-20261112-v1")
        self.ledger.snapshot()
        self._factory = client_factory or self._client
        self._counter = input_counter or self._count
        self._tokenizer = None
        self.runtime_python = runtime_python or sys.executable

    def _client(self, context):
        return TrioLLMClient(model=MODEL, max_input_tokens=1250, max_output_tokens=128,
            timeout_seconds=15, model_type="official_mlp", prompt_profile="official_sft",
            official_context=context, tokenizer_path=str(ROOT / "deployment/tokenizer"),
            input_price_per_million=INPUT_PRICE, output_price_per_million=OUTPUT_PRICE,
            worker_command=[self.runtime_python, "-X", "utf8", "-m", "ite.trio_worker"])

    def _count(self, messages):
        if self._tokenizer is None:
            verify_teacher_tokenizer()
            from transformers import AutoTokenizer
            self._tokenizer = AutoTokenizer.from_pretrained(str(ROOT / "deployment/tokenizer"),
                local_files_only=True, trust_remote_code=False)
        prompt = self._tokenizer.apply_chat_template(messages, add_generation_prompt=True,
            tokenize=False, enable_thinking=False)
        return len(self._tokenizer.encode(prompt, add_special_tokens=False))

    def remaining_tokens(self):
        state = self.ledger.snapshot()
        return max(0, 60000 - state["used_tokens"] - state["reserved_tokens"])

    def decide(self, context):
        if self.ledger.snapshot()["trip_reason"]:
            return None
        observation = dict(context["observation"], remaining_token_budget=self.remaining_tokens())
        context["observation"] = observation
        visible = {key: context[key] for key in ("profile", "remaining_train_seconds", "feature_distance")}
        messages = build_messages(observation, model_type="official_mlp", prompt_profile="official_sft",
                                  official_context=visible)
        try:
            counted = self._counter(messages)
            if type(counted) is not int or not 0 < counted <= 1250:
                raise ValueError("input_token_limit")
        except Exception:
            self.ledger.trip("tokenizer_preflight_failed")
            return None
        reservation = self.ledger.reserve(**LIMITS, input_price_per_million=INPUT_PRICE,
            output_price_per_million=OUTPUT_PRICE, step=context["step"], model=MODEL)
        if reservation is None:
            return None
        record = {"call_id": reservation["call_id"], "profile": context["profile"], "step": context["step"],
            "split": context["split"], "scenario": context["scenario"], "messages": messages,
            "local_input_tokens": counted, "raw_response": None, "parsed_action": None,
            "input_tokens": None, "output_tokens": None, "status": "unknown", **reservation}
        started = time.perf_counter()
        proposal = None
        try:
            reply = self._factory(visible).get_decision(observation)
            record.update(raw_response=reply.raw_json, input_tokens=reply.input_tokens,
                          output_tokens=reply.output_tokens, finish_reason=reply.stop_reason)
            settled = self.ledger.settle(reservation["call_id"], input_tokens=reply.input_tokens,
                                         output_tokens=reply.output_tokens)
            if settled["trip_reason"] or reply.token_accounting_mode != "real":
                raise ValueError("provider_usage_exceeds_reservation")
            if reply.stop_reason != "stop":
                raise ValueError("incomplete_response")
            action = parse_action(reply.raw_json)
            record.update(status="ok", parsed_action={"action": action.action, "reason": action.reason})
            proposal = {"action": action.action, "reason": action.reason, "messages": messages,
                        "source": "teacher", "call_id": reservation["call_id"]}
        except Exception as error:
            code = "client_timeout" if isinstance(error, TimeoutError) else (
                "invalid_action" if isinstance(error, ValueError) else "provider_request_failed")
            if record["input_tokens"] is None:
                self.ledger.mark_unknown(reservation["call_id"], code)
            else:
                self.ledger.trip(code)
            record["status"] = code
        finally:
            record["latency_seconds"] = time.perf_counter() - started
            with (self.output / "teacher-events.jsonl").open("a", encoding="utf-8", newline="\n") as stream:
                stream.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n")
        return proposal
