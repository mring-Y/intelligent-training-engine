"""Complete C input-adapter artifacts with actual frozen official MLP bytes."""

import base64
import hashlib
import io
import json
from pathlib import Path
import subprocess
import time
import zipfile

import numpy as np

from .input_adapter import InputAdapter,POLICY,SHAPES
from .c_rbf_model import npz_bytes,LIMIT

FORMAT="ite.c-mlp-input-adapter.v1"
FIELDS={"metadata","mlp_checkpoint"}|{prefix+k for prefix in ("adapter_","adapter_first_","adapter_second_") for k in SHAPES}


def is_input_adapter(raw):
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as z:return "adapter_down.npy" in z.namelist()
    except zipfile.BadZipFile as error:raise ValueError("invalid input adapter checkpoint archive") from error


def unpack_checkpoint(raw):
    if not isinstance(raw,bytes) or not 1<=len(raw)<=LIMIT:raise ValueError("invalid input adapter checkpoint size")
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            entries=z.infolist()
            if len(entries)!=len(FIELDS) or {e.filename for e in entries}!={k+".npy" for k in FIELDS} or sum(e.file_size for e in entries)>LIMIT:
                raise ValueError("complete input adapter checkpoint fields are required")
        with np.load(io.BytesIO(raw),allow_pickle=False) as z:
            from .platform_data import json_value
            m=z["metadata"]
            if m.shape!=() or m.dtype.kind!="U":raise ValueError("invalid input adapter metadata")
            meta=json_value(str(m))
            if (not isinstance(meta,dict) or set(meta)!={"format","profile","policy","parent_checkpoint_sha256","mlp_sha256","optimizer"} or
                    meta["format"]!=FORMAT or meta["profile"]!="C" or meta["policy"]!=POLICY):
                raise ValueError("unsupported input adapter format or policy")
            for k in ("parent_checkpoint_sha256","mlp_sha256"):
                s=meta[k]
                if not isinstance(s,str) or len(s)!=64 or any(c not in "0123456789abcdef" for c in s):raise ValueError("invalid input adapter digest")
            core=z["mlp_checkpoint"]
            if core.ndim!=1 or core.dtype!=np.uint8 or not len(core):raise ValueError("missing original MLP bytes")
            core=core.tobytes()
            if hashlib.sha256(core).hexdigest()!=meta["mlp_sha256"]:raise ValueError("embedded MLP digest mismatch")
            with zipfile.ZipFile(io.BytesIO(core)) as inner:
                if len(inner.infolist())!=15 or "w1.npy" not in inner.namelist():raise ValueError("embedded MLP must be native")
            opt=meta["optimizer"]
            if not isinstance(opt,dict) or set(opt)!={"steps","epochs","seed","learning_rate","batch_size"}:raise ValueError("missing module optimizer metadata")
            module=InputAdapter(*({k:z[prefix+k] for k in SHAPES} for prefix in ("adapter_","adapter_first_","adapter_second_")),**opt)
        return core,module,meta
    except (zipfile.BadZipFile,KeyError,TypeError) as error:raise ValueError("invalid complete input adapter checkpoint") from error


def pack_checkpoint(core,module,parent_digest):
    module.validate()
    opt={k:getattr(module,k) for k in ("steps","epochs","seed","learning_rate","batch_size")}
    meta={"format":FORMAT,"profile":"C","policy":dict(POLICY),"parent_checkpoint_sha256":parent_digest,
          "mlp_sha256":hashlib.sha256(core).hexdigest(),"optimizer":opt}
    arrays={"metadata":np.array(json.dumps(meta,sort_keys=True,separators=(",",":"),allow_nan=False)),"mlp_checkpoint":np.frombuffer(core,dtype=np.uint8)}
    for prefix,group in (("adapter_",module.params),("adapter_first_",module.first),("adapter_second_",module.second)):
        arrays.update({prefix+k:v for k,v in group.items()})
    raw=npz_bytes(arrays);unpack_checkpoint(raw)
    return raw


class CInputAdapterModel:
    def __init__(self,mlp,module=None,*,parent_digest=None,checkpoint=None):
        from .official_model import OfficialModelAdapter
        if not isinstance(mlp,OfficialModelAdapter) or mlp.profile_type!="C" or mlp.safety_margin!=0 or (module is not None and not isinstance(module,InputAdapter)):
            raise ValueError("input adapter requires actual uncalibrated official C parent")
        self.mlp,self.module=mlp,module
        self.parent_digest=parent_digest or mlp.checkpoint_sha256
        self.checkpoint_bytes=checkpoint if checkpoint is not None else (mlp.checkpoint_bytes if module is None else pack_checkpoint(mlp.checkpoint_bytes,module,self.parent_digest))
        self.checkpoint_sha256=hashlib.sha256(self.checkpoint_bytes).hexdigest()
        self.parameter_count=833 if module is None else 1053

    def __getattr__(self,name):return getattr(self.mlp,name)

    def _invoke(self,operation,features,*,timeout=30.,deadline=None,**options):
        from .compact_rbf import matrix
        req={"operation":operation,"checkpoint":base64.b64encode(self.checkpoint_bytes).decode("ascii"),"features":matrix(features,24).tolist(),**options}
        cmd=[self.runtime_python,"-B","-X","utf8",str(Path(__file__).with_name("c_adapter_worker.py")),self.package_path]
        payload=json.dumps(req,allow_nan=False)
        if deadline is not None:
            timeout=min(timeout,deadline-time.perf_counter())
            if timeout<=0:raise TimeoutError("input adapter request preparation exceeded candidate deadline")
        try:result=subprocess.run(cmd,input=payload,text=True,encoding="utf8",capture_output=True,timeout=timeout)
        except subprocess.TimeoutExpired as error:raise TimeoutError("input adapter worker exceeded candidate deadline") from error
        if result.returncode:raise RuntimeError("input adapter worker failed: "+result.stderr[-1500:])
        response=json.loads(result.stdout)
        if response.get("ok") is not True:raise RuntimeError("invalid input adapter worker response")
        return response

    def predict(self,features):
        if self.module is None:return self.mlp.predict(features)
        values=np.asarray(self._invoke("predict",features)["predictions"],dtype=np.float64)
        if values.shape!=(len(features),) or not np.isfinite(values).all() or np.any(values<0):raise ValueError("invalid input adapter prediction")
        return values

    def save(self,path):
        with Path(path).open("xb") as f:f.write(self.checkpoint_bytes)

    @classmethod
    def from_bytes(cls,raw,runtime_python):
        from .official_model import OfficialModelAdapter
        core,module,meta=unpack_checkpoint(raw) if is_input_adapter(raw) else (raw,None,{"parent_checkpoint_sha256":hashlib.sha256(raw).hexdigest()})
        mlp=OfficialModelAdapter("regression",runtime_python,profile_type="C",checkpoint_bytes=core,candidate_epochs=2)
        return cls(mlp,module,parent_digest=meta["parent_checkpoint_sha256"],checkpoint=raw)

    @classmethod
    def load(cls,path,runtime_python):
        path=Path(path)
        if path.is_symlink() or not path.is_file() or not 1<=path.stat().st_size<=LIMIT:raise ValueError("input adapter checkpoint must be a bounded regular file")
        return cls.from_bytes(path.read_bytes(),runtime_python)


def fit_adapter_candidate(parent,features,targets,allowance,*,trainable_policy="head_only"):
    from .official_model import OfficialModelAdapter
    if isinstance(parent,OfficialModelAdapter):parent=CInputAdapterModel(parent)
    if not isinstance(parent,CInputAdapterModel) or trainable_policy!="head_only" or parent.candidate_epochs!=2 or not 0<float(allowance)<=5:
        raise ValueError("input adapter requires fixed two-epoch policy and original five-second allowance")
    started=time.perf_counter()
    response=parent._invoke("fit",features,timeout=allowance,deadline=started+allowance,
        targets=np.asarray(targets,dtype=float).tolist(),allowance=float(allowance))
    raw=base64.b64decode(response["checkpoint"],validate=True)
    core,module,meta=unpack_checkpoint(raw)
    if core!=parent.mlp.checkpoint_bytes or meta["parent_checkpoint_sha256"]!=parent.checkpoint_sha256:
        raise ValueError("candidate changed frozen backbone or actual parent binding")
    candidate=CInputAdapterModel(OfficialModelAdapter.from_state(parent.mlp.state()),module,
        parent_digest=meta["parent_checkpoint_sha256"],checkpoint=raw)
    elapsed=time.perf_counter()-started
    if elapsed>allowance:raise TimeoutError("input adapter candidate exceeded original allowance")
    candidate.last_fit_audit=response["fit_audit"]
    return candidate,elapsed
