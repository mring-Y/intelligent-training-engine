"""Bounded identity-initialized 24/4/24 adapter; backbone is never updated."""

import math
import time

import numpy as np

SHAPES={"down":(24,4),"down_bias":(4,),"up":(4,24),"up_bias":(24,)}
POLICY={"width":4,"parameters":220,"correction_bound":1.,"epochs":2,"loss":"standardized_mse",
        "backbone":"frozen_exact_bytes","optimizer":"separate_adam","gradient_clip":5.}


class InputAdapter:
    def __init__(self,params,first,second,*,steps=0,epochs=0,seed=42,learning_rate=.002,batch_size=256):
        self.params,self.first,self.second=({k:np.asarray(v).copy() for k,v in group.items()} for group in (params,first,second))
        self.steps,self.epochs,self.seed=steps,epochs,seed
        self.learning_rate,self.batch_size=learning_rate,batch_size
        self.validate()

    @classmethod
    def initial(cls,*,seed=42,learning_rate=.002,batch_size=256):
        p={k:np.zeros(shape,dtype=np.float64) for k,shape in SHAPES.items()}
        p["down"]=np.random.default_rng(seed).normal(0.,1./np.sqrt(24),(24,4))
        zeros={k:np.zeros_like(v) for k,v in p.items()}
        return cls(p,zeros,zeros,seed=seed,learning_rate=learning_rate,batch_size=batch_size)

    def validate(self):
        for group in (self.params,self.first,self.second):
            if set(group)!=set(SHAPES) or any(group[k].shape!=shape or group[k].dtype!=np.float64 or
                    not np.isfinite(group[k]).all() for k,shape in SHAPES.items()):
                raise ValueError("invalid input adapter tensors")
        if any(np.any(v<0) for v in self.second.values()):
            raise ValueError("invalid input adapter second moment")
        if (any(type(v) is not int or v<0 for v in (self.steps,self.epochs,self.seed)) or self.seed>=2**32 or
                type(self.batch_size) is not int or not 1<=self.batch_size<=65536 or
                isinstance(self.learning_rate,bool) or not math.isfinite(self.learning_rate) or self.learning_rate<=0):
            raise ValueError("invalid input adapter optimizer metadata")

    def _forward(self,z):
        z=np.asarray(z,dtype=np.float64)
        if z.ndim!=2 or z.shape[1]!=24 or not np.isfinite(z).all():
            raise ValueError("input adapter requires finite 24-dimensional normalized inputs")
        h=np.tanh(z@self.params["down"]+self.params["down_bias"])
        r=np.tanh(h@self.params["up"]+self.params["up_bias"])
        return z,h,r,z+r

    def transform(self,z):
        return np.clip(self._forward(z)[3],-10.,10.)

    def loss_and_gradients(self,z,targets,core):
        z,h,r,pre=self._forward(z)
        expected=np.asarray(targets,dtype=np.float64)
        if expected.shape!=(len(z),) or not len(z) or not np.isfinite(expected).all():
            raise ValueError("invalid input adapter targets")
        hidden=np.tanh(np.clip(pre,-10.,10.)@core["w1"]+core["b1"])
        error=(hidden@core["w2"]+core["b2"])[:,0]-expected
        dz=(((2*error/len(z))[:,None]@core["w2"].T)*(1-hidden**2))@core["w1"].T
        ds=dz*((pre>-10.)&(pre<10.))*(1-r**2)
        dh=(ds@self.params["up"].T)*(1-h**2)
        return float(np.mean(error**2)),{"up":h.T@ds,"up_bias":ds.sum(axis=0),
            "down":z.T@dh,"down_bias":dh.sum(axis=0)}

    def fit(self,z,targets,core,epochs=2,*,deadline=None):
        if type(epochs) is not int or not 1<=epochs<=20:
            raise ValueError("invalid input adapter epochs")
        losses=[]
        for _ in range(epochs):
            order=np.random.default_rng(np.random.SeedSequence([self.seed,self.epochs])).permutation(len(z))
            for start in range(0,len(order),self.batch_size):
                if deadline is not None and time.perf_counter()>=deadline:
                    raise TimeoutError("input adapter fit exceeded candidate allowance")
                idx=order[start:start+self.batch_size]
                loss,grads=self.loss_and_gradients(z[idx],targets[idx],core)
                norm=math.sqrt(sum(float(np.sum(g*g)) for g in grads.values()))
                if not math.isfinite(norm):raise ValueError("nonfinite input adapter gradient")
                self.steps+=1
                for k in SHAPES:
                    g=grads[k]*min(1.,5./max(norm,1e-12))
                    self.first[k]=.9*self.first[k]+.1*g
                    self.second[k]=.999*self.second[k]+.001*g*g
                    m=self.first[k]/(1-.9**self.steps);v=self.second[k]/(1-.999**self.steps)
                    self.params[k]-=self.learning_rate*m/(np.sqrt(v)+1e-8)
                self.validate();losses.append(loss)
            self.epochs+=1
        return losses
