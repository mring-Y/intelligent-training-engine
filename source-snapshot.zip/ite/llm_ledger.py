"""Locked, atomic and restart-safe accounting for bounded provider requests."""

import json
import os
import tempfile
from contextlib import contextmanager
from decimal import Decimal, InvalidOperation
from pathlib import Path


_MILLION = Decimal(1_000_000)
_CNY_QUANTUM = Decimal("0.00000001")


def _decimal(value, name):
    try:
        number = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise ValueError(f"{name} must be a finite nonnegative decimal") from None
    if not number.is_finite() or number < 0:
        raise ValueError(f"{name} must be a finite nonnegative decimal")
    return number


def _money(value):
    return format(value.quantize(_CNY_QUANTUM), "f")


class CallLedger:
    """Persist request reservations and provider-reported usage across restarts."""

    VERSION = 1

    def __init__(self, path, *, identity):
        self.path = Path(path)
        self.identity = identity
        self.lock_path = self.path.with_suffix(self.path.suffix + ".lock")
        self._owned_inflight = set()

    @contextmanager
    def _locked(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.lock_path.open("a+b") as lock_stream:
            lock_stream.seek(0, os.SEEK_END)
            if lock_stream.tell() == 0:
                lock_stream.write(b"\0")
                lock_stream.flush()
            lock_stream.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(lock_stream.fileno(), msvcrt.LK_LOCK, 1)
            else:
                import fcntl
                fcntl.flock(lock_stream.fileno(), fcntl.LOCK_EX)
            try:
                yield
            finally:
                if os.name == "nt":
                    msvcrt.locking(lock_stream.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    fcntl.flock(lock_stream.fileno(), fcntl.LOCK_UN)

    def _empty(self):
        return {"version": self.VERSION, "identity": self.identity, "attempted_calls": 0,
                "used_input_tokens": 0, "used_output_tokens": 0, "used_cost_cny": "0",
                "trip_reason": None, "requests": []}

    def _load(self):
        if not self.path.exists():
            return self._empty()
        try:
            state = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            raise RuntimeError("llm_ledger_unreadable") from None
        if (not isinstance(state, dict) or state.get("version") != self.VERSION or
                state.get("identity") != self.identity or not isinstance(state.get("requests"), list)):
            raise RuntimeError("llm_ledger_identity_mismatch")
        try:
            self._validate(state)
        except (ValueError, KeyError, TypeError, InvalidOperation):
            raise RuntimeError("llm_ledger_accounting_mismatch") from None
        return state

    def _validate(self, state):
        for key in ("attempted_calls", "used_input_tokens", "used_output_tokens"):
            if type(state[key]) is not int or state[key] < 0:
                raise ValueError("Invalid ledger count")
        if state["attempted_calls"] != len(state["requests"]):
            raise ValueError("Attempt count differs from durable requests")
        if state["trip_reason"] is not None and not isinstance(state["trip_reason"], str):
            raise ValueError("Invalid latch")
        inputs = outputs = 0
        total_cost = Decimal(0)
        for index, request in enumerate(state["requests"], 1):
            if request["call_id"] != index or request["status"] not in ("reserved", "settled"):
                raise ValueError("Invalid request sequence")
            if request.get("model") is not None and (not isinstance(request["model"], str)
                    or not request["model"].strip()):
                raise ValueError("Invalid request model")
            for key in ("max_input_tokens", "max_output_tokens", "reserved_input_tokens", "reserved_output_tokens"):
                if type(request[key]) is not int or request[key] < 0:
                    raise ValueError("Invalid request limits")
            in_price = _decimal(request["input_price_per_million"], "input price")
            out_price = _decimal(request["output_price_per_million"], "output price")
            reserved_cost = (request["reserved_input_tokens"] * in_price +
                             request["reserved_output_tokens"] * out_price) / _MILLION
            if _money(reserved_cost) != _money(_decimal(request["reserved_cost_cny"], "reserved cost")):
                raise ValueError("Invalid reservation cost")
            if request["status"] == "settled":
                for key in ("input_tokens", "output_tokens"):
                    if type(request[key]) is not int or request[key] < 0:
                        raise ValueError("Invalid provider usage")
                expected = (request["input_tokens"] * in_price + request["output_tokens"] * out_price) / _MILLION
                if _money(expected) != _money(_decimal(request["cost_cny"], "request cost")):
                    raise ValueError("Invalid settled cost")
                inputs += request["input_tokens"]
                outputs += request["output_tokens"]
                total_cost += _decimal(request["cost_cny"], "request cost")
        if (inputs != state["used_input_tokens"] or outputs != state["used_output_tokens"] or
                _money(total_cost) != _money(_decimal(state["used_cost_cny"], "used cost"))):
            raise ValueError("Ledger totals differ from request receipts")

    def _save(self, state):
        serialized = json.dumps(state, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
        temporary = None
        try:
            with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=self.path.parent,
                                             prefix=f".{self.path.name}.", suffix=".tmp", delete=False) as stream:
                temporary = Path(stream.name)
                stream.write(serialized)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.path)
        finally:
            if temporary is not None and temporary.exists():
                temporary.unlink()

    def _pending(self, state):
        return [item for item in state["requests"] if item["status"] == "reserved"]

    def _trip(self, state, reason):
        if state["trip_reason"] is None:
            state["trip_reason"] = reason

    def snapshot(self):
        with self._locked():
            state = self._load()
            pending = self._pending(state)
            if pending and state["trip_reason"] is None:
                for request in pending:
                    if request["call_id"] not in self._owned_inflight:
                        self._trip(state, "uncertain_inflight_call")
                        break
            self._save(state)
        reserved_inputs = sum(item["reserved_input_tokens"] for item in pending)
        reserved_outputs = sum(item["reserved_output_tokens"] for item in pending)
        reserved_cost = sum((_decimal(item["reserved_cost_cny"], "reserved cost") for item in pending), Decimal(0))
        used = state["used_input_tokens"] + state["used_output_tokens"]
        return {"attempted_calls": state["attempted_calls"],
                "used_input_tokens": state["used_input_tokens"],
                "used_output_tokens": state["used_output_tokens"], "used_tokens": used,
                "reserved_input_tokens": reserved_inputs, "reserved_output_tokens": reserved_outputs,
                "reserved_tokens": reserved_inputs + reserved_outputs,
                "reserved_cost_cny": _money(reserved_cost),
                "used_cost_cny": _money(_decimal(state["used_cost_cny"], "used cost")),
                "estimated_cost_cny": _money(_decimal(state["used_cost_cny"], "used cost") + reserved_cost),
                "unknown_calls": len(pending), "trip_reason": state["trip_reason"]}

    def trip(self, reason):
        with self._locked():
            state = self._load()
            self._trip(state, reason)
            self._save(state)
        return self.snapshot()

    def reserve(self, *, max_calls, max_input_tokens, max_output_tokens, max_total_tokens,
                max_cost_cny, input_price_per_million, output_price_per_million, step, model=None):
        values = (max_calls, max_input_tokens, max_output_tokens, max_total_tokens, step)
        if any(type(value) is not int or value < 0 for value in values) or max_calls < 1:
            raise ValueError("Call and token limits must be nonnegative integers")
        if model is not None and (not isinstance(model, str) or not model.strip()):
            raise ValueError("Request model must be a nonempty string")
        limit = _decimal(max_cost_cny, "max cost")
        in_price = _decimal(input_price_per_million, "input price")
        out_price = _decimal(output_price_per_million, "output price")
        reservation = ((Decimal(max_input_tokens) * in_price +
                        Decimal(max_output_tokens) * out_price) / _MILLION)
        with self._locked():
            state = self._load()
            if state["trip_reason"] is not None:
                return None
            pending = self._pending(state)
            if pending:
                self._trip(state, "concurrent_inflight_call")
                self._save(state)
                return None
            if state["attempted_calls"] >= max_calls:
                self._trip(state, "llm_call_limit")
                self._save(state)
                return None
            used_tokens = state["used_input_tokens"] + state["used_output_tokens"]
            if (used_tokens + max_input_tokens + max_output_tokens) * 5 >= max_total_tokens * 4:
                self._trip(state, "token_reservation_limit")
                self._save(state)
                return None
            total_cost = _decimal(state["used_cost_cny"], "used cost") + reservation
            if total_cost > limit:
                self._trip(state, "cost_reservation_limit")
                self._save(state)
                return None
            call_id = state["attempted_calls"] + 1
            state["attempted_calls"] = call_id
            state["requests"].append({"call_id": call_id, "step": step, "status": "reserved", "model": model,
                "max_input_tokens": max_input_tokens, "max_output_tokens": max_output_tokens,
                "input_price_per_million": str(in_price), "output_price_per_million": str(out_price),
                "reserved_input_tokens": max_input_tokens, "reserved_output_tokens": max_output_tokens,
                "reserved_cost_cny": _money(reservation), "input_tokens": None, "output_tokens": None,
                "cost_cny": None})
            self._owned_inflight.add(call_id)
            self._save(state)
            return {"call_id": call_id, "reserved_tokens": max_input_tokens + max_output_tokens,
                    "reserved_cost_cny": _money(reservation)}

    def settle(self, call_id, *, input_tokens, output_tokens):
        if any(type(value) is not int or value < 0 for value in (input_tokens, output_tokens)):
            raise ValueError("Provider usage must be nonnegative integers")
        with self._locked():
            state = self._load()
            request = next((item for item in state["requests"] if item["call_id"] == call_id), None)
            if request is None or request["status"] != "reserved":
                raise RuntimeError("llm_call_not_pending")
            cost = ((Decimal(input_tokens) * _decimal(request["input_price_per_million"], "input price") +
                     Decimal(output_tokens) * _decimal(request["output_price_per_million"], "output price")) / _MILLION)
            request.update(status="settled", input_tokens=input_tokens, output_tokens=output_tokens,
                           cost_cny=_money(cost))
            state["used_input_tokens"] += input_tokens
            state["used_output_tokens"] += output_tokens
            state["used_cost_cny"] = _money(_decimal(state["used_cost_cny"], "used cost") + cost)
            self._owned_inflight.discard(call_id)
            if input_tokens > request["max_input_tokens"] or output_tokens > request["max_output_tokens"]:
                self._trip(state, "provider_usage_exceeds_reservation")
            self._save(state)
        return self.snapshot()

    def mark_unknown(self, call_id, reason):
        with self._locked():
            state = self._load()
            request = next((item for item in state["requests"] if item["call_id"] == call_id), None)
            if request is None or request["status"] != "reserved":
                raise RuntimeError("llm_call_not_pending")
            request["failure_reason"] = reason
            self._trip(state, reason)
            self._owned_inflight.discard(call_id)
            self._save(state)
        return self.snapshot()
