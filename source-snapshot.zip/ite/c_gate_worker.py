"""Pinned gated-adapter inference and train-only input-domain fitting."""

import base64
import hashlib
import json
import os
from pathlib import Path
import sys
import time

for k in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):os.environ[k]="1"
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))


def load_model(raw,package):
    from ite.c_gate_model import is_gated,unpack_checkpoint
    from ite.c_stable_head import is_stable_checkpoint, unpack_stable_checkpoint
    from ite.c_adapter_worker import load_model as load_adapter
    drift, head, _ = unpack_stable_checkpoint(raw) if is_stable_checkpoint(raw) else (raw, None, None)
    raw = drift
    adapter,gate,meta=unpack_checkpoint(raw) if is_gated(raw) else (raw,None,{"gate_fits":0})
    model,module,core=load_adapter(adapter,package)
    if head is not None:
        head.validate_clock(model.meta["steps"], model.meta["epochs"], model.meta["batch_size"])
    return model,module,gate,core,meta,head,drift


def gated_forward(model, module, z, gate_weight):
    import numpy as np

    correction = module._forward(z)[2]
    hidden, logits = model.forward(np.clip(z + gate_weight * correction, -10, 10))
    value = max(0., float(logits[0, 0] * model.meta["target_scale"] + model.meta["target_mean"]))
    return hidden[0], value


def drift_forward(model, module, gate, row, z, weight):
    hidden, value = gated_forward(model, module, z, weight)
    if gate.operating_support is not None:
        parent_value = float(model.predict(row.reshape(1, -1))[0])
        value = gate.operating_support.apply(z[0, -3:], parent_value, value)
    elif gate.residual_calibration is not None and gate.residual_calibration.audit["positive_target_rows"]:
        parent_value = float(model.predict(row.reshape(1, -1))[0])
        value = gate.residual_calibration.apply(hidden, z[0, -3:], parent_value, value, model.meta["target_scale"])
    return hidden, value


def predict_values(model,module,gate,x,stable_head=None):
    import numpy as np
    from ite.c_adapter_worker import predict_values as adapter_predict
    if gate is None and stable_head is None:
        return adapter_predict(model,module,x)
    original_domain = stable_head.domain.contains(model.normalized(x)) if stable_head is not None else None
    predictions=[]
    for i, row in enumerate(x):
        z = model.normalized(row.reshape(1, -1))
        g = float(gate.values(z)[0]) if gate is not None else 0.
        if g==0.:
            value = (stable_head.predict(model, z) if original_domain is not None and original_domain[i]
                     else float(model.predict(row.reshape(1, -1))[0]))
            predictions.append(value)
            continue
        hidden, value = drift_forward(model, module, gate, row, z, g)
        if gate.low_rul_residual is not None:
            value = gate.low_rul_residual.apply(hidden, value, model.meta["target_scale"])
        predictions.append(value)
    return np.asarray(predictions,dtype=np.float64)


def fit_residual_calibration(model, module, gate, request):
    import numpy as np
    from ite.input_gate import matrix
    from ite.residual_calibration import ResidualCalibration, array_digest, correction_targets, design_matrix, validate_source

    if not isinstance(request, dict) or set(request) != {"x", "y", "source"}:
        raise ValueError("invalid residual calibration request")
    provenance = request["source"]
    validate_source(provenance)
    count = provenance["rows"]
    x = np.empty((0, 24)) if count == 0 and request["x"] == [] else matrix(request["x"])
    y = np.asarray(request["y"], dtype=np.float64)
    if (len(x) != count or y.shape != (count,) or not np.isfinite(y).all() or np.any(y < 0)
            or array_digest(x) != provenance["inputs_sha256"] or array_digest(y) != provenance["targets_sha256"]):
        raise ValueError("residual calibration arrays do not match the released source")
    hidden = np.empty((count, 32))
    settings = np.empty((count, 3))
    parent, adapted = np.empty(count), np.empty(count)
    for index, row in enumerate(x):
        raw = row.reshape(1, -1)
        z = model.normalized(raw)
        settings[index] = z[0, -3:]
        parent[index] = model.predict(raw)[0]
        weight = float(gate.values(z)[0])
        if weight > 0:
            hidden[index], adapted[index] = gated_forward(model, module, z, weight)
        else:
            hidden[index] = model.forward(z)[0][0]
            adapted[index] = parent[index]
    scale = model.meta["target_scale"]
    design = design_matrix(hidden, settings, np.maximum(adapted - parent, 0.) / scale)
    return ResidualCalibration.fit(design, correction_targets(parent, adapted, y, scale), provenance)


def fit_low_rul_residual(model, module, gate, x, z, y, source):
    import numpy as np
    from ite.c_low_rul_residual import LowRulResidual, WIDTH, validate_source
    from ite.residual_calibration import array_digest

    validate_source(source)
    calibration = gate.residual_calibration.audit
    if (source["rows"] != len(x) or source["source_step"] != calibration["gradient_source_step"]
            or source["train_sha256"] != calibration["train_sha256"]
            or source["inputs_sha256"] != array_digest(x) or source["targets_sha256"] != array_digest(y)):
        raise ValueError("low-RUL residual requires the actual released gradient rows")
    weights = gate.values(z)
    hidden = np.zeros((len(x), WIDTH - 1))
    predictions = np.zeros(len(x))
    for index in np.flatnonzero(weights > 0.):
        hidden[index], predictions[index] = drift_forward(
            model, module, gate, x[index], z[index:index + 1], float(weights[index]))
    return LowRulResidual.fit(hidden, predictions, y, weights, model.meta["target_scale"], source)


def fit_stable_head(model, previous, active_gate, source_sha256, request):
    import numpy as np
    from ite.c_stable_head import ROWS, StableDomain, StableHead, array_digest, validate_source
    from ite.input_gate import matrix
    from ite.official_finetune import fit_head_only

    if not isinstance(request, dict) or set(request) != {"x", "y", "ids", "source", "center", "whitening", "threshold"}:
        raise ValueError("invalid original-domain fit request")
    x = matrix(request["x"])
    y = np.asarray(request["y"], dtype=np.float64)
    ids = request["ids"]
    source = request["source"]
    validate_source(source)
    if (len(x) != ROWS or y.shape != (ROWS,) or not np.isfinite(y).all() or np.any(y < 0.)
            or not isinstance(ids, list) or len(ids) != ROWS or len(set(ids)) != ROWS
            or any(not isinstance(identity, str) for identity in ids)
            or hashlib.sha256("\n".join(ids).encode()).hexdigest() != source["ids_sha256"]
            or source["train_sha256"] != source_sha256
            or source["inputs_sha256"] != array_digest(x) or source["targets_sha256"] != array_digest(y)):
        raise ValueError("original-domain fit data differs from released source")
    domain = StableDomain(request["center"], request["whitening"], request["threshold"])
    if previous is not None and (domain.threshold != previous.domain.threshold
            or not np.array_equal(domain.center, previous.domain.center)
            or not np.array_equal(domain.whitening, previous.domain.whitening)):
        raise ValueError("original-domain fit attempted to change the selected distance state")
    z = model.normalized(x)
    if not domain.contains(z).all() or (active_gate is not None and np.any(active_gate.values(z))):
        raise ValueError("original-domain fit requires eligible training rows")
    if previous is not None:
        for name in ("params", "first", "second"):
            getattr(model, name).update({key: value.copy() for key, value in getattr(previous, name).items()})
        model.meta.update(steps=previous.steps, epochs=previous.epochs)
    before_steps, before_epochs = model.meta["steps"], model.meta["epochs"]
    fit_head_only(model, x, y, 2)
    snapshots = [{key: getattr(model, name)[key] for key in ("w2", "b2")} for name in ("params", "first", "second")]
    head = StableHead(domain, *snapshots, model.meta["steps"], model.meta["epochs"], source)
    return head, {"stable_parent_steps": before_steps, "stable_parent_epochs": before_epochs, "stable_head": head.audit}


def handle(request,package):
    import numpy as np
    from ite.input_adapter import InputAdapter
    from ite.input_gate import InputGate,matrix
    from ite.c_adapter_model import pack_checkpoint as pack_adapter
    from ite.c_gate_model import pack_checkpoint
    from ite.c_rbf_worker import peak_memory_bytes
    from ite.c_stable_head import SAMPLING_POLICY, pack_stable_checkpoint, screening_counts, screening_eligible
    from ite.operating_support import DIMENSIONS, OperatingSupport
    raw=base64.b64decode(request["checkpoint"],validate=True)
    model,module,active_gate,core,meta,stable_head,drift=load_model(raw,package)
    x=matrix(request["features"])
    if request["operation"]=="predict":
        return {"predictions":predict_values(model,module,active_gate,x,stable_head).tolist()}
    if request["operation"]!="fit":raise ValueError("unsupported gate operation")
    started=time.perf_counter();allowance=float(request["allowance"])
    if not 0<allowance<=5:raise ValueError("invalid gate allowance")
    y=np.asarray(request["targets"],dtype=np.float64)
    if y.shape!=(len(x),) or len(y)<2 or not np.isfinite(y).all() or np.any(y<0):raise ValueError("invalid module training targets")
    ref=request["reference"]
    groups=[set(ref[k]) for k in ("fit_groups","calibration_groups","current_groups")]
    if groups[0]&groups[1] or groups[0]&groups[2] or groups[1]&groups[2]:raise ValueError("gate engine sources must be disjoint")
    z=model.normalized(x)
    context=model.normalized(matrix(request["gate_features"])) if "gate_features" in request else z
    gate=InputGate.fit(model.normalized(matrix(ref["fit_x"])),context,model.normalized(matrix(ref["calibration_x"])))
    support_request = request.get("operating_support")
    residual_request = request.get("residual_calibration")
    if support_request is not None and residual_request is not None:
        raise ValueError("gated prediction variants are mutually exclusive")
    stable_request = request.get("stable_head")
    low_rul_source = request.get("low_rul_source")
    if low_rul_source is None and active_gate is not None and active_gate.low_rul_residual is not None:
        raise ValueError("the actual parent requires its low-RUL residual policy")
    if low_rul_source is not None and (stable_request is None or "sampling_audit" not in stable_request
            or residual_request is None):
        raise ValueError("low-RUL residual requires the balanced original-domain and NR-055 branches")
    allow_single_probe_hit = request.get("allow_single_probe_hit", False)
    if type(allow_single_probe_hit) is not bool or (allow_single_probe_hit and (
            request.get("stable_head_only") is not True or stable_request is None
            or "sampling_audit" not in stable_request)):
        raise ValueError("single probe hit allowance requires an early balanced original-domain fit")
    branch_audit = {}
    parent = hashlib.sha256(raw).hexdigest()
    balanced_sampling = False
    if stable_request is not None:
        expected_stable = {"screening_x", "eligible_rows", "fit"}
        if residual_request is None or set(stable_request) not in (expected_stable, expected_stable | {"sampling_audit"}):
            raise ValueError("original-domain training requires the NR-055 drift policy")
        screening = model.normalized(matrix(stable_request["screening_x"]))
        counts = screening_counts(screening, gate, active_gate)
        branch_audit = {"screening_gate_counts": counts, "stable_eligible_rows": stable_request["eligible_rows"]}
        balanced_sampling = "sampling_audit" in stable_request
        fit = stable_request["fit"]
        if balanced_sampling:
            sampling = stable_request["sampling_audit"]
            if (sampling["policy"] != SAMPLING_POLICY
                    or sampling["eligible_rows"] != stable_request["eligible_rows"]
                    or (fit is not None and (fit["source"]["ids_sha256"] != sampling["selected_ids_sha256"]
                        or fit["source"]["source_steps"] != sampling["selected_source_steps"]))):
                raise ValueError("original-domain sampling audit differs from its candidate window")
        if screening_eligible(counts, allow_single_probe_hit=allow_single_probe_hit) and fit is not None:
            head, head_audit = fit_stable_head(model, stable_head, active_gate, ref["source_sha256"], fit)
            checkpoint = pack_stable_checkpoint(drift, head, parent, balanced_sampling=balanced_sampling)
            if time.perf_counter() > started + allowance:
                raise TimeoutError("original-domain head exceeded candidate deadline")
            audit = {**branch_audit, **head_audit, "candidate_branch": "stable_head",
                     "trainable_policy": "original_domain_head_only", "trainable_parameters": 33,
                     "mlp_frozen_exact_bytes": True, "parent_mlp_sha256": hashlib.sha256(core).hexdigest(),
                     "parent_checkpoint_sha256": parent, "epochs_added": 2, "loss_policy": "squared",
                     "worker_peak_memory_bytes": peak_memory_bytes()}
            return {"checkpoint": base64.b64encode(checkpoint).decode("ascii"), "fit_audit": audit}
        if request.get("stable_head_only") is True:
            return {"stable_head_unavailable": branch_audit}
        branch_audit["candidate_branch"] = "drift_adapter"
    elif drift != raw:
        raise ValueError("original-domain parent requires its candidate policy")
    if module is None:
        module=InputAdapter.initial(**{k:model.meta[k] for k in ("seed","learning_rate","batch_size")})
    before_steps,before_epochs=module.steps,module.epochs
    losses=module.fit(z,(y-model.meta["target_mean"])/model.meta["target_scale"],model.params,2,deadline=started+allowance)
    if support_request is not None:
        support = OperatingSupport(z[:, -DIMENSIONS:], support_request["distance"],
                                   support_request["gradient_ids_sha256"], ref["source_sha256"])
        gate = InputGate(gate.weight, gate.threshold, gate.scale, operating_support=support)
    if residual_request is not None:
        calibration = fit_residual_calibration(model, module, gate, residual_request)
        gate = InputGate(gate.weight, gate.threshold, gate.scale, residual_calibration=calibration)
        if low_rul_source is not None:
            head = fit_low_rul_residual(model, module, gate, x, z, y, low_rul_source)
            gate = InputGate(gate.weight, gate.threshold, gate.scale, residual_calibration=calibration,
                             low_rul_residual=head)
    if time.perf_counter()>started+allowance:raise TimeoutError("gate fit exceeded deadline")
    audit={k:ref[k] for k in ("source_sha256","current_ids_sha256","current_groups","fit_ids","calibration_ids","fit_groups","calibration_groups")}
    audit.update(fit_rows=len(ref["fit_x"]),calibration_rows=len(ref["calibration_x"]),current_rows=len(context),
        calibration_nonzero_rate=float(np.mean(gate.values(model.normalized(matrix(ref["calibration_x"])))>0)),
        current_nonzero_rate=float(np.mean(gate.values(context)>0)),current_mean_weight=float(np.mean(gate.values(context))),uses_rul_targets=False)
    drift_parent = hashlib.sha256(drift).hexdigest()
    adapter=pack_adapter(core,module,drift_parent)
    checkpoint=pack_checkpoint(adapter,gate,drift_parent,meta["gate_fits"]+1,audit)
    if stable_request is not None:
        checkpoint = pack_stable_checkpoint(checkpoint, stable_head, parent, balanced_sampling=balanced_sampling)
    fit_audit={"trainable_policy":"input_adapter_with_domain_gate","trainable_parameters":220,"gate_numeric_state":26,
        "mlp_frozen_exact_bytes":True,"parent_mlp_sha256":hashlib.sha256(core).hexdigest(),"parent_checkpoint_sha256":parent,
        "parent_module_steps":before_steps,"candidate_module_steps":module.steps,"parent_module_epochs":before_epochs,"candidate_module_epochs":module.epochs,
        "gate_fits":meta["gate_fits"]+1,"gate_audit":audit,"learning_rate":module.learning_rate,"batch_size":module.batch_size,"epochs_added":2,
        "loss_policy":"squared","module_fit_ignores_gate":True,"mlp_steps":model.meta["steps"],"mlp_epochs":model.meta["epochs"],
        "first_batch_loss":losses[0],"last_batch_loss":losses[-1],"worker_peak_memory_bytes":peak_memory_bytes(),
        **branch_audit}
    if stable_request is not None:
        fit_audit.update(drift_parent_checkpoint_sha256=drift_parent, carried_stable_head=stable_head.audit if stable_head else None)
    if gate.operating_support is not None:
        fit_audit["operating_support"] = gate.operating_support.audit
    if gate.residual_calibration is not None:
        fit_audit["residual_calibration"] = gate.residual_calibration.audit
    if gate.low_rul_residual is not None:
        fit_audit["low_rul_residual"] = gate.low_rul_residual.audit
    return {"checkpoint":base64.b64encode(checkpoint).decode("ascii"),"fit_audit":fit_audit}


if __name__=="__main__":
    try:
        raw=sys.stdin.buffer.read(32*1024*1024+1)
        if len(raw)>32*1024*1024:raise ValueError("gate request too large")
        print(json.dumps({"ok":True,**handle(json.loads(raw),sys.argv[1])},allow_nan=False),flush=True)
    except Exception as error:
        print(f"{type(error).__name__}: {error}",file=sys.stderr);raise SystemExit(2)
