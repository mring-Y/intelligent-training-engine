"""Explicit resource accounting; prediction remains available after budgets expire."""

import math


class ResourceBudget:
    def __init__(self, config, *, model_type=None):
        self.config = config
        self.model_type = model_type or config.model_type
        self.train_seconds = 0.0
        self.experiments = self.labels = self.tokens = 0
        self.training_attempts = 0

    def training_allowance(self):
        available = self.config.max_train_seconds - self.train_seconds
        cap = (self.config.tree_timeout_seconds if self.model_type == "tree" else
               self.config.official_timeout_seconds if self.model_type in ("official", "official_mlp") else
               self.config.candidate_timeout_seconds)
        # Reserve worker startup and teardown overhead before spending training time.
        return max(0.0, min(cap,
                            available - self.config.candidate_startup_reserve_seconds))

    def start_experiment(self, needs_training=True):
        if self.experiments >= self.config.max_experiments or (needs_training and self.training_allowance() <= 0):
            return False
        self.experiments += 1
        self.training_attempts += int(needs_training)
        return True

    def charge_training(self, seconds):
        if not math.isfinite(seconds) or seconds < 0:
            raise ValueError("Training time must be finite and nonnegative")
        self.train_seconds += seconds

    def record_labels(self, count):
        if (isinstance(count, bool) or not isinstance(count, int) or count < 0 or
                (self.config.label_mode == "budgeted" and self.labels + count > self.config.max_labels)):
            raise ValueError("Label budget would be exceeded")
        self.labels += count

    @property
    def remaining_label_budget(self):
        return self.config.max_labels - self.labels if self.config.label_mode == "budgeted" else None

    def record_tokens(self, count):
        if isinstance(count, bool) or not isinstance(count, int) or count < 0 or self.tokens + count > self.config.max_tokens:
            raise ValueError("Token budget would be exceeded")
        self.tokens += count

    def snapshot(self):
        return {"adaptation_train_seconds": self.train_seconds, "experiments": self.experiments,
                "training_attempts": self.training_attempts,
                "labels_requested": self.labels, "tokens": self.tokens,
                "label_mode": self.config.label_mode, "label_budget_remaining": self.remaining_label_budget,
                "training_budget_remaining": max(0.0, self.config.max_train_seconds - self.train_seconds)}
