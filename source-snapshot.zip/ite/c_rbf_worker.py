"""C2 continuation and composite prediction under pinned NumPy 1.26.4."""

import base64
import hashlib
import io
import json
import os
from pathlib import Path
import sys
import time

for name in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[name] = "1"
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))


def load_model(raw, package):
    sys.path.insert(0,str(package))
    import numpy as np
    from baselines.model import Model
    from ite.c_rbf_model import is_composite, unpack_checkpoint
    from official_worker import _model, _validate_model, PROFILES
    core, module = (unpack_checkpoint(raw)[:2] if is_composite(raw) else (raw,None))
    model = _model(Path(package),core)
    _validate_model(model,"C",PROFILES["C"])
    if np.__version__ != "1.26.4":
        raise ValueError("compact model requires pinned NumPy 1.26.4")
    return model,module


def predict_values(model,module,x):
    import numpy as np
    base = np.asarray([model.predict(row.reshape(1,-1))[0] for row in x],dtype=np.float64)
    if module is None:
        return base
    z = model.normalized(x)
    correction = np.asarray([module.predict(row.reshape(1,-1))[0] for row in z])
    return np.maximum(0.,base+np.clip(.2*correction,-10.,10.))


def peak_memory_bytes():
    if os.name != "nt":
        import resource
        return int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)*1024
    import ctypes
    from ctypes import wintypes
    class Counters(ctypes.Structure):
        _fields_ = [("cb",wintypes.DWORD),("PageFaultCount",wintypes.DWORD)]+[(n,ctypes.c_size_t) for n in
            ("PeakWorkingSetSize","WorkingSetSize","QuotaPeakPagedPoolUsage","QuotaPagedPoolUsage",
             "QuotaPeakNonPagedPoolUsage","QuotaNonPagedPoolUsage","PagefileUsage","PeakPagefileUsage")]
    info = Counters()
    info.cb = ctypes.sizeof(info)
    kernel = ctypes.WinDLL("kernel32")
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    query = ctypes.WinDLL("psapi").GetProcessMemoryInfo
    query.argtypes = [wintypes.HANDLE,ctypes.POINTER(Counters),wintypes.DWORD]
    query.restype = wintypes.BOOL
    okay = query(kernel.GetCurrentProcess(),ctypes.byref(info),info.cb)
    return int(info.PeakWorkingSetSize) if okay else None


def handle(request,package):
    import numpy as np
    from ite.compact_rbf import CompactRBF, POLICY, matrix
    from ite.c_rbf_model import pack_checkpoint
    from ite.official_finetune import fit_with_audit
    raw = base64.b64decode(request["checkpoint"],validate=True)
    model,module = load_model(raw,package)
    x = matrix(request["features"],24)
    if request["operation"] == "predict":
        return {"predictions":predict_values(model,module,x).tolist()}
    if request["operation"] != "fit":
        raise ValueError("unknown compact worker operation")
    started = time.perf_counter()
    allowance = float(request["allowance"])
    if not 0 < allowance <= 5:
        raise ValueError("invalid compact training allowance")
    y = np.asarray(request["targets"],dtype=np.float64)
    if y.shape != (len(x),) or not np.isfinite(y).all() or np.any(y<0):
        raise ValueError("invalid C training labels")
    audit = fit_with_audit(model,x,y,2,"head_only")
    residual = y-predict_values(model,None,x)
    module = CompactRBF.fit(model.normalized(x),residual,deadline=started+allowance)
    import tempfile
    with tempfile.TemporaryDirectory(prefix="ite-rbf-fit-") as temporary:
        path = Path(temporary)/"mlp.npz"
        model.save(path)
        core = path.read_bytes()
    checkpoint = pack_checkpoint(core,module,hashlib.sha256(raw).hexdigest())
    audit.update(residual_policy=dict(POLICY),residual_training_rows=len(x),residual_centers=len(module.centers),
                 parent_checkpoint_sha256=hashlib.sha256(raw).hexdigest(),
                 residual_target="y_minus_resumed_mlp_prediction",worker_peak_memory_bytes=peak_memory_bytes(),
                 training_support_rate=float(np.mean(module.basis(model.normalized(x)).max(axis=1)>0)))
    return {"checkpoint":base64.b64encode(checkpoint).decode("ascii"),"fit_audit":audit}


if __name__ == "__main__":
    try:
        raw = sys.stdin.buffer.read(32*1024*1024+1)
        if len(raw)>32*1024*1024:
            raise ValueError("compact worker request too large")
        result = handle(json.loads(raw),sys.argv[1])
        print(json.dumps({"ok":True,**result},allow_nan=False),flush=True)
    except Exception as error:
        print(f"{type(error).__name__}: {error}",file=sys.stderr)
        raise SystemExit(2)
