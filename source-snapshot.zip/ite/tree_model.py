"""Bounded CART training with numeric-only, dependency-free checkpoint inference.

Only ``fit`` imports sklearn. Checkpoints never deserialize Python objects and
are checked for ZIP/NPY allocation bounds before NumPy opens their arrays.
"""

import ast
import numbers
import os
from pathlib import Path
import re
import tempfile
import zipfile
import zlib

import numpy as np

from .models import normalize_sample_weight


MAX_DEPTH = 16
MAX_NODES = 8191
MAX_LEAVES = 4096
MAX_FEATURES = 2048
MAX_CLASSES = 6
MAX_FILE_BYTES = 16 * 1024 * 1024
MAX_MEMBERS = 64
MAX_HEADER_BYTES = 4096
_FORMAT_VERSION = 1
_TREE_KIND = 1
_PARAMETERS = ("max_depth", "min_samples_leaf", "max_leaf_nodes", "random_state")
_ARRAYS = ("mean", "std", "children_left", "children_right", "feature", "threshold", "value")
_STATE_FIELDS = {"model_kind", "format_version", "task", "family", "allow_missing_classes",
                 "class_labels", *_PARAMETERS, *_ARRAYS}
_CHECKPOINT_FIELDS = {"tree_format", "tree_kind", "task_id", "allow_missing_classes",
                      "class_labels", *_PARAMETERS, *_ARRAYS}
_MEMBER_NAME = re.compile(r"[A-Za-z_][A-Za-z0-9_]{0,63}\.npy\Z")


def _bounded_integer(value, name, minimum, maximum):
    if (isinstance(value, (bool, np.bool_)) or not isinstance(value, numbers.Integral)
            or not minimum <= value <= maximum):
        raise ValueError(f"{name} must be an integer in [{minimum}, {maximum}]")
    return int(value)


def _read_exact(stream, size):
    value = stream.read(size)
    if len(value) != size:
        raise ValueError("Truncated NPY header or payload")
    return value


def _check_npy_member(stream, member_size, *, allow_text):
    magic = _read_exact(stream, 8)
    if magic[:6] != b"\x93NUMPY" or magic[6:] not in (b"\x01\x00", b"\x02\x00", b"\x03\x00"):
        raise ValueError("Unsupported NPY format")
    size_bytes = 2 if magic[6] == 1 else 4
    header_size = int.from_bytes(_read_exact(stream, size_bytes), "little")
    if not 1 <= header_size <= MAX_HEADER_BYTES:
        raise ValueError("NPY header exceeds the bounded parser limit")
    encoded = _read_exact(stream, header_size)
    if not encoded.endswith(b"\n"):
        raise ValueError("Invalid NPY header termination")
    header = ast.literal_eval(encoded.decode("utf8" if magic[6] == 3 else "latin1"))
    if (not isinstance(header, dict) or set(header) != {"descr", "shape", "fortran_order"}
            or header["fortran_order"] is not False):
        raise ValueError("NPY requires a canonical C-order array header")
    shape, descriptor = header["shape"], header["descr"]
    if (not isinstance(shape, tuple) or len(shape) > 4 or not isinstance(descriptor, str)
            or len(descriptor) > 128):
        raise ValueError("Invalid NPY dimensions or dtype descriptor")
    dtype = np.dtype(descriptor)
    if dtype.hasobject or dtype.fields is not None or dtype.subdtype is not None:
        raise ValueError("Object and structured checkpoint arrays are forbidden")
    numeric = dtype.kind in "iuf" and dtype.itemsize in (1, 2, 4, 8)
    text = allow_text and dtype.kind in "US" and 1 <= dtype.itemsize <= 4096
    if not numeric and not text:
        raise ValueError("Checkpoint arrays must have bounded numeric dtypes")
    count = 1
    for dimension in shape:
        dimension = _bounded_integer(dimension, "NPY dimension", 0, MAX_FILE_BYTES)
        count *= dimension
        if count > MAX_FILE_BYTES // dtype.itemsize:
            raise ValueError("NPY shape exceeds the allocation quota")
    payload_size = count * dtype.itemsize
    if 8 + size_bytes + header_size + payload_size != member_size:
        raise ValueError("NPY shape and dtype disagree with actual payload bytes")
    # Read through the CRC, with bounded temporary memory, before allowing np.load.
    remaining = payload_size
    while remaining:
        remaining -= len(_read_exact(stream, min(remaining, 65536)))
    if stream.read(1):
        raise ValueError("Unexpected trailing NPY payload bytes")


def _preflight_stream(stream, *, allowed_fields=None, allow_text=False):
    try:
        stream.seek(0, os.SEEK_END)
        size = stream.tell()
        stream.seek(0)
        if not 1 <= size <= MAX_FILE_BYTES:
            raise ValueError("Checkpoint file exceeds the 16 MiB quota or is empty")
        with zipfile.ZipFile(stream, "r") as archive:
            members = archive.infolist()
            if not 1 <= len(members) <= MAX_MEMBERS:
                raise ValueError("Checkpoint member count exceeds the quota")
            names = [member.filename for member in members]
            if len(set(names)) != len(names):
                raise ValueError("Duplicate ZIP checkpoint members")
            fields = set()
            compressed_total = uncompressed_total = 0
            for member in members:
                if (not _MEMBER_NAME.fullmatch(member.filename)
                        or member.flag_bits & 1
                        or member.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED)):
                    raise ValueError("Unsafe checkpoint member name, encryption or compression")
                name = member.filename[:-4]
                if allowed_fields is not None and name not in allowed_fields:
                    raise ValueError("Unknown checkpoint field")
                fields.add(name)
                compressed_total += member.compress_size
                uncompressed_total += member.file_size
                if (not 10 <= member.file_size <= MAX_FILE_BYTES
                        or not 0 <= member.compress_size <= MAX_FILE_BYTES
                        or compressed_total > MAX_FILE_BYTES or uncompressed_total > MAX_FILE_BYTES):
                    raise ValueError("Checkpoint compressed or expanded bytes exceed the quota")
                with archive.open(member, "r") as member_stream:
                    _check_npy_member(member_stream, member.file_size, allow_text=allow_text)
        return fields
    finally:
        try:
            stream.seek(0)
        except (AttributeError, OSError, ValueError):
            pass


def _is_binary_stream(source):
    return all(callable(getattr(source, name, None)) for name in ("read", "seek", "tell"))


def preflight_npz(path_or_stream, *, allowed_fields=None, allow_text=False):
    """Validate NPZ file/member/header/payload bounds and return its field names.

    ``allow_text`` supports bounded legacy Ridge metadata only. Tree archives
    always keep the default numeric-only policy.
    """
    try:
        if _is_binary_stream(path_or_stream):
            return _preflight_stream(path_or_stream, allowed_fields=allowed_fields,
                                     allow_text=allow_text)
        with Path(path_or_stream).open("rb") as stream:
            return _preflight_stream(stream, allowed_fields=allowed_fields, allow_text=allow_text)
    except (OSError, EOFError, SyntaxError, TypeError, OverflowError, UnicodeError,
            RecursionError, zipfile.BadZipFile, zlib.error, NotImplementedError) as error:
        raise ValueError("Malformed or unsupported checkpoint archive") from error


def _bounded_array(value, name, shape, *, integer=False):
    # Reject oversized/ragged Python containers before NumPy can allocate them.
    def check_container(item, remaining):
        if not remaining:
            if isinstance(item, (list, tuple, np.ndarray)):
                raise ValueError(f"Invalid {name} array rank")
            return
        if not isinstance(item, (list, tuple, np.ndarray)) or len(item) != remaining[0]:
            raise ValueError(f"Invalid {name} array dimensions")
        if isinstance(item, np.ndarray):
            if item.shape != remaining:
                raise ValueError(f"Invalid {name} array dimensions")
            return
        for child in item:
            check_container(child, remaining[1:])

    check_container(value, shape)
    array = np.asarray(value)
    if (array.shape != shape or array.dtype.kind not in ("iu" if integer else "iuf")
            or array.dtype.itemsize > 8 or not np.isfinite(array).all()):
        raise ValueError(f"Invalid {name} array dtype, dimensions or finite values")
    if integer:
        if np.any(array < -2) or np.any(array > max(MAX_FEATURES, MAX_NODES)):
            raise ValueError(f"{name} integer values exceed topology bounds")
    array = np.array(array, dtype=np.int64 if integer else np.float64, copy=True)
    array.setflags(write=False)
    return array


class TreeModel:
    """Single CART with explicit binary/six-class IDs and bounded numeric state."""

    model_type = "tree"
    family = "tree"

    def __init__(self, task="regression", *, max_depth=6, min_samples_leaf=5,
                 max_leaf_nodes=64, random_state=7, class_labels=None,
                 allow_missing_classes=False):
        if task not in ("regression", "classification"):
            raise ValueError("Unsupported tree task")
        self.task = task
        self.max_depth = _bounded_integer(max_depth, "max_depth", 1, MAX_DEPTH)
        self.min_samples_leaf = _bounded_integer(min_samples_leaf, "min_samples_leaf", 1, 1_000_000)
        self.max_leaf_nodes = _bounded_integer(max_leaf_nodes, "max_leaf_nodes", 2, MAX_LEAVES)
        self.random_state = _bounded_integer(random_state, "random_state", 0, 2**32 - 1)
        if not isinstance(allow_missing_classes, bool):
            raise ValueError("allow_missing_classes must be a boolean")
        self.allow_missing_classes = allow_missing_classes
        if task == "regression":
            if class_labels is not None:
                raise ValueError("Regression has no configured classes")
            self._classes = np.empty(0, dtype=np.int64)
        else:
            labels = (0, 1) if class_labels is None else class_labels
            if not isinstance(labels, (tuple, list, np.ndarray)) or len(labels) not in (2, 6):
                raise ValueError("Class IDs must be (0,1) or (1,2,3,4,5,6)")
            labels = np.asarray(labels)
            if (labels.dtype.kind not in "iu" or labels.ndim != 1
                    or not any(np.array_equal(labels, ids) for ids in ((0, 1), (1, 2, 3, 4, 5, 6)))):
                raise ValueError("Class IDs must be integer (0,1) or (1,2,3,4,5,6)")
            self._classes = np.array(labels, dtype=np.int64, copy=True)
        self._classes.setflags(write=False)

    @property
    def classes_(self):
        if self.task != "classification":
            raise ValueError("Regression has no class IDs")
        return self._classes.copy()

    def _require_fitted(self):
        if not hasattr(self, "_mean"):
            raise ValueError("TreeModel has not been fitted")

    @property
    def mean(self):
        self._require_fitted()
        return self._mean.copy()

    @property
    def std(self):
        self._require_fitted()
        return self._std.copy()

    @staticmethod
    def _features(features, feature_count=None):
        try:
            raw = np.asarray(features)
            if (raw.ndim != 2 or not 1 <= raw.shape[1] <= MAX_FEATURES
                    or raw.dtype.kind not in "iuf" or raw.dtype.itemsize > 8
                    or (feature_count is not None and raw.shape[1] != feature_count)
                    or not np.isfinite(raw).all()):
                raise ValueError("Features need matching finite numeric matrix dimensions")
            x = np.asarray(raw, dtype=np.float64)
            with np.errstate(over="ignore", invalid="ignore"):
                rounded = np.asarray(x, dtype=np.float32)
            if not np.isfinite(rounded).all():
                raise ValueError("Features overflow the native tree float32 input range")
            return x, rounded
        except (TypeError, OverflowError) as error:
            raise ValueError("Invalid numeric feature matrix") from error

    def fit(self, features, targets, sample_weight=None):
        x, rounded = self._features(features)
        y = np.asarray(targets)
        if (len(x) < 2 or y.shape != (len(x),) or y.dtype.kind not in "iuf"
                or not np.isfinite(y).all()):
            raise ValueError("Training needs at least two finite feature/target rows")
        weights = normalize_sample_weight(sample_weight, len(x))
        if self.task == "classification":
            if not np.isin(y, self._classes).all():
                raise ValueError("Training contains an unknown class ID")
            present = np.unique(y if weights is None else y[weights > 0])
            if not self.allow_missing_classes and not np.array_equal(present, self._classes):
                raise ValueError("Initial tree training must contain every configured class")
        # Native dependencies exist only at this bounded worker training boundary.
        from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
        estimator_class = DecisionTreeClassifier if self.task == "classification" else DecisionTreeRegressor
        estimator = estimator_class(**{name: getattr(self, name) for name in _PARAMETERS})
        estimator.fit(rounded, y, sample_weight=weights)
        if weights is None:
            mean, std = x.mean(axis=0), x.std(axis=0)
        else:
            mean = np.average(x, axis=0, weights=weights)
            std = np.sqrt(np.average((x - mean) ** 2, axis=0, weights=weights))
        std = np.where(std < 1e-10, 1., std)
        tree = estimator.tree_
        if self.task == "regression":
            values = tree.value[:, 0, :]
        else:
            values = np.zeros((tree.node_count, len(self._classes)), dtype=np.float64)
            for column, label in enumerate(estimator.classes_):
                values[:, np.flatnonzero(self._classes == label)[0]] = tree.value[:, 0, column]
        state = {"model_kind": "tree", "format_version": _FORMAT_VERSION, "task": self.task,
                 "family": "tree", "class_labels": self._classes,
                 "allow_missing_classes": self.allow_missing_classes,
                 **{name: getattr(self, name) for name in _PARAMETERS},
                 "mean": mean, "std": std, "children_left": tree.children_left,
                 "children_right": tree.children_right, "feature": tree.feature,
                 "threshold": tree.threshold, "value": values}
        restored = type(self).from_state(state)
        self.__dict__.update(restored.__dict__)
        return self

    def _leaf_indices(self, features):
        self._require_fitted()
        _, rounded = self._features(features, len(self._mean))
        nodes = np.zeros(len(rounded), dtype=np.int64)
        for _ in range(self.max_depth + 1):
            active = np.flatnonzero(self.children_left[nodes] != -1)
            if not len(active):
                return nodes
            current = nodes[active]
            go_left = rounded[active, self.feature[current]] <= self.threshold[current]
            nodes[active] = np.where(go_left, self.children_left[current], self.children_right[current])
        raise ValueError("Tree traversal exceeded validated depth")

    def predict(self, features):
        leaves = self._leaf_indices(features)
        values = self.value[leaves]
        return self._classes[np.argmax(values, axis=1)] if self.task == "classification" else values[:, 0]

    def predict_proba(self, features):
        if self.task != "classification":
            raise ValueError("Regression has no class probabilities")
        leaves = self._leaf_indices(features)
        return self.value[leaves].copy()

    def state(self):
        self._require_fitted()
        return {"model_kind": "tree", "format_version": _FORMAT_VERSION, "task": self.task,
                "family": "tree", "class_labels": self._classes.tolist(),
                "allow_missing_classes": self.allow_missing_classes,
                **{name: getattr(self, name) for name in _PARAMETERS},
                "mean": self._mean.tolist(), "std": self._std.tolist(),
                **{name: getattr(self, name).tolist() for name in _ARRAYS[2:]}}

    @classmethod
    def from_state(cls, state):
        try:
            if (not isinstance(state, dict) or set(state) != _STATE_FIELDS
                    or state["model_kind"] != "tree" or state["family"] != "tree"):
                raise ValueError("Unknown tree model identity or state fields")
            _bounded_integer(state["format_version"], "tree format", _FORMAT_VERSION, _FORMAT_VERSION)
            labels = state["class_labels"]
            if state["task"] == "regression":
                if not isinstance(labels, (tuple, list, np.ndarray)) or len(labels) != 0:
                    raise ValueError("Regression checkpoint must have no classes")
                labels = None
            model = cls(state["task"], **{name: state[name] for name in _PARAMETERS},
                        class_labels=labels, allow_missing_classes=state["allow_missing_classes"])
            features, nodes = len(state["mean"]), len(state["children_left"])
            if not 1 <= features <= MAX_FEATURES or not 1 <= nodes <= MAX_NODES:
                raise ValueError("Tree node or feature count exceeds resource bounds")
            model._mean = _bounded_array(state["mean"], "mean", (features,))
            model._std = _bounded_array(state["std"], "std", (features,))
            if np.any(model._std <= 0):
                raise ValueError("Tree monitoring scale must be positive")
            for name in ("children_left", "children_right", "feature"):
                setattr(model, name, _bounded_array(state[name], name, (nodes,), integer=True))
            model.threshold = _bounded_array(state["threshold"], "threshold", (nodes,))
            columns = len(model._classes) if model.task == "classification" else 1
            model.value = _bounded_array(state["value"], "value", (nodes, columns))
            model._validate_topology()
            if model.task == "classification":
                if (np.any(model.value < 0) or np.any(model.value > 1)
                        or not np.allclose(model.value.sum(axis=1), 1., rtol=0, atol=1e-12)
                        or (not model.allow_missing_classes and np.any(model.value[0] == 0))
                        or np.any(model.value[:, model.value[0] == 0] != 0)):
                    raise ValueError("Tree class probabilities or missing-class columns are invalid")
            return model
        except (KeyError, TypeError, OverflowError, IndexError) as error:
            raise ValueError("Malformed numeric tree state") from error

    def _validate_topology(self):
        count = len(self.children_left)
        parents = np.zeros(count, dtype=np.int64)
        for index, (left, right, feature, threshold) in enumerate(zip(
                self.children_left, self.children_right, self.feature, self.threshold)):
            if left == -1 and right == -1:
                if feature != -2 or threshold != -2.:
                    raise ValueError("Invalid tree leaf sentinels")
            else:
                if (not 0 <= left < count or not 0 <= right < count or left == right
                        or not 0 <= feature < len(self._mean)):
                    raise ValueError("Invalid tree child or split feature")
                parents[left] += 1
                parents[right] += 1
        if parents[0] != 0 or np.any(parents[1:] != 1):
            raise ValueError("Tree root, multiple parents or unreachable nodes are invalid")
        seen, leaves = set(), 0
        pending = [(0, 0)]
        while pending:
            index, depth = pending.pop()
            if index in seen or depth > self.max_depth:
                raise ValueError("Tree cycle or configured depth violation")
            seen.add(index)
            if self.children_left[index] == -1:
                leaves += 1
            else:
                pending.extend(((int(self.children_left[index]), depth + 1),
                                (int(self.children_right[index]), depth + 1)))
        if len(seen) != count or leaves > self.max_leaf_nodes or leaves > MAX_LEAVES:
            raise ValueError("Tree contains unreachable nodes or exceeds its leaf budget")

    def save(self, path):
        """Write numeric fields, fsync, then atomically replace the destination."""
        model = type(self).from_state(self.state())
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(mode="wb", dir=path.parent, prefix=f".{path.name}.",
                                             suffix=".tmp", delete=False) as stream:
                temporary = Path(stream.name)
                np.savez_compressed(stream, tree_format=np.int64(_FORMAT_VERSION),
                                    tree_kind=np.int64(_TREE_KIND),
                                    task_id=np.int64(model.task == "classification"),
                                    allow_missing_classes=np.int64(model.allow_missing_classes),
                                    class_labels=model._classes,
                                    **{name: np.int64(getattr(model, name)) for name in _PARAMETERS},
                                    mean=model._mean, std=model._std,
                                    **{name: getattr(model, name) for name in _ARRAYS[2:]})
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)

    @classmethod
    def _load_stream(cls, stream):
        fields = _preflight_stream(stream, allowed_fields=_CHECKPOINT_FIELDS)
        if fields != _CHECKPOINT_FIELDS:
            raise ValueError("Missing numeric tree checkpoint fields")
        with np.load(stream, allow_pickle=False, max_header_size=MAX_HEADER_BYTES) as archive:
            values = {name: archive[name].copy() for name in archive.files}
        scalars = {}
        for name in ("tree_format", "tree_kind", "task_id", "allow_missing_classes", *_PARAMETERS):
            value = values[name]
            if value.shape != () or value.dtype.kind not in "iu":
                raise ValueError("Tree checkpoint metadata must be integer scalars")
            scalars[name] = int(value.item())
        if (scalars["tree_format"] != _FORMAT_VERSION or scalars["tree_kind"] != _TREE_KIND
                or scalars["task_id"] not in (0, 1) or scalars["allow_missing_classes"] not in (0, 1)):
            raise ValueError("Unsupported tree checkpoint version, kind or task")
        return cls.from_state({"model_kind": "tree", "family": "tree",
                               "format_version": scalars["tree_format"],
                               "task": "classification" if scalars["task_id"] else "regression",
                               "allow_missing_classes": bool(scalars["allow_missing_classes"]),
                               **{name: scalars[name] for name in _PARAMETERS},
                               "class_labels": values["class_labels"],
                               **{name: values[name] for name in _ARRAYS}})

    @classmethod
    def load_stream(cls, stream):
        """Load from an already-open binary seekable stream without closing it."""
        if not _is_binary_stream(stream):
            raise ValueError("Tree checkpoint stream must provide binary read/seek/tell")
        try:
            return cls._load_stream(stream)
        except (OSError, EOFError, SyntaxError, TypeError, OverflowError, UnicodeError,
                RecursionError, zipfile.BadZipFile, zlib.error, NotImplementedError) as error:
            raise ValueError("Malformed or unsupported tree checkpoint") from error

    @classmethod
    def load(cls, path_or_stream):
        """Load a numeric checkpoint from a path or an already-open stream."""
        if _is_binary_stream(path_or_stream):
            return cls.load_stream(path_or_stream)
        try:
            # Check and load the same open file, retaining bounds across path replacement.
            with Path(path_or_stream).open("rb") as stream:
                return cls.load_stream(stream)
        except (OSError, EOFError, SyntaxError, TypeError, OverflowError, UnicodeError,
                RecursionError, zipfile.BadZipFile, zlib.error, NotImplementedError) as error:
            raise ValueError("Malformed or unsupported tree checkpoint") from error
