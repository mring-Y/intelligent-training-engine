"""Visible-loss host fallback. Returning an action never grants deployment."""

import json
import math
from pathlib import Path
import zipfile

import numpy as np

from .harness import Action, validate_observation


def choose_heuristic_action(action, observation, *, profile, remaining_train_seconds,
                            experiments_remaining, enabled=True):
    if action is None:
        return None
    validate_observation(observation)
    if (not enabled or action.action != "DO_NOTHING" or profile not in ("A", "C") or
            not observation["drift_alarm"] or experiments_remaining <= 0 or
            not math.isfinite(remaining_train_seconds) or remaining_train_seconds <= 0 or
            observation["remaining_token_budget"] <= 0 or observation["remaining_label_budget"] == 0):
        return action
    trend = observation["loss_trend"]
    if len(trend) < 3:
        return action
    first, second, latest = (item["loss"] for item in trend[-3:])
    if min(second, latest) <= first + max(.01, .1 * first):
        return action
    return Action("RETRAIN_REPLAY" if profile == "A" else "RETRAIN_HEAD_ONLY",
                  "规则兜底：漂移报警且连续两个已揭晓来源损失恶化；申请候选，仍须独立未来门控。")


def load_a_replay_reserve(model):
    from .official_sft_data import select_a_replay_reserve
    from .official_model import _validate_package
    package = Path(model.package_path)
    _validate_package(package, "A")
    # Only the approved historical training split is loaded, never validation.
    with zipfile.ZipFile(package) as archive:
        rows = [json.loads(line) for line in archive.read("public/train.jsonl").decode("utf-8").splitlines() if line]
    return select_a_replay_reserve(rows, [])


def replace_a_replay(features, targets, reserve):
    x, y = np.asarray(features), np.asarray(targets)
    rx, ry = np.asarray(reserve["x"]), np.asarray(reserve["y"])
    ids = reserve["ids"]
    if (x.ndim != 2 or len(x) < 48 or y.shape != (len(x),) or rx.shape != (48,x.shape[1]) or
            ry.shape != (48,) or len(ids) != 48 or len(set(ids)) != 48 or
            not all(np.isfinite(a).all() for a in (x,y,rx,ry)) or
            any(np.count_nonzero(ry == label) != 8 for label in range(1,7))):
        raise ValueError("A replay requires 48 distinct balanced historical rows and enough online training rows")
    return np.concatenate((rx,x[48:]),axis=0), np.concatenate((ry,y[48:]),axis=0)


def load_training_stream(profile, *, exclude_a_reserve=False):
    from .official_model import OFFICIAL_PROFILES, default_package_path, _validate_package
    from .official_sft_data import flatten_features, select_a_replay_reserve
    package=default_package_path(profile)
    _validate_package(package,profile)
    with zipfile.ZipFile(package) as archive:
        rows=[json.loads(s) for s in archive.read("public/train.jsonl").decode("utf-8").splitlines() if s]
    excluded=set(select_a_replay_reserve(rows,[])["ids"]) if profile=="A" and exclude_a_reserve else set()
    rows=[r for r in rows if r["id"] not in excluded]
    contract=OFFICIAL_PROFILES[profile]
    return {"x":np.asarray([flatten_features(r["inputs"])[0] for r in rows],dtype=float),
            "y":np.asarray([contract["classes"].index(r["answer"])+1 if profile=="A" else r["answer"] for r in rows]),
            "ids":[r["id"] for r in rows],"role":"official_public_train",
            "package_sha256":contract["sha256"],"excluded_a_reserve_ids":sorted(excluded)}
