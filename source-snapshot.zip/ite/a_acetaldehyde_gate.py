"""A frozen PCA margin correction carried with the complete official A checkpoint."""

import hashlib
import io
import json
import math
import time
import zipfile

import numpy as np

from .c_rbf_model import npz_bytes


FORMAT = "ite.a-acetaldehyde-gate.v1"
POLICY = "a_acetaldehyde_gate_v1"
LIMIT_BYTES = 16 * 1024 * 1024
SCREEN_CHECKPOINT_SHA256 = "17bd5a5f18cdd2c519a67687c010a776e36192b958a38d70f40264eafddf73bc"
ETHANOL, ACETALDEHYDE = 0, 3
INPUT_SHAPES = {
    "pca_center": (128,), "pca_basis": (128, 32),
    "input_center": (32,), "input_scale": (32,),
    "input_weights": (32, 6), "input_bias": (6,),
}


def input_state(arrays):
    state = {key: np.asarray(arrays[key], dtype=np.float64) for key in INPUT_SHAPES}
    for key, expected in INPUT_SHAPES.items():
        if state[key].shape != expected or not np.isfinite(state[key]).all():
            raise ValueError(f"Invalid A PCA state: {key}")
    if np.any(state["input_scale"] <= 0):
        raise ValueError("A PCA scale must be positive")
    return state


def _validate_threshold(threshold):
    if threshold is not None and (type(threshold) not in (int, float) or not math.isfinite(threshold)):
        raise ValueError("A correction threshold must be finite or disabled")


def pack_checkpoint(native, state, threshold):
    _validate_threshold(threshold)
    metadata = {"format": FORMAT, "profile": "A", "threshold": threshold,
                "parent_sha256": hashlib.sha256(native).hexdigest()}
    raw = npz_bytes({**input_state(state), "mlp_checkpoint": np.frombuffer(native, np.uint8),
                     "metadata": np.asarray(json.dumps(metadata, allow_nan=False, sort_keys=True))})
    if len(raw) > LIMIT_BYTES:
        raise ValueError("A combined checkpoint exceeds the checkpoint size limit")
    return raw


def is_acetaldehyde_checkpoint(raw):
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        return "pca_basis.npy" in archive.namelist()


def unpack_checkpoint(raw):
    fields = {*INPUT_SHAPES, "mlp_checkpoint", "metadata"}
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        if (len(raw) > LIMIT_BYTES or sorted(archive.namelist()) != sorted(key + ".npy" for key in fields) or
                sum(entry.file_size for entry in archive.infolist()) > LIMIT_BYTES):
            raise ValueError("Incomplete or oversized A correction checkpoint")
    with np.load(io.BytesIO(raw), allow_pickle=False) as archive:
        state = input_state(archive)
        native = archive["mlp_checkpoint"]
        if native.dtype != np.uint8 or native.ndim != 1:
            raise ValueError("Invalid embedded A MLP")
        native = native.tobytes()
        metadata = json.loads(archive["metadata"].item())
    if (not isinstance(metadata, dict) or set(metadata) != {"format", "profile", "parent_sha256", "threshold"} or
            metadata["format"] != FORMAT or metadata["profile"] != "A" or
            metadata["parent_sha256"] != hashlib.sha256(native).hexdigest()):
        raise ValueError("A correction checkpoint does not match its embedded MLP or format")
    _validate_threshold(metadata["threshold"])
    return native, state, metadata["threshold"]


def corrected_logits(normalized, logits, state):
    projected = (normalized - state["pca_center"]) @ state["pca_basis"]
    features = (projected - state["input_center"]) / state["input_scale"]
    return logits + (features @ state["input_weights"] + state["input_bias"])


def margin(logits):
    return logits[:, ACETALDEHYDE] - logits[:, ETHANOL]


def predict_scores(model, features, state, threshold):
    normalized = model.normalized(features)
    _, logits = model.forward(normalized)
    exp = np.exp(logits - logits.max(axis=1, keepdims=True))
    scores = exp / exp.sum(axis=1, keepdims=True)
    if threshold is not None:
        flips = (logits.argmax(axis=1) == ETHANOL) & (margin(corrected_logits(normalized, logits, state)) > threshold)
        ethanol = scores[flips, ETHANOL].copy()
        scores[flips, ETHANOL] = scores[flips, ACETALDEHYDE]
        scores[flips, ACETALDEHYDE] = ethanol
        tied = flips & (scores.argmax(axis=1) != ACETALDEHYDE)
        scores[tied, ACETALDEHYDE] = np.nextafter(scores[tied, ACETALDEHYDE], np.inf)
    return scores


def frozen_template(path):
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != SCREEN_CHECKPOINT_SHA256:
        raise ValueError("A continuation requires the frozen Batch 1 correction checkpoint")
    return raw


def continuation_trainer(template):
    """Fit the supplied MLP with the existing budget, then attach the frozen correction."""
    from .official_sft_replay import _bounded_fit

    native, state, threshold = unpack_checkpoint(template)
    with np.load(io.BytesIO(native), allow_pickle=False) as archive:
        mean, scale = archive["mean"], archive["scale"]
    if threshold is None:
        raise ValueError("The A correction template must contain an active threshold")

    def train(parent, features, labels, allowance, *, trainable_policy="full"):
        if (parent.profile != "A" or trainable_policy != "full" or
                not np.array_equal(parent.mean, mean) or not np.array_equal(parent.std, scale)):
            raise ValueError("A correction requires the same normalization and full Step 7 update")
        started = time.perf_counter()
        candidate, _ = _bounded_fit(parent, features, labels, allowance, trainable_policy=trainable_policy)
        if not is_acetaldehyde_checkpoint(candidate.checkpoint_bytes):
            candidate.checkpoint_bytes = pack_checkpoint(candidate.checkpoint_bytes, state, threshold)
            candidate.checkpoint_sha256 = hashlib.sha256(candidate.checkpoint_bytes).hexdigest()
        elapsed = time.perf_counter() - started
        if elapsed > allowance:
            raise TimeoutError("A Step 7 correction exhausted its training allowance")
        return candidate, elapsed

    return train
