"""Train-input-only domain gate with held-out source calibration."""

import math

import numpy as np

from .c_low_rul_residual import LowRulResidual
from .operating_support import OperatingSupport
from .residual_calibration import ResidualCalibration

POLICY={"kind":"pooled_covariance_domain_gate","ridge":.001,"source_quantile":.995,
        "reference_rows_per_engine":4,"calibration_engine_rule":"every_fifth_sorted",
        "minimum_fit_rows":64,"minimum_calibration_rows":32,"ramp_minimum_scale":1.}


def matrix(value):
    a=np.asarray(value,dtype=np.float64)
    if a.ndim!=2 or a.shape[1]!=24 or not np.isfinite(a).all():
        raise ValueError("gate requires finite 24-dimensional inputs")
    return a


class InputGate:
    def __init__(self,weight,threshold,scale,*,operating_support=None,residual_calibration=None,low_rul_residual=None):
        self.weight=np.asarray(weight,dtype=np.float64).copy()
        self.threshold,self.scale=float(threshold),float(scale)
        if (self.weight.shape!=(24,) or not np.isfinite(self.weight).all() or
                not math.isfinite(self.threshold) or not math.isfinite(self.scale) or self.scale<=0):
            raise ValueError("invalid input gate state")
        if operating_support is not None and not isinstance(operating_support, OperatingSupport):
            raise ValueError("invalid operating support")
        if residual_calibration is not None and (not isinstance(residual_calibration, ResidualCalibration)
                or operating_support is not None):
            raise ValueError("residual calibration requires its own gated model variant")
        self.operating_support = operating_support
        self.residual_calibration = residual_calibration
        if low_rul_residual is not None and (not isinstance(low_rul_residual, LowRulResidual)
                or residual_calibration is None):
            raise ValueError("low-RUL residual requires the calibrated drift branch")
        self.low_rul_residual = low_rul_residual

    def values(self,z):
        return np.clip((matrix(z)@self.weight-self.threshold)/self.scale,0.,1.)

    @classmethod
    def fit(cls,reference,current,calibration):
        a,b,c=(matrix(v) for v in (reference,current,calibration))
        if len(a)<64 or len(b)<2 or len(c)<32:raise ValueError("insufficient independent gate input capacity")
        ma,mb=a.mean(axis=0),b.mean(axis=0)
        da,db=a-ma,b-mb
        covariance=(da.T@da/len(a)+db.T@db/len(b))/2+np.eye(24)*.001
        w=np.linalg.solve(covariance,mb-ma)
        if float(np.linalg.norm(w))<1e-12:return cls(np.zeros(24),0.,1.)
        scores=np.sort(c@w)
        index=min(len(c)-1,math.ceil((len(c)+1)*.995)-1)
        threshold=max(float((ma+mb)@w/2),float(scores[index]))
        return cls(w,threshold,max(float(np.std(b@w)),1.))
