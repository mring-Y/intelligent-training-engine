"""One-shot PyTRiO HTTP transport; never writes credentials or response bodies on errors."""

import json
import sys
import time
from contextlib import redirect_stdout


class SafeWorkerError(RuntimeError):
    def __init__(self, code):
        super().__init__(code)
        self.code = code


def sample_chat(request, *, tokenizer_loader=None, http_client=None, token_provider=None):
    deadline = request.get("deadline_monotonic", time.monotonic() + 15)
    if tokenizer_loader is None:
        from pathlib import Path
        if request["model"] == "Qwen/Qwen3.5-4B":
            from .tokenizer_assets import verify_tokenizer_provenance
            try:
                verify_tokenizer_provenance(request["tokenizer_path"], request["model"])
            except (OSError, ValueError, KeyError, TypeError):
                raise SafeWorkerError("tokenizer_provenance") from None
        from transformers import AutoTokenizer
        tokenizer_path = Path(request["tokenizer_path"])
        tokenizer_loader = lambda model: AutoTokenizer.from_pretrained(
            str(tokenizer_path), local_files_only=True, trust_remote_code=False)
    if token_provider is None:
        from pytrio.config.config import auth_state
        token_provider = lambda: auth_state.api_key
    close_client = False
    try:
        tokenizer = tokenizer_loader(request["model"])
        # The public completion API accepts the fully rendered prompt. This
        # makes local preflight count the exact role template and turns thinking
        # off using the model's own template, without relying on server JSON mode.
        prompt = tokenizer.apply_chat_template(request["messages"], add_generation_prompt=True,
                                              tokenize=False, enable_thinking=False)
        input_tokens = len(tokenizer.encode(prompt, add_special_tokens=False))
        if input_tokens > request["max_input_tokens"]:
            raise SafeWorkerError("input_token_limit")
        token = token_provider()
        if not token:
            raise SafeWorkerError("pytrio_auth_unavailable")
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise SafeWorkerError("client_timeout")
        if http_client is None:
            import httpx
            transport = httpx.HTTPTransport(retries=0)
            http_client = httpx.Client(transport=transport,
                timeout=httpx.Timeout(min(15.0, remaining), connect=min(10.0, remaining)), trust_env=False)
            close_client = True
        response = http_client.post(
            "https://pytrio.com/api/openai/v1/completions",
            headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
            json={"model": request["model"], "prompt": prompt,
                  "max_tokens": request["max_output_tokens"], "temperature": 0, "top_p": 1,
                  "stream": False})
        if response.status_code < 200 or response.status_code >= 300:
            raise SafeWorkerError(f"http_status_{response.status_code}")
        body = response.json()
        choice = body["choices"][0]
        content = choice["text"]
        usage = body["usage"]
        input_usage = usage.get("prompt_tokens", usage.get("input_tokens"))
        output_usage = usage.get("completion_tokens", usage.get("output_tokens"))
        if (not isinstance(content, str) or type(input_usage) is not int or
                type(output_usage) is not int or input_usage < 0 or output_usage < 0):
            raise SafeWorkerError("invalid_provider_response")
        # Preserve even a provider-reported overage: the Guard records the
        # actual charge and latches before any action can execute.
        return {"content": content, "input_tokens": input_usage, "output_tokens": output_usage,
                "finish_reason": choice.get("finish_reason") or "unknown"}
    except SafeWorkerError:
        raise
    except Exception:
        raise SafeWorkerError("provider_request_failed") from None
    finally:
        if close_client:
            http_client.close()


def main():
    protocol = sys.stdout
    with redirect_stdout(sys.stderr):
        try:
            request = json.load(sys.stdin)
            result = sample_chat(request)
        except SafeWorkerError as error:
            result = {"error": error.code}
            print(json.dumps(result), file=protocol)
            return 2
        except Exception:
            print(json.dumps({"error": "worker_failed"}), file=protocol)
            return 2
    print(json.dumps(result, ensure_ascii=False, allow_nan=False), file=protocol)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
