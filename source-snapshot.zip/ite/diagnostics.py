"""Synthetic ground-truth diagnostics, called only after a policy has finished."""

import numpy as np


def drift_diagnostics(config, losses, detection_steps):
    """Delays include label latency; missed changes are reported separately.

    A gradual change is dated at its first changed batch. Covariate shifts
    and transient label corruption are not persistent concept changes.
    Cumulative loss is the sum of per-batch mean losses (not sample sums).
    """
    starts = []
    if config.scenario == "triple_abrupt" and config.drift_magnitude > 0:
        starts = [step for step in (2, 10, 18) if step < config.n_batches]
    elif config.scenario == "recurring" and config.drift_magnitude > 0:
        starts = list(range(config.drift_start, config.n_batches, config.drift_width))
    elif config.scenario in ("abrupt", "gradual", "mixed") and config.drift_magnitude > 0 and config.drift_start < config.n_batches:
        starts = [config.drift_start]
    detections = sorted(detection_steps)
    changes, delays, redundant = [], [], 0
    for start, end in zip(starts, [*starts[1:], config.n_batches]):
        alerts = [step for step in detections if start <= step < end]
        delay = alerts[0] - start if alerts else None
        if delay is not None:
            delays.append(delay)
        redundant += max(0, len(alerts) - 1)
        changes.append({"source_step": start, "end_step": end, "detection_delay_batches": delay,
                        "cumulative_loss": float(np.sum(losses[start:end]))})
    return {"drift_changes": len(starts), "missed_changes": len(starts) - len(delays),
            "mean_detection_delay_batches": float(np.mean(delays)) if delays else None,
            "false_alarms": sum(not starts or step < starts[0] for step in detections),
            "redundant_alerts": redundant,
            "post_drift_cumulative_loss": float(np.sum(losses[starts[0]:])) if starts else None,
            "changes": changes}
