"""Offline decision boundary; external adapters must enforce their own call timeout.

Only whitelisted candidate suggestions are accepted. Provider failure or invalid
usage conservatively charges the reserved allowance, then uses the local search.
This module contains no network client or official PyTRiO integration.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class Advice:
    windows: tuple
    alphas: tuple
    charged_tokens: int
    status: str
    reason: str


class LocalMockProvider:
    def propose(self, context, max_tokens):
        return {"windows": [min(context["allowed_windows"])],
                "alphas": list(context["allowed_alphas"]), "usage_tokens": min(8, max_tokens)}


class DecisionAdvisor:
    def __init__(self, provider=None):
        self.provider = provider

    def decide(self, windows, alphas, observed, remaining_tokens):
        windows, alphas = tuple(windows), tuple(alphas)
        if self.provider is None or remaining_tokens <= 0:
            return Advice(windows, alphas, 0, "rules", "provider_disabled_or_budget_exhausted")
        allowance = min(64, remaining_tokens)
        context = {"allowed_windows": list(windows), "allowed_alphas": list(alphas),
                   "observed": {key: observed.get(key) for key in
                                ("recent_loss", "feature_distance", "labeled_count", "latest_source_step")}}
        charged = allowance
        try:
            reply = self.provider.propose(context, max_tokens=allowance)
            if not isinstance(reply, dict) or set(reply) != {"windows", "alphas", "usage_tokens"}:
                raise ValueError("Malformed candidate advice")
            usage = reply["usage_tokens"]
            if isinstance(usage, bool) or not isinstance(usage, int) or not 0 <= usage <= allowance:
                raise ValueError("Invalid provider token usage")
            charged = usage
            for key, permitted in (("windows", windows), ("alphas", alphas)):
                values = reply[key]
                if not isinstance(values, list) or not values or any(
                        isinstance(value, bool) or value not in permitted for value in values):
                    raise ValueError("Candidate advice exceeds the permitted search space")
                if key == "windows" and any(not isinstance(value, int) for value in values):
                    raise ValueError("Window sizes must be integers")
            return Advice(tuple(dict.fromkeys(reply["windows"])), tuple(dict.fromkeys(reply["alphas"])),
                          charged, "advised", "validated_local_mock_or_adapter")
        except Exception as error:
            return Advice(windows, alphas, charged, "fallback", f"{type(error).__name__}: {error}")
