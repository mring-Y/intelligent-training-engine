"""Fixed six-class OVR bridge around the unchanged binary Ridge model."""

import os
import tempfile
from pathlib import Path

import numpy as np

from .models import RidgeModel


CLASS_LABELS = (1, 2, 3, 4, 5, 6)
_HEAD_ARRAYS = ("mean", "std", "weights", "intercept", "basis_mean")
_STATE_FIELDS = {"model_kind", "task", "family", "alpha", "classes", "heads"}
_CHECKPOINT_FIELDS = {"format_version", "model_kind", "classes", "alpha", *_HEAD_ARRAYS}


class OneVsRestRidge:
    task = "classification"
    family = "ovr_ridge"

    def __init__(self, alpha=1.0, classes=CLASS_LABELS, *, allow_missing_classes=False):
        values = np.asarray(classes)
        if values.dtype.kind not in "iu" or not np.array_equal(values, CLASS_LABELS):
            raise ValueError("One-vs-Rest classes must be the fixed integer IDs 1 through 6")
        if (isinstance(alpha, bool) or not isinstance(alpha, (int, float, np.integer, np.floating))
                or not np.isfinite(alpha) or alpha <= 0):
            raise ValueError("Alpha must be positive and finite")
        if not isinstance(allow_missing_classes, bool):
            raise ValueError("allow_missing_classes must be a boolean")
        self._classes = values.copy()
        self._classes.setflags(write=False)
        self.alpha = float(alpha)
        self.allow_missing_classes = allow_missing_classes

    @property
    def classes_(self):
        return self._classes.copy()

    @property
    def mean(self):
        return self.models[0].mean.copy()

    @property
    def std(self):
        return self.models[0].std.copy()

    def fit(self, features, targets, sample_weight=None):
        x, y = np.asarray(features, dtype=float), np.asarray(targets)
        if (x.ndim != 2 or x.shape[1] < 1 or len(x) < 2 or y.shape != (len(x),)
                or y.dtype.kind not in "iuf" or not np.isfinite(x).all()
                or not np.isfinite(y).all() or not np.isin(y, self._classes).all()):
            raise ValueError("Training needs finite features and matching known class IDs 1 through 6")
        if not self.allow_missing_classes and not np.array_equal(np.unique(y), self._classes):
            raise ValueError("Initial training must contain every configured class and no unknown class")
        # Always retain all six heads. An absent candidate class has a zero target,
        # using the same original numerical path and sample weights as every head.
        self.models = tuple(RidgeModel("classification", self.alpha).fit(
            x, (y == label).astype(int), sample_weight=sample_weight) for label in self._classes)
        return self

    def decision_function(self, features):
        # Clipping to [0,1] before argmax can create false ties.
        return np.column_stack([model._scores(features) for model in self.models])

    def predict(self, features):
        return self._classes[np.argmax(self.decision_function(features), axis=1)]

    def state(self):
        return {"model_kind": self.family, "task": self.task, "family": self.family,
                "alpha": self.alpha, "classes": self._classes.tolist(),
                "heads": [model.state() for model in self.models]}

    @classmethod
    def from_state(cls, state):
        if (not isinstance(state, dict) or set(state) != _STATE_FIELDS
                or state["model_kind"] != "ovr_ridge" or state["task"] != "classification"
                or state["family"] != "ovr_ridge"):
            raise ValueError("Invalid One-vs-Rest model identity or state fields")
        try:
            model = cls(state["alpha"], state["classes"])
            heads = state["heads"]
            if not isinstance(heads, (list, tuple)) or len(heads) != len(CLASS_LABELS):
                raise ValueError("Checkpoint head count differs from the fixed class universe")
            restored = []
            for head in heads:
                if (not isinstance(head, dict) or head.get("task") != "classification"
                        or head.get("family") != "ridge" or head.get("alpha") != model.alpha):
                    raise ValueError("One-vs-Rest heads must use the same classification Ridge and alpha")
                restored.append(RidgeModel.from_state(head))
            first = restored[0]
            if any(not all(np.array_equal(getattr(head, name), getattr(first, name))
                           for name in ("mean", "std", "basis_mean")) for head in restored[1:]):
                raise ValueError("One-vs-Rest heads must share feature dimensions and scaling")
            model.models = tuple(restored)
            return model
        except (KeyError, TypeError, OverflowError) as error:
            raise ValueError("Malformed One-vs-Rest model state") from error

    def save(self, path):
        """Atomically replace a checkpoint, retaining the original numeric format."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        states = [model.state() for model in self.models]
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(mode="wb", dir=path.parent, prefix=f".{path.name}.",
                                             suffix=".tmp", delete=False) as stream:
                temporary = Path(stream.name)
                np.savez_compressed(stream, format_version=1, model_kind=self.family,
                                    classes=self._classes, alpha=self.alpha,
                                    **{name: np.asarray([state[name] for state in states])
                                       for name in _HEAD_ARRAYS})
            os.replace(temporary, path)
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)

    @classmethod
    def load(cls, path):
        """Read version-1 static OVR checkpoints without enabling pickle."""
        with np.load(path, allow_pickle=False) as archive:
            if set(archive.files) != _CHECKPOINT_FIELDS:
                raise ValueError("Unknown One-vs-Rest checkpoint fields")
            values = {name: archive[name].copy() for name in archive.files}
        if (values["format_version"].shape != () or values["format_version"].dtype.kind not in "iu"
                or values["format_version"].item() != 1 or values["model_kind"].shape != ()
                or values["model_kind"].item() != "ovr_ridge" or values["alpha"].shape != ()):
            raise ValueError("Unsupported One-vs-Rest checkpoint")
        if any(values[name].ndim == 0 or len(values[name]) != len(CLASS_LABELS) for name in _HEAD_ARRAYS):
            raise ValueError("Checkpoint head count differs from the fixed class universe")
        return cls.from_state({"model_kind": "ovr_ridge", "task": "classification", "family": "ovr_ridge",
                               "classes": values["classes"].tolist(), "alpha": values["alpha"].item(),
                               "heads": [{"task": "classification", "family": "ridge",
                                          "alpha": values["alpha"].item(),
                                          **{name: values[name][index].tolist() for name in _HEAD_ARRAYS}}
                                         for index in range(len(CLASS_LABELS))]})
