"""Chronological predict-request-release-adapt execution and fair policy comparisons."""

import time
from dataclasses import replace
from pathlib import Path

import numpy as np

from .config import POLICIES
from .controller import AdaptationController
from .data import make_simulation
from .diagnostics import drift_diagnostics
from .labeling import LabelScheduler
from .model_factory import make_model
from .models import prediction_loss
from .official_model import OFFICIAL_PROFILES, is_official_model_type
from .providers import OfflineScorer, SimulationDataProvider
from .report import render_report, write_rows
from .tracking import JsonlLogger, source_metadata, write_json
from .training import BoundedTrainer


def _validate_targets(task, targets, model_family="ridge", *, model_type="ridge", class_labels=None):
    values = np.asarray(targets)
    classes = tuple(range(1, 7)) if model_family == "ovr_ridge" else (0, 1)
    if model_type not in ("ridge", "tree", "official", "official_mlp"):
        raise ValueError("Unsupported model type")
    if class_labels is not None:
        if (not isinstance(class_labels, (tuple, list)) or any(type(label) is not int for label in class_labels)
                or tuple(class_labels) not in ((0, 1), (1, 2, 3, 4, 5, 6))
                or (model_type == "ridge" and tuple(class_labels) != classes)):
            raise ValueError("Unsupported classification class labels")
        classes = tuple(class_labels)
    if (values.dtype.kind not in "biuf" or values.ndim != 1 or not np.isfinite(values).all()
            or (task == "classification" and not np.isin(values, classes).all())):
        raise ValueError(f"Targets must be finite numeric values; classification requires classes {classes}")


def _resolve_official_profile(config, provider):
    provenance = provider.provenance() if provider is not None else {}
    observed = provenance.get("official_profile") if isinstance(provenance, dict) else None
    if config.official_profile == "auto":
        if observed not in OFFICIAL_PROFILES:
            raise ValueError("official_profile auto requires provider provenance official_profile A, B or C")
        return observed
    if observed is not None and observed != config.official_profile:
        raise ValueError("Configured and provider official_profile values disagree")
    if config.official_profile not in OFFICIAL_PROFILES:
        raise ValueError("An explicit official_profile A, B or C is required")
    return config.official_profile


def _fit_official_fallback(config, initial, trainer, class_labels):
    attempts = []
    try:
        result = trainer.fit(config.task, None, initial.train_x, initial.train_y,
            config.tree_initial_timeout_seconds, model_family="ridge", model_type="tree",
            tree_options=config.tree_options(), class_labels=class_labels, candidate=False)
        attempts.append({"model_type": "tree", "status": result.status, "error": result.error,
                         "wall_seconds": result.wall_seconds})
        if result.status == "ok" and result.model is not None:
            return result.model, "tree", attempts, result.timings
    except Exception as error:
        attempts.append({"model_type": "tree", "status": "error",
                         "error": f"{type(error).__name__}: {error}"[:2048]})
    family = ("ovr_ridge" if config.task == "classification" and
              tuple(class_labels or ()) == (1, 2, 3, 4, 5, 6) else config.model_family)
    model = make_model(config.task, config.candidate_alphas[0], family,
                       class_labels=class_labels).fit(initial.train_x, initial.train_y)
    attempts.append({"model_type": "ridge", "status": "ok", "error": ""})
    return model, "ridge", attempts, None


def run_policy(config, policy, output_dir, trainer, provider=None, offline_scorer: OfflineScorer | None = None):
    requested_model_type = config.model_type
    official_requested = is_official_model_type(requested_model_type)
    if config.harness_backend == "pytrio" and config.scenario == "triple_abrupt":
        from .three_abrupt import validate_paid_claim
        validate_paid_claim(config, output_dir, injected=provider is not None)
    synthetic = provider is None
    if synthetic:
        provider = SimulationDataProvider(make_simulation(config), config)
        offline_scorer = provider.offline_scorer
    profile_error = None
    if official_requested:
        try:
            profile_type = _resolve_official_profile(config, provider)
            if config.official_profile == "auto":
                contract = OFFICIAL_PROFILES[profile_type]
                class_labels = contract["class_labels"] or None
                config = replace(config, task=contract["task"], n_features=contract["n_features"],
                                 official_profile=profile_type, class_labels=class_labels)
        except Exception as error:
            profile_error = error
    multiclass = config.model_family == "ovr_ridge" or config.class_labels == (1, 2, 3, 4, 5, 6)
    if multiclass and (provider is None or
            isinstance(provider, SimulationDataProvider) or config.harness_backend != "mock"):
        raise ValueError("Six-class models require an injected real-data provider and Mock backend")
    if (provider.n_features != config.n_features or len(provider.batch_sizes) != config.n_batches
            or provider.label_delay != config.label_delay or any(size < 1 for size in provider.batch_sizes)):
        raise ValueError("Provider features, batches and label delay must match config")
    run_class_labels = config.class_labels
    initial = provider.initial_data()
    for x, y in ((initial.train_x, initial.train_y), (initial.validation_x, initial.validation_y)):
        _validate_targets(config.task, y, config.model_family, model_type=config.model_type,
                          class_labels=run_class_labels)
        if (np.ndim(x) != 2 or np.shape(x)[1] != config.n_features or np.ndim(y) != 1
                or len(x) != len(y) or len(y) < 4 or not np.isfinite(x).all() or not np.isfinite(y).all()):
            raise ValueError("Provider initial data is invalid")
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=False)
    write_json(output_dir / "config.json", {**config.to_dict(), "requested_model_type": requested_model_type,
                                             "policy": policy})
    predictions, prediction_lookup, timeline = [], {}, []
    official_ids, probabilities = [], []
    tree = config.model_type == "tree"
    official = official_requested
    worker_model = tree or official
    owned_trainer = worker_model and trainer is None
    if owned_trainer:
        trainer = BoundedTrainer()
    initial_timings = None
    initial_checkpoint_seconds = 0.0
    started = time.perf_counter()
    logger = JsonlLogger(output_dir / "events.jsonl", output_dir.name)
    try:
        logger.event("run_started", -1, policy=policy, config=config.to_dict(),
                     data_source=({"kind": "synthetic", "scenario": config.scenario} if synthetic else
                                  provider.provenance()), **source_metadata())
        initial_started = time.perf_counter()
        active_model_type = config.model_type
        fallback_attempts = None
        if official:
            try:
                if profile_error is not None:
                    raise profile_error
                model = make_model(config.task, None, config.model_family, model_type=config.model_type,
                                   class_labels=run_class_labels, official_options=config.official_options())
                initial_seconds = time.perf_counter() - initial_started
            except Exception as error:
                failure_reason = f"{type(error).__name__}: {error}"[:2048]
                model, active_model_type, fallback_attempts, initial_timings = _fit_official_fallback(
                    config, initial, trainer, run_class_labels)
                logger.event("model_fallback", -1, requested_model_type=requested_model_type,
                    failed_model_type=config.model_type, failure_reason=failure_reason,
                    fallback_model_type=active_model_type, attempts=fallback_attempts)
                initial_seconds = time.perf_counter() - initial_started
                official = False
                tree = active_model_type == "tree"
        elif tree:
            initial_result = trainer.fit(config.task, None, initial.train_x, initial.train_y,
                config.tree_initial_timeout_seconds, model_family="ridge", model_type="tree",
                tree_options=config.tree_options(), class_labels=run_class_labels, candidate=False)
            initial_seconds = max(time.perf_counter() - initial_started, initial_result.wall_seconds)
            initial_timings = initial_result.timings
            if initial_result.status != "ok" or initial_result.model is None:
                logger.event("initial_training", -1, status=initial_result.status, model_type="tree",
                    train_samples=len(initial.train_y), validation_samples=len(initial.validation_y), alpha=None,
                    tree_options=config.tree_options(), wall_seconds=initial_seconds,
                    timings=initial_timings, error=initial_result.error)
                raise RuntimeError(f"Initial tree training failed: {initial_result.status}: {initial_result.error}")
            model = initial_result.model
            active_model_type = "tree"
        else:
            model = make_model(config.task, config.candidate_alphas[0], config.model_family,
                               class_labels=run_class_labels).fit(initial.train_x, initial.train_y)
            initial_seconds = time.perf_counter() - initial_started
        scale = max(float(np.var(initial.validation_y)), 1e-8) if config.task == "regression" else 1.0
        try:
            baseline_loss = prediction_loss(config.task, initial.validation_y,
                                           model.predict(initial.validation_x), scale)
        except Exception as error:
            if not is_official_model_type(active_model_type):
                raise
            failure_reason = f"{type(error).__name__}: {error}"[:2048]
            model, active_model_type, fallback_attempts, initial_timings = _fit_official_fallback(
                config, initial, trainer, run_class_labels)
            baseline_loss = prediction_loss(config.task, initial.validation_y,
                                           model.predict(initial.validation_x), scale)
            logger.event("model_fallback", -1, requested_model_type=requested_model_type,
                failed_model_type=config.model_type, failure_reason=failure_reason,
                fallback_model_type=active_model_type, attempts=fallback_attempts)
            initial_seconds = time.perf_counter() - initial_started
            official = False
            tree = active_model_type == "tree"
        checkpoint_started = time.perf_counter()
        model.save(output_dir / "initial.npz")
        model.save(output_dir / "deployed.npz")
        initial_checkpoint_seconds = time.perf_counter() - checkpoint_started
        logger.event("initial_training", -1, train_samples=len(initial.train_y),
                     validation_samples=len(initial.validation_y), alpha=None if tree or official else model.alpha,
                     validation_loss=baseline_loss, wall_seconds=initial_seconds,
                     checkpoint_seconds=initial_checkpoint_seconds,
                     **({"status": "ok", "model_type": "tree", "tree_options": config.tree_options(),
                         "class_labels": run_class_labels, "timings": initial_timings} if tree else
                        {"status": "ok", "model_type": active_model_type,
                         "official_profile": config.official_profile,
                         "checkpoint_sha256": model.checkpoint_sha256} if official else
                        {"status": "ok", "model_type": active_model_type,
                         "fallback_attempts": fallback_attempts} if fallback_attempts is not None else {}))
        controller = AdaptationController(config, policy, model, baseline_loss, scale, logger, trainer,
                                          output_dir, active_model_type=active_model_type)
        rng = np.random.default_rng(config.seed + 100_003)
        scheduler = LabelScheduler(config)
        labels_released = peak_prediction_cache = 0
        prediction_seconds = 0.0
        peak_label_history = 0
        for expected_step, batch in enumerate(provider.iter_batches()):
            if (batch.step != expected_step or expected_step >= config.n_batches
                    or batch.features.shape != (provider.batch_sizes[expected_step], config.n_features)
                    or batch.sample_ids.shape != (len(batch.features),)
                    or not np.isfinite(batch.features).all()):
                raise ValueError("Provider returned an invalid batch boundary or feature shape")
            labels_allowed = controller.allow_label_request(batch.step)
            # Store predictions before any labels from this batch can be requested or released.
            prediction_started = time.perf_counter()
            try:
                prediction = controller.predict(batch.features)
            except Exception as error:
                if not is_official_model_type(controller.active_model_type):
                    raise
                fallback_model, fallback_type, attempts, _ = _fit_official_fallback(
                    config, initial, trainer, run_class_labels)
                fallback_loss = prediction_loss(config.task, initial.validation_y,
                    fallback_model.predict(initial.validation_x), scale)
                controller.activate_fallback(fallback_model, fallback_type, fallback_loss, batch.step,
                    f"{type(error).__name__}: {error}"[:2048], attempts)
                prediction = controller.predict(batch.features)
                tree = fallback_type == "tree"
                official = is_official_model_type(fallback_type)
            active_model_type = controller.active_model_type
            if (config.task == "classification" and
                    active_model_type in ("tree", "official", "official_mlp")):
                probabilities.append(controller.gate.model.predict_proba(batch.features))
            prediction_seconds += time.perf_counter() - prediction_started
            predictions.append(prediction.copy())
            provider.commit_predictions(batch.step, batch.sample_ids, prediction)
            if not synthetic:
                official_ids.append(batch.sample_ids.copy())
            logger.event("prediction", batch.step, samples=len(prediction), model_version=controller.gate.version)
            count = scheduler.count(batch.step, controller.budget.labels,
                                    controller.performance_drop_active, controller.pending is not None)
            # Preserve the legacy RNG sequence even after its quota is exhausted.
            if config.label_schedule == "frontloaded":
                count = scheduler.per_batch
            count = min(count, len(batch.sample_ids))
            if not synthetic and controller.budget.remaining_label_budget is not None:
                count = min(count, controller.budget.remaining_label_budget)
            if not labels_allowed:
                count = 0
            ids = rng.choice(batch.sample_ids, size=count, replace=False)
            accepted = provider.request_labels(ids, batch.step) if policy != "static" and labels_allowed else 0
            lookup = dict(zip(map(int, batch.sample_ids), prediction.tolist()))
            prediction_lookup.update((int(i), lookup[int(i)]) for i in ids[:accepted])
            peak_prediction_cache = max(peak_prediction_cache, len(prediction_lookup))
            controller.budget.record_labels(accepted)
            logger.event("labels_requested", batch.step, count=accepted, total=controller.budget.labels)
            # Hard Harness fallback wins over a pending gate in this same batch.
            controller.allow_label_request(batch.step)
            released = provider.release_labels(batch.step)
            if released is not None:
                active_family = ("ovr_ridge" if controller.active_model_type == "ridge" and
                                 run_class_labels == (1, 2, 3, 4, 5, 6) else config.model_family)
                _validate_targets(config.task, released.targets, active_family,
                                  model_type=controller.active_model_type, class_labels=run_class_labels)
                labels_released += len(released.targets)
                logger.event("labels_released", batch.step, count=len(released.targets),
                             latest_source_step=int(released.source_steps.max()),
                             sources=[{"source_step": int(source), "count": int(np.sum(released.source_steps == source))}
                                      for source in np.unique(released.source_steps)])
            availability = provider.label_availability(controller.budget.remaining_label_budget, scheduler.per_batch)
            controller.observe(batch, released, prediction_lookup, label_availability=availability)
            peak_label_history = max(peak_label_history, len(controller.history_y))
            if released is not None:
                for sample_id in released.sample_ids:
                    prediction_lookup.pop(int(sample_id))
            timeline.append({"step": batch.step, "model_version": controller.gate.version,
                             **controller.budget.snapshot()})
        if len(predictions) != config.n_batches:
            raise ValueError("Provider stream ended before its declared batch count")
        controller.finish(config.n_batches)
        # Only now is the isolated retrospective scorer used. No scoring labels enter the controller.
        losses = offline_scorer.score(predictions) if offline_scorer is not None else None
        diagnostics = drift_diagnostics(config, losses, controller.detection_steps) if synthetic else {
            "available": False, "reason": "Official provider has no simulation drift truth"}
        write_json(output_dir / "diagnostics.json", diagnostics)
        for row, loss in zip(timeline, losses if losses is not None else [None] * len(timeline)):
            row["loss"] = loss
        summary = {"task": config.task, "scenario": config.scenario, "seed": config.seed, "policy": policy,
                   "strategy_adaptation": config.strategy_adaptation if policy == "drift" else False,
                   "deployment_validation": config.deployment_validation,
                   "model_family": model.family, "model_type": controller.active_model_type,
                   "requested_model_type": requested_model_type,
                   "class_labels": run_class_labels,
                   "tree_options": config.tree_options() if controller.active_model_type == "tree" else None,
                   "official_profile": config.official_profile if is_official_model_type(
                       controller.active_model_type) and config.official_profile in OFFICIAL_PROFILES else None,
                   "relationship": config.relationship,
                   "monitor_min_labeled": config.monitor_min_labeled or config.min_labeled,
                   "reuse_history": config.reuse_history if policy == "drift" else False,
                   "history_reuses": controller.history_reuses,
                   "label_schedule": config.label_schedule, "labels_released": labels_released,
                   "label_startup_budget": config.label_startup_budget,
                   "train_source_window_batches": config.train_source_window_batches,
                   "training_preflight": config.training_preflight,
                   "training_weighting": config.training_weighting,
                   "training_half_life_batches": config.training_half_life_batches,
                   "training_ess_audit_count": controller.training_ess_audit_count,
                   "training_ess_min": controller.training_ess_min,
                   "training_ess_mean": (controller.training_ess_sum / controller.training_ess_audit_count
                                         if controller.training_ess_audit_count else None),
                   "training_ess_max": controller.training_ess_max,
                   "training_preflight_skips": controller.training_preflight_skips,
                   "last_experiment": controller.last_experiment,
                   "cooldown_until": controller.cooldown_until,
                   "labels_unreleased": controller.budget.labels - labels_released,
                   "peak_prediction_cache": peak_prediction_cache,
                   "remaining_prediction_cache": len(prediction_lookup),
                   "peak_label_history": peak_label_history,
                   "prediction_seconds": prediction_seconds,
                   "candidates_frozen": controller.candidate_serial,
                   "candidate_wait_mean_batches": float(np.mean(controller.candidate_waits)) if controller.candidate_waits else 0.0,
                   "candidate_wait_max_batches": max(controller.candidate_waits, default=0),
                   "pending_expired": controller.pending_expired,
                   "pending_uncollectable": controller.pending_uncollectable,
                   "label_infeasible_skips": controller.label_infeasible_skips,
                   "model_evaluation_seconds": controller.evaluation_seconds,
                   **{key: value for key, value in diagnostics.items() if key != "changes"},
                   "mean_loss": float(np.mean(losses)) if losses is not None else None,
                   "accuracy": 1 - float(np.mean(losses))
                   if config.task == "classification" and losses is not None else None,
                   "loss_gain_vs_static": None, "updates": controller.gate.updates,
                   "rollbacks": controller.gate.rollbacks, "detections": controller.detections,
                   **controller.budget.snapshot(), "initial_train_seconds": initial_seconds,
                   "initial_train_timings": initial_timings,
                   "initial_checkpoint_seconds": initial_checkpoint_seconds,
                   "adaptation_checkpoint_seconds": controller.checkpoint_seconds,
                   "initial_train_labels": len(initial.train_y), "initial_validation_labels": len(initial.validation_y),
                   "run_wall_seconds": time.perf_counter() - started, "stream_batches": len(predictions),
                   "curve_file": "curve.csv"}
        if controller.budget_guard:
            summary.update(controller.budget_guard.snapshot())
            summary.update(harness_enabled=True, harness_mock_mode=config.harness_mock_mode,
                           harness_backend=config.harness_backend)
        if config.task == "regression" and offline_scorer is not None:
            raw_metrics = getattr(offline_scorer, "regression_metrics", None)
            if callable(raw_metrics):
                summary.update(raw_metrics(predictions))
        if config.task == "classification" and offline_scorer is not None:
            counts = offline_scorer.classification_counts(predictions)
            summary.update(counts)
            if multiclass:
                summary["batch_mean_accuracy"] = summary["accuracy"]
                summary["accuracy"] = counts["sample_weighted_accuracy"]
            else:
                summary["false_positive_rate"] = counts["fp"] / max(1, counts["fp"] + counts["tn"])
                summary["false_negative_rate"] = counts["fn"] / max(1, counts["fn"] + counts["tp"])
        if len({len(prediction) for prediction in predictions}) == 1:
            saved = {"predictions": np.asarray(predictions)}
        else:
            saved = {"predictions": np.concatenate(predictions),
                     "batch_offsets": np.cumsum([0, *(len(p) for p in predictions)])}
        if not synthetic:
            saved["sample_ids"] = np.concatenate(official_ids)
            saved["batch_offsets"] = np.cumsum([0, *(len(p) for p in predictions)])
        if probabilities:
            saved["probabilities"] = np.concatenate(probabilities)
            saved["class_labels"] = np.asarray(run_class_labels, dtype=np.int64)
        np.savez_compressed(output_dir / "predictions.npz", **saved)
        write_rows(output_dir / "curve.csv", timeline)
        write_json(output_dir / "summary.json", summary)
        logger.event("run_completed", config.n_batches, **summary)
    except Exception as error:
        try:
            logger.event("run_failed", len(predictions), reason=f"{type(error).__name__}: {error}")
        except OSError:
            pass  # Preserve the original error if the disk cannot store even a failure event.
        raise
    finally:
        logger.close()
        if owned_trainer:
            trainer.close()
    return summary


def run_comparison(config, output_dir, policies=POLICIES, trainer=None, reference_static_loss=None):
    if config.harness_backend == "pytrio" and tuple(policies) != ("drift",):
        raise ValueError("Paid smoke requires exactly one drift policy")
    if not policies or len(set(policies)) != len(policies) or any(p not in POLICIES for p in policies):
        raise ValueError("Specify unique supported policies")
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    if any(output_dir.iterdir()):
        raise FileExistsError(f"Refusing to overwrite an existing experiment: {output_dir}")
    write_json(output_dir / "config.json", config.to_dict())
    owned = trainer is None
    trainer = trainer or BoundedTrainer()
    try:
        results = []
        for policy in policies:
            # Give every policy a cold worker; otherwise the first adaptive policy pays
            # all process startup overhead and later policies appear artificially cheap.
            trainer.close()
            results.append(run_policy(config, policy, output_dir / policy, trainer))
    finally:
        if owned:
            trainer.close()
    static = next((item for item in results if item["policy"] == "static"), None)
    reference = static["mean_loss"] if static is not None else reference_static_loss
    for result in results:
        if reference is not None:
            result["loss_gain_vs_static"] = reference - result["mean_loss"]
        write_json(output_dir / result["policy"] / "summary.json", result)
        if reference is not None:
            with JsonlLogger(output_dir / result["policy"] / "events.jsonl", result["policy"], append=True) as logger:
                logger.event("comparison_finalized", config.n_batches, **result)
        result["curve_file"] = f"{result['policy']}/curve.csv"
    render_report(output_dir, results)
    return results
