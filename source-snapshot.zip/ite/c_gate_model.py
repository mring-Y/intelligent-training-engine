"""Complete frozen MLP/adapter/gate artifact and one-deadline candidate fit."""

import base64
import hashlib
import io
import json
import math
from pathlib import Path
import subprocess
import time
import zipfile

import numpy as np

from .c_adapter_model import CInputAdapterModel,pack_checkpoint as pack_adapter,unpack_checkpoint as unpack_adapter
from .c_low_rul_residual import LowRulResidual, SOURCE_FIELDS as LOW_RUL_SOURCE_FIELDS
from .c_rbf_model import LIMIT,npz_bytes
from .c_stable_head import (BALANCED_MODULE, LOW_RUL_MODULE, MODULE as STABLE_MODULE, MODULE_BY_FORMAT, ROWS as STABLE_ROWS,
                            SAMPLING_POLICY, StableHeadUnavailable, array_digest, eligible_training_rows, is_stable_checkpoint, load_domain, normalize,
                            pack_stable_checkpoint, screening_eligible, select_balanced_history_rows,
                            stable_training_rows, unpack_stable_checkpoint)
from .gate_reference import load_reference
from .input_gate import InputGate,POLICY,matrix
from .operating_support import DIMENSIONS, MODULE as SUPPORT_MODULE, OperatingSupport, ROWS, reference_distance
from .residual_calibration import MODULE as RESIDUAL_MODULE, SOURCE_FIELDS, ResidualCalibration, prepare_source

FORMAT="ite.c-mlp-input-gate.v1"
SUPPORT_FORMAT = "ite.c-mlp-input-gate.v2"
RESIDUAL_FORMAT = "ite.c-mlp-input-gate.v3"
LOW_RUL_FORMAT = "ite.c-mlp-input-gate.v4"
GATE_MODULE = "input_gate_v1"
STABLE_POLICIES = (STABLE_MODULE, BALANCED_MODULE)
GATE_POLICIES = (GATE_MODULE, SUPPORT_MODULE, RESIDUAL_MODULE, *STABLE_POLICIES, LOW_RUL_MODULE)
FIELDS={"metadata","adapter_checkpoint","gate_weight","gate_threshold","gate_scale"}
SUPPORT_FIELDS = {"support_points", "support_distance"}
RESIDUAL_FIELDS = {"residual_coefficients"}
LOW_RUL_FIELDS = {"low_rul_coefficients"}


def validate_audit(audit):
    required={"source_sha256","current_ids_sha256","current_groups","fit_ids","calibration_ids","fit_groups","calibration_groups",
        "fit_rows","calibration_rows","current_rows","calibration_nonzero_rate","current_nonzero_rate","current_mean_weight","uses_rul_targets"}
    if not isinstance(audit,dict) or set(audit)!=required or audit["uses_rul_targets"] is not False:
        raise ValueError("complete train-input-only gate provenance required")
    for key in ("source_sha256","current_ids_sha256"):
        s=audit[key]
        if not isinstance(s,str) or len(s)!=64 or any(c not in "0123456789abcdef" for c in s):raise ValueError("invalid gate source digest")
    for key,minimum in (("fit_rows",64),("calibration_rows",32),("current_rows",2)):
        if type(audit[key]) is not int or audit[key]<minimum:raise ValueError("invalid gate source count")
    for key in ("current_groups","fit_ids","calibration_ids","fit_groups","calibration_groups"):
        rows=audit[key]
        if not isinstance(rows,list) or not rows or any(not isinstance(r,str) or not r for r in rows):raise ValueError("invalid gate source identities")
    for role in ("fit","calibration"):
        ids,groups=audit[role+"_ids"],audit[role+"_groups"]
        if len(ids)!=audit[role+"_rows"] or len(groups)!=len(ids) or len(ids)!=len(set(ids)):
            raise ValueError("gate provenance count or identity mismatch")
    groups=[set(audit[k]) for k in ("fit_groups","calibration_groups","current_groups")]
    if groups[0]&groups[1] or groups[0]&groups[2] or groups[1]&groups[2] or set(audit["fit_ids"])&set(audit["calibration_ids"]):
        raise ValueError("gate provenance engines must be disjoint")
    for key in ("calibration_nonzero_rate","current_nonzero_rate","current_mean_weight"):
        v=audit[key]
        if type(v) not in (float,int) or not math.isfinite(v) or not 0<=v<=1:raise ValueError("invalid gate activation audit")
    if audit["current_mean_weight"]>audit["current_nonzero_rate"]+1e-12:raise ValueError("inconsistent gate activation audit")


def is_gated(raw):
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            return bool({"adapter_checkpoint.npy", "drift_checkpoint.npy"} & set(z.namelist()))
    except zipfile.BadZipFile as error:raise ValueError("invalid gated checkpoint archive") from error


def gate_policy(raw, requested):
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        names = archive.namelist()
    if "drift_checkpoint.npy" in names:
        drift_checkpoint, _, meta = unpack_stable_checkpoint(raw)
        if is_gated(drift_checkpoint):
            _, gate, _ = unpack_checkpoint(drift_checkpoint)
            if gate.low_rul_residual is not None:
                if requested not in ("none", LOW_RUL_MODULE, *STABLE_POLICIES):
                    raise ValueError("the actual parent requires its low-RUL residual module")
                return LOW_RUL_MODULE
        retained = MODULE_BY_FORMAT[meta["format"]]
        if retained == STABLE_MODULE and requested == BALANCED_MODULE:
            return BALANCED_MODULE
        if requested == LOW_RUL_MODULE:
            return LOW_RUL_MODULE
        if requested not in ("none", retained):
            raise ValueError("the actual parent requires its original-domain head policy")
        return retained
    if "support_points.npy" in names and requested not in ("none", SUPPORT_MODULE):
        raise ValueError("the actual parent requires its operating support module")
    if "low_rul_coefficients.npy" in names:
        if requested not in ("none", LOW_RUL_MODULE):
            raise ValueError("the actual parent requires its low-RUL residual module")
        return LOW_RUL_MODULE
    if "residual_coefficients.npy" in names and requested not in (
            "none", RESIDUAL_MODULE, *STABLE_POLICIES, LOW_RUL_MODULE):
        raise ValueError("the actual parent requires its residual calibration module")
    if "support_points.npy" in names:
        return SUPPORT_MODULE
    if "residual_coefficients.npy" in names:
        return requested if requested in (*STABLE_POLICIES, LOW_RUL_MODULE) else RESIDUAL_MODULE
    if requested in (*STABLE_POLICIES, LOW_RUL_MODULE) and ("w1.npy" not in names or "w2.npy" not in names):
        raise ValueError("the original-domain head requires a native or NR-055 parent checkpoint")
    return requested if requested in GATE_POLICIES else GATE_MODULE


def pack_checkpoint(adapter,gate,parent_digest,gate_fits=1,gate_audit=None):
    meta={"format":FORMAT,"profile":"C","policy":dict(POLICY),"parent_checkpoint_sha256":parent_digest,
          "adapter_sha256":hashlib.sha256(adapter).hexdigest(),"gate_fits":gate_fits,"gate_audit":gate_audit or {}}
    arrays = {"adapter_checkpoint":np.frombuffer(adapter,dtype=np.uint8),"gate_weight":gate.weight,
        "gate_threshold":np.array(gate.threshold),"gate_scale":np.array(gate.scale)}
    support = gate.operating_support
    if support is not None:
        meta.update(format=SUPPORT_FORMAT, operating_support=support.audit)
        arrays.update(support_points=support.points, support_distance=np.array(support.distance))
    calibration = gate.residual_calibration
    if calibration is not None:
        meta.update(format=RESIDUAL_FORMAT, residual_calibration=calibration.audit)
        arrays["residual_coefficients"] = calibration.coefficients
    low_rul = gate.low_rul_residual
    if low_rul is not None:
        meta.update(format=LOW_RUL_FORMAT, low_rul_residual=low_rul.audit)
        arrays["low_rul_coefficients"] = low_rul.coefficients
    arrays["metadata"] = np.array(json.dumps(meta,sort_keys=True,separators=(",",":"),allow_nan=False))
    raw=npz_bytes(arrays)
    unpack_checkpoint(raw)
    return raw


def unpack_checkpoint(raw):
    if not isinstance(raw,bytes) or not 1<=len(raw)<=LIMIT:raise ValueError("invalid gated checkpoint size")
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            entries=z.infolist()
            names = {e.filename for e in entries}
            supported = "support_points.npy" in names
            residual = "residual_coefficients.npy" in names
            low_rul = "low_rul_coefficients.npy" in names
            expected_fields = FIELDS | (SUPPORT_FIELDS if supported else RESIDUAL_FIELDS if residual else set())
            if low_rul:
                if not residual or supported:
                    raise ValueError("low-RUL residual requires complete NR-055 calibration")
                expected_fields |= LOW_RUL_FIELDS
            if len(entries)!=len(expected_fields) or names!={k+".npy" for k in expected_fields} or sum(e.file_size for e in entries)>LIMIT:
                raise ValueError("complete gated checkpoint fields required")
        with np.load(io.BytesIO(raw),allow_pickle=False) as z:
            from .platform_data import json_value
            m=z["metadata"]
            if m.shape!=() or m.dtype.kind!="U":raise ValueError("invalid gate metadata")
            meta=json_value(str(m))
            metadata_fields = {"format","profile","policy","parent_checkpoint_sha256","adapter_sha256","gate_fits","gate_audit"}
            if supported:
                metadata_fields.add("operating_support")
            if residual:
                metadata_fields.add("residual_calibration")
            expected_format = SUPPORT_FORMAT if supported else RESIDUAL_FORMAT if residual else FORMAT
            if low_rul:
                metadata_fields.add("low_rul_residual")
                expected_format = LOW_RUL_FORMAT
            if (not isinstance(meta,dict) or set(meta)!=metadata_fields or
                    meta["format"]!=expected_format or meta["profile"]!="C" or meta["policy"]!=POLICY or
                    type(meta["gate_fits"]) is not int or meta["gate_fits"]<1 or not isinstance(meta["gate_audit"],dict)):
                raise ValueError("unsupported gated checkpoint metadata")
            for key in ("parent_checkpoint_sha256","adapter_sha256"):
                s=meta[key]
                if not isinstance(s,str) or len(s)!=64 or any(c not in "0123456789abcdef" for c in s):raise ValueError("invalid gate checkpoint digest")
            arr=z["adapter_checkpoint"]
            if arr.ndim!=1 or arr.dtype!=np.uint8 or not len(arr):raise ValueError("missing actual adapter checkpoint")
            adapter=arr.tobytes()
            if hashlib.sha256(adapter).hexdigest()!=meta["adapter_sha256"]:raise ValueError("embedded adapter digest mismatch")
            _,module,adapter_meta=unpack_adapter(adapter)
            if adapter_meta["parent_checkpoint_sha256"]!=meta["parent_checkpoint_sha256"] or meta["gate_fits"]>module.epochs//2:
                raise ValueError("combined gate candidate parent or fit count mismatch")
            validate_audit(meta["gate_audit"])
            for k in ("gate_threshold","gate_scale"):
                if z[k].shape!=() or z[k].dtype!=np.float64:raise ValueError("invalid gate scalar")
            if z["gate_weight"].dtype!=np.float64:raise ValueError("invalid gate weight dtype")
            support = None
            if supported:
                points, distance = z["support_points"], z["support_distance"]
                audit = meta["operating_support"]
                if (points.dtype != np.float64 or distance.dtype != np.float64 or distance.shape != ()
                        or not isinstance(audit, dict)):
                    raise ValueError("invalid operating support payload")
                support = OperatingSupport(points, distance, audit["gradient_ids_sha256"], audit["reference_sha256"])
                if support.audit != audit or audit["reference_sha256"] != meta["gate_audit"]["source_sha256"]:
                    raise ValueError("operating support digest or provenance mismatch")
            calibration = None
            if residual:
                coefficients, audit = z["residual_coefficients"], meta["residual_calibration"]
                if coefficients.dtype != np.float64 or not isinstance(audit, dict):
                    raise ValueError("invalid residual calibration payload")
                provenance = {key: audit[key] for key in SOURCE_FIELDS}
                calibration = ResidualCalibration(coefficients, provenance, audit["positive_target_rows"])
                if calibration.audit != audit or provenance["train_sha256"] != meta["gate_audit"]["source_sha256"]:
                    raise ValueError("residual calibration digest or provenance mismatch")
            head = None
            if low_rul:
                coefficients, audit = z["low_rul_coefficients"], meta["low_rul_residual"]
                if coefficients.dtype != np.float64 or not isinstance(audit, dict):
                    raise ValueError("invalid low-RUL residual payload")
                provenance = {key: audit[key] for key in LOW_RUL_SOURCE_FIELDS}
                head = LowRulResidual(coefficients, provenance, audit["fit_rows"])
                if (head.audit != audit or provenance["train_sha256"] != meta["gate_audit"]["source_sha256"]
                        or provenance["source_step"] != calibration.audit["gradient_source_step"]
                        or provenance["rows"] != ROWS):
                    raise ValueError("low-RUL residual digest or provenance mismatch")
            gate=InputGate(z["gate_weight"],z["gate_threshold"],z["gate_scale"],
                           operating_support=support,residual_calibration=calibration,low_rul_residual=head)
        return adapter,gate,meta
    except (zipfile.BadZipFile,KeyError,TypeError) as error:raise ValueError("invalid complete gated checkpoint") from error


class CGatedInputModel:
    def __init__(self,adapter,gate=None,*,parent_digest=None,gate_fits=0,gate_audit=None,checkpoint=None):
        if not isinstance(adapter,CInputAdapterModel) or (gate is not None and (not isinstance(gate,InputGate) or adapter.module is None)):
            raise ValueError("gate requires actual frozen C MLP/adapter")
        self.adapter,self.gate=adapter,gate
        self.parent_digest=parent_digest or adapter.checkpoint_sha256
        self.gate_fits=gate_fits if gate is None or gate_fits else 1
        self.gate_audit=gate_audit or {}
        self.checkpoint_bytes=(checkpoint if checkpoint is not None else adapter.checkpoint_bytes if gate is None else
            pack_checkpoint(adapter.checkpoint_bytes,gate,self.parent_digest,self.gate_fits,self.gate_audit))
        self.checkpoint_sha256=hashlib.sha256(self.checkpoint_bytes).hexdigest()
        self.parameter_count=adapter.parameter_count+(26 if gate is not None else 0)
        if gate is not None and gate.residual_calibration is not None:
            self.parameter_count += len(gate.residual_calibration.coefficients)
        if gate is not None and gate.low_rul_residual is not None:
            self.parameter_count += len(gate.low_rul_residual.coefficients)

    def __getattr__(self,name):return getattr(self.adapter,name)

    def _invoke(self,operation,features,*,timeout=30.,deadline=None,**options):
        request={"operation":operation,"checkpoint":base64.b64encode(self.checkpoint_bytes).decode("ascii"),"features":matrix(features).tolist(),**options}
        payload=json.dumps(request,allow_nan=False)
        if deadline is not None:
            timeout=min(timeout,deadline-time.perf_counter())
            if timeout<=0:raise TimeoutError("gate request preparation exceeded deadline")
        cmd=[self.runtime_python,"-B","-X","utf8",str(Path(__file__).with_name("c_gate_worker.py")),self.package_path]
        try:r=subprocess.run(cmd,input=payload,text=True,encoding="utf8",capture_output=True,timeout=timeout)
        except subprocess.TimeoutExpired as error:raise TimeoutError("gate worker exceeded candidate allowance") from error
        if r.returncode:raise RuntimeError("gate worker failed: "+r.stderr[-1500:])
        response=json.loads(r.stdout)
        if response.get("ok") is not True:raise RuntimeError("invalid gate worker response")
        return response

    def predict(self,features):
        if self.gate is None and getattr(self, "stable_head", None) is None:
            return self.adapter.predict(features)
        values=np.asarray(self._invoke("predict",features)["predictions"],dtype=np.float64)
        if values.shape!=(len(features),) or not np.isfinite(values).all() or np.any(values<0):raise ValueError("invalid gated predictions")
        return values

    def save(self,path):
        with Path(path).open("xb") as f:f.write(self.checkpoint_bytes)

    @classmethod
    def from_bytes(cls,raw,runtime_python):
        if is_stable_checkpoint(raw):
            drift, head, meta = unpack_stable_checkpoint(raw)
            return CStableHeadModel(cls.from_bytes(drift, runtime_python), head, meta["parent_checkpoint_sha256"], raw)
        if is_gated(raw):
            adapter,gate,meta=unpack_checkpoint(raw)
            return cls(CInputAdapterModel.from_bytes(adapter,runtime_python),gate,parent_digest=meta["parent_checkpoint_sha256"],
                gate_fits=meta["gate_fits"],gate_audit=meta["gate_audit"],checkpoint=raw)
        return cls(CInputAdapterModel.from_bytes(raw,runtime_python),checkpoint=raw)

    @classmethod
    def load(cls,path,runtime_python):
        p=Path(path)
        if p.is_symlink() or not p.is_file() or not 1<=p.stat().st_size<=LIMIT:raise ValueError("gate checkpoint must be bounded regular NPZ")
        return cls.from_bytes(p.read_bytes(),runtime_python)


class CStableHeadModel(CGatedInputModel):
    def __init__(self, drift, head, parent_digest, checkpoint):
        super().__init__(drift.adapter, drift.gate, parent_digest=parent_digest, gate_fits=drift.gate_fits,
                         gate_audit=drift.gate_audit, checkpoint=checkpoint)
        self.routed_base, self.stable_head = drift, head
        if head is not None:
            head.validate_clock(self.steps, self.epochs, _native_batch_size(self.mlp.checkpoint_bytes))
            self.parameter_count += 33


def _native_batch_size(raw):
    with np.load(io.BytesIO(raw), allow_pickle=False) as native:
        return json.loads(str(native["metadata"]))["batch_size"]


def _stable_fit_request(parent, context, reference, gradient_ids, *, balanced_sampling):
    expected = {"x", "y", "ids", "source_step", "screening_x"}
    if balanced_sampling:
        expected.update(("source_steps", "screening_ids"))
    if not isinstance(context, dict) or set(context) != expected:
        raise ValueError("original-domain head requires released history, source clocks, and screening IDs")
    x = matrix(context["x"])
    y = np.asarray(context["y"], dtype=np.float64)
    ids = context["ids"]
    if (y.shape != (len(x),) or not np.isfinite(y).all() or np.any(y < 0)
            or len(ids) != len(x) or len(set(ids)) != len(ids)
            or any(identity not in reference.group_for_id for identity in ids)
            or type(context["source_step"]) is not int or context["source_step"] < 0):
        raise ValueError("invalid original-domain released history")
    domain, domain_reference = load_domain(parent.package_path, tuple(parent.mean), tuple(parent.std))
    prior_head = getattr(parent, "stable_head", None)
    if prior_head is not None:
        # Resume with the distance state stored alongside the selected head.
        domain = prior_head.domain
    normalized = normalize(x, parent.mean, parent.std)
    screening = matrix(context["screening_x"])
    request = {"screening_x": screening.tolist(), "fit": None}
    source_step = context["source_step"]
    if balanced_sampling:
        source_steps = context["source_steps"]
        screening_ids = context["screening_ids"]
        if (not isinstance(source_steps, list) or not source_steps or source_steps[-1] != source_step
                or any(type(step) is not int for step in source_steps)
                or not isinstance(screening_ids, list) or len(screening_ids) != len(screening)
                or any(not isinstance(identity, str) or not identity for identity in screening_ids)
                or len(set(screening_ids)) != len(screening_ids)):
            raise ValueError("released history needs aligned source clocks and screening IDs")
        indices = eligible_training_rows(normalized, domain, parent.gate)
        selected, sampling_audit = select_balanced_history_rows(
            indices, ids, source_steps, reference.group_for_id,
            excluded_groups={reference.group_for_id[identity] for identity in gradient_ids},
            excluded_ids=screening_ids,
        )
        request.update(eligible_rows=len(indices), sampling_audit=sampling_audit)
    else:
        selected, eligible = stable_training_rows(normalized, domain, parent.gate)
        request["eligible_rows"] = eligible
    selected_ids = []
    source = None
    if len(selected) == STABLE_ROWS:
        selected_ids = [ids[int(i)] for i in selected]
        source = {"source_step": source_step, "rows": STABLE_ROWS,
                  "ids_sha256": hashlib.sha256("\n".join(selected_ids).encode()).hexdigest(),
                  "inputs_sha256": array_digest(x[selected]), "targets_sha256": array_digest(y[selected]),
                  "train_sha256": reference.source_sha256}
        if balanced_sampling:
            selected_steps = sampling_audit["selected_source_steps"]
            source.update(source_step=selected_steps[-1], source_steps=selected_steps,
                          source_step_counts=sampling_audit["source_step_counts"], sampling_policy=SAMPLING_POLICY)
        request["fit"] = {"x": x[selected].tolist(), "y": y[selected].tolist(), "ids": selected_ids,
                          "source": source,
                          "center": domain.center.tolist(), "whitening": domain.whitening.tolist(),
                          "threshold": domain.threshold}
    return request, selected_ids, source, domain_reference


def fit_gated_candidate(parent,features,targets,allowance,*,trainable_policy="head_only",train_source_ids=None,gate_context=None,
                        operating_support=False,residual_source=None,stable_context=None,balanced_sampling=False,
                        stable_head_only=False,allow_single_probe_hit=False,low_rul_residual=False):
    from .official_model import OfficialModelAdapter
    if isinstance(parent,OfficialModelAdapter):parent=CGatedInputModel(CInputAdapterModel(parent))
    if isinstance(parent,CInputAdapterModel):parent=CGatedInputModel(parent)
    if not isinstance(parent,CGatedInputModel) or trainable_policy!="head_only" or parent.candidate_epochs!=2 or not 0<float(allowance)<=5:
        raise ValueError("gated experiment requires original two-epoch and five-second policy")
    started=time.perf_counter()
    if stable_context is None and isinstance(parent, CStableHeadModel):
        raise ValueError("the actual parent requires its original-domain head policy")
    if stable_context is not None and residual_source is None:
        raise ValueError("the original-domain head requires the NR-055 drift branch")
    if type(low_rul_residual) is not bool:
        raise ValueError("low-RUL residual opt-in must be explicit")
    low_rul_enabled = low_rul_residual or (parent.gate is not None and parent.gate.low_rul_residual is not None)
    if low_rul_enabled and (stable_context is None or not balanced_sampling or residual_source is None):
        raise ValueError("low-RUL residual requires the balanced C original-domain and NR-055 branches")
    if stable_head_only and (stable_context is None or not balanced_sampling):
        raise ValueError("an early original-domain fit requires released balanced history")
    if type(allow_single_probe_hit) is not bool or (allow_single_probe_hit and (
            not stable_head_only or stable_context.get("source_step") != 4)):
        raise ValueError("single probe hit allowance requires an early original-domain fit at step 5")
    if not operating_support and parent.gate is not None and parent.gate.operating_support is not None:
        raise ValueError("the actual parent requires its operating support module")
    if residual_source is None and parent.gate is not None and parent.gate.residual_calibration is not None:
        raise ValueError("the actual parent requires its residual calibration module")
    if residual_source is not None and (operating_support or len(features) != ROWS):
        raise ValueError("residual calibration requires the unchanged balanced gradient window")
    if train_source_ids is None or len(train_source_ids)!=len(features) or len(set(train_source_ids))!=len(train_source_ids):raise ValueError("gate requires distinct exact train source IDs")
    reference_source=load_reference(parent.package_path)
    if any(identity not in reference_source.group_for_id for identity in train_source_ids):raise ValueError("unknown gradient train source")
    context_x,context_ids=features,train_source_ids
    if gate_context is not None:
        if not isinstance(gate_context,dict) or set(gate_context)!={"x","ids"}:raise ValueError("gate context accepts inputs and IDs only")
        context_x,context_ids=matrix(gate_context["x"]),gate_context["ids"]
        if len(context_ids)!=len(context_x):raise ValueError("gate context source count mismatch")
    reference=reference_source.for_sources(context_ids)
    request={k:v.tolist() if isinstance(v,np.ndarray) else v for k,v in reference.items()}
    context_options={"gate_features":np.asarray(context_x).tolist()} if gate_context is not None else {}
    expected_support = None
    if operating_support:
        if len(features) != ROWS:
            raise ValueError("operating support requires the full balanced gradient window")
        settings = [row[3][-DIMENSIONS:] for row in reference_source.samples]
        mean, std = parent.mean[-DIMENSIONS:], parent.std[-DIMENSIONS:]
        distance = reference_distance(settings, mean, std)
        points = np.clip((matrix(features)[:, -DIMENSIONS:] - mean) / std, -10., 10.)
        ids_digest = hashlib.sha256("\n".join(train_source_ids).encode()).hexdigest()
        expected_support = OperatingSupport(points, distance, ids_digest, reference_source.source_sha256)
        context_options["operating_support"] = {"distance": distance, "gradient_ids_sha256": ids_digest}
    calibration_rows, calibration_source = None, None
    if residual_source is not None:
        calibration_rows, calibration_source = prepare_source(residual_source, train_source_ids,
            reference_source.group_for_id, reference_source.source_sha256)
        context_options["residual_calibration"] = {
            "x": calibration_rows["x"].tolist(), "y": calibration_rows["y"].tolist(), "source": calibration_source,
        }
    low_rul_source = None
    if low_rul_enabled:
        low_rul_source = {
            "rows": len(features), "source_step": calibration_source["gradient_source_step"],
            "ids_sha256": hashlib.sha256("\n".join(train_source_ids).encode()).hexdigest(),
            "inputs_sha256": array_digest(features), "targets_sha256": array_digest(targets),
            "train_sha256": reference_source.source_sha256,
        }
        context_options["low_rul_source"] = low_rul_source
    if stable_context is not None:
        gate_policy(parent.checkpoint_bytes, BALANCED_MODULE if balanced_sampling else STABLE_MODULE)
        stable_request, stable_ids, stable_source, domain_reference = _stable_fit_request(
            parent, stable_context, reference_source, train_source_ids, balanced_sampling=balanced_sampling)
        if stable_context["source_step"] != calibration_source["gradient_source_step"]:
            raise ValueError("original-domain training must use the latest released train step")
        context_options["stable_head"] = stable_request
    if stable_head_only:
        context_options["stable_head_only"] = True
    if allow_single_probe_hit:
        context_options["allow_single_probe_hit"] = True
    response=parent._invoke("fit",features,timeout=allowance,deadline=started+allowance,targets=np.asarray(targets,dtype=float).tolist(),
        allowance=float(allowance),reference=request,**context_options)
    if stable_head_only and "stable_head_unavailable" in response:
        audit = response["stable_head_unavailable"]
        counts = audit["screening_gate_counts"]
        eligible = screening_eligible(counts, allow_single_probe_hit=allow_single_probe_hit)
        if (counts[0] != len(stable_request["screening_x"])
                or audit["stable_eligible_rows"] != stable_request["eligible_rows"]
                or (stable_source is not None and eligible)):
            raise ValueError("worker returned an inconsistent original-domain eligibility check")
        if time.perf_counter() - started > allowance:
            raise TimeoutError("original-domain eligibility check exceeded allowance")
        raise StableHeadUnavailable(audit)
    raw=base64.b64decode(response["checkpoint"],validate=True)
    fit_audit = response["fit_audit"]
    branch_parent = getattr(parent, "routed_base", parent)
    drift = raw
    head = None
    if stable_context is not None:
        drift, head, outer = unpack_stable_checkpoint(raw)
        if (outer["parent_checkpoint_sha256"] != parent.checkpoint_sha256
                or MODULE_BY_FORMAT[outer["format"]] != (BALANCED_MODULE if balanced_sampling else STABLE_MODULE)):
            raise ValueError("original-domain candidate did not bind its actual parent")
        fit_audit["stable_domain_reference"] = domain_reference
        counts = fit_audit["screening_gate_counts"]
        if (counts[0] != len(stable_request["screening_x"])
                or fit_audit["stable_eligible_rows"] != stable_request["eligible_rows"]):
            raise ValueError("worker returned unexpected original-domain window counts")
        eligible = screening_eligible(counts, allow_single_probe_hit=allow_single_probe_hit)
        uses_stable = stable_source is not None and eligible
        if stable_head_only and not uses_stable:
            raise ValueError("early original-domain attempt returned a drift candidate")
        prior_head = getattr(parent, "stable_head", None)
        if uses_stable:
            previous_steps = parent.steps if prior_head is None else prior_head.steps
            previous_epochs = parent.epochs if prior_head is None else prior_head.epochs
            if (fit_audit["candidate_branch"] != "stable_head" or drift != branch_parent.checkpoint_bytes or head is None
                    or head.source != stable_source or head.audit != fit_audit["stable_head"]
                    or head.steps != previous_steps + 2 * math.ceil(STABLE_ROWS / _native_batch_size(parent.mlp.checkpoint_bytes))
                    or head.epochs != previous_epochs + 2):
                raise ValueError("original-domain candidate changed the drift branch or lost training state")
            fit_audit["stable_train_ids"] = stable_ids
            if balanced_sampling:
                fit_audit["stable_train_source_steps"] = stable_source["source_steps"]
                fit_audit["stable_sampling_audit"] = stable_request["sampling_audit"]
                fit_audit["stable_gradient_ids"] = list(train_source_ids)
                fit_audit["stable_gradient_groups"] = sorted({reference_source.group_for_id[i] for i in train_source_ids})
            child = CStableHeadModel(branch_parent, head, parent.checkpoint_sha256, raw)
        elif (fit_audit["candidate_branch"] != "drift_adapter"
                or (None if head is None else head.audit) != (None if prior_head is None else prior_head.audit)):
            raise ValueError("drift candidate changed the selected original-domain head")
    else:
        uses_stable = False
    if not uses_stable:
        child = _verify_gated_fit(drift, branch_parent, expected_support, calibration_source, calibration_rows, fit_audit,
                                  low_rul_source=low_rul_source)
        if stable_context is not None:
            child = CStableHeadModel(child, head, parent.checkpoint_sha256, raw)
    elapsed=time.perf_counter()-started
    if elapsed>allowance:raise TimeoutError("complete gated candidate exceeded allowance")
    child.last_fit_audit=fit_audit
    return child,elapsed


def _verify_gated_fit(raw, parent, expected_support, calibration_source, calibration_rows, fit_audit, *,
                      low_rul_source=None):
    from .official_model import OfficialModelAdapter

    adapter_raw,gate,meta=unpack_checkpoint(raw);core,module,ameta=unpack_adapter(adapter_raw)
    if core!=parent.mlp.checkpoint_bytes or meta["parent_checkpoint_sha256"]!=parent.checkpoint_sha256 or meta["gate_fits"]!=parent.gate_fits+1:
        raise ValueError("gate candidate changed frozen core or actual parent binding")
    returned_support = gate.operating_support.audit if gate.operating_support is not None else None
    expected_audit = expected_support.audit if expected_support is not None else None
    if returned_support != expected_audit or fit_audit.get("operating_support") != expected_audit:
        raise ValueError("worker returned operating support for the wrong observed window")
    calibration = gate.residual_calibration
    if calibration_source is not None:
        if (calibration is None or fit_audit.get("residual_calibration") != calibration.audit
                or any(calibration.audit[key] != value for key, value in calibration_source.items())):
            raise ValueError("worker returned residual calibration for the wrong observed window")
        fit_audit["residual_source_ids"] = calibration_rows["ids"]
    elif calibration is not None:
        raise ValueError("worker returned unrequested residual calibration")
    low_rul = gate.low_rul_residual
    if low_rul_source is not None:
        if (low_rul is None or low_rul.audit != fit_audit.get("low_rul_residual")
                or any(low_rul.audit[key] != value for key, value in low_rul_source.items())):
            raise ValueError("worker returned low-RUL residual for the wrong gradient window")
    elif low_rul is not None:
        raise ValueError("worker returned unrequested low-RUL residual")
    adapter=CInputAdapterModel(OfficialModelAdapter.from_state(parent.mlp.state()),module,parent_digest=ameta["parent_checkpoint_sha256"],checkpoint=adapter_raw)
    return CGatedInputModel(adapter,gate,parent_digest=meta["parent_checkpoint_sha256"],gate_fits=meta["gate_fits"],gate_audit=meta["gate_audit"],checkpoint=raw)


fit_gated_candidate.requires_train_source_ids=True
fit_gated_candidate.accepts_gate_context=True


def fit_supported_candidate(parent, features, targets, allowance, **options):
    return fit_gated_candidate(parent, features, targets, allowance, operating_support=True, **options)


fit_supported_candidate.requires_train_source_ids = True
fit_supported_candidate.accepts_gate_context = True


def fit_residual_calibrated_candidate(parent, features, targets, allowance, *, residual_source, **options):
    if residual_source is None:
        raise ValueError("residual calibration needs the preceding released train source")
    return fit_gated_candidate(parent, features, targets, allowance, residual_source=residual_source, **options)


fit_residual_calibrated_candidate.requires_train_source_ids = True
fit_residual_calibrated_candidate.accepts_gate_context = True
fit_residual_calibrated_candidate.accepts_residual_source = True


def fit_stable_head_candidate(parent, features, targets, allowance, *, stable_context, residual_source, **options):
    if stable_context is None or residual_source is None:
        raise ValueError("the original-domain head requires both released train sources")
    return fit_gated_candidate(parent, features, targets, allowance, stable_context=stable_context,
                               residual_source=residual_source, **options)


fit_stable_head_candidate.requires_train_source_ids = True
fit_stable_head_candidate.accepts_gate_context = True
fit_stable_head_candidate.accepts_residual_source = True
fit_stable_head_candidate.accepts_stable_context = True


def fit_balanced_stable_head_candidate(parent, features, targets, allowance, **options):
    return fit_stable_head_candidate(parent, features, targets, allowance, balanced_sampling=True, **options)


fit_balanced_stable_head_candidate.requires_train_source_ids = True
fit_balanced_stable_head_candidate.accepts_gate_context = True
fit_balanced_stable_head_candidate.accepts_residual_source = True
fit_balanced_stable_head_candidate.accepts_stable_context = True
fit_balanced_stable_head_candidate.accepts_stable_history = True


def fit_low_rul_stable_head_candidate(parent, features, targets, allowance, **options):
    return fit_stable_head_candidate(parent, features, targets, allowance,
                                     balanced_sampling=True, low_rul_residual=True, **options)


fit_low_rul_stable_head_candidate.requires_train_source_ids = True
fit_low_rul_stable_head_candidate.accepts_gate_context = True
fit_low_rul_stable_head_candidate.accepts_residual_source = True
fit_low_rul_stable_head_candidate.accepts_stable_context = True
fit_low_rul_stable_head_candidate.accepts_stable_history = True
