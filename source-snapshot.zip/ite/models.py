"""Small standardized ridge baselines; persistence never enables pickle."""

from pathlib import Path

import numpy as np


def normalize_sample_weight(sample_weight, sample_count):
    """Validate nonnegative weights and normalize to mean one without sum overflow."""
    if sample_weight is None:
        return None
    weights = np.asarray(sample_weight, dtype=float)
    if (weights.shape != (sample_count,) or sample_count == 0 or
            not np.isfinite(weights).all() or np.any(weights < 0) or not np.any(weights > 0)):
        raise ValueError("Sample weights must be a matching finite nonnegative vector with positive sum")
    scaled = weights / weights.max()
    return scaled * (sample_count / scaled.sum())


def prediction_loss(task, targets, predictions, scale=1.0):
    targets, predictions = np.asarray(targets), np.asarray(predictions)
    if targets.shape != predictions.shape or targets.size == 0:
        raise ValueError("Targets and predictions must have matching nonempty shapes")
    if task == "classification":
        return float(np.mean(targets != predictions))
    if task != "regression" or scale <= 0:
        raise ValueError("Invalid loss task or normalization scale")
    return float(np.mean((targets - predictions) ** 2) / scale)


class RidgeModel:
    def __init__(self, task="classification", alpha=1.0, family="ridge"):
        if task not in ("classification", "regression") or not np.isfinite(alpha) or alpha <= 0:
            raise ValueError("Unsupported task or nonpositive alpha")
        self.task, self.alpha = task, float(alpha)
        if family not in ("ridge", "quadratic"):
            raise ValueError("Unsupported model family")
        self.family = family

    def _basis(self, standardized):
        if self.family == "ridge":
            return standardized
        n = standardized.shape[1]
        interactions = [standardized[:, i] * standardized[:, j] for i in range(n) for j in range(i + 1, n)]
        return np.column_stack((standardized, standardized ** 2, *interactions))

    def fit(self, features, targets, sample_weight=None):
        x, y = np.asarray(features, dtype=float), np.asarray(targets, dtype=float)
        if x.ndim != 2 or y.shape != (len(x),) or len(x) < 2:
            raise ValueError("Training needs a feature matrix and a matching target vector")
        if not np.isfinite(x).all() or not np.isfinite(y).all():
            raise ValueError("Training data must be finite")
        if self.task == "classification" and not np.isin(y, [0, 1]).all():
            raise ValueError("The local classification baseline supports binary labels 0/1")
        weights = normalize_sample_weight(sample_weight, len(x))
        # Equal weights use the original numerical path, including exact checkpoints.
        if weights is not None and np.all(weights == weights[0]):
            weights = None
        if weights is None:
            self.mean, self.std = x.mean(axis=0), x.std(axis=0)
        else:
            self.mean = np.average(x, axis=0, weights=weights)
            self.std = np.sqrt(np.average((x - self.mean) ** 2, axis=0, weights=weights))
        self.std = np.where(self.std < 1e-10, 1.0, self.std)
        basis = self._basis((x - self.mean) / self.std)
        self.basis_mean = ((basis.mean(axis=0) if weights is None else
                            np.average(basis, axis=0, weights=weights))
                           if self.family == "quadratic" else np.zeros(x.shape[1]))
        standardized = basis - self.basis_mean
        self.intercept = float(y.mean() if weights is None else np.average(y, weights=weights))
        if weights is None:
            matrix = standardized.T @ standardized + self.alpha * np.eye(standardized.shape[1])
            self.weights = np.linalg.solve(matrix, standardized.T @ (y - self.intercept))
        else:
            # Row scaling is O(NP), with no N-by-N diagonal allocation. Centering
            # separates the unpenalized intercept from the ridge coefficients.
            root = np.sqrt(weights)
            design = standardized * root[:, None]
            matrix = design.T @ design + self.alpha * np.eye(design.shape[1])
            self.weights = np.linalg.solve(matrix, design.T @ ((y - self.intercept) * root))
        return self

    def _scores(self, features):
        x = np.asarray(features, dtype=float)
        if x.ndim != 2 or x.shape[1] != len(self.mean) or not np.isfinite(x).all():
            raise ValueError("Prediction features have invalid shape or nonfinite values")
        return (self._basis((x - self.mean) / self.std) - self.basis_mean) @ self.weights + self.intercept

    def predict(self, features):
        scores = self._scores(features)
        return (scores >= 0.5).astype(int) if self.task == "classification" else scores

    def predict_proba(self, features):
        if self.task != "classification":
            raise ValueError("Regression has no class probabilities")
        positive = np.clip(self._scores(features), 0, 1)
        return np.column_stack((1 - positive, positive))

    def state(self):
        return {"task": self.task, "alpha": self.alpha, "family": self.family,
                "basis_mean": self.basis_mean.tolist(), "mean": self.mean.tolist(),
                "std": self.std.tolist(), "weights": self.weights.tolist(), "intercept": self.intercept}

    @classmethod
    def from_state(cls, state):
        model = cls(str(state["task"]), float(state["alpha"]), str(state.get("family", "ridge")))
        for name in ("mean", "std", "weights"):
            setattr(model, name, np.asarray(state[name], dtype=float))
        model.intercept = float(state["intercept"])
        model.basis_mean = np.asarray(state.get("basis_mean", np.zeros(len(model.weights))), dtype=float)
        n = len(model.mean)
        size = n if model.family == "ridge" else n * (n + 3) // 2
        arrays = (model.mean, model.std, model.weights, model.basis_mean)
        if (n < 1 or model.mean.shape != (n,) or model.std.shape != (n,) or
                model.weights.shape != (size,) or model.basis_mean.shape != (size,) or
                not all(np.isfinite(value).all() for value in arrays) or
                np.any(model.std <= 0) or not np.isfinite(model.intercept)):
            raise ValueError("Invalid model checkpoint dimensions, scaling or coefficients")
        return model

    def save(self, path):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("wb") as stream:
            np.savez_compressed(stream, **self.state())

    @classmethod
    def load(cls, path):
        with np.load(path, allow_pickle=False) as values:
            return cls.from_state({name: values[name].tolist() for name in values.files})
