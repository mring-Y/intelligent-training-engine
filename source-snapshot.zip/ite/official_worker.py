"""One-request worker that imports official packages under NumPy 1.26.4."""

import base64
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import zipfile


MAX_REQUEST_BYTES = 32 * 1024 * 1024
MAX_CHECKPOINT_BYTES = 16 * 1024 * 1024
PROFILES = {
    "A": {"task": "classification", "features": 128, "classes": 6, "parameters": 4326,
          "target_unit": None},
    "B": {"task": "regression", "features": 34, "classes": 0, "parameters": 865,
          "target_unit": "minutes"},
    "C": {"task": "regression", "features": 24, "classes": 0, "parameters": 833,
          "target_unit": "cycles"},
}


def _response(value):
    sys.stdout.write(json.dumps({"ok": True, **value}, allow_nan=False, separators=(",", ":")))
    sys.stdout.flush()


def _checkpoint_bytes(value):
    if not isinstance(value, str) or len(value) > MAX_CHECKPOINT_BYTES * 2:
        raise ValueError("Invalid checkpoint payload")
    data = base64.b64decode(value, validate=True)
    if not 1 <= len(data) <= MAX_CHECKPOINT_BYTES:
        raise ValueError("Checkpoint exceeds the size limit")
    return data


def _package_info(package_path, profile_type):
    contract = PROFILES.get(profile_type)
    if contract is None:
        raise ValueError("Unknown official profile_type")
    try:
        with zipfile.ZipFile(package_path) as archive:
            info = json.loads(archive.read("baseline-info.json").decode("utf-8"))
    except (KeyError, OSError, zipfile.BadZipFile, UnicodeError, json.JSONDecodeError) as error:
        raise ValueError("Official package metadata is missing or invalid") from error
    if (info.get("dataset_key") != profile_type or info.get("task") != contract["task"] or
            info.get("parameter_count") != contract["parameters"]):
        raise ValueError("Official package baseline-info does not match profile_type")
    return info, contract


def _model(package_path, checkpoint):
    with tempfile.TemporaryDirectory(prefix="ite-official-") as temporary:
        path = Path(temporary) / "checkpoint.npz"
        path.write_bytes(checkpoint)
        sys.path.insert(0, str(package_path))
        from baselines.model import Model
        model = Model.load(path)
    return model


def _metadata(model, numpy_version, profile_type, contract):
    return {"numpy_version": numpy_version, "profile_type": profile_type,
            "task": model.meta["task"], "classes": model.meta["classes"],
            "feature_count": len(model.meta["paths"]), "target_unit": contract["target_unit"],
            "mean": model.mean.tolist(), "scale": model.scale.tolist(),
            "steps": model.meta["steps"], "epochs": model.meta["epochs"],
            "parameter_count": model.meta["parameter_count"]}


def _validate_model(model, profile_type, contract):
    metadata_profile = model.meta.get("profile")
    if (model.meta.get("task") != contract["task"] or
            len(model.meta.get("paths", ())) != contract["features"] or
            model.meta.get("parameter_count") != contract["parameters"] or
            len(model.meta.get("classes", ())) != contract["classes"] or
            (metadata_profile is not None and metadata_profile != profile_type)):
        raise ValueError("Official checkpoint task, profile, feature dimension or parameters do not match")
    if profile_type == "B" and model.meta.get("target_unit", "minutes") != "minutes":
        raise ValueError("Official B checkpoint target unit must be minutes")


def handle(request, package_path):
    if not package_path.is_file() or package_path.is_symlink():
        raise ValueError("Official baseline package must be a regular file")
    import numpy as np

    if request.get("operation") == "version":
        return {"numpy_version": np.__version__}
    operation = request.get("operation")
    if operation not in ("inspect", "predict", "fit"):
        raise ValueError("Unsupported official worker operation")
    profile_type = request.get("profile_type")
    info, contract = _package_info(package_path, profile_type)
    checkpoint = _checkpoint_bytes(request.get("checkpoint"))
    correction = None
    if profile_type == "A":
        sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
        from ite.a_acetaldehyde_gate import is_acetaldehyde_checkpoint, pack_checkpoint, predict_scores, unpack_checkpoint
        if is_acetaldehyde_checkpoint(checkpoint):
            checkpoint, state, threshold = unpack_checkpoint(checkpoint)
            correction = (state, threshold)
    model = _model(package_path, checkpoint)
    _validate_model(model, profile_type, contract)
    if operation == "inspect":
        return _metadata(model, np.__version__, profile_type, contract)
    if request.get("task") != model.meta["task"]:
        raise ValueError("Task does not match the official checkpoint")
    x = np.asarray(request.get("features"), dtype=np.float64)
    if x.ndim != 2 or x.shape[1] != contract["features"] or not np.isfinite(x).all():
        raise ValueError("Feature matrix does not match the official checkpoint")
    if operation == "predict":
        if correction is None:
            predictions = np.asarray([model.predict(row.reshape(1, -1))[0] for row in x], dtype=np.float64)
        else:
            predictions = np.asarray([predict_scores(model, row.reshape(1, -1), *correction)[0] for row in x])
        expected_shape = (len(x), contract["classes"]) if model.meta["task"] == "classification" else (len(x),)
        if predictions.shape != expected_shape or not np.isfinite(predictions).all():
            raise ValueError("Official model returned invalid predictions")
        if model.meta["task"] == "regression" and np.any(predictions < 0):
            raise ValueError("Official regression predictions must be nonnegative")
        return {"numpy_version": np.__version__, "predictions": predictions.tolist()}
    y = np.asarray(request.get("targets"))
    epochs = request.get("epochs")
    valid_target_dtype = y.dtype.kind in ("iu" if model.meta["task"] == "classification" else "iuf")
    valid_targets = (valid_target_dtype and np.isfinite(y).all() and
                     (np.isin(y, np.arange(len(model.meta["classes"]))).all()
                      if model.meta["task"] == "classification" else np.all(y >= 0)))
    if (y.shape != (len(x),) or type(epochs) is not int or not 1 <= epochs <= 20 or not valid_targets):
        raise ValueError("Official resume targets or epoch count are invalid")
    trainable_policy = request.get("trainable_policy", "full")
    loss_policy = request.get("loss_policy", "squared")
    from official_finetune import fit_with_audit, LOSS_POLICIES, C_REFERENCE_SHA256
    if loss_policy not in LOSS_POLICIES:
        raise ValueError("Unsupported official loss_policy")
    if loss_policy != "squared" and (profile_type != "C" or trainable_policy != "head_only" or
                                      model.meta["task"] != "regression"):
        raise ValueError("Alternative loss requires official C head_only regression")
    reference, reference_digest = None, None
    if loss_policy == "official_anchor_l2":
        with zipfile.ZipFile(package_path) as archive:
            raw_reference = archive.read("checkpoint.npz")
        reference_digest = hashlib.sha256(raw_reference).hexdigest()
        if reference_digest != C_REFERENCE_SHA256 or info["checkpoint_sha256"] != "sha256:"+reference_digest:
            raise ValueError("Fixed official reference checkpoint digest mismatch")
        reference = _model(package_path, raw_reference)
    audit = fit_with_audit(model, x,
        y.astype(np.int64 if model.meta["task"] == "classification" else np.float64),
        epochs, trainable_policy, loss_policy, reference=reference, reference_sha256=reference_digest)
    with tempfile.TemporaryDirectory(prefix="ite-official-fit-") as temporary:
        path = Path(temporary) / "candidate.npz"
        model.save(path)
        updated = path.read_bytes()
    if correction is not None:
        updated = pack_checkpoint(updated, *correction)
    return {**_metadata(model, np.__version__, profile_type, contract),
            "checkpoint": base64.b64encode(updated).decode("ascii"), "fit_audit": audit}


def main():
    if len(sys.argv) != 2:
        raise SystemExit("expected the official baseline package ZIP path")
    for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
        os.environ[name] = "1"
    package_path = Path(sys.argv[1]).resolve()
    raw = sys.stdin.buffer.read(MAX_REQUEST_BYTES + 1)
    if len(raw) > MAX_REQUEST_BYTES:
        raise SystemExit("request exceeds the size limit")
    try:
        request = json.loads(raw.decode("utf-8"))
        if not isinstance(request, dict):
            raise ValueError("Request must be a JSON object")
        _response(handle(request, package_path))
    except Exception as error:
        sys.stderr.write(f"{type(error).__name__}: {error}\n")
        raise SystemExit(2)


if __name__ == "__main__":
    main()
