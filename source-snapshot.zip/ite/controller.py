"""Finite candidate selection, postdeployment rollback, and bounded policy adaptation."""

import time

import numpy as np

from .budget import ResourceBudget
from .budget_guard import BudgetGuard
from .config import HEURISTIC_C_EPOCHS
from .decision import Advice, DecisionAdvisor, LocalMockProvider
from .harness import MockLLMClient, validate_observation
from .models import normalize_sample_weight, prediction_loss
from .monitor import DriftMonitor
from .official_model import is_official_model_type


def _recent_disjoint_masks(history_samples, requested_validation):
    """Partition released entities by position, reserving the newest for fitting."""
    validation = np.zeros(history_samples, dtype=bool)
    count = min(requested_validation, max(0, history_samples - 1))
    if count:
        start = max(0, history_samples - 2 * requested_validation)
        indices = np.linspace(start, history_samples - 2, count, dtype=int)
        validation[indices] = True
    return ~validation, validation


class DeploymentGate:
    def __init__(self, model, min_gain, rollback_margin, min_rollback_samples, scale=1.0):
        self.model, self.previous = model, None
        self.min_gain, self.rollback_margin = min_gain, rollback_margin
        self.min_rollback_samples, self.scale = min_rollback_samples, scale
        self.version, self.updates, self.rollbacks = 0, 0, 0
        self.deployed_at = -1
        self.archive = [model]
        self._rollback_x, self._rollback_y = None, None

    def consider(self, candidate, features, targets, step):
        old_loss = prediction_loss(self.model.task, targets, self.model.predict(features), self.scale)
        new_loss = prediction_loss(candidate.task, targets, candidate.predict(features), self.scale)
        gain = old_loss - new_loss
        accepted = gain >= self.min_gain and gain > 0
        if accepted:
            self.previous, self.model = self.model, candidate
            self.version += 1
            self.updates += 1
            self.deployed_at = step
            if not any(candidate is item for item in self.archive):
                self.archive.append(candidate)
            # Keep the original static model and at most three recent snapshots.
            self.archive = [self.archive[0], *self.archive[1:][-3:]]
            self._rollback_x, self._rollback_y = None, None
        return {"accepted": bool(accepted), "incumbent_loss": old_loss, "candidate_loss": new_loss,
                "validation_gain": gain, "model_version": self.version}

    def check_rollback(self, features, targets, source_steps, step):
        alternatives = [item for item in self.archive if item is not self.model]
        if not alternatives:
            return None
        valid = np.asarray(source_steps) > self.deployed_at
        if not np.any(valid):
            return None
        x, y = features[valid], targets[valid]
        self._rollback_x = x.copy() if self._rollback_x is None else np.concatenate((self._rollback_x, x))
        self._rollback_y = y.copy() if self._rollback_y is None else np.concatenate((self._rollback_y, y))
        limit = self.min_rollback_samples * 2
        self._rollback_x, self._rollback_y = self._rollback_x[-limit:], self._rollback_y[-limit:]
        count = len(self._rollback_y)
        if count < self.min_rollback_samples:
            return None
        x, y = self._rollback_x, self._rollback_y
        current = prediction_loss(self.model.task, y, self.model.predict(x), self.scale)
        restored = min(alternatives, key=lambda item: prediction_loss(item.task, y, item.predict(x), self.scale))
        previous = prediction_loss(restored.task, y, restored.predict(x), self.scale)
        if current > previous + self.rollback_margin:
            self.previous, self.model = self.model, restored
            self.version += 1
            self.rollbacks += 1
            self.deployed_at = step
            self._rollback_x, self._rollback_y = None, None
            return {"reason": "archived_model_better_on_postdeployment_labels", "current_loss": current,
                    "previous_loss": previous, "samples": count, "model_version": self.version}
        return None


class WindowPolicy:
    def __init__(self, windows, enabled=False):
        self.windows, self.enabled = tuple(windows), enabled
        self._rewards = {window: [] for window in windows}
        self._round = 0

    def choose(self):
        self._round += 1
        if not self.enabled or any(not values for values in self._rewards.values()):
            return self.windows
        best = max(self.windows, key=lambda w: np.mean(self._rewards[w]))
        explore = self.windows[(self._round - 1) % len(self.windows)]
        return tuple(dict.fromkeys((best, explore)))

    def record(self, window, gain, seconds):
        if window not in self._rewards:
            raise ValueError("Window is outside the permitted policy range")
        # Deterministic cost proxy avoids adapting differently due to OS timer jitter.
        self._rewards[window].append(float(gain) / window)


class _DecisionLogger:
    """Attach causal IDs during a synchronous action, without changing legacy logs."""

    def __init__(self, logger):
        self.logger, self.context = logger, {}

    def event(self, event, step, **values):
        self.logger.event(event, step, **{**self.context, **values})


class AdaptationController:
    def __init__(self, config, policy, model, baseline_loss, scale, logger, trainer, output_dir,
                 *, active_model_type=None):
        self.config, self.policy = config, policy
        self.active_model_type = active_model_type or config.model_type
        self.active_model_family = (config.model_family if self.active_model_type in ("tree", "official", "official_mlp")
                                    else model.family)
        self.logger = _DecisionLogger(logger)
        self._decision_serial = 0
        self.trainer, self.output_dir = trainer, output_dir
        self.budget = ResourceBudget(config, model_type=self.active_model_type)
        self.gate = DeploymentGate(model, config.min_gain, config.rollback_margin,
                                   config.min_validation, scale)
        self.monitor = DriftMonitor(config, model.mean, model.std, baseline_loss)
        self.window_policy = WindowPolicy(config.history_windows, config.strategy_adaptation and policy == "drift")
        self.history_x = np.empty((0, config.n_features))
        self.history_y = np.empty(0)
        self.history_steps = np.empty(0, dtype=int)
        self.last_experiment = -config.cooldown - 1
        self.last_experiment_source = -1
        self.scale, self.detections = scale, 0
        self.pending = None
        self.candidate_serial = self.history_reuses = 0
        self.evaluation_seconds = 0.0
        self.checkpoint_seconds = 0.0
        self.detection_steps = []
        self.failed_reuses = set()
        self.performance_drop_active = False
        self.label_availability = None
        self.advisor = DecisionAdvisor(LocalMockProvider() if config.decision_backend == "mock" else None)
        self.candidate_waits = []
        self.pending_expired = self.pending_uncollectable = self.label_infeasible_skips = 0
        self.training_preflight_skips = 0
        self._label_release_revision = 0
        self._last_training_preflight_evidence = None
        self.training_ess_audit_count = 0
        self.training_ess_sum = 0.0
        self.training_ess_min = self.training_ess_max = None
        ledger = None
        if config.harness_enabled and policy == "drift" and config.harness_backend == "pytrio":
            from .llm_ledger import CallLedger
            ledger = CallLedger(config.llm_ledger_path,
                identity=f"pytrio:{config.llm_model}:{config.llm_prompt_profile}:ledger-v1")
        action_profile = "official_finetune" if is_official_model_type(self.active_model_type) else "default"
        if is_official_model_type(self.active_model_type) and getattr(model, "profile_type", None) == "C":
            action_profile = "official_c_calibration"
        self.budget_guard = BudgetGuard(self.budget, self.logger, ledger=ledger, action_profile=action_profile) if config.harness_enabled and policy == "drift" else None
        model_options = {"model_type": self.active_model_type} if self.active_model_type != "ridge" else {}
        mock_mode = config.harness_mock_mode
        if mock_mode in ("head_only", "calibrate_down") and action_profile == "default":
            mock_mode = "normal"
        mock_options = dict(model_options)
        if is_official_model_type(self.active_model_type):
            mock_options["profile_type"] = getattr(model, "profile_type", None)
        self.llm_client = MockLLMClient(mock_mode, **mock_options) if self.budget_guard else None
        if ledger is not None:
            from .trio_client import TrioLLMClient
            self.llm_client = TrioLLMClient(model=config.llm_model,
                max_input_tokens=config.llm_max_input_tokens, max_output_tokens=config.llm_max_output_tokens,
                timeout_seconds=config.llm_timeout_seconds, tokenizer_path=config.llm_tokenizer_path,
                input_price_per_million=config.llm_input_price_per_million,
                output_price_per_million=config.llm_output_price_per_million,
                prompt_profile=config.llm_prompt_profile, **model_options)
        self._loss_trend = {}
        self._risk_residuals = np.empty(0)
        self._calibration_sources = {}
        self._model_age_batches = 0
        self._last_harness_evidence = None
        self._last_llm_call_step = -config.cooldown - 1
        self._fallback_recorded = False
        self._a_replay_reserve = None

    @property
    def cooldown_until(self):
        return max(0, self.last_experiment + self.config.cooldown + 1)

    def predict(self, features):
        prediction = self.gate.model.predict(features)
        if self.budget_guard:
            self._model_age_batches += 1
        return prediction

    def activate_fallback(self, model, model_type, baseline_loss, step, failure_reason, attempts):
        if model_type not in ("tree", "ridge"):
            raise ValueError("Official model fallback must select Tree or Ridge")
        if self.pending is not None:
            self._reject_pending(step, "official_model_fallback")
        failed_type = self.active_model_type
        self.gate.model, self.gate.previous = model, None
        self.gate.archive = [model]
        self.gate.version += 1
        self.gate.deployed_at = step - 1
        self.gate._rollback_x = self.gate._rollback_y = None
        self.active_model_type = model_type
        self.active_model_family = "ridge" if model_type == "tree" else model.family
        self.budget.model_type = model_type
        if self.budget_guard:
            self.budget_guard.action_profile = "default"
        self.monitor = DriftMonitor(self.config, model.mean, model.std, baseline_loss)
        self._risk_residuals = np.empty(0)
        self._calibration_sources.clear()
        if self.llm_client is not None and hasattr(self.llm_client, "model_type"):
            self.llm_client.model_type = "tree" if model_type == "tree" else "ridge"
            if isinstance(self.llm_client, MockLLMClient) and self.llm_client.mode in ("head_only", "calibrate_down"):
                self.llm_client.mode = "normal"
        self.logger.event("model_fallback", step, requested_model_type=self.config.model_type,
            failed_model_type=failed_type, failure_reason=failure_reason,
            fallback_model_type=model_type, attempts=attempts, model_version=self.gate.version)

    def allow_label_request(self, step):
        if self.budget_guard is None or self.budget_guard.check(step):
            return True
        if self.pending is not None:
            self._reject_pending(step, "budget_guard_static_fallback")
        if not self._fallback_recorded:
            self.logger.event("harness_static_fallback", step, model_version=self.gate.version,
                              **self.budget_guard.snapshot(), **self.budget.snapshot())
            self._fallback_recorded = True
        self.performance_drop_active = False
        return False

    def harness_observation(self, drift_alarm):
        value = {
            "loss_trend": [{"source_step": source, "loss": total / count, "labeled_samples": count}
                           for source, (total, count) in sorted(self._loss_trend.items())],
            "drift_alarm": drift_alarm,
            "remaining_label_budget": self.budget.remaining_label_budget,
            "remaining_token_budget": self.config.max_tokens - self.budget.tokens,
            "model_age_batches": self._model_age_batches}
        if self.budget_guard.action_profile == "official_c_calibration" and len(self._risk_residuals):
            value.update(overestimate_rate=float(np.mean(self._risk_residuals > 0)),
                         mean_overestimate=float(np.mean(np.maximum(self._risk_residuals, 0))))
        validate_observation(value, task=self.config.task)
        return value

    def _record_harness_losses(self, losses, source_steps, *, overestimation_residuals=None):
        for source in np.unique(source_steps):
            values = losses[source_steps == source]
            total, count = self._loss_trend.get(int(source), (0.0, 0))
            self._loss_trend[int(source)] = (total + float(np.sum(values)), count + len(values))
        self._loss_trend = {source: self._loss_trend[source] for source in sorted(self._loss_trend)[-5:]}
        if self.budget_guard.action_profile == "official_c_calibration" and overestimation_residuals is not None:
            residuals = np.asarray(overestimation_residuals, dtype=float)
            if residuals.shape != losses.shape or not np.isfinite(residuals).all():
                raise ValueError("Released overestimation residuals must match loss evidence")
            order = np.argsort(source_steps, kind="stable")
            self._risk_residuals = np.concatenate((self._risk_residuals, residuals[order]))[-48:]

    def _harness_decide(self, step, evidence):
        if not self.allow_label_request(step) or self.pending is not None:
            return
        if len(self.history_y) < self.config.min_labeled or step < self.cooldown_until:
            return
        if self.config.harness_drift_only:
            if (not evidence["performance_drop"] or step <= self._last_llm_call_step + self.config.cooldown or
                    not self._can_validate(step, step) or
                    self.budget.experiments >= self.config.max_experiments or self.budget.training_allowance() <= 0):
                return
        latest = int(self.history_steps.max())
        key = (self._label_release_revision, latest, self.gate.version)
        if latest <= self.last_experiment_source or key == self._last_harness_evidence:
            return
        self._last_harness_evidence = key
        observation = self.harness_observation(evidence["performance_drop"])
        self._decision_serial += 1
        self.logger.context = {"decision_id": f"decision-{self._decision_serial}"}
        try:
            self.logger.event("harness_observation", step, observation=observation)
            self._last_llm_call_step = step
            action = self.budget_guard.get_decision(observation, self.llm_client, step)
            if not self.allow_label_request(step) or action is None:
                return
            self.logger.event("harness_decision", step, action=action.action, reason=action.reason,
                              observation=observation, **self.budget_guard.snapshot())
            if self.config.heuristic_override:
                from .heuristic_override import choose_heuristic_action
                effective = choose_heuristic_action(action, observation,
                    profile=getattr(self.gate.model,"profile_type",None) if is_official_model_type(self.active_model_type) else None,
                    remaining_train_seconds=self.budget.training_allowance(),
                    experiments_remaining=self.config.max_experiments-self.budget.experiments)
                if effective is not action:
                    self.logger.event("heuristic_override",step,original_action=action.action,
                        effective_action=effective.action,reason=effective.reason,observation=observation,
                        **self.budget.snapshot())
                action = effective
            if action.action == "DO_NOTHING":
                return
            self.logger.context["attempt_id"] = f"attempt-{self._decision_serial}"
            if not self._can_validate(step, step):
                self.logger.event("harness_action_rejected", step, action=action.action,
                                  reason="independent_labels_unavailable")
                return
            if action.action == "ROLLBACK":
                self._harness_rollback(step)
            elif action.action == "RETRAIN_REPLAY":
                if getattr(self.gate.model,"profile_type",None) != "A" or not self._head_profile_supported():
                    self.logger.event("harness_action_rejected",step,action=action.action,reason="official_replay_profile_mismatch")
                    return
                self._experiment(step,evidence,windows=(768,),a_replay=True)
            elif action.action in ("RETRAIN_HEAD_ONLY", "CALIBRATE_DOWN"):
                if not self._head_profile_supported(calibrate_down=action.action == "CALIBRATE_DOWN"):
                    self.logger.event("harness_action_rejected", step, action=action.action,
                                      reason="official_head_profile_mismatch")
                    return
                self._experiment(step, evidence, windows=(max(self.config.history_windows),),
                                 trainable_policy="head_only", calibrate_down=action.action == "CALIBRATE_DOWN")
            else:
                windows = ((min(self.config.history_windows),) if action.action == "RETRAIN_SMALL"
                           else self.config.history_windows)
                self._experiment(step, evidence, windows=windows)
        finally:
            self.logger.context = {}

    def _harness_rollback(self, step):
        candidate = self.gate.previous
        if candidate is None or candidate is self.gate.model:
            self.logger.event("harness_action_rejected", step, action="ROLLBACK", reason="no_previous_snapshot")
            return
        count = max(self.config.min_validation, 64)
        x, y = self.history_x[-count:], self.history_y[-count:]
        started = time.perf_counter()
        old_loss = prediction_loss(self.config.task, y, self.gate.model.predict(x), self.scale)
        loss = prediction_loss(self.config.task, y, candidate.predict(x), self.scale)
        self.evaluation_seconds += time.perf_counter() - started
        if old_loss - loss < self.config.min_gain or old_loss <= loss:
            self.logger.event("harness_action_rejected", step, action="ROLLBACK", reason="not_better_on_selection")
            return
        if not self.budget.start_experiment(needs_training=False):
            self.logger.event("harness_action_rejected", step, action="ROLLBACK", reason="budget_exhausted")
            return
        self.logger.event("experiment_started", step, diagnosis="harness_rollback_selection", candidate_kind="rollback")
        self._freeze(candidate, step, {"candidate_kind": "rollback", "selection_loss": loss})

    def observe(self, batch, released, historical_predictions, label_availability=None):
        self.label_availability = label_availability
        if not self.allow_label_request(batch.step):
            return
        if self.pending is not None and batch.step > self._deadline(self.pending["frozen_at"]):
            self._reject_pending(batch.step, "independent_validation_deadline")
        distance = self.monitor.observe_features(batch.features)
        if released is not None:
            self._label_release_revision += 1
            previous_predictions = np.asarray([historical_predictions[int(i)] for i in released.sample_ids])
            losses = ((previous_predictions != released.targets).astype(float) if self.config.task == "classification"
                      else (previous_predictions - released.targets) ** 2 / self.scale)
            # Delayed predictions from a replaced deployment must not diagnose the new one.
            current_deployment = released.source_steps > self.gate.deployed_at
            self.monitor.observe_losses(losses[current_deployment])
            if self.budget_guard:
                self._record_harness_losses(losses[current_deployment], released.source_steps[current_deployment],
                    overestimation_residuals=(previous_predictions-released.targets)[current_deployment]
                        if self.config.task == "regression" else None)
            if (is_official_model_type(self.active_model_type) and
                    getattr(self.gate.model, "profile_type", None) == "C"):
                for source in np.unique(released.source_steps):
                    mask = released.source_steps == source
                    old = self._calibration_sources.get(int(source))
                    values = (released.features[mask], released.targets[mask], released.sample_ids[mask])
                    if old is not None:
                        values = tuple(np.concatenate((a, b)) for a, b in zip(old, values))
                    self._calibration_sources[int(source)] = tuple(value[-48:].copy() for value in values)
            self.history_x = np.concatenate((self.history_x, released.features))
            self.history_y = np.concatenate((self.history_y, released.targets))
            self.history_steps = np.concatenate((self.history_steps, released.source_steps))
            order = np.argsort(self.history_steps, kind="stable")
            keep = order[-max(self.config.history_windows):]
            self.history_x, self.history_y, self.history_steps = (
                self.history_x[keep], self.history_y[keep], self.history_steps[keep])
            if self._calibration_sources and len(self.history_steps):
                oldest = int(self.history_steps.min()) - 1
                self._calibration_sources = {source: values for source, values in self._calibration_sources.items()
                                             if source >= oldest}
            # The legacy comparison retains the original rolling rollback behavior.
            # Future mode sends EVERY model change, including archive reuse, through
            # a frozen candidate and a separate set of subsequently generated labels.
            rollback = (self.gate.check_rollback(released.features, released.targets,
                                                released.source_steps, batch.step)
                        if self.config.deployment_validation == "legacy" else None)
            if rollback:
                self.logger.event("rollback", batch.step, **rollback)
                self._save_deployment()
                self.last_experiment = batch.step
            if self.pending is not None:
                self._validate_pending(released, batch.step)
        if self.pending is not None:
            count = sum(len(y) for y in self.pending["y"])
            if batch.step >= self._deadline(self.pending["frozen_at"]):
                self._reject_pending(batch.step, "independent_validation_deadline")
            elif not self._can_validate(self.pending["frozen_at"], batch.step, count):
                self._reject_pending(batch.step, "independent_labels_unavailable")
        evidence = self.monitor.evidence(distance)
        self.logger.event("monitor", batch.step, **evidence)
        if self.policy == "drift":
            if evidence["performance_drop"] and not self.performance_drop_active:
                self.detections += 1
                self.detection_steps.append(batch.step)
                self.logger.event("drift_detected", batch.step, **evidence)
            self.performance_drop_active = evidence["performance_drop"]
        if self.pending is not None:
            return
        if self.budget_guard:
            self._harness_decide(batch.step, evidence)
            return
        trigger = (self.policy == "periodic" and (batch.step + 1) % self.config.update_interval == 0 or
                   self.policy == "drift" and evidence["performance_drop"])
        fresh_labels = len(self.history_steps) > 0 and self.history_steps.max() > self.last_experiment_source
        minimum = self.config.min_validation if self.config.reuse_history and self.policy == "drift" else self.config.min_labeled
        if trigger and fresh_labels and len(self.history_y) >= minimum:
            if batch.step - self.last_experiment > self.config.cooldown:
                if self.config.deployment_validation == "future" and not self._can_validate(batch.step, batch.step):
                    self.label_infeasible_skips += 1
                    self.last_experiment, self.last_experiment_source = batch.step, int(self.history_steps.max())
                    self.logger.event("experiment_skipped", batch.step, reason="independent_labels_unavailable",
                                      **self.budget.snapshot())
                    return
                if self.config.reuse_history and self.policy == "drift" and self._reuse_history(batch.step):
                    return
                if len(self.history_y) >= self.config.min_labeled:
                    self._experiment(batch.step, evidence)

    def _deadline(self, frozen_at):
        wait = self.config.candidate_max_wait_batches
        return frozen_at + wait if wait is not None else self.config.n_batches

    def _can_validate(self, frozen_at, step, collected=0):
        if not self.config.candidate_feasibility or self.label_availability is None:
            return True
        capacity = self.label_availability.capacity(frozen_at, step, self._deadline(frozen_at))
        return collected + capacity >= self.config.min_validation

    def _reject_pending(self, step, reason):
        pending = self.pending
        waited = step - pending["frozen_at"]
        self.candidate_waits.append(waited)
        self.pending_expired += reason == "independent_validation_deadline"
        self.pending_uncollectable += reason == "independent_labels_unavailable"
        self.logger.event("experiment_rejected", step, reason=reason, waited_batches=waited,
                          candidate_id=pending["candidate_id"], frozen_at=pending["frozen_at"],
                          gate_samples=sum(len(y) for y in pending["y"]), **pending["spec"])
        self.pending = None
        self.last_experiment = step

    def _freeze(self, candidate, step, spec):
        if not self.allow_label_request(step):
            return
        self.candidate_serial += 1
        spec = {**self.logger.context, **spec}
        self.pending = {"model": candidate, "frozen_at": step, "incumbent_version": self.gate.version,
                        "candidate_id": self.candidate_serial, "spec": spec, "x": [], "y": [], "steps": []}
        self.last_experiment = step
        self.last_experiment_source = int(self.history_steps.max())
        self.logger.event("candidate_frozen", step, candidate_id=self.candidate_serial, frozen_at=step,
                          incumbent_version=self.gate.version,
                          selection_max_source_step=spec.get("validation_max_step", int(self.history_steps.max())),
                          **spec)

    def _validate_pending(self, released, step):
        if not self.allow_label_request(step) or self.pending is None:
            return
        pending = self.pending
        valid = released.source_steps > pending["frozen_at"]
        if not np.any(valid):
            return
        pending["x"].append(released.features[valid].copy())
        pending["y"].append(released.targets[valid].copy())
        pending["steps"].append(released.source_steps[valid].copy())
        if sum(len(y) for y in pending["y"]) < self.config.min_validation:
            return
        x, y = np.concatenate(pending["x"]), np.concatenate(pending["y"])
        source_steps = np.concatenate(pending["steps"])
        started = time.perf_counter()
        decision = self.gate.consider(pending["model"], x, y, step)
        self.evaluation_seconds += time.perf_counter() - started
        self.logger.event("deploy" if decision["accepted"] else "experiment_rejected", step,
                          reason="independent_future_labels", candidate_id=pending["candidate_id"],
                          frozen_at=pending["frozen_at"], gate_min_source_step=int(source_steps.min()),
                          gate_max_source_step=int(source_steps.max()), gate_samples=len(y),
                          waited_batches=step - pending["frozen_at"],
                          **decision, **pending["spec"], **self.budget.snapshot())
        if decision["accepted"]:
            if pending["spec"]["candidate_kind"] == "archive":
                self.history_reuses += 1
            if pending["spec"]["candidate_kind"] == "rollback":
                self.gate.rollbacks += 1
            self.failed_reuses.clear()
            self._save_deployment()
        elif pending["spec"]["candidate_kind"] == "archive":
            self.failed_reuses.add(id(pending["model"]))
        self.pending = None
        self.candidate_waits.append(step - pending["frozen_at"])
        self.last_experiment = step

    def _save_deployment(self):
        started = time.perf_counter()
        self.gate.model.save(self.output_dir / "deployed.npz")
        self.gate.model.save(self.output_dir / f"model-v{self.gate.version}.npz")
        elapsed = time.perf_counter() - started
        self.checkpoint_seconds += elapsed
        self.logger.event("checkpoint_saved", self.gate.deployed_at, model_version=self.gate.version,
                          model_type=self.active_model_type, wall_seconds=elapsed)
        self.monitor.reset()
        if self.budget_guard:
            self._loss_trend.clear()
            self._risk_residuals = np.empty(0)
            self._model_age_batches = 0

    def _reuse_history(self, step):
        alternatives = [m for m in self.gate.archive if m is not self.gate.model and id(m) not in self.failed_reuses]
        if not alternatives:
            return False
        started = time.perf_counter()
        count = max(self.config.min_validation, 64)
        x, y = self.history_x[-count:], self.history_y[-count:]
        old_loss = prediction_loss(self.config.task, y, self.predict(x), self.scale)
        candidate = min(alternatives, key=lambda m: prediction_loss(self.config.task, y, m.predict(x), self.scale))
        loss = prediction_loss(self.config.task, y, candidate.predict(x), self.scale)
        self.evaluation_seconds += time.perf_counter() - started
        self.logger.event("archive_evaluated", step, incumbent_loss=old_loss, selection_loss=loss,
                          alternatives=len(alternatives), selection_samples=len(y))
        if old_loss - loss < self.config.min_gain or old_loss <= loss:
            return False
        if not self.budget.start_experiment(needs_training=False):
            self.logger.event("experiment_skipped", step, reason="budget_exhausted", **self.budget.snapshot())
            self.last_experiment = step
            self.last_experiment_source = int(self.history_steps.max())
            return True
        self.logger.event("experiment_started", step, diagnosis="archive_reuse_selection",
                          candidate_kind="archive", selection_samples=len(y))
        self._freeze(candidate, step, {"candidate_kind": "archive", "selection_loss": loss})
        return True

    def finish(self, step):
        if self.pending is not None:
            self._reject_pending(step, "stream_ended_before_independent_validation")

    def _training_weight_evidence(self, source_steps, latest_source):
        """Use released source time only; ESS is descriptive and never gates work."""
        count = len(source_steps)
        exponential = self.config.training_weighting == "exponential"
        weights = None
        if exponential and count:
            # Subtracting the candidate's maximum log weight cancels the common
            # latest_source reference, avoiding underflow when selection is far newer.
            with np.errstate(over="ignore", under="ignore"):
                log_weights = (source_steps.astype(float) - float(source_steps.max())) / self.config.training_half_life_batches
                weights = normalize_sample_weight(np.exp2(log_weights), count)
        total = float(weights.sum()) if weights is not None else float(count)
        ess = float(total ** 2 / (weights @ weights)) if weights is not None else float(count)
        audit = {"training_weighting": self.config.training_weighting,
                 "training_half_life_batches": self.config.training_half_life_batches if exponential else None,
                 "weight_reference_source_step": latest_source if exponential else None,
                 "effective_sample_size": ess,
                 "weight_min": float(weights.min()) if weights is not None else (1.0 if count else None),
                 "weight_max": float(weights.max()) if weights is not None else (1.0 if count else None),
                 "weight_sum": total}
        return weights, audit

    def _head_profile_supported(self, *, calibrate_down=False):
        screening = max(self.config.min_validation, min(self.config.history_windows) // 4)
        c_tuning = (self.config.heuristic_override and not calibrate_down and
                    getattr(self.gate.model, "profile_type", None) == "C")
        allowed_epochs = HEURISTIC_C_EPOCHS if c_tuning else (5,)
        return (is_official_model_type(self.active_model_type) and max(self.config.history_windows) == 768 and
                screening == 48 and self.config.official_candidate_epochs in allowed_epochs and
                getattr(self.gate.model, "candidate_epochs", None) == self.config.official_candidate_epochs and
                self.config.max_train_seconds <= 20)

    def _experiment(self, step, evidence, windows=None, *, trainable_policy="full", calibrate_down=False,
                    a_replay=False):
        if a_replay and (getattr(self.gate.model,"profile_type",None) != "A" or
                not self._head_profile_supported() or self.config.deployment_validation != "future"):
            raise ValueError("Replay requires the official A prospective Harness")
        if (trainable_policy not in ("full", "head_only") or
                (trainable_policy == "head_only" and not is_official_model_type(self.active_model_type))):
            raise ValueError("Training policy is not available for the active model")
        if trainable_policy == "head_only":
            if not self._head_profile_supported(calibrate_down=calibrate_down) or (windows is not None and tuple(windows) != (768,)):
                raise ValueError("Official HEAD requires the fixed 768/48/20second profile and approved epochs")
            windows = (768,)
        if calibrate_down and (trainable_policy != "head_only" or self.config.task != "regression" or
                getattr(self.gate.model, "profile_type", None) != "C"):
            raise ValueError("Calibration requires official C head-only candidate")
        if calibrate_down and self.config.deployment_validation != "future":
            raise ValueError("Calibration requires independent future deployment validation")
        if not self.allow_label_request(step):
            return
        # A single bounded marker deduplicates unchanged evidence, including source counts.
        # New releases change the revision even when their latest source stays the same.
        if self.config.training_preflight:
            source_evidence = (self._label_release_revision, self.history_steps.tobytes())
            if source_evidence == self._last_training_preflight_evidence:
                return
        elif not self._start_training_experiment(step):
            return
        requested_validation = max(self.config.min_validation, min(self.config.history_windows) // 4)
        selection_split_effective = self.config.selection_split
        if self.config.selection_split == "task_specific":
            if self.config.scenario == "recurring":
                selection_split_effective = "chronological"
            else:
                selection_split_effective = "recent_disjoint"
                if self.config.task == "classification":
                    requested_validation = self.config.task_specific_classification_pool_samples // 2
        recent_disjoint = selection_split_effective == "recent_disjoint"
        selection_pool_samples = (min(len(self.history_y), 2 * requested_validation)
                                  if recent_disjoint else None)
        if recent_disjoint:
            train_mask, val_mask = _recent_disjoint_masks(len(self.history_y), requested_validation)
        else:
            # Preserve legacy whole-source-batch chronological separation exactly.
            split = max(1, len(self.history_y) - requested_validation)
            boundary = self.history_steps[split]
            train_mask, val_mask = self.history_steps < boundary, self.history_steps >= boundary
        if trainable_policy == "head_only" or a_replay:
            # Both fixed paths include disjoint screening rows (768=720+48).
            recent_disjoint = False
            selection_split_effective, selection_pool_samples = "chronological", None
            positions = np.arange(len(self.history_y))
            end = max(0, len(self.history_y) - requested_validation)
            train_mask = (positions >= max(0, len(self.history_y)-max(self.config.history_windows))) & (positions < end)
            val_mask = positions >= end
        calibration = None
        if calibrate_down:
            first_source = int(self.history_steps[train_mask].min()) if np.any(train_mask) else -1
            source_step = first_source - 1
            values = self._calibration_sources.get(source_step)
            if int(train_mask.sum()) != 720 or int(val_mask.sum()) != 48 or values is None or len(values[1]) != 48:
                self.logger.event("harness_action_rejected", step, action="CALIBRATE_DOWN",
                                  reason="insufficient_independent_calibration_window")
                return
            calibration = {"x": values[0], "y": values[1], "ids": values[2].tolist(), "source_step": source_step}
        train_samples_before_filter = int(train_mask.sum())
        latest_source = int(self.history_steps.max()) if len(self.history_steps) else None
        source_window = self.config.train_source_window_batches
        cutoff = latest_source - source_window + 1 if source_window else None
        if cutoff is not None:
            train_mask &= self.history_steps >= cutoff
        if calibrate_down and int(train_mask.sum()) != 720:
            self.logger.event("harness_action_rejected", step, action="CALIBRATE_DOWN",
                              reason="calibration_requires_720_training_samples")
            return
        train_x, train_y = self.history_x[train_mask], self.history_y[train_mask]
        if a_replay and len(train_y) < 48:
            self.logger.event("harness_action_rejected",step,action="RETRAIN_REPLAY",reason="insufficient_replay_training_rows")
            return
        train_steps = self.history_steps[train_mask]
        val_x, val_y = self.history_x[val_mask], self.history_y[val_mask]
        _, weight_audit = self._training_weight_evidence(train_steps, latest_source)
        source_audit = {
            "selection_split": self.config.selection_split,
            "selection_split_effective": selection_split_effective,
            "selection_pool_samples": selection_pool_samples,
            "history_samples": len(self.history_y),
            "latest_released_source_step": latest_source, "train_source_cutoff": cutoff,
            "train_samples_before_filter": train_samples_before_filter, "train_samples": len(train_y),
            "train_min_step": int(self.history_steps[train_mask].min()) if len(train_y) else None,
            "train_max_step": int(self.history_steps[train_mask].max()) if len(train_y) else None,
            "validation_min_step": int(self.history_steps[val_mask].min()) if len(val_y) else None,
            "validation_max_step": int(self.history_steps[val_mask].max()) if len(val_y) else None,
            "latest_source_train_samples": int(np.sum(train_steps == latest_source)),
            "latest_source_validation_samples": int(np.sum(self.history_steps[val_mask] == latest_source)),
            "validation_samples": len(val_y), **weight_audit}
        if recent_disjoint:
            source_audit["selection_history_indices"] = np.flatnonzero(val_mask).tolist()
        required_validation = requested_validation if recent_disjoint else self.config.min_validation
        if len(train_y) < 16 or len(val_y) < required_validation:
            if self.config.training_preflight:
                self._last_training_preflight_evidence = source_evidence
                self.training_preflight_skips += 1
                self.logger.event("training_preflight_skipped", step,
                                  reason="insufficient_temporally_separate_labels",
                                  released_label_revision=self._label_release_revision,
                                  last_experiment=self.last_experiment, cooldown_until=self.cooldown_until,
                                  **source_audit, **self.budget.snapshot())
            else:
                self.logger.event("experiment_skipped", step, reason="insufficient_temporally_separate_labels",
                                  **source_audit)
            return
        if self.config.training_preflight and not self._start_training_experiment(step):
            return
        tree = self.active_model_type == "tree"
        official = is_official_model_type(self.active_model_type)
        bounded_model = tree or official
        if bounded_model:
            if windows is None:
                windows = self.window_policy.choose()
            else:
                windows = tuple(windows)
                if not windows or any(window not in self.config.history_windows for window in windows):
                    raise ValueError("Harness training windows exceed the configured whitelist")
            advice = Advice(tuple(windows), (None,), 0,
                            "fixed_tree" if tree else "fixed_official",
                            "tree_fixed_parameters" if tree else "official_resume_fixed_epochs")
        elif self.budget_guard:
            windows = tuple(self.config.history_windows if windows is None else windows)
            if not windows or any(window not in self.config.history_windows for window in windows):
                raise ValueError("Harness training windows exceed the configured whitelist")
            advice = Advice(windows, self.config.candidate_alphas, 0, "harness", "fixed_action_profile")
        else:
            windows = self.window_policy.choose()
            advice = self.advisor.decide(windows, self.config.candidate_alphas,
                {"recent_loss": evidence.get("released_loss"), "feature_distance": evidence.get("feature_distance"),
                 "labeled_count": len(self.history_y), "latest_source_step": int(self.history_steps.max())},
                self.config.max_tokens - self.budget.tokens)
            self.budget.record_tokens(advice.charged_tokens)
            if self.config.decision_backend != "rules":
                self.logger.event("decision_advice", step, status=advice.status, reason=advice.reason,
                                  charged_tokens=advice.charged_tokens, windows=list(advice.windows),
                                  alphas=list(advice.alphas))
        windows = advice.windows
        self.logger.event("experiment_started", step, diagnosis=evidence["diagnosis"],
                          windows=list(windows), strategy_adaptation=self.window_policy.enabled,
                          **source_audit)
        old_loss = prediction_loss(self.config.task, val_y, self.gate.model.predict(val_x), self.scale)
        best, best_loss, best_spec = None, float("inf"), None
        classification = self.config.task == "classification"
        conservative_ties = classification and not bounded_model and self.config.classification_tie_break == "alpha_desc"
        best_key, selection_candidates = None, []
        equal_error_comparisons = tie_replacements = 0
        lowest_error_count = None
        for window in windows:
            losses = []
            for alpha in (None,) if bounded_model else advice.alphas:
                if self.budget_guard and not self.allow_label_request(step):
                    return
                allowance = self.budget.training_allowance()
                if allowance <= 0:
                    break
                x, y = train_x[-window:], train_y[-window:]
                candidate_steps = train_steps[-window:]
                replay_audit = {}
                if a_replay:
                    from .heuristic_override import load_a_replay_reserve, replace_a_replay
                    if self._a_replay_reserve is None:
                        self._a_replay_reserve = load_a_replay_reserve(self.gate.model)
                    x,y = replace_a_replay(x,y,self._a_replay_reserve)
                    replay_audit = {"replay_source_ids":self._a_replay_reserve["ids"],
                        "replay_samples":48,"replay_source_role":"official_public_train",
                        "replay_policy":"class_balanced_official_train","online_samples_replaced":48}
                sample_weight, candidate_audit = self._training_weight_evidence(candidate_steps, latest_source)
                # Keep legacy trainer calls compatible with existing implementations.
                weight_options = {"sample_weight": sample_weight} if sample_weight is not None else {}
                if tree:
                    weight_options.update(model_type="tree", tree_options=self.config.tree_options(),
                                          class_labels=self.config.class_labels, candidate=True)
                elif official:
                    official_options = {"parent_state": self.gate.model.state()}
                    if trainable_policy == "head_only":
                        official_options["trainable_policy"] = trainable_policy
                    weight_options.update(model_type=self.active_model_type,
                        official_options=official_options, candidate=True)
                elif self.active_model_family == "ovr_ridge":
                    weight_options.update(model_type="ridge", class_labels=self.config.class_labels)
                result = self.trainer.fit(self.config.task, alpha, x, y, allowance,
                                          model_family=self.active_model_family, **weight_options)
                self.budget.charge_training(result.wall_seconds)
                if self.budget_guard and not self.allow_label_request(step):
                    return
                calibration_spec = {}
                if calibration is not None and result.status == "ok" and result.model is not None:
                    started_calibration = time.perf_counter()
                    try:
                        audit = result.model.calibrate_down(calibration["x"], calibration["y"])
                    except Exception as error:
                        self.logger.event("harness_action_rejected", step, action="CALIBRATE_DOWN",
                                          reason="candidate_calibration_error", error=str(error)[:1024])
                        continue
                    finally:
                        self.evaluation_seconds += time.perf_counter() - started_calibration
                    calibration_spec = {"safety_margin": result.model.safety_margin,
                        "calibration_samples": len(calibration["y"]), "calibration_source_step": calibration["source_step"],
                        "calibration_source_ids": calibration["ids"], "calibration_audit": audit}
                    self.logger.event("candidate_calibrated", step, **calibration_spec)
                predictions = result.model.predict(val_x) if result.status == "ok" and result.model is not None else None
                loss = (prediction_loss(self.config.task, val_y, predictions, self.scale)
                        if predictions is not None else None)
                errors = (int(np.count_nonzero(val_y != predictions))
                          if classification and predictions is not None else None)
                spec = {"window": window, "alpha": alpha, "train_samples": len(y),
                        "train_min_step": int(candidate_steps.min()), "train_max_step": int(candidate_steps.max()),
                        **candidate_audit, **calibration_spec, **replay_audit}
                if tree:
                    spec.update(model_type="tree", tree_options=self.config.tree_options(),
                                class_labels=self.config.class_labels)
                elif official:
                    spec.update(model_type=self.active_model_type, official_profile=self.config.official_profile,
                                candidate_epochs=self.config.official_candidate_epochs,
                                trainable_policy=trainable_policy,
                                fit_audit=getattr(result.model, "last_fit_audit", {}),
                                parent_checkpoint_sha256=self.gate.model.checkpoint_sha256)
                if recent_disjoint:
                    spec["validation_max_step"] = source_audit["validation_max_step"]
                ess = candidate_audit["effective_sample_size"]
                self.training_ess_audit_count += 1
                self.training_ess_sum += ess
                self.training_ess_min = ess if self.training_ess_min is None else min(self.training_ess_min, ess)
                self.training_ess_max = ess if self.training_ess_max is None else max(self.training_ess_max, ess)
                self.logger.event("candidate_evaluated", step, **spec, status=result.status,
                                  validation_loss=loss, wall_seconds=result.wall_seconds, error=result.error,
                                  **({"timings": result.timings} if bounded_model else {}),
                                  **({"validation_errors": errors} if classification else {}))
                if loss is not None:
                    losses.append(loss)
                    if classification:
                        selection_candidates.append({"window": window, "alpha": alpha,
                            "train_samples": len(y), "validation_errors": errors, "validation_loss": loss})
                        if lowest_error_count is not None and errors == lowest_error_count:
                            equal_error_comparisons += 1
                        if lowest_error_count is None or errors < lowest_error_count:
                            lowest_error_count = errors
                    key = (errors, -alpha, window) if conservative_ties else None
                    choose = (best_key is None or key < best_key) if conservative_ties else loss < best_loss
                    if choose:
                        if classification and best is not None and loss == best_loss:
                            tie_replacements += 1
                        best, best_loss, best_spec = result.model, loss, spec
                        best_key = key
            if losses:
                self.window_policy.record(window, old_loss - min(losses), 0)
        if classification:
            legacy = min(selection_candidates, key=lambda c: c["validation_loss"], default=None)
            selected = next((c for c in selection_candidates if best_spec is not None and
                             c["window"] == best_spec["window"] and c["alpha"] == best_spec["alpha"]), None)
            tied = sum(c["validation_errors"] == lowest_error_count for c in selection_candidates)
            reason = "no_completed_candidate"
            if selected is not None:
                if not conservative_ties:
                    reason = "legacy_first_minimum"
                elif selected["alpha"] != legacy["alpha"]:
                    reason = "exact_error_tie_larger_alpha"
                elif selected["window"] != legacy["window"]:
                    reason = "exact_error_tie_fixed_window"
                else:
                    reason = "exact_error_tie_fixed_key" if tied > 1 else "lowest_error_count"
            self.logger.event("candidate_selection", step,
                policy="fixed_tree" if tree else "fixed_official" if official else self.config.classification_tie_break,
                decision_key=(["validation_errors_asc", "alpha_desc", "window_asc"] if conservative_ties else
                              ["validation_loss_asc", "first_encountered"]),
                candidates_completed=len(selection_candidates), best_error_count=lowest_error_count,
                best_tied_candidates=tied, equal_error_comparisons=equal_error_comparisons,
                tie_replacements=tie_replacements, legacy_winner=legacy, selected_winner=selected, reason=reason)
        if best is None:
            self.logger.event("experiment_rejected", step, reason="no_candidate_completed")
            return
        if self.config.deployment_validation == "future":
            if old_loss - best_loss < self.config.min_gain or old_loss <= best_loss:
                self.logger.event("experiment_rejected", step, reason="not_better_on_selection",
                                  selection_loss=best_loss, incumbent_loss=old_loss)
            else:
                self._freeze(best, step, {"candidate_kind": "trained", "selection_loss": best_loss, **best_spec})
            return
        decision = self.gate.consider(best, val_x, val_y, step)
        self.logger.event("deploy" if decision["accepted"] else "experiment_rejected", step,
                          **decision, **best_spec, **self.budget.snapshot())
        if decision["accepted"]:
            self._save_deployment()

    def _start_training_experiment(self, step):
        self.last_experiment = step
        self.last_experiment_source = int(self.history_steps.max())
        if not self.budget.start_experiment():
            self.logger.event("experiment_skipped", step, reason="budget_exhausted", **self.budget.snapshot())
            return False
        return True
