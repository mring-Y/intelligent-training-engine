"""Isolated adapters for the supplied NumPy CPU baseline checkpoints."""

import base64
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import zipfile

import numpy as np


OFFICIAL_NUMPY_VERSION = "1.26.4"
OFFICIAL_PROFILES = {
    "A": {
        "task": "classification", "n_features": 128, "parameter_count": 4326,
        "classes": ("Ethanol", "Ethylene", "Ammonia", "Acetaldehyde", "Acetone", "Toluene"),
        "class_labels": (1, 2, 3, 4, 5, 6), "target_unit": None,
        "package": "cpu-a-guide-20261110-v1.zip",
        "sha256": "7a992b92d92c807869c3eccf25b3bf82dcdeba9174e161d6e8b61d82c3ec8851",
    },
    "B": {
        "task": "regression", "n_features": 34, "parameter_count": 865,
        "classes": (), "class_labels": (), "target_unit": "minutes",
        "package": "cpu-b-rul-20261110-v1.zip",
        "sha256": "68db6a72c29bac11a4f86e97d9c1f524d35695464fd5f3f6d131f1431bc69d68",
    },
    "C": {
        "task": "regression", "n_features": 24, "parameter_count": 833,
        "classes": (), "class_labels": (), "target_unit": "cycles",
        "package": "cpu-c-guide-20261110-v1.zip",
        "sha256": "6cb8784e2cab7ee93453e756abf54c168721c667ca0c2c1327f5faae96e4211f",
    },
}
OFFICIAL_A_CLASSES = OFFICIAL_PROFILES["A"]["classes"]
MAX_CHECKPOINT_BYTES = 16 * 1024 * 1024
MAX_WORKER_PAYLOAD_BYTES = 32 * 1024 * 1024
_WORKER = Path(__file__).with_name("official_worker.py")
_PACKAGE_ROOT = Path(__file__).resolve().parents[1] / "third_party" / "official_baselines"


class OfficialModelTimeout(TimeoutError):
    pass


def is_official_model_type(model_type):
    return model_type in ("official", "official_mlp")


def default_package_path(profile_type):
    if profile_type not in OFFICIAL_PROFILES:
        raise ValueError("Unknown official profile_type")
    return _PACKAGE_ROOT / OFFICIAL_PROFILES[profile_type]["package"]


def _regular_file(path, name):
    path = Path(path).expanduser()
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"{name} must be an existing regular file")
    return path.resolve()


def _validate_package(package_path, profile_type):
    contract = OFFICIAL_PROFILES.get(profile_type)
    if contract is None:
        raise ValueError("Unknown official profile_type")
    if hashlib.sha256(package_path.read_bytes()).hexdigest() != contract["sha256"]:
        raise ValueError(f"Official profile {profile_type} package digest does not match the supplied baseline")
    try:
        with zipfile.ZipFile(package_path) as archive:
            info = json.loads(archive.read("baseline-info.json").decode("utf-8"))
            checkpoint = archive.read("checkpoint.npz")
    except (KeyError, OSError, zipfile.BadZipFile, UnicodeError, json.JSONDecodeError) as error:
        raise ValueError("Official baseline package is incomplete or malformed") from error
    if (info.get("dataset_key") != profile_type or info.get("task") != contract["task"] or
            info.get("parameter_count") != contract["parameter_count"] or
            info.get("checkpoint_sha256") != "sha256:" + hashlib.sha256(checkpoint).hexdigest()):
        raise ValueError(f"Official profile {profile_type} metadata does not match its checkpoint")
    return info


def _load_checkpoint(package_path, checkpoint_path=None, checkpoint_bytes=None):
    if checkpoint_bytes is not None:
        if not isinstance(checkpoint_bytes, bytes) or not 1 <= len(checkpoint_bytes) <= MAX_CHECKPOINT_BYTES:
            raise ValueError("Official checkpoint bytes are invalid or exceed the size limit")
        return checkpoint_bytes
    if checkpoint_path:
        path = _regular_file(checkpoint_path, "Official checkpoint")
        if path.stat().st_size > MAX_CHECKPOINT_BYTES:
            raise ValueError("Official checkpoint exceeds the size limit")
        return path.read_bytes()
    with zipfile.ZipFile(package_path) as archive:
        info = archive.getinfo("checkpoint.npz")
        if info.file_size > MAX_CHECKPOINT_BYTES:
            raise ValueError("Packaged official checkpoint exceeds the size limit")
        return archive.read(info)


class OfficialModelAdapter:
    """Model interface backed by a separate Python/NumPy worker process."""

    model_type = "official_mlp"
    family = "official_cpu_mlp"

    @staticmethod
    def default_classes(profile_type="A"):
        if profile_type not in OFFICIAL_PROFILES:
            raise ValueError("Unknown official profile_type")
        return OFFICIAL_PROFILES[profile_type]["classes"]

    def __init__(self, task, runtime_python, package_path=None, *, profile_type=None, profile=None,
                 classes=None, class_labels=None, checkpoint_path=None, checkpoint_bytes=None,
                 candidate_epochs=5, validate_runtime=True):
        if profile_type is None:
            profile_type = profile or "A"
        elif profile is not None and profile != profile_type:
            raise ValueError("profile and profile_type must identify the same official package")
        contract = OFFICIAL_PROFILES.get(profile_type)
        if contract is None:
            raise ValueError("profile_type must be one of A, B or C")
        if task != contract["task"]:
            raise ValueError(f"Official profile {profile_type} requires task={contract['task']}")
        self.task, self.alpha = task, None
        self.profile_type = profile_type
        self.profile = profile_type
        self.safety_margin = 0.0
        self.safety_calibration = None
        expected_classes, expected_labels = contract["classes"], contract["class_labels"]
        classes = expected_classes if classes is None else tuple(classes)
        class_labels = expected_labels if class_labels is None else tuple(class_labels)
        if classes != expected_classes or class_labels != expected_labels:
            raise ValueError(f"Official profile {profile_type} class metadata does not match its task")
        if type(candidate_epochs) is not int or not 1 <= candidate_epochs <= 20:
            raise ValueError("Official candidate epochs must be in 1..20")
        self.candidate_epochs = candidate_epochs
        self.classes, self.class_labels = expected_classes, expected_labels
        self.feature_count, self.target_unit = contract["n_features"], contract["target_unit"]
        self.runtime_python = str(_regular_file(runtime_python, "Official runtime Python"))
        if Path(self.runtime_python) == Path(sys.executable).resolve():
            raise ValueError("Official model runtime must use a separate Python environment")
        if package_path is None:
            package_path = default_package_path(profile_type)
        self.package_path = str(_regular_file(package_path, "Official baseline package"))
        if Path(self.package_path).stat().st_size > 32 * 1024 * 1024:
            raise ValueError("Official baseline package exceeds the size limit")
        self.package_info = _validate_package(Path(self.package_path), profile_type)
        self.checkpoint_bytes = _load_checkpoint(self.package_path, checkpoint_path, checkpoint_bytes)
        self.checkpoint_sha256 = hashlib.sha256(self.checkpoint_bytes).hexdigest()
        if validate_runtime:
            version = self._invoke({"operation": "version"}, timeout_seconds=5.0).get("numpy_version")
            if version != OFFICIAL_NUMPY_VERSION:
                raise ValueError(f"Official runtime requires NumPy {OFFICIAL_NUMPY_VERSION}; found {version}")
        metadata = self._inspect()
        self._set_metadata(metadata)
        if checkpoint_path:
            self.load_safety_policy(checkpoint_path)

    def _invoke(self, request, timeout_seconds=10.0):
        payload = json.dumps(request, separators=(",", ":"), allow_nan=False).encode("utf-8")
        if len(payload) > MAX_WORKER_PAYLOAD_BYTES:
            raise ValueError("Official worker request exceeds the size limit")
        environment = os.environ.copy()
        for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
            environment[key] = "1"
        command = [self.runtime_python, str(_WORKER), self.package_path]
        try:
            completed = subprocess.run(command, input=payload, stdout=subprocess.PIPE,
                stderr=subprocess.PIPE, timeout=timeout_seconds, env=environment, check=False)
        except subprocess.TimeoutExpired as error:
            raise OfficialModelTimeout("Official CPU worker exceeded its wall-time allowance") from error
        if completed.returncode != 0:
            detail = completed.stderr.decode("utf-8", errors="replace")[:2048]
            raise RuntimeError(f"Official CPU worker exited {completed.returncode}: {detail}")
        if len(completed.stdout) > MAX_WORKER_PAYLOAD_BYTES:
            raise ValueError("Official worker response exceeds the size limit")
        try:
            response = json.loads(completed.stdout.decode("utf-8"))
        except (UnicodeError, json.JSONDecodeError) as error:
            raise ValueError("Official CPU worker returned invalid JSON") from error
        if not isinstance(response, dict) or response.get("ok") is not True:
            raise RuntimeError(str(response.get("error", "Official CPU worker failed"))[:2048]
                               if isinstance(response, dict) else "Official CPU worker returned an invalid response")
        return response

    def _inspect(self):
        return self._invoke({"operation": "inspect", "profile_type": self.profile_type,
            "checkpoint": base64.b64encode(self.checkpoint_bytes).decode("ascii")})

    def _set_metadata(self, metadata):
        contract = OFFICIAL_PROFILES[self.profile_type]
        if (metadata.get("profile_type") != self.profile_type or metadata.get("task") != self.task or
                metadata.get("classes") != list(self.classes) or
                metadata.get("feature_count") != self.feature_count or
                metadata.get("target_unit") != self.target_unit or
                metadata.get("numpy_version") != OFFICIAL_NUMPY_VERSION):
            raise ValueError(f"Official profile {self.profile_type} checkpoint metadata does not match")
        mean, scale = np.asarray(metadata.get("mean"), dtype=float), np.asarray(metadata.get("scale"), dtype=float)
        if (mean.shape != (self.feature_count,) or scale.shape != (self.feature_count,) or
                not np.isfinite(mean).all() or not np.isfinite(scale).all() or np.any(scale <= 0)):
            raise ValueError(f"Official profile {self.profile_type} feature normalization is invalid")
        self.mean, self.std = mean, scale
        self.runtime_numpy_version = metadata["numpy_version"]
        for name in ("steps", "epochs", "parameter_count"):
            value = metadata.get(name)
            if type(value) is not int or value < 0:
                raise ValueError("Official checkpoint has invalid training metadata")
            setattr(self, name, value)
        if self.parameter_count != contract["parameter_count"]:
            raise ValueError(f"Official profile {self.profile_type} parameter count does not match")

    @classmethod
    def from_state(cls, state):
        legacy = {"model_kind", "task", "profile", "runtime_python", "package_path", "classes",
                  "class_labels", "checkpoint_bytes", "checkpoint_sha256", "mean", "std",
                  "steps", "epochs", "parameter_count", "candidate_epochs", "runtime_numpy_version"}
        current = legacy | {"profile_type", "feature_count", "target_unit"}
        calibrated = current | {"safety_margin", "safety_calibration"}
        legacy_calibrated = legacy | {"safety_margin", "safety_calibration"}
        if (not isinstance(state, dict) or set(state) not in (legacy, current, calibrated, legacy_calibrated) or
                state.get("model_kind") != "official"):
            raise ValueError("Invalid official model state")
        profile_type = state.get("profile_type", state["profile"])
        contract = OFFICIAL_PROFILES.get(profile_type)
        if contract is None:
            raise ValueError("Official model state has an unsupported profile_type")
        model = cls.__new__(cls)
        model.model_type, model.family = "official_mlp", "official_cpu_mlp"
        model.task, model.alpha = state["task"], None
        model.profile_type = model.profile = profile_type
        model.safety_margin = state.get("safety_margin", 0.0)
        model.safety_calibration = state.get("safety_calibration")
        model._validate_safety_policy()
        model.classes, model.class_labels = tuple(state["classes"]), tuple(state["class_labels"])
        model.feature_count = state.get("feature_count", contract["n_features"])
        model.target_unit = state.get("target_unit", contract["target_unit"])
        if type(state["candidate_epochs"]) is not int or not 1 <= state["candidate_epochs"] <= 20:
            raise ValueError("Official model state has invalid candidate epoch count")
        model.candidate_epochs = state["candidate_epochs"]
        model.runtime_python = str(_regular_file(state["runtime_python"], "Official runtime Python"))
        model.package_path = str(_regular_file(state["package_path"], "Official baseline package"))
        model.package_info = _validate_package(Path(model.package_path), profile_type)
        model.checkpoint_bytes = state["checkpoint_bytes"]
        if (not isinstance(model.checkpoint_bytes, bytes) or
                not 1 <= len(model.checkpoint_bytes) <= MAX_CHECKPOINT_BYTES or
                hashlib.sha256(model.checkpoint_bytes).hexdigest() != state["checkpoint_sha256"]):
            raise ValueError("Official checkpoint state digest mismatch")
        model.checkpoint_sha256 = state["checkpoint_sha256"]
        if state["runtime_numpy_version"] != OFFICIAL_NUMPY_VERSION:
            raise ValueError("Official model state has an unsupported NumPy runtime")
        model.runtime_numpy_version = state["runtime_numpy_version"]
        model.mean, model.std = np.asarray(state["mean"], dtype=float), np.asarray(state["std"], dtype=float)
        if (model.mean.shape != (model.feature_count,) or model.std.shape != (model.feature_count,) or
                not np.isfinite(model.mean).all() or not np.isfinite(model.std).all() or np.any(model.std <= 0)):
            raise ValueError("Official model state has invalid feature normalization")
        for name in ("steps", "epochs", "parameter_count"):
            if type(state[name]) is not int or state[name] < 0:
                raise ValueError("Official model state has invalid training metadata")
            setattr(model, name, state[name])
        if (model.task != contract["task"] or model.classes != contract["classes"] or
                model.class_labels != contract["class_labels"] or
                model.feature_count != contract["n_features"] or
                model.target_unit != contract["target_unit"] or
                model.parameter_count != contract["parameter_count"]):
            raise ValueError("Official model state contract mismatch")
        return model

    def state(self):
        return {"model_kind": "official", "task": self.task, "profile": self.profile_type,
                "profile_type": self.profile_type, "feature_count": self.feature_count,
                "target_unit": self.target_unit, "runtime_python": self.runtime_python,
                "package_path": self.package_path, "classes": list(self.classes),
                "class_labels": list(self.class_labels), "checkpoint_bytes": self.checkpoint_bytes,
                "checkpoint_sha256": self.checkpoint_sha256, "mean": self.mean.tolist(),
                "std": self.std.tolist(), "steps": self.steps, "epochs": self.epochs,
                "parameter_count": self.parameter_count, "candidate_epochs": self.candidate_epochs,
                "runtime_numpy_version": self.runtime_numpy_version,
                "safety_margin": self.safety_margin, "safety_calibration": self.safety_calibration}

    def predict_proba(self, features):
        if self.task != "classification":
            raise ValueError("Regression official models do not expose class probabilities")
        x = np.asarray(features, dtype=np.float64)
        if x.ndim != 2 or x.shape[1] != self.feature_count or not np.isfinite(x).all():
            raise ValueError("Official classification prediction requires a finite feature matrix")
        response = self._invoke({"operation": "predict", "profile_type": self.profile_type,
            "task": self.task, "checkpoint": base64.b64encode(self.checkpoint_bytes).decode("ascii"),
            "features": x.tolist()})
        probabilities = np.asarray(response.get("predictions"), dtype=np.float64)
        if (probabilities.shape != (len(x), len(self.classes)) or not np.isfinite(probabilities).all() or
                np.any(probabilities < 0) or not np.allclose(probabilities.sum(axis=1), 1.0, atol=1e-7)):
            raise ValueError("Official worker returned an invalid probability matrix")
        return probabilities

    def predict_raw(self, features):
        if self.task != "regression":
            raise ValueError("Raw regression prediction is unavailable for classification models")
        x = np.asarray(features, dtype=np.float64)
        if x.ndim != 2 or x.shape[1] != self.feature_count or not np.isfinite(x).all():
            raise ValueError("Official regression prediction requires a finite feature matrix")
        response = self._invoke({"operation": "predict", "profile_type": self.profile_type,
            "task": self.task, "checkpoint": base64.b64encode(self.checkpoint_bytes).decode("ascii"),
            "features": x.tolist()})
        predictions = np.asarray(response.get("predictions"), dtype=np.float64)
        if (predictions.shape != (len(x),) or not np.isfinite(predictions).all() or
                np.any(predictions < 0)):
            raise ValueError("Official worker returned invalid regression predictions")
        return predictions

    def predict(self, features):
        if self.task == "classification":
            return np.argmax(self.predict_proba(features), axis=1).astype(np.int64) + 1
        return np.maximum(0.0, self.predict_raw(features) - self.safety_margin)

    def _validate_safety_policy(self):
        margin, calibration = self.safety_margin, self.safety_calibration
        if (isinstance(margin, bool) or type(margin) not in (int, float) or
                not math.isfinite(margin) or margin < 0):
            raise ValueError("Official C safety margin must be finite and nonnegative")
        if calibration is None:
            if margin != 0:
                raise ValueError("A nonzero safety margin requires calibration evidence")
            return
        if (self.profile_type != "C" or self.task != "regression" or not isinstance(calibration, dict) or
                set(calibration) != {"samples", "quantile", "positive_residuals"} or
                calibration["samples"] != 48 or calibration["quantile"] != .9 or
                type(calibration["positive_residuals"]) is not int or
                not 0 <= calibration["positive_residuals"] <= 48):
            raise ValueError("Official C calibration metadata is invalid")

    def calibrate_down(self, features, targets, *, quantile=.9):
        if self.profile_type != "C" or self.task != "regression":
            raise ValueError("Downward safety calibration is restricted to official C regression")
        x, y = np.asarray(features, dtype=np.float64), np.asarray(targets, dtype=np.float64)
        if (x.ndim != 2 or x.shape != (48, self.feature_count) or y.shape != (48,) or
                not np.isfinite(x).all() or not np.isfinite(y).all() or np.any(y < 0) or
                type(quantile) not in (int, float) or quantile != .9):
            raise ValueError("C safety calibration requires exactly 48 valid regression rows")
        residuals = self.predict_raw(x) - y
        positive = np.maximum(residuals, 0.0)
        margin = max(0.0, float(np.quantile(residuals, quantile)))
        self.safety_margin = margin
        self.safety_calibration = {"samples": 48, "quantile": float(quantile),
                                   "positive_residuals": int(np.count_nonzero(residuals > 0))}
        self._validate_safety_policy()
        return {**self.safety_calibration, "safety_margin": margin,
                "positive_residual_mean": float(np.mean(positive))}

    def load_safety_policy(self, checkpoint_path):
        if self.profile_type != "C":
            return self
        sidecar = Path(str(checkpoint_path) + ".policy.json")
        if not sidecar.exists():
            return self
        if sidecar.is_symlink() or not sidecar.is_file() or sidecar.stat().st_size > 4096:
            raise ValueError("Official safety policy sidecar must be a regular bounded file")
        try:
            policy = json.loads(sidecar.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError) as error:
            raise ValueError("Official safety policy sidecar is malformed") from error
        if (not isinstance(policy, dict) or set(policy) != {"format_version", "profile_type", "target_unit",
                "checkpoint_sha256", "safety_margin", "calibration"} or policy["format_version"] != 1 or
                policy["profile_type"] != "C" or policy["target_unit"] != self.target_unit or
                policy["checkpoint_sha256"] != self.checkpoint_sha256):
            raise ValueError("Official safety policy does not match its checkpoint")
        self.safety_margin, self.safety_calibration = policy["safety_margin"], policy["calibration"]
        self._validate_safety_policy()
        return self

    def fit(self, features, targets, sample_weight=None, *, epochs=None, timeout_seconds=5.0,
            trainable_policy="full", loss_policy="squared"):
        if trainable_policy not in ("full", "head_only"):
            raise ValueError("trainable_policy must be full or head_only")
        if loss_policy not in ("squared", "overestimate_2x"):
            raise ValueError("loss_policy must be squared or overestimate_2x")
        if loss_policy != "squared" and (trainable_policy != "head_only" or self.task != "regression" or
                                          self.profile_type != "C"):
            raise ValueError("Asymmetric loss requires official C head_only regression")
        if sample_weight is not None:
            raise ValueError("Official resume training does not accept external sample weights")
        epochs = self.candidate_epochs if epochs is None else epochs
        if type(epochs) is not int or not 1 <= epochs <= 20:
            raise ValueError("Official candidate epochs must be in 1..20")
        x, y = np.asarray(features, dtype=np.float64), np.asarray(targets)
        valid_targets = (np.isfinite(y).all() and
                         (np.isin(y, self.class_labels).all() if self.task == "classification" else
                          np.all(y >= 0)))
        if (x.ndim != 2 or x.shape[1] != self.feature_count or y.shape != (len(x),) or len(x) < 2 or
                not np.isfinite(x).all() or not valid_targets):
            raise ValueError(f"Official profile {self.profile_type} resume data is invalid")
        encoded = (y.astype(np.int64) - 1).tolist() if self.task == "classification" else y.astype(float).tolist()
        request = {"operation": "fit", "profile_type": self.profile_type,
            "task": self.task, "checkpoint": base64.b64encode(self.checkpoint_bytes).decode("ascii"),
            "features": x.tolist(), "targets": encoded, "epochs": epochs,
            "trainable_policy": trainable_policy}
        if loss_policy != "squared":
            request["loss_policy"] = loss_policy
        response = self._invoke(request, timeout_seconds=timeout_seconds)
        updated = base64.b64decode(response.get("checkpoint", ""), validate=True)
        if not 1 <= len(updated) <= MAX_CHECKPOINT_BYTES:
            raise ValueError("Official candidate checkpoint is invalid")
        previous_steps = self.steps
        self.checkpoint_bytes = updated
        self.checkpoint_sha256 = hashlib.sha256(updated).hexdigest()
        self._set_metadata(response)
        if self.steps <= previous_steps or self.epochs <= 0:
            raise ValueError("Official continuation did not advance optimizer state")
        self.last_fit_audit = response["fit_audit"]
        return self

    def save(self, path):
        self._validate_safety_policy()
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(path.name + ".tmp")
        temporary.write_bytes(self.checkpoint_bytes)
        os.replace(temporary, path)
        if self.profile_type == "C":
            self._validate_safety_policy()
            policy_path = Path(str(path) + ".policy.json")
            policy_temp = policy_path.with_name(policy_path.name + ".tmp")
            policy_temp.write_text(json.dumps({"format_version": 1, "profile_type": "C",
                "target_unit": self.target_unit, "checkpoint_sha256": self.checkpoint_sha256,
                "safety_margin": self.safety_margin, "calibration": self.safety_calibration},
                sort_keys=True, separators=(",", ":"), allow_nan=False), encoding="utf-8")
            os.replace(policy_temp, policy_path)
