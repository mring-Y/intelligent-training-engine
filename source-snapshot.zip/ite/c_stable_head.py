"""Original-domain routing and a numeric checkpoint for an independent C2 head."""

from functools import lru_cache
from collections import Counter, deque
import hashlib
import io
import json
import math
import zipfile

import numpy as np

from .c_rbf_model import LIMIT, npz_bytes
from .gate_reference import load_reference


MODULE = "input_gate_stable_head_v1"
BALANCED_MODULE = "input_gate_stable_head_balanced_v1"
LOW_RUL_MODULE = "input_gate_stable_head_low_rul_residual_v1"
FORMAT = "ite.c-mlp-input-gate.v5"
LEGACY_FORMAT = "ite.c-mlp-input-gate.v4"
MODULE_BY_FORMAT = {LEGACY_FORMAT: MODULE, FORMAT: BALANCED_MODULE}
ROUND_POLICY = "C_frozen_mlp_stable_head_and_residual_calibration_epoch2_v1"
ROUND_POLICIES = {
    MODULE: ROUND_POLICY,
    BALANCED_MODULE: "C_frozen_mlp_stable_head_balanced_epoch2_v1",
    LOW_RUL_MODULE: "C_frozen_mlp_stable_head_low_rul_residual_epoch2_v1",
}
ROWS = 720
EARLY_STABLE_SCREEN_ROWS = 48
SAMPLING_POLICY = "fd_engine_round_robin_v1"
REPORT_CLOCKS = ("initial_stable_head_steps", "final_stable_head_steps",
                 "initial_stable_head_epochs", "final_stable_head_epochs")
POLICY = {
    "kind": MODULE,
    "distance": "squared_mahalanobis",
    "ridge": .001,
    "source_quantile": .995,
    "reference_rows_per_engine": 4,
    "calibration_engine_rule": "every_fifth_sorted",
    "source": "latest_released_official_train_batch_tail_of_eligible_rows",
    "rows": ROWS,
    "epochs": 2,
    "trainable_parameters": 33,
}
BALANCED_POLICY = {**POLICY, "kind": BALANCED_MODULE, "source": "released_official_train_history",
                   "sampling_policy": SAMPLING_POLICY, "within_engine": "sha256_id_then_id",
                   "output_order": "source_step_and_row"}
HEAD_SHAPES = {"w2": (32, 1), "b2": (1,)}
HEAD_GROUPS = ("params", "first", "second")
HEAD_FIELDS = {"stable_param_" + key for key in HEAD_SHAPES} | {
    f"stable_{group}_{key}" for group in HEAD_GROUPS[1:] for key in HEAD_SHAPES
} | {"stable_center", "stable_whitening", "stable_threshold"}
FIELDS = {"metadata", "drift_checkpoint"}
SOURCE_FIELDS = {"source_step", "rows", "ids_sha256", "inputs_sha256", "targets_sha256", "train_sha256"}
BALANCED_SOURCE_FIELDS = SOURCE_FIELDS | {"source_steps", "source_step_counts", "sampling_policy"}


class StableHeadUnavailable(Exception):
    def __init__(self, audit):
        super().__init__("Original-domain head eligibility was not met")
        self.audit = audit


def sha256(raw):
    return hashlib.sha256(raw).hexdigest()


def array_digest(array):
    return sha256(np.asarray(array, dtype="<f8").tobytes())


def _is_digest(value):
    return isinstance(value, str) and len(value) == 64 and all(c in "0123456789abcdef" for c in value)


def normalize(raw, mean, scale):
    return np.clip((np.asarray(raw, dtype=np.float64) - mean) / scale, -10., 10.)


class StableDomain:
    def __init__(self, center, whitening, threshold):
        self.center = np.asarray(center, dtype=np.float64).copy()
        self.whitening = np.asarray(whitening, dtype=np.float64).copy()
        self.threshold = float(threshold)
        if (self.center.shape != (24,) or self.whitening.shape != (24, 24)
                or not np.isfinite(self.center).all() or not np.isfinite(self.whitening).all()
                or not np.array_equal(self.whitening, np.tril(self.whitening))
                or np.any(np.diag(self.whitening) <= 0)
                or not math.isfinite(self.threshold) or self.threshold <= 0):
            raise ValueError("invalid original-domain distance state")
        self.center.flags.writeable = self.whitening.flags.writeable = False

    def scores(self, normalized):
        x = np.asarray(normalized, dtype=np.float64)
        if x.ndim != 2 or x.shape[1] != 24 or not np.isfinite(x).all():
            raise ValueError("original-domain distance requires finite 24-dimensional inputs")
        projected = np.einsum("ij,kj->ik", x - self.center, self.whitening)
        return np.sum(projected ** 2, axis=1)

    def contains(self, normalized):
        return self.scores(normalized) <= self.threshold


@lru_cache(maxsize=4)
def load_domain(package, mean, scale):
    reference = load_reference(package)
    fit = [(identity, group, features) for identity, group, role, features in reference.samples if role == "fit"]
    calibration = [(identity, group, features) for identity, group, role, features in reference.samples if role == "calibration"]
    fit_groups = {group for _, group, _ in fit}
    cal_groups = {group for _, group, _ in calibration}
    if len(fit) < 64 or len(calibration) < 32 or fit_groups & cal_groups:
        raise ValueError("original-domain reference requires distinct train engine partitions")
    x = normalize([row[2] for row in fit], mean, scale)
    center = x.mean(axis=0)
    centered = x - center
    covariance = centered.T @ centered / len(x) + POLICY["ridge"] * np.eye(24)
    whitening = np.tril(np.linalg.solve(np.linalg.cholesky(covariance), np.eye(24)))
    z = normalize([row[2] for row in calibration], mean, scale)
    distances = np.sort(StableDomain(center, whitening, 1.).scores(z))
    rank = min(len(z), math.ceil((len(z) + 1) * POLICY["source_quantile"]))
    return StableDomain(center, whitening, distances[rank - 1]), {
        "train_sha256": reference.source_sha256, "uses_rul_targets": False,
        "fit_rows": len(fit), "calibration_rows": len(calibration),
        "fit_engines": len(fit_groups), "calibration_engines": len(cal_groups),
        "fit_ids_sha256": sha256("\n".join(row[0] for row in fit).encode()),
        "calibration_ids_sha256": sha256("\n".join(row[0] for row in calibration).encode()),
        "calibration_rank": rank,
    }


def screening_counts(normalized, probe, current):
    if not len(normalized):
        raise ValueError("original-domain selection requires a nonempty screening window")
    return (len(normalized), int(np.count_nonzero(probe.values(normalized))),
            int(np.count_nonzero(current.values(normalized))) if current is not None else 0)


def screening_eligible(counts, *, allow_single_probe_hit=False):
    rows, probe_open, current_open = counts
    if any(type(value) is not int for value in counts) or rows <= 0 or not (
            0 <= probe_open <= rows and 0 <= current_open <= rows):
        raise ValueError("invalid original-domain screening counts")
    if allow_single_probe_hit and rows != EARLY_STABLE_SCREEN_ROWS:
        raise ValueError("single probe hit allowance requires 48 rows")
    return current_open == 0 and probe_open <= int(allow_single_probe_hit)


def eligible_training_rows(normalized, domain, gate):
    eligible = domain.contains(normalized)
    if gate is not None:
        eligible &= gate.values(normalized) == 0.
    return np.flatnonzero(eligible)


def stable_training_rows(normalized, domain, gate):
    indices = eligible_training_rows(normalized, domain, gate)
    return indices[-ROWS:], len(indices)


def select_balanced_history_rows(eligible_indices, identities, source_steps, group_for_id, *,
                                excluded_groups=(), excluded_ids=()):
    indices = np.asarray(eligible_indices)
    steps = np.asarray(source_steps)
    if (indices.ndim != 1 or indices.dtype.kind not in "iu"
            or steps.ndim != 1 or steps.dtype.kind not in "iu"
            or len(steps) != len(identities) or np.any(steps < 0)
            or np.any(steps[1:] < steps[:-1])):
        raise ValueError("invalid released training history clocks")
    if (any(not isinstance(identity, str) or not identity for identity in identities)
            or len(set(identities)) != len(identities)
            or any(identity not in group_for_id for identity in identities)):
        raise ValueError("history identities must be distinct locked official train IDs")
    if len(indices) and (np.any(indices < 0) or np.any(indices >= len(identities))):
        raise ValueError("eligible history row is outside its source")
    if len(set(indices.tolist())) != len(indices):
        raise ValueError("eligible history rows must be distinct")
    excluded_groups = set(excluded_groups)
    excluded_ids = set(excluded_ids)
    if any(not isinstance(group, str) or ":" not in group for group in excluded_groups):
        raise ValueError("gradient engine groups must use locked FD:engine identities")
    if any(not isinstance(identity, str) for identity in excluded_ids):
        raise ValueError("screening identities must be strings")

    pools = {}
    excluded_gradient_rows = 0
    excluded_screening_rows = 0
    for raw_index in indices:
        index = int(raw_index)
        identity = identities[index]
        group = group_for_id[identity]
        if group in excluded_groups:
            excluded_gradient_rows += 1
            continue
        if identity in excluded_ids:
            excluded_screening_rows += 1
            continue
        subset, separator, engine = group.partition(":")
        if not separator or not subset.startswith("FD") or not engine:
            raise ValueError("locked engine groups must include an FD subset and engine")
        pools.setdefault(subset, {}).setdefault(group, []).append(index)

    available_rows = sum(len(rows) for engines in pools.values() for rows in engines.values())
    selected = []
    if available_rows >= ROWS:
        subsets = deque()
        for subset in sorted(pools):
            engines = deque()
            for group in sorted(pools[subset]):
                rows = sorted(pools[subset][group],
                              key=lambda index: (hashlib.sha256(identities[index].encode()).digest(), identities[index]))
                engines.append(deque(rows))
            subsets.append(engines)
        for _ in range(ROWS):
            engines = subsets.popleft()
            rows = engines.popleft()
            selected.append(rows.popleft())
            if rows:
                engines.append(rows)
            if engines:
                subsets.append(engines)
    selected.sort(key=lambda index: (int(steps[index]), index))
    selected_steps = [int(steps[index]) for index in selected]
    selected_ids = [identities[index] for index in selected]
    selected_groups = [group_for_id[identity] for identity in selected_ids]
    audit = {
        "policy": SAMPLING_POLICY,
        "eligible_rows": len(indices),
        "available_rows": available_rows,
        "available_engines": sum(len(engines) for engines in pools.values()),
        "excluded_gradient_rows": excluded_gradient_rows,
        "excluded_gradient_groups": sorted(excluded_groups),
        "excluded_screening_rows": excluded_screening_rows,
        "selected_subset_counts": dict(Counter(group.partition(":")[0] for group in selected_groups)),
        "selected_engine_counts": dict(Counter(selected_groups)),
        "selected_source_steps": selected_steps,
        "source_step_counts": dict(Counter(map(str, selected_steps))),
        "selected_ids_sha256": sha256("\n".join(selected_ids).encode()),
        "selection_uses_targets": False,
    }
    return np.asarray(selected, dtype=np.int64), audit


def validate_source(source):
    if (not isinstance(source, dict) or set(source) not in (SOURCE_FIELDS, BALANCED_SOURCE_FIELDS)
            or type(source["source_step"]) is not int or source["source_step"] < 0
            or type(source["rows"]) is not int or source["rows"] != ROWS
            or any(not _is_digest(source[key]) for key in SOURCE_FIELDS - {"source_step", "rows"})):
        raise ValueError("invalid original-domain training provenance")
    if set(source) == BALANCED_SOURCE_FIELDS:
        steps, counts = source["source_steps"], source["source_step_counts"]
        if (source["sampling_policy"] != SAMPLING_POLICY or not isinstance(steps, list)
                or len(steps) != ROWS or any(type(step) is not int or step < 0 for step in steps)
                or steps != sorted(steps) or steps[-1] != source["source_step"]
                or not isinstance(counts, dict)):
            raise ValueError("invalid original-domain per-row source clock")
        if any(type(count) is not int for count in counts.values()) or counts != Counter(map(str, steps)):
            raise ValueError("invalid original-domain source-step counts")


class StableHead:
    def __init__(self, domain, params, first, second, steps, epochs, source):
        validate_source(source)
        if (not isinstance(domain, StableDomain) or type(steps) is not int or steps < 1
                or type(epochs) is not int or epochs < 2):
            raise ValueError("invalid original-domain head clock")
        self.domain, self.steps, self.epochs, self.source = domain, steps, epochs, dict(source)
        for name, values in zip(HEAD_GROUPS, (params, first, second)):
            if set(values) != set(HEAD_SHAPES):
                raise ValueError("missing original-domain head optimizer state")
            arrays = {}
            for key, shape in HEAD_SHAPES.items():
                value = np.asarray(values[key])
                if (value.shape != shape or value.dtype != np.float64 or not np.isfinite(value).all()
                        or (name == "second" and np.any(value < 0.))):
                    raise ValueError("invalid original-domain head optimizer state")
                arrays[key] = value.copy()
                arrays[key].flags.writeable = False
            setattr(self, name, arrays)

    def arrays(self):
        arrays = {"stable_center": self.domain.center, "stable_whitening": self.domain.whitening,
                  "stable_threshold": np.asarray(self.domain.threshold)}
        for group, prefix in zip(HEAD_GROUPS, ("param", "first", "second")):
            arrays.update({f"stable_{prefix}_{key}": value for key, value in getattr(self, group).items()})
        return arrays

    @property
    def audit(self):
        digest = hashlib.sha256()
        for name, value in sorted(self.arrays().items()):
            digest.update(name.encode())
            digest.update(np.asarray(value, dtype="<f8").tobytes())
        return {**self.source, "steps": self.steps, "epochs": self.epochs, "state_sha256": digest.hexdigest()}

    def validate_clock(self, native_steps, native_epochs, batch_size):
        added = self.epochs - native_epochs
        if added <= 0 or added % 2 or self.steps != native_steps + added * math.ceil(ROWS / batch_size):
            raise ValueError("original-domain head clock differs from the native optimizer contract")

    def predict(self, model, normalized_row):
        hidden, _ = model.forward(normalized_row)
        logits = (hidden @ self.params["w2"] + self.params["b2"])[0, 0]
        return max(0., float(logits * model.meta["target_scale"] + model.meta["target_mean"]))


def is_stable_checkpoint(raw):
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        return "drift_checkpoint.npy" in archive.namelist()


def pack_stable_checkpoint(drift, head, parent_digest, *, balanced_sampling=False):
    metadata = {"format": FORMAT if balanced_sampling else LEGACY_FORMAT, "profile": "C",
                "parent_checkpoint_sha256": parent_digest,
                "drift_sha256": sha256(drift), "stable_head": head.audit if head is not None else None}
    arrays = {"metadata": np.asarray(json.dumps(metadata, sort_keys=True, separators=(",", ":")).encode()),
              "drift_checkpoint": np.frombuffer(drift, dtype=np.uint8)}
    if head is not None:
        arrays.update(head.arrays())
    raw = npz_bytes(arrays)
    unpack_stable_checkpoint(raw)
    return raw


def _require_supported_drift(drift):
    from .c_gate_model import LOW_RUL_FORMAT, RESIDUAL_FORMAT, unpack_checkpoint

    with zipfile.ZipFile(io.BytesIO(drift)) as archive:
        names = set(archive.namelist())
    if "adapter_checkpoint.npy" in names:
        if unpack_checkpoint(drift)[2]["format"] not in (RESIDUAL_FORMAT, LOW_RUL_FORMAT):
            raise ValueError("original-domain head requires the NR-055 drift branch")
    elif len(names) != 15 or "w1.npy" not in names or "w2.npy" not in names:
        raise ValueError("original-domain head requires a native MLP or NR-055 drift branch")


def unpack_stable_checkpoint(raw):
    from .platform_data import json_value
    from .tree_model import preflight_npz

    if not isinstance(raw, bytes) or not 1 <= len(raw) <= LIMIT:
        raise ValueError("invalid original-domain checkpoint size")
    names = preflight_npz(io.BytesIO(raw), allowed_fields=FIELDS | HEAD_FIELDS, allow_text=True)
    try:
        with np.load(io.BytesIO(raw), allow_pickle=False) as archive:
            value = archive["metadata"]
            if value.shape != () or value.dtype.kind != "S":
                raise ValueError("invalid original-domain checkpoint metadata")
            meta = json_value(value.item().decode("utf-8"))
            if (not isinstance(meta, dict) or set(meta) != {"format", "profile", "parent_checkpoint_sha256", "drift_sha256", "stable_head"}
                    or meta["format"] not in MODULE_BY_FORMAT or meta["profile"] != "C"
                    or not _is_digest(meta["parent_checkpoint_sha256"])):
                raise ValueError("unsupported original-domain checkpoint")
            embedded = archive["drift_checkpoint"]
            if embedded.ndim != 1 or embedded.dtype != np.uint8 or not len(embedded):
                raise ValueError("missing original-domain drift checkpoint")
            drift = embedded.tobytes()
            if sha256(drift) != meta["drift_sha256"]:
                raise ValueError("original-domain drift digest mismatch")
            _require_supported_drift(drift)
            audit = meta["stable_head"]
            if names != (FIELDS if audit is None else FIELDS | HEAD_FIELDS):
                raise ValueError("incomplete original-domain checkpoint fields")
            if audit is None:
                return drift, None, meta
            audit_clocks = {"steps", "epochs", "state_sha256"}
            source_fields = set(audit) - audit_clocks if isinstance(audit, dict) else set()
            if (not isinstance(audit, dict) or set(audit) != source_fields | audit_clocks
                    or source_fields not in (SOURCE_FIELDS, BALANCED_SOURCE_FIELDS)
                    or (meta["format"] == LEGACY_FORMAT and source_fields != SOURCE_FIELDS)
                    or any(archive[name].dtype != np.float64 for name in HEAD_FIELDS)
                    or archive["stable_threshold"].shape != ()):
                raise ValueError("invalid original-domain head payload")
            domain = StableDomain(archive["stable_center"], archive["stable_whitening"], archive["stable_threshold"])
            state = [{key: archive[f"stable_{prefix}_{key}"] for key in HEAD_SHAPES} for prefix in ("param", "first", "second")]
            head = StableHead(domain, *state, audit["steps"], audit["epochs"],
                              {key: audit[key] for key in source_fields})
            if head.audit != audit:
                raise ValueError("original-domain head digest mismatch")
            return drift, head, meta
    except (KeyError, TypeError, UnicodeError, zipfile.BadZipFile) as error:
        raise ValueError("invalid complete original-domain checkpoint") from error
