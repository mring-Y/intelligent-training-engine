"""CLI for offline real-call cost analysis."""

from ite.llm_audit import main

if __name__ == "__main__":
    raise SystemExit(main())
