"""Audit completed artifacts and emit paired results without changing any policy."""

import argparse
import csv
import hashlib
import json
from collections import defaultdict
from pathlib import Path

import numpy as np

from ite.config import ExperimentConfig
from ite.diagnostics import drift_diagnostics
from ite.models import RidgeModel
from ite.tracking import write_json


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def rows(path):
    with Path(path).open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def avg(items, key):
    values = [float(item[key]) for item in items if item.get(key) not in (None, "", "None")]
    return float(np.mean(values)) if values else None


def audit(root, final_commit):
    counts, sources, waits, corrected = {}, {}, defaultdict(list), defaultdict(list)
    verified = 0
    for stage, expected in (("development", 360), ("robustness", 228), ("acceptance", 420), ("stress", 80)):
        event_paths = sorted((root / stage).rglob("events.jsonl"))
        if len(event_paths) != expected:
            raise ValueError(f"{stage}: expected {expected} completed runs, found {len(event_paths)}")
        counts[stage] = len(event_paths)
        for event_path in event_paths:
            directory = event_path.parent
            events = [json.loads(line) for line in event_path.read_text(encoding="utf-8").splitlines()]
            summary, raw = read_json(directory / "summary.json"), read_json(directory / "config.json")
            config = ExperimentConfig.from_dict({k: v for k, v in raw.items() if k != "policy"})
            start = next(e for e in events if e["event"] == "run_started")
            commit = start["source_commit"]
            if start["source_dirty"] is not False or (stage != "development" and commit != final_commit):
                raise ValueError(f"Unexpected source provenance: {directory}")
            provenance = {"source_commit": commit, "source_sha256": start["source_sha256"]}
            if stage in sources and sources[stage] != provenance:
                raise ValueError(f"Mixed source hashes in {stage}")
            sources[stage] = provenance
            completed = [e for e in events if e["event"] == "run_completed"]
            if len(completed) != 1 or any(e["event"] == "run_failed" for e in events):
                raise ValueError(f"Incomplete run: {directory}")
            if summary["labels_requested"] > config.max_labels or summary["experiments"] > config.max_experiments:
                raise ValueError(f"Budget exceeded: {directory}")
            if summary["tokens"] > config.max_tokens:
                raise ValueError(f"Token allowance exceeded: {directory}")
            if summary["adaptation_train_seconds"] > config.max_train_seconds:
                raise ValueError(f"Training allowance exceeded: {directory}")
            if summary["labels_released"] + summary["labels_unreleased"] != summary["labels_requested"]:
                raise ValueError(f"Label accounting mismatch: {directory}")
            if summary["peak_prediction_cache"] > int(np.ceil(config.label_fraction * config.batch_size)) * (config.label_delay + 1):
                raise ValueError(f"Unbounded online prediction cache: {directory}")
            if summary.get("peak_label_history", 0) > max(config.history_windows):
                raise ValueError(f"Unbounded training history: {directory}")
            curve = rows(directory / "curve.csv")
            losses = [float(row["loss"]) for row in curve]
            if len(losses) != config.n_batches or not np.isfinite(losses).all() or abs(np.mean(losses) - summary["mean_loss"]) > 1e-12:
                raise ValueError(f"Loss or stream accounting mismatch: {directory}")
            with np.load(directory / "predictions.npz", allow_pickle=False) as archive:
                if archive["predictions"].shape != (config.n_batches, config.batch_size) or not np.isfinite(archive["predictions"]).all():
                    raise ValueError(f"Invalid saved predictions: {directory}")
            pending = None
            for event in events:
                if event["event"] == "candidate_frozen":
                    if pending is not None:
                        raise ValueError(f"Overlapping frozen candidates: {directory}")
                    pending = event["candidate_id"]
                if event["event"] == "experiment_started":
                    if pending is not None:
                        raise ValueError(f"Search during independent validation: {directory}")
                    if "train_max_step" in event and not event["train_max_step"] < event["validation_min_step"] <= event["step"] - config.label_delay:
                        raise ValueError(f"Temporal selection split violation: {directory}")
                if event.get("reason") == "independent_future_labels":
                    if not (event["gate_min_source_step"] > event["frozen_at"] and
                            event["gate_max_source_step"] + config.label_delay <= event["step"] and
                            event["gate_samples"] >= config.min_validation):
                        raise ValueError(f"Independent gate violation: {directory}")
                if event["event"] in ("deploy", "experiment_rejected") and "candidate_id" in event:
                    if pending != event["candidate_id"]:
                        raise ValueError(f"Unknown candidate decision: {directory}")
                    pending = None
                    waits[stage].append(event["step"] - event["frozen_at"])
            if pending is not None:
                raise ValueError(f"Unfinished candidate: {directory}")
            model = RidgeModel.load(directory / "deployed.npz")
            checkpoints = sorted(directory.glob("model-v*.npz"), key=lambda p: int(p.stem[7:]))
            checkpoint = RidgeModel.load(checkpoints[-1] if checkpoints else directory / "initial.npz")
            features = np.random.default_rng(4421).normal(size=(24, config.n_features))
            if not np.array_equal(model.predict(features), checkpoint.predict(features)):
                raise ValueError(f"Checkpoint prediction mismatch: {directory}")
            verified += 1
            if stage == "development":
                diagnostics = drift_diagnostics(config, losses, [e["step"] for e in events if e["event"] == "drift_detected"])
                variant = event_path.relative_to(root / stage).parts[0]
                corrected[(variant, config.task, config.scenario, raw["policy"])].append(diagnostics)
    corrected_groups = []
    for (variant, task, scenario, policy), values in corrected.items():
        corrected_groups.append({"variant": variant, "task": task, "scenario": scenario, "policy": policy,
            **{key: avg(values, key) for key in ("drift_changes", "missed_changes", "false_alarms",
                "mean_detection_delay_batches", "post_drift_cumulative_loss")}})
    return {"counts": counts, "total_runs": verified, "all_invariants_passed": True, "sources": sources,
        "max_wait_batches": {key: max(value, default=0) for key, value in waits.items()},
        "development_corrected_diagnostics": corrected_groups}


def paired_groups(root):
    baseline = rows(root / "acceptance/legacy/summary.csv")
    front = rows(root / "acceptance/future-frontloaded/summary.csv")
    candidate = rows(root / "acceptance/adaptive/summary.csv")
    result = []
    for task in ("classification", "regression"):
        for scenario in ("stable", "abrupt", "gradual", "recurring", "covariate", "noise"):
            def group(data, policy):
                return sorted([r for r in data if (r["task"], r["scenario"], r["policy"]) ==
                              (task, scenario, policy)], key=lambda r: int(r["seed"]))
            old, new, previous = group(baseline, "drift"), group(candidate, "drift"), group(front, "drift")
            static = group(candidate, "static")
            if [r["mean_loss"] for r in static] != [r["mean_loss"] for r in group(baseline, "static")]:
                raise ValueError("Static predictions changed across paired configurations")
            if [int(r["seed"]) for r in old] != [211, 223, 227, 229, 233] or len(new) != 5:
                raise ValueError("Fresh paired seed set mismatch")
            delta = np.array([float(n["mean_loss"]) - float(o["mean_loss"]) for n, o in zip(new, old)])
            static_delta = np.array([float(n["mean_loss"]) - float(s["mean_loss"]) for n, s in zip(new, static)])
            half = 2.776445 * float(delta.std(ddof=1)) / np.sqrt(5)
            result.append({"task": task, "scenario": scenario, "static_loss": avg(static, "mean_loss"),
                "legacy_loss": avg(old, "mean_loss"), "future_frontloaded_loss": avg(previous, "mean_loss"),
                "candidate_loss": avg(new, "mean_loss"), "paired_delta_vs_legacy": delta.tolist(),
                "paired_delta_vs_static": static_delta.tolist(), "delta_std": float(delta.std(ddof=1)),
                "descriptive_t95_delta_vs_legacy": [float(delta.mean() - half), float(delta.mean() + half)],
                **{f"candidate_{key}": avg(new, key) for key in ("labels_requested", "labels_released",
                    "updates", "experiments", "adaptation_train_seconds", "prediction_seconds", "model_evaluation_seconds",
                    "candidate_wait_max_batches", "mean_detection_delay_batches", "missed_changes", "false_alarms",
                    "post_drift_cumulative_loss", "history_reuses", "peak_prediction_cache", "peak_label_history")}})
    return result


def summarize_other(root):
    model_groups = defaultdict(list)
    for row in rows(root / "robustness/summary.csv"):
        model_groups[(row["synthetic_case"], row["task"], row["model_family"], row["policy"])].append(row)
    models = [{"case": case, "task": task, "family": family, "policy": policy,
        **{key: avg(values, key) for key in ("mean_loss", "false_positive_rate", "false_negative_rate",
            "initial_train_seconds", "adaptation_train_seconds", "prediction_seconds", "labels_requested")}}
        for (case, task, family, policy), values in model_groups.items()]
    stress = []
    for name in ("delay-6", "labels-10pct", "period-4", "period-16"):
        data = rows(root / "stress" / name / "summary.csv")
        for task in ("classification", "regression"):
            new, static = ([r for r in data if r["task"] == task and r["policy"] == p] for p in ("drift", "static"))
            stress.append({"condition": name, "task": task, "candidate_loss": avg(new, "mean_loss"),
                "static_loss": avg(static, "mean_loss"), "at_or_below_static": avg(new, "mean_loss") <= avg(static, "mean_loss"),
                "max_wait_batches": max(float(r["candidate_wait_max_batches"]) for r in new),
                "labels_requested": avg(new, "labels_requested"), "missed_changes": avg(new, "missed_changes")})
    return models, stress


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    root = args.root
    receipt = read_json(root / "delivery/container-receipt-validated.json")
    checked = audit(root, receipt["source_commit"])
    models, stress = summarize_other(root)
    result = {"date": "2026-11-04", "candidate": "adaptive", "default_promoted": False,
        "development_selection": read_json(root / "development/selection.json"),
        "assessment": read_json(root / "acceptance/assessment.json"), "paired_groups": paired_groups(root),
        "stress": stress, "models": models, "audit": checked,
        "container": {k: v for k, v in receipt.items() if k not in ("runtime_logs", "sampled_memory")},
        "analysis_script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "diagnostic_correction": "recurring changes start at drift_start; development diagnostics recomputed without overwriting originals",
        "timing_scope": "Linux CPU wall times, compared separately from Windows; no official scoring formula"}
    write_json(root / "assessment.json", result)
    write_json(root / "robustness-summary.json", {"models": models, "stress": stress})
    lines = ["# 本地优化实验结果", "", f"已审计 {checked['total_runs']} 次完整运行，时间隔离、配额、候选独立门控和模型检查点全部通过。",
             "", "默认不晋级；以下为模拟指标，不代表官方成绩。", "",
             "| 任务 | 场景 | 静态 | 旧默认 | 原未来门控 | 自适应调度 |", "| --- | --- | ---: | ---: | ---: | ---: |"]
    for group in result["paired_groups"]:
        lines.append(f"| {group['task']} | {group['scenario']} | {group['static_loss']:.6f} | {group['legacy_loss']:.6f} | {group['future_frontloaded_loss']:.6f} | {group['candidate_loss']:.6f} |")
    lines += ["", "## 压力边界", "", "| 条件 | 任务 | 静态 | 候选 | 不高于静态 |", "| --- | --- | ---: | ---: | --- |"]
    for group in stress:
        lines.append(f"| {group['condition']} | {group['task']} | {group['static_loss']:.6f} | {group['candidate_loss']:.6f} | {group['at_or_below_static']} |")
    lines += ["", "逐种子配对差值、离散程度、成本、模型对照及修正后的开发诊断见同目录 assessment.json。",
              "t 区间仅为小样本描述；晋级仍按预登记均值门槛判断。"]
    (root / "results.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"total_runs": checked["total_runs"], "candidate_passed": result["assessment"]["candidate_passed"],
                      "audit_passed": checked["all_invariants_passed"]}))


if __name__ == "__main__":
    main()
