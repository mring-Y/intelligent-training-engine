"""Offline Ridge versus depth-3 decision-tree benchmark on nonlinear data."""

import argparse
import json
import os
import platform
import time

import numpy as np

from ite.models import RidgeModel


def _sample(rows, n_features, rng):
    features = rng.uniform(-2.0, 2.0, size=(rows, n_features))
    boundaries = np.asarray([-1.1, -0.2, 0.7])
    levels = np.asarray([-3.0, 1.5, -1.0, 2.5])
    regime = levels[np.digitize(features[:, 0], boundaries)]
    targets = regime + 0.04 * np.sin(3.0 * features[:, 1]) + rng.normal(0.0, 0.03, rows)
    return features, targets


def make_nonlinear_data(train_rows=6000, test_rows=1500, n_features=8, seed=20261108):
    """Return a reproducible four-regime regression problem with distractor features."""
    if (type(train_rows) is not int or train_rows < 32 or
            type(test_rows) is not int or test_rows < 8 or
            type(n_features) is not int or n_features < 2 or
            type(seed) is not int):
        raise ValueError("Invalid synthetic benchmark dimensions or seed")
    rng = np.random.default_rng(seed)
    train_x, train_y = _sample(train_rows, n_features, rng)
    test_x, test_y = _sample(test_rows, n_features, rng)
    return train_x, train_y, test_x, test_y


def run_benchmark(train_rows=6000, test_rows=1500, n_features=8, seed=20261108,
                  max_depth=3, max_tree_seconds=3.0):
    if max_depth != 3:
        raise ValueError("This benchmark fixes DecisionTreeRegressor max_depth at 3")
    if not np.isfinite(max_tree_seconds) or max_tree_seconds <= 0:
        raise ValueError("max_tree_seconds must be finite and positive")
    try:
        import sklearn
        from sklearn.tree import DecisionTreeRegressor
        from threadpoolctl import threadpool_limits
    except ImportError as error:
        raise RuntimeError("Offline tree benchmark requires scikit-learn and threadpoolctl") from error

    train_x, train_y, test_x, test_y = make_nonlinear_data(
        train_rows=train_rows, test_rows=test_rows, n_features=n_features, seed=seed)
    ridge = RidgeModel(task="regression", alpha=1.0)
    tree = DecisionTreeRegressor(max_depth=3, random_state=seed)

    with threadpool_limits(limits=1):
        started = time.perf_counter()
        ridge.fit(train_x, train_y)
        ridge_seconds = time.perf_counter() - started
        started = time.perf_counter()
        tree.fit(train_x, train_y)
        tree_seconds = time.perf_counter() - started

    ridge_mse = float(np.mean(np.square(test_y - ridge.predict(test_x))))
    tree_mse = float(np.mean(np.square(test_y - tree.predict(test_x))))
    return {
        "dataset": {
            "kind": "four_regime_piecewise_nonlinear_regression",
            "train_rows": train_rows,
            "test_rows": test_rows,
            "n_features": n_features,
            "seed": seed,
            "target": "piecewise(x0) + 0.04*sin(3*x1) + N(0, 0.03)",
        },
        "models": {
            "ridge": {"fit_seconds": ridge_seconds, "test_mse": ridge_mse},
            "decision_tree": {
                "max_depth": 3,
                "actual_depth": int(tree.get_depth()),
                "leaves": int(tree.get_n_leaves()),
                "thread_limit": 1,
                "fit_seconds": tree_seconds,
                "test_mse": tree_mse,
                "within_time_limit": tree_seconds <= max_tree_seconds,
                "time_limit_seconds": float(max_tree_seconds),
            },
        },
        "environment": {
            "python": platform.python_version(),
            "platform": platform.platform(),
            "numpy": np.__version__,
            "scikit_learn": sklearn.__version__,
            "host_logical_cpus": os.cpu_count(),
            "container_cpu_memory_limit_verified": False,
        },
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--train-rows", type=int, default=6000)
    parser.add_argument("--test-rows", type=int, default=1500)
    parser.add_argument("--features", type=int, default=8)
    parser.add_argument("--seed", type=int, default=20261108)
    parser.add_argument("--max-tree-seconds", type=float, default=3.0)
    args = parser.parse_args(argv)
    result = run_benchmark(args.train_rows, args.test_rows, args.features,
                           args.seed, max_tree_seconds=args.max_tree_seconds)
    print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
    return 0 if result["models"]["decision_tree"]["within_time_limit"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
