"""Build frozen official-MLP replay evidence and an optional bounded Teacher pilot."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import sys

from ite.official_model import OFFICIAL_PROFILES, OfficialModelAdapter
from ite.official_sft_data import DRIFT, NOTICE, SCENARIOS, export_samples, load_public_package, split_sources
from ite.official_sft_replay import replay_partition
from ite.tracking import source_metadata


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OFFLINE = ROOT / "outputs/official-sft-20261112/offline"
DEFAULT_TEACHER = ROOT / "outputs/official-sft-20261112/teacher"
DEFAULT_PAYMENT = ROOT / "outputs/official-sft-20261112/records/payment-preflight.json"
DEFAULT_PRICES = ROOT / "outputs/official-sft-20261112/records/model-prices-current.json"
DEFAULT_PRICES_URL = "https://pytrio.cn/api/model-prices"
MODEL_ALIAS = "qwen38-27b"
MODEL_NAME = "Qwen/Qwen3.8-27B"
PAID_STATE = ROOT / "outputs/official-sft-27b-paid-state-20261112"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def case_plan():
    return [{"profile": profile, "scenario": scenario, "split": split,
             "decision_steps": (3, 7) if split == "train" else (3,)}
            for profile in "ABC" for scenario in SCENARIOS
            for split in ("train", "eval")]


def verify_payment_preflight(payment_path=DEFAULT_PAYMENT, pricing_path=DEFAULT_PRICES):
    payment_path, pricing_path = Path(payment_path), Path(pricing_path)
    if not payment_path.is_file() or not pricing_path.is_file():
        raise FileNotFoundError("Fresh payment screenshot evidence and current PyTRiO prices are required")
    payment = json.loads(payment_path.read_text(encoding="utf-8"))
    prices = json.loads(pricing_path.read_text(encoding="utf-8"))
    try:
        balance = float(payment["cash_balance_cny"])
        timestamp = datetime.fromisoformat(payment["verified_at"].replace("Z", "+00:00"))
        item = next(item for item in prices["items"] if item["alias"] == MODEL_ALIAS)
        input_price = float(item["prices"]["prefill"]["unit_price"]) / 100
        output_price = float(item["prices"]["sample"]["unit_price"]) / 100
    except (KeyError, ValueError, StopIteration, TypeError, IndexError):
        raise ValueError("Payment evidence or current 27B price response is incomplete") from None
    if (payment.get("source") != "user_provided_balance_screenshot" or not math.isfinite(balance) or balance < .50 or
            timestamp.tzinfo is None or not 0 <= (datetime.now(timezone.utc) - timestamp).total_seconds() <= 86400 or
            prices.get("currency") != "CNY" or prices.get("token_unit") != "per_1m_tokens" or
            item.get("display_name") != MODEL_NAME or (input_price, output_price) != (3.15, 25.29)):
        raise ValueError("The current balance or Qwen3.8-27B price ceiling is not verified")
    screenshot = Path(payment.get("screenshot_path", ""))
    if not screenshot.is_file() or digest(screenshot) != payment.get("screenshot_sha256"):
        raise ValueError("The user-provided balance screenshot must be retained with a matching digest")
    return {"cash_balance_cny": f"{balance:.2f}", "source": payment["source"],
            "verified_at": timestamp.isoformat(), "model": MODEL_NAME,
            "input_price_per_million": f"{input_price:.2f}",
            "output_price_per_million": f"{output_price:.2f}",
            "pricing_response_sha256": digest(pricing_path), "pricing_source": DEFAULT_PRICES_URL}


def _model(profile, runtime_python):
    if not Path(runtime_python).is_file():
        raise FileNotFoundError(f"Official isolated runtime does not exist: {runtime_python}")
    return OfficialModelAdapter(OFFICIAL_PROFILES[profile]["task"], str(runtime_python), profile_type=profile)


def _partition_case(case, data, runtime_python, output, decide):
    partition = split_sources(data)
    model = _model(case["profile"], runtime_python)
    path = output / f"{case['profile']}-{case['scenario']}-{case['split']}"
    result = replay_partition(data, partition[case["split"]], case["split"], case["scenario"], path,
        model, decide, decision_steps=case["decision_steps"])
    print(f"Completed {path.name}: updates={result['updates']}, fits={result['training_attempts']}, gain={result['paired_primary_gain']:.6g}", flush=True)
    return {"case": case, "output": path.name,
            "source_rows": len(partition[case["split"]]),
            "source_ids_sha256": hashlib.sha256("\n".join(
                data["ids"][i] for i in partition[case["split"]]).encode()).hexdigest(),
            "evidence_files": {name: digest(path / name) for name in ("events.jsonl", "predictions.npz", "summary.json")},
            "summary": result}


def offline_decision(context):
    # A controlled worker/gate probe, not a learned decision or an optimal label.
    action = "RETRAIN_LARGE" if context["step"] == 3 or context["observation"]["drift_alarm"] else "DO_NOTHING"
    return {"action": action, "reason": "离线预检请求真实resume以验证隔离、筛选及未来门控。",
            "source": "offline_mock"}


def verify_offline_preflight(offline_dir):
    offline_dir = Path(offline_dir)
    path = offline_dir / "manifest.json"
    if not path.is_file():
        raise ValueError("Complete offline preflight manifest is required")
    result = json.loads(path.read_text(encoding="utf-8"))
    cases = result.get("cases", [])
    expected = {(case["profile"], case["scenario"], case["split"]) for case in case_plan()}
    observed = {(case["case"]["profile"], case["case"]["scenario"], case["case"]["split"]) for case in cases}
    if (result.get("mode") != "offline_preflight" or len(cases) != 18 or observed != expected or
            not result.get("engineering_preflight_passed") or
            result.get("source", {}).get("source_sha256") != source_metadata()["source_sha256"]):
        raise ValueError("Offline preflight is incomplete or belongs to a different source")
    if result.get("runner_sha256") != digest(Path(__file__)):
        raise ValueError("Offline runner digest does not match the frozen implementation")
    for case in cases:
        directory = offline_dir / "runs" / case["output"]
        if directory.parent != offline_dir / "runs":
            raise ValueError("Invalid offline evidence path")
        if set(case["evidence_files"]) != {"events.jsonl", "predictions.npz", "summary.json"}:
            raise ValueError("Offline evidence files are incomplete")
        for name, expected_digest in case["evidence_files"].items():
            if name not in ("events.jsonl", "predictions.npz", "summary.json") or digest(directory / name) != expected_digest:
                raise ValueError("Offline evidence digest mismatch")
        events = [json.loads(line) for line in (directory / "events.jsonl").read_text(encoding="utf-8").splitlines()]
        summary = json.loads((directory / "summary.json").read_text(encoding="utf-8"))
        if not _engineering_ok(summary, events):
            raise ValueError("Offline evidence does not show a complete bounded resume preflight")
    return result


def _engineering_ok(summary, events):
    candidates = [e for e in events if e["event"] == "candidate_evaluated"]
    return (sum(e["event"] == "prediction" for e in events) == 12 and
        not any(e["event"] == "training_failed" for e in events) and bool(candidates) and
        all(e["candidate_adam_steps"] > e["parent_adam_steps"] and 0 < e["train_seconds"] <= 5
            and not set(e["train_source_ids"]) & set(e["screening_source_ids"]) for e in candidates) and
        summary["train_seconds"] <= 20)


def run_offline(output_dir=DEFAULT_OFFLINE, *, runtime_python=None):
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=False)
    runs = output / "runs"
    runs.mkdir()
    runtime_python = runtime_python or os.environ.get("ITE_OFFICIAL_RUNTIME_PYTHON",
        ROOT / ".venv-official-a/Scripts/python.exe")
    data = {profile: load_public_package(profile) for profile in "ABC"}
    source_freeze = {profile: {"package_sha256": data[profile]["package_sha256"],
        "feature_count": data[profile]["x"].shape[1], "rows": len(data[profile]["ids"]),
        "reported_baseline": data[profile]["reported_baseline"],
        "split": {key: len(value) if isinstance(value, list) else value
                  for key, value in split_sources(data[profile]).items()}}
        for profile in "ABC"}
    (output / "source-freeze.json").write_text(json.dumps({"sources": source_freeze,
        "drift": DRIFT, "scenarios": SCENARIOS, "plan": case_plan(), "notice": NOTICE,
        "source": source_metadata()}, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    cases = []
    for case in case_plan():
        result = _partition_case(case, data[case["profile"]], runtime_python, runs, offline_decision)
        cases.append(result)
    engineering_ok = True
    for case in cases:
        events = [json.loads(line) for line in (runs / case["output"] / "events.jsonl").read_text(encoding="utf-8").splitlines()]
        engineering_ok &= _engineering_ok(case["summary"], events)
    manifest = {"mode": "offline_preflight", "notice": NOTICE,
        "logical_scenarios": len({(c["profile"], c["scenario"]) for c in case_plan()}),
        "physical_partitions": len(cases), "teacher_requests": 0,
        "engineering_preflight_passed": bool(engineering_ok), "source": source_metadata(),
        "runner_sha256": digest(Path(__file__)), "cases": cases}
    (output / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False,
        indent=2, allow_nan=False), encoding="utf-8")
    return manifest


def run_teacher(offline_dir, output_dir=DEFAULT_TEACHER, *, payment_path=DEFAULT_PAYMENT,
                pricing_path=DEFAULT_PRICES, runtime_python=None, worker_python=None):
    offline_dir, output = Path(offline_dir), Path(output_dir)
    manifest_path = offline_dir / "manifest.json"
    verify_offline_preflight(offline_dir)
    payment = verify_payment_preflight(payment_path, pricing_path)
    from ite.official_sft_teacher import TeacherSession, verify_teacher_tokenizer, verify_teacher_runtime
    tokenizer = verify_teacher_tokenizer()
    worker_python = Path(worker_python or ROOT / ".venv-sft/Scripts/python.exe").resolve()
    if not worker_python.is_file() or worker_python == Path(sys.executable).resolve():
        raise ValueError("Teacher must run in a provisioned isolated Python environment")
    runtime = verify_teacher_runtime(worker_python)
    claim = {"mode": "single_use_teacher_pilot", "limits": {"calls": 30, "cost_cny": "0.50",
        "input_tokens": 1250, "output_tokens": 128, "deadline_seconds": 15, "retries": 0},
        "payment": payment, "offline_manifest_sha256": digest(manifest_path),
        "teacher_tokenizer": tokenizer, "source": source_metadata(),
        "worker_python": str(worker_python), "worker_runtime": runtime}
    if output.exists():
        raise FileExistsError("Teacher output cannot be overwritten")
    PAID_STATE.mkdir(parents=True, exist_ok=True)
    with (PAID_STATE / "run-claim.json").open("x", encoding="utf-8") as stream:
        json.dump({**claim, "output": str(output.resolve())}, stream, ensure_ascii=False, indent=2)
    output.mkdir(parents=True, exist_ok=False)
    session_root = output / "session"
    session_root.mkdir()
    (output / "run-claim.json").write_text(json.dumps(claim, ensure_ascii=False,
        indent=2, allow_nan=False), encoding="utf-8")
    teacher = TeacherSession(session_root, runtime_python=worker_python)
    teacher_events = output / "teacher-decisions"
    teacher_events.mkdir()
    data = {profile: load_public_package(profile) for profile in "ABC"}
    cases = []
    for case in case_plan():
        result = _partition_case(case, data[case["profile"]], runtime_python or
            os.environ.get("ITE_OFFICIAL_RUNTIME_PYTHON", ROOT / ".venv-official-a/Scripts/python.exe"),
            teacher_events, teacher.decide)
        cases.append(result)
    records = [record for case in cases for record in case["summary"]["records"]]
    counts = export_samples(records, output / "dataset")
    summary = {"mode": "teacher_pilot", "notice": NOTICE, "cases": cases, "dataset_counts": counts,
               "ledger": teacher.ledger.snapshot(), "teacher_events_sha256": digest(session_root / "teacher-events.jsonl"),
               "source": source_metadata()}
    (output / "manifest.json").write_text(json.dumps(summary, ensure_ascii=False,
        indent=2, allow_nan=False), encoding="utf-8")
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("offline", "teacher"), default="offline")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--offline-dir", type=Path, default=DEFAULT_OFFLINE)
    parser.add_argument("--payment-evidence", type=Path, default=DEFAULT_PAYMENT)
    parser.add_argument("--pricing-response", type=Path, default=DEFAULT_PRICES)
    parser.add_argument("--official-python", type=Path)
    parser.add_argument("--worker-python", type=Path)
    args = parser.parse_args()
    if args.mode == "offline":
        result = run_offline(args.output or DEFAULT_OFFLINE, runtime_python=args.official_python)
    else:
        result = run_teacher(args.offline_dir, args.output or DEFAULT_TEACHER,
            payment_path=args.payment_evidence, pricing_path=args.pricing_response,
            runtime_python=args.official_python, worker_python=args.worker_python)
    print(json.dumps({key: result[key] for key in result if key != "cases"}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
