"""Build synthetic A-package proxies and run a local 10-batch Mock Harness rehearsal."""

import argparse
import json
from dataclasses import replace
from pathlib import Path

import numpy as np

from ite.config import ExperimentConfig
from ite.data import make_simulation
from ite.providers import ColumnMapping, ParquetDataProvider
from ite.runner import run_policy
from ite.training import BoundedTrainer


FULL_BATCHES = 96
BATCH_SIZE = 96
INITIAL_TRAIN = 512
INITIAL_VALIDATION = 256


PROFILES = {
    "gas_sensor": {
        "task": "classification",
        "n_features": 24,
        "relationship": "nonlinear",
        "data_type": "synthetic_sensor_drift_proxy",
        "streams": (("abrupt", 8, 16),),
        "description": "High-dimensional nonlinear gas-sensor concept drift proxy.",
    },
    "bearing": {
        "task": "regression",
        "n_features": 12,
        "relationship": "nonlinear",
        "data_type": "synthetic_degradation_proxy",
        "streams": (("gradual", 8, 24), ("abrupt", 8, 16)),
        "description": "Bearing degradation regression proxies with gradual and abrupt changes.",
    },
    "engine_rul": {
        "task": "regression",
        "n_features": 8,
        "relationship": "nonlinear",
        "data_type": "proxy_stream_requires_official_mapping",
        "streams": (("gradual", 8, 64),),
        "description": (
            "Ninety-six batch gradual-drift proxy; not a per-engine trajectory or physical RUL model."
        ),
        "limitations": (
            "Synthetic batch-level gradual-drift proxy only. Replace the feature, target, unit and cycle "
            "mapping with official RUL fields before drawing task-level conclusions."
        ),
    },
}


def _write_parquet(path, columns, row_group_size):
    try:
        import pyarrow as pa
        import pyarrow.parquet as pq
    except ImportError as error:
        raise RuntimeError("Mock A package generation requires optional pyarrow==22.0.0") from error
    pq.write_table(pa.Table.from_pydict(columns), path, compression="zstd",
                   row_group_size=row_group_size, use_dictionary=False)


def _initial_columns(features, targets, feature_names, first_id):
    rows = len(targets)
    columns = {name: features[:, index] for index, name in enumerate(feature_names)}
    columns.update({
        "label": targets,
        "sample_id": np.arange(first_id, first_id + rows, dtype=np.int64),
    })
    return columns


def _stream_columns(simulation, feature_names, seed, label_delay, id_base):
    features = np.concatenate([batch.features for batch in simulation.batches]).astype(float, copy=True)
    released_targets = []
    for batch in simulation.batches:
        if simulation.oracle.request(batch.sample_ids, batch.step) != len(batch.sample_ids):
            raise RuntimeError("Synthetic package oracle did not provide every generated label")
        released = simulation.oracle.release(batch.step + label_delay)
        if released is None or len(released.targets) != len(batch.sample_ids):
            raise RuntimeError("Synthetic package oracle did not release the current batch")
        released_targets.extend(released.targets.tolist())
    targets = list(released_targets)
    sample_ids = np.arange(id_base, id_base + len(features), dtype=np.int64)
    batch_ids = np.repeat(np.arange(len(simulation.batches), dtype=np.int64),
                          [len(batch.sample_ids) for batch in simulation.batches])
    rng = np.random.default_rng(seed + 37)
    timestamps = 1_800_000_000 + np.arange(len(features), dtype=np.int64) * 300
    timestamps[BATCH_SIZE * 5:] += 3_600
    for step in range(len(simulation.batches)):
        start = step * BATCH_SIZE
        end = start + BATCH_SIZE
        timestamps[start:end] = rng.permutation(timestamps[start:end])

    features[0, 0] = np.nan
    features[1, 1] = np.inf
    features[2, 2] = float(np.finfo(np.float32).max) * 4.0
    targets[3] = None

    columns = {name: features[:, index] for index, name in enumerate(feature_names)}
    columns.update({
        "label": targets,
        "sample_id": sample_ids,
        "batch_id": batch_ids,
        "timestamp": timestamps,
    })
    return columns


def _stream_cases(columns, feature_names, sample_ids):
    timestamps = np.asarray(columns["timestamp"])
    return {
        "missing_feature_value_id": int(sample_ids[0]),
        "infinite_feature_value_id": int(sample_ids[1]),
        "float32_overflow_value_id": int(sample_ids[2]),
        "missing_target_id": int(sample_ids[3]),
        "missing_channel": feature_names[-1],
        "timestamp_is_monotonic": bool(np.all(np.diff(timestamps) >= 0)),
    }


def make_mock_a_package(output, seed=20261108, smoke_batches=10):
    if type(seed) is not int or seed < 0:
        raise ValueError("seed must be a nonnegative integer")
    if type(smoke_batches) is not int or not 1 <= smoke_batches <= FULL_BATCHES:
        raise ValueError(f"smoke_batches must be in [1, {FULL_BATCHES}]")

    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    datasets = {}
    for dataset_index, (dataset_name, profile) in enumerate(PROFILES.items()):
        folder = output / dataset_name
        folder.mkdir()
        feature_names = tuple(f"sensor_{index:02d}" for index in range(profile["n_features"]))
        mapping = {
            "features": list(feature_names),
            "target": "label",
            "sample_id": "sample_id",
            "batch": "batch_id",
        }
        streams = {}
        initial_written = False

        for stream_index, (scenario, drift_start, drift_width) in enumerate(profile["streams"]):
            stream_seed = seed + dataset_index * 100 + stream_index
            config = ExperimentConfig(
                seed=stream_seed,
                task=profile["task"],
                scenario=scenario,
                n_features=profile["n_features"],
                initial_train=INITIAL_TRAIN,
                initial_validation=INITIAL_VALIDATION,
                n_batches=FULL_BATCHES,
                batch_size=BATCH_SIZE,
                drift_start=drift_start,
                drift_width=drift_width,
                label_delay=2,
                label_fraction=0.25,
                max_labels=FULL_BATCHES * 24,
                label_mode="provided",
                deployment_validation="future",
                relationship=profile["relationship"],
            )
            simulation = make_simulation(config)
            if not initial_written:
                initial_train = f"{dataset_name}/initial_train.parquet"
                initial_validation = f"{dataset_name}/initial_validation.parquet"
                _write_parquet(
                    output / initial_train,
                    _initial_columns(simulation.initial.train_x, simulation.initial.train_y,
                                    feature_names, dataset_index * 1_000_000),
                    row_group_size=128,
                )
                _write_parquet(
                    output / initial_validation,
                    _initial_columns(simulation.initial.validation_x, simulation.initial.validation_y,
                                    feature_names, dataset_index * 1_000_000 + 100_000),
                    row_group_size=128,
                )
                initial_written = True

            stream_id_base = (dataset_index + 1) * 10_000_000
            columns = _stream_columns(simulation, feature_names, stream_seed,
                                      config.label_delay, stream_id_base)
            all_ids = columns["sample_id"]
            full_name = f"{dataset_name}/stream_{scenario}.parquet"
            _write_parquet(output / full_name, columns, row_group_size=BATCH_SIZE)

            smoke_drift_start = min(2, smoke_batches - 2)
            smoke_drift_width = (min(drift_width, max(2, smoke_batches // 2))
                                 if scenario == "gradual" else drift_width)
            smoke_config = replace(
                config,
                n_batches=smoke_batches,
                drift_start=smoke_drift_start,
                drift_width=smoke_drift_width,
                max_labels=smoke_batches * 24,
            )
            smoke_simulation = make_simulation(smoke_config)
            smoke_columns = _stream_columns(
                smoke_simulation, feature_names, stream_seed + 1_000,
                smoke_config.label_delay, stream_id_base)
            smoke_name = f"{dataset_name}/smoke_{scenario}.parquet"
            _write_parquet(output / smoke_name, smoke_columns, row_group_size=BATCH_SIZE)

            missing_channel_columns = {
                name: values for name, values in smoke_columns.items() if name != feature_names[-1]
            }
            missing_channel_name = f"{dataset_name}/smoke_{scenario}_missing_channel.parquet"
            _write_parquet(output / missing_channel_name, missing_channel_columns,
                           row_group_size=BATCH_SIZE)

            streams[scenario] = {
                "drift_start": drift_start,
                "drift_width": drift_width,
                "smoke_drift_start": smoke_drift_start,
                "smoke_drift_width": smoke_drift_width,
                "sequence_batches": FULL_BATCHES,
                "smoke_batches": smoke_batches,
                "full": full_name,
                "smoke": smoke_name,
                "smoke_missing_channel": missing_channel_name,
                "dirty_cases": _stream_cases(columns, feature_names, all_ids),
            }

        datasets[dataset_name] = {
            "task": profile["task"],
            "relationship": profile["relationship"],
            "data_type": profile["data_type"],
            "description": profile["description"],
            "limitations": profile.get("limitations", "Synthetic concept-drift proxy; not official A-package data."),
            "sequence_batches": FULL_BATCHES,
            "n_features": profile["n_features"],
            "initial_train_rows": INITIAL_TRAIN,
            "initial_validation_rows": INITIAL_VALIDATION,
            "batch_size": BATCH_SIZE,
            "label_delay": 2,
            "mapping": mapping,
            "initial_train": initial_train,
            "initial_validation": initial_validation,
            "metadata_columns": ["timestamp"],
            "streams": streams,
        }

    manifest = {
        "format_version": 1,
        "package_name": "mock_A",
        "source": "ite.data.make_simulation",
        "seed": seed,
        "smoke_batches": smoke_batches,
        "dirty_policy": {
            "feature_nan_inf": "impute_with_initial_train_median_and_audit",
            "feature_float32_overflow": "retain_finite_float64_and_audit_without_clipping",
            "missing_target": "never_impute_or_request",
            "missing_channel": "impute_with_initial_train_median_and_audit",
            "timestamp": "metadata_only_with_gaps_and_out_of_order_values",
        },
        "datasets": datasets,
    }
    (output / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    return manifest


def _package_path(root, relative):
    root = Path(root).resolve()
    candidate = (root / relative).resolve()
    try:
        candidate.relative_to(root)
    except ValueError:
        raise ValueError("Manifest paths must remain inside the package directory") from None
    return candidate


def run_mock_a_rehearsal(package, output, smoke_batches=10):
    package, output = Path(package), Path(output)
    manifest = json.loads((package / "manifest.json").read_text(encoding="utf-8"))
    if type(smoke_batches) is not int or smoke_batches != manifest["smoke_batches"]:
        raise ValueError("Rehearsal batch count must match the generated smoke streams")
    output.mkdir(parents=True, exist_ok=False)
    runs = []

    for dataset_name, item in manifest["datasets"].items():
        mapping = ColumnMapping(**item["mapping"])
        for scenario, stream in item["streams"].items():
            run_name = f"{dataset_name}-{scenario}"
            provider = ParquetDataProvider(
                _package_path(package, stream["smoke_missing_channel"]), mapping,
                initial_train_path=_package_path(package, item["initial_train"]),
                initial_validation_path=_package_path(package, item["initial_validation"]),
                label_delay=item["label_delay"],
                max_labels=smoke_batches * 24,
            )
            config = ExperimentConfig(
                seed=manifest["seed"],
                task=item["task"],
                scenario=scenario,
                n_features=item["n_features"],
                initial_train=item["initial_train_rows"],
                initial_validation=item["initial_validation_rows"],
                n_batches=smoke_batches,
                batch_size=item["batch_size"],
                drift_start=stream["smoke_drift_start"],
                drift_width=stream["smoke_drift_width"],
                label_delay=item["label_delay"],
                label_fraction=0.25,
                max_labels=smoke_batches * 24,
                max_experiments=2,
                max_train_seconds=20.0,
                candidate_timeout_seconds=3.0,
                candidate_startup_reserve_seconds=1.5,
                history_windows=(192, 384),
                min_labeled=96,
                min_validation=32,
                deployment_validation="future",
                training_preflight=True,
                candidate_feasibility=True,
                relationship=item["relationship"],
                decision_backend="rules",
                max_tokens=8_000,
                harness_enabled=True,
                harness_mock_mode="normal",
                harness_backend="mock",
                max_llm_calls=10,
                max_llm_cost_cny="0.50",
            )
            run_output = output / run_name
            with BoundedTrainer() as trainer:
                summary = run_policy(config, "drift", run_output, trainer, provider=provider)
            events = [json.loads(line) for line in (run_output / "events.jsonl").read_text().splitlines()]
            mock_calls = sum(event["event"] == "harness_call" for event in events)
            decisions = sum(event["event"] == "harness_decision" for event in events)
            predictions = sum(event["event"] == "prediction" for event in events)
            if summary["stream_batches"] != smoke_batches or predictions != smoke_batches:
                raise RuntimeError(f"Incomplete Mock A rehearsal for {run_name}")
            if mock_calls < 1 or decisions < 1:
                raise RuntimeError(f"Mock Harness did not complete a decision for {run_name}")
            if summary["real_llm_tokens"] != 0:
                raise RuntimeError("Mock A rehearsal must not spend real LLM tokens")
            runs.append({
                "dataset": dataset_name,
                "scenario": scenario,
                "stream_batches": summary["stream_batches"],
                "batch_size": item["batch_size"],
                "mock_calls": mock_calls,
                "decisions": decisions,
                "training_attempts": summary["training_attempts"],
                "frozen_candidates": summary["candidates_frozen"],
                "deployments": summary["updates"],
                "output_dir": run_name,
            })

    result = {
        "package": str(package.resolve()),
        "mode": "offline_mock_harness",
        "real_llm_tokens": 0,
        "smoke_batches": smoke_batches,
        "runs": runs,
    }
    (output / "rehearsal.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path,
                        help="new output directory; existing directories are never overwritten")
    parser.add_argument("--seed", type=int, default=20261108)
    parser.add_argument("--smoke-batches", type=int, default=10)
    args = parser.parse_args(argv)
    make_mock_a_package(args.output, seed=args.seed, smoke_batches=args.smoke_batches)
    result = run_mock_a_rehearsal(args.output, args.output / "rehearsal",
                                  smoke_batches=args.smoke_batches)
    print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
