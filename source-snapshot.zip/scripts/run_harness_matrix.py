"""Run exactly the approved offline Mock stress matrix."""

from ite.harness_matrix import main

if __name__ == "__main__":
    raise SystemExit(main())
