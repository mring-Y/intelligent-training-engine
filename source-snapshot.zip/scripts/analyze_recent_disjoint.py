"""Read-only reconstruction and retrospective scoring of the approved split experiment.

No fitting occurs here. Hidden targets are accessed only by this offline analysis.
All output files are exclusive creations; experiment inputs are fingerprinted.
"""
import argparse
import csv
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from ite.config import ExperimentConfig
from ite.data import make_simulation
from ite.labeling import LabelScheduler
from ite.models import RidgeModel
from ite.validation import SCENARIOS, TASKS, _evaluate, _read_matrix

SEEDS = (7, 19, 43)
ARMS = ("control", "recent-disjoint")
FROZEN_CONFIG = ExperimentConfig(n_batches=96, deployment_validation="future", monitor_min_labeled=32,
    label_schedule="adaptive", training_preflight=True, training_weighting="exponential")


def check(condition, message):
    if not condition:
        raise ValueError(message)


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def first_new_window(events, losses, initial_losses):
    steps = [e["step"] for e in events if e["event"] == "prediction" and e["model_version"] > 0]
    result = {"status": "not_deployed", "start": None, "steps": [], "observed_batches": 0,
              "new_loss": None, "initial_loss": None}
    if not steps and any(e["event"] == "deploy" for e in events):
        result["status"] = "incomplete"
    if steps:
        start = steps[0]
        window = list(range(start, min(start + 3, len(losses))))
        result.update(status="complete" if len(window) == 3 else "incomplete", start=start,
                      steps=window, observed_batches=len(window))
        if len(window) == 3:
            result.update(new_loss=float(np.mean(np.asarray(losses)[window])),
                          initial_loss=float(np.mean(np.asarray(initial_losses)[window])))
    return result


def partition_history(ids, event, mode, batch_size, requested=48):
    ids = np.asarray(ids, dtype=int)
    check(len(set(ids.tolist())) == len(ids), "duplicate history identity")
    if mode == "recent_disjoint":
        indices = event["selection_history_indices"]
        check(all(isinstance(i, int) and not isinstance(i, bool) for i in indices), "invalid selection index")
        check(len(set(indices)) == len(indices) and all(0 <= i < len(ids) - 1 for i in indices),
              "duplicate/out-of-range selection indices or latest label selected")
        mask = np.zeros(len(ids), dtype=bool); mask[indices] = True
    else:
        check(mode == "chronological" and len(ids) > 1, "invalid chronological history")
        source = ids // batch_size
        boundary = source[max(1, len(ids) - requested)]
        mask = source >= boundary
    train, validation = ids[~mask], ids[mask]
    check(not set(train.tolist()) & set(validation.tolist()), "overlapping label identities")
    return train, validation


def selection_rule(config):
    requested = max(config.min_validation, min(config.history_windows) // 4)
    mode = config.selection_split
    if mode == "task_specific":
        if config.scenario == "recurring":
            return "chronological", requested
        if config.task == "classification":
            return "recent_disjoint", config.task_specific_classification_pool_samples // 2
        return "recent_disjoint", requested
    return mode, requested


def audit_weights(event, steps, config, latest):
    n = len(steps)
    expected = {"train_samples": n, "train_min_step": int(min(steps)) if n else None,
                "train_max_step": int(max(steps)) if n else None,
                "training_weighting": config.training_weighting,
                "training_half_life_batches": 4.0, "weight_reference_source_step": latest}
    # Relative-to-maximum form avoids numerical underflow; normalization is independent.
    w = np.exp2((np.asarray(steps, dtype=float) - max(steps)) / 4) if n else np.array([])
    if n:
        w *= n / w.sum()
    expected.update(weight_min=float(w.min()) if n else None, weight_max=float(w.max()) if n else None,
                    weight_sum=float(w.sum()), effective_sample_size=float(w.sum() ** 2 / (w @ w)) if n else 0.)
    for key, value in expected.items():
        actual = event.get(key)
        check(actual == value if value is None or isinstance(value, str) else
              actual is not None and np.isclose(actual, value, rtol=1e-12, atol=1e-12), f"weight/source {key}")


def residual_metrics(predictions, targets, scale):
    r = (np.asarray(predictions) - np.asarray(targets)).reshape(-1) / np.sqrt(scale)
    return {"mean": float(r.mean()), "variance": float(r.var()), "mean_squared": float(np.mean(r * r))}


def audit_classification_selection(candidates, record, policy, validation_samples):
    """Rebuild the documented integer-error rule without the controller comparator."""
    completed = []
    for event in candidates:
        errors = event.get("validation_errors")
        loss = event.get("validation_loss")
        if loss is None:
            check(errors is None, "failed candidate has error count")
            continue
        check(isinstance(errors, int) and not isinstance(errors, bool) and
              0 <= errors <= validation_samples and loss == errors / validation_samples,
              "integer classification errors/loss mismatch")
        completed.append({name: event[name] for name in
            ("window", "alpha", "train_samples", "validation_errors", "validation_loss")})
    check(policy in ("legacy", "alpha_desc"), "unknown classification tie policy")
    legacy = min(completed, key=lambda c: c["validation_errors"], default=None)
    selected = (min(completed, key=lambda c: (c["validation_errors"], -c["alpha"], c["window"]),
                    default=None) if policy == "alpha_desc" else legacy)
    minimum = min((c["validation_errors"] for c in completed), default=None)
    tied = sum(c["validation_errors"] == minimum for c in completed)
    comparisons = replacements = 0
    prior = None
    for candidate in completed:
        if prior is not None:
            same_error = candidate["validation_errors"] == prior["validation_errors"]
            comparisons += same_error
            better = (candidate["validation_errors"] < prior["validation_errors"] or
                      policy == "alpha_desc" and same_error and
                      (-candidate["alpha"], candidate["window"]) < (-prior["alpha"], prior["window"]))
        else:
            better, same_error = True, False
        if better:
            replacements += same_error
            prior = candidate
    reason = "no_completed_candidate"
    if selected is not None:
        if policy == "legacy":
            reason = "legacy_first_minimum"
        elif selected["alpha"] != legacy["alpha"]:
            reason = "exact_error_tie_larger_alpha"
        elif selected["window"] != legacy["window"]:
            reason = "exact_error_tie_fixed_window"
        else:
            reason = "exact_error_tie_fixed_key" if tied > 1 else "lowest_error_count"
    expected = {"policy": policy, "candidates_completed": len(completed), "best_error_count": minimum,
        "best_tied_candidates": tied, "equal_error_comparisons": comparisons,
        "tie_replacements": replacements, "legacy_winner": legacy, "selected_winner": selected,
        "reason": reason, "decision_key": (["validation_errors_asc", "alpha_desc", "window_asc"]
            if policy == "alpha_desc" else ["validation_loss_asc", "first_encountered"])}
    check(all(record.get(key) == value for key, value in expected.items()), "classification selection audit mismatch")
    return selected


def audit_paired_configs(control, candidate, factor):
    check(factor in ("selection_split", "classification_tie_break"), "unregistered paired factor")
    check({k for k in control if control[k] != candidate[k]} == {factor}, "single factor config difference")


def audit_run(path):
    path = Path(path)
    raw = read_json(path / "config.json"); policy = raw.pop("policy")
    cfg = ExperimentConfig.from_dict(raw)
    frozen = FROZEN_CONFIG.to_dict()
    for name in ("task", "scenario", "seed", "selection_split", "classification_tie_break"):
        frozen[name] = getattr(cfg, name)
    check(cfg.to_dict() == frozen, "run differs from independently frozen configuration")
    check((cfg.n_batches, cfg.batch_size, cfg.label_delay, cfg.max_labels, cfg.label_fraction, cfg.drift_width) ==
          (96, 96, 2, 864, .25, 8), "fixed stream protocol")
    check(cfg.training_preflight and cfg.training_weighting == "exponential" and
          cfg.training_half_life_batches == 4 and cfg.history_windows == (192, 384, 768) and
          cfg.deployment_validation == "future" and not cfg.reuse_history and
          cfg.train_source_window_batches == 0, "fixed training protocol")
    check(cfg.n_features == 8 and cfg.model_family == "ridge", "fixed model complexity")
    events = [json.loads(line) for line in (path / "events.jsonl").read_text(encoding="utf-8").splitlines()]
    selection_audit_required = cfg.task == "classification" and "classification_tie_break" in raw
    check(events and events[0]["event"] == "run_started" and
          sum(e["event"] == "run_completed" for e in events) == 1 and
          not any(e["event"] == "run_failed" for e in events), "complete event stream")
    origin = events[0]
    check(len(origin["source_commit"]) == 40 and len(origin["source_sha256"]) == 64 and
          origin["source_dirty"] is False and origin["config"] == raw and origin["policy"] == policy,
          "source/config provenance")
    summary = read_json(path / "summary.json")
    with (path / "curve.csv").open(encoding="utf-8", newline="") as stream:
        curve = list(csv.DictReader(stream))
    with np.load(path / "predictions.npz", allow_pickle=False) as values:
        pred = values["predictions"]
    check(pred.shape == (96, 96) and np.isfinite(pred).all() and len(curve) == 96, "finite complete predictions/curve")
    sim = make_simulation(cfg)
    models = {0: RidgeModel.load(path / "initial.npz")}
    models.update({int(p.stem[7:]): RidgeModel.load(p) for p in path.glob("model-v*.npz")})
    counts = Counter(); history = np.array([], dtype=int); requested = {}; used = released = revision = 0
    pending = None; experiments = attempts = version = 0; last = -cfg.cooldown - 1; peak = 0
    train = None; latest = None; esses = []; splits = []; markers = set(); prior_drop = False
    selection_candidates = []; selected_candidate = None
    rng = np.random.default_rng(cfg.seed + 100_003); scheduler = LabelScheduler(cfg)
    by_step = {step: [] for step in range(97)}
    check(all(-1 <= e["step"] <= 96 for e in events), "event step bounds")
    check([e["step"] for e in events] == sorted(e["step"] for e in events), "ordered events")
    check([e["step"] for e in events if e["event"] == "prediction"] == list(range(96)),
          "exactly one prediction per stream batch")
    check(all(0 <= e["step"] < 96 for e in events if e["event"] == "deploy"), "deployment outside stream")
    for e in events:
        if e["step"] >= 0:
            by_step[e["step"]].append(e)
    for step in range(96):
        seq = by_step[step]
        check(seq and seq[0]["event"] == "prediction" and seq[0]["model_version"] == version and
              seq[0]["samples"] == 96, "deploy k+1 prediction version")
        check(version in models and np.array_equal(models[version].predict(sim.batches[step].features), pred[step]),
              f"checkpoint prediction at {step}")
        counts["prediction_batches"] += 1
        requests = [e for e in seq if e["event"] == "labels_requested"]
        check(len(requests) == 1, "single label request")
        req = requests[0]
        desired = 0 if policy == "static" else scheduler.count(step, used, prior_drop, pending is not None)
        check(req["count"] == desired, "label scheduler count")
        ids = rng.choice(sim.batches[step].sample_ids, size=desired, replace=False)
        requested[step] = ids; used += desired
        check(req["total"] == used and used <= cfg.max_labels, "label quota")
        ready = requested.get(step - cfg.label_delay, np.array([], dtype=int))
        release_events = [e for e in seq if e["event"] == "labels_released"]
        check(len(release_events) == int(len(ready) > 0), "release presence")
        if len(ready):
            check(release_events[0]["count"] == len(ready) and
                  release_events[0]["latest_source_step"] == step - 2, "release source/count")
            history = np.concatenate((history, ready))
            history = history[np.argsort(history // 96, kind="stable")][-768:]
            released += len(ready); revision += 1
        peak = max(peak, len(history)); check(len(history) <= 768, "history quota")
        for e in seq:
            kind = e["event"]
            if kind == "monitor":
                prior_drop = e["performance_drop"]
            if kind in ("experiment_started", "training_preflight_skipped"):
                check(pending is None, "no training while candidate pending")
                effective_split, requested_validation = selection_rule(cfg)
                train, val = partition_history(history, e, effective_split, 96, requested_validation)
                ts, vs = train // 96, val // 96; latest = int(max(history // 96))
                check(e["selection_split"] == cfg.selection_split and e["history_samples"] == len(history) and
                      e.get("selection_split_effective") == effective_split and
                      e.get("selection_pool_samples") == (min(len(history), 2 * requested_validation)
                                                           if effective_split == "recent_disjoint" else None) and
                      e["validation_samples"] == len(val) and e["validation_min_step"] == int(min(vs)) and
                      e["validation_max_step"] == int(max(vs)) and
                      e["latest_released_source_step"] == latest and latest <= step - 2 and
                      e["latest_source_train_samples"] == int(sum(ts == latest)) and
                      e["latest_source_validation_samples"] == int(sum(vs == latest)) and
                      e["train_samples_before_filter"] == len(train) and e["train_source_cutoff"] is None,
                      "source split audit")
                if effective_split == "recent_disjoint":
                    check(len(val) == min(requested_validation, max(0, len(history) - 1)) and
                          train[-1] == history[-1] and sum(ts == latest) > 0,
                          "recent selection feasibility/latest train")
                    expected = np.linspace(max(0, len(history) - 2 * requested_validation),
                                            len(history) - 2, len(val), dtype=int).tolist()
                    check(e["selection_history_indices"] == expected, "deterministic recent selection")
                else:
                    check(not len(ts) or max(ts) < min(vs), "chronological source separation")
                audit_weights(e, ts, cfg, latest); counts["source_splits"] += 1
                min_validation = requested_validation if effective_split == "recent_disjoint" else 32
                if kind == "training_preflight_skipped":
                    check(len(train) < 16 or len(val) < min_validation, "preflight infeasible")
                    check(e["experiments"] == experiments and e["training_attempts"] == attempts and
                          e["last_experiment"] == last and e["cooldown_until"] == max(0, last + cfg.cooldown + 1),
                          "preflight no attempt/cooldown consumption")
                    marker = (revision, history.tobytes())
                    check(marker not in markers and e["released_label_revision"] == revision, "preflight evidence")
                    markers.add(marker); counts["preflight_skips"] += 1
                else:
                    check(len(train) >= 16 and len(val) >= min_validation and step - last > cfg.cooldown,
                          "fit feasibility/cooldown")
                    experiments += 1; attempts += 1; last = step
                    selection_candidates = []; selected_candidate = None
                    splits.append({"step": step, "train_source_counts": dict(Counter(map(int, ts))),
                                   "validation_source_counts": dict(Counter(map(int, vs))), "audit": e})
            if kind == "candidate_evaluated":
                check(pending is None and train is not None and e["window"] in cfg.history_windows and
                      e["alpha"] in cfg.candidate_alphas, "candidate parameters/pending")
                candidate = train[-e["window"]:]
                check(candidate[-1] == train[-1], "candidate preserves newest training identity")
                audit_weights(e, candidate // 96, cfg, latest); esses.append(e["effective_sample_size"])
                check(e["status"] == "ok" and not e["error"] and np.isfinite(e["validation_loss"]), "completed candidate")
                counts["candidate_fits"] += 1
                if selection_audit_required:
                    selection_candidates.append(e)
            if kind == "candidate_selection":
                check(selection_audit_required and counts["classification_selections"] < attempts,
                      "unexpected or duplicate selection audit")
                selected_candidate = audit_classification_selection(
                    selection_candidates, e, cfg.classification_tie_break, len(val))
                counts["classification_selections"] += 1
            if kind == "candidate_frozen":
                if selection_audit_required:
                    check(selected_candidate is not None and all(e[k] == selected_candidate[k]
                          for k in ("window", "alpha", "train_samples")) and
                          e["selection_loss"] == selected_candidate["validation_loss"], "frozen selection winner")
                check(pending is None and e["frozen_at"] == step and e["incumbent_version"] == version and
                      e["selection_max_source_step"] == e.get("validation_max_step", latest) <= latest <= step - 2,
                      "frozen identity/source")
                pending = e; last = step; counts["frozen"] += 1
            if kind == "deploy":
                check(e.get("reason") == "independent_future_labels" and pending is not None and
                      e.get("accepted") is True, "deploy requires independent future gate")
            if kind in ("deploy", "experiment_rejected") and e.get("reason") == "independent_future_labels":
                check(pending is not None and e["candidate_id"] == pending["candidate_id"] and
                      e["frozen_at"] == pending["frozen_at"], "pending gate identity")
                gate = np.concatenate([v for k, v in requested.items() if pending["frozen_at"] < k <= step - 2])
                check(len(gate) >= 32 and e["gate_samples"] == len(gate) and
                      e["gate_min_source_step"] == int(min(gate // 96)) > e["frozen_at"] >= latest and
                      e["gate_max_source_step"] == int(max(gate // 96)), "independent future gate")
                pending = None; last = step; counts["future_gates"] += 1
            if kind == "deploy":
                check(e["model_version"] == version + 1, "deployment version")
                version = e["model_version"]; counts["deploys"] += 1
            if kind == "experiment_skipped" and e.get("reason") in ("budget_exhausted", "independent_labels_unavailable"):
                last = step
            if kind == "experiment_rejected" and e.get("reason") in (
                    "independent_validation_deadline", "independent_labels_unavailable", "stream_ended_before_independent_validation"):
                check(pending is not None and e["candidate_id"] == pending["candidate_id"], "rejection identity")
                pending = None; last = step
        row = curve[step]
        check(int(row["step"]) == step and int(row["model_version"]) == version and
              int(row["experiments"]) == experiments and int(row["training_attempts"]) == attempts and
              int(row["labels_requested"]) == used and int(row["tokens"]) == 0 and
              experiments <= cfg.max_experiments and float(row["adaptation_train_seconds"]) <= cfg.max_train_seconds + cfg.candidate_timeout_seconds,
              "curve resource/version audit")
    for e in by_step[96]:
        if e["event"] == "experiment_rejected":
            check(pending is not None and e["candidate_id"] == pending["candidate_id"] and
                  e["frozen_at"] == pending["frozen_at"] and e["reason"] == "stream_ended_before_independent_validation",
                  "stream-end pending rejection")
            pending = None
    check(pending is None, "pending candidate not finalized")
    if selection_audit_required:
        check(counts["classification_selections"] == attempts, "missing classification selection audit")
    check(summary["peak_label_history"] == peak and summary["labels_requested"] == used == released and
          summary["labels_released"] == released and summary["remaining_prediction_cache"] == 0 and
          summary["experiments"] == experiments and summary["training_attempts"] == attempts,
          "summary protocol counters")
    check(summary["training_ess_audit_count"] == len(esses), "summary ESS count")
    for key, value in zip(("training_ess_min", "training_ess_mean", "training_ess_max"),
                          (min(esses), np.mean(esses), max(esses)) if esses else (None,) * 3):
        check(summary[key] is None if value is None else np.isclose(summary[key], value, rtol=1e-12), "summary ESS values")
    deployed = RidgeModel.load(path / "deployed.npz")
    check(deployed.state() == models[version].state() and set(models) == set(range(version + 1)), "latest checkpoint")
    losses = sim.scorer.score(pred)
    check(np.allclose(losses, [float(r["loss"]) for r in curve], rtol=1e-12, atol=1e-12) and
          np.isclose(np.mean(losses), summary["mean_loss"], rtol=1e-12), "retrospective loss consistency")
    old_losses = sim.scorer.score([models[0].predict(b.features) for b in sim.batches])
    counts.update(policy_runs=1, final_checkpoint_matches=1)
    return {"config": cfg, "policy": policy, "events": events, "simulation": sim, "predictions": pred, "models": models,
            "losses": losses, "first_new_window": first_new_window(events, losses, old_losses),
            "splits": splits, "audit": {"path": str(path), "counts": dict(counts), "prediction_batches": 96,
            "checkpoint_max_abs_error": 0., "source": {k: origin[k] for k in ("source_commit", "source_sha256", "source_dirty")},
            "complexities": {str(k): len(m.weights) + 1 for k, m in models.items()}, "peak_history": peak}}


def analyze_pair(control, recent, candidate_arm="recent-disjoint"):
    arms = ("control", candidate_arm)
    result = {"own_windows": {name: run["first_new_window"] for name, run in zip(arms, (control, recent))},
              "curves": {name: run["losses"] for name, run in zip(arms, (control, recent))},
              "timing": {}, "same_samples": {}}
    for name, run in zip(arms, (control, recent)):
        result["timing"][name] = {kind: next((e["step"] for e in run["events"] if e["event"] == kind), None)
            for kind in ("drift_detected", "experiment_started", "candidate_frozen", "deploy")}
        result["timing"][name]["first_training_composition"] = run["splits"][0] if run["splits"] else None
    starts = [r["first_new_window"]["start"] for r in (control, recent)]
    windows = {"source25_35": (25, 36), "early": (13, 36), "late": (36, 96)}
    if all(s is not None for s in starts):
        windows["shared_first3"] = (max(starts), min(max(starts) + 3, 96))
    else:
        result["same_samples"]["shared_first3"] = {"status": "not_deployed", "losses": None}
    for label, (start, stop) in windows.items():
        block = {"start": start, "end": stop - 1, "status": "incomplete" if label == "shared_first3" and stop-start < 3 else "complete", "arms": {}}
        for name, run in zip(arms, (control, recent)):
            sim = run["simulation"]; model = run["models"].get(1)
            scale = max(float(np.var(sim.initial.validation_y)), 1e-8) if run["config"].task == "regression" else 1.
            # Scorer's hidden targets are inspected only in this isolated retrospective tool.
            targets = sim.scorer._targets[start:stop]
            entry = {"actual_residual": None,
                     "first_model_loss": None, "initial_loss": None, "old_new_score_correlation": None}
            if block["status"] == "complete":
                entry["actual_residual"] = residual_metrics(run["predictions"][start:stop], targets, scale)
            if model is not None and block["status"] == "complete":
                x = np.concatenate([b.features for b in sim.batches[start:stop]])
                initial, new = run["models"][0], model
                entry.update(first_model_residual=residual_metrics(model.predict(x), np.concatenate(targets), scale),
                             initial_residual=residual_metrics(initial.predict(x), np.concatenate(targets), scale))
                entry["first_model_loss"] = entry["first_model_residual"]["mean_squared"]
                entry["initial_loss"] = entry["initial_residual"]["mean_squared"]
                a, b = initial._scores(x), new._scores(x)
                if np.std(a) and np.std(b):
                    entry["old_new_score_correlation"] = float(np.corrcoef(a, b)[0, 1])
            block["arms"][name] = entry
        result["same_samples"][label] = block
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--legacy", required=True, type=Path)
    parser.add_argument("--historical-control", type=Path)
    parser.add_argument("--control-arm", default="control")
    parser.add_argument("--candidate-arm", default="recent-disjoint")
    parser.add_argument("--control-selection-split", default="chronological")
    parser.add_argument("--candidate-selection-split", default="recent_disjoint")
    parser.add_argument("--paired-factor", choices=("selection_split", "classification_tie_break"),
                        default="selection_split")
    args = parser.parse_args(argv)
    arms = (args.control_arm, args.candidate_arm)
    check(args.control_arm != args.candidate_arm, "control and candidate arm names must differ")
    outputs = [args.root / p for p in ("records/offline-audit.json", "assessment.json", "records/gradual-analysis.json", "paired-summary.csv")]
    check(not any(p.exists() for p in outputs), "refusing to overwrite audit outputs")
    expected = {(t, s, k, p) for t in TASKS for s in SCENARIOS for k in SEEDS for p in ("static", "drift")}
    paths = [p for arm in arms for p in (args.root / arm).rglob("*") if p.is_file()] + [args.legacy]
    if args.historical_control:
        paths.extend(args.historical_control / t / s / f"seed-{k}" / p / name
                     for t, s, k, p in expected for name in ("config.json", "summary.json", "predictions.npz"))
        paths.extend(p for p in (args.historical_control / "config.json", args.historical_control / "summary.csv") if p.is_file())
    paths = sorted(set(paths))
    fingerprints = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    legacy = _read_matrix(args.legacy)
    matrices = {arm: _read_matrix(args.root / arm / "summary.csv") for arm in arms}
    check(all(set(m) == expected for m in matrices.values()), "complete 72-run matrices")
    runs = {}; audits = []; counts = Counter(); gradual = {}; paired = []; source = None
    for key in sorted(expected):
        task, scenario, seed, policy = key
        relative = Path(task) / scenario / f"seed-{seed}" / policy
        for arm in arms:
            run = audit_run(args.root / arm / relative); runs[(arm, key)] = run
            check((run["config"].task, run["config"].scenario, run["config"].seed, run["policy"]) == key,
                  "run identity differs from directory/matrix key")
            wanted_split = args.control_selection_split if arm == args.control_arm else args.candidate_selection_split
            check(run["config"].selection_split == wanted_split, "arm split")
            check(np.isclose(matrices[arm][key], np.mean(run["losses"]), rtol=1e-12), "matrix loss")
            current = run["audit"]["source"]; source = source or current
            check(current == source, "single frozen source")
            audits.append(run["audit"]); counts.update(run["audit"]["counts"])
        a, b = (runs[(arm, key)] for arm in arms)
        ca, cb = a["config"].to_dict(), b["config"].to_dict()
        audit_paired_configs(ca, cb, args.paired_factor)
        if policy == "static":
            check(np.array_equal(a["predictions"], b["predictions"]), "static pair prediction equality")
            counts["static_pair_matches"] += 1
        if args.historical_control:
            with np.load(args.historical_control / relative / "predictions.npz", allow_pickle=False) as old:
                check(np.array_equal(a["predictions"], old["predictions"]), "historical control prediction equality")
            counts["historical_prediction_matches"] += 1
        if policy == "drift" and scenario == "gradual":
            gradual[f"{task}/seed-{seed}"] = analyze_pair(a, b, args.candidate_arm)
    for task in TASKS:
        for scenario in SCENARIOS:
            av = np.array([matrices["control"][(task, scenario, k, "drift")] for k in SEEDS])
            bv = np.array([matrices[args.candidate_arm][(task, scenario, k, "drift")] for k in SEEDS])
            paired.append({"task": task, "scenario": scenario, "seeds": list(SEEDS),
                "control_values": av.tolist(), "candidate_values": bv.tolist(), "paired_deltas": (bv-av).tolist(),
                "control_mean": float(av.mean()), "control_sd": float(av.std(ddof=1)) if len(av) > 1 else None,
                "candidate_arm": args.candidate_arm,
                "candidate_mean": float(bv.mean()), "candidate_sd": float(bv.std(ddof=1)) if len(bv) > 1 else None,
                "delta_mean": float((bv-av).mean()), "delta_sd": float((bv-av).std(ddof=1)) if len(av) > 1 else None})
    assessment = {arm: _evaluate(legacy, matrices[arm], SEEDS, ("static", "drift"), matrices[arm]) for arm in arms}
    assessment.update(candidate_arm=args.candidate_arm,
                      candidate_passed=assessment[args.candidate_arm]["passed"], paired=paired,
                      scope="development only; no independent acceptance or automatic promotion")
    check(all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == h for p, h in fingerprints.items()), "immutable experiment inputs")
    evidence = {"status": "passed", "source": source, "arms": list(arms),
        "paired_factor": args.paired_factor,
        "selection_splits": {args.control_arm: args.control_selection_split,
                             args.candidate_arm: args.candidate_selection_split},
        "frozen_config": FROZEN_CONFIG.to_dict(),
        "counts": dict(counts), "runs": audits,
        "input_sha256": fingerprints, "historical_control": str(args.historical_control) if args.historical_control else None,
        "gaps": ["Unretained rejected candidates cannot be rescored; source/weight audits cover their logged inputs.",
                 "Truth and target values are used only in retrospective analysis, never fitting or selection."]}
    for p in outputs:
        p.parent.mkdir(parents=True, exist_ok=True)
    serialized = [json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) for value in
        (evidence, assessment, {"seeds": list(SEEDS), "runs": gradual,
         "normalization": "regression residual divided by sqrt(initial validation variance); classification hard-label residual, not probability error"})]
    for p, value in zip(outputs[:3], serialized):
        with p.open("x", encoding="utf-8") as stream:
            stream.write(value)
    with outputs[3].open("x", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=paired[0]); writer.writeheader(); writer.writerows(paired)
    print(json.dumps({"status": "passed", "counts": dict(counts), "candidate_passed": assessment["candidate_passed"]}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
