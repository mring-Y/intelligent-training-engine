param(
    [string]$Image = "ite-local:verification",
    [string]$ExportArchive = "",
    [string]$ReceiptPath = "outputs/phase2/container-receipt.json"
)

$ErrorActionPreference = "Stop"
$Docker = "C:/Users/LENOVO/AppData/Local/Programs/DockerDesktop/resources/bin/docker.exe"
if (-not (Test-Path -LiteralPath $Docker)) {
    $dockerCommand = Get-Command docker -ErrorAction SilentlyContinue
    if (-not $dockerCommand) { throw "Docker CLI not found" }
    $Docker = $dockerCommand.Source
}
$DockerDirectory = Split-Path -Parent $Docker
if ($env:PATH -notlike "*$DockerDirectory*") { $env:PATH = "$DockerDirectory;$env:PATH" }

function Invoke-Docker([string[]]$Arguments) {
    & $Docker @Arguments
    if ($LASTEXITCODE -ne 0) { throw "Docker command failed ($LASTEXITCODE): $($Arguments -join ' ')" }
}

$baseTag = "python:3.12-slim@sha256:b18b261e1b4974b4f321451ad5251ded85abb22c2b8b262da527dda1d031ab30"
$git = Get-Command git -ErrorAction Stop
$gitSafe = @("-c", "safe.directory=$((Get-Location).Path)")
$status = (& $git.Source @gitSafe status --porcelain --untracked-files=all | Out-String).Trim()
if ($LASTEXITCODE -ne 0) { throw "Could not verify Git worktree state" }
if ($status) { throw "Container provenance requires a clean Git worktree; commit or remove local changes first" }

Invoke-Docker @("pull", $baseTag)
$baseRepoDigest = (& $Docker image inspect --format '{{index .RepoDigests 0}}' $baseTag).Trim()
if ($LASTEXITCODE -ne 0 -or $baseRepoDigest -notmatch '@sha256:([0-9a-f]{64})$') {
    throw "Could not resolve python:3.12-slim to a registry digest"
}
$baseDigestRef = "python:3.12-slim@sha256:$($Matches[1])"

$commit = (& $git.Source @gitSafe rev-parse HEAD).Trim()
if ($LASTEXITCODE -ne 0) { throw "Could not read source commit" }
$dirtyOutput = (& $git.Source @gitSafe status --porcelain | Out-String).Trim()
$dirty = [bool]$dirtyOutput
$sourceHash = [System.Security.Cryptography.IncrementalHash]::CreateHash(
    [System.Security.Cryptography.HashAlgorithmName]::SHA256)
try {
    Get-ChildItem ite -Filter "*.py" -File | Sort-Object Name | ForEach-Object {
        $nameBytes = [System.Text.Encoding]::UTF8.GetBytes($_.Name)
        $fileBytes = [System.IO.File]::ReadAllBytes($_.FullName)
        $sourceHash.AppendData($nameBytes)
        $sourceHash.AppendData($fileBytes)
    }
    $sourceSha256 = [Convert]::ToHexString($sourceHash.GetHashAndReset()).ToLowerInvariant()
} finally { $sourceHash.Dispose() }

Invoke-Docker @("build", "--network", "default", "--target", "test", "-t", "$Image-test",
    "--build-arg", "PYTHON_BASE=$baseDigestRef", "--build-arg", "ITE_SOURCE_COMMIT=$commit",
    "--build-arg", "ITE_SOURCE_DIRTY=$($dirty.ToString().ToLowerInvariant())",
    "--build-arg", "ITE_SOURCE_SHA256=$sourceSha256", ".")
Invoke-Docker @("run", "--rm", "--network", "none", "--cpus", "4", "--memory", "4g", "$Image-test")
Invoke-Docker @("build", "--network", "default", "--target", "runtime", "-t", $Image,
    "--build-arg", "PYTHON_BASE=$baseDigestRef", "--build-arg", "ITE_SOURCE_COMMIT=$commit",
    "--build-arg", "ITE_SOURCE_DIRTY=$($dirty.ToString().ToLowerInvariant())",
    "--build-arg", "ITE_SOURCE_SHA256=$sourceSha256", ".")

$runId = [Guid]::NewGuid().ToString("N")
$hostOutput = Join-Path (Get-Location) "outputs/container-$runId"
New-Item -ItemType Directory -Path $hostOutput | Out-Null
$resolvedOutput = (Resolve-Path -LiteralPath $hostOutput).Path
$containerOutput = "/app/outputs/local"
$runtimeCommand = @("ite", "run", "--config", "/app/configs/default.json", "--output", $containerOutput)
$runtimeStarted = Get-Date
$runtimeArgs = @("run", "--name", "ite-run-$runId", "--network", "none", "--cpus", "4",
    "--memory", "4g", "--mount", "type=bind,source=$resolvedOutput,target=$containerOutput", $Image) + $runtimeCommand
Invoke-Docker $runtimeArgs
$containerInfo = (& $Docker inspect "ite-run-$runId" | ConvertFrom-Json)[0]
if ($LASTEXITCODE -ne 0 -or $containerInfo.State.ExitCode -ne 0) { throw "Runtime container failed" }
$containerLogs = (& $Docker logs "ite-run-$runId" 2>&1 | Out-String)
# Run the artifact verifier on the host so its result is recorded separately from the model CLI.
$python = "C:/Users/LENOVO/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe"
if (-not (Test-Path -LiteralPath $python)) { $python = "python" }
$verification = & $python scripts/container_check.py $resolvedOutput | ConvertFrom-Json
if ($LASTEXITCODE -ne 0) { throw "Artifact verification failed" }

$inspect = (& $Docker image inspect $Image | ConvertFrom-Json)[0]
$versionOutput = (& $Docker run --rm --network none --entrypoint python $Image -c `
    "import numpy,sys; print(sys.version.split()[0]); print(numpy.__version__)") -join "`n"
$stats = (& $Docker stats "ite-run-$runId" --no-stream --format '{{.MemUsage}}' 2>$null | Out-String).Trim()
$receipt = [ordered]@{
    image = $Image
    image_id = $inspect.Id
    image_created = $inspect.Created
    image_labels = $inspect.Config.Labels
    base_image_digest = $baseDigestRef
    source_commit = $commit
    source_dirty = $dirty
    source_sha256 = $sourceSha256
    python_numpy = $versionOutput
    test_target = "passed"
    runtime_exit_code = $containerInfo.State.ExitCode
    runtime_status = $containerInfo.State.Status
    runtime_logs = $containerLogs
    runtime_seconds = ((Get-Date) - $runtimeStarted).TotalSeconds
    configured_cpus = 4
    configured_memory_bytes = 4294967296
    cgroup_memory_limit_bytes = $containerInfo.HostConfig.Memory
    cgroup_cpu_quota = $containerInfo.HostConfig.CpuQuota
    sampled_memory = $stats
    verification = $verification
    runtime_output = $resolvedOutput
}

if ($ExportArchive) {
    Invoke-Docker @("save", "-o", $ExportArchive, $Image)
    $archiveHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $ExportArchive).Hash.ToLowerInvariant()
    Invoke-Docker @("load", "-i", $ExportArchive)
    $reloaded = (& $Docker image inspect --format '{{.Id}}' $Image).Trim()
    if ($reloaded -ne $inspect.Id) { throw "Loaded archive image ID differs from exported image" }
    $predictionCheck = (& $Docker run --rm --network none --mount `
        "type=bind,source=$resolvedOutput/drift,target=/models,readonly" --entrypoint python $Image -c `
        "import numpy as np; from pathlib import Path; from ite.models import RidgeModel; d=RidgeModel.load('/models/deployed.npz'); p=sorted(Path('/models').glob('model-v*.npz'), key=lambda x:int(x.stem[7:])); c=RidgeModel.load(p[-1] if p else '/models/initial.npz'); x=np.random.default_rng(4421).normal(size=(24,d.mean.size)); print(bool(np.array_equal(d.predict(x),c.predict(x))))")
    if ($LASTEXITCODE -ne 0 -or $predictionCheck.Trim() -ne "True") {
        throw "Post-load deployed/checkpoint prediction equality failed"
    }
    $receipt["archive_path"] = (Resolve-Path -LiteralPath $ExportArchive).Path
    $receipt["archive_sha256"] = $archiveHash
    $receipt["archive_image_id"] = $reloaded
    $receipt["post_load_prediction_match"] = $true
}

$receiptDirectory = Split-Path -Parent $ReceiptPath
if ($receiptDirectory) { New-Item -ItemType Directory -Force -Path $receiptDirectory | Out-Null }
$receipt | ConvertTo-Json -Depth 8 | Set-Content -Encoding utf8 -LiteralPath $ReceiptPath
Invoke-Docker @("rm", "ite-run-$runId")
Write-Output (Get-Content -Raw -LiteralPath $ReceiptPath)
