"""Compare fixed-step B head training with a 48-row balanced historical reserve."""

import argparse
import hashlib
import json
import os
from pathlib import Path

import numpy as np

from ite.official_model import OfficialModelAdapter
from ite.official_sft_data import DRIFT, NOTICE, SCENARIOS, load_public_package, split_sources
from ite.official_sft_replay import replay_partition
from ite.tracking import source_metadata, write_json
from scripts.run_official_b_head_comparison import _residual_metrics, audit_candidate


ROOT = Path(__file__).resolve().parents[1]
ARMS = ("static", "head_only", "head_replay")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def case_plan():
    return [{"profile": "B", "scenario": scenario, "split": split, "arm": arm,
             "decision_steps": (7,),
             "replay_policy": "source_balanced_official_train" if arm == "head_replay" else "none"}
            for scenario in SCENARIOS for split in ("train", "eval") for arm in ARMS]


def summarize_b_replay_paired(predictions, scenario, *, source_groups=None):
    if set(predictions) != set(ARMS) or scenario not in SCENARIOS:
        raise ValueError("Static and both fixed B head arms are required")
    reference = predictions["static"]
    ids = np.asarray(reference["source_ids"])
    if ids.ndim != 1 or not len(ids) or len(set(ids.tolist())) != len(ids):
        raise ValueError("B paired source IDs must be unique and nonempty")
    for arm in ARMS:
        for key in ("source_ids", "targets", "static"):
            if not np.array_equal(predictions[arm][key], reference[key]):
                raise ValueError(f"Unpaired B {arm} {key}")
    if not np.array_equal(reference["active"], reference["static"]):
        raise ValueError("B static arm changed its checkpoint")
    scores = {arm: _residual_metrics(row["targets"], row["active"])
              for arm, row in predictions.items()}
    baseline = scores["static"]
    passes = {arm: ((scores[arm]["rmse"] <= baseline["rmse"] if scenario == "stable" else
                     scores[arm]["rmse"] < baseline["rmse"]) and
                    scores[arm]["mae"] <= baseline["mae"]) for arm in ARMS if arm != "static"}
    bearing_metrics = {}
    if source_groups is not None:
        groups = np.asarray(source_groups)
        if groups.shape != ids.shape or groups.dtype.kind not in ("U", "S"):
            raise ValueError("B bearing groups must match paired rows")
        for group in sorted(set(groups.tolist())):
            mask = groups == group
            bearing_metrics[group] = {arm: _residual_metrics(
                row["targets"][mask], row["active"][mask]) for arm, row in predictions.items()}
    return {"metrics": scores, "bearing_metrics": bearing_metrics, "passes": passes}


def engineering_issues(case, summary, events, reserve_ids):
    arm, split = case["arm"], case["split"]
    issues = []
    predictions = [e for e in events if e["event"] == "prediction"]
    candidates = [e for e in events if e["event"] == "candidate_evaluated"]
    if len(predictions) != 12 or summary["train_seconds"] > 20. or summary["training_attempts"] > 4:
        issues.append("flow_budget_or_predictions")
    if any(e["event"] == "training_failed" for e in events):
        issues.append("training_failed")
    if arm == "static":
        if candidates or summary["training_attempts"] or summary["updates"]:
            issues.append("static_updated")
        return issues
    if len(candidates) != 1 or summary["training_attempts"] != 1:
        return issues + ["candidate_count"]
    c = candidates[0]
    train, screen = c["train_source_ids"], c["screening_source_ids"]
    online, replay = c["online_train_source_ids"], c["replay_source_ids"]
    expected_rows, expected_screen = (720, 48) if split == "train" else (54, 18)
    fit = c.get("fit_audit", {})
    if (c["step"] != 7 or len(train) != expected_rows or c["train_samples"] != expected_rows or
            len(screen) != expected_screen or c["screening_samples"] != expected_screen or
            len(online) != expected_rows or len(set(train)) != len(train) or set(train) & set(screen) or
            not 0 < c["train_seconds"] <= 5. or c["candidate_adam_steps"] <= c["parent_adam_steps"] or
            fit.get("trainable_policy") != "head_only" or fit.get("trainable_parameters") != 25 or
            fit.get("epochs_added") != 5 or c.get("b_replay_policy") != case["replay_policy"]):
        issues.append("candidate_contract")
    if arm == "head_replay":
        if (replay != reserve_ids or c["replaced_online_source_ids"] != online[:48] or
                train != replay + online[48:] or set(replay) & (set(online) | set(screen))):
            issues.append("replay_replacement")
    elif replay or c["replaced_online_source_ids"] or train != online:
        issues.append("ordinary_head_changed_sources")
    deployments = []
    frozen_ids = {e.get("decision_id") for e in events if e["event"] == "candidate_frozen"}
    future_ids = set()
    for e in events:
        if e["event"] in ("deploy", "experiment_rejected") and e.get("reason") == "independent_future_labels":
            future_ids.add(e.get("decision_id"))
            if (e.get("decision_id") != c["decision_id"] or e.get("frozen_at") != 7 or
                    e.get("gate_min_source_step") != 8 or e["step"] != 9 or
                    not e.get("source_ids") or set(e["source_ids"]) & (set(train) | set(screen)) or
                    e.get("candidate_replay_source_ids") != replay):
                issues.append("future_isolation")
            if e["event"] == "deploy":
                deployments.append(e)
    if frozen_ids != future_ids:
        issues.append("missing_future_verdict")
    for p in predictions:
        if p["model_version"] != sum(d["step"] < p["step"] for d in deployments):
            issues.append("effective_prediction_version")
    return issues


def run_comparison(output, runtime_python=None):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    runs = output / "runs"
    runs.mkdir()
    runtime_python = runtime_python or os.environ.get(
        "ITE_OFFICIAL_RUNTIME_PYTHON", ROOT / ".venv-official-a/Scripts/python.exe")
    data = load_public_package("B")
    partitions = split_sources(data)
    initial = OfficialModelAdapter("regression", runtime_python, profile_type="B", candidate_epochs=5)
    state = initial.state()
    initial.save(output / "initial.npz")
    reserve = data["replay_reserve"]
    np.savez_compressed(output / "replay-reserve.npz", x=reserve["x"], y=reserve["y"],
                        source_ids=np.asarray(reserve["ids"]), groups=np.asarray(reserve["groups"]))
    write_json(output / "freeze.json", {"notice": NOTICE, "development_only": True,
        "source": source_metadata(), "runner_sha256": digest(__file__),
        "package_sha256": data["package_sha256"], "initial_checkpoint_sha256": initial.checkpoint_sha256,
        "reported_static_validation": data["reported_baseline"], "drift": DRIFT,
        "partition_rule": partitions["rule"],
        "partitions": {split: {"rows": len(partitions[split]),
            "source_ids": [data["ids"][i] for i in partitions[split]]} for split in ("train", "eval")},
        "cases": case_plan(), "only_changed_factor": "48-row historical source-balanced replacement",
        "replay_reserve": {key: value for key, value in reserve.items() if key not in ("x", "y")},
        "replay_reserve_sha256": digest(output / "replay-reserve.npz"),
        "candidate_epochs": 5, "trainable_parameters": 25, "decision_step": 7,
        "candidate_timeout_seconds": 5, "total_train_seconds_per_flow": 20,
        "maximum_attempts_per_flow": 4, "maximum_window_including_screening": 768,
        "expected_train_rows": {"train": 720, "eval": 54},
        "expected_screening_rows": {"train": 48, "eval": 18},
        "acceptance": "stable RMSE/MAE nonworse; each drift partition RMSE strictly lower and MAE nonworse",
        "data_role": "previously_seen_public_development; released validation rows participate in gradients",
        "paid_calls": 0, "llm_tokens": 0})
    summaries, arrays, costs, errors = {}, {}, {}, []
    for case in case_plan():
        scenario, split, arm = (case[key] for key in ("scenario", "split", "arm"))
        name = f"B-{scenario}-{split}-{arm}"
        path = runs / name
        action = "DO_NOTHING" if arm == "static" else "RETRAIN_HEAD_ONLY"
        result = replay_partition(data, partitions[split], split, scenario, path,
            OfficialModelAdapter.from_state(state),
            lambda _, action=action: {"action": action, "reason": "固定时点来源均衡对照。", "source": "fixed_comparison"},
            decision_steps=case["decision_steps"], action_profile="official_finetune",
            b_replay_policy=case["replay_policy"])
        events = [json.loads(line) for line in (path / "events.jsonl").read_text(encoding="utf-8").splitlines()]
        issues = engineering_issues(case, result, events, reserve["ids"])
        audits = {e["decision_id"]: audit_candidate(output / "initial.npz",
            path / f"candidate-step{e['step']}.npz", "head_only")
            for e in events if e["event"] == "candidate_evaluated"}
        with np.load(path / "predictions.npz", allow_pickle=False) as archive:
            arrays[scenario, split, arm] = {key: archive[key].copy() for key in archive.files}
        costs[name] = {"training_attempts": result["training_attempts"], "train_seconds": result["train_seconds"],
            "released_label_rows": sum(e["samples"] for e in events if e["event"] == "labels_released"),
            "paid_calls": 0, "llm_tokens": 0}
        summaries[name] = {"case": case, "summary": result, "costs": costs[name],
            "engineering_issues": issues, "candidate_audits": audits,
            "evidence_sha256": {file: digest(path / file)
                for file in ("events.jsonl", "predictions.npz", "summary.json")}}
        errors.extend(f"{name}:{issue}" for issue in issues)
        print(f"{name}: RMSE={result['active_metrics']['rmse']:.9f}; "
              f"MAE={result['active_metrics']['mae']:.9f}; deploys={result['updates']}; "
              f"training={result['train_seconds']:.6f}s", flush=True)
    groups = {}
    group_lookup = dict(zip(data["ids"], data["groups"]))
    for scenario in SCENARIOS:
        for split in ("train", "eval"):
            rows = {arm: arrays[scenario, split, arm] for arm in ARMS}
            groups[f"{scenario}-{split}"] = summarize_b_replay_paired(rows, scenario,
                source_groups=np.asarray([group_lookup[i] for i in rows["static"]["source_ids"]]))
    result = {"notice": NOTICE, "development_only": True, "physical_flows": len(summaries),
        "engineering_passed": not errors, "engineering_errors": errors,
        "flows": summaries, "costs": costs, "groups": groups,
        "all_partition_criteria_pass": {arm: all(g["passes"][arm] for g in groups.values())
            for arm in ARMS if arm != "static"}, "freeze_sha256": digest(output / "freeze.json"),
        "paid_calls": 0, "llm_tokens": 0}
    write_json(output / "comparison.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--official-python", default=os.environ.get("ITE_OFFICIAL_RUNTIME_PYTHON",
        str(ROOT / ".venv-official-a/Scripts/python.exe")))
    args = parser.parse_args()
    result = run_comparison(args.output, args.official_python)
    print(json.dumps({key: result[key] for key in ("engineering_passed", "all_partition_criteria_pass")}))
    return 0 if result["engineering_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
