"""Run the supplied CPU A checkpoint on a time-ordered public-validation replay."""

import argparse
import csv
from dataclasses import replace
import hashlib
import json
import os
from pathlib import Path
import zipfile

import numpy as np

from ite.config import ExperimentConfig
from ite.data import InitialData
from ite.model_factory import make_model
from ite.providers import CSVDataProvider, ColumnMapping
from ite.runner import run_policy
from ite.tracking import source_metadata
from ite.training import BoundedTrainer


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_PACKAGE = ROOT / "third_party" / "official_baselines" / "cpu-a-guide-20261110-v1.zip"
DEFAULT_CONFIG = ROOT / "configs" / "gas-official-mock.json"
DEFAULT_OUTPUT = ROOT / "outputs" / "official-a-mock-20261111"
CLASSES = ("Ethanol", "Ethylene", "Ammonia", "Acetaldehyde", "Acetone", "Toluene")
DISCLAIMER = "当前测试流为公开验证集的时序模拟，不代表官方隐藏测试集的真实表现。"
CALIBRATION_FRACTION = 0.10
FUTURE_FRACTION = 0.25
DRIFT_BATCH = 3
DRIFT_STANDARD_DEVIATIONS = 1.5


def _read_rows(package, member):
    with zipfile.ZipFile(package) as archive:
        return [json.loads(line) for line in archive.read(member).decode("utf-8").splitlines() if line.strip()]


def _flatten(value):
    output = []

    def visit(item):
        if isinstance(item, dict):
            for key in sorted(item):
                visit(item[key])
        elif isinstance(item, list):
            for child in item:
                visit(child)
        elif isinstance(item, (int, float)) and not isinstance(item, bool) and np.isfinite(item):
            output.append(float(item))
        else:
            raise ValueError("Official A inputs must contain finite numeric features only")

    visit(value)
    return output


def split_validation_rows(rows):
    if len(rows) < 40:
        raise ValueError("The public validation replay needs at least 40 ordered rows")
    ids, batches, indices = [], [], []
    for row in rows:
        meta = row.get("meta", {})
        identity, batch, index = row.get("id"), meta.get("source_batch"), meta.get("source_index")
        if not isinstance(identity, str) or not identity or type(batch) is not int or type(index) is not int:
            raise ValueError("Official validation rows require ID and source time metadata")
        ids.append(identity)
        batches.append(batch)
        indices.append(index)
    if len(ids) != len(set(ids)) or len(set(batches)) != 1 or any(b <= a for a, b in zip(indices, indices[1:])):
        raise ValueError("Validation rows must be unique and strictly time ordered within one source batch")
    calibration_count = max(4, int(len(rows) * CALIBRATION_FRACTION))
    future_count = max(4, int(len(rows) * FUTURE_FRACTION))
    online_end = len(rows) - future_count
    if online_end - calibration_count < 4:
        raise ValueError("Validation split leaves too few online rows")
    return {"calibration": rows[:calibration_count], "stream": rows[calibration_count:online_end],
            "future": rows[online_end:], "source_batch": batches[0],
            "source_index_range": [indices[0], indices[-1]]}


def _arrays(rows):
    x = np.asarray([_flatten(row["inputs"]) for row in rows], dtype=np.float64)
    y = np.asarray([CLASSES.index(row["answer"]) + 1 for row in rows], dtype=np.int64)
    if x.ndim != 2 or x.shape[1] != 128 or len(x) != len(y):
        raise ValueError("Official A rows must contain 128 features and a valid gas label")
    return x, y


def simulate_covariate_drift(features, scale, active, standard_deviations=DRIFT_STANDARD_DEVIATIONS):
    x = np.asarray(features, dtype=np.float64)
    scale = np.asarray(scale, dtype=np.float64)
    if (x.ndim != 2 or x.shape[1] != 128 or scale.shape != (128,) or
            not np.isfinite(x).all() or not np.isfinite(scale).all() or np.any(scale <= 0)):
        raise ValueError("Covariate drift requires finite A features and checkpoint scales")
    if type(active) is not bool or not isinstance(standard_deviations, (int, float)) or standard_deviations < 0:
        raise ValueError("Invalid simulated drift settings")
    return x + standard_deviations * scale if active else x.copy()


def classification_metrics(targets, predictions):
    y, predicted = np.asarray(targets), np.asarray(predictions)
    if y.shape != predicted.shape or y.ndim != 1 or not len(y):
        raise ValueError("Classification metrics need matching nonempty vectors")
    if not np.isin(y, np.arange(1, 7)).all() or not np.isin(predicted, np.arange(1, 7)).all():
        raise ValueError("Unknown official A class ID")
    classes = np.arange(1, 7)
    confusion = np.asarray([[np.sum((y == actual) & (predicted == guess)) for guess in classes]
                            for actual in classes], dtype=np.int64)
    f1 = []
    for index in range(6):
        true_positive = confusion[index, index]
        denominator = confusion[index].sum() + confusion[:, index].sum()
        f1.append(2.0 * true_positive / denominator if denominator else 0.0)
    return {"samples": len(y), "accuracy": float(np.mean(y == predicted)),
            "macro_f1": float(np.mean(f1)), "classes": classes.tolist(),
            "confusion_matrix": confusion.tolist()}


class OfficialGasScorer:
    """Offline scorer kept outside the provider/controller label path."""

    def __init__(self, labels, batch_sizes):
        self.labels = np.asarray(labels, dtype=np.int64)
        self.batch_sizes = tuple(batch_sizes)
        if sum(self.batch_sizes) != len(self.labels):
            raise ValueError("Scorer batch sizes do not cover the stream labels")
        offsets = np.cumsum([0, *self.batch_sizes])
        self._targets = [self.labels[start:end] for start, end in zip(offsets[:-1], offsets[1:])]

    def score(self, predictions):
        if len(predictions) != len(self._targets):
            raise ValueError("Expected one prediction vector per replay batch")
        return [float(np.mean(y != p)) for y, p in zip(self._targets, predictions)]

    def classification_counts(self, predictions):
        joined = np.concatenate(predictions)
        return {"sample_weighted_accuracy": classification_metrics(self.labels, joined)["accuracy"],
                "macro_f1": classification_metrics(self.labels, joined)["macro_f1"],
                "classes": list(range(1, 7)),
                "confusion_matrix": classification_metrics(self.labels, joined)["confusion_matrix"]}


def _write_stream(path, rows, batch_count, scale, *, apply_drift):
    x, y = _arrays(rows)
    partitions = np.array_split(np.arange(len(rows)), batch_count)
    batch_sizes = [len(partition) for partition in partitions]
    path.parent.mkdir(parents=True, exist_ok=True)
    feature_names = [f"x{index}" for index in range(x.shape[1])]
    with path.open("x", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["sample_id", "batch", *feature_names, "target"])
        for batch, partition in enumerate(partitions):
            shifted = simulate_covariate_drift(x[partition], scale,
                                               apply_drift and batch >= DRIFT_BATCH)
            for row_index, features, target in zip(partition, shifted, y[partition]):
                writer.writerow([int(row_index), batch, *features.tolist(), int(target)])
    return batch_sizes


def _make_provider(stream_path, mapping, initial, label_delay):
    return CSVDataProvider(stream_path, mapping, initial=initial, label_delay=label_delay, max_labels=None)


def _prediction_metrics(run_dir, targets):
    with np.load(Path(run_dir) / "predictions.npz", allow_pickle=False) as archive:
        predictions = archive["predictions"]
    return classification_metrics(targets, predictions)


def _save_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def run_official_gas(package_path=DEFAULT_PACKAGE, output_dir=DEFAULT_OUTPUT, runtime_python=None,
                     config_path=DEFAULT_CONFIG):
    package, output = Path(package_path).resolve(), Path(output_dir).resolve()
    runtime_value = runtime_python or os.environ.get("ITE_OFFICIAL_RUNTIME_PYTHON")
    runtime = Path(runtime_value) if runtime_value else ROOT / ".venv-official-a" / (
        "Scripts/python.exe" if os.name == "nt" else "bin/python")
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite official A replay: {output}")
    if not package.is_file():
        raise FileNotFoundError(package)
    config = replace(ExperimentConfig.load(config_path), official_package_path=str(package),
                     official_runtime_python=str(runtime.resolve()))
    train_rows = _read_rows(package, "public/train.jsonl")
    validation_rows = _read_rows(package, "public/validation.jsonl")
    split = split_validation_rows(validation_rows)
    train_x, train_y = _arrays(train_rows)
    calibration_x, calibration_y = _arrays(split["calibration"])
    stream_x, stream_y = _arrays(split["stream"])
    future_x, future_y = _arrays(split["future"])
    if len(train_rows) != 445 or len(validation_rows) != 1244:
        raise ValueError("This replay is pinned to the supplied official A public data package")
    if (config.n_batches != 7 or config.batch_size < int(np.ceil(len(stream_y) / config.n_batches)) or
            config.n_features != 128 or config.initial_train != len(train_y) or
            config.initial_validation != len(calibration_y)):
        raise ValueError("Official A replay configuration does not match its fixed temporal partitions")
    config = replace(config, initial_validation=len(calibration_y))
    model_options = config.official_options()
    baseline = make_model("classification", None, "ridge", model_type="official",
                          class_labels=config.class_labels, official_options=model_options)
    all_x, all_y = _arrays(validation_rows)
    full_validation_metrics = classification_metrics(all_y, baseline.predict(all_x))
    calibration = InitialData(train_x, train_y, calibration_x, calibration_y)
    output.mkdir(parents=True, exist_ok=False)
    data_dir = output / "data"
    data_dir.mkdir()
    stream_path = data_dir / "validation-time-simulation.csv"
    batch_sizes = _write_stream(stream_path, split["stream"], config.n_batches, baseline.std,
                                apply_drift=True)
    future_shifted = simulate_covariate_drift(future_x, baseline.std, True)
    mapping = ColumnMapping(features=tuple(f"x{index}" for index in range(128)), target="target",
                             sample_id="sample_id", batch="batch")
    scorer = OfficialGasScorer(stream_y + 0, batch_sizes)
    split_summary = {"notice": DISCLAIMER, "source_batch": split["source_batch"],
        "source_index_range": split["source_index_range"],
        "calibration_rows": len(split["calibration"]), "online_stream_rows": len(split["stream"]),
        "future_holdout_rows": len(split["future"]), "batch_sizes": batch_sizes,
        "simulated_covariate_shift": {"kind": "additive_standard_deviation_shift", "magnitude": DRIFT_STANDARD_DEVIATIONS,
            "first_drift_batch": DRIFT_BATCH, "labels_unchanged": True}}
    _save_json(data_dir / "split-and-drift.json", split_summary)
    with (data_dir / "source-id-map.jsonl").open("x", encoding="utf-8", newline="\n") as stream:
        for index, row in enumerate(split["stream"]):
            stream.write(json.dumps({"sample_id": index, "source_id": row["id"],
                "source_batch": row["meta"]["source_batch"],
                "source_index": row["meta"]["source_index"]}, ensure_ascii=False) + "\n")
    _save_json(output / "provenance.json", {**source_metadata(), "package_path": str(package),
        "package_sha256": hashlib.sha256(package.read_bytes()).hexdigest(),
        "config": config.to_dict(), "validation_simulation": split_summary,
        "official_baseline_checkpoint_sha256": baseline.checkpoint_sha256,
        "evaluation_notice": DISCLAIMER})
    static_provider = _make_provider(stream_path, mapping, calibration, config.label_delay)
    with BoundedTrainer() as trainer:
        static_result = run_policy(config, "static", output / "static", trainer,
                                   provider=static_provider,
                                   offline_scorer=OfficialGasScorer(stream_y, batch_sizes))
    drift_provider = _make_provider(stream_path, mapping, calibration, config.label_delay)
    with BoundedTrainer() as trainer:
        drift_result = run_policy(config, "drift", output / "drift", trainer,
                                  provider=drift_provider,
                                  offline_scorer=OfficialGasScorer(stream_y, batch_sizes))
    static_stream_metrics = _prediction_metrics(output / "static", stream_y)
    drift_stream_metrics = _prediction_metrics(output / "drift", stream_y)
    final_options = {**model_options, "checkpoint_path": str(output / "drift" / "deployed.npz")}
    final_model = make_model("classification", None, "ridge", model_type="official",
                             class_labels=config.class_labels, official_options=final_options)
    static_future_metrics = classification_metrics(future_y, baseline.predict(future_shifted))
    adapted_future_metrics = classification_metrics(future_y, final_model.predict(future_shifted))
    result = {"notice": DISCLAIMER, "validation_split": split_summary,
        "official_package_baseline_full_validation": full_validation_metrics,
        "static_online_stream": static_stream_metrics, "harness_online_stream": drift_stream_metrics,
        "static_future_holdout": static_future_metrics, "harness_future_holdout": adapted_future_metrics,
        "static_run": static_result, "harness_run": drift_result,
        "parent_checkpoint_sha256": baseline.checkpoint_sha256,
        "final_checkpoint_sha256": final_model.checkpoint_sha256}
    _save_json(output / "comparison.json", result)
    _save_json(output / "summary.json", {"evaluation_notice": DISCLAIMER,
        "baseline_accuracy": full_validation_metrics["accuracy"],
        "baseline_macro_f1": full_validation_metrics["macro_f1"],
        "harness_online_accuracy": drift_stream_metrics["accuracy"],
        "harness_online_macro_f1": drift_stream_metrics["macro_f1"],
        "static_future_accuracy": static_future_metrics["accuracy"],
        "static_future_macro_f1": static_future_metrics["macro_f1"],
        "harness_future_accuracy": adapted_future_metrics["accuracy"],
        "harness_future_macro_f1": adapted_future_metrics["macro_f1"],
        "updates": drift_result["updates"], "detections": drift_result["detections"],
        "training_attempts": drift_result["training_attempts"], "prediction_versions": sorted(
            {event["model_version"] for event in
             (json.loads(line) for line in (output / "drift" / "events.jsonl").read_text(encoding="utf-8").splitlines())
             if event.get("event") == "prediction"})})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", type=Path, default=DEFAULT_PACKAGE)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--runtime-python", type=Path)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    args = parser.parse_args()
    result = run_official_gas(args.package, args.output, args.runtime_python, args.config)
    print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
