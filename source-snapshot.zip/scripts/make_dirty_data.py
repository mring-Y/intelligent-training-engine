"""Create deterministic Parquet inputs for provider fault-injection tests."""

import argparse
import json
from pathlib import Path

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq


FEATURES = ("sensor_1", "sensor_2", "sensor_3")
FLOAT32_MAX = float(np.finfo(np.float32).max)


def _write_table(path, columns):
    table = pa.Table.from_pydict(columns)
    pq.write_table(table, path, compression="zstd", row_group_size=7, use_dictionary=False)


def make_dirty_data(output):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    rng = np.random.default_rng(20261108)

    train_x = rng.normal(size=(64, len(FEATURES)))
    train_y = (train_x[:, 0] + train_x[:, 1] > 0).astype(np.int64)
    validation_x = rng.normal(size=(32, len(FEATURES)))
    validation_y = (validation_x[:, 0] + validation_x[:, 1] > 0).astype(np.int64)
    _write_table(output / "initial_train.parquet", {
        **{name: train_x[:, index] for index, name in enumerate(FEATURES)},
        "label": train_y, "sample_id": np.arange(1, 65, dtype=np.int64),
    })
    _write_table(output / "initial_validation.parquet", {
        **{name: validation_x[:, index] for index, name in enumerate(FEATURES)},
        "label": validation_y, "sample_id": np.arange(1001, 1033, dtype=np.int64),
    })

    count = 24
    stream_x = rng.normal(size=(count, len(FEATURES)))
    stream_y = (stream_x[:, 0] + stream_x[:, 1] > 0).astype(object)
    stream_ids = np.arange(10000, 10000 + count, dtype=np.int64)
    batch_ids = np.repeat(np.arange(4, dtype=np.int64), 6)
    timestamps = 1_800_000_000 + rng.permutation(np.arange(count, dtype=np.int64)) * 300
    timestamps[5] += 17_400

    stream_x[0, 0] = np.nan
    stream_x[1, 1] = np.inf
    stream_x[2, 2] = FLOAT32_MAX * 4.0
    stream_y[3] = None

    columns = {
        **{name: stream_x[:, index] for index, name in enumerate(FEATURES)},
        "label": stream_y.tolist(),
        "sample_id": stream_ids,
        "batch_id": batch_ids,
        "timestamp": timestamps,
    }
    dirty_stream = "dirty_stream.parquet"
    _write_table(output / dirty_stream, columns)

    missing_feature_columns = dict(columns)
    missing_feature_columns.pop("sensor_3")
    missing_feature_stream = "missing_feature_stream.parquet"
    _write_table(output / missing_feature_stream, missing_feature_columns)

    manifest = {
        "seed": 20261108,
        "mapping": {
            "features": list(FEATURES), "target": "label",
            "sample_id": "sample_id", "batch": "batch_id",
        },
        "files": {
            "initial_train": "initial_train.parquet",
            "initial_validation": "initial_validation.parquet",
            "stream": dirty_stream,
            "missing_feature_stream": missing_feature_stream,
        },
        "metadata_columns": ["timestamp"],
        "cases": {
            "missing_feature_value": int(stream_ids[0]),
            "infinite_feature_value": int(stream_ids[1]),
            "float32_overflow_value": int(stream_ids[2]),
            "missing_target": int(stream_ids[3]),
            "missing_stream_feature_column": "sensor_3",
            "timestamp_is_monotonic": bool(np.all(np.diff(timestamps) >= 0)),
        },
    }
    (output / "manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path,
                        help="new output directory; an existing path is never overwritten")
    args = parser.parse_args()
    manifest = make_dirty_data(args.output)
    print(json.dumps({"output": str(args.output.resolve()), "rows": 24,
                      "timestamp_is_monotonic": manifest["cases"]["timestamp_is_monotonic"]}))


if __name__ == "__main__":
    main()
