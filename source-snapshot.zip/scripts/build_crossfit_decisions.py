"""Bounded local cross-fit action labels; no remote trainer or Teacher export.

Only three tested actions and a 12-batch horizon are compared. A DO_NOTHING
label asserts no tested intervention satisfied the paired outcome and guards;
it does not assert global optimality or failure of all future interventions.
"""

import argparse
from collections import Counter, defaultdict
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ite.official_model import OfficialModelAdapter, OFFICIAL_PROFILES
from ite.official_sft_crossfit import (load_public_training_source, make_crossfit_folds,
                                      choose_counterfactual_action)
from ite.official_sft_data import metrics
from ite.models import prediction_loss
from ite.official_sft_replay import replay_partition, _bounded_fit
from ite.tracking import source_metadata


ACTIONS = ("DO_NOTHING", "RETRAIN_LARGE", "RETRAIN_HEAD_ONLY")
SCENARIOS = ("stable", "abrupt", "gradual")
LIMITATION = ("Cross-fit surrogate public-development evidence only. Finite candidate set: "
              "DO_NOTHING, RETRAIN_LARGE, RETRAIN_HEAD_ONLY; 12-batch horizon. "
              "DO_NOTHING means no tested intervention met paired outcome and guards; "
              "not absolute optimality or proof all future interventions fail.")
BOOTSTRAP_SECONDS = 120.


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False))


def runtime_python():
    configured = os.environ.get("ITE_OFFICIAL_RUNTIME_PYTHON")
    path = Path(configured) if configured else ROOT / ".venv-official-a" / "Scripts" / "python.exe"
    if not path.is_file() or path.resolve() == Path(sys.executable).resolve():
        raise ValueError("A separate existing NumPy 1.26.4 runtime is required")
    return str(path.resolve())


def bootstrap_fold(data, fold, output_dir, runtime=None):
    """Initialize once, preserve complete stdout/stderr, timeout kills/reaps child.

    subprocess.run uses communicate(timeout) and kills and reaps the process on
    TimeoutExpired. The cap is fixed before observing results, never retried.
    """
    output = Path(output_dir).resolve()
    output.mkdir(parents=True, exist_ok=False)
    request = {"profile": data["profile"], "package": data["package"],
        "package_sha256": data["package_sha256"], "train_sha256": data["train_sha256"],
        "fold": fold, "checkpoint_output": str(output / "initial.npz")}
    write_json(output / "request.json", request)
    environment = os.environ.copy()
    for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                "NUMEXPR_NUM_THREADS", "BASELINE_CPU_THREADS"):
        environment[key] = "1"
    started, stdout, stderr = time.perf_counter(), b"", b""
    report = {"status": "incomplete", "model_kind": "cross_fit_surrogate",
              "bootstrap_cap_seconds": BOOTSTRAP_SECONDS, "official_acceptance": False}
    try:
        result = subprocess.run([runtime or runtime_python(), str(ROOT / "ite" / "official_crossfit_worker.py")],
            input=canonical(request).encode(), stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            timeout=BOOTSTRAP_SECONDS, env=environment, check=False)
        stdout, stderr = result.stdout, result.stderr
        if result.returncode:
            raise RuntimeError(f"bootstrap exited {result.returncode}")
        payload = json.loads(stdout)
        _require(payload.get("status") == "ok" and payload.get("numpy_version") == "1.26.4",
                 "Bootstrap failed pinned runtime contract")
        _require(payload["checkpoint_sha256"] == file_hash(output / "initial.npz"), "Bootstrap checkpoint hash")
        _require(payload["used_ids"] == [data["ids"][i] for i in fold["initialization_indices"]],
                 "Bootstrap initialization IDs differ")
        report.update(payload)
    except subprocess.TimeoutExpired as error:
        stdout, stderr = error.stdout or b"", error.stderr or b""
        report["error"] = "bootstrap_timeout"
    except Exception as error:
        report["error"] = f"{type(error).__name__}: {error}"
    report["process_seconds"] = time.perf_counter() - started
    (output / "stdout.txt").write_bytes(stdout)
    (output / "stderr.txt").write_bytes(stderr)
    write_json(output / "report.json", report)
    return report


def build_plan(sources):
    folds, states, groups, counts = {}, [], {}, {}
    for profile, data in sources.items():
        folds[profile] = make_crossfit_folds(profile, data)
        groups[profile] = sum(len(f["replay_groups"]) for f in folds[profile])
        for fold in folds[profile]:
            for group in fold["replay_groups"]:
                indices = (fold["replay_indices"] if profile == "A" else
                    [i for i in fold["replay_indices"] if data["groups"][i] == group])
                for scenario in SCENARIOS:
                    for step in (3, 7):
                        states.append({"profile": profile, "fold_id": fold["fold_id"],
                            "split": fold["split"], "source_group": group, "indices": indices,
                            "scenario": scenario, "step": step})
        counts[profile] = sum(s["profile"] == profile for s in states)
    return {"folds": folds, "states": states, "state_counts": counts,
            "source_group_counts": groups, "physical_arm_replays": len(states) * 3,
            "candidate_actions": list(ACTIONS), "bootstrap_cap_seconds": BOOTSTRAP_SECONDS,
            "candidate_cap_seconds": 5., "flow_train_cap_seconds": 20., "limitation": LIMITATION}


def action_messages(context):
    """Rebuild model input exclusively from allowlisted decision-visible fields."""
    profile = context["profile"]
    contract, obs = OFFICIAL_PROFILES[profile], context["observation"]
    visible = {"profile": profile, "task": contract["task"], "n_features": contract["n_features"],
        "target_unit": contract["target_unit"], "loss_trend": [
            {k: row[k] for k in ("source_step", "loss", "labeled_samples")} for row in obs["loss_trend"]],
        **{k: obs[k] for k in ("drift_alarm", "model_age_batches", "remaining_token_budget",
                               "remaining_label_budget")},
        "feature_distance": context["feature_distance"],
        "remaining_train_seconds": context["remaining_train_seconds"]}
    objective = {"A": "Improve Macro-F1 without reducing accuracy.",
        "B": "Reduce RMSE without increasing MAE.",
        "C": "Reduce RMSE without increasing overestimate rate or mean positive overestimate."}[profile]
    return [{"role": "system", "content": "Select one action only. " + objective +
        " DO_NOTHING: retain current model. RETRAIN_LARGE: fine-tune all model parameters on the "
        "released large window. RETRAIN_HEAD_ONLY: fine-tune the output head on that same window. "
        "Interventions must pass screening and an independent future gate within the fixed budget."},
        {"role": "user", "content": canonical(visible)}]


class CachedInitialModel:
    """Standalone deterministic static inference cache, never used for candidates."""

    def __init__(self, model, cache):
        self._model, self._cache = model, cache

    def __getattr__(self, name):
        return getattr(self._model, name)

    def predict(self, features):
        x = np.asarray(features)
        if x.ndim != 2 or not np.isfinite(x).all():
            raise ValueError("Cache requires finite feature matrix")
        key = (self.checkpoint_sha256, float(getattr(self._model, "safety_margin", 0.)),
               x.shape, x.dtype.str, hashlib.sha256(x.tobytes(order="C")).digest())
        if key not in self._cache:
            self._cache[key] = self._model.predict(x).copy()
        return self._cache[key].copy()


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _single(events, kind, *, step=None):
    rows = [e for e in events if e["event"] == kind and (step is None or e["step"] == step)]
    _require(len(rows) == 1, f"Expected exactly one {kind} event at {step}")
    return rows[0]


def audit_counterfactual_arms(data, indices, root, step, checkpoint_sha256, initialization_ids):
    try:
        return _audit_counterfactual_arms(data, indices, root, step, checkpoint_sha256, initialization_ids)
    except (KeyError, TypeError, OSError, IndexError) as error:
        raise ValueError(f"Malformed/incomplete counterfactual evidence: {error}") from error


def _audit_counterfactual_arms(data, indices, root, step, checkpoint_sha256, initialization_ids):
    """Validate raw complete matched arms BEFORE invoking the outcome selector.

    Neither a malformed outcome nor missing provenance can become DO_NOTHING.
    Predictions/events are the authority for deployment timing and suffix IDs.
    """
    indices = np.asarray(indices, dtype=int)
    expected_ids = [data["ids"][i] for i in indices]
    _require(len(expected_ids) >= 48 and len(set(expected_ids)) == len(expected_ids), "Invalid replay rows")
    _require(not set(expected_ids) & set(initialization_ids), "Initialization overlaps replay")
    batches = np.array_split(indices, 12)
    batch_ids = [[data["ids"][i] for i in b] for b in batches]
    baseline, state, outcomes, hashes = None, None, [], {}
    for action in ACTIONS:
        arm = Path(root) / action
        summary = json.loads((arm / "summary.json").read_text(encoding="utf-8"))
        events = [json.loads(s) for s in (arm / "events.jsonl").read_text(encoding="utf-8").splitlines()]
        with np.load(arm / "predictions.npz", allow_pickle=False) as archive:
            _require(set(archive.files) == {"source_ids", "targets", "static", "active", "versions"},
                     "Unexpected prediction arrays")
            arrays = {k: archive[k].copy() for k in archive.files}
        _require(all(v.shape == (len(indices),) for v in arrays.values()), "Incomplete prediction arrays")
        _require(arrays["source_ids"].tolist() == expected_ids, "Source IDs differ from frozen stream")
        _require(np.array_equal(arrays["targets"], data["y"][indices]), "Targets differ from frozen stream")
        _require(all(np.isfinite(arrays[k]).all() for k in ("targets", "static", "active", "versions")),
                 "Nonfinite arm arrays")
        _require(all((np.isin(arrays[k], np.arange(1, 7)).all() if data["profile"] == "A" else
                      (arrays[k] >= 0).all()) for k in ("static", "active")), "Invalid prediction target domain")
        _require(arrays["versions"].dtype.kind in "iu", "Model versions must be integers")
        if baseline is None:
            baseline = arrays["static"]
        _require(np.array_equal(arrays["static"], baseline), "Initial predictions differ across arms")
        _require(len(summary["records"]) == 1, "Missing/extra decision record")
        record, started = summary["records"][0], _single(events, "run_started", step=-1)
        _require(started["parent_checkpoint"] == checkpoint_sha256 and started["batches"] == 12 and
            started["rows"] == len(indices) and started["a_replay_policy"] == "none" and
            started["c_replay_policy"] == "none", "Initial checkpoint/replay policy mismatch")
        _require(record["action"] == action and record["step"] == step and
                 record["evidence"]["candidate_parent_checkpoint"] == checkpoint_sha256,
                 "Counterfactual action/parent mismatch")
        _require(record["teacher_source"] == "counterfactual_probe" and not record["qualified"],
                 "Local probes cannot become Teacher supervision")
        complete = _single(events, "run_completed", step=12)
        _require(events[-1] == complete and
                 all(complete[k] == v for k, v in summary.items() if k != "records"), "Incomplete arm summary")
        _require(summary["profile"] == data["profile"] and started["profile"] == data["profile"] and
            started["scenario"] == summary["scenario"] and started["split"] == summary["split"],
            "Arm profile/split/scenario mismatch")
        _require(record["profile"] == summary["profile"] and record["scenario"] == summary["scenario"] and
                 record["split"] == summary["split"], "Record scenario/split mismatch")
        for key, prediction_key in (("static_metrics", "static"), ("active_metrics", "active")):
            _require(summary[key] == metrics(data["profile"], arrays["targets"], arrays[prediction_key]),
                     "Arm metric evidence mismatch")
        predictions = [e for e in events if e["event"] == "prediction"]
        _require(len(predictions) == 12 and [e["step"] for e in predictions] == list(range(12)),
                 "Incomplete prediction event horizon")
        releases = [e for e in events if e["event"] == "labels_released"]
        _require(len(releases) == 11, "Incomplete release horizon")
        active_batches = np.array_split(arrays["active"], 12)
        released_losses = []
        for number, release in enumerate(releases, 1):
            loss = prediction_loss(data["task"], data["y"][batches[number-1]], active_batches[number-1], data["loss_scale"])
            released_losses.append({"source_step": number-1, "loss": loss, "labeled_samples": len(batches[number-1])})
            _require(release["step"] == number and release["source_step"] == number-1 and
                release["samples"] == len(batches[number-1]) and release["loss"] == loss and
                events.index(predictions[number]) < events.index(release), "Release timing/loss mismatch")
        observation = _single(events, "harness_observation", step=step)
        decision = _single(events, "harness_decision", step=step)
        _require(decision["action"] == action and decision["decision_id"] == record["decision_id"],
                 "Decision event mismatch")
        _require(sum(e["event"] == "harness_decision" for e in events) == 1 and
                 sum(e["event"] == "harness_observation" for e in events) == 1, "Extra decision state")
        _require(observation["observation"] == record["observation"] and
                 observation["feature_distance"] == record["feature_distance"] and
                 observation["remaining_train_seconds"] == record["remaining_train_seconds"] == 20.,
                 "Observation/budget mismatch")
        obs = record["observation"]
        expected_alarm = (record["feature_distance"] >= .65 or
            float(np.mean([r["loss"] for r in released_losses[:step][-3:]])) > released_losses[0]["loss"] + .13)
        _require(obs["loss_trend"] == released_losses[:step][-5:] and
                 obs["model_age_batches"] == step+1 and obs["remaining_token_budget"] == 60000 and
                 obs["remaining_label_budget"] is None and obs["drift_alarm"] == bool(expected_alarm),
                 "Observation includes nonvisible or incorrect information")
        _require(events.index(releases[step-1]) < events.index(observation) < events.index(decision),
                 "Observation precedes released labels")
        released = [v for ids in batch_ids[:step] for v in ids]
        _require(record["source_ids"] == released and
            record["source_groups"] == sorted({data["groups"][i] for i in indices}), "Visible source provenance")
        visible_state = {k: record[k] for k in ("profile", "split", "scenario", "step", "observation",
            "feature_distance", "remaining_train_seconds", "source_ids", "source_groups")}
        visible_state["checkpoint_sha256"] = checkpoint_sha256
        if state is None:
            state = visible_state
        _require(visible_state == state, "Counterfactual states differ")
        _require(record["messages"] == action_messages(record), "Arm messages differ from visible allowlist")
        _require(not any(e["event"] in ("training_failed", "rollback") for e in events), "Engineering failure")
        evidence = record["evidence"]
        seconds = summary["train_seconds"]
        _require(type(seconds) in (int, float) and np.isfinite(seconds) and 0 <= seconds <= 20., "Flow budget")
        gate_event, deployed_at = None, None
        if action == "DO_NOTHING":
            _require(summary["training_attempts"] == 0 and seconds == 0 and summary["updates"] == 0,
                     "DO_NOTHING changed model")
            _require(not any(e["event"] in ("candidate_evaluated", "candidate_frozen", "deploy") for e in events),
                     "Unexpected intervention")
        else:
            evaluated = _single(events, "candidate_evaluated", step=step)
            _require(summary["training_attempts"] == 1 and
                record.get("rejection") not in ("training_over_budget", "training_budget_exhausted",
                    "candidate_training_error", "awaiting_independent_future_gate"), "Incomplete adaptation")
            _require(type(evidence["train_seconds"]) in (int, float) and
                np.isfinite(evidence["train_seconds"]) and 0 <= evidence["train_seconds"] <= 5. and
                seconds == evidence["train_seconds"], "Candidate budget")
            evaluated_keys = ("candidate_parent_checkpoint", "train_samples", "screening_samples", "train_max_source_step",
                "selection_loss", "incumbent_loss", "train_seconds", "candidate_checkpoint", "trainable_policy",
                "fit_audit", "loss_policy", "parent_adam_steps", "candidate_adam_steps", "a_replay_policy",
                "c_replay_policy", "train_source_ids", "online_train_source_ids", "replay_source_ids",
                "replaced_online_source_ids", "screening_source_ids")
            _require(all(k in evaluated and evaluated[k] == evidence[k] for k in evaluated_keys) and
                evaluated["decision_id"] == record["decision_id"],
                     "Candidate event evidence mismatch")
            window = released[-768:]
            selection = max(4, min(48, len(window) // 4))
            train_ids, screen_ids = window[:-selection], window[-selection:]
            _require(evidence["train_source_ids"] == train_ids and evidence["online_train_source_ids"] == train_ids and
                evidence["screening_source_ids"] == screen_ids and evidence["train_samples"] == len(train_ids) and
                evidence["screening_samples"] == len(screen_ids) and evidence["train_max_source_step"] == step - 1 and
                not evidence["replay_source_ids"] and evidence["loss_policy"] == "squared" and
                evidence["a_replay_policy"] == evidence["c_replay_policy"] == "none", "Fit/screen source isolation")
            _require(evidence["trainable_policy"] == ("head_only" if action == "RETRAIN_HEAD_ONLY" else "full"),
                     "Unexpected trainable parameters")
            _require(not set(train_ids) & set(screen_ids) and
                not (set(train_ids) | set(screen_ids)) & set(initialization_ids), "Initialization/fit/screen overlap")
            candidate_file = arm / f"candidate-step{step}.npz"
            if len(evidence["candidate_checkpoint"]) == 64:
                _require(candidate_file.is_file() and file_hash(candidate_file) == evidence["candidate_checkpoint"],
                         "Missing/changed candidate checkpoint")
            if evidence["selection_loss"] >= evidence["incumbent_loss"]:
                _require(record["rejection"] == "not_better_on_selection" and "future_gate" not in evidence and
                         not any(e["event"] == "candidate_frozen" for e in events), "Screening rejection mismatch")
            else:
                frozen = _single(events, "candidate_frozen", step=step)
                _require(frozen["candidate_checkpoint"] == evidence["candidate_checkpoint"] and
                    frozen["decision_id"] == record["decision_id"], "Frozen checkpoint mismatch")
                gate = evidence["future_gate"]
                _require(gate["frozen_at"] == step and gate["source_step"] == step + 1 and
                    gate["source_ids"] == batch_ids[step + 1], "Independent future gate provenance")
                kind = "deploy" if gate["accepted"] else "experiment_rejected"
                gate_events = [e for e in events if e["event"] == kind and
                               e.get("reason") == "independent_future_labels"]
                _require(len(gate_events) == 1, "Missing/extra future gate event")
                gate_event = gate_events[0]
                _require(gate_event["step"] == step + 2 and gate_event["source_ids"] == gate["source_ids"] and
                    gate_event["frozen_at"] == step and gate_event["gate_min_source_step"] == step + 1 and
                    gate_event["decision_id"] == record["decision_id"] and
                    all(gate_event[k] == gate[k] for k in ("accepted", "incumbent_loss", "candidate_loss",
                                                          "validation_gain", "model_version")), "Gate event mismatch")
                _require(events.index(frozen) < events.index(gate_event) and
                    events.index(predictions[step+2]) < events.index(gate_event), "Gate precedes freeze/prediction")
                _require(type(gate["accepted"]) is bool and gate["model_version"] == int(gate["accepted"]) and
                    (gate["validation_gain"] > 0) == gate["accepted"] and
                    np.isfinite(gate["validation_gain"]) and
                    gate["validation_gain"] == gate["incumbent_loss"] - gate["candidate_loss"],
                    "Gate loss/acceptance mismatch")
                _require(not (set(train_ids) | set(screen_ids) | set(initialization_ids)) & set(gate["source_ids"]),
                         "Gate source overlap")
                if gate["accepted"]:
                    deployed_at = step + 2
                    _require(evidence["deployed_at"] == deployed_at and evidence["deployment_version"] == 1,
                             "Deployment provenance mismatch")
                else:
                    _require(record["rejection"] == "independent_future_gate_rejected" and
                             "deployment_version" not in evidence, "Rejected gate deployed")
        _require(sum(e["event"] == "deploy" for e in events) == int(deployed_at is not None), "Extra deployment")
        _require(summary["updates"] == int(deployed_at is not None), "Update count mismatch")
        offset = 0
        for number, prediction in enumerate(predictions):
            version = int(deployed_at is not None and number > deployed_at)
            n = len(batches[number])
            _require(prediction["model_version"] == version and prediction["source_ids"] == batch_ids[number] and
                prediction["samples"] == n and np.all(arrays["versions"][offset:offset+n] == version),
                "Prediction version/source/horizon mismatch")
            if not version:
                _require(np.array_equal(arrays["active"][offset:offset+n], baseline[offset:offset+n]),
                         "Candidate predicted before deployment")
            offset += n
        if deployed_at is not None:
            suffix = arrays["versions"] == 1
            suffix_ids = set(arrays["source_ids"][suffix].tolist())
            _require(suffix.any() and not suffix_ids & (set(initialization_ids) | set(train_ids) |
                set(screen_ids) | set(evidence["future_gate"]["source_ids"])), "Deployed suffix overlaps fitting/gate")
            for key, prediction_key in (("post_deployment_static", "static"), ("post_deployment_active", "active")):
                _require(evidence[key] == metrics(data["profile"], arrays["targets"][suffix], arrays[prediction_key][suffix]),
                         "Deployed suffix metric mismatch")
        outcomes.append(record)
        hashes[action] = {p.name: file_hash(p) for p in sorted(arm.iterdir()) if p.is_file()}
    return {"outcomes": outcomes, "state_sha256": digest(state), "arms": hashes,
            "messages": action_messages(state), "train_seconds": sum(r["evidence"].get("train_seconds", 0.)
                                                                      for r in outcomes)}


def run_decision_state(data, indices, fold, group, scenario, step, output_dir, model_factory, *, trainer=_bounded_fit):
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=False)
    row = {"profile": data["profile"], "fold_id": fold["fold_id"], "split": fold["split"],
        "source_group": group, "scenario": scenario, "step": step, "status": "review",
        "limitation": LIMITATION, "review_issues": [], "messages": []}
    checkpoint, arm_costs = None, {}
    for action in ACTIONS:
        started = time.perf_counter()
        try:
            model = model_factory()
            if checkpoint is None:
                checkpoint = model.checkpoint_sha256
            _require(model.checkpoint_sha256 == checkpoint, "Model factory changed initial checkpoint")
            def decide(context, action=action):
                return {"action": action, "reason": "固定本地动作探针。", "source": "counterfactual_probe",
                        "messages": action_messages(context)}
            replay_partition(data, indices, fold["split"], scenario, output / action, model, decide,
                decision_steps=(step,), trainer=trainer, action_profile="official_finetune")
        except Exception as error:
            row["review_issues"].append(f"{action}: {type(error).__name__}: {error}")
        cost = {"process_seconds": time.perf_counter()-started, "train_seconds": None, "released_label_rows": None}
        try:
            summary = json.loads((output / action / "summary.json").read_text(encoding="utf-8"))
            events = [json.loads(s) for s in (output / action / "events.jsonl").read_text(encoding="utf-8").splitlines()]
            cost.update(train_seconds=summary["train_seconds"],
                        released_label_rows=sum(e["samples"] for e in events if e["event"] == "labels_released"))
        except (OSError, ValueError, KeyError):
            pass
        arm_costs[action] = cost
    row["costs"] = {"arms": arm_costs,
        "adaptation_train_seconds": sum(c["train_seconds"] or 0. for c in arm_costs.values()),
        "released_label_rows": sum(c["released_label_rows"] or 0 for c in arm_costs.values()),
        "complete": all(c["train_seconds"] is not None for c in arm_costs.values())}
    try:
        audit = audit_counterfactual_arms(data, indices, output, step, checkpoint, fold["initialization_ids"])
        row["messages"], row["evidence"] = audit.pop("messages"), audit
        _require(not row["review_issues"], "An arm replay failed")
        row.update(status="complete", target_action=choose_counterfactual_action(data["profile"], audit["outcomes"]))
    except Exception as error:
        row["review_issues"].append(f"audit: {type(error).__name__}: {error}")
        row["raw_arm_hashes"] = {p.relative_to(output).as_posix(): file_hash(p) for p in sorted(output.rglob("*")) if p.is_file()}
    write_json(output / "decision.json", row)
    return row


def export_dataset(rows, output_dir):
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=False)
    inputs, group_splits = defaultdict(list), defaultdict(set)
    for row in rows:
        inputs[digest(row["messages"])].append(row)
        group_splits[(row["profile"], row["source_group"])].add(row["split"])
    exported = {"train": [], "eval": [], "review": []}
    for input_hash, matches in inputs.items():
        issues = []
        if len({r.get("target_action") for r in matches if r["status"] == "complete"}) > 1:
            issues.append("identical_input_conflicting_actions")
        if len({r["split"] for r in matches}) > 1:
            issues.append("identical_input_cross_split")
        if any(len(group_splits[(r["profile"], r["source_group"])]) > 1 for r in matches):
            issues.append("source_group_cross_split")
        if any(r["status"] != "complete" for r in matches):
            issues.append("engineering_incomplete")
        if issues:
            for row in matches:
                review = {**row, "status": "review", "input_sha256": input_hash,
                          "review_issues": row.get("review_issues", []) + issues}
                review.pop("target_action", None)
                exported["review"].append(review)
        else:
            row = dict(matches[0])
            row.update(input_sha256=input_hash, duplicate_count=len(matches),
                duplicate_sources=[{k: r.get(k) for k in ("profile", "fold_id", "source_group", "scenario", "step")}
                                   for r in matches], duplicate_evidence=[r.get("evidence", {}) for r in matches])
            exported[row["split"]].append(row)
    for split, items in exported.items():
        with (output / f"{split}.jsonl").open("x", encoding="utf-8") as stream:
            for row in items:
                stream.write(canonical(row) + "\n")
    counts = {p: {s: dict(Counter(r["target_action"] for r in exported[s] if r["profile"] == p))
                  for s in ("train", "eval")} for p in OFFICIAL_PROFILES}
    issues = []
    if exported["review"]:
        issues.append("review_records_present")
    for p in counts:
        for s in ("train", "eval"):
            if not counts[p][s]:
                issues.append(f"{p}_{s}_empty")
            elif len(counts[p][s]) < 2:
                issues.append(f"{p}_{s}_single_action")
    manifest = {"counts": {s: len(v) for s, v in exported.items()}, "action_counts": counts,
        "unique_source_groups": {p: {s: len({r["source_group"] for r in rows if r["profile"] == p and r["split"] == s})
                                     for s in ("train", "eval")} for p in OFFICIAL_PROFILES},
        "qualified_source_groups": {p: {s: len({r["source_group"] for r in exported[s] if r["profile"] == p})
                                         for s in ("train", "eval")} for p in OFFICIAL_PROFILES},
        "readiness_issues": issues, "structural_data_ready": not issues,
        "remote_training_ready": False, "statistical_acceptance": "not_assessed",
        "official_acceptance": False, "limitation": LIMITATION,
        "hashes": {f"{s}.jsonl": file_hash(output / f"{s}.jsonl") for s in exported}}
    write_json(output / "manifest.json", manifest)
    return manifest


def run(output_dir, profiles=("A", "B", "C"), *, plan_only=False, progress=None):
    output = Path(output_dir).resolve()
    output.mkdir(parents=True, exist_ok=False)
    sources = {p: load_public_training_source(p) for p in profiles}
    plan = build_plan(sources)
    freeze = {"source": source_metadata(), "numpy": np.__version__, "python": sys.version,
        "plan": plan, "source_manifests": {p: {k: d[k] for k in ("package", "package_sha256", "train_sha256", "ids", "groups")}
                                             for p, d in sources.items()},
        "code_hashes": {p.relative_to(ROOT).as_posix(): file_hash(p) for p in
            (Path(__file__), ROOT / "ite" / "official_crossfit_worker.py", ROOT / "ite" / "official_sft_crossfit.py",
             ROOT / "ite" / "official_sft_replay.py", ROOT / "ite" / "official_model.py")}}
    write_json(output / "freeze.json", freeze)
    if plan_only:
        return plan
    runtime = runtime_python()
    records, bootstrap_reports = [], []
    def add_record(row):
        records.append(row)
        if progress is not None:
            progress({"event": "decision_completed", **{k: row.get(k) for k in
                ("profile", "fold_id", "source_group", "scenario", "step", "status", "target_action")}})
    for profile, folds in plan["folds"].items():
        data = sources[profile]
        for fold in folds:
            bootstrap_path = output / "bootstrap" / fold["fold_id"]
            report = bootstrap_fold(data, fold, bootstrap_path, runtime)
            bootstrap_reports.append(report)
            if progress is not None:
                progress({"event": "bootstrap_completed", "profile": profile, "fold_id": fold["fold_id"],
                          "status": report["status"], "process_seconds": report["process_seconds"],
                          "training_seconds": report.get("training_seconds")})
            states = [s for s in plan["states"] if s["fold_id"] == fold["fold_id"]]
            if report["status"] != "ok":
                for state in states:
                    add_record({**{k: v for k, v in state.items() if k != "indices"}, "messages": [],
                        "status": "review", "review_issues": ["bootstrap_engineering_incomplete"], "bootstrap": report})
                continue
            data = {**data, "scale": np.asarray(report["scale"]), "loss_scale": report["loss_scale"]}
            try:
                initial = OfficialModelAdapter(data["task"], runtime, data["package"], profile_type=profile,
                    checkpoint_path=bootstrap_path / "initial.npz")
                initial_state, cache = initial.state(), {}
            except Exception as error:
                for state in states:
                    add_record({**{k: v for k, v in state.items() if k != "indices"}, "messages": [],
                        "status": "review", "review_issues": [f"bootstrap_adapter_error: {type(error).__name__}: {error}"],
                        "bootstrap": report})
                continue
            def factory():
                return CachedInitialModel(OfficialModelAdapter.from_state(initial_state), cache)
            annotated_fold = {**fold, "initialization_ids": report["used_ids"]}
            for state in states:
                key = digest(state)[:20]
                add_record(run_decision_state(data, state["indices"], annotated_fold, state["source_group"],
                    state["scenario"], state["step"], output / "arms" / key, factory))
    dataset = export_dataset(records, output / "dataset")
    costs = {"bootstrap_training_seconds": sum(r.get("training_seconds", 0.) for r in bootstrap_reports),
        "bootstrap_process_seconds": sum(r["process_seconds"] for r in bootstrap_reports),
        "adaptation_train_seconds": sum(r.get("costs", {}).get("adaptation_train_seconds", 0.) for r in records),
        "released_label_rows": sum(r.get("costs", {}).get("released_label_rows", 0) for r in records),
        "costs_complete": all(r["status"] == "ok" for r in bootstrap_reports) and
                          all(r.get("costs", {}).get("complete", False) for r in records),
        "bootstrap_incomplete": sum(r["status"] != "ok" for r in bootstrap_reports),
        "candidate_cap_seconds": 5., "flow_train_cap_seconds": 20., "bootstrap_cap_seconds": BOOTSTRAP_SECONDS,
        "remote_requests": 0, "llm_tokens": 0, "new_label_requests": 0}
    report = {"model_kind": "cross_fit_surrogate", "planned_states": len(plan["states"]),
        "planned_physical_arm_replays": plan["physical_arm_replays"], "dataset": dataset,
        "bootstrap_reports": bootstrap_reports, "costs": costs,
        "engineering_complete": not costs["bootstrap_incomplete"] and all(r["status"] == "complete" for r in records),
        "output_hashes": {p.relative_to(output).as_posix(): file_hash(p) for p in sorted(output.rglob("*")) if p.is_file()},
        "limitation": LIMITATION}
    write_json(output / "report.json", report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--profiles", nargs="+", choices=list(OFFICIAL_PROFILES), default=list(OFFICIAL_PROFILES))
    parser.add_argument("--plan-only", action="store_true")
    args = parser.parse_args()
    result = run(args.output, tuple(dict.fromkeys(args.profiles)), plan_only=args.plan_only,
                 progress=lambda row: print(canonical(row), flush=True))
    print(canonical({k: result[k] for k in ("state_counts", "physical_arm_replays") if k in result} or
                    {"engineering_complete": result["engineering_complete"], "costs": result["costs"]}))


if __name__ == "__main__":
    main()
