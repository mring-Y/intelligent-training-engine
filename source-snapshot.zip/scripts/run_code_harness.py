"""Opt-in public A/B/C ten-round code Harness; defaults to a no-network rehearsal."""

import argparse
from decimal import Decimal
import json
import os
from pathlib import Path
import sys
import urllib.request
import zipfile

from ite.code_harness import TenRoundRun, load_round_data, digest, write_new
from ite.code_harness_agent import PaidToolSession, RehearsalActor, run_agent, MODEL, MODEL_SETTINGS
from ite.official_model import OfficialModelAdapter, OFFICIAL_PROFILES
from ite.tracking import source_metadata, _check_artifact


ROOT = Path(__file__).resolve().parents[1]
PRIOR = ROOT / "outputs/pytrio-decision-sft-paid-state-20261114/request-ledger.json"


def argument_parser():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--mode", choices=("rehearsal", "paid", "replay"), default="rehearsal")
    parser.add_argument("--model", choices=tuple(MODEL_SETTINGS), default=MODEL)
    parser.add_argument("--answers", type=Path, help="Frozen host answers.jsonl; replay never calls a service")
    parser.add_argument("--official-python", default=os.environ.get("ITE_OFFICIAL_RUNTIME_PYTHON",
        str(ROOT / ".venv-official-a/Scripts/python.exe")))
    parser.add_argument("--llm-python", default=str(ROOT / ".venv-sft/Scripts/python.exe"))
    parser.add_argument("--previous-ledger", type=Path, default=PRIOR)
    parser.add_argument("--additional-ledger", action="append", type=Path, default=[])
    parser.add_argument("--renewed-cumulative-budget-cny", default=None,
                        help="Explicit user-authorized new session; carries all old reservations; must be <30 CNY")
    parser.add_argument("--proposal-corrections",type=int,choices=(0,2),default=0,
                        help="Bounded new decisions after a rejected host-tool proposal; never network retries")
    parser.add_argument("--paid-state", type=Path, default=ROOT / "outputs/code-harness-paid-state-20261114")
    parser.add_argument("--swanlab", choices=("none", "offline", "online"), default="none")
    return parser


def check_prices(model=MODEL):
    settings = MODEL_SETTINGS[model]
    with urllib.request.urlopen("https://pytrio.cn/api/model-prices", timeout=15) as response:
        prices = json.loads(response.read())
    price = next(item for item in prices["items"] if item["display_name"] == model)
    if (prices.get("currency") != "CNY" or prices.get("token_unit") != "per_1m_tokens" or
            [Decimal(str(price["prices"][key]["unit_price"]))/100 for key in ("prefill", "sample")] !=
            [Decimal(settings["input_price"]), Decimal(settings["output_price"])]):
        raise ValueError("Approved model inference prices changed")
    return prices


def execute(args):
    output = args.output.resolve()
    if args.mode == "replay" and args.answers is None:
        raise ValueError("Offline replay requires frozen tool answers")
    if args.mode != "replay" and args.answers is not None:
        raise ValueError("Frozen answers are only accepted in explicit replay mode")
    # A paid claim and pricing preflight occur before any model service calls.
    prices = check_prices(args.model) if args.mode == "paid" else None
    output.mkdir(parents=True, exist_ok=False)
    session = PaidToolSession(output / "network", args.paid_state, args.previous_ledger,
                              additional_ledgers=args.additional_ledger,
                              renewal_cny=args.renewed_cumulative_budget_cny,
                              max_proposal_corrections=args.proposal_corrections,
                              runtime_python=args.llm_python, model=args.model) if args.mode == "paid" else None
    answers = None
    if args.mode == "replay":
        answers = iter([json.loads(line) for line in args.answers.read_text(encoding="utf-8").splitlines()])
    freeze = {"mode": args.mode, "source": source_metadata(), "model": args.model if args.mode != "rehearsal" else None,
        "real_llm": session is not None, "development_only": True, "packages": ["A","B","C"],
        "ten_rounds_per_package": True, "prices": prices, "runtime_python": args.official_python,
        "frozen_answers_sha256": digest(args.answers) if args.answers else None,
        "source_files": {name: digest(ROOT / name) for name in ("ite/code_harness.py",
            "ite/code_harness_agent.py", "ite/trio_client.py", "scripts/run_code_harness.py")}}
    write_new(output / "freeze.json", freeze)
    packages, errors = {}, []
    for profile in ("A", "B", "C"):
        data = load_round_data(profile)
        initial = OfficialModelAdapter(OFFICIAL_PROFILES[profile]["task"], args.official_python,
                                       profile_type=profile, candidate_epochs=5)
        run = TenRoundRun(output / profile, data, initial)
        rehearsal = RehearsalActor()
        def ask(stage, payload):
            if session is not None:
                reply = session.ask(stage, payload)
            elif answers is not None:
                item = next(answers)
                if item["stage"] != stage or item["profile"] != profile:
                    raise ValueError("Replay answer stage or package mismatch")
                reply = item["reply"]
            else:
                reply = rehearsal(stage, payload)
            with (output / "answers.jsonl").open("a", encoding="utf-8", newline="\n") as stream:
                stream.write(json.dumps({"profile": profile, "stage": stage, "reply": reply},
                                        ensure_ascii=False, allow_nan=False) + "\n")
            print(f"{profile} {stage}: {reply.get('tool')}; completed={run.completed_rounds}", flush=True)
            return reply
        try:
            packages[profile] = run_agent(run, ask,max_proposal_corrections=args.proposal_corrections)
        except Exception as error:
            errors.append({"profile": profile, "error_type": type(error).__name__, "message": str(error)[:512]})
            run.event("run_failed_closed", error=type(error).__name__)
            packages[profile] = run.finish()
            # A failed live session is never replaced by a deterministic actor.
            if session is not None:
                break
    if answers is not None and not errors and next(answers, None) is not None:
        errors.append({"profile":"suite", "error_type":"ValueError", "message":"Unused replay answers"})
    result = {"mode": args.mode, "model": freeze["model"], "real_llm": session is not None, "development_only": True,
        "hidden_test_evaluated": False, "packages": packages, "errors": errors,
        "all_ten_rounds_complete": set(packages)=={"A","B","C"} and not errors and
            all(row["ten_rounds_complete"] for row in packages.values())}
    if session:
        prior = session.total_budget_cny-session.remaining
        result["cost"] = {"previous_reserved_cny":str(prior), "new_reserved_cny":session.ledger.reserved_cny,
            "cumulative_reserved_cny":str(prior+Decimal(session.ledger.reserved_cny)),
            "limit_cny":str(session.total_budget_cny), "requests":session.calls,
            "notice":"Conservative reservations and tariff estimates, not provider billing receipts."}
        write_new(output / "request-ledger.json", session.ledger.data)
    write_new(output / "summary.json", result)
    return result


def log_swanlab(output, result, *, mode="online", swan=None):
    if swan is None:
        import swanlab as swan
    output = Path(output)
    run = swan.init(workspace="mring-Y", project="Intelligent_Training_Engine",
        name=f"code-harness-ten-rounds-{result['mode']}-20261114", mode=mode,
        config={"mode":result["mode"], "development_only":True, "model":result.get("model", MODEL),
                "hidden_test_evaluated":False, "round_target_per_package":10},
        description="Constrained model-written CPU training wrappers, independent future gate, A/B/C")
    try:
        for profile, package in result["packages"].items():
            for number in range(1, package["completed_rounds"]+1):
                row=json.loads((output/profile/f"round-{number:02d}"/"experiment.json").read_text(encoding="utf-8"))
                run.log({f"{profile}/train_seconds":row["train_seconds"],
                         f"{profile}/screen_passed":int(row["screen_passed"]),
                         f"{profile}/gate_passed":int(row["gate_passed"]),
                         f"{profile}/epochs":row["config"]["epochs"],
                         f"{profile}/head_only":int(row["config"]["trainable_policy"]=="head_only")},step=number)
            values={f"{profile}/completed_rounds":package["completed_rounds"]}
            for scenario, comparison in package["final_development_metrics"].items():
                for arm, scores in comparison.items():
                    values.update({f"{profile}/{scenario}/{arm}/{key}":value for key,value in scores.items()
                                   if type(value) in (int,float)})
            run.log(values,step=11)
        paths=[p for p in sorted(output.rglob("*")) if p.is_file() and p.suffix in (".json",".jsonl",".npz",".py")]
        for path in paths:
            _check_artifact(path)
        with zipfile.ZipFile(output/"evidence.zip","x",compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("sha256.json",json.dumps({p.relative_to(output).as_posix():digest(p) for p in paths},indent=2))
            for path in paths:
                archive.write(path,path.relative_to(output).as_posix())
        swan.save(output/"evidence.zip",base_path=output,policy="now")
        swan.save(output/"summary.json",base_path=output,policy="now")
    finally:
        swan.finish()
    receipt={"run_id":getattr(run,"id",None),"mode":mode,"project":"mring-Y/Intelligent_Training_Engine",
             "archive_sha256":digest(output/"evidence.zip"),"status":"logged_and_upload_requested"}
    write_new(output/"swanlab-receipt.json",receipt)
    return receipt


def main():
    args=argument_parser().parse_args()
    result=execute(args)
    if args.swanlab!="none":
        log_swanlab(args.output,result,mode=args.swanlab)
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0 if result["all_ten_rounds_complete"] else 1


if __name__=="__main__":
    raise SystemExit(main())
