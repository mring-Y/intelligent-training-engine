"""Fixed FD001 static/Mock Tree pair, followed by isolated saved-result scoring."""

import argparse
import json
from collections import Counter
from pathlib import Path

import numpy as np
import pyarrow.parquet as pq

from ite.config import ExperimentConfig
from ite.providers import ColumnMapping
from ite.report import write_rows
from ite.runner import run_policy
from ite.tracking import source_metadata
from ite.training import BoundedTrainer
from scripts.data_prep.baseline import _verified_files
from scripts.data_prep.cmapss import FEATURES
from scripts.data_prep.common import fingerprint, write_json
from scripts.data_prep.provider import PreparedDataProvider
from scripts.gas_harness_report import _prediction_versions, _read_events


def _manifest(package):
    manifest = json.loads((package / "manifest.json").read_text(encoding="utf-8"))
    if (manifest.get("dataset") != "cmapss_fd001" or manifest.get("task") != "regression"
            or manifest.get("metadata", {}).get("subset") != "FD001"
            or manifest["column_mapping"]["features"] != list(FEATURES)):
        raise ValueError("FD001 requires its original 24 sensor/setting predictors")
    units = manifest["metadata"]["split_units"]
    if any(set(units[a]) & set(units[b]) for a, b in
           (("train", "val"), ("train", "stream"), ("val", "stream"))):
        raise ValueError("FD001 engine partitions must be disjoint")
    return manifest, _verified_files(package, manifest)


def _targets(package, manifest, files):
    mapping = manifest["column_mapping"]
    columns = [mapping[name] for name in ("sample_id", "batch", "target")] + ["unit_id", "cycle"]
    table = pq.read_table(files["stream"], columns=columns, use_threads=False).to_pydict()
    ids, steps, y, units, cycles = (np.asarray(table[name]) for name in columns)
    declared = manifest["splits"]["stream"]
    sizes = [int(np.count_nonzero(steps == step)) for step in range(declared["batches"])]
    cap = manifest["metadata"]["target"]["rul_cap"]
    if (any(a.ndim != 1 for a in (ids, steps, y, units, cycles))
            or any(a.dtype.kind not in "iu" for a in (ids, steps, units, cycles))
            or not len(ids) or len(ids) != declared["rows"] or len(set(ids.tolist())) != len(ids)
            or any(n < 1 for n in sizes)
            or not np.array_equal(steps, np.repeat(np.arange(len(sizes)), sizes))
            or y.dtype.kind not in "iuf" or not np.isfinite(y).all()
            or not np.isfinite(cap) or cap <= 30 or np.any((y < 0) | (y > cap))
            or not np.array_equal(np.unique(units), sorted(manifest["metadata"]["split_units"]["stream"]))
            or np.any(np.diff(units) < 0)):
        raise ValueError("FD001 saved rows do not match ordered package boundaries/targets")
    for unit in np.unique(units):
        selected = units == unit
        if np.any(np.diff(cycles[selected]) <= 0):
            raise ValueError("Engine cycles must increase chronologically")
    _verified_files(package, manifest)
    return ids, y.astype(float), units, cycles, np.cumsum([0, *sizes]), float(cap)


def _read_predictions(pair, policy, ids, offsets, events):
    with np.load(pair / policy / "predictions.npz", allow_pickle=False) as saved:
        p, actual_ids, actual_offsets = (saved[name].copy() for name in
                                         ("predictions", "sample_ids", "batch_offsets"))
    if (actual_ids.dtype.kind not in "iu" or not np.array_equal(actual_ids, ids)
            or actual_offsets.dtype.kind not in "iu" or not np.array_equal(actual_offsets, offsets)):
        raise ValueError("Prediction IDs/offsets do not match true FD001 rows")
    sizes = np.diff(offsets).tolist()
    if p.ndim == 2 and len(set(sizes)) == 1 and p.shape == (len(sizes), sizes[0]):
        p = p.reshape(-1)
    if p.shape != ids.shape or p.dtype.kind not in "iuf" or not np.isfinite(p).all():
        raise ValueError("Regression predictions must be finite and aligned")
    versions, timeline = _prediction_versions(events, sizes, policy)
    return p, versions, timeline


def _metrics(y, p):
    residual = p - y
    count = len(residual)
    sse = float(np.sum(residual ** 2))
    return {"samples": count, "squared_error_sum": sse,
            "rmse": float(np.sqrt(sse / count)) if count else None,
            "mae": float(np.mean(np.abs(residual))) if count else None,
            "bias": float(np.mean(residual)) if count else None,
            "residual_variance": float(np.var(residual)) if count else None}


def _group(y, predictions, mask, **identity):
    return {**identity, **{policy: _metrics(y[mask], p[mask]) for policy, p in predictions.items()}}


def _csv(path, rows):
    flattened = []
    for row in rows:
        values = {}
        for name, value in row.items():
            if isinstance(value, dict):
                values.update({f"{name}_{key}": v for key, v in value.items()})
            else:
                values[name] = value
        flattened.append(values)
    write_rows(path, flattened)


def _svg(rows, engines, timeline):
    parts = ['<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="740" viewBox="0 0 1200 740">',
             '<title>FD001 static Tree versus Mock Harness RMSE</title>',
             '<rect width="1200" height="740" fill="white"/>',
             '<g font-family="Arial,sans-serif" font-size="14" fill="#233044">',
             '<text x="75" y="32" font-size="22">FD001: static Tree vs Mock Harness</text>',
             '<text x="75" y="56">Offline sample-weighted RMSE (cycles); actual prediction versions</text>']
    for series, top, title in ((rows, 100, "Batch RMSE / cumulative RMSE"),
                               (engines, 425, "Per-engine RMSE (unit 81 onward)")):
        maximum = max(row[p]["rmse"] for row in series for p in ("static", "drift"))
        if series is rows:
            maximum = max(maximum, max(row[f"{p}_cumulative_rmse"] for row in rows for p in ("static", "drift")))
        maximum = max(maximum * 1.15, 1.)
        bottom = top + 210

        def x(i):
            return 75 + i * 1060 / max(1, len(series) - 1)

        def yy(value):
            return bottom - value * 210 / maximum

        parts.append(f'<text x="75" y="{top-15}">{title}</text>')
        for i in range(5):
            value = maximum * i / 4
            pos = yy(value)
            parts.extend([f'<line x1="75" x2="1135" y1="{pos}" y2="{pos}" stroke="#e1e6ec"/>',
                          f'<text x="20" y="{pos+5}">{value:.1f}</text>'])
        for policy, color in (("static", "#2563eb"), ("drift", "#d65b23")):
            points = " ".join(f'{x(i):.2f},{yy(row[policy]["rmse"]):.2f}' for i, row in enumerate(series))
            parts.append(f'<polyline points="{points}" fill="none" stroke="{color}" stroke-width="2.5"/>')
            if series is rows:
                points = " ".join(f'{x(i):.2f},{yy(row[f"{policy}_cumulative_rmse"]):.2f}' for i, row in enumerate(series))
                parts.append(f'<polyline points="{points}" fill="none" stroke="{color}" stroke-dasharray="6 4"/>')
        for i, row in enumerate(series):
            parts.append(f'<text x="{x(i):.2f}" y="{bottom+23}" text-anchor="middle">{row.get("step", row.get("unit_id"))}</text>')
        if series is rows:
            for item in timeline:
                event = item["first_next_prediction"]
                if event:
                    pos = x(event["step"])
                    parts.append(f'<line x1="{pos}" x2="{pos}" y1="{top}" y2="{bottom}" stroke="#16a34a" stroke-dasharray="3 3"/>')
                    parts.append(f'<text x="{pos+3}" y="{top+15}">v{event["model_version"]} first prediction</text>')
    parts.extend(['<text x="75" y="704" fill="#2563eb">Blue: static</text>',
                  '<text x="225" y="704" fill="#d65b23">Orange: Mock Harness</text>',
                  '<text x="470" y="704">Dashed: cumulative; green: deployed model first predicts</text>', '</g></svg>'])
    return "\n".join(parts)


def build_report(pair_dir, package_dir, output_dir):
    pair, package, output = map(Path, (pair_dir, package_dir, output_dir))
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite assessment: {output}")
    events = {p: _read_events(pair / p / "events.jsonl") for p in ("static", "drift")}
    # Require two terminal streams before opening any retrospective target labels.
    if any(not e or e[-1]["event"] != "run_completed" for e in events.values()):
        raise ValueError("Both runs must be completed before retrospective scoring")
    manifest, files = _manifest(package)
    ids, y, units, cycles, offsets, cap = _targets(package, manifest, files)
    predictions, versions, timelines = {}, {}, {}
    for policy in events:
        predictions[policy], versions[policy], timelines[policy] = _read_predictions(
            pair, policy, ids, offsets, events[policy])
    post = np.repeat(np.asarray(versions["drift"]) > 0, np.diff(offsets))
    full = {p: _metrics(y, predicted) for p, predicted in predictions.items()}
    after = {"drift": _metrics(y[post], predictions["drift"][post]),
             "static_same_samples": _metrics(y[post], predictions["static"][post])}
    checks = {"deployment_with_subsequent_predictions": bool(timelines["drift"] and np.any(post)),
              "full_stream_rmse_strictly_below_static": full["drift"]["rmse"] < full["static"]["rmse"],
              "post_deployment_rmse_strictly_below_static": bool(np.any(post) and
                  after["drift"]["rmse"] < after["static_same_samples"]["rmse"])}
    rows = []
    for step, (start, stop) in enumerate(zip(offsets[:-1], offsets[1:])):
        row = _group(y, predictions, slice(start, stop), step=step, samples=int(stop-start),
                     unit_ids=",".join(map(str, np.unique(units[start:stop]))),
                     post_deployment=bool(versions["drift"][step] > 0))
        for p in predictions:
            row[f"{p}_cumulative_rmse"] = _metrics(y[:stop], predictions[p][:stop])["rmse"]
            row[f"{p}_model_version"] = versions[p][step]
        rows.append(row)
    engines = [_group(y, predictions, units == unit, unit_id=int(unit)) for unit in np.unique(units)]
    stages = [_group(y, predictions, mask, stage=name) for name, mask in (
        ("RUL<=30", y <= 30), (f"30<RUL<{cap:g}", (y > 30) & (y < cap)), (f"RUL={cap:g}", y == cap))]
    counts = Counter(e["event"] for e in events["drift"])
    assessment = {"dataset": "cmapss_fd001", "target_unit": "cycles", "full_stream": full,
        "post_deployment": after, "positive_condition": {"passed": all(checks.values()), **checks},
        "actual_prediction_versions": versions, "by_engine": engines, "by_rul_stage": stages,
        "events": {"deployments": len(timelines["drift"]), "counts": dict(counts)},
        "deployment_timeline": timelines["drift"],
        "source": {"package_manifest": fingerprint(package / "manifest.json"),
                   "saved_runs": {p: [fingerprint(pair / p / name) for name in
                       ("events.jsonl", "predictions.npz")] for p in predictions},
                   "scoring_implementation": fingerprint(Path(__file__).resolve())},
        "limitations": ["Public development-unit partitions, not hidden-test acceptance.",
                        "Batch boundaries are unchanged and can span engine boundaries.",
                        "Mock decisions do not test a real LLM or Prompt effect."]}
    output.mkdir(parents=True, exist_ok=False)
    write_json(output / "assessment.json", assessment)
    write_json(output / "events.json", events)
    for name, values in (("batch", rows), ("engine", engines), ("stage", stages)):
        _csv(output / f"{name}_metrics.csv", values)
    (output / "curves.svg").write_text(_svg(rows, engines, timelines["drift"]), encoding="utf-8")
    lines = ["# C-MAPSS FD001 Tree Harness assessment", "",
        f"Full stream: static RMSE **{full['static']['rmse']:.10f}**, Mock Harness **{full['drift']['rmse']:.10f}** cycles; {len(y)} samples, {len(engines)} engines.", "",
        f"Actual deployments: {len(timelines['drift'])}; postdeployment samples: {int(np.sum(post))}.", "",
        f"Postdeployment RMSE: Harness {after['drift']['rmse']}; static on identical samples {after['static_same_samples']['rmse']}.", "",
        f"Preregistered positive condition: **{'PASS' if all(checks.values()) else 'FAIL'}**. All three conditions must pass; no retuning.", "",
        "| Condition | Passed |", "| --- | --- |", *[f"| {k} | {v} |" for k, v in checks.items()], "",
        "![RMSE curves](curves.svg)", "", "Scoring uses cumulative sample squared errors, not an average of batch RMSE. Actual versions come from prediction events; deploy(k) first affects k+1. Targets were read for scoring only after both runs completed.", "",
        "| RUL stage | Samples | Static RMSE | Harness RMSE |", "| --- | ---: | ---: | ---: |",
        *[f"| {r['stage']} | {r['static']['samples']} | {r['static']['rmse']} | {r['drift']['rmse']} |" for r in stages], "",
        "Raw events: events.json; per-batch, per-engine, per-stage metrics: corresponding CSVs; exact checks and source fingerprints: assessment.json.", "",
        *assessment["limitations"]]
    (output / "report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return assessment


def run_cmapss_pair(package_dir, output_dir, config):
    package, output = Path(package_dir), Path(output_dir)
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite FD001 experiment: {output}")
    if (config.task != "regression" or config.model_type != "tree" or not config.harness_enabled
            or config.harness_backend != "mock" or not config.harness_drift_only
            or config.selection_split != "recent_disjoint" or config.deployment_validation != "future"):
        raise ValueError("FD001 pair requires the explicit Mock Tree independent-future configuration")
    manifest, files = _manifest(package)
    mapping = ColumnMapping(**manifest["column_mapping"])

    def provider():
        return PreparedDataProvider(files["stream"], mapping, initial_train_path=files["train"],
            initial_validation_path=files["validation"], label_delay=config.label_delay, max_labels=None)

    first = provider()
    if (first.n_features != config.n_features or len(first.batch_sizes) != config.n_batches
            or max(first.batch_sizes) > config.batch_size
            or manifest["splits"]["train"]["rows"] != config.initial_train
            or manifest["splits"]["validation"]["rows"] != config.initial_validation):
        raise ValueError("Prepared dimensions must match frozen FD001 configuration")
    output.mkdir(parents=True, exist_ok=False)
    write_json(output / "config.json", config.to_dict())
    write_json(output / "provenance.json", {**source_metadata(),
        "package_manifest": fingerprint(package / "manifest.json"),
        "effective_config": fingerprint(output / "config.json"),
        "implementation": fingerprint(Path(__file__).resolve()),
        "batch_sizes": list(first.batch_sizes), "real_llm_tokens": 0})
    summaries = {}
    for policy, online in (("static", first), ("drift", provider())):
        with BoundedTrainer() as trainer:
            summaries[policy] = run_policy(config, policy, output / policy, trainer, provider=online)
    assessment = build_report(output, package, output / "report")
    result = {**assessment, "online_summaries": summaries}
    write_json(output / "comparison.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--config", type=Path, default=Path("configs/cmapss-harness-tree.json"))
    args = parser.parse_args()
    result = run_cmapss_pair(args.package, args.output, ExperimentConfig.load(args.config))
    print(json.dumps({key: result[key] for key in ("full_stream", "post_deployment", "positive_condition", "events")},
                     ensure_ascii=False, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
