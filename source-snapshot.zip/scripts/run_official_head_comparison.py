"""Preregistered CPU-C three-arm public-development comparison; no paid API."""

import argparse
import hashlib
import io
import json
import os
from pathlib import Path

import numpy as np

from ite.official_model import OfficialModelAdapter
from ite.official_sft_data import DRIFT, NOTICE, SCENARIOS, load_public_package, metrics, split_sources
from ite.official_sft_replay import replay_partition
from ite.tracking import source_metadata, write_json


ARMS = ("static", "head_only", "head_calibrated")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def case_plan():
    return [{"profile": "C", "scenario": scenario, "split": split, "arm": arm, "decision_steps": (7,)}
            for scenario in SCENARIOS for split in ("train", "eval") for arm in ARMS]


def loss_policy(arm):
    if arm == "head_only":
        return "squared"
    if arm == "head_calibrated":
        return "squared"
    if arm == "static":
        return None
    raise ValueError("Unknown registered arm")


def fixed_decision(arm):
    action = {"static": "DO_NOTHING", "head_only": "RETRAIN_HEAD_ONLY",
              "head_calibrated": "CALIBRATE_DOWN"}[arm]
    return lambda _: {"action": action, "reason": "预登记固定时点的配对训练策略对照，非Teacher标签。",
                      "source": "fixed_comparison"}


def summarize_paired(predictions, scenario):
    if set(predictions) != set(ARMS) or scenario not in SCENARIOS:
        raise ValueError("Three frozen arms and a registered scenario are required")
    reference = predictions["static"]
    ids = np.asarray(reference["source_ids"])
    if ids.ndim != 1 or len(set(ids.tolist())) != len(ids):
        raise ValueError("Paired source IDs must be unique")
    for arm in ARMS:
        row = predictions[arm]
        for key in ("source_ids", "targets", "static"):
            if not np.array_equal(row[key], reference[key]):
                raise ValueError(f"Unpaired {arm} {key}")
    if not np.array_equal(reference["active"], reference["static"]):
        raise ValueError("Static arm must retain the original checkpoint")
    scores = {arm: metrics("C", row["targets"], row["active"]) for arm, row in predictions.items()}
    before = scores["static"]
    passes = {arm: ((scores[arm]["rmse"] <= before["rmse"] if scenario == "stable" else
                     scores[arm]["rmse"] < before["rmse"]) and
                    all(scores[arm][key] <= before[key] for key in ("overestimate_rate", "mean_overestimate")) and
                    (scenario == "stable" or arm != "head_calibrated" or scores[arm]["overestimate_rate"] < .1652))
              for arm in ("head_only", "head_calibrated")}
    return {"metrics": scores, "passes": passes}


def _audit_candidate(parent, path, policy):
    with np.load(io.BytesIO(parent.checkpoint_bytes), allow_pickle=False) as cp:
        original = {key: cp[key].copy() for key in cp.files}
    with np.load(path, allow_pickle=False) as cp:
        candidate = {key: cp[key].copy() for key in cp.files}
    old, new = (json.loads(state["metadata"].item()) for state in (original, candidate))
    unchanged = {key: original[key].tobytes() == candidate[key].tobytes() for key in (
        "w1", "b1", "adam_first_w1", "adam_first_b1", "adam_second_w1", "adam_second_b1", "mean", "scale")}
    if (not all(unchanged[key] for key in ("mean", "scale")) or
            any(new[key] != old[key] for key in ("learning_rate", "target_mean", "target_scale", "batch_size")) or
            new["steps"] != old["steps"] + 15 or new["epochs"] != old["epochs"] + 5 or
            (policy in ("head_only", "head_calibrated") and not all(unchanged.values()))):
        raise ValueError("Candidate violates the frozen resume/parameter contract")
    return {"candidate_sha256": digest(path), "unchanged_arrays": unchanged,
            "parent_steps": old["steps"], "candidate_steps": new["steps"],
            "parent_epochs": old["epochs"], "candidate_epochs": new["epochs"],
            "learning_rate": new["learning_rate"],
            "max_parameter_delta": {key: float(np.max(np.abs(candidate[key]-original[key])))
                                    for key in ("w1", "b1", "w2", "b2")}}


def run_comparison(output, runtime_python):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    data = load_public_package("C")
    partitions = split_sources(data)
    parent = OfficialModelAdapter("regression", runtime_python, profile_type="C", candidate_epochs=5)
    parent.save(output/"initial.npz")
    write_json(output/"freeze.json", {"notice": NOTICE, "source": source_metadata(),
        "runner_sha256": digest(__file__), "package_sha256": data["package_sha256"],
        "initial_checkpoint_sha256": parent.checkpoint_sha256, "feature_paths": data["feature_paths"],
        "partition_rule": partitions["rule"], "partitions": {
            split: {"rows": len(partitions[split]), "source_ids": [data["ids"][i] for i in partitions[split]]}
            for split in ("train", "eval")}, "cases": case_plan(), "drift": DRIFT,
        "candidate_epochs": 5, "candidate_timeout_seconds": 5, "total_train_seconds_per_flow": 20,
        "window_including_screening": 768, "screening_rows": 48, "label_delay": 1,
        "arm_loss_policies": {arm: loss_policy(arm) for arm in ARMS},
        "calibration": {"profile": "C", "samples": 48, "quantile": .9,
            "source": "immediately preceding source batch before the 768-row train/screen window",
            "margin": "max(0, empirical_p90(candidate_raw_prediction - released_target))",
            "prediction": "max(0, raw - margin)", "independent_future_mse_gate": True},
        "paid_calls": 0, "acceptance": "stable nonworse; drift RMSE lower and both overestimation metrics no worse than paired static; calibrated overestimate rate strictly below 16.52% per partition",
        "data_role": "previously_seen_public_development_only"})
    summaries, arrays = {}, {}
    for case in case_plan():
        scenario, split, arm = (case[key] for key in ("scenario", "split", "arm"))
        name = f"C-{scenario}-{split}-{arm}"
        root = output/name
        model = OfficialModelAdapter.from_state(parent.state())
        result = replay_partition(data, partitions[split], split, scenario, root, model, fixed_decision(arm),
            decision_steps=(7,), action_profile="official_c_calibration",
            candidate_loss_policy=loss_policy(arm) or "squared")
        audit = None
        if (root/"candidate-step7.npz").is_file():
            audit = _audit_candidate(parent, root/"candidate-step7.npz", arm)
        with np.load(root/"predictions.npz", allow_pickle=False) as values:
            arrays[scenario, split, arm] = {key: values[key].copy() for key in values.files}
        summaries[name] = {"case": case, "summary": result, "checkpoint_audit": audit,
            "evidence_sha256": {file: digest(root/file) for file in ("events.jsonl", "predictions.npz", "summary.json")}}
        print(f"{name}: RMSE={result['active_metrics']['rmse']:.9f}; over={result['active_metrics']['overestimate_rate']:.9f}; "
              f"deploys={result['updates']}; training={result['train_seconds']:.6f}s", flush=True)
    groups = {}
    for scenario in SCENARIOS:
        for split in ("train", "eval", "merged"):
            rows = {arm: arrays[scenario, split, arm] for arm in ARMS} if split != "merged" else {
                arm: {key: np.concatenate([arrays[scenario, part, arm][key] for part in ("train", "eval")])
                      for key in ("targets", "source_ids", "static", "active")} for arm in ARMS}
            groups[f"{scenario}-{split}"] = summarize_paired(rows, scenario)
    errors = [name for name, row in summaries.items() if any(
        record["rejection"] in ("candidate_training_error", "training_over_budget", "candidate_calibration_error",
            "insufficient_independent_calibration_window") for record in row["summary"]["records"])]
    result = {"notice": NOTICE, "development_only": True, "paid_calls": 0,
        "engineering_passed": not errors, "engineering_errors": errors, "physical_flows": len(summaries),
        "groups": groups, "flows": summaries, "freeze_sha256": digest(output/"freeze.json"),
        "all_partition_criteria_pass": {arm: all(groups[f"{scenario}-{split}"]["passes"][arm]
            for scenario in SCENARIOS for split in ("train", "eval")) for arm in ("head_only", "head_calibrated")}}
    write_json(output/"comparison.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--official-python", default=os.environ.get("ITE_OFFICIAL_RUNTIME_PYTHON",
        str(Path(__file__).resolve().parents[1]/".venv-official-a/Scripts/python.exe")))
    args = parser.parse_args()
    result = run_comparison(args.output, args.official_python)
    print(json.dumps({"engineering_passed": result["engineering_passed"],
                      "all_partition_criteria_pass": result["all_partition_criteria_pass"]}))
    return 0 if result["engineering_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
