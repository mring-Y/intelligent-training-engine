"""One fixed static/Mock pair on the nine original future UCI Gas batches."""

import argparse
import json
from pathlib import Path

import numpy as np
import pyarrow.parquet as pq

from ite.config import ExperimentConfig
from ite.providers import ColumnMapping
from ite.runner import run_policy
from ite.tracking import source_metadata
from ite.training import BoundedTrainer
from scripts.data_prep.baseline import _metrics, _verified_files
from scripts.data_prep.common import fingerprint, write_json
from scripts.data_prep.provider import PreparedDataProvider


class GasOfflineScorer:
    """Runner calls this only after finish; no evaluator is passed to Controller.

    Construction stores public paths and batch sizes, without reading targets.
    Every scoring read checks the original manifest fingerprints first.
    """

    def __init__(self, package, manifest, batch_sizes):
        self.package, self.manifest = Path(package), manifest
        self.batch_sizes = tuple(batch_sizes)
        self._targets = None

    def _read_targets(self):
        files = _verified_files(self.package, self.manifest)
        mapping = self.manifest["column_mapping"]
        ids, steps, targets = [], [], []
        parquet = pq.ParquetFile(files["stream"])
        try:
            for batch in parquet.iter_batches(columns=[mapping["sample_id"], mapping["batch"],
                                                       mapping["target"]], use_threads=False):
                rows = batch.to_pydict()
                ids.extend(rows[mapping["sample_id"]])
                steps.extend(rows[mapping["batch"]])
                targets.extend(rows[mapping["target"]])
        finally:
            parquet.close()
        expected = np.repeat(np.arange(len(self.batch_sizes)), self.batch_sizes)
        targets = np.asarray(targets)
        if (not np.array_equal(steps, expected) or len(ids) != len(set(ids))
                or not np.isin(targets, np.arange(1, 7)).all()):
            raise ValueError("Retrospective targets do not match the public Gas boundaries/classes")
        offsets = np.cumsum([0, *self.batch_sizes])
        self.sample_ids = np.asarray(ids)
        self._targets = [targets[a:b] for a, b in zip(offsets[:-1], offsets[1:])]

    def score(self, predictions):
        if (len(predictions) != len(self.batch_sizes) or any(
                np.shape(p) != (n,) or not np.isin(p, np.arange(1, 7)).all()
                for p, n in zip(predictions, self.batch_sizes))):
            raise ValueError("Scoring needs one valid six-class prediction vector per public batch")
        if self._targets is None:
            self._read_targets()
        return [float(np.mean(y != p)) for y, p in zip(self._targets, predictions)]

    def classification_counts(self, predictions):
        self.score(predictions)
        y, predicted = np.concatenate(self._targets), np.concatenate(predictions)
        metrics = _metrics("multiclass", y, predicted, classes=np.arange(1, 7))
        return {"samples": len(y), "correct": int(np.sum(y == predicted)),
                "sample_weighted_accuracy": metrics["accuracy"],
                "classes": metrics["classes"], "confusion_matrix": metrics["confusion_matrix"]}


def run_gas_pair(package_dir, output_dir, config):
    package, output = Path(package_dir), Path(output_dir)
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite Gas experiment: {output}")
    tree_multiclass = (config.model_type == "tree" and config.model_family == "ridge"
                       and config.class_labels == (1, 2, 3, 4, 5, 6))
    ovr_multiclass = config.model_type == "ridge" and config.model_family == "ovr_ridge"
    if (config.task != "classification" or not (tree_multiclass or ovr_multiclass)
            or config.harness_backend != "mock" or not config.harness_enabled
            or not config.harness_drift_only or config.n_batches != 9):
        raise ValueError("Gas pair requires the explicit nine-batch Mock six-class configuration")
    manifest = json.loads((package / "manifest.json").read_text(encoding="utf-8"))
    if (manifest["dataset"] != "uci_gas" or manifest["task"] != "multiclass"
            or manifest["metadata"].get("classes") != list(range(1, 7))
            or manifest["metadata"].get("stream_source_batches") != list(range(2, 11))):
        raise ValueError("Gas pair requires the unchanged six-class, nine-source-batch package")
    files = _verified_files(package, manifest)
    mapping = ColumnMapping(**manifest["column_mapping"])

    def provider():
        return PreparedDataProvider(files["stream"], mapping,
            initial_train_path=files["train"], initial_validation_path=files["validation"],
            label_delay=config.label_delay, max_labels=None)

    first = provider()
    if (first.n_features != config.n_features or len(first.batch_sizes) != config.n_batches
            or max(first.batch_sizes) > config.batch_size
            or manifest["splits"]["train"]["rows"] != config.initial_train
            or manifest["splits"]["validation"]["rows"] != config.initial_validation):
        raise ValueError("Prepared dimensions and initial counts must match the frozen config")
    output.mkdir(parents=True, exist_ok=False)
    write_json(output / "config.json", config.to_dict())
    write_json(output / "provenance.json", {**source_metadata(),
        "package_manifest": fingerprint(package / "manifest.json"),
        "effective_config": fingerprint(output / "config.json"),
        "implementation": [fingerprint(Path(__file__).resolve()),
            *[fingerprint(Path(__file__).parent / "data_prep" / name)
              for name in ("provider.py", "baseline.py", "common.py")]],
        "source_batches": manifest["metadata"]["stream_source_batches"],
        "batch_sizes": list(first.batch_sizes), "real_llm_tokens": 0})
    result = {}
    for policy, online in (("static", first), ("drift", provider())):
        # Each adaptive policy starts with its own cold process and data gateway.
        with BoundedTrainer() as trainer:
            result[policy] = run_policy(config, policy, output / policy, trainer, provider=online,
                offline_scorer=GasOfflineScorer(package, manifest, online.batch_sizes))
    write_json(output / "comparison.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--config", type=Path, default=Path("configs/gas-harness-mock.json"))
    args = parser.parse_args()
    result = run_gas_pair(args.package, args.output, ExperimentConfig.load(args.config))
    print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
