"""Reproduce preregistered development, acceptance, and stress matrices offline."""

import argparse
import csv
import json
from pathlib import Path

from ite.cli import main
from ite.config import ExperimentConfig
from ite.tracking import source_metadata, write_json
from ite.validation import assess_deployment

DEVELOPMENT_SEEDS = (7, 19, 43)
ACCEPTANCE_SEEDS = (211, 223, 227, 229, 233)
TASKS = ("classification", "regression")
SCENARIOS = ("stable", "abrupt", "gradual", "recurring", "covariate", "noise")
VARIANTS = {
    "legacy": {"deployment_validation": "legacy", "monitor_min_labeled": None},
    "future-frontloaded": {},
    "uniform": {"label_schedule": "uniform"},
    "adaptive": {"label_schedule": "adaptive"},
    "uniform-governed": {"label_schedule": "uniform", "candidate_feasibility": True,
                         "candidate_max_wait_batches": 8},
    "adaptive-governed": {"label_schedule": "adaptive", "candidate_feasibility": True,
                          "candidate_max_wait_batches": 8},
    "uniform-reuse": {"label_schedule": "uniform", "candidate_feasibility": True,
                      "candidate_max_wait_batches": 8, "reuse_history": True},
    "adaptive-reuse": {"label_schedule": "adaptive", "candidate_feasibility": True,
                       "candidate_max_wait_batches": 8, "reuse_history": True},
}


def config_for(name, **changes):
    return ExperimentConfig.from_dict({"n_batches": 96, "monitor_min_labeled": 32,
        "deployment_validation": "future", **VARIANTS[name], **changes})


def matrix(root, name, config, seeds, policies, scenarios=SCENARIOS):
    config_path = root / f"{name}.json"
    write_json(config_path, config.to_dict())
    code = main(["matrix", "--config", str(config_path), "--output", str(root / name),
        "--tasks", *TASKS, "--scenarios", *scenarios,
        "--seeds", *map(str, seeds), "--policies", *policies])
    if code:
        raise RuntimeError(f"Matrix {name} failed: {code}")


def read_rows(path):
    with Path(path).open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def summarize(root):
    baseline = read_rows(root / "legacy/summary.csv")
    def mean(rows, task, scenario, policy="drift"):
        values = [float(r["mean_loss"]) for r in rows if
                  (r["task"], r["scenario"], r["policy"]) == (task, scenario, policy)]
        return sum(values) / len(values)
    results = []
    for name in VARIANTS:
        if name == "legacy":
            continue
        rows = read_rows(root / name / "summary.csv")
        failures, recurring_delta, groups = [], [], []
        for task in TASKS:
            tolerance = .005 if task == "classification" else .01
            for scenario in SCENARIOS:
                loss, previous = mean(rows, task, scenario), mean(baseline, task, scenario)
                static = mean(baseline, task, scenario, "static")
                passed = loss <= (static if scenario == "recurring" else previous + tolerance) + 1e-12
                groups.append({"task": task, "scenario": scenario, "loss": loss,
                               "legacy_loss": previous, "static_loss": static, "passed": passed})
                if not passed:
                    failures.append(f"{task}/{scenario}")
                if scenario == "recurring":
                    recurring_delta.append(loss - static)
        results.append({"variant": name, "passed": not failures, "failures": failures,
                        "worst_recurring_delta": max(recurring_delta), "groups": groups,
                        "max_candidate_wait": max(float(r["candidate_wait_max_batches"]) for r in rows),
                        "history_reuses": sum(int(r["history_reuses"]) for r in rows),
                        "labels_requested": sorted({int(r["labels_requested"]) for r in rows})})
    eligible = [r for r in results if r["passed"]]
    # Prespecified fallback: fewest failed conditions, then worst recurring delta;
    # insertion order breaks exact ties in favor of simpler variants.
    winner = min(eligible or results, key=lambda r: (len(r["failures"]), r["worst_recurring_delta"]))
    result = {"development_seeds": list(DEVELOPMENT_SEEDS), "acceptance_seeds": list(ACCEPTANCE_SEEDS),
              "selected_variant": winner["variant"], "development_passed": winner["passed"],
              "selection_rule": "eligible first; failure count, worst recurring delta, simplicity",
              "variants": results, **source_metadata()}
    write_json(root / "selection.json", result)
    return result


def main_script():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=("development", "acceptance", "stress"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--variant", choices=tuple(VARIANTS)[1:])
    args = parser.parse_args()
    if args.output.exists() and any(args.output.iterdir()):
        raise FileExistsError(args.output)
    args.output.mkdir(parents=True, exist_ok=True)
    if args.stage == "development":
        for name in VARIANTS:
            matrix(args.output, name, config_for(name), DEVELOPMENT_SEEDS,
                   ("static", "periodic", "drift") if name == "legacy" else ("drift",))
        summarize(args.output)
    elif args.stage == "acceptance":
        if not args.variant:
            parser.error("--variant is required after development configuration freeze")
        for name, policies in (("legacy", ("static", "periodic", "drift")),
                               ("future-frontloaded", ("drift",)),
                               (args.variant, ("static", "periodic", "drift"))):
            matrix(args.output, name, config_for(name), ACCEPTANCE_SEEDS, policies)
        result = assess_deployment(args.output / "legacy/summary.csv",
            args.output / args.variant / "summary.csv", seeds=ACCEPTANCE_SEEDS)
        write_json(args.output / "assessment.json", result)
    else:
        if not args.variant:
            parser.error("--variant is required for stress tests")
        for name, changes in {"delay-6": {"label_delay": 6},
                              "labels-10pct": {"label_fraction": .1},
                              "period-4": {"drift_width": 4},
                              "period-16": {"drift_width": 16}}.items():
            matrix(args.output, name, config_for(args.variant, **changes), ACCEPTANCE_SEEDS,
                   ("static", "drift"), ("recurring",))
    write_json(args.output / "provenance.json", {"stage": args.stage, "variant": args.variant,
                                                **source_metadata()})


if __name__ == "__main__":
    main_script()
