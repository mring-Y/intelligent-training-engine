"""Compare the same official A replay candidate at decision steps 3 and 7."""

import argparse
import hashlib
import json
import os
from pathlib import Path

import numpy as np

from ite.official_model import OFFICIAL_PROFILES, OfficialModelAdapter
from ite.official_sft_data import DRIFT, NOTICE, SCENARIOS, load_public_package, metrics, split_sources
from ite.official_sft_replay import replay_partition
from ite.tracking import source_metadata, write_json


ROOT = Path(__file__).resolve().parents[1]
ARMS = ("static", "replay_step3", "replay_step7")
DECISION_STEPS = {"static": (), "replay_step3": (3,), "replay_step7": (7,)}
EXPECTED_SCREENING_SAMPLES = {
    "train": {3: 48, 7: 48},
    "eval": {3: 18, 7: 41},
}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def case_plan():
    return [{"scenario": scenario, "split": split, "arm": arm,
             "decision_steps": DECISION_STEPS[arm],
             "expected_screening_samples": (0 if arm == "static" else
                 EXPECTED_SCREENING_SAMPLES[split][DECISION_STEPS[arm][0]])}
            for scenario in SCENARIOS for split in ("train", "eval") for arm in ARMS]


def _case_for(scenario, split, arm):
    matches = [case for case in case_plan()
               if case["scenario"] == scenario and case["split"] == split and case["arm"] == arm]
    if len(matches) != 1:
        raise ValueError("Unknown registered A replay timing case")
    return matches[0]


def _fixed_decision(arm):
    if arm not in ARMS:
        raise ValueError("Unknown registered A replay timing arm")
    action = "DO_NOTHING" if arm == "static" else "RETRAIN_LARGE"
    return lambda _: {"action": action,
                      "reason": "固定回放策略，仅对比公开流候选决策时点，不是Teacher标签。",
                      "source": "fixed_timing_comparison"}


def summarize_a_timing_paired(predictions, scenario):
    if set(predictions) != set(ARMS) or scenario not in SCENARIOS:
        raise ValueError("Static and both registered timing arms are required")
    reference = predictions["static"]
    ids = np.asarray(reference["source_ids"])
    if ids.ndim != 1 or not len(ids) or len(set(ids.tolist())) != len(ids):
        raise ValueError("Paired A source IDs must be unique and nonempty")
    for arm in ARMS:
        row = predictions[arm]
        for key in ("source_ids", "targets", "static"):
            if not np.array_equal(row[key], reference[key]):
                raise ValueError(f"Unpaired {arm} {key}")
    if not np.array_equal(reference["active"], reference["static"]):
        raise ValueError("Static arm must retain the original checkpoint")
    scores = {arm: metrics("A", row["targets"], row["active"])
              for arm, row in predictions.items()}
    baseline = scores["static"]
    passes = {arm: ((scores[arm]["macro_f1"] >= baseline["macro_f1"] if scenario == "stable" else
                     scores[arm]["macro_f1"] > baseline["macro_f1"]) and
                    scores[arm]["accuracy"] >= baseline["accuracy"])
              for arm in ARMS if arm != "static"}
    return {"metrics": scores, "passes": passes}


def _engineering_ok(arm, summary, events, expected_screening_samples):
    candidates = [event for event in events if event["event"] == "candidate_evaluated"]
    predictions = [event for event in events if event["event"] == "prediction"]
    if (arm not in ARMS or len(predictions) != 12 or
            any(event["event"] == "training_failed" for event in events) or
            summary["train_seconds"] > 20.):
        return False
    if arm == "static":
        return (not candidates and summary["training_attempts"] == 0 and
                summary["updates"] == 0 and expected_screening_samples == 0)
    if len(candidates) != 1 or summary["training_attempts"] != 1:
        return False
    candidate = candidates[0]
    expected_step = DECISION_STEPS[arm][0]
    screening_ids = candidate.get("screening_source_ids", [])
    train_ids = candidate.get("train_source_ids", [])
    online_ids = candidate.get("online_train_source_ids", [])
    replay_ids = candidate.get("replay_source_ids", [])
    replaced_ids = candidate.get("replaced_online_source_ids", [])
    screening_samples = candidate.get("screening_samples", 0)
    if (candidate.get("step") != expected_step or
            candidate.get("candidate_adam_steps", 0) <= candidate.get("parent_adam_steps", 0) or
            not 0 < candidate.get("train_seconds", 0) <= 5. or
            candidate.get("train_samples") != len(train_ids) or
            len(online_ids) != candidate.get("train_samples") or
            screening_samples != expected_screening_samples or
            screening_samples != len(screening_ids) or not 0 < screening_samples <= 48 or
            len(set(screening_ids)) != screening_samples or
            len(replay_ids) != 48 or len(set(replay_ids)) != 48 or
            len(replaced_ids) != 48 or len(set(replaced_ids)) != 48 or
            replaced_ids != online_ids[:48] or
            train_ids != replay_ids + online_ids[48:] or
            len(set(online_ids)) != len(online_ids) or
            len(set(train_ids)) != len(train_ids) or
            len(train_ids) != candidate.get("train_samples") or
            set(train_ids) & set(screening_ids) or
            set(replay_ids) & set(screening_ids) or
            set(replay_ids) & set(online_ids)):
        return False
    candidates_by_id = {candidate["decision_id"]: candidate}
    for event in events:
        if event["event"] not in ("deploy", "experiment_rejected") or event.get("reason") != "independent_future_labels":
            continue
        frozen = candidates_by_id.get(event.get("decision_id"))
        future_ids = event.get("source_ids", [])
        if (frozen is None or not future_ids or
                event.get("gate_min_source_step", -1) <= frozen["step"] or
                event.get("candidate_replay_source_ids") != frozen["replay_source_ids"] or
                set(future_ids) & (set(frozen["train_source_ids"]) |
                                   set(frozen["screening_source_ids"]) |
                                   set(frozen["replay_source_ids"]))):
            return False
    return True


def run_comparison(output, runtime_python=None):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    runs = output / "runs"
    runs.mkdir()
    runtime_python = runtime_python or os.environ.get(
        "ITE_OFFICIAL_RUNTIME_PYTHON", ROOT / ".venv-official-a/Scripts/python.exe")
    data = load_public_package("A")
    partitions = split_sources(data)
    initial = OfficialModelAdapter(OFFICIAL_PROFILES["A"]["task"], runtime_python,
                                   profile_type="A", candidate_epochs=5)
    initial_state = initial.state()
    initial.save(output / "initial.npz")
    reserve = data["replay_reserve"]
    cases = case_plan()
    freeze = {"notice": NOTICE, "development_only": True, "source": source_metadata(),
        "runner_sha256": digest(__file__), "package_sha256": data["package_sha256"],
        "initial_checkpoint_sha256": initial.checkpoint_sha256,
        "reported_static_validation": data["reported_baseline"],
        "feature_paths": data["feature_paths"], "partition_rule": partitions["rule"],
        "partitions": {split: {"rows": len(partitions[split]),
            "source_ids": [data["ids"][index] for index in partitions[split]]}
            for split in ("train", "eval")},
        "replay_reserve": {"rows": len(reserve["ids"]), "class_counts": reserve["class_counts"],
            "selection_policy": reserve["selection_policy"], "source_ids": reserve["ids"],
            "source_ids_sha256": hashlib.sha256("\n".join(reserve["ids"]).encode()).hexdigest()},
        "drift": DRIFT, "scenarios": SCENARIOS, "cases": cases,
        "arms": {"static": "supplied checkpoint, no updates",
            "replay_step3": "one full resume with the existing 48-row class-balanced replay at step 3",
            "replay_step7": "same full resume and replay, delayed to step 7"},
        "only_changed_factor": "candidate decision step: 3 versus 7",
        "candidate_action": "RETRAIN_LARGE", "candidate_epochs": 5,
        "candidate_timeout_seconds": 5, "total_train_seconds_per_flow": 20,
        "maximum_attempts_per_flow": 4, "maximum_window_including_screening": 768,
        "screening_rule": "existing min(48, max(4, released_rows // 4)); future gate remains independent",
        "screening_sample_counts": {"train_step3": 48, "eval_step3": 18,
                                     "train_step7": 48, "eval_step7": 41},
        "paid_calls": 0, "llm_tokens": 0,
        "acceptance": "stable Macro-F1 and Accuracy no worse than static; drift Macro-F1 strictly higher and Accuracy no worse, per train/eval partition",
        "data_role": "previously_seen_public_development_only"}
    write_json(output / "freeze.json", freeze)

    summaries, arrays, costs, engineering_errors = {}, {}, {}, []
    for case in cases:
        scenario, split, arm = (case[key] for key in ("scenario", "split", "arm"))
        name = f"A-{scenario}-{split}-{arm}"
        path = runs / name
        model = OfficialModelAdapter.from_state(initial_state)
        replay_policy = "class_balanced_official_train" if arm != "static" else "none"
        result = replay_partition(data, partitions[split], split, scenario, path, model,
            _fixed_decision(arm), decision_steps=case["decision_steps"],
            a_replay_policy=replay_policy)
        events = [json.loads(line) for line in
                  (path / "events.jsonl").read_text(encoding="utf-8").splitlines()]
        with np.load(path / "predictions.npz", allow_pickle=False) as values:
            arrays[scenario, split, arm] = {key: values[key].copy() for key in values.files}
        label_rows = sum(event["samples"] for event in events if event["event"] == "labels_released")
        costs[name] = {"training_attempts": result["training_attempts"],
            "train_seconds": result["train_seconds"], "released_label_rows": label_rows,
            "llm_tokens": 0, "paid_calls": 0}
        if not _engineering_ok(arm, result, events, case["expected_screening_samples"]):
            engineering_errors.append(name)
        candidate_events = [event for event in events if event["event"] == "candidate_evaluated"]
        summaries[name] = {"case": case, "summary": result, "costs": costs[name],
            "screening_samples": [event["screening_samples"] for event in candidate_events],
            "candidate_steps": [event["step"] for event in candidate_events],
            "evidence_sha256": {file: digest(path / file)
                for file in ("events.jsonl", "predictions.npz", "summary.json")}}
        print(f"{name}: Macro-F1={result['active_metrics']['macro_f1']:.9f}; "
              f"Accuracy={result['active_metrics']['accuracy']:.9f}; "
              f"screen={summaries[name]['screening_samples']}; "
              f"deploys={result['updates']}; training={result['train_seconds']:.6f}s", flush=True)

    groups = {}
    for scenario in SCENARIOS:
        for split in ("train", "eval"):
            predictions = {arm: arrays[scenario, split, arm] for arm in ARMS}
            groups[f"{scenario}-{split}"] = summarize_a_timing_paired(predictions, scenario)
    result = {"notice": NOTICE, "development_only": True, "paid_calls": 0, "llm_tokens": 0,
        "engineering_passed": not engineering_errors, "engineering_errors": engineering_errors,
        "physical_flows": len(summaries), "groups": groups, "flows": summaries, "costs": costs,
        "freeze_sha256": digest(output / "freeze.json"),
        "all_partition_criteria_pass": {arm: all(
            groups[f"{scenario}-{split}"]["passes"][arm]
            for scenario in SCENARIOS for split in ("train", "eval"))
            for arm in ARMS if arm != "static"}}
    write_json(output / "comparison.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--official-python", default=os.environ.get("ITE_OFFICIAL_RUNTIME_PYTHON",
        str(ROOT / ".venv-official-a/Scripts/python.exe")))
    args = parser.parse_args()
    result = run_comparison(args.output, args.official_python)
    print(json.dumps({"engineering_passed": result["engineering_passed"],
        "all_partition_criteria_pass": result["all_partition_criteria_pass"]}))
    return 0 if result["engineering_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
