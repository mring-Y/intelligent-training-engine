"""Read-only retrospective Gas scoring from completed prediction/event archives.

No provider, trainer, controller or policy is run by this module. Public target
labels are read only here, after the paired runs have saved their predictions.
"""

import argparse
import csv
import json
from collections import Counter, defaultdict
from html import escape
from pathlib import Path

import numpy as np
import pyarrow.parquet as pq

from scripts.data_prep.baseline import _verified_files
from scripts.data_prep.common import fingerprint, write_json


def _integer(value):
    return type(value) is int


def _class_vector(values, name):
    values = np.asarray(values)
    if (values.ndim != 1 or values.dtype.kind not in "iuf" or not np.isfinite(values).all()
            or not np.isin(values, np.arange(1, 7)).all()):
        raise ValueError(f"{name} must contain finite Gas class IDs 1..6")
    return values


def _read_package(package):
    manifest = json.loads((package / "manifest.json").read_text(encoding="utf-8"))
    metadata = manifest.get("metadata", {})
    source_batches = metadata.get("stream_source_batches", [])
    if (manifest.get("dataset") != "uci_gas" or manifest.get("task") != "multiclass"
            or metadata.get("classes") != list(range(1, 7)) or not source_batches
            or source_batches != list(range(2, len(source_batches) + 2)) or len(source_batches) > 9):
        raise ValueError("Report needs the original ordered six-class Gas package")
    files = _verified_files(package, manifest)
    mapping = manifest["column_mapping"]
    columns = [mapping[name] for name in ("sample_id", "batch", "target")]
    parquet = pq.ParquetFile(files["stream"])
    rows = {name: [] for name in columns}
    try:
        if "source_batch" in parquet.schema_arrow.names:
            columns.append("source_batch")
            rows["source_batch"] = []
        for batch in parquet.iter_batches(columns=columns, use_threads=False):
            for name, values in batch.to_pydict().items():
                rows[name].extend(values)
    finally:
        parquet.close()
    ids, steps = np.asarray(rows[mapping["sample_id"]]), np.asarray(rows[mapping["batch"]])
    targets = _class_vector(rows[mapping["target"]], "Targets")
    if (ids.ndim != 1 or ids.dtype.kind not in "iu" or len(set(ids.tolist())) != len(ids)
            or steps.dtype.kind not in "iu" or len(ids) != len(targets) or not len(ids)):
        raise ValueError("Gas source IDs/steps must be unique integers aligned with targets")
    sizes = [int(np.count_nonzero(steps == step)) for step in range(len(source_batches))]
    if (any(size < 1 for size in sizes)
            or not np.array_equal(steps, np.repeat(np.arange(len(sizes)), sizes))):
        raise ValueError("Gas true rows do not match ordered original batch boundaries")
    if "source_batch" in rows and not np.array_equal(
            rows["source_batch"], np.repeat(source_batches, sizes)):
        raise ValueError("Gas source batch labels do not match original boundaries")
    declared = manifest["splits"]["stream"]
    if declared["rows"] != len(ids) or declared["batches"] != len(sizes):
        raise ValueError("Gas manifest counts do not match true rows")
    _verified_files(package, manifest)
    return manifest, files, ids, targets, np.cumsum([0, *sizes]), source_batches


def _reject_constant(value):
    raise ValueError(f"Non-finite JSON constant: {value}")


def _read_events(path):
    events = [json.loads(line, parse_constant=_reject_constant)
              for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if any(not isinstance(event, dict) or not isinstance(event.get("event"), str)
           or not _integer(event.get("step")) for event in events):
        raise ValueError("Events need an event name and integer step")
    return events


def _check_gate(event):
    names = ("frozen_at", "gate_min_source_step", "gate_max_source_step", "gate_samples")
    if (event.get("accepted") is not True or event.get("reason") != "independent_future_labels"
            or any(not _integer(event.get(name)) for name in names)):
        raise ValueError("Deployment requires complete accepted independent-future gate evidence")
    frozen, first, last, samples = (event[name] for name in names)
    if not (0 <= frozen < first <= last <= event["step"] and samples > 0):
        raise ValueError("Gate needs positive samples generated strictly after candidate freeze")


def _prediction_versions(events, sizes, policy):
    completed = [index for index, event in enumerate(events) if event["event"] == "run_completed"]
    if (any(event["event"] == "run_failed" for event in events) or len(completed) != 1
            or completed[0] != len(events) - 1 or events[completed[0]]["step"] != len(sizes)):
        raise ValueError("Report requires one terminal run_completed and no run_failed events")
    predictions, deployments, changed_steps = [], [], set()
    version = 0
    for event in events:
        step, kind = event["step"], event["event"]
        if not -1 <= step <= len(sizes):
            raise ValueError("Event step leaves the declared Gas stream")
        if kind == "prediction":
            if (step != len(predictions) or step >= len(sizes)
                    or not _integer(event.get("samples")) or event["samples"] != sizes[step]
                    or not _integer(event.get("model_version")) or event["model_version"] != version):
                raise ValueError("Prediction steps/counts/actual versions do not match the saved stream")
            predictions.append(event)
        elif kind in ("deploy", "rollback"):
            if (policy == "static" or not predictions or step != predictions[-1]["step"]
                    or step in changed_steps or not _integer(event.get("model_version"))
                    or event["model_version"] != version + 1):
                raise ValueError("Deployment must follow its same-batch prediction and increment the version")
            _check_gate(event)
            version = event["model_version"]
            changed_steps.add(step)
            deployments.append(event)
    if len(predictions) != len(sizes):
        raise ValueError("Each true batch needs exactly one prediction event")
    timeline = [{"deploy": event,
                 "first_next_prediction": predictions[event["step"] + 1]
                 if event["step"] + 1 < len(predictions) else None} for event in deployments]
    return [event["model_version"] for event in predictions], timeline


def _read_run(pair, policy, ids, offsets):
    directory = pair / policy
    path = directory / "predictions.npz"
    with np.load(path, allow_pickle=False) as saved:
        if not {"predictions", "sample_ids", "batch_offsets"}.issubset(saved.files):
            raise ValueError("Saved predictions require sample IDs and original batch offsets")
        predicted, saved_ids, saved_offsets = (saved[name].copy() for name in
                                              ("predictions", "sample_ids", "batch_offsets"))
    sizes = np.diff(offsets).tolist()
    if (saved_ids.ndim != 1 or saved_ids.dtype.kind not in "iu" or not np.array_equal(saved_ids, ids)
            or saved_offsets.ndim != 1 or saved_offsets.dtype.kind not in "iu"
            or not np.array_equal(saved_offsets, offsets)):
        raise ValueError("Saved IDs/offsets do not match true Gas rows")
    if predicted.ndim == 2:
        if len(set(sizes)) != 1 or predicted.shape != (len(sizes), sizes[0]):
            raise ValueError("Two-dimensional predictions must preserve every original batch")
        predicted = predicted.reshape(-1)
    predicted = _class_vector(predicted, "Predictions")
    if len(predicted) != len(ids):
        raise ValueError("Saved prediction count differs from true Gas rows")
    events = _read_events(directory / "events.jsonl")
    versions, timeline = _prediction_versions(events, sizes, policy)
    return predicted, events, versions, timeline


def _metrics(correct):
    samples, count = len(correct), int(np.count_nonzero(correct))
    return {"samples": samples, "correct": count, "errors": samples - count,
            "sample_weighted_accuracy": count / samples if samples else None,
            "zero_one_loss": (samples - count) / samples if samples else None}


def _batch_rows(targets, predictions, versions, offsets, source_batches):
    rows, cumulative = [], {policy: 0 for policy in predictions}
    for step, (start, stop) in enumerate(zip(offsets[:-1], offsets[1:])):
        samples = int(stop - start)
        row = {"step": step, "source_batch": source_batches[step], "samples": samples}
        for policy in predictions:
            correct = int(np.count_nonzero(targets[start:stop] == predictions[policy][start:stop]))
            cumulative[policy] += correct
            row.update({f"{policy}_correct": correct, f"{policy}_errors": samples - correct,
                        f"{policy}_loss": (samples - correct) / samples,
                        f"{policy}_accuracy": correct / samples,
                        f"{policy}_cumulative_accuracy": cumulative[policy] / int(stop),
                        f"{policy}_model_version": versions[policy][step]})
        row["post_deployment"] = versions["drift"][step] > 0
        rows.append(row)
    return rows


def _event_counts(events):
    rejected = [event for event in events if event["event"] == "experiment_rejected"]
    return {"updates": sum(event["event"] == "deploy" for event in events),
            "rollbacks": sum(event["event"] == "rollback" for event in events),
            "rejections": len(rejected),
            "expirations": sum(event.get("reason") == "independent_validation_deadline" for event in rejected),
            "rejection_reasons": dict(Counter(event.get("reason", "unspecified") for event in rejected)),
            "harness_action_rejections": sum(event["event"] == "harness_action_rejected" for event in events),
            "training_candidates": sum(event["event"] == "candidate_evaluated" for event in events),
            "candidates_frozen": sum(event["event"] == "candidate_frozen" for event in events),
            "retrain_small_decisions": sum(event["event"] == "harness_decision"
                                          and event.get("action") == "RETRAIN_SMALL" for event in events)}


def _markers(events, timeline):
    markers = defaultdict(list)
    for event in events:
        kind = event["event"]
        if kind == "harness_decision" and event.get("action") == "RETRAIN_SMALL":
            markers[event["step"]].append("R: RETRAIN_SMALL")
        elif kind == "candidate_frozen":
            markers[event["step"]].append("F: Freeze")
        elif kind in ("deploy", "experiment_rejected") and event.get("reason") == "independent_future_labels":
            markers[event["step"]].append("G: Gate " + ("accepted" if kind == "deploy" else "rejected"))
        if kind in ("deploy", "rollback"):
            markers[event["step"]].append(f"D: Deploy v{event['model_version']} after prediction")
    for item in timeline:
        event = item["first_next_prediction"]
        if event is not None:
            markers[event["step"]].append(f"P: Next prediction v{event['model_version']}")
    return markers


def _render_svg(rows, events, timeline):
    width, left, right = 1280, 85, 1235
    count = len(rows)

    def x(index):
        return (left + right) / 2 if count == 1 else left + index * (right - left) / (count - 1)

    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="850" viewBox="0 0 {width} 850">',
             '<title>Gas static and Mock Harness retrospective accuracy</title>',
             '<desc>Offline true labels; actual versions from prediction events. Deployment affects the next batch.</desc>',
             '<rect width="100%" height="100%" fill="#fff"/>',
             '<g font-family="Arial, sans-serif" font-size="14" fill="#233044">',
             '<text x="85" y="35" font-size="24" font-weight="bold">Gas: static vs Mock Harness</text>',
             '<text x="85" y="59">Offline retrospective scoring; released monitor loss remains in the event log.</text>']
    markers = _markers(events, timeline)
    for step, labels in sorted(markers.items()):
        if step < 0 or step >= count:
            continue
        tooltip = escape("; ".join(labels))
        short = "/".join(dict.fromkeys(label[0] for label in labels))
        parts.extend([f'<g class="event-marker"><title>{tooltip}</title>',
                      f'<line x1="{x(step):.5f}" x2="{x(step):.5f}" y1="100" y2="690" stroke="#a0a8b5" stroke-dasharray="4 5"/>',
                      f'<text x="{x(step):.5f}" y="91" text-anchor="middle" font-weight="bold">{short}</text></g>'])
    for panel, bottom, title, key in (("loss", 340, "Per-batch 0/1 loss (error rate)", "loss"),
                                      ("cumulative", 690, "Cumulative sample-weighted accuracy", "cumulative_accuracy")):
        parts.append(f'<text x="85" y="{bottom - 235}" font-size="18" font-weight="bold">{title}</text>')
        for tick in (0, 0.25, 0.5, 0.75, 1):
            y = bottom - 220 * tick
            parts.extend([f'<line x1="{left}" x2="{right}" y1="{y}" y2="{y}" stroke="#e0e5ec"/>',
                          f'<text x="72" y="{y + 5}" text-anchor="end">{tick:.2f}</text>'])
        for policy, color in (("static", "#3679b9"), ("drift", "#d84b39")):
            points = " ".join(f"{x(index):.5f},{bottom - 220 * row[f'{policy}_{key}']:.5f}"
                              for index, row in enumerate(rows))
            parts.append(f'<polyline id="{policy}-{panel}" points="{points}" fill="none" stroke="{color}" stroke-width="3"/>')
            for index, row in enumerate(rows):
                value = row[f"{policy}_{key}"]
                parts.append(f'<circle cx="{x(index):.5f}" cy="{bottom - 220 * value:.5f}" r="4" fill="{color}"><title>{policy}, source batch {row["source_batch"]}: {value:.8f}</title></circle>')
        for index, row in enumerate(rows):
            parts.append(f'<text x="{x(index):.5f}" y="{bottom + 23}" text-anchor="middle">{row["source_batch"]}</text>')
    parts.extend(['<text x="660" y="737" text-anchor="middle">Original source batch</text>',
                  '<text x="85" y="777" fill="#3679b9">Blue: static</text>',
                  '<text x="255" y="777" fill="#d84b39">Red: Mock Harness</text>',
                  '<text x="85" y="806">R: retrain decision; F: freeze; G: gate result; D: deploy after prediction; P: first next prediction.</text>',
                  '<text x="85" y="829">Hover event markers for details. Version &gt; 0 predictions alone enter the post-deployment target.</text>',
                  '</g></svg>'])
    return "\n".join(parts)


def _render_event_log(events, timeline):
    lines = ["# Gas saved-event log", "",
             "Offline retrospective target scoring is separate from the released-label monitor loss below.",
             "All event payloads are copied from the saved logs. Optional metadata remains unspecified when absent.",
             "Accepted deployments require complete independent-future source fields and positive gate samples.",
             "deploy(k) follows prediction(k); its first next prediction is prediction(k+1).", ""]
    for policy in ("static", "drift"):
        lines.extend([f"## {policy}", ""])
        for index, event in enumerate(events[policy]):
            payload = json.dumps(event, ensure_ascii=False, allow_nan=False)
            lines.append(f"- {index + 1}. step {event['step']}, `{event['event']}`: `{payload}`")
        lines.append("")
    lines.extend(["## Deployment and first next prediction", ""])
    for item in timeline:
        deployment, following = item["deploy"], item["first_next_prediction"]
        after = (f"step {following['step']}, actual version {following['model_version']}"
                 if following else "none before stream end; no eligible target samples from this deployment")
        lines.append(f"- deploy step {deployment['step']}, version {deployment['model_version']}; first next prediction: {after}.")
    if not timeline:
        lines.append("No deployment occurred; the post-deployment target has no eligible predictions.")
    return "\n".join(lines) + "\n"


def _render_html(assessment, rows, svg):
    def accuracy(value):
        return "unavailable (no samples)" if value is None else f"{value:.6%}"

    full, post = assessment["full_stream"], assessment["post_deployment"]
    cells = "".join("<tr>" + "".join(f"<td>{escape(str(value))}</td>" for value in
                    (row["source_batch"], row["samples"], row["static_model_version"], row["drift_model_version"],
                     f"{row['static_loss']:.6f}", f"{row['drift_loss']:.6f}",
                     accuracy(row["static_cumulative_accuracy"]), accuracy(row["drift_cumulative_accuracy"])))
                    + "</tr>" for row in rows)
    return f'''<!doctype html>
<html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Gas saved-prediction report</title>
<style>body{{font-family:Arial,sans-serif;color:#233044;margin:32px auto;max-width:1280px;padding:0 20px}}svg{{width:100%;height:auto}}table{{border-collapse:collapse;width:100%}}td,th{{border:1px solid #dce2e9;padding:8px;text-align:right}}p{{line-height:1.5}}</style>
<h1>Gas static and Mock Harness</h1>
<p>Offline retrospective scoring uses all saved predictions and the verified public target rows.
These labels do not enter Harness decisions. Released-label monitor loss is retained separately in the event log.</p>
<p>Full stream accuracy: static <b>{accuracy(full['static']['sample_weighted_accuracy'])}</b>;
Mock <b>{accuracy(full['drift']['sample_weighted_accuracy'])}</b> ({full['drift']['samples']} samples).</p>
<p>Post-deployment accuracy (actual prediction version &gt; 0): <b>{accuracy(post['sample_weighted_accuracy'])}</b>
({post['correct']}/{post['samples']}); static on the same samples: {accuracy(post['static_same_samples']['sample_weighted_accuracy'])}.
Strict &gt;50% target: <b>{'PASS' if assessment['target']['passed'] else 'NOT PASSED'}</b>.</p>
<p>deploy(k) takes effect at prediction(k+1). All accuracies aggregate correct counts over sample counts.
This seen public A stream and fixed Mock rule do not establish independent promotion or causal LLM quality.</p>
{svg}
<table><thead><tr><th>Source batch</th><th>Samples</th><th>Static version</th><th>Mock version</th><th>Static loss</th><th>Mock loss</th><th>Static cumulative accuracy</th><th>Mock cumulative accuracy</th></tr></thead><tbody>{cells}</tbody></table>
<p><a href="batch_metrics.csv">Exact per-batch metrics</a> · <a href="assessment.json">Assessment JSON</a> ·
<a href="event_log.md">Readable saved events</a> · <a href="event_log.json">Raw event payloads and next predictions</a> ·
<a href="curves.svg">SVG curves</a></p></html>
'''


def build_report(pair_dir, package_dir, output_dir):
    """Validate and score saved static/drift archives; create a new immutable report.

    Short original-boundary fixtures are accepted for tests; the real package has
    nine source batches 2..10. Neither summaries nor post-observation curves are
    used for versions, counts or scores.
    """
    pair, package, output = Path(pair_dir), Path(package_dir), Path(output_dir)
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite Gas report: {output}")
    manifest, files, ids, targets, offsets, source_batches = _read_package(package)
    predictions, events, versions = {}, {}, {}
    timeline = []
    for policy in ("static", "drift"):
        predictions[policy], events[policy], versions[policy], changes = _read_run(pair, policy, ids, offsets)
        if policy == "drift":
            timeline = changes
    rows = _batch_rows(targets, predictions, versions, offsets, source_batches)
    mask = np.repeat(np.asarray(versions["drift"]) > 0, np.diff(offsets))
    post = _metrics((predictions["drift"] == targets)[mask])
    matched = _metrics((predictions["static"] == targets)[mask])
    post.update(static_same_samples=matched, by_batch=[row for row in rows if row["post_deployment"]],
                accuracy_gain_vs_static=(post["sample_weighted_accuracy"] - matched["sample_weighted_accuracy"]
                                         if post["samples"] else None))
    assessment = {"scope": "Offline retrospective scoring; released monitor loss is separate",
                  "full_stream": {policy: _metrics(predictions[policy] == targets) for policy in predictions},
                  "post_deployment": post,
                  "target": {"definition": "Sample-weighted accuracy of actual version > 0 predictions",
                             "threshold": 0.5, "comparison": ">",
                             "passed": bool(post["samples"] and post["correct"] * 2 > post["samples"])},
                  "events": _event_counts(events["drift"]), "actual_prediction_versions": versions,
                  "provenance": {"package_manifest": fingerprint(package / "manifest.json"),
                                 "source_files": {name: fingerprint(path) for name, path in files.items()},
                                 "saved_archives": {policy: {name: fingerprint(pair / policy / name)
                                                    for name in ("predictions.npz", "events.jsonl")}
                                                    for policy in predictions},
                                 "report_implementation": fingerprint(Path(__file__))},
                  "limitations": ["Seen public A stream; fixed Mock decisions; no causal LLM-quality claim",
                                  "No independent hidden-data promotion",
                                  "Optional gate diagnostics beyond required source fields remain unspecified"]}
    svg = _render_svg(rows, events["drift"], timeline)
    html = _render_html(assessment, rows, svg)
    markdown = _render_event_log(events, timeline)
    _verified_files(package, manifest)
    output.mkdir(parents=True, exist_ok=False)
    write_json(output / "assessment.json", assessment)
    write_json(output / "event_log.json", {**events, "deployment_timeline": timeline})
    with (output / "batch_metrics.csv").open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    for name, text in (("event_log.md", markdown), ("curves.svg", svg), ("report.html", html)):
        with (output / name).open("x", encoding="utf-8", newline="\n") as stream:
            stream.write(text)
    return assessment


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair", type=Path, required=True)
    parser.add_argument("--package", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(build_report(args.pair, args.package, args.output), indent=2,
                     ensure_ascii=False, allow_nan=False))


if __name__ == "__main__":
    main()
