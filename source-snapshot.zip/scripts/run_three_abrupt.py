"""Entry point for the pre-registered 30-batch/5-call profile."""

from ite.three_abrupt import main

if __name__ == "__main__":
    raise SystemExit(main())
