param(
    [string]$Output = "outputs/local",
    [string]$Config = "configs/default.json"
)
$ErrorActionPreference = "Stop"
$Python = Join-Path $PSScriptRoot "..\.venv\Scripts\python.exe"
if (-not (Test-Path -LiteralPath $Python)) {
    throw "Project Python environment not found. Create .venv first."
}
& $Python -m ite run --config $Config --output $Output
if ($LASTEXITCODE -ne 0) {
    exit $LASTEXITCODE
}
Write-Output "Report: $([System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot "..\$Output\report.html")))"
