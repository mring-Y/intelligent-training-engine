"""One confirmed action-only LoRA pilot; preflight performs no remote work."""

import argparse
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import random
import sys
import time

from ite.decision_sft import (ACTIONS, MODEL, BudgetLedger, candidate_prompt,
                              encode_decision, score_candidate_logprobs, write_json)


ROOT = Path(__file__).resolve().parents[1]
DATASET = ROOT / "outputs/pytrio-crossfit-20261114/host-v1/dataset"
OUTPUT = ROOT / "outputs/pytrio-decision-sft-20261114/paid-v1"
PAID_STATE = ROOT / "outputs/pytrio-decision-sft-paid-state-20261114"
TRAIN_SHA = "6492440a996f51dd80aa4014666eb3d047b815cf0d3048b69514833d3ad03317"
EVAL_SHA = "0f9986e9c1cabb5ce53887701cd7690f712c7f8403da244196699f1c076cdb71"
PRICE_URL = "https://pytrio.cn/api/model-prices"


@dataclass(frozen=True)
class TrainingConfig:
    train_path: str = str(DATASET / "train.jsonl")
    eval_path: str = str(DATASET / "eval.jsonl")
    train_sha256: str = TRAIN_SHA
    eval_sha256: str = EVAL_SHA
    output_dir: str = str(OUTPUT)
    model: str = MODEL
    epochs: int = 3
    batch_size: int = 16
    max_seq_len: int = 512
    rank: int = 8
    learning_rate: float = 0.0001
    seed: int = 7


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _read_rows(path, expected_hash, verify=True):
    raw = Path(path).read_bytes()
    if verify and hashlib.sha256(raw).hexdigest() != expected_hash:
        raise ValueError("Dataset sha256 differs from approved source")
    rows = [json.loads(line) for line in raw.decode("utf-8").splitlines() if line.strip()]
    if not rows:
        raise ValueError("Empty action dataset")
    return rows


def _json_value(value):
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    if isinstance(value, dict):
        return {key: _json_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_value(item) for item in value]
    if hasattr(value, "data"):
        return {"data": list(value.data)}
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    return {key: _json_value(item) for key, item in vars(value).items()
            if not key.startswith("_")}


def _append(stream, value):
    stream.write(json.dumps(_json_value(value), ensure_ascii=False, allow_nan=False) + "\n")
    stream.flush()


def build_datum(record, tokenizer, *, max_seq_len=512, sdk=None):
    if sdk is None:
        import pytrio as sdk
    encoded = encode_decision(record, tokenizer, max_seq_len=max_seq_len)
    return sdk.Datum(model_input=sdk.ModelInput.from_ints(encoded.model_input),
                     loss_fn_inputs={"target_tokens": encoded.target_tokens, "weights": encoded.weights})


def _loss(output, encoded_batch):
    result = _json_value(output)
    outputs = result.get("loss_fn_outputs", [])
    if len(outputs) != len(encoded_batch):
        raise ValueError("Incomplete training loss outputs")
    total = 0.0
    for item, encoded in zip(outputs, encoded_batch):
        logprobs = item.get("logprobs", {})
        values = logprobs.get("data") if isinstance(logprobs, dict) else logprobs
        if not isinstance(values, list) or len(values) != len(encoded.model_input):
            raise ValueError("Training logprob alignment mismatch")
        value = values[encoded.marker_index - 1]
        if type(value) not in (float, int) or not math.isfinite(value) or value > 0:
            raise ValueError("Nonfinite supervised training logprob")
        total -= value
    return total / len(encoded_batch)


def run_training(config, *, tokenizer, training_client, sdk=None, ledger=None, verify_hashes=True):
    """Train all rows with the tail preserved; the caller owns the single remote actor."""
    if sdk is None:
        import pytrio as sdk
    rows = _read_rows(config.train_path, config.train_sha256, verify_hashes)
    encoded = [encode_decision(row, tokenizer, max_seq_len=config.max_seq_len) for row in rows]
    datums = [build_datum(row, tokenizer, max_seq_len=config.max_seq_len, sdk=sdk) for row in rows]
    output = Path(config.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    global_step, input_tokens = 0, 0
    rng = random.Random(config.seed)
    with (output / "train-metrics.jsonl").open("x", encoding="utf-8") as metrics:
        for epoch in range(config.epochs):
            order = list(range(len(rows)))
            rng.shuffle(order)
            for offset in range(0, len(order), config.batch_size):
                indices = order[offset:offset + config.batch_size]
                batch = [datums[index] for index in indices]
                encoded_batch = [encoded[index] for index in indices]
                tokens = sum(item.input_token_count for item in encoded_batch)
                request_id = f"train-{global_step:03d}"
                reserve = BudgetLedger.rounded_request_cost(tokens, 0, "4.54", "0")
                if ledger:
                    ledger.reserve(request_id, reserve, purpose="sft", input_limit=tokens,
                                   epoch=epoch + 1, rows=len(batch))
                started = time.monotonic()
                try:
                    result = training_client.forward_backward(batch, "cross_entropy", auto_shift=False).result(timeout=120)
                    loss = _loss(result, encoded_batch)
                    optimizer_result = training_client.optim_step(
                        sdk.AdamParams(learning_rate=config.learning_rate)).result(timeout=120)
                    if ledger:
                        ledger.settle(request_id, input_tokens=tokens, output_tokens=0,
                                      input_price="4.54", output_price="0",
                                      usage_source="locally_counted_submitted_model_input_tokens",
                                      provider_training_usage_reported=False)
                except Exception as error:
                    if ledger and ledger.data["requests"][request_id]["state"] == "reserved":
                        ledger.mark_unknown(request_id, reason=type(error).__name__)
                    raise
                global_step += 1
                input_tokens += tokens
                entry = {"global_step": global_step, "epoch": epoch + 1, "batch_rows": len(batch),
                         "row_indices": indices, "loss": loss, "supervised_tokens": len(batch),
                         "input_tokens": tokens, "usage_source": "locally_counted_submission",
                         "seconds": time.monotonic() - started, "trainer": _json_value(result),
                         "optimizer": _json_value(optimizer_result)}
                _append(metrics, entry)
                print(f"train step {global_step}/{config.epochs * math.ceil(len(rows)/config.batch_size)} "
                      f"epoch={epoch+1} rows={len(batch)} loss={loss:.6f}", flush=True)
    weights = training_client.save_weights_for_sampler("action-sft-final-epoch3").result(timeout=120)
    # Persist this path before saving the full state, so a later failure cannot hide usable weights.
    result = {"global_steps": global_step, "supervised_tokens": len(rows) * config.epochs,
              "submitted_input_tokens": input_tokens, "weights_path": weights.path,
              "weights_response": _json_value(weights)}
    write_json(output / "training-result.json", result, exclusive=True)
    state = training_client.save_state("action-sft-final-state-epoch3").result(timeout=120)
    result["state_path"] = state.path
    write_json(output / "checkpoint-paths.json", {**result, "state_response": _json_value(state)}, exclusive=True)
    return result


def evaluate(rows, *, tokenizer, sampler, sdk=None, output, phase, ledger=None):
    if sdk is None:
        import pytrio as sdk
    output = Path(output)
    results = []
    with output.open("x", encoding="utf-8") as stream, output.with_suffix(".requests.jsonl").open(
            "x", encoding="utf-8") as requests:
        for index, row in enumerate(rows):
            prompts = [candidate_prompt(row, action, tokenizer) for action in ACTIONS]
            responses = []
            for candidate_index, prompt in enumerate(prompts):
                request_id = f"{phase}-{index:03d}-{candidate_index}"
                if ledger:
                    ledger.reserve(request_id, BudgetLedger.rounded_request_cost(
                        len(prompt.input_ids), 1, "1.49", "4.54"),
                        purpose=f"{phase}-eval", input_limit=len(prompt.input_ids), output_limit=1)
                started = time.monotonic()
                try:
                    response = sampler.sample(
                        prompt=sdk.ModelInput.from_ints(prompt.input_ids), num_samples=1,
                        sampling_params=sdk.SamplingParams(max_tokens=1, temperature=0.0, seed=7),
                        include_prompt_logprobs=True, topk_prompt_logprobs=0, return_text=False,
                    ).result(timeout=120)
                    raw = _json_value(response)
                    _append(requests, {"request_id": request_id, "seconds": time.monotonic() - started,
                                       "candidate": prompt.action, "candidate_index": prompt.token_index,
                                       "prompt_ids": prompt.input_ids, "response": raw})
                    if (type(raw.get("input_tokens")) is not int or
                            raw["input_tokens"] != len(prompt.input_ids) or
                            type(raw.get("output_tokens")) is not int or
                            not 0 <= raw["output_tokens"] <= 1):
                        raise ValueError("Provider token usage missing or exceeds request limits")
                    if ledger:
                        ledger.settle(request_id, input_tokens=raw["input_tokens"], output_tokens=raw["output_tokens"],
                                      input_price="1.49", output_price="4.54")
                    responses.append(raw)
                except Exception as error:
                    if ledger and ledger.data["requests"][request_id]["state"] == "reserved":
                        ledger.mark_unknown(request_id, reason=type(error).__name__)
                    raise
            scores = score_candidate_logprobs(prompts, responses)
            prediction = {"index": index, "input_sha256": row.get("input_sha256"),
                          "profile": row.get("profile"), "phase": phase,
                          "action": scores.action, "actions": list(scores.actions),
                          "logprobs": list(scores.logprobs), "probabilities": list(scores.probabilities)}
            _append(stream, prediction)
            results.append(prediction)
            print(f"{phase} eval {index+1}/{len(rows)} action={scores.action}", flush=True)
    return results


def preflight(config, tokenizer):
    train = _read_rows(config.train_path, config.train_sha256)
    evaluation = _read_rows(config.eval_path, config.eval_sha256)
    if (len(train), len(evaluation)) != (137, 70):
        raise ValueError("Approved dataset counts changed")
    encoded = [[encode_decision(row, tokenizer, max_seq_len=config.max_seq_len) for row in rows]
               for rows in (train, evaluation)]
    estimate = BudgetLedger.estimate_plan(train_rows=len(train), eval_rows=len(evaluation),
        epochs=config.epochs, batch_size=config.batch_size, max_seq_len=config.max_seq_len, candidates=3)
    return {"counts": {"train": len(train), "eval": len(evaluation)}, "budget": asdict(estimate),
            "max_sequence_tokens": max(len(item.input_ids) for group in encoded for item in group),
            "train_model_input_tokens_per_epoch": sum(item.input_token_count for item in encoded[0]),
            "eval_full_prompt_tokens": sum(len(item.input_ids) for item in encoded[1]),
            "supervised_tokens_total": len(train) * config.epochs}


def execute(config, *, approved=False, service_factory=None, tokenizer=None, sdk=None, state_dir=None):
    if not approved:
        raise ValueError("This concrete pilot must be confirmed before remote calls")
    fixed = TrainingConfig()
    for name in ("model", "epochs", "batch_size", "max_seq_len", "rank", "learning_rate", "seed",
                 "train_sha256", "eval_sha256"):
        if getattr(config, name) != getattr(fixed, name):
            raise ValueError(f"Unapproved pilot factor: {name}")
    output = Path(config.output_dir)
    state_dir = Path(state_dir or PAID_STATE)
    if output.exists() or (state_dir / "run-claim.json").exists():
        raise ValueError("Pilot output or single-use claim already exists")
    if tokenizer is None:
        from transformers import AutoTokenizer
        from ite.tokenizer_assets import verify_tokenizer_provenance
        verify_tokenizer_provenance(ROOT / "deployment/tokenizer-qwen3.5-4b", MODEL)
        tokenizer = AutoTokenizer.from_pretrained(str(ROOT / "deployment/tokenizer-qwen3.5-4b"),
                                                 local_files_only=True)
    assessment = preflight(config, tokenizer)
    if sdk is None:
        import pytrio as sdk
        if importlib.metadata.version("pytrio") != "0.2.9":
            raise ValueError("PyTRiO pinned version differs")
        sdk.configure(request_timeout_seconds=30, retry_max_attempts=1,
                      control_retry_timeout_seconds=0, training_retry_timeout_seconds=0,
                      sampling_retry_timeout_seconds=0, actor_capacity_wait_timeout_seconds=120,
                      sampling_timeout_seconds=120, sampling_first_chunk_timeout_seconds=60,
                      sampling_chunk_idle_timeout_seconds=60)
    # Refresh only the public price endpoint; no service session is created here.
    import urllib.request
    prices = json.loads(urllib.request.urlopen(PRICE_URL, timeout=15).read())
    price = next(item for item in prices["items"] if item["display_name"] == MODEL)
    if (prices.get("currency") != "CNY" or prices.get("token_unit") != "per_1m_tokens" or
            [price["prices"][key]["unit_price"] for key in ("prefill", "sample", "train")] != [149, 454, 454]):
        raise ValueError("Approved price ceiling changed")
    output.mkdir(parents=True, exist_ok=False)
    state_dir.mkdir(parents=True, exist_ok=True)
    write_json(state_dir / "run-claim.json", {"output": str(output), "budget_cny": "10.00",
               "started_utc": datetime.now(timezone.utc).isoformat()}, exclusive=True)
    ledger = BudgetLedger(state_dir / "request-ledger.json", total_cny="10.00")
    from ite.tracking import source_metadata
    freeze = {"config": asdict(config), "assessment": assessment, "source": source_metadata(),
              "prices": prices, "source_hashes": {str(p.relative_to(ROOT)): file_hash(p) for p in
                  (ROOT / "ite/decision_sft.py", Path(__file__), ROOT / "configs/decision-sft-20261114.json")}}
    write_json(output / "freeze.json", freeze, exclusive=True)
    try:
        service = (service_factory or sdk.ServiceClient)()
        supported = service.get_supported_models()
        if MODEL not in supported:
            raise ValueError("Approved 4B model unavailable")
        rows = _read_rows(config.eval_path, config.eval_sha256)
        base = service.create_sampling_client(base_model=MODEL)
        evaluate(rows, tokenizer=tokenizer, sampler=base, sdk=sdk, ledger=ledger,
                 output=output / "base-predictions.jsonl", phase="base")
        trainer = service.create_lora_training_client(base_model=MODEL, rank=config.rank, seed=config.seed,
                    train_mlp=True, train_attn=True, train_unembed=False)
        write_json(output / "remote-runs.json", {"service_session": service.service_session_cuid,
                   "training_run": getattr(trainer, "training_run_cuid", None)}, exclusive=True)
        training = run_training(config, tokenizer=tokenizer, training_client=trainer, sdk=sdk, ledger=ledger)
        student = service.create_sampling_client(base_model=MODEL, model_path=training["weights_path"])
        evaluate(rows, tokenizer=tokenizer, sampler=student, sdk=sdk, ledger=ledger,
                 output=output / "student-predictions.jsonl", phase="student")
        from scripts.report_decision_sft import create_report
        assessment = create_report(output)
        status = {"status": "complete", "training": training, "eval_rows": len(rows),
                  "reserved_cny": ledger.reserved_cny, "unknown_requests": 0,
                  "imitation_pass": assessment["imitation_pass"],
                  "cpu_guards_pass": assessment["cpu_guards_pass"]}
        write_json(output / "request-ledger.json", ledger.data, exclusive=True)
        tracking_python = ROOT / ".venv/Scripts/python.exe"
        if tracking_python.is_file():
            import subprocess
            try:
                result = subprocess.run([str(tracking_python), "-X", "utf8", "-m",
                    "scripts.report_decision_sft", "--run", str(output), "--swanlab", "online"],
                    cwd=ROOT, capture_output=True, text=True, encoding="utf-8", timeout=120)
                tracking_status = "uploaded" if result.returncode == 0 else "failed"
                tracking_note = "exit_code=" + str(result.returncode)
            except (OSError, subprocess.SubprocessError) as error:
                tracking_status, tracking_note = "failed", type(error).__name__
        else:
            tracking_status, tracking_note = "unavailable", "project SwanLab runtime is absent"
        status["swanlab_status"] = tracking_status
        write_json(output / "swanlab-subprocess.json", {"status": tracking_status,
                   "note": tracking_note}, exclusive=True)
    except Exception as error:
        status = {"status": "failed", "error_type": type(error).__name__,
                  "reserved_cny": ledger.reserved_cny,
                  "note": "No retry. Reservations retained. Local exit does not cancel remote work."}
        write_json(output / "status.json", status, exclusive=True)
        write_json(output / "request-ledger.json", ledger.data)
        raise
    write_json(output / "status.json", status, exclusive=True)
    write_json(output / "request-ledger.json", ledger.data)
    return status


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--approved", action="store_true")
    parser.add_argument("--preflight", action="store_true")
    args = parser.parse_args()
    config = TrainingConfig()
    if args.preflight:
        from transformers import AutoTokenizer
        tokenizer = AutoTokenizer.from_pretrained(str(ROOT / "deployment/tokenizer-qwen3.5-4b"), local_files_only=True)
        print(json.dumps(preflight(config, tokenizer), indent=2))
        return
    try:
        print(json.dumps(execute(config, approved=args.approved), indent=2))
    except Exception as error:
        print(json.dumps({"status": "stopped", "error_type": type(error).__name__}), file=sys.stderr)
        raise SystemExit(1) from None


if __name__ == "__main__":
    main()
