"""Run a paired public-development comparison of full and head-only B updates."""

import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import zipfile

import numpy as np

from ite.official_model import OFFICIAL_PROFILES, OfficialModelAdapter
from ite.official_sft_data import DRIFT, NOTICE, SCENARIOS, load_public_package, metrics, split_sources
from ite.official_sft_replay import replay_partition
from ite.tracking import source_metadata, write_json


ROOT = Path(__file__).resolve().parents[1]
ARMS = ("static", "full", "head_only")
ACTIONS = {"static": "DO_NOTHING", "full": "RETRAIN_LARGE", "head_only": "RETRAIN_HEAD_ONLY"}
TRAINABLE_PARAMETERS = {"full": 865, "head_only": 25}
FROZEN_ARRAYS = ("mean", "scale", "w1", "b1", "adam_first_w1", "adam_first_b1",
                 "adam_second_w1", "adam_second_b1")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def case_plan():
    return [{"profile": "B", "scenario": scenario, "split": split, "arm": arm,
             "decision_steps": (3, 7) if split == "train" else (3,)}
            for scenario in SCENARIOS for split in ("train", "eval") for arm in ARMS]


def fixed_decision(arm):
    if arm not in ACTIONS:
        raise ValueError("Unknown registered B comparison arm")
    return lambda _: {"action": ACTIONS[arm], "reason": "固定时点的官方B可训练参数集合配对对照，非Teacher标签。",
                      "source": "fixed_comparison"}


def trainable_parameters(arm):
    try:
        return TRAINABLE_PARAMETERS[arm]
    except KeyError:
        raise ValueError("Unknown trainable B comparison arm") from None


def _residual_metrics(targets, predictions):
    result = metrics("B", targets, predictions)
    residual = np.asarray(predictions, dtype=float) - np.asarray(targets, dtype=float)
    return {**result, "bias": float(np.mean(residual)),
            "residual_std": float(np.std(residual)), "residual_variance": float(np.var(residual))}


def summarize_paired(predictions, scenario, *, source_groups=None):
    if set(predictions) != set(ARMS) or scenario not in SCENARIOS:
        raise ValueError("Three registered B arms and a supported scenario are required")
    reference = predictions["static"]
    ids = np.asarray(reference["source_ids"])
    if ids.ndim != 1 or not len(ids) or len(set(ids.tolist())) != len(ids):
        raise ValueError("Paired B source IDs must be unique and nonempty")
    for arm in ARMS:
        row = predictions[arm]
        for key in ("source_ids", "targets", "static"):
            if not np.array_equal(row[key], reference[key]):
                raise ValueError(f"Unpaired {arm} {key}")
    if not np.array_equal(reference["active"], reference["static"]):
        raise ValueError("Static arm must retain the original checkpoint")
    scores = {arm: _residual_metrics(row["targets"], row["active"])
              for arm, row in predictions.items()}
    baseline = scores["static"]
    passes = {arm: ((scores[arm]["rmse"] <= baseline["rmse"] if scenario == "stable" else
                     scores[arm]["rmse"] < baseline["rmse"]) and
                    scores[arm]["mae"] <= baseline["mae"])
              for arm in ("full", "head_only")}
    bearing_metrics = {}
    if source_groups is not None:
        groups = np.asarray(source_groups)
        if groups.shape != ids.shape or groups.dtype.kind not in ("U", "S") or not groups.tolist():
            raise ValueError("B bearing groups must be a matching nonempty string vector")
        for group in sorted(set(groups.tolist())):
            mask = groups == group
            bearing_metrics[group] = {arm: _residual_metrics(
                predictions[arm]["targets"][mask], predictions[arm]["active"][mask]) for arm in ARMS}
    return {"metrics": scores, "bearing_metrics": bearing_metrics, "passes": passes}


def audit_candidate(parent_checkpoint_path, candidate_checkpoint_path, arm):
    if arm not in TRAINABLE_PARAMETERS:
        raise ValueError("Only trained B arms have candidate checkpoints")
    with np.load(parent_checkpoint_path, allow_pickle=False) as archive:
        parent = {key: archive[key].copy() for key in archive.files}
    with np.load(candidate_checkpoint_path, allow_pickle=False) as archive:
        candidate = {key: archive[key].copy() for key in archive.files}
    if set(parent) != set(candidate) or not all(
            parent[key].tobytes() == candidate[key].tobytes() for key in FROZEN_ARRAYS[:2]):
        raise ValueError("Candidate changed B feature normalization or checkpoint arrays")
    try:
        parent_meta = json.loads(parent["metadata"].item())
        candidate_meta = json.loads(candidate["metadata"].item())
    except (KeyError, TypeError, ValueError, json.JSONDecodeError) as error:
        raise ValueError("B checkpoint metadata is invalid") from error
    invariant_meta = ("task", "profile", "target_unit", "learning_rate", "target_mean", "target_scale",
                      "batch_size", "paths", "seed")
    if (any(candidate_meta.get(key) != parent_meta.get(key) for key in invariant_meta) or
            candidate_meta.get("steps", 0) <= parent_meta.get("steps", 0) or
            candidate_meta.get("epochs", 0) != parent_meta.get("epochs", 0) + 5):
        raise ValueError("Candidate changed the B fit contract or did not complete five epochs")
    unchanged = {key: parent[key].tobytes() == candidate[key].tobytes() for key in FROZEN_ARRAYS}
    if arm == "head_only" and not all(unchanged.values()):
        raise ValueError("Frozen B parameters or Adam state changed in head-only candidate")
    changed_parameters = {key: int(np.count_nonzero(parent[key] != candidate[key]))
                          for key in ("w1", "b1", "w2", "b2")}
    if arm == "head_only" and not all(changed_parameters[key] > 0 for key in ("w2", "b2")):
        raise ValueError("B head-only candidate did not update both output parameters")
    if arm == "full" and not any(changed_parameters.values()):
        raise ValueError("B full candidate did not update model parameters")
    return {"trainable_policy": arm, "trainable_parameters": TRAINABLE_PARAMETERS[arm],
        "parent_checkpoint_sha256": hashlib.sha256(Path(parent_checkpoint_path).read_bytes()).hexdigest(),
        "candidate_checkpoint_sha256": hashlib.sha256(Path(candidate_checkpoint_path).read_bytes()).hexdigest(),
        "unchanged_arrays": unchanged, "changed_parameter_counts": changed_parameters,
        "parent_adam_steps": parent_meta["steps"], "candidate_adam_steps": candidate_meta["steps"],
        "parent_epochs": parent_meta["epochs"], "candidate_epochs": candidate_meta["epochs"],
        "learning_rate": candidate_meta["learning_rate"]}


def engineering_issues(arm, split, summary, events):
    issues = []
    if sum(event.get("event") == "prediction" for event in events) != 12:
        issues.append("prediction_batch_count")
    if any(event.get("event") == "training_failed" for event in events):
        issues.append("training_failed")
    if summary["train_seconds"] > 20. or summary["training_attempts"] > 4:
        issues.append("flow_training_budget")
    candidates = [event for event in events if event.get("event") == "candidate_evaluated"]
    if arm == "static":
        if candidates or summary["updates"] or summary["training_attempts"]:
            issues.append("static_arm_updated")
    else:
        if not candidates:
            issues.append("candidate_missing")
        allowed_steps = {3, 7} if split == "train" else {3}
        candidates_by_id = {}
        for candidate in candidates:
            candidates_by_id[candidate.get("decision_id")] = candidate
            audit = candidate.get("fit_audit", {})
            if (candidate.get("step") not in allowed_steps or
                    candidate.get("candidate_adam_steps", 0) <= candidate.get("parent_adam_steps", 0) or
                    not 0 < candidate.get("train_seconds", 0) <= 5. or
                    candidate.get("train_samples") != len(candidate.get("train_source_ids", [])) or
                    candidate.get("screening_samples") != len(candidate.get("screening_source_ids", [])) or
                    set(candidate.get("train_source_ids", [])) & set(candidate.get("screening_source_ids", [])) or
                    audit.get("trainable_policy") != arm or
                    audit.get("trainable_parameters") != TRAINABLE_PARAMETERS[arm] or
                    audit.get("epochs_added") != 5):
                issues.append(f"candidate_contract:{candidate.get('decision_id')}")
        for event in events:
            if (event.get("event") not in ("deploy", "experiment_rejected") or
                    event.get("reason") != "independent_future_labels"):
                continue
            candidate = candidates_by_id.get(event.get("decision_id"))
            if (candidate is None or event.get("gate_min_source_step", -1) <= event.get("frozen_at", -1) or
                    event.get("step", -1) <= event.get("frozen_at", -1) or
                    not event.get("source_ids") or
                    set(event["source_ids"]) & (set(candidate.get("train_source_ids", [])) |
                                                  set(candidate.get("screening_source_ids", [])))):
                issues.append(f"future_gate_isolation:{event.get('decision_id')}")
    return issues


def _read_events(path):
    return [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line]


def _flow_comparison(case, data, indices, initial_state, output):
    scenario, split, arm = (case[key] for key in ("scenario", "split", "arm"))
    name = f"B-{scenario}-{split}-{arm}"
    path = output / name
    model = OfficialModelAdapter.from_state(initial_state)
    result = replay_partition(data, indices, split, scenario, path, model, fixed_decision(arm),
        decision_steps=case["decision_steps"], action_profile="official_finetune")
    events = _read_events(path / "events.jsonl")
    parent_paths = {model.checkpoint_sha256: output / "initial.npz"}
    audits = {}
    for candidate in (event for event in events if event.get("event") == "candidate_evaluated"):
        candidate_path = path / f"candidate-step{candidate['step']}.npz"
        parent_path = parent_paths.get(candidate.get("candidate_parent_checkpoint"))
        if parent_path is None or not candidate_path.is_file():
            raise ValueError(f"Could not resolve B candidate parent for {candidate.get('decision_id')}")
        audit = audit_candidate(parent_path, candidate_path, arm)
        fit_audit = candidate.get("fit_audit", {})
        if (fit_audit.get("trainable_policy") != audit["trainable_policy"] or
                fit_audit.get("trainable_parameters") != audit["trainable_parameters"]):
            raise ValueError("B event audit does not match candidate checkpoint changes")
        audits[candidate["decision_id"]] = audit
        parent_paths[audit["candidate_checkpoint_sha256"]] = candidate_path
    issues = engineering_issues(arm, split, result, events)
    if issues:
        raise ValueError(f"B flow {name} failed engineering audit: {issues}")
    ids_to_group = dict(zip(data["ids"], data["groups"]))
    with np.load(path / "predictions.npz", allow_pickle=False) as archive:
        arrays = {key: archive[key].copy() for key in archive.files}
    costs = {"training_attempts": result["training_attempts"], "train_seconds": result["train_seconds"],
        "released_label_rows": sum(event.get("samples", 0) for event in events
                                    if event.get("event") == "labels_released"),
        "llm_tokens": 0, "paid_calls": 0}
    return name, arrays, {"case": case, "summary": result, "candidate_audits": audits,
        "costs": costs, "evidence_sha256": {file: digest(path / file)
            for file in ("events.jsonl", "predictions.npz", "summary.json")}}, ids_to_group


def run_comparison(output, runtime_python=None):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    runtime_python = runtime_python or os.environ.get("ITE_OFFICIAL_RUNTIME_PYTHON",
        ROOT / ".venv-official-a/Scripts/python.exe")
    data = load_public_package("B")
    partitions = split_sources(data)
    parent = OfficialModelAdapter(OFFICIAL_PROFILES["B"]["task"], runtime_python,
                                  profile_type="B", candidate_epochs=5)
    initial_state = parent.state()
    parent.save(output / "initial.npz")
    write_json(output / "freeze.json", {"notice": NOTICE, "development_only": True,
        "source": source_metadata(), "runner_sha256": digest(__file__),
        "package_sha256": data["package_sha256"], "reported_static_validation": data["reported_baseline"],
        "initial_checkpoint_sha256": parent.checkpoint_sha256,
        "partition_rule": partitions["rule"],
        "partitions": {split: {"rows": len(partitions[split]),
            "source_ids": [data["ids"][index] for index in partitions[split]],
            "bearing_rows": {group: sum(data["groups"][index] == group for index in partitions[split])
                             for group in sorted({data["groups"][index] for index in partitions[split]})}}
            for split in ("train", "eval")},
        "cases": case_plan(), "arms": {"static": "supplied checkpoint, no candidate training",
            "full": "RETRAIN_LARGE; all 865 parameters trainable",
            "head_only": "RETRAIN_HEAD_ONLY; output layer only, 25 parameters trainable"},
        "candidate_epochs": 5, "candidate_timeout_seconds": 5,
        "total_train_seconds_per_flow": 20, "maximum_window_including_screening": 768,
        "screening_rule": "existing min(48, max(4, released_rows // 4)); independent future gate unchanged",
        "label_delay": 1, "paid_calls": 0, "llm_tokens": 0,
        "acceptance": "stable RMSE and MAE no worse than paired static; abrupt/gradual RMSE strictly lower and MAE no worse for each train/eval split",
        "data_role": "previously_seen_public_development_only"})
    summaries, predictions, costs, errors = {}, {}, {}, []
    group_lookup = dict(zip(data["ids"], data["groups"]))
    for case in case_plan():
        name, arrays, flow, _ = _flow_comparison(case, data, partitions[case["split"]], initial_state, output)
        predictions[case["scenario"], case["split"], case["arm"]] = arrays
        summaries[name], costs[name] = flow, flow["costs"]
        if any(audit["trainable_parameters"] != TRAINABLE_PARAMETERS[case["arm"]]
               for audit in flow["candidate_audits"].values()):
            errors.append(name)
        print(f"{name}: RMSE={flow['summary']['active_metrics']['rmse']:.9f}; "
              f"MAE={flow['summary']['active_metrics']['mae']:.9f}; updates={flow['summary']['updates']}; "
              f"training={flow['summary']['train_seconds']:.6f}s", flush=True)
    groups = {}
    for scenario in SCENARIOS:
        for split in ("train", "eval"):
            arrays = {arm: predictions[scenario, split, arm] for arm in ARMS}
            source_groups = np.asarray([group_lookup[identity] for identity in arrays["static"]["source_ids"]])
            groups[f"{scenario}-{split}"] = summarize_paired(arrays, scenario, source_groups=source_groups)
    result = {"notice": NOTICE, "development_only": True, "paid_calls": 0, "llm_tokens": 0,
        "engineering_passed": not errors, "engineering_errors": errors, "physical_flows": len(summaries),
        "groups": groups, "flows": summaries, "costs": costs,
        "freeze_sha256": digest(output / "freeze.json"),
        "all_partition_criteria_pass": {arm: all(groups[f"{scenario}-{split}"]["passes"][arm]
            for scenario in SCENARIOS for split in ("train", "eval")) for arm in ("full", "head_only")}}
    write_json(output / "comparison.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--official-python", default=os.environ.get("ITE_OFFICIAL_RUNTIME_PYTHON",
        str(ROOT / ".venv-official-a/Scripts/python.exe")))
    args = parser.parse_args()
    result = run_comparison(args.output, args.official_python)
    print(json.dumps({"engineering_passed": result["engineering_passed"],
        "all_partition_criteria_pass": result["all_partition_criteria_pass"]}))
    return 0 if result["engineering_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
