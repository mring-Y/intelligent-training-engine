"""Validate artifacts produced by the offline container run."""

import csv
import json
import sys
from pathlib import Path

import numpy as np

# The verifier is invoked as `python scripts/container_check.py ...`, so Python's
# import path starts at scripts/ rather than the repository root.
REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from ite.models import RidgeModel


def check_run(root):
    root = Path(root)
    required_root = ("config.json", "summary.csv", "report.html")
    missing = [name for name in required_root if not (root / name).is_file()]
    if missing:
        raise AssertionError(f"Missing run outputs: {missing}")
    summaries = list(csv.DictReader((root / "summary.csv").open(encoding="utf-8", newline="")))
    if (root / "aggregates.csv").exists():
        list(csv.DictReader((root / "aggregates.csv").open(encoding="utf-8", newline="")))
    if {row["policy"] for row in summaries} != {"static", "periodic", "drift"}:
        raise AssertionError("Expected static, periodic, and drift policy summaries")
    for row in summaries:
        directory = root / row["policy"]
        for name in ("events.jsonl", "summary.json", "curve.csv", "initial.npz", "deployed.npz",
                     "predictions.npz", "diagnostics.json"):
            if not (directory / name).is_file():
                raise AssertionError(f"Missing {row['policy']}/{name}")
        events = [json.loads(line) for line in (directory / "events.jsonl").read_text(encoding="utf-8").splitlines()]
        meta = next(event for event in events if event["event"] == "run_started")
        if meta["source_commit"] in ("unavailable", "") or len(meta["source_sha256"]) != 64:
            raise AssertionError(f"Invalid source metadata in {row['policy']}")
        actual = json.loads((directory / "summary.json").read_text(encoding="utf-8"))
        if int(actual["stream_batches"]) != len(list(csv.DictReader(
                (directory / "curve.csv").open(encoding="utf-8", newline="")))):
            raise AssertionError(f"Batch accounting mismatch in {row['policy']}")
        requested = [event["count"] for event in events if event["event"] == "labels_requested"]
        if sum(requested) != int(actual["labels_requested"]) or max(requested, default=0) < 0:
            raise AssertionError(f"Label accounting mismatch in {row['policy']}")
        for event in events:
            if event["event"] == "experiment_started" and event["train_max_step"] >= event["validation_min_step"]:
                raise AssertionError(f"Temporal leakage in {row['policy']}")

    deployment = root / "drift"
    model = RidgeModel.load(deployment / "deployed.npz")
    checkpoints = sorted(deployment.glob("model-v*.npz"), key=lambda path: int(path.stem[7:]))
    x = np.random.default_rng(4421).normal(size=(24, model.mean.size))
    expected = model.predict(x)
    checkpoint = checkpoints[-1] if checkpoints else deployment / "initial.npz"
    if not np.array_equal(expected, RidgeModel.load(checkpoint).predict(x)):
        raise AssertionError("Latest version checkpoint differs from deployed model")
    with np.load(deployment / "predictions.npz", allow_pickle=False) as values:
        if values["predictions"].shape[0] != int(json.loads(
                (deployment / "summary.json").read_text(encoding="utf-8"))["stream_batches"]):
            raise AssertionError("Prediction artifact has the wrong batch count")
    return {"policy_runs": len(summaries), "policies": sorted(row["policy"] for row in summaries),
            "checkpoint_prediction_match": True, "batch_accounting": "passed",
            "resource_and_temporal_invariants": "passed"}


if __name__ == "__main__":
    print(json.dumps(check_run(sys.argv[1]), indent=2))
