"""Official-train-only comparisons of controls and bounded package policies."""

import argparse
import hashlib
import json
import os
from pathlib import Path

import numpy as np

from ite.heuristic_override import load_training_stream
from ite.official_model import OfficialModelAdapter
from ite.official_sft_data import SCENARIOS, NOTICE, DRIFT, load_public_package, split_sources, metrics
from ite.official_sft_replay import replay_partition
from ite.tracking import source_metadata
from ite.code_harness import write_new, digest
from ite.config import HEURISTIC_C_EPOCHS


ARMS=("static","no_control","heuristic")
DECISION_STEPS=tuple(range(3,10))
TOLERANCES={"a_accuracy_absolute_drop":.005,"c_mae_relative_increase":.02,
            "c_overestimate_rate_absolute_increase":.02,"c_mean_overestimate_increase":1.,
            "a_substantial_macro_f1_gain":.005,"c_substantial_rmse_relative_gain":.01}


def assess_metrics(profile,before,after,scenario,*,allow_equal=False):
    if profile=="A":
        gain=after["macro_f1"]-before["macro_f1"]
        protected=after["accuracy"]>=before["accuracy"]-.005
    else:
        gain=before["rmse"]-after["rmse"]
        protected=(after["mae"]<=before["mae"]*1.02 and
            after["overestimate_rate"]<=before["overestimate_rate"]+.02 and
            after["mean_overestimate"]<=before["mean_overestimate"]+1.) if profile=="C" else (
            after["mae"]<=before["mae"])
    meets_primary = gain >= 0 if allow_equal or scenario == "stable" or profile == "B" else gain > 0
    return {"primary_gain":gain,"primary_improved":gain>0,"auxiliary_within_tolerance":bool(protected),
            "passed":bool(protected and meets_primary)}


def score(profile,values,arm):
    result=metrics(profile,values["targets"],values[arm])
    if profile=="C":
        residual=values[arm]-values["targets"]
        result["nasa_asymmetric_sum"]=float(np.sum(np.expm1(np.where(residual>=0,residual/10.,-residual/13.))))
    return result


def case_plan():
    return [dict(profile=p,scenario=s,split=t,arm=a) for p in "ABC" for s in SCENARIOS
            for t in ("train","eval") for a in ARMS]


def effective_policy(profile, arm, c_epochs=None):
    if c_epochs is not None and (type(c_epochs) is not int or c_epochs not in HEURISTIC_C_EPOCHS):
        raise ValueError("C epoch must be one of the approved 1/2/3/5 values")
    enabled = arm == "heuristic" and (c_epochs is None or profile == "C")
    return enabled, c_epochs if profile == "C" and c_epochs is not None else 5


def policy_for_case(profile, arm, c_epochs=None, *, a_step7_replay=False):
    if (profile not in ("A", "B", "C") or arm not in ARMS or
            type(a_step7_replay) is not bool or (a_step7_replay and c_epochs != 2)):
        raise ValueError("A step7 integration requires C2 and registered package/control arms")
    enabled, epochs = effective_policy(profile, arm, c_epochs)
    scheduled_a = a_step7_replay and profile == "A" and arm == "heuristic"
    return {"decision_steps": (7,) if a_step7_replay and profile == "A" else DECISION_STEPS,
            "action": "RETRAIN_LARGE" if scheduled_a else "DO_NOTHING",
            "candidate_epochs": epochs, "heuristic_override": enabled,
            "a_replay_policy": "class_balanced_official_train" if profile == "A" and
                (enabled or scheduled_a) else "none",
            "gradient_role": "official_public_train_only"}


def assess_a_step7(composite_scores, scenario_scores):
    assessment = assess_metrics("A", composite_scores["static"], composite_scores["heuristic"], "stable")
    substantial = assessment["primary_gain"] >= TOLERANCES["a_substantial_macro_f1_gain"]
    scenes = {s: assess_metrics("A", scenario_scores[s]["static"],
              scenario_scores[s]["heuristic"], "stable") for s in SCENARIOS}
    return {"assessment": assessment, "substantial_primary_gain": substantial,
            "scenario_nonregression": scenes,
            "passed": bool(assessment["passed"] and substantial and all(v["passed"] for v in scenes.values()))}


def run_comparison(output,runtime_python,*,c_epochs=None,a_step7_replay=False):
    policy_for_case("C", "heuristic", c_epochs, a_step7_replay=a_step7_replay)
    root=Path(output);root.mkdir(parents=True,exist_ok=False)
    data={p:load_public_package(p) for p in "ABC"}
    streams={p:load_training_stream(p,exclude_a_reserve=True) for p in "ABC"}
    parts={p:split_sources(data[p]) for p in "ABC"}
    policies={p:policy_for_case(p,"heuristic",c_epochs,a_step7_replay=a_step7_replay) for p in "ABC"}
    models={p:OfficialModelAdapter(data[p]["task"],runtime_python,profile_type=p,
        candidate_epochs=policies[p]["candidate_epochs"]) for p in "ABC"}
    write_new(root/"freeze.json",{"source":source_metadata(),"cases":case_plan(),"drift":DRIFT,
        "notice":NOTICE,"runner_sha256":digest(__file__),"tolerances":TOLERANCES,
        "decision_steps":DECISION_STEPS,"candidate_seconds":5,"flow_training_seconds":20,
        "maximum_training_attempts":4,"gradient_role":"official_public_train_only",
        "combination_c_epochs":c_epochs,
        "combination_a_step7_replay":a_step7_replay,"candidate_policies":policies,
        "combination_notice":"A step7 replay; B static; C2; official train-only gradients" if a_step7_replay else
            "A/B static and C tuned" if c_epochs is not None else "original A/C override experiment",
        "a_timing_development_metrics_reused_as_acceptance":False,
        "control_notice":"constant-NO behavioural control; no new sampler inference or paid LLM calls",
        "training_sources":{p:{"rows":len(d["ids"]),"package_sha256":d["package_sha256"],
             "ordered_source_ids_sha256":hashlib.sha256('\n'.join(d["ids"]).encode()).hexdigest(),
             "excluded_a_reserve_ids":d["excluded_a_reserve_ids"]} for p,d in streams.items()},
        "hidden_test_evaluated":False,"official_platform_protocol_verified":False})
    results={};arrays={}
    for case in case_plan():
        p,s,t,arm=(case[k] for k in ("profile","scenario","split","arm"))
        name=f"{p}-{s}-{t}-{arm}";path=root/name
        policy=policy_for_case(p,arm,c_epochs,a_step7_replay=a_step7_replay)
        result=replay_partition(data[p],parts[p][t],t,s,path,OfficialModelAdapter.from_state(models[p].state()),
            lambda _,action=policy["action"]: {"action":action,
                "reason":"A固定step7申请回放候选，仍须独立未来门控。" if action=="RETRAIN_LARGE" else
                    "固定NO行为对照，隔离宿主规则作用；非本轮真实模型输出。",
                "source":"scheduled_a_replay" if action=="RETRAIN_LARGE" else "constant_no_behavior_control"},
            decision_steps=policy["decision_steps"],
            action_profile="official_finetune",heuristic_override=policy["heuristic_override"],
            a_replay_policy=policy["a_replay_policy"],
            training_stream=streams[p])
        models[p].save(path/"initial.npz")
        # The experiment leaves the actual selected state in its own artifact.
        with np.load(path/"predictions.npz",allow_pickle=False) as values:
            arrays[p,s,t,arm]={k:values[k].copy() for k in values.files}
        events=[json.loads(x) for x in (path/"events.jsonl").read_text(encoding="utf-8").splitlines()]
        train_ids=set(streams[p]["ids"]) | (set(data[p]["replay_reserve"]["ids"]) if p=="A" else set())
        for e in events:
            if e["event"]=="candidate_evaluated":
                assert set(e["train_source_ids"])<=train_ids
                assert not set(e["train_source_ids"])&set(data[p]["ids"])
        results[name]={"case":case,"policy":policy,"summary":result,
            "overrides":sum(e["event"]=="heuristic_override" for e in events),
            "evidence_sha256":{n:digest(path/n) for n in ("events.jsonl","predictions.npz","summary.json")}}
        print(f"{name}: gain={result['paired_primary_gain']:.9f}; fits={result['training_attempts']}; updates={result['updates']}",flush=True)
    groups={};total={}
    for p in "ABC":
        composite={a:{k:[] for k in ("targets","active")} for a in ARMS}
        for s in SCENARIOS:
            merged={a:{k:np.concatenate([arrays[p,s,t,a][k] for t in ("train","eval")])
                       for k in ("targets","active","static","source_ids")} for a in ARMS}
            for a in ARMS:
                assert np.array_equal(merged[a]["targets"],merged["static"]["targets"])
                assert np.array_equal(merged[a]["source_ids"],merged["static"]["source_ids"])
                if a!="heuristic":assert np.array_equal(merged[a]["active"],merged[a]["static"])
                for k in ("targets","active"):composite[a][k].append(merged[a][k])
            scores={a:score(p,merged[a],"active") for a in ARMS}
            groups[f"{p}-{s}-merged"]={"metrics":scores,"assessment":assess_metrics(p,scores["static"],scores["heuristic"],s,
                allow_equal=c_epochs is not None and p in "AB")}
            for t in ("train","eval"):
                ts={a:score(p,arrays[p,s,t,a],"active") for a in ARMS}
                groups[f"{p}-{s}-{t}"]={"metrics":ts,"assessment":assess_metrics(p,ts["static"],ts["heuristic"],s,
                    allow_equal=c_epochs is not None and p in "AB")}
        cs={a:score(p,{k:np.concatenate(v) for k,v in composite[a].items()},"active") for a in ARMS}
        assessment=assess_metrics(p,cs["static"],cs["heuristic"],"stable" if p=="A" and c_epochs is not None else "abrupt")
        substantial=(assessment["primary_gain"] >= (0. if c_epochs is not None and not a_step7_replay else .005) if p=="A" else
                     assessment["primary_gain"]>=.01*cs["static"]["rmse"] if p=="C" else assessment["primary_gain"]>=0)
        total[p]={"metrics":cs,"assessment":assessment,"substantial_primary_gain":bool(substantial)}
    bad=[n for n,r in results.items() if any(q["rejection"] in ("candidate_training_error","training_over_budget") for q in r["summary"]["records"])]
    passed=not bad and all(total[p]["assessment"]["passed"] and total[p]["substantial_primary_gain"] and
        groups[f"{p}-stable-merged"]["assessment"]["passed"] for p in "ABC")
    if c_epochs is not None:
        passed = passed and all(assess_metrics("C",groups[f"C-{s}-merged"]["metrics"]["static"],
            groups[f"C-{s}-merged"]["metrics"]["heuristic"],"stable")["passed"] for s in SCENARIOS)
    a_assessment = assess_a_step7(total["A"]["metrics"],
        {s:groups[f"A-{s}-merged"]["metrics"] for s in SCENARIOS}) if a_step7_replay else None
    if a_assessment is not None:
        passed = passed and a_assessment["passed"]
    result={"engineering_passed":not bad,"engineering_errors":bad,"effect_passed":passed,"groups":groups,
        "composite_development_metrics":total,"physical_flows":54,"flows":results,"paid_calls":0,
        "real_llm_inference":False,"notice":NOTICE,"gradient_role":"official_public_train_only",
        "combination_c_epochs":c_epochs,
        "combination_a_step7_replay":a_step7_replay,"a_step7_assessment":a_assessment,
        "tolerances":TOLERANCES,"freeze_sha256":digest(root/"freeze.json")}
    write_new(root/"comparison.json",result)
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path,required=True)
    parser.add_argument("--official-python",default=os.environ.get("ITE_OFFICIAL_RUNTIME_PYTHON",
        str(Path(__file__).resolve().parents[1]/".venv-official-a/Scripts/python.exe")))
    parser.add_argument("--c-epochs",type=int,choices=HEURISTIC_C_EPOCHS,
        default=os.environ.get("ITE_HEURISTIC_C_EPOCHS"),help="A/B remain static; use one fixed C epoch across scenarios")
    parser.add_argument("--a-step7-replay",action="store_true",
        help="Integrate one A replay attempt at step7 with C2, using official train-only gradients")
    args=parser.parse_args();r=run_comparison(args.output,args.official_python,c_epochs=args.c_epochs,
        a_step7_replay=args.a_step7_replay)
    print(json.dumps({"engineering_passed":r["engineering_passed"],"effect_passed":r["effect_passed"]}))
    return 0 if r["engineering_passed"] else 1


if __name__=="__main__":raise SystemExit(main())
