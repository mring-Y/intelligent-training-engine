"""Paired CPU-C source-balanced historical replay; previously seen development data."""

import argparse
import hashlib
import json
import os
from pathlib import Path

import numpy as np

from ite.official_model import OfficialModelAdapter
from ite.official_sft_data import DRIFT, NOTICE, SCENARIOS, load_public_package, metrics, split_sources
from ite.official_sft_replay import replay_partition
from ite.tracking import source_metadata, write_json


ROOT = Path(__file__).resolve().parents[1]
ARMS = ("static", "head_only", "head_with_replay")
REPLAY = "source_balanced_official_train"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def case_plan():
    return [{"profile": "C", "scenario": scenario, "split": split, "arm": arm, "decision_steps": (7,)}
            for scenario in SCENARIOS for split in ("train", "eval") for arm in ARMS]


def fixed_decision(arm):
    if arm not in ARMS:
        raise ValueError("Unknown C replay comparison arm")
    return lambda _: {"action": "DO_NOTHING" if arm == "static" else "RETRAIN_HEAD_ONLY",
        "reason": "固定时点的官方C来源回放单因素对照，非Teacher标签。", "source": "fixed_comparison"}


def _residual_metrics(y, p):
    residual = p - y
    return {**metrics("C", y, p), "bias": float(np.mean(residual)),
            "residual_std": float(np.std(residual)), "residual_variance": float(np.var(residual))}


def summarize_paired(predictions, scenario, *, source_groups=None):
    if set(predictions) != set(ARMS) or scenario not in SCENARIOS:
        raise ValueError("Three registered C arms and a supported scenario are required")
    reference = predictions["static"]
    ids = np.asarray(reference["source_ids"])
    if ids.ndim != 1 or not len(ids) or len(set(ids.tolist())) != len(ids):
        raise ValueError("Paired C source IDs must be unique and nonempty")
    for arm, row in predictions.items():
        for key in ("source_ids", "targets", "static"):
            if not np.array_equal(row[key], reference[key]):
                raise ValueError(f"Unpaired {arm} {key}")
    if not np.array_equal(reference["active"], reference["static"]):
        raise ValueError("Static arm must retain the original checkpoint")
    scores = {arm: _residual_metrics(row["targets"], row["active"]) for arm, row in predictions.items()}
    baseline = scores["static"]
    passes = {arm: ((scores[arm]["rmse"] <= baseline["rmse"] if scenario == "stable" else
                     scores[arm]["rmse"] < baseline["rmse"]) and
                    all(scores[arm][key] <= baseline[key] for key in ("overestimate_rate", "mean_overestimate")))
              for arm in ARMS[1:]}
    subset_metrics, engine_metrics = {}, {}
    if source_groups is not None:
        groups = np.asarray(source_groups)
        if groups.shape != ids.shape or groups.dtype.kind not in ("U", "S"):
            raise ValueError("C source groups must match paired source IDs")
        subsets = np.asarray([group.split(":")[0] for group in groups.tolist()])
        for identities, destination in ((groups, engine_metrics), (subsets, subset_metrics)):
            for group in sorted(set(identities.tolist())):
                mask = identities == group
                destination[group] = {arm: _residual_metrics(row["targets"][mask], row["active"][mask])
                                      for arm, row in predictions.items()}
    return {"metrics": scores, "passes": passes, "subset_metrics": subset_metrics, "engine_metrics": engine_metrics}


def audit_candidate(parent_path, candidate_path):
    with np.load(parent_path, allow_pickle=False) as cp:
        parent = {key: cp[key].copy() for key in cp.files}
    with np.load(candidate_path, allow_pickle=False) as cp:
        candidate = {key: cp[key].copy() for key in cp.files}
    frozen = ("mean", "scale", "w1", "b1", "adam_first_w1", "adam_first_b1", "adam_second_w1", "adam_second_b1")
    if set(parent) != set(candidate):
        raise ValueError("C candidate checkpoint arrays changed")
    unchanged = {key: parent[key].tobytes() == candidate[key].tobytes() for key in frozen}
    old, new = (json.loads(state["metadata"].item()) for state in (parent, candidate))
    expected_meta = {**old, "epochs": old["epochs"] + 5, "steps": old["steps"] + 15}
    changed = {key: int(np.count_nonzero(parent[key] != candidate[key])) for key in ("w1", "b1", "w2", "b2")}
    if (not all(unchanged.values()) or new != expected_meta or old.get("profile") != "C" or
            not all(changed[key] > 0 for key in ("w2", "b2"))):
        raise ValueError("C head candidate changed frozen state or the five-epoch fit contract")
    return {"trainable_parameters": 33, "unchanged_arrays": unchanged, "changed_parameter_counts": changed,
        "parent_checkpoint_sha256": digest(parent_path), "candidate_checkpoint_sha256": digest(candidate_path),
        "parent_steps": old["steps"], "candidate_steps": new["steps"],
        "parent_epochs": old["epochs"], "candidate_epochs": new["epochs"], "learning_rate": new["learning_rate"]}


def engineering_issues(arm, summary, events):
    issues = []
    predictions = [e for e in events if e.get("event") == "prediction"]
    candidates = [e for e in events if e.get("event") == "candidate_evaluated"]
    if [e.get("step") for e in predictions] != list(range(12)):
        issues.append("prediction_batch_count_or_order")
    if summary["train_seconds"] > 20. or any(e.get("event") == "training_failed" for e in events):
        issues.append("training_budget_or_failure")
    if arm == "static":
        if candidates or summary["updates"] or summary["training_attempts"]:
            issues.append("static_updated")
    else:
        if len(candidates) != 1 or summary["training_attempts"] != 1:
            issues.append("candidate_count")
        for e in candidates:
            replay = e.get("replay_source_ids", [])
            online = e.get("online_train_source_ids", [])
            audit = e.get("fit_audit", {})
            expected_replay = 48 if arm == "head_with_replay" else 0
            expected_ids = replay + online[48:] if expected_replay else online
            if (e.get("step") != 7 or e.get("train_samples") != 720 or e.get("screening_samples") != 48 or
                    len(online) != 720 or len(e.get("screening_source_ids", [])) != 48 or
                    len(replay) != expected_replay or len(set(replay)) != expected_replay or
                    e.get("train_source_ids") != expected_ids or len(set(expected_ids)) != 720 or
                    e.get("replaced_online_source_ids") != (online[:48] if expected_replay else []) or
                    e.get("c_replay_policy") != (REPLAY if expected_replay else "none") or
                    e.get("loss_policy") != "squared" or not 0 < e.get("train_seconds", 0) <= 5. or
                    e.get("candidate_adam_steps", 0) != e.get("parent_adam_steps", 0) + 15 or
                    audit.get("trainable_policy") != "head_only" or audit.get("trainable_parameters") != 33 or
                    audit.get("epochs_added") != 5 or
                    set(expected_ids) & set(e.get("screening_source_ids", []))):
                issues.append("candidate_contract")
    by_id = {e.get("decision_id"): e for e in candidates}
    gates = [e for e in events if e.get("reason") == "independent_future_labels"]
    for e in gates:
        c = by_id.get(e.get("decision_id"))
        if (c is None or e.get("frozen_at") != 7 or e.get("gate_min_source_step") != 8 or e.get("step") != 9 or
                not e.get("source_ids") or e.get("candidate_replay_source_ids") != c.get("replay_source_ids") or
                set(e.get("source_ids", [])) & (set(c.get("train_source_ids", [])) | set(c.get("screening_source_ids", [])))):
            issues.append("future_gate_isolation")
    deployments = [e for e in gates if e.get("event") == "deploy"]
    if len(deployments) != summary["updates"]:
        issues.append("deployment_count")
    for e in predictions:
        prior = [d for d in deployments if d["step"] < e["step"]]
        expected = prior[-1]["model_version"] if prior else 0
        if e.get("model_version") != expected:
            issues.append("prediction_version_timing")
    return issues


def run_comparison(output, runtime_python=None):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    runtime_python = runtime_python or os.environ.get("ITE_OFFICIAL_RUNTIME_PYTHON",
        ROOT / ".venv-official-a/Scripts/python.exe")
    data = load_public_package("C")
    partitions = split_sources(data)
    parent = OfficialModelAdapter("regression", runtime_python, profile_type="C", candidate_epochs=5)
    parent.save(output / "initial.npz")
    initial_state, reserve = parent.state(), data["replay_reserve"]
    np.savez_compressed(output / "replay-reserve.npz", **{key: np.asarray(reserve[key]) for key in ("x", "y", "ids", "groups")})
    write_json(output / "freeze.json", {"notice": NOTICE, "development_only": True, "source": source_metadata(),
        "runner_sha256": digest(__file__), "package_sha256": data["package_sha256"],
        "initial_checkpoint_sha256": parent.checkpoint_sha256, "feature_paths": data["feature_paths"],
        "partition_rule": partitions["rule"], "partitions": {split: {"rows": len(partitions[split]),
            "source_ids": [data["ids"][i] for i in partitions[split]]} for split in ("train", "eval")},
        "cases": case_plan(), "drift": DRIFT, "batches": 12, "label_delay": 1,
        "replay_reserve": {"source_ids": reserve["ids"], "groups": reserve["groups"],
            "subset_counts": reserve["subset_counts"], "selection_policy": reserve["selection_policy"],
            "sha256": digest(output / "replay-reserve.npz"), "transform": "original unshifted historical train rows",
            "replacement": "replace oldest 48 online fit rows; keep 720 total training rows"},
        "arms": {"static": "supplied checkpoint; no training", "head_only": "720 online fit rows",
                 "head_with_replay": "48 historical reserve + newest 672 online fit rows"},
        "trainable_parameters": 33, "candidate_epochs": 5, "loss_policy": "squared", "learning_rate": .002,
        "candidate_timeout_seconds": 5, "total_train_seconds_per_flow": 20, "maximum_window_including_screening": 768,
        "screening_rows": 48, "independent_future_gate": True, "paid_calls": 0, "llm_tokens": 0,
        "acceptance": "stable RMSE and both overestimation metrics no worse; drift RMSE strictly lower and both overestimation metrics no worse than same-ID static, per train/eval partition",
        "data_role": "previously_seen_public_development_only"})
    flows, arrays, costs, errors = {}, {}, {}, []
    lookup = dict(zip(data["ids"], data["groups"]))
    for case in case_plan():
        scenario, split, arm = (case[key] for key in ("scenario", "split", "arm"))
        name = f"C-{scenario}-{split}-{arm}"
        path = output / name
        summary = replay_partition(data, partitions[split], split, scenario, path,
            OfficialModelAdapter.from_state(initial_state), fixed_decision(arm), decision_steps=(7,),
            action_profile="official_finetune", c_replay_policy=REPLAY if arm == "head_with_replay" else "none")
        events = [json.loads(s) for s in (path / "events.jsonl").read_text(encoding="utf-8").splitlines()]
        issues = engineering_issues(arm, summary, events)
        if issues:
            errors.append({"flow": name, "issues": issues})
        candidate_audit = audit_candidate(output / "initial.npz", path / "candidate-step7.npz") if arm != "static" else None
        with np.load(path / "predictions.npz", allow_pickle=False) as z:
            arrays[scenario, split, arm] = {key: z[key].copy() for key in z.files}
        costs[name] = {"training_attempts": summary["training_attempts"], "train_seconds": summary["train_seconds"],
            "released_label_rows": sum(e["samples"] for e in events if e.get("event") == "labels_released"),
            "llm_tokens": 0, "paid_calls": 0}
        flows[name] = {"case": case, "summary": summary, "costs": costs[name], "candidate_audit": candidate_audit,
            "evidence_sha256": {file: digest(path / file) for file in ("events.jsonl", "predictions.npz", "summary.json")}}
        print(f"{name}: RMSE={summary['active_metrics']['rmse']:.9f}; "
              f"over={summary['active_metrics']['overestimate_rate']:.9f}; "
              f"updates={summary['updates']}; train={summary['train_seconds']:.6f}s", flush=True)
    groups = {}
    for scenario in SCENARIOS:
        for split in ("train", "eval"):
            rows = {arm: arrays[scenario, split, arm] for arm in ARMS}
            source_groups = np.asarray([lookup[identity] for identity in rows["static"]["source_ids"]])
            groups[f"{scenario}-{split}"] = summarize_paired(rows, scenario, source_groups=source_groups)
    result = {"notice": NOTICE, "development_only": True, "paid_calls": 0, "llm_tokens": 0,
        "engineering_passed": not errors, "engineering_errors": errors, "physical_flows": len(flows),
        "groups": groups, "flows": flows, "costs": costs, "freeze_sha256": digest(output / "freeze.json"),
        "all_partition_criteria_pass": {arm: all(group["passes"][arm] for group in groups.values()) for arm in ARMS[1:]}}
    write_json(output / "comparison.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--official-python", default=os.environ.get("ITE_OFFICIAL_RUNTIME_PYTHON",
        str(ROOT / ".venv-official-a/Scripts/python.exe")))
    args = parser.parse_args()
    result = run_comparison(args.output, args.official_python)
    print(json.dumps({"engineering_passed": result["engineering_passed"],
        "all_partition_criteria_pass": result["all_partition_criteria_pass"]}))
    return 0 if result["engineering_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
