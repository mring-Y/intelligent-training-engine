param(
    [string]$Image = "ite-local:verification",
    [string]$Output = "outputs/phase2"
)

$ErrorActionPreference = "Stop"
$Docker = Get-Command docker -ErrorAction SilentlyContinue
if ($Docker) {
    $DockerExe = $Docker.Source
} else {
    $DockerExe = Join-Path $env:LOCALAPPDATA "Programs/DockerDesktop/resources/bin/docker.exe"
}
if (-not (Test-Path -LiteralPath $DockerExe)) {
    throw "Docker CLI not found at $DockerExe"
}
$DockerDirectory = Split-Path -Parent $DockerExe
if ($env:PATH -notlike "*$DockerDirectory*") { $env:PATH = "$DockerDirectory;$env:PATH" }

$Root = (Resolve-Path .).Path
$OutputPath = Join-Path $Root $Output
New-Item -ItemType Directory -Force -Path $OutputPath | Out-Null
$OutputMount = $OutputPath.Replace("\", "/")
$Seeds = "101 103 107 109 113"
$Tasks = "classification regression"
$Scenarios = "stable abrupt gradual recurring covariate noise"

function Invoke-IteMatrix {
    param(
        [string]$Name,
        [string]$Config,
        [string]$TaskList,
        [string]$ScenarioList,
        [string]$PolicyList = "static periodic drift"
    )
    $DockerArguments = @("run", "--rm", "--network", "none", "--cpus", "4", "--memory", "4g",
              "-e", "OPENBLAS_NUM_THREADS=1", "-e", "OMP_NUM_THREADS=1", "-e", "MKL_NUM_THREADS=1",
              "-v", "${OutputMount}:/app/outputs/phase2", $Image, "ite", "matrix",
              "--config", "/app/configs/$Config", "--output", "/app/outputs/phase2/$Name",
              "--tasks")
    $DockerArguments += $TaskList.Split(" ")
    $DockerArguments += @("--scenarios")
    $DockerArguments += $ScenarioList.Split(" ")
    $DockerArguments += @("--seeds")
    $DockerArguments += $Seeds.Split(" ")
    $DockerArguments += @("--batches", "96", "--policies")
    $DockerArguments += $PolicyList.Split(" ")
    & $DockerExe @DockerArguments
    if ($LASTEXITCODE -ne 0) {
        throw "Matrix $Name failed with exit code $LASTEXITCODE"
    }
}

Invoke-IteMatrix -Name "legacy" -Config "validation-legacy.json" -TaskList $Tasks -ScenarioList $Scenarios
Invoke-IteMatrix -Name "future-32" -Config "validation-future-32.json" -TaskList $Tasks -ScenarioList $Scenarios
Invoke-IteMatrix -Name "future-64" -Config "validation-future-64.json" -TaskList $Tasks -ScenarioList $Scenarios -PolicyList "drift"
Invoke-IteMatrix -Name "future-96" -Config "validation-future-96.json" -TaskList $Tasks -ScenarioList $Scenarios -PolicyList "drift"
Invoke-IteMatrix -Name "history-reuse" -Config "validation-history.json" -TaskList $Tasks -ScenarioList $Scenarios -PolicyList "drift"

foreach ($Stress in @(
    @{ Name = "stress-delay-6"; Config = "validation-delay-stress.json" },
    @{ Name = "stress-label-10pct"; Config = "validation-label-stress.json" },
    @{ Name = "stress-period-4"; Config = "validation-period-4.json" },
    @{ Name = "stress-period-16"; Config = "validation-period-16.json" }
)) {
    Invoke-IteMatrix -Name $Stress.Name -Config $Stress.Config -TaskList $Tasks -ScenarioList "recurring" -PolicyList "drift"
}

$AssessArguments = @("run", "--rm", "--network", "none", "--cpus", "4", "--memory", "4g",
                "-v", "${OutputMount}:/app/outputs/phase2", $Image, "ite", "assess",
                "--baseline", "/app/outputs/phase2/legacy/summary.csv",
                "--candidate", "/app/outputs/phase2/future-32/summary.csv",
                "--history", "/app/outputs/phase2/history-reuse/summary.csv",
                "--seeds")
$AssessArguments += $Seeds.Split(" ")
$AssessArguments += @("--output", "/app/outputs/phase2/deployment-decision.json")
& $DockerExe @AssessArguments
if ($LASTEXITCODE -eq 1) {
    Write-Warning "At least one experimental strategy failed the predeclared promotion gate. The legacy strategy remains default."
} elseif ($LASTEXITCODE -ne 0) {
    throw "Deployment assessment failed with exit code $LASTEXITCODE"
}
