"""Evaluate frozen decisions and select archived CPU outcomes without fitting any model."""

import argparse
from collections import Counter, defaultdict
import copy
import hashlib
import json
import math
from pathlib import Path

import numpy as np

from ite.decision_sft import ACTIONS, write_json
from ite.official_sft_data import metrics as cpu_metrics
from scripts.train_decision_sft import DATASET, OUTPUT, ROOT, _read_rows, EVAL_SHA


def log_swanlab(result, *, run_name, mode="online", swanlab_module=None, output=None):
    """Record scalar experiment evidence; callers decide whether to publish online."""
    if swanlab_module is None:
        import swanlab as swanlab_module
    output = Path(output) if output is not None else None
    ledger = json.loads((output / "request-ledger.json").read_text(encoding="utf-8")) if output else {}
    reserved = sum(float(request["reserved_cny"]) for request in ledger.get("requests", {}).values())
    config = {
        "model": "Qwen/Qwen3.5-4B", "sdk": "pytrio==0.2.9", "epochs": 3,
        "rank": 8, "batch_size": 16, "learning_rate": 0.0001, "seed": 7,
        "train_rows": 137, "eval_rows": 70, "supervision": "one_marker_position",
        "budget_limit_cny": 10.0, "reserved_cny": reserved, "public_development_only": True,
        "train_sha256": "6492440a996f51dd80aa4014666eb3d047b815cf0d3048b69514833d3ad03317",
        "eval_sha256": "0f9986e9c1cabb5ce53887701cd7690f712c7f8403da244196699f1c076cdb71",
    }
    run = swanlab_module.init(project="Intelligent_Training_Engine", workspace="mring-Y",
                              name=run_name, mode=mode, config=config,
                              description="PyTRiO action-only Decision SFT pilot")
    student = result.get("action_metrics", {}).get("student", {}).get("all", {})
    constant = result.get("action_metrics", {}).get("constant_no", {}).get("all", {})
    try:
        if output:
            for line in (output / "train-metrics.jsonl").read_text(encoding="utf-8").splitlines():
                row = json.loads(line)
                run.log({"train/loss": row["loss"], "train/epoch": row["epoch"],
                         "train/supervised_tokens": row["supervised_tokens"],
                         "train/input_tokens": row["input_tokens"]}, step=row["global_step"])
        if student and constant and "macro_f1" in student and "macro_f1" in constant:
            run.log({"eval/accuracy": student["accuracy"], "eval/macro_f1": student["macro_f1"],
                     "eval/nll": student["nll"], "eval/ece_10_bin": student["ece_10_bin"],
                     "eval/brier": student["brier"],
                     "baseline/constant_no_accuracy": constant["accuracy"],
                     "baseline/constant_no_macro_f1": constant["macro_f1"],
                     "eval/imitation_pass": int(result.get("imitation_pass", False)),
                     "cpu/guards_pass": int(result.get("cpu_guards_pass", False)),
                     "cpu/reserved_cost_cny": reserved}, step=28)
        comparison = {}
        for name, evaluation in result.get("action_metrics", {}).items():
            if name == "base":
                for metric in ("accuracy", "macro_f1", "nll", "ece_10_bin", "brier"):
                    if metric in evaluation["all"]:
                        comparison[f"baseline/base_{metric}"] = evaluation["all"][metric]
            for profile, values in evaluation.get("by_package", {}).items():
                for metric in ("accuracy", "macro_f1", "nll", "ece_10_bin", "brier"):
                    comparison[f"action/{name}/{profile}/{metric}"] = values[metric]
        for name, cpu in result.get("cpu_outcomes", {}).items():
            for profile, package in cpu.get("packages", {}).items():
                for metric, value in package["selected_policy"].items():
                    if type(value) in (int, float) and math.isfinite(value):
                        comparison[f"cpu/{name}/{profile}/{metric}"] = value
        if comparison:
            run.log(comparison, step=29)
        if output:
            from ite.tracking import _check_artifact
            for filename in ("freeze.json", "report.json", "train-metrics.jsonl", "request-ledger.json",
                             "base-predictions.jsonl", "student-predictions.jsonl", "checkpoint-paths.json"):
                artifact = output / filename
                if artifact.is_file():
                    _check_artifact(artifact)
                    swanlab_module.save(artifact, base_path=output, policy="now")
    finally:
        finish = getattr(swanlab_module, "finish", None)
        if finish is not None:
            finish()
    if output is not None:
        write_json(output / "swanlab-receipt.json", {"mode": mode, "run_id": getattr(run, "id", None),
                                  "project": "mring-Y/Intelligent_Training_Engine",
                                  "status": "initialized_and_logged"}, exclusive=True)
    return {"mode": mode, "run_id": getattr(run, "id", None)}


def action_metrics(labels, predictions):
    if not labels or len(labels) != len(predictions):
        raise ValueError("Unpaired action labels/predictions")
    confusion = [[0] * 3 for _ in range(3)]
    nll, brier, bins = 0.0, 0.0, [[] for _ in range(10)]
    for label, prediction in zip(labels, predictions):
        truth, chosen = ACTIONS.index(label), ACTIONS.index(prediction["action"])
        probability = prediction["probabilities"]
        if (len(probability) != 3 or any(type(p) not in (int, float) or not math.isfinite(p) or
                                         not 0 <= p <= 1 for p in probability) or
                not math.isclose(sum(probability), 1.0, abs_tol=1e-10)):
            raise ValueError("Invalid action probabilities")
        confusion[truth][chosen] += 1
        nll -= math.log(max(probability[truth], 1e-15))
        brier += sum((p - int(i == truth)) ** 2 for i, p in enumerate(probability))
        confidence = probability[chosen]
        bins[min(int(confidence * 10), 9)].append((confidence, int(truth == chosen)))
    support = [sum(row) for row in confusion]
    f1, recall = [], {}
    for i, action in enumerate(ACTIONS):
        tp, predicted = confusion[i][i], sum(confusion[j][i] for j in range(3))
        f1.append(2 * tp / (support[i] + predicted) if support[i] + predicted else 0.0)
        recall[action] = tp / support[i] if support[i] else None
    count = len(labels)
    ece = sum(abs(sum(v[0] for v in group) - sum(v[1] for v in group)) / count
              for group in bins)
    return {"samples": count, "accuracy": sum(confusion[i][i] for i in range(3)) / count,
            "macro_f1": sum(f1) / 3, "confusion_matrix": confusion, "recall": recall,
            "class_support": dict(zip(ACTIONS, support)),
            "missing_classes": [action for action, n in zip(ACTIONS, support) if n == 0],
            "action_counts": dict(Counter(row["action"] for row in predictions)),
            "nll": nll / count, "nll_probability_floor": 1e-15, "brier": brier / count,
            "ece_10_bin": ece}


def load_predictions(path, hashes):
    rows = [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(rows) != len(hashes):
        raise ValueError("Prediction count differs from fixed evaluation records")
    for i, (row, expected_hash) in enumerate(zip(rows, hashes)):
        probabilities = row.get("probabilities", [])
        if (len(probabilities) != 3 or any(type(p) not in (int, float) or not math.isfinite(p) or
                not 0 <= p <= 1 for p in probabilities) or
                not math.isclose(sum(probabilities), 1.0, abs_tol=1e-10)):
            raise ValueError("Invalid prediction probabilities")
        if (row.get("input_sha256") != expected_hash or row.get("index") != i or
                tuple(row.get("actions", [])) != ACTIONS or row.get("action") !=
                ACTIONS[max(range(3), key=lambda k: probabilities[k])]):
            raise ValueError("Prediction identity/action differs from its frozen input")
    return rows


def _aggregate(profile, scores):
    n = sum(s["samples"] for s in scores)
    if profile == "A":
        matrix = np.sum([s["confusion_matrix"] for s in scores], axis=0)
        true = matrix.sum(axis=1)
        pred = matrix.sum(axis=0)
        denominators = true + pred
        f1 = np.divide(2 * np.diag(matrix), denominators, out=np.zeros(6), where=denominators > 0)
        return {"samples": n, "accuracy": float(np.trace(matrix) / n),
                "macro_f1": float(np.mean(f1)), "confusion_matrix": matrix.tolist()}
    weighted = lambda key: sum(s["samples"] * s[key] for s in scores) / n
    return {"samples": n, "rmse": math.sqrt(sum(s["samples"] * s["rmse"] ** 2 for s in scores) / n),
            "mae": weighted("mae"), "overestimate_rate": weighted("overestimate_rate"),
            "mean_overestimate": weighted("mean_overestimate"),
            "unit": "minutes" if profile == "B" else "cycles"}


def compare_cpu_outcomes(rows, predictions):
    if len(rows) != len(predictions):
        raise ValueError("CPU outcomes are not paired with policy decisions")
    packages, per_decision = {}, []
    for profile in "ABC":
        selected_scores, static_scores, fallback = [], [], 0
        for row, prediction in zip(rows, predictions):
            if row["profile"] != profile:
                continue
            outcomes = {o["action"]: o for o in row["evidence"]["outcomes"]}
            chosen = outcomes[prediction["action"]]["evidence"]
            no = outcomes["DO_NOTHING"]["evidence"]
            static = no["whole_static"]
            active = chosen["whole_active"]
            if static["samples"] != active["samples"]:
                raise ValueError("Archived CPU outcomes have different source counts")
            selected_scores.append(active)
            static_scores.append(static)
            is_fallback = prediction["action"] == "DO_NOTHING" or not chosen.get("deployment_version", 1)
            fallback += int(is_fallback)
            keys = ("macro_f1", "accuracy") if profile == "A" else (
                "rmse", "mae", "overestimate_rate", "mean_overestimate")
            per_decision.append({"input_sha256": row["input_sha256"], "profile": profile,
                "scenario": row.get("scenario"), "step": row.get("step"),
                "source_group": row.get("source_group"), "action": prediction["action"],
                "static": static, "active": active,
                "delta": {key: active[key] - static[key] for key in keys},
                "static_fallback": is_fallback,
                "train_seconds": chosen.get("train_seconds", 0.0)})
        if not selected_scores:
            continue
        active, static = _aggregate(profile, selected_scores), _aggregate(profile, static_scores)
        guard_keys = ("accuracy",) if profile == "A" else ("mae",) if profile == "B" else (
            "overestimate_rate", "mean_overestimate")
        safe = all(active[key] >= static[key] if profile == "A" else active[key] <= static[key]
                   for key in guard_keys)
        active.update({f"static_{key}": static[key] for key in static if key not in ("samples", "unit")})
        active["safety_pass"] = safe
        packages[profile] = {"paired_decisions": len(selected_scores), "selected_policy": active,
                             "static_fallback": static, "static_fallback_decisions": fallback}
    return {"packages": packages, "per_decision": per_decision,
            "scope": "Archived single-decision counterfactual windows; repeated variants are not independent entities."}


def hydrate_archived_outcomes(rows, crossfit_root):
    """Verify archived hashes and recompute every evaluated arm from raw arrays; no fit calls."""
    crossfit_root = Path(crossfit_root)
    report = json.loads((crossfit_root / "report.json").read_text(encoding="utf-8"))
    hashes = report["output_hashes"]
    decisions = {}
    for path in sorted((crossfit_root / "arms").glob("*/decision.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        key = tuple(data[k] for k in ("profile", "fold_id", "source_group", "scenario", "step"))
        decisions[key] = path.parent
    expanded, original_indices, evidence_hashes = [], [], {}
    for index, row in enumerate(rows):
        sources = row.get("duplicate_sources") or [{key: row[key] for key in (
            "profile", "fold_id", "source_group", "scenario", "step")}]
        for source in sources:
            path = decisions[tuple(source[k] for k in ("profile", "fold_id", "source_group", "scenario", "step"))]
            hydrated = copy.deepcopy(row)
            hydrated.update(source)
            outcomes = []
            baseline = None
            for action in ACTIONS:
                arm = path / action
                for filename in ("predictions.npz", "summary.json", "events.jsonl"):
                    artifact = arm / filename
                    relative = artifact.relative_to(crossfit_root).as_posix()
                    digest = hashlib.sha256(artifact.read_bytes()).hexdigest()
                    if digest != hashes[relative]:
                        raise ValueError("Archived CPU evidence hash mismatch")
                    evidence_hashes[relative] = digest
                with np.load(arm / "predictions.npz", allow_pickle=False) as archive:
                    arrays = {key: archive[key].copy() for key in archive.files}
                if set(arrays) != {"targets", "static", "active", "source_ids", "versions"}:
                    raise ValueError("Unexpected archived CPU array fields")
                state = (arrays["source_ids"], arrays["targets"], arrays["static"])
                if baseline is None:
                    baseline = state
                elif any(not np.array_equal(a, b) for a, b in zip(baseline, state)):
                    raise ValueError("CPU source IDs, labels or static predictions differ across arms")
                summary = json.loads((arm / "summary.json").read_text(encoding="utf-8"))
                probe = copy.deepcopy(summary["records"][0])
                evidence = probe["evidence"]
                for label, pred in (("whole_static", "static"), ("whole_active", "active")):
                    evidence[label] = cpu_metrics(row["profile"], arrays["targets"], arrays[pred])
                evidence["deployment_version"] = int(np.any(arrays["versions"] > 0))
                evidence["source_ids_sha256"] = hashlib.sha256(
                    "\n".join(arrays["source_ids"].tolist()).encode()).hexdigest()
                outcomes.append(probe)
            hydrated["evidence"] = {"outcomes": outcomes}
            expanded.append(hydrated)
            original_indices.append(index)
    return expanded, original_indices, evidence_hashes


def cpu_guards_pass(outcomes):
    """Every package must satisfy guards overall and in each registered scenario."""
    student = outcomes.get("student", {})
    scenarios = student.get("by_scenario", {})
    if set(scenarios) != {"stable", "abrupt", "gradual"}:
        return False
    return all(set(group.get("packages", {})) == set("ABC") and all(
        package["selected_policy"]["safety_pass"] is True
        for package in group["packages"].values())
        for group in (student, *scenarios.values()))


def create_report(run_root=OUTPUT, *, crossfit_root=DATASET.parent):
    run_root = Path(run_root)
    rows = _read_rows(DATASET / "eval.jsonl", EVAL_SHA)
    hashes = [row["input_sha256"] for row in rows]
    base = load_predictions(run_root / "base-predictions.jsonl", hashes)
    student = load_predictions(run_root / "student-predictions.jsonl", hashes)
    constant = [{"action": ACTIONS[0], "probabilities": [1.0, 0.0, 0.0]} for _ in rows]
    policies = {"base": base, "student": student, "constant_no": constant}
    result = {"scope": "Public development action imitation and archived single-decision outcomes.",
              "action_eval_records": len(rows), "action_metrics": {}, "cpu_outcomes": {}}
    labels = [row["target_action"] for row in rows]
    for name, predictions in policies.items():
        result["action_metrics"][name] = {"all": action_metrics(labels, predictions), "by_package": {}}
        for profile in "ABC":
            indices = [i for i, row in enumerate(rows) if row["profile"] == profile]
            result["action_metrics"][name]["by_package"][profile] = action_metrics(
                [labels[i] for i in indices], [predictions[i] for i in indices])
    expanded, original_indices, evidence_hashes = hydrate_archived_outcomes(rows, crossfit_root)
    result["cpu_replay_states"] = len(expanded)
    result["cpu_evidence_hashes"] = evidence_hashes
    for name, predictions in policies.items():
        selected = [predictions[i] for i in original_indices]
        result["cpu_outcomes"][name] = compare_cpu_outcomes(expanded, selected)
        result["cpu_outcomes"][name]["by_scenario"] = {}
        result["cpu_outcomes"][name]["by_source_group"] = {}
        for field, key in (("scenario", "by_scenario"), ("source_group", "by_source_group")):
            for value in sorted({row[field] for row in expanded}):
                indices = [i for i, row in enumerate(expanded) if row[field] == value]
                result["cpu_outcomes"][name][key][value] = compare_cpu_outcomes(
                    [expanded[i] for i in indices], [selected[i] for i in indices])
    result["imitation_pass"] = all(
        result["action_metrics"]["student"]["all"]["macro_f1"] >
        result["action_metrics"][name]["all"]["macro_f1"] for name in ("base", "constant_no"))
    result["cpu_guards_pass"] = cpu_guards_pass(result["cpu_outcomes"])
    result["official_acceptance"] = False
    result["autonomous_closed_loop_measured"] = False
    write_json(run_root / "report.json", result, exclusive=True)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", default=str(OUTPUT))
    parser.add_argument("--swanlab", choices=("online", "local", "offline"))
    args = parser.parse_args()
    run_root = Path(args.run)
    result = (json.loads((run_root / "report.json").read_text(encoding="utf-8"))
              if args.swanlab and (run_root / "report.json").is_file() else create_report(run_root))
    tracking = None
    if args.swanlab:
        tracking = log_swanlab(result, run_name="pytrio-decision-sft-20261114", mode=args.swanlab,
                               output=run_root)
    print(json.dumps({"imitation_pass": result["imitation_pass"],
                      "cpu_guards_pass": result["cpu_guards_pass"], "swanlab": tracking}, indent=2))


if __name__ == "__main__":
    main()
