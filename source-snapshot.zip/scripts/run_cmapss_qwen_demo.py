"""One single-use, budgeted Qwen decision on the frozen FD001 stream."""

import json
import shutil
from collections import Counter
from decimal import Decimal
from datetime import datetime, timezone
from pathlib import Path

from ite.config import ExperimentConfig
from ite.runner import run_policy
from ite.tracking import source_metadata, write_json
from ite.training import BoundedTrainer
from ite.tokenizer_assets import verify_tokenizer_provenance
from scripts.data_prep.common import fingerprint
from scripts.data_prep.provider import PreparedDataProvider
from scripts.run_cmapss_harness import _manifest
from ite.providers import ColumnMapping


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_PACKAGE = ROOT / "outputs/a-package-20261110/prepared/cmapss_fd001"
DEFAULT_OUTPUT = ROOT / "outputs/cmapss-tree-qwen4b-live-20261112"
STATE_ROOT = ROOT / "outputs/cmapss-tree-qwen-paid-state-20261112"
DEFAULT_CONFIG = ROOT / "configs/cmapss-tree-qwen-demo.json"
REFERENCE_EVENTS = ROOT / "outputs/cmapss-tree-harness-20261110/host-pair/drift/events.jsonl"
REPORT = ROOT / "Qwen_Live_Decision.md"


def claim_single_run(state_root, output_dir, config, package_manifest):
    if config != ExperimentConfig.load(DEFAULT_CONFIG):
        raise ValueError("Paid run claim requires the frozen C-MAPSS defense configuration")
    state_root, output_dir = Path(state_root), Path(output_dir)
    state_root.mkdir(parents=True, exist_ok=True)
    claim = state_root / "run-claim.json"
    value = {"profile": "cmapss-fd001-tree-defense-qwen35-4b-v1", "output": str(output_dir.resolve()),
             "model": config.llm_model,
             "input_price_per_million": config.llm_input_price_per_million,
             "output_price_per_million": config.llm_output_price_per_million,
             "config_sha256": fingerprint(DEFAULT_CONFIG)["sha256"],
             "package_manifest_sha256": fingerprint(package_manifest)["sha256"],
             **source_metadata()}
    try:
        with claim.open("x", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.write("\n")
    except FileExistsError:
        raise FileExistsError("C-MAPSS paid demo claim is single-use; no second run is allowed") from None
    return claim


def tokenizer_preflight(tokenizer_dir, model, observation, config):
    locked = verify_tokenizer_provenance(tokenizer_dir, model)
    from transformers import AutoTokenizer
    from ite.trio_client import build_messages
    tokenizer = AutoTokenizer.from_pretrained(str(tokenizer_dir), local_files_only=True,
                                              trust_remote_code=False)
    messages = build_messages(observation, model_type=config.model_type,
                              prompt_profile=config.llm_prompt_profile)
    prompt = tokenizer.apply_chat_template(messages, add_generation_prompt=True,
                                          tokenize=False, enable_thinking=False)
    inputs = len(tokenizer.encode(prompt, add_special_tokens=False))
    if inputs > config.llm_max_input_tokens:
        raise ValueError("input_token_limit")
    return {"local_tokenizer_input_tokens": inputs, "input_limit": config.llm_max_input_tokens,
            "prompt_profile": config.llm_prompt_profile, "model": model,
            "tokenizer_provenance": locked, "messages": messages}


def _verify_reference(path, manifest):
    events = [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]
    started = next((e for e in events if e.get("event") == "run_started"), None)
    observation = next((e for e in events if e.get("event") == "harness_observation" and e.get("step") == 10), None)
    decision = next((e for e in events if e.get("event") == "harness_decision" and e.get("step") == 10), None)
    candidate = next((e for e in events if e.get("event") == "candidate_evaluated" and e.get("step") == 10), None)
    rejected = next((e for e in events if e.get("event") == "experiment_rejected"
                     and e.get("step") == 10 and e.get("reason") == "not_better_on_selection"), None)
    config = started.get("config", {}) if started else {}
    stream = started.get("data_source", {}).get("stream", {}) if started else {}
    if (started is None or config.get("model_type") != "tree" or config.get("seed") != 7
            or config.get("n_batches") != 18
            or stream.get("sha256") != manifest["files"]["stream"]["sha256"]
            or observation is None or decision is None or decision.get("action") != "RETRAIN_SMALL"
            or candidate is None or candidate.get("train_samples") != 192 or rejected is None):
        raise ValueError("The frozen FD001 reference evidence for step 10 is incomplete")
    return {"observation": observation["observation"], "decision": decision,
            "candidate": candidate, "rejection": rejected,
            "events_sha256": fingerprint(path)["sha256"]}


def _parse_run(run_dir):
    events_path = Path(run_dir) / "drift/events.jsonl"
    events = [json.loads(line) for line in events_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    calls = [event for event in events if event.get("event") == "harness_call"
             and event.get("token_accounting_mode") == "real"]
    if len(calls) > 2:
        raise ValueError("Real Qwen call count exceeded the fixed two-call profile")
    ledger = json.loads((Path(run_dir) / "paid-call-ledger.json").read_text(encoding="utf-8"))
    if ledger.get("attempted_calls", 0) > 2:
        raise ValueError("Durable Qwen ledger exceeded the fixed two-call profile")
    reserved = sum((Decimal(item.get("reserved_cost_cny", "0")) for item in ledger.get("requests", [])
                    if item.get("status") == "reserved"), Decimal(0))
    used = Decimal(ledger.get("used_cost_cny", "0"))
    if used + reserved > Decimal("0.03"):
        raise ValueError("Durable Qwen ledger exceeded the fixed CNY budget")
    return events, calls, ledger


def append_live_report(run_dir, report_path=REPORT):
    events, calls, ledger = _parse_run(run_dir)
    summary_path = Path(run_dir) / "summary.json"
    summary = json.loads(summary_path.read_text(encoding="utf-8")) if summary_path.is_file() else {}
    predictions = [event for event in events if event.get("event") == "prediction"]
    versions = Counter(event.get("model_version") for event in predictions)
    prediction_samples = sum(event.get("samples", 0) for event in predictions)
    reserved_cost = sum((Decimal(item.get("reserved_cost_cny", "0"))
                         for item in ledger.get("requests", []) if item.get("status") == "reserved"), Decimal(0))
    settlement = (f"已结算费用¥{ledger.get('used_cost_cny', '0')}；未结算请求预留¥{reserved_cost}，最终扣费未知"
                  if reserved_cost else f"已结算费用¥{ledger.get('used_cost_cny', '0')}，无未结算请求")
    config_path = Path(run_dir) / "config.json"
    config = json.loads(config_path.read_text(encoding="utf-8")) if config_path.is_file() else {}
    run_date = datetime.now(timezone.utc).date().isoformat()
    lines = ["", f"## {run_date}：C-MAPSS Tree 防守决策 Demo（{config.get('llm_model', '以账本为准')}）", "",
        "本次为在同一公开FD001开发流上重放已冻结配置的Harness决策链路，不做性能调参或晋级；"
        "只用当前已释放Loss和历史筛选审计作为决策上下文。", "",
        f"本轮费率：Prefill ¥{config.get('llm_input_price_per_million', '以请求账本为准')}/M，"
        f"Sample ¥{config.get('llm_output_price_per_million', '以请求账本为准')}/M。", "",
        f"流完成：{sum(e.get('event') == 'prediction' for e in events)}/18批。真实请求："
        f"{ledger.get('attempted_calls', 0)}/2；{settlement}；"
        f"熔断状态：`{ledger.get('trip_reason')}`。", ""]
    if summary:
        version_text = ", ".join(f"v{version}: {count}批" for version, count in sorted(versions.items()))
        lines.extend([f"预测样本：{prediction_samples}；实际版本：{version_text or '无'}；"
                      f"训练尝试/部署/回滚：{summary.get('training_attempts')}/{summary.get('updates')}/{summary.get('rollbacks')}。", ""])
    if not calls:
        lines.extend(["没有向Qwen发出已记录请求；未生成Reason或响应JSON。", ""])
    for index, event in enumerate(calls, 1):
        parsed = event.get("parsed_action") if event.get("status") == "ok" else None
        lines.extend([f"### 请求 {index}", "", f"触发step：{event.get('step')}；客户端端到端延迟："
            f"{event.get('latency_seconds')}秒；状态：`{event.get('status')}`。", ""])
        request = next((item for item in ledger.get("requests", []) if item.get("call_id") == event.get("call_id")), None)
        if request and request.get("status") == "settled":
            lines.append(f"服务端Token：输入 {request['input_tokens']}、输出 {request['output_tokens']}，"
                         f"合计 {request['input_tokens'] + request['output_tokens']}；按配置费率估算¥{request['cost_cny']}（不是服务商扣款回执）。")
        else:
            reserved_cost = request.get("reserved_cost_cny") if request else event.get("llm_reserved_cost_cny")
            lines.append(f"Token用量未知（{event.get('status')}；没有服务端结算）；本次费用预留¥{reserved_cost}。")
        observation = next((e.get("observation") for e in events if e.get("event") == "harness_observation"
                            and e.get("step") == event.get("step")), None)
        lines.extend(["", "发送的Observation：", "", "```json",
                      json.dumps(observation, ensure_ascii=False, indent=2, allow_nan=False)
                      if observation is not None else "不可用", "```", ""])
        raw = event.get("raw_response")
        if raw is None:
            lines.extend(["原始响应JSON：没有响应JSON。", "", "Reason：未知，未收到可解析的Qwen响应。", ""])
        else:
            lines.extend(["原始响应JSON：", "", "```json", raw, "```", "",
                          f"Qwen结构化动作：`{parsed.get('action') if parsed else '无效/未解析'}`。",
                          f"Qwen Reason：{parsed.get('reason') if parsed else '无有效reason'}", ""])
        if parsed and parsed.get("action") == "DO_NOTHING":
            lines.extend(["本次Qwen选择DO_NOTHING，宿主没有为该决策启动重训；独立未来门控保持可用。"
                          "这只展示单次保守决策，不证明未运行候选必然更差，也不构成普遍因果结论。", ""])
    if any(e.get("event") == "budget_guard_tripped" and e.get("reason") == "client_timeout" for e in events):
        lines.append("15秒超时后触发Fail-Closed；客户端不重试，保留已部署模型完成剩余预测。")
    lines.extend(["本决策流不提供全流RMSE晋级结果；先前NR-022及原始对照保持冻结。",
                  "本次历史候选被拒绝属于筛选结果，不能改述为独立未来门控拒绝。", ""])
    section = "\n".join(lines)
    with Path(report_path).open("a", encoding="utf-8", newline="\n") as report:
        report.write(section)
    return {"decision_count": sum(e.get("raw_response") is not None for e in calls),
            "attempted_calls": ledger.get("attempted_calls", 0),
            "used_cost_cny": ledger.get("used_cost_cny", "0"),
            "trip_reason": ledger.get("trip_reason")}


def run_demo():
    config = ExperimentConfig.load(DEFAULT_CONFIG)
    package = DEFAULT_PACKAGE
    output = DEFAULT_OUTPUT
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite live Qwen output: {output}")
    manifest, files = _manifest(package)
    if (manifest["splits"]["train"]["rows"] != 11942
            or manifest["splits"]["validation"]["rows"] != 4196
            or manifest["splits"]["stream"]["rows"] != 4493
            or manifest["splits"]["stream"]["batches"] != 18):
        raise ValueError("Live Qwen demo requires the original FD001 package")
    reference = _verify_reference(REFERENCE_EVENTS, manifest)
    state_root = STATE_ROOT.resolve()
    ledger_path = (ROOT / config.llm_ledger_path).resolve()
    tokenizer = (ROOT / config.llm_tokenizer_path).resolve()
    if ledger_path != state_root / "call-ledger.json" or tokenizer != (ROOT / "deployment/tokenizer-qwen3.5-4b").resolve():
        raise ValueError("Live Qwen paths must match the fixed paid state and local tokenizer")
    if ledger_path.exists():
        raise FileExistsError("A durable C-MAPSS Qwen ledger already exists; no second allowance is available")
    preflight = tokenizer_preflight(tokenizer, config.llm_model, reference["observation"], config)
    claim_single_run(state_root, output, config, package / "manifest.json")
    output.mkdir(parents=True, exist_ok=False)
    write_json(output / "config.json", config.to_dict())
    write_json(output / "reference-evidence.json", reference)
    write_json(output / "tokenizer-preflight.json", preflight)
    write_json(output / "provenance.json", {**source_metadata(),
        "package_manifest": fingerprint(package / "manifest.json"),
        "config": fingerprint(DEFAULT_CONFIG), "reference_events": fingerprint(REFERENCE_EVENTS),
        "run_script": fingerprint(Path(__file__).resolve()), "live_model": config.llm_model,
        "input_price_per_million": config.llm_input_price_per_million,
        "output_price_per_million": config.llm_output_price_per_million,
        "tokenizer_manifest_sha256": preflight["tokenizer_provenance"]["manifest_sha256"],
        "max_calls": 2, "max_cost_cny": "0.03", "retry_policy": "none"})
    mapping = ColumnMapping(**manifest["column_mapping"])
    provider = PreparedDataProvider(files["stream"], mapping, initial_train_path=files["train"],
        initial_validation_path=files["validation"], label_delay=config.label_delay, max_labels=None)
    trainer = BoundedTrainer()
    try:
        summary = run_policy(config, "drift", output / "drift", trainer, provider=provider)
        write_json(output / "summary.json", summary)
    finally:
        trainer.close()
        if ledger_path.is_file():
            shutil.copyfile(ledger_path, output / "paid-call-ledger.json")
    report = append_live_report(output, REPORT)
    write_json(output / "live-audit.json", report)
    return {"summary": summary, "live_audit": report}


def main():
    result = run_demo()
    print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
