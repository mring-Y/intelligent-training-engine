"""Train-only cold/warm TreeModel timing for the prepared public datasets."""

import argparse
import json
import time
from pathlib import Path

import numpy as np

from ite.providers import ColumnMapping
from ite.training import BoundedTrainer
from scripts.data_prep.provider import PreparedDataProvider


def _measure(initial, task, class_labels, *, cold, runs, timeout_seconds, options):
    measurements = []
    trainers = [None] * runs if cold else [BoundedTrainer()]
    try:
        for index in range(runs):
            trainer = trainers[index] if cold else trainers[0]
            if cold:
                trainer = BoundedTrainer()
            started = time.perf_counter()
            result = trainer.fit(task, None, initial.train_x, initial.train_y, timeout_seconds,
                                 model_type="tree", tree_options=options,
                                 class_labels=class_labels, candidate=False)
            measurements.append({"run": index + 1, "status": result.status,
                                 "wall_seconds": time.perf_counter() - started,
                                 "reported_wall_seconds": result.wall_seconds,
                                 "timings": result.timings, "error": result.error})
            if cold:
                trainer.close()
    finally:
        if not cold:
            trainers[0].close()
    return measurements


def measure(package_root, *, timeout_seconds=15., runs=3):
    root = Path(package_root)
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    files = {name: root / entry["path"] for name, entry in manifest["files"].items()}
    provider = PreparedDataProvider(files["stream"], ColumnMapping(**manifest["column_mapping"]),
                                    initial_train_path=files["train"],
                                    initial_validation_path=files["validation"], label_delay=2)
    initial = provider.initial_data()
    task = "classification" if manifest["task"] == "multiclass" else manifest["task"]
    classes = manifest["metadata"].get("classes") if task == "classification" else None
    options = {"max_depth": 6, "min_samples_leaf": 5, "max_leaf_nodes": 64, "random_state": 7}
    return {"dataset": manifest["dataset"], "task": task, "train_samples": len(initial.train_y),
            "features": int(initial.train_x.shape[1]), "parameters": options,
            "cold": _measure(initial, task, classes, cold=True, runs=runs,
                             timeout_seconds=timeout_seconds, options=options),
            "warm": _measure(initial, task, classes, cold=False, runs=runs,
                             timeout_seconds=timeout_seconds, options=options)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", action="append", nargs=2, metavar=("NAME", "PATH"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--timeout-seconds", type=float, default=15.)
    parser.add_argument("--runs", type=int, default=3)
    args = parser.parse_args()
    results = {name: measure(path, timeout_seconds=args.timeout_seconds, runs=args.runs)
               for name, path in args.package}
    receipt = {"scope": "Train-only TreeModel engineering timing; no stream labels or model selection",
               "measurement_timeout_seconds": args.timeout_seconds, "runs": args.runs,
               "datasets": results, "python": __import__("platform").python_version(),
               "numpy": np.__version__}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(receipt, indent=2), encoding="utf-8")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
