"""One-factor C head epoch comparison using only official public/train gradients."""

import argparse
import hashlib
import json
import os
from pathlib import Path

import numpy as np

from ite.code_harness import digest, write_new
from ite.config import HEURISTIC_C_EPOCHS
from ite.heuristic_override import load_training_stream
from ite.official_model import OfficialModelAdapter
from ite.official_sft_data import DRIFT, NOTICE, SCENARIOS, load_public_package, split_sources
from ite.official_sft_replay import replay_partition
from ite.tracking import source_metadata
from scripts.run_heuristic_comparison import DECISION_STEPS, TOLERANCES, assess_metrics, score


ARMS = ("static", "no_control", "epoch1", "epoch2", "epoch3", "epoch5")


def summarize_predictions(arrays):
    groups = {}
    composite = {arm:{k:[] for k in ("targets", "active")} for arm in ARMS}
    for scenario in SCENARIOS:
        merged = {arm:{k:np.concatenate([arrays[scenario,split,arm][k] for split in ("train", "eval")])
                  for k in ("targets", "active", "static", "source_ids")} for arm in ARMS}
        for arm, values in merged.items():
            reference = merged["static"]
            if any(not np.array_equal(values[k],reference[k]) for k in ("targets", "source_ids", "static")):
                raise ValueError("Epoch arms must share the same IDs, targets and static predictions")
            if arm in ("static", "no_control") and not np.array_equal(values["active"],values["static"]):
                raise ValueError("Static and constant-NO controls must be identical")
            for k in ("targets", "active"):
                composite[arm][k].append(values[k])
        for split in ("train", "eval", "merged"):
            values = merged if split == "merged" else {arm:arrays[scenario,split,arm] for arm in ARMS}
            scores = {arm:score("C",v,"active") for arm,v in values.items()}
            groups[f"{scenario}-{split}"] = {"metrics":scores,
                "assessments":{arm:assess_metrics("C",scores["static"],scores[arm],"stable")
                               for arm in ARMS if arm.startswith("epoch")}}
    return groups, {arm:score("C",{k:np.concatenate(v) for k,v in values.items()},"active")
                    for arm,values in composite.items()}


def select_epoch(groups, composite, *, engineering_passed=True):
    candidates = {}
    eligible = []
    for epoch in HEURISTIC_C_EPOCHS:
        arm = f"epoch{epoch}"
        overall = assess_metrics("C",composite["static"],composite[arm],"abrupt")
        substantial = overall["primary_gain"] >= .01 * composite["static"]["rmse"]
        scenarios = {s:assess_metrics("C",groups[f"{s}-merged"]["metrics"]["static"],
                         groups[f"{s}-merged"]["metrics"][arm],"stable") for s in SCENARIOS}
        passed = bool(engineering_passed and overall["passed"] and substantial and
                      all(v["passed"] for v in scenarios.values()))
        candidates[arm] = {"passed":passed,"overall":overall,"substantial_primary_gain":bool(substantial),
                           "scenarios":scenarios}
        if passed:
            eligible.append((composite[arm]["rmse"],epoch))
    return {"selected_epoch":min(eligible)[1] if eligible else None,"candidates":candidates}


def run_comparison(output, runtime_python):
    root = Path(output)
    root.mkdir(parents=True,exist_ok=False)
    data = load_public_package("C")
    training = load_training_stream("C")
    partitions = split_sources(data)
    parent = OfficialModelAdapter("regression",runtime_python,profile_type="C",candidate_epochs=5)
    cases = [dict(profile="C",scenario=s,split=t,arm=a) for s in SCENARIOS
             for t in ("train", "eval") for a in ARMS]
    write_new(root/"freeze.json", {"source":source_metadata(),"runner_sha256":digest(__file__),
        "cases":cases,"epochs":HEURISTIC_C_EPOCHS,"drift":DRIFT,"tolerances":TOLERANCES,
        "candidate_seconds":5,"flow_training_seconds":20,"maximum_training_attempts":4,
        "decision_steps":DECISION_STEPS,"training_rows":len(training["ids"]),
        "training_source_ids_sha256":hashlib.sha256('\n'.join(training["ids"]).encode()).hexdigest(),
        "package_sha256":data["package_sha256"],"gradient_role":"official_public_train_only",
        "selection_rule":"eligible composite RMSE smallest; exact tie chooses fewer epochs; one epoch for all scenarios",
        "acceptance":"C composite RMSE >=1% improvement; each merged scenario nonworse and confirmed full-flow auxiliary tolerances",
        "control_notice":"deterministic constant-NO behavioral control, no new real sampler inference",
        "paid_calls":0,"hidden_test_evaluated":False,"independent_acceptance":False,
        "official_platform_protocol_verified":False,"notice":NOTICE})
    flows, arrays = {}, {}
    for case in cases:
        scenario, split, arm = (case[k] for k in ("scenario", "split", "arm"))
        epoch = int(arm.removeprefix("epoch")) if arm.startswith("epoch") else 5
        model = OfficialModelAdapter.from_state(parent.state())
        model.candidate_epochs = epoch
        name = f"C-{scenario}-{split}-{arm}"
        path = root/name
        summary = replay_partition(data,partitions[split],split,scenario,path,model,
            lambda _: {"action":"DO_NOTHING","reason":"Constant-NO behavioral control; not a new sampler reply.",
                       "source":"constant_no_behavior_control"}, decision_steps=DECISION_STEPS,
            action_profile="official_finetune",heuristic_override=arm.startswith("epoch"),training_stream=training)
        parent.save(path/"initial.npz")
        events = [json.loads(line) for line in (path/"events.jsonl").read_text(encoding="utf-8").splitlines()]
        allowed, validation = set(training["ids"]), set(data["ids"])
        for event in events:
            if event["event"] == "candidate_evaluated":
                assert set(event["train_source_ids"]) <= allowed
                assert not set(event["train_source_ids"]) & validation
                assert event["fit_audit"]["epochs_added"] == epoch
                assert event["fit_audit"]["trainable_parameters"] == 33
                assert event["fit_audit"]["max_parameter_delta"]["w1"] == 0.
                assert event["fit_audit"]["max_parameter_delta"]["b1"] == 0.
        with np.load(path/"predictions.npz",allow_pickle=False) as values:
            arrays[scenario,split,arm] = {k:values[k].copy() for k in values.files}
        flows[name] = {"case":case,"epochs":epoch,"summary":summary,
            "overrides":sum(e["event"] == "heuristic_override" for e in events),
            "evidence_sha256":{n:digest(path/n) for n in ("events.jsonl","summary.json","predictions.npz")}}
        print(f"{name}: RMSE={summary['active_metrics']['rmse']:.9f}; fits={summary['training_attempts']}; updates={summary['updates']}",flush=True)
    groups, composite = summarize_predictions(arrays)
    errors = [name for name,flow in flows.items() if any(record["rejection"] in
              ("candidate_training_error", "training_over_budget") for record in flow["summary"]["records"])]
    selection = select_epoch(groups,composite,engineering_passed=not errors)
    result = {"engineering_passed":not errors,"engineering_errors":errors,
        "effect_passed":selection["selected_epoch"] is not None,**selection,
        "physical_flows":len(cases),"groups":groups,"composite_development_metrics":composite,
        "flows":flows,"paid_calls":0,"real_llm_inference":False,"notice":NOTICE,
        "gradient_role":"official_public_train_only","tolerances":TOLERANCES,
        "freeze_sha256":digest(root/"freeze.json")}
    write_new(root/"comparison.json",result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path,required=True)
    parser.add_argument("--official-python",default=os.environ.get("ITE_OFFICIAL_RUNTIME_PYTHON",
        str(Path(__file__).resolve().parents[1]/".venv-official-a/Scripts/python.exe")))
    args = parser.parse_args()
    result = run_comparison(args.output,args.official_python)
    print(json.dumps({k:result[k] for k in ("engineering_passed","effect_passed","selected_epoch")}))
    return 0 if result["engineering_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
