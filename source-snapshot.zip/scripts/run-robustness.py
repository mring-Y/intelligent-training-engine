"""Development-only model and synthetic-factor comparisons; no hidden labels online."""

import argparse
from pathlib import Path

from ite.config import ExperimentConfig
from ite.report import aggregate_results, render_report, write_rows
from ite.runner import run_comparison
from ite.tracking import source_metadata, write_json

CASES = {
    "linear-stable": {"scenario": "stable"},
    "linear-abrupt": {"scenario": "abrupt"},
    "linear-recurring": {"scenario": "recurring"},
    "nonlinear-stable": {"scenario": "stable", "relationship": "nonlinear"},
    "nonlinear-abrupt": {"scenario": "abrupt", "relationship": "nonlinear"},
    "nonlinear-recurring": {"scenario": "recurring", "relationship": "nonlinear"},
    "imbalance": {"scenario": "abrupt", "class_threshold": 1.25},
    "outliers": {"scenario": "abrupt", "outlier_fraction": .05},
    "mild-drift": {"scenario": "abrupt", "drift_magnitude": .5},
    "mixed": {"scenario": "mixed"},
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.output
    if root.exists() and any(root.iterdir()):
        raise FileExistsError(root)
    root.mkdir(parents=True, exist_ok=True)
    base = ExperimentConfig.load(args.config)
    results = []
    for name, changes in CASES.items():
        for family in ("ridge", "quadratic"):
            for task in (("classification",) if name == "imbalance" else ("classification", "regression")):
                for seed in (7, 19, 43):
                    print(f"{name}/{family}/{task}/seed-{seed}", flush=True)
                    config = ExperimentConfig.from_dict({**base.to_dict(), **changes,
                                                          "model_family": family, "task": task, "seed": seed})
                    directory = root / name / family / task / f"seed-{seed}"
                    for row in run_comparison(config, directory, policies=("static", "drift")):
                        row = dict(row, experiment_group=f"{name}/{family}", synthetic_case=name)
                        row["curve_file"] = (directory / row["curve_file"]).relative_to(root).as_posix()
                        results.append(row)
    write_rows(root / "aggregates.csv", aggregate_results(results))
    render_report(root, results, title="开发种子：模拟因素与轻量模型对照")
    write_json(root / "config.json", {"base_config": base.to_dict(), "cases": CASES,
        "models": ["ridge", "quadratic"], "seeds": [7, 19, 43], **source_metadata()})
    print(f"Completed {len(results)} development runs", flush=True)


if __name__ == "__main__":
    main()
