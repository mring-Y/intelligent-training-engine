"""Exercise workspace-v2 stdin/stdout against the actual read-only Docker image.

The host and model replies are offline fixtures. CPU training and prediction
execute unchanged. This is protocol evidence on seen public data, not an
official model call, hidden-test evaluation or independent effect acceptance.
"""

import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import queue
import shutil
import subprocess
import sys
import threading
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))
from contest_host import OfflineHost, fixture, frame, rows


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n", encoding="utf-8")


def container_base(docker, image, name, *, mounts=(), environment=()):
    command = [docker, "run", "--name", name, "--network", "none", "--read-only",
        "--cpus", "4", "--memory", "4g", "--pids-limit", "256", "--cap-drop", "ALL",
        "--security-opt", "no-new-privileges", "--tmpfs", "/tmp:rw,noexec,nosuid,size=268435456",
        "--entrypoint", "python3", "-i"]
    for source, destination, readonly in mounts:
        command += ["--mount", f"type=bind,source={source.resolve()},target={destination}" + (",readonly" if readonly else "")]
    for key, value in environment:
        command += ["-e", f"{key}={value}"]
    return command + [image]


def prepare(root, profile):
    directory = root / profile
    directory.mkdir()
    parent, train, validation = fixture(directory, profile)
    data = directory / "data"
    data.mkdir()
    shutil.move(str(train), data / "train.jsonl")
    shutil.move(str(validation), data / "validation-1.jsonl")
    previous_fixture = ROOT / "outputs/continuation-adapter-20261116/fixtures-v1" / profile / "validation-2.jsonl"
    if previous_fixture.is_file():
        shutil.copyfile(previous_fixture, data / "validation-2.jsonl")
    else:
        values = rows(profile, "public/validation.jsonl")
        count = len(values) // 2 if profile == "A" else 512
        (data / "validation-2.jsonl").write_text("".join(json.dumps(row) + "\n" for row in values[count:count * 2]), encoding="utf-8")
    return directory, parent, data


def inspect(docker, name, destination):
    result = subprocess.run([docker, "inspect", name], capture_output=True, text=True, check=True)
    value = json.loads(result.stdout)[0]
    receipt = {"id": value["Id"], "image": value["Image"], "state": value["State"],
        "host_config": {key: value["HostConfig"].get(key) for key in (
            "ReadonlyRootfs", "NetworkMode", "NanoCpus", "Memory", "PidsLimit", "Tmpfs", "CapDrop", "SecurityOpt")},
        "mounts": [{key: item.get(key) for key in ("Source", "Destination", "RW")} for item in value["Mounts"]]}
    write_json(destination, receipt)
    if receipt["state"].get("OOMKilled"):
        raise AssertionError("container was OOM-killed")
    return receipt


def training_advanced(report):
    """Count the optimizer actually trained by the declared model architecture."""
    progressed = (report.get("final_module_steps",0)>report.get("initial_module_steps",0)
                  if report.get("module_policy") in ("input_adapter_v1","input_gate_v1") else report["final_steps"]>report["initial_steps"])
    return bool(progressed and report["checkpoint_sha256"]!=report["parent_checkpoint_sha256"])


def train_round(docker, image, name, round_root, parent, data, state, profile, index, history):
    round_root.mkdir()
    work = round_root / "workspace"
    work.mkdir()
    validation = data / f"validation-{1 if index % 2 else 2}.jsonl"
    start = frame(parent, data / "train.jsonl", validation, profile, index=index,
        artifact_id="baseline-" + profile if not history else history[-1]["selected_artifact_id"])
    start["task_contract"]["public_projection"].update(train_path="/data/train.jsonl", validation_path="/data/validation.jsonl")
    start["state_path"] = "/state" if state else None
    proposal = {"action": "RETAIN" if profile == "B" else "EXPERIMENT",
        "reason": "Offline host fixture asks to evaluate only the frozen CPU policy; no provider called."}
    selection = {"action": "SELECT_CANDIDATE", "reason": "Offline host fixture selects only an eligible measured candidate."}
    # The helper scores candidate files with real CPU predictions on this host.
    # Keep its source contract pointed at the exact mounted public validation.
    host = OfflineHost(start, [proposal, selection], history, candidate_id=f"candidate-{profile}-{index}")
    original_respond = host.respond

    def respond(request):
        if request["type"] == "model_request":
            assert "OFFICIAL_TASK_PROMPT_ATTACHED_ONLY_BY_HOST" not in json.dumps(request["messages"])
        if request["type"] == "candidate_request":
            start["task_contract"]["public_projection"]["validation_path"] = str(validation)
            try:
                original_respond(request)
            finally:
                start["task_contract"]["public_projection"]["validation_path"] = "/data/validation.jsonl"
        else:
            original_respond(request)

    mounts = [(parent, "/previous", True), (data / "train.jsonl", "/data/train.jsonl", True),
        (validation, "/data/validation.jsonl", True), (work, "/workspace", False)]
    if state:
        mounts.append((state, "/state", True))
    command = container_base(docker, image, name, mounts=mounts) + ["/app/harness.py", "train"]
    write_json(round_root / "start.json", start)
    write_json(round_root / "command.json", command)
    process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
        stderr=(round_root / "stderr.txt").open("w", encoding="utf-8"), text=True, encoding="utf-8", bufsize=1)
    lines = queue.Queue()
    def collect():
        for line in process.stdout:
            lines.put(line)
        lines.put(None)
    threading.Thread(target=collect, daemon=True).start()
    process.stdin.write(json.dumps(start, ensure_ascii=False) + "\n")
    process.stdin.flush()
    try:
        with (round_root / "stdout.jsonl").open("x", encoding="utf-8") as raw:
            while host.record is None:
                line = lines.get(timeout=180)
                if not line:
                    raise RuntimeError("participant closed stdout without round_complete")
                raw.write(line)
                request = json.loads(line)
                if request["type"] == "round_failed":
                    raise RuntimeError("participant round_failed: " + str(request))
                respond(request)
                while host.incoming:
                    process.stdin.write(host.readline())
                    process.stdin.flush()
        process.stdin.close()
        code = process.wait(timeout=20)
        if code != 0:
            raise RuntimeError(f"container exited {code}")
    finally:
        if process.poll() is None:
            process.kill()
            process.wait()
    receipt = inspect(docker, name, round_root / "container.json")
    assert receipt["host_config"]["ReadonlyRootfs"] is True
    assert receipt["host_config"]["NetworkMode"] == "none"
    assert len(host.calls) == 2 and host.record["model_call_ids"] == ["call-1", "call-2"]
    report = json.loads((work / "cpu-result/training.json").read_text(encoding="utf-8"))
    assert report["parent_checkpoint_sha256"] == hashlib.sha256((parent / "checkpoint.npz").read_bytes()).hexdigest()
    selected_parent = parent
    if host.candidates and host.record["selected_artifact_id"] == host.candidate_id:
        selected_parent = work / "cpu-result"
        assert training_advanced(report) and report["accepted_updates"] > 0
    write_json(round_root / "record.json", host.record)
    return selected_parent, work / "native-state", {"id": f"offline-{profile}-{index}", **host.record}, report


def prediction_check(docker, image, root, parent, profile):
    requests = [{"task": "classification" if profile == "A" else "regression", "inputs": row["inputs"]}
        for row in rows(profile, "public/validation.jsonl")[:3]]
    name = "ite-sdk-predict-" + profile.lower() + "-" + hashlib.sha256(str(root).encode()).hexdigest()[:7]
    context = {"protocol": "contest.predict-context.v1", "dataset_key": profile,
        "task": requests[0]["task"], "artifact": {"checkpoint_paths": ["checkpoint.npz"]}, "artifact_id": "selected"}
    command = container_base(docker, image, name, mounts=[(parent, "/model", True)],
        environment=[("CONTEST_ARTIFACT_PATH", "/model/checkpoint.npz"), ("CONTEST_PREDICTION_CONTEXT", json.dumps(context))])
    command += ["/app/harness.py", "predict"]
    stderr = (root / "prediction-stderr.txt").open("w", encoding="utf-8")
    process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
        stderr=stderr, text=True, encoding="utf-8", bufsize=1)
    response_queue = queue.Queue()
    threading.Thread(target=lambda: [response_queue.put(line) for line in process.stdout], daemon=True).start()
    actual = []
    try:
        for request in requests:
            process.stdin.write(json.dumps(request) + "\n")
            process.stdin.flush()
            actual.append(json.loads(response_queue.get(timeout=30)))
            assert process.poll() is None, "must respond before EOF"
        process.stdin.close()
        assert process.wait(timeout=10) == 0
    finally:
        if process.poll() is None:
            process.kill()
            process.wait()
        stderr.close()
    # Run the official CPU predictor in the same image and compare values.
    model_path = "/app/third_party/official_baselines/"
    from ite.official_model import OFFICIAL_PROFILES
    reference = [docker, "run", "--name", name + "-reference", "--network", "none", "--read-only",
        "--cpus", "4", "--memory", "4g", "--tmpfs", "/tmp:rw,noexec,size=268435456",
        "--mount", f"type=bind,source={parent.resolve()},target=/model,readonly", "--entrypoint",
        "/opt/ite-official-a/bin/python", "-i", image, "/app/ite/platform_predict_worker.py",
        model_path + OFFICIAL_PROFILES[profile]["package"], "/model/checkpoint.npz", profile, "0"]
    # Carry the selected C margin instead of claiming raw predictor equivalence.
    sidecar = parent / "checkpoint.npz.policy.json"
    if sidecar.is_file():
        reference[-1] = str(json.loads(sidecar.read_text())["safety_margin"])
    expected = subprocess.run(reference, input="".join(json.dumps(row) + "\n" for row in requests),
        capture_output=True, text=True, timeout=45, check=True)
    expected_values = [json.loads(line) for line in expected.stdout.splitlines()]
    assert actual == expected_values, (profile, actual, expected_values)
    inspect(docker, name, root / "prediction-container.json")
    write_json(root / "predictions.json", {"requests": requests, "actual": actual, "reference": expected_values,
        "identical": True, "answered_before_eof": True})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--image", required=True)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--docker", default="docker")
    parser.add_argument("--rounds", type=int, default=10, choices=range(1, 11))
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    all_results = []
    for profile in "ABC":
        directory, parent, data = prepare(args.output, profile)
        state, history = None, []
        for index in range(1, args.rounds + 1):
            suffix = hashlib.sha256(str(args.output.resolve()).encode()).hexdigest()[:7]
            name = f"ite-sdk-{suffix}-{profile.lower()}-{index}"
            parent, state, record, report = train_round(args.docker, args.image, name,
                directory / f"round-{index:02}", parent, data, state, profile, index, history)
            history.append(record)
            all_results.append({"profile": profile, "round_index": index,
                "parent_checkpoint_sha256": report["parent_checkpoint_sha256"],
                "cpu_selected_checkpoint_sha256": report["checkpoint_sha256"],
                "training_attempts": report["training_attempts"], "accepted_updates": report["accepted_updates"],
                "platform_selected_artifact_id": record["selected_artifact_id"],
                "call_ids": record["model_call_ids"], "fresh_validation_rows": report["fresh_validation_rows"]})
            print(profile, index, report["training_attempts"], record["selected_artifact_id"], flush=True)
        prediction_check(args.docker, args.image, directory, parent, profile)
    write_json(args.output / "summary.json", {"purpose": __doc__, "image": args.image, "rounds": all_results,
        "real_provider_calls": 0, "official_hidden_evaluation": False, "passed": True})


if __name__ == "__main__":
    main()
