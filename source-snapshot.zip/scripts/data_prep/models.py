"""Compatibility import for the original public-data static baseline."""

from ite.multiclass import OneVsRestRidge

__all__ = ["OneVsRestRidge"]
