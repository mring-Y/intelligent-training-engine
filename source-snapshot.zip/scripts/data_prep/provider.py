"""Use existing file-provider gates with CSV initial files and a Parquet stream."""

from ite.providers import CSVDataProvider, ParquetDataProvider


class PreparedDataProvider(ParquetDataProvider):
    def _read_rows(self, path, initial=False):
        if path.suffix.lower() == ".csv":
            yield from CSVDataProvider._read_rows(self, path, initial=initial)
        elif path.suffix.lower() == ".parquet":
            yield from super()._read_rows(path, initial=initial)
        else:
            raise ValueError("Prepared files must be CSV or Parquet")
