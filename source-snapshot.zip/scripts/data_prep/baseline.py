"""Static, fixed-alpha public A baseline; targets are scored after prediction commits."""

import argparse
import json
import math
import time
from pathlib import Path

import numpy as np
import pyarrow.parquet as pq

from ite.models import RidgeModel
from ite.providers import ColumnMapping
from ite.tracking import source_metadata
from ite.training import BoundedTrainer

from .common import fingerprint, write_json
from .models import OneVsRestRidge
from .provider import PreparedDataProvider


def _metrics(task, targets, predictions, classes=None):
    if len(targets) != len(predictions) or not len(targets) or not np.isfinite(targets).all():
        raise ValueError("Scoring needs matching finite targets and predictions")
    if task == "regression":
        residual = predictions - targets
        return {"samples": len(targets), "rmse": float(np.sqrt(np.mean(residual ** 2))),
                "mae": float(np.mean(np.abs(residual)))}
    classes = np.asarray(classes)
    if not np.isin(targets, classes).all() or not np.isin(predictions, classes).all():
        raise ValueError("Unknown class encountered during scoring")
    confusion = [[int(np.sum((targets == actual) & (predictions == predicted))) for predicted in classes]
                 for actual in classes]
    return {"samples": len(targets), "accuracy": float(np.mean(targets == predictions)),
            "classes": classes.tolist(), "confusion_matrix": confusion}


def _verified_files(package, manifest):
    files = {}
    for split in ("train", "validation", "stream"):
        entry = manifest["files"][split]
        path = (package / entry["path"]).resolve()
        if not path.is_relative_to(package.resolve()):
            raise ValueError("Package file leaves its root")
        actual = fingerprint(path)
        if actual["sha256"] != entry["sha256"] or actual["bytes"] != entry["bytes"]:
            raise ValueError(f"Prepared {split} does not match its source manifest")
        files[split] = path
    return files


def run_baseline(package_dir, output_dir, *, alpha=1.0, model_type="ridge",
                 tree_options=None, tree_timeout_seconds=5.0):
    package, output = Path(package_dir), Path(output_dir)
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite baseline results: {output}")
    if model_type not in ("ridge", "tree"):
        raise ValueError("Unsupported baseline model type")
    if (isinstance(tree_timeout_seconds, bool) or not isinstance(tree_timeout_seconds, (int, float))
            or not math.isfinite(tree_timeout_seconds) or not 0 < tree_timeout_seconds <= 5):
        raise ValueError("Tree training timeout must be finite and in (0, 5]")
    manifest = json.loads((package / "manifest.json").read_text(encoding="utf-8"))
    files = _verified_files(package, manifest)
    task = manifest["task"]
    if task not in ("regression", "classification", "multiclass"):
        raise ValueError("Unsupported prepared task")
    mapping = ColumnMapping(**manifest["column_mapping"])
    provider = PreparedDataProvider(files["stream"], mapping,
                                    initial_train_path=files["train"],
                                    initial_validation_path=files["validation"], label_delay=2, max_labels=None)
    initial = provider.initial_data()
    classes = manifest["metadata"].get("classes", [0, 1]) if task != "regression" else None
    tree = model_type == "tree"
    effective_alpha = None if tree else alpha
    options = dict(max_depth=6, min_samples_leaf=5, max_leaf_nodes=64, random_state=7)
    options.update(tree_options or {})
    model = None if tree else (OneVsRestRidge(alpha, classes) if task == "multiclass" else RidgeModel(task, alpha))
    output.mkdir(parents=True, exist_ok=False)
    started = time.perf_counter()
    predictions, sample_ids, offsets, batches = [], [], [0], []
    probabilities = []
    with (output / "events.jsonl").open("x", encoding="utf-8", newline="\n") as log:
        def event(name, step, **values):
            log.write(json.dumps({"event": name, "step": step, **values}, allow_nan=False) + "\n")
            log.flush()

        event("run_started", -1, dataset=manifest["dataset"], policy="static", alpha=effective_alpha,
              **({"model_type": "tree", "tree_options": options,
                  "tree_timeout_seconds": tree_timeout_seconds} if tree else {}),
              source=source_metadata(), package_manifest=fingerprint(package / "manifest.json"),
              implementation=[fingerprint(Path(__file__).with_name(name))
                              for name in ("baseline.py", "models.py", "provider.py", "common.py")])
        training_started = time.perf_counter()
        training_phases = None
        if tree:
            with BoundedTrainer() as trainer:
                trained = trainer.fit("classification" if task == "multiclass" else task, None,
                    initial.train_x, initial.train_y, tree_timeout_seconds, model_type="tree",
                    tree_options=options, class_labels=classes, candidate=False)
            if trained.status != "ok" or trained.model is None:
                event("run_failed", -1, reason="initial_tree_training_failed", status=trained.status,
                      wall_seconds=trained.wall_seconds, error=trained.error)
                raise RuntimeError(f"Initial tree training failed: {trained.status}: {trained.error}")
            model = trained.model
            training_phases = trained.timings
        else:
            model.fit(initial.train_x, initial.train_y)
        train_seconds = time.perf_counter() - training_started
        validation = _metrics(task, initial.validation_y, model.predict(initial.validation_x), classes)
        model.save(output / "initial.npz")
        event("initial_training", -1, samples=len(initial.train_y), wall_seconds=train_seconds,
              validation=validation, **({"training_phases": training_phases} if tree else {}))
        predict_seconds = 0.0
        for batch in provider.iter_batches():
            before = time.perf_counter()
            prediction = model.predict(batch.features)
            if tree and task != "regression":
                probabilities.append(model.predict_proba(batch.features))
            predict_seconds += time.perf_counter() - before
            provider.commit_predictions(batch.step, batch.sample_ids, prediction)
            predictions.append(np.asarray(prediction))
            sample_ids.append(batch.sample_ids.copy())
            offsets.append(offsets[-1] + len(prediction))
            batches.extend([batch.step] * len(prediction))
            event("prediction", batch.step, samples=len(prediction), model_version=0)
        if len(predictions) != len(provider.batch_sizes):
            raise ValueError("Provider did not complete the declared stream")
        prediction = np.concatenate(predictions)
        ids = np.concatenate(sample_ids)
        saved = dict(predictions=prediction, sample_ids=ids, batch_offsets=np.asarray(offsets))
        if probabilities:
            saved.update(probabilities=np.concatenate(probabilities), class_labels=np.asarray(classes))
        np.savez_compressed(output / "predictions.npz", **saved)
        # Recheck immutable sources before the isolated, post-run scoring read.
        _verified_files(package, manifest)
        scored_ids, targets = [], []
        parquet = pq.ParquetFile(files["stream"])
        try:
            for batch in parquet.iter_batches(columns=[mapping.sample_id, mapping.target], use_threads=False):
                values = batch.to_pydict()
                scored_ids.extend(values[mapping.sample_id])
                targets.extend(values[mapping.target])
        finally:
            parquet.close()
        if not np.array_equal(ids, scored_ids):
            raise ValueError("Post-run scoring rows do not align with committed predictions")
        targets = np.asarray(targets)
        test = _metrics(task, targets, prediction, classes)
        event("offline_scoring", len(predictions), samples=len(targets))
        result = {"dataset": manifest["dataset"], "task": task, "policy": "static", "alpha": effective_alpha,
                  "model": "decision_tree" if tree else ("one_vs_rest_ridge" if task == "multiclass" else "ridge"),
                  "target_unit": manifest["metadata"].get("target_unit"),
                  "initial_train_samples": len(initial.train_y), "validation": validation, "test": test,
                  "stream_batches": len(predictions), "initial_train_seconds": train_seconds,
                  "prediction_seconds": predict_seconds, "wall_seconds": time.perf_counter() - started,
                  "real_llm_tokens": 0, "mock_calls": 0, "updates": 0,
                  "package_manifest": fingerprint(package / "manifest.json")}
        if tree:
            result.update(model_type="tree", tree_options=options, tree_timeout_seconds=tree_timeout_seconds,
                          training_phases=training_phases)
        event("run_completed", len(predictions), **result)
    write_json(output / "summary.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--alpha", type=float, default=1.0)
    parser.add_argument("--model-type", choices=("ridge", "tree"), default="ridge")
    parser.add_argument("--tree-timeout-seconds", type=float, default=5.0)
    args = parser.parse_args()
    print(json.dumps(run_baseline(args.package, args.output, alpha=args.alpha, model_type=args.model_type,
                                 tree_timeout_seconds=args.tree_timeout_seconds), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
