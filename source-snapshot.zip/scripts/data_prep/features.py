"""NumPy-only vibration summaries; every calculation uses one waveform window."""
from __future__ import annotations

import math

import numpy as np


STATISTICS = ("rms", "peak_to_peak", "kurtosis", "envelope_peak_hz")
FEATURE_NAMES = tuple(f"ch{channel}_{name}" for channel in (1, 2) for name in STATISTICS)


def _positive_rate(value: float) -> float:
    rate = float(value)
    if not math.isfinite(rate) or rate <= 0:
        raise ValueError("sampling rate must be finite and positive")
    return rate


def signal_features(signal: np.ndarray, *, sample_rate: float) -> dict[str, float]:
    """RMS, range, Pearson kurtosis and dominant non-DC analytic-envelope Hz.

    Constant signals have kurtosis and envelope frequency zero. The kurtosis is
    the central fourth moment divided by variance squared (Gaussian value 3),
    without a small-sample bias correction. No scaler or population fit is used.
    """
    rate = _positive_rate(sample_rate)
    values = np.asarray(signal, dtype=np.float64)
    if values.ndim != 1 or values.size < 2 or not np.isfinite(values).all():
        raise ValueError("signal must contain at least two finite scalar samples")
    centered = values - np.mean(values)
    variance = float(np.mean(centered ** 2))
    kurtosis = float(np.mean(centered ** 4) / variance ** 2) if variance > 0 else 0.0
    # Standard discrete Hilbert multiplier: keep DC/Nyquist and double positive
    # Fourier bins. This produces the analytic signal, not rectified vibration.
    multiplier = np.zeros(values.size)
    multiplier[0] = 1.0
    if values.size % 2 == 0:
        multiplier[1:values.size // 2] = 2.0
        multiplier[values.size // 2] = 1.0
    else:
        multiplier[1:(values.size + 1) // 2] = 2.0
    envelope = np.abs(np.fft.ifft(np.fft.fft(values) * multiplier))
    envelope = envelope - np.mean(envelope)
    spectrum = np.abs(np.fft.rfft(envelope))
    # Roundoff in a pure sinusoid must not create a fictitious envelope peak.
    tolerance = np.finfo(float).eps * values.size * max(1.0, float(np.max(np.abs(values)))) * 16
    peak = int(np.argmax(spectrum[1:])) + 1 if float(np.max(spectrum[1:])) > tolerance else 0
    result = {
        "rms": float(np.sqrt(np.mean(values ** 2))),
        "peak_to_peak": float(np.ptp(values)),
        "kurtosis": kurtosis,
        "envelope_peak_hz": float(peak * rate / values.size),
    }
    if not all(math.isfinite(value) for value in result.values()):
        raise ValueError("signal statistics exceed finite floating-point range")
    return result


def extract_features(window: np.ndarray, *, sample_rate: float) -> dict[str, float]:
    """Return exactly eight named features from a time-by-two-channel window."""
    values = np.asarray(window, dtype=np.float64)
    if values.ndim != 2 or values.shape[1] != 2:
        raise ValueError("bearing window must have exactly two vibration channels")
    return {
        f"ch{channel + 1}_{name}": value
        for channel in range(2)
        for name, value in signal_features(values[:, channel], sample_rate=sample_rate).items()
    }


def resample_signal(signal: np.ndarray, *, source_rate: float, target_rate: float) -> np.ndarray:
    """Windowed-sinc anti-alias filtering followed by time-grid interpolation.

    The symmetric Hann-windowed FIR uses 32 input-sample lobes per decimation
    factor, unity DC gain and cutoff 0.45 times the lower sampling rate. Reflect
    padding removes zero-padding edge loss; interpolation is deterministic and
    uses no fitted state. At the native rate this returns an independent copy.
    """
    source = _positive_rate(source_rate)
    target = _positive_rate(target_rate)
    values = np.asarray(signal, dtype=np.float64)
    if values.ndim not in (1, 2) or values.shape[0] < 2 or not np.isfinite(values).all():
        raise ValueError("resampling requires finite time-ordered samples")
    if source == target:
        return values.copy()
    ratio = target / source
    count = int(math.floor(values.shape[0] * ratio + 1e-10))
    if count < 2:
        raise ValueError("resampling would leave fewer than two samples")
    cutoff = .45 * min(1.0, ratio)
    half_width = int(math.ceil(32 / min(1.0, ratio)))
    offsets = np.arange(-half_width, half_width + 1, dtype=np.float64)
    kernel = 2 * cutoff * np.sinc(2 * cutoff * offsets) * np.hanning(offsets.size)
    kernel /= np.sum(kernel)
    matrix = values[:, None] if values.ndim == 1 else values
    grid = np.arange(count, dtype=np.float64) / ratio
    original_grid = np.arange(values.shape[0], dtype=np.float64)
    columns = []
    for column in matrix.T:
        padded = np.pad(column, (half_width, half_width), mode="reflect")
        filtered = np.convolve(padded, kernel, mode="valid")
        columns.append(np.interp(grid, original_grid, filtered))
    result = np.column_stack(columns)
    return result[:, 0] if values.ndim == 1 else result
