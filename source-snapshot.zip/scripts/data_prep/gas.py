"""Six-class UCI Gas: batch 1 initialization; batches 2 onward remain chronological."""

import argparse
import io
import re
import zipfile
from pathlib import Path

import numpy as np

from .common import download_file, export_dataset, fingerprint

SOURCE_URL = "https://archive.ics.uci.edu/static/public/224/gas+sensor+array+drift+dataset.zip"
FEATURES = tuple(f"gas_{index:03d}" for index in range(1, 129))


def _sources(source):
    source = Path(source)
    found = {}

    def add(name, payload):
        match = re.fullmatch(r"batch(\d+)\.dat", Path(name).name, re.IGNORECASE)
        if match:
            batch = int(match.group(1))
            if batch in found:
                raise ValueError(f"Duplicate Gas source batch {batch}")
            found[batch] = payload.decode("utf-8-sig")

    if source.is_dir():
        for path in sorted(source.rglob("*.dat")):
            add(path.name, path.read_bytes())
        hashes = [fingerprint(path) for path in sorted(source.rglob("*.dat"))]
    else:
        hashes = [fingerprint(source)]
        with zipfile.ZipFile(source) as archive:
            for member in archive.namelist():
                if member.lower().endswith(".dat"):
                    add(member, archive.read(member))
                elif member.lower().endswith(".zip"):
                    with zipfile.ZipFile(io.BytesIO(archive.read(member))) as nested:
                        for child in nested.namelist():
                            if child.lower().endswith(".dat"):
                                add(child, nested.read(child))
    if len(found) < 2 or sorted(found) != list(range(1, max(found, default=0) + 1)):
        raise ValueError("Gas requires contiguous source batches starting at 1")
    return found, hashes


def prepare_gas(source, output_dir, *, seed=7, validation_fraction=0.2, expected_batches=10):
    if not 0 < validation_fraction < 1:
        raise ValueError("Validation fraction must be between zero and one")
    sources, hashes = _sources(source)
    if type(expected_batches) is not int or expected_batches < 2 or len(sources) != expected_batches:
        raise ValueError(f"Gas requires all {expected_batches} expected source batches")
    batches = {}
    for batch, text in sorted(sources.items()):
        rows = []
        for line_number, line in enumerate(text.splitlines(), 1):
            if not line.strip():
                continue
            tokens = line.split()
            try:
                label = int(tokens[0])
                if label not in range(1, 7):
                    raise ValueError("Gas labels must be the original six classes 1..6")
                values = dict.fromkeys(FEATURES, 0.0)
                seen = set()
                for token in tokens[1:]:
                    index, value = token.split(":")
                    index = int(index)
                    if index in seen or index not in range(1, 129):
                        raise ValueError("Duplicate or out-of-range feature index")
                    seen.add(index)
                    values[FEATURES[index - 1]] = float(value)
            except (ValueError, IndexError) as error:
                raise ValueError(f"Invalid Gas batch {batch} line {line_number}: {error}") from error
            rows.append({**values, "target": label, "source_batch": batch,
                         "source_row": line_number, "batch_id": max(0, batch - 2)})
        if not rows:
            raise ValueError(f"Gas source batch {batch} is empty")
        batches[batch] = rows
    rng = np.random.default_rng(seed)
    validation_indices = set()
    for label in range(1, 7):
        indices = [i for i, row in enumerate(batches[1]) if row["target"] == label]
        if len(indices) < 2:
            raise ValueError("Initial Gas batch must contain at least two samples per class")
        count = min(len(indices) - 1, max(1, int(round(len(indices) * validation_fraction))))
        validation_indices.update(map(int, rng.choice(indices, count, replace=False)))
    train = [dict(row, batch_id=0) for i, row in enumerate(batches[1]) if i not in validation_indices]
    validation = [dict(row, batch_id=0) for i, row in enumerate(batches[1]) if i in validation_indices]
    return export_dataset(output_dir, dataset="uci_gas", task="multiclass", features=FEATURES,
                          train_rows=train, val_rows=validation,
                          stream_rows=[row for batch in sorted(batches) if batch > 1 for row in batches[batch]],
                          metadata={"source_url": "https://archive.ics.uci.edu/dataset/224/gas",
                                    "license": "CC BY 4.0", "source_files": hashes,
                                    "classes": list(range(1, 7)), "seed": seed,
                                    "validation_fraction": validation_fraction,
                                    "initial_source_batch": 1, "stream_source_batches": sorted(batches)[1:],
                                    "complete_public_dataset": expected_batches == 10,
                                    "within_batch_time_available": False,
                                    "split": "stratified within initial batch only; later batches never shuffled"})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, help="Existing original ZIP or directory of batch*.dat")
    parser.add_argument("--download-to", type=Path, help="Download original UCI ZIP to this immutable file")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=7)
    args = parser.parse_args()
    source = args.source
    if source is None:
        if args.download_to is None:
            parser.error("Supply --source or --download-to")
        source = download_file(SOURCE_URL, args.download_to)
    manifest = prepare_gas(source, args.output, seed=args.seed)
    print({"dataset": manifest["dataset"], "splits": manifest["splits"]})


if __name__ == "__main__":
    main()
