"""Prepare engine-isolated FD001 RUL packages from complete NASA train runs.

Only ``train_FD001.txt`` is accepted: the published test trajectories are
right-censored and their last observations must never be given zero RUL.
"""

import argparse
import json
import math
from pathlib import Path
from urllib.parse import urlparse


# Current NASA PCoE repository page links this archive (2026-11-10).
OFFICIAL_URL = ("https://phm-datasets.s3.amazonaws.com/NASA/"
                "6.+Turbofan+Engine+Degradation+Simulation+Data+Set.zip")
FEATURES = tuple([f"setting_{index}" for index in range(1, 4)] +
                 [f"sensor_{index}" for index in range(1, 22)])


def _training_file(source):
    source = Path(source)
    if source.is_dir():
        candidates = sorted(path for path in source.rglob("*")
                            if path.is_file() and path.name.lower() == "train_fd001.txt")
        if len(candidates) != 1:
            raise ValueError("Source directory must contain exactly one unambiguous train_FD001.txt")
        source = candidates[0]
    if source.name.lower() != "train_fd001.txt":
        raise ValueError("Only full run-to-failure train_FD001.txt is supported; censored test is reserved")
    if not source.is_file():
        raise FileNotFoundError(source)
    return source


def _positive_integer(value, name):
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a positive integer")
    try:
        number = int(str(value))
    except (TypeError, ValueError):
        raise ValueError(f"{name} must be a positive integer") from None
    if not 0 < number <= 2 ** 63 - 1:
        raise ValueError(f"{name} must fit positive int64")
    return number


def _read_trajectories(path):
    trajectories = {}
    previous_unit = 0
    with path.open(encoding="ascii") as stream:
        for line_number, line in enumerate(stream, 1):
            tokens = line.split()
            if not tokens:
                continue
            if len(tokens) != 26:
                raise ValueError(f"Line {line_number}: expected exactly 26 columns, got {len(tokens)}")
            unit = _positive_integer(tokens[0], f"unit at line {line_number}")
            cycle = _positive_integer(tokens[1], f"cycle at line {line_number}")
            if unit < previous_unit:
                raise ValueError(f"Line {line_number}: engines must appear in ascending unit order")
            rows = trajectories.setdefault(unit, [])
            if cycle != len(rows) + 1:
                raise ValueError(f"Line {line_number}: engine cycles must be contiguous from 1 in order")
            try:
                values = [float(token) for token in tokens[2:]]
            except ValueError:
                raise ValueError(f"Line {line_number}: feature columns must be numeric") from None
            rows.append({"unit_id": unit, "cycle": cycle, **dict(zip(FEATURES, values))})
            previous_unit = unit
    if not trajectories:
        raise ValueError("The training source is empty; no complete trajectory was found")
    return trajectories


def _partitions(trajectories, train_units, val_units, stream_units):
    defaults = {"train": range(1, 61), "val": range(61, 81), "stream": range(81, 101)}
    selected = {}
    for name, units in (("train", train_units), ("val", val_units), ("stream", stream_units)):
        if units is None:
            units = defaults[name]
        try:
            values = [_positive_integer(unit, f"{name} unit") for unit in units]
        except TypeError:
            raise ValueError(f"{name} units must be an explicit nonempty iterable") from None
        if not values or len(values) != len(set(values)):
            raise ValueError(f"{name} units must be nonempty and contain no duplicates")
        selected[name] = sorted(values)
    flattened = [unit for units in selected.values() for unit in units]
    if len(flattened) != len(set(flattened)):
        raise ValueError("Train, validation and stream unit partitions must be disjoint")
    if set(flattened) != set(trajectories):
        unknown = sorted(set(flattened) - set(trajectories))
        unassigned = sorted(set(trajectories) - set(flattened))
        raise ValueError(f"Unit partitions must cover the source exactly: missing units={unknown}; "
                         f"unassigned units={unassigned}. A partial source needs explicit partitions.")
    return selected


def prepare_cmapss(source, output_dir, *, subset="FD001", rul_cap=125.0,
                   train_units=None, val_units=None, stream_units=None, batch_size=256):
    """Export complete FD001 training trajectories without splitting an engine.

    Three operating settings and all 21 sensors are predictors. Cycle and unit
    are audit metadata only. Default unit groups are 1–60 / 61–80 / 81–100.
    Explicit groups may describe a smaller source but must cover it exactly.
    """
    if subset != "FD001":
        raise ValueError("This approved preparer supports only the FD001 subset")
    try:
        cap = float(rul_cap)
    except (TypeError, ValueError):
        raise ValueError("RUL cap must be finite and positive") from None
    if not math.isfinite(cap) or cap <= 0 or isinstance(rul_cap, bool):
        raise ValueError("RUL cap must be finite and positive")
    path = _training_file(source)
    trajectories = _read_trajectories(path)
    partitions = _partitions(trajectories, train_units, val_units, stream_units)
    split_rows = {}
    for split, units in partitions.items():
        split_rows[split] = []
        for unit in units:
            trajectory = trajectories[unit]
            last_cycle = trajectory[-1]["cycle"]
            for row in trajectory:
                split_rows[split].append({**row, "target": min(cap, last_cycle - row["cycle"])})

    # Keep parsing usable while the shared exporter is developed independently.
    from .common import export_dataset, fingerprint

    source_fingerprint = fingerprint(path)
    receipt_path = path.with_suffix(path.suffix + ".source.json")
    source_receipt = None
    if receipt_path.exists():
        source_receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
        if not isinstance(source_receipt, dict) or source_receipt.get("sha256") != source_fingerprint["sha256"]:
            raise ValueError("Source receipt SHA-256 does not match raw training bytes")
    metadata = {
        "source": source_fingerprint,
        "source_kind": "NASA C-MAPSS FD001 run-to-failure training trajectories",
        "subset": subset,
        "target_unit": "cycles",
        "target": {"units": "cycles", "formula": "min(rul_cap, max_cycle(unit) - cycle)",
                   "rul_cap": cap, "endpoint": "recorded run-to-failure endpoint"},
        "split_units": partitions,
        "unit_cycle_counts": {str(unit): len(rows) for unit, rows in trajectories.items()},
        "ordering": ["unit_id ascending", "cycle ascending within complete engine"],
        "excluded_from_predictors": ["unit_id", "cycle", "sample_id", "batch_id", "target"],
        "published_censored_test_reserved": True,
        "coverage": {"units": len(trajectories), "rows": sum(map(len, trajectories.values())),
                     "split_rows": {name: len(rows) for name, rows in split_rows.items()}},
        "limitations": ["Public FD001 training-unit partitions are development data, not official hidden test results.",
                        "A training filename declares run-to-failure semantics; file content alone cannot prove the physical endpoint."],
    }
    if source_receipt is not None:
        metadata["source_provenance"] = source_receipt
    return export_dataset(output_dir, dataset="cmapss_fd001", task="regression", features=FEATURES,
                          train_rows=split_rows["train"], val_rows=split_rows["val"],
                          stream_rows=split_rows["stream"], metadata=metadata, batch_size=batch_size)


def _cli_units(value):
    try:
        return [_positive_integer(token, "partition unit") for token in value.split(",")]
    except ValueError as error:
        raise argparse.ArgumentTypeError(str(error)) from error


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sources = parser.add_mutually_exclusive_group(required=True)
    sources.add_argument("--source", type=Path, help="Local train_FD001.txt or its directory")
    sources.add_argument("--download", action="store_true", help="Acquire a raw NASA archive or an explicit mirror URL")
    parser.add_argument("--url", default=OFFICIAL_URL, help="Download URL; record mirror provenance separately")
    parser.add_argument("--raw-dir", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--subset", default="FD001")
    parser.add_argument("--rul-cap", type=float, default=125.0)
    parser.add_argument("--train-units", type=_cli_units)
    parser.add_argument("--val-units", type=_cli_units)
    parser.add_argument("--stream-units", type=_cli_units)
    parser.add_argument("--batch-size", type=int, default=256)
    arguments = parser.parse_args(argv)
    source = arguments.source
    if arguments.download:
        from .common import download_file, extract_zip

        raw_dir = arguments.raw_dir or arguments.output.parent / "raw" / "cmapss"
        raw_dir.mkdir(parents=True, exist_ok=True)
        if urlparse(arguments.url).path.lower().endswith(".txt"):
            source = download_file(arguments.url, raw_dir / "train_FD001.txt")
        else:
            archive = download_file(arguments.url, raw_dir / "CMAPSSData.zip")
            source = extract_zip(archive, raw_dir / "extracted")
    manifest = prepare_cmapss(source, arguments.output, subset=arguments.subset,
                              rul_cap=arguments.rul_cap, train_units=arguments.train_units,
                              val_units=arguments.val_units, stream_units=arguments.stream_units,
                              batch_size=arguments.batch_size)
    print(json.dumps(manifest, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
