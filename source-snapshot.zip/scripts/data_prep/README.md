# Public development A package

The user selected UCI Gas, XJTU-SY and C-MAPSS as the development A data on 2026-11-10. These commands prepare public datasets; they do not supply the competition SDK, official scoring protocol or hidden B stream. Run from the repository root with the fixed project environment. NumPy 2.3.5 and PyArrow 22.0.0 are already in the runtime lock; no new dependency is needed.

Each command requires a new output directory and produces `train.csv`, `val.csv`, `test_stream.parquet`, and `manifest.json`. All raw data, source receipts, derived features and experimental output belong under ignored `outputs/`, which the Docker context also excludes. Source downloads have URL, SHA-256 and byte receipts. The manifest lists explicit ordered features and relative prepared file paths; raw-source original locations are informational audit fields.

## UCI Gas

```powershell
.\.venv\Scripts\python.exe -m scripts.data_prep.gas `
  --download-to outputs/my-A/raw/gas.zip --output outputs/my-A/prepared/gas
```

Or use `--source <existing ZIP or extracted directory>`. The canonical public dataset must contain all ten nonempty `batch*.dat` files and labels 1–6. All 128 features are retained. Only batch 1 is split, by fixed seed 7 and per-class 20% validation; original row order is preserved after the split. Source batches 2–10 remain the nine chronological stream batches. No within-batch timestamps are invented. Sparse omitted feature indices retain their SVMlight meaning of zero.

## C-MAPSS FD001

```powershell
.\.venv\Scripts\python.exe -m scripts.data_prep.cmapss `
  --source outputs/my-A/raw/cmapss/train_FD001.txt `
  --output outputs/my-A/prepared/cmapss_fd001
```

`--download --raw-dir <directory> --url <archive or train_FD001.txt URL>` also supports acquisition. The legacy NASA link can fail DNS; use the source receipt from the current experiment when reproducing its explicitly identified mirror. An arbitrary file with the expected filename is not proof of authenticity.

Use the complete run-to-failure **training** trajectories. Fixed unit IDs 1–60 / 61–80 / 81–100 become train / validation / development stream. Preserve unit order and cycle order; the three operating settings and 21 sensors are predictors, while unit and cycle are metadata. RUL is `min(125, last_cycle_of_unit - cycle)` in cycles. Censored published test files and their endpoint labels remain reserved and are never treated as complete lifetimes. The first real experiment has 18 stream batches of at most 256 observations.

## XJTU-SY bearing RUL

```powershell
.\.venv\Scripts\python.exe -m scripts.data_prep.bearing `
  --source outputs/my-A/raw/xjtu_sy/extracted `
  --output outputs/my-A/prepared/xjtu_sy `
  --train-bearings Bearing1_1 --val-bearings Bearing1_4 `
  --stream-bearings Bearing1_5 --batch-size 16
```

Local layout must include complete `Bearing<condition>_<number>/<capture_index>.csv` directories. By default, known author-published capture counts are enforced: a shortened download cannot become a new zero-RUL endpoint. When all bearings are available, omit explicit partitions to train on bearings 1–3, validate on 4 and stream 5 within each available condition. Three explicit partitions are required for a smaller authentic subset.

The native acquisition is 25,600 Hz, two channels and 32,768 samples per capture, with a nominal 60-second interval. Use complete nonoverlapping one-second windows; drop and audit the remaining 7,168 time samples per channel for each capture. No raw waveform enters Ridge. Each channel contributes RMS, peak-to-peak, Pearson kurtosis and the dominant non-DC analytic-envelope FFT frequency (eight predictors total). `--target-sample-rate` optionally enables deterministic anti-alias FIR filtering plus resampling; the first real experiment retains native sampling. Nonfinite waveform windows are dropped and counted; missing labels are never synthesized.

RUL is seconds from the current complete window's end to the last complete recorded window's end of that bearing. This is an explicitly recorded endpoint proxy. Gaps between captures remain 60-second acquisition gaps and are not concatenated as continuous vibration. Capture index, timestamp, condition, bearing ID and lifetime length are excluded from predictors.

The optional `--max-rul 10000` clips only RUL targets in seconds. Omission preserves uncapped labels. The manifest's `metadata.rul_cap` records the chosen value, original maximum RUL and strictly clipped row count for each split. The existing three-bearing subset has maxima 7320/7260/3060 seconds, so a 10000-second Cap cannot change these labels.

## Fixed static baseline

```powershell
.\.venv\Scripts\python.exe -m scripts.data_prep.baseline `
  --package outputs/my-A/prepared/gas --output outputs/my-A/baseline/gas --alpha 1
```

Use the same command for the other prepared package paths. Gas uses six independent original binary Ridge models and raw-score argmax. Regression uses the unchanged `RidgeModel`. No parameter search or clipping of predictions is performed. The standalone `PreparedDataProvider` dispatches the existing CSV and Parquet readers while inheriting prediction/commit/label gates; the production binary Runner and its defaults stay unchanged.

Fit feature imputation on train only and apply fixed medians to validation/stream. Initial model scaling is also fitted only on train. The baseline verifies the prepared file hashes, commits every stream prediction, writes predictions/model/events, then reads scoring targets in an isolated post-run pass. `summary.json` includes validation and test Accuracy/confusion matrix or RMSE/MAE in original RUL units, fit/prediction times and zero real Token use. `events.jsonl` does not expose target values during prediction.

The initial MVP produces frozen static references. The separately approved Gas Mock round below adds explicit multiclass adaptation through the existing Controller; the original binary defaults and static numerical results remain the reference.

## Nine-batch Gas Mock intervention

```powershell
.\.venv\Scripts\python.exe -m scripts.run_gas_harness `
  --package outputs/a-package-20261110/prepared/uci_gas `
  --config configs/gas-harness-mock.json --output outputs/my-gas-pair
.\.venv\Scripts\python.exe -m scripts.gas_harness_report `
  --pair outputs/my-gas-pair --package outputs/a-package-20261110/prepared/uci_gas `
  --output outputs/my-gas-report
```

Use new output paths. The explicit `ovr_ridge` family fixes classes 1–6; initial fitting needs all classes, while partial-class candidates keep all six original binary heads. This configuration uses alpha1, nine original source batches, provided labels delayed two batches, bounded recent-disjoint selection and the existing independent future deployment gate. Only Mock is supported for this real-data round.

The read-only report scores saved predictions after both runs complete, checks source fingerprints and actual prediction versions, and exports SVG/HTML curves, exact CSV counts and full retraining events. Full-stream and post-deployment accuracies are sample weighted. A deployment in step k begins predicting in k+1; the post-deployment target includes all actual version>0 predictions and requires strictly over50%. The legacy Runner `mean_loss` remains the mean of batch losses and is not a sample-weighted full-stream score. Failed/incomplete runs or unverified gate events are rejected by the report.

The frozen round is specified in `docs/gas-harness-cap-design-20261110.md`. This is public development A data with a fixed Mock rule; it does not establish official or hidden-data promotion, or real LLM decision quality. No paid calls, C-MAPSS intervention or tree implementation belong to this round.

## Tests

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -p 'test_data_prep_*.py' -v
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Tests cover hand-derived signal/RUL/score values, anti-alias filtering, whole-entity partitions, class and temporal coverage, train-only imputation, corrupted/truncated sources, archive traversal, immutable outputs, Provider round trips and original binary compatibility. Real-data and Linux receipts are linked from the dated results document in `docs/`.

The optional `scripts/data_prep/Dockerfile` extends the previously verified local `ite-final:official-submit` runtime, copies the repository scripts and tests, exposes the existing pinned tokenizer at the historical test path, and installs no packages. Build from the repository root with the frozen source commit and preparation SHA-256 build arguments, under a new image tag. Preserve the original final-submit tag. Runtime checks use `--network none --cpus 4 --memory 8g` and explicit read-only prepared-data mounts; raw waveforms and source archives never enter the image.
