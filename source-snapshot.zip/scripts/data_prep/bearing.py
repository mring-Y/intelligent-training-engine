"""XJTU-SY whole-lifecycle vibration features and recorded-endpoint RUL proxy.

Sources: https://biaowang.tech/xjtu-sy-bearing-datasets/ and the author's linked
dataset. Published acquisition counts are enforced so an incomplete download
cannot silently become a run-to-failure example. Raw archives remain external.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
from numbers import Real
from pathlib import Path
import re

import numpy as np

from .features import FEATURE_NAMES, extract_features, resample_signal


SOURCE_URL = "https://biaowang.tech/xjtu-sy-bearing-datasets/"
CAPTURE_COUNT_URL = "https://biaowang.tech/images/table2.jpg"
PUBLISHED_CAPTURE_COUNTS = {
    "Bearing1_1": 123, "Bearing1_2": 161, "Bearing1_3": 158,
    "Bearing1_4": 122, "Bearing1_5": 52,
    "Bearing2_1": 491, "Bearing2_2": 161, "Bearing2_3": 533,
    "Bearing2_4": 42, "Bearing2_5": 339,
    "Bearing3_1": 2538, "Bearing3_2": 2496, "Bearing3_3": 371,
    "Bearing3_4": 1515, "Bearing3_5": 114,
}
_BEARING = re.compile(r"Bearing([123])_([1-5])", re.IGNORECASE)


def _bearing_id(name: str) -> str:
    match = _BEARING.fullmatch(name)
    if not match:
        raise ValueError(f"Unrecognized XJTU-SY bearing directory: {name}")
    return f"Bearing{match[1]}_{match[2]}"


def _capture_paths(source: Path) -> dict[str, list[Path]]:
    groups: dict[str, list[Path]] = {}
    if not source.is_dir():
        raise ValueError("XJTU-SY source must be an extracted directory")
    for path in source.rglob("*.csv"):
        if not _BEARING.fullmatch(path.parent.name):
            continue
        bearing = _bearing_id(path.parent.name)
        if not path.stem.isdecimal() or int(path.stem) < 1:
            raise ValueError(f"Capture filenames must be positive acquisition indices: {path}")
        groups.setdefault(bearing, []).append(path)
    if not groups:
        raise ValueError("No XJTU-SY Bearing<condition>_<entity>/<index>.csv captures found")
    for bearing, paths in groups.items():
        paths.sort(key=lambda path: int(path.stem))
        if [int(path.stem) for path in paths] != list(range(1, len(paths) + 1)):
            raise ValueError(f"{bearing}: captures must be unique and contiguous from 1")
    return dict(sorted(groups.items()))


def _read_capture(path: Path, expected_samples: int) -> np.ndarray:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.reader(handle)
        first = next(reader, None)
        if first is None or len(first) != 2:
            raise ValueError(f"Capture must contain two vibration columns: {path}")
        try:
            first_numeric = [float(value) for value in first]
        except ValueError:
            if not all("vibration" in value.casefold() for value in first):
                raise ValueError(f"Unexpected vibration CSV header: {path}")
            first_numeric = None
        rows = [] if first_numeric is None else [first_numeric]
        for line, row in enumerate(reader, 2):
            if len(row) != 2:
                raise ValueError(f"Expected two channels at {path}:{line}")
            try:
                rows.append([float(value) if value.strip() else float("nan") for value in row])
            except ValueError:
                # Keep time/sample alignment. A malformed amplitude invalidates
                # its own window and is counted; rows and labels never shift.
                rows.append([float("nan"), float("nan")])
            if len(rows) > expected_samples:
                raise ValueError(f"Capture exceeds expected {expected_samples} samples: {path}")
    if len(rows) != expected_samples:
        raise ValueError(f"Expected {expected_samples} samples, got {len(rows)}: {path}")
    return np.asarray(rows, dtype=np.float64)


def prepare_bearing(source, output_dir, *, sample_rate=25600,
                    target_sample_rate=None, window_seconds=1.0,
                    capture_interval_seconds=60.0, expected_capture_samples=32768,
                    expected_capture_counts=None, train_bearings=None,
                    val_bearings=None, stream_bearings=None, batch_size=256,
                    max_rul=None):
    """Export full bearing lifecycles; target units are recorded-endpoint seconds.

    RUL is last complete recorded window *end* minus current window end. Both
    ends include capture spacing and within-capture time, never concatenating
    missing 58.72-second gaps into a fake continuous waveform. It is an endpoint
    proxy, not a measured exact mechanical failure instant. Published default
    partitions are bearings 1–3 train, 4 validation and 5 chronological stream.
    A smaller subset needs all three explicit, fixed whole-bearing partitions.
    Optional max_rul clips only targets in seconds; None preserves raw RUL.
    """
    from .common import export_dataset, fingerprint

    source = Path(source)
    output_dir = Path(output_dir)
    if output_dir.exists():
        raise FileExistsError(f"Refusing to overwrite prepared bearing data: {output_dir}")
    if max_rul is not None:
        if isinstance(max_rul, bool) or not isinstance(max_rul, Real):
            raise ValueError("max_rul must be a finite positive number of seconds or None")
        try:
            max_rul = float(max_rul)
        except (OverflowError, ValueError) as error:
            raise ValueError("max_rul must be a finite positive number of seconds or None") from error
        if not math.isfinite(max_rul) or max_rul <= 0:
            raise ValueError("max_rul must be a finite positive number of seconds or None")
    rate, window, interval = map(float, (sample_rate, window_seconds, capture_interval_seconds))
    target_rate = rate if target_sample_rate is None else float(target_sample_rate)
    if any(not math.isfinite(value) or value <= 0 for value in (rate, target_rate, window, interval)):
        raise ValueError("Sampling, window and capture intervals must be finite and positive")
    if type(expected_capture_samples) is not int or expected_capture_samples < 2:
        raise ValueError("Expected capture samples must be an integer >=2")
    window_samples = int(round(rate * window))
    output_samples = int(round(target_rate * window))
    if (window_samples < 2 or output_samples < 2 or
            not math.isclose(rate * window, window_samples, abs_tol=1e-9) or
            not math.isclose(target_rate * window, output_samples, abs_tol=1e-9)):
        raise ValueError("A complete window must contain an integer number of samples at each rate")
    windows_per_capture = expected_capture_samples // window_samples
    if windows_per_capture < 1 or expected_capture_samples / rate > interval:
        raise ValueError("Capture duration/window is incompatible with the acquisition interval")
    groups = _capture_paths(source)
    counts = PUBLISHED_CAPTURE_COUNTS if expected_capture_counts is None else expected_capture_counts
    for bearing, paths in groups.items():
        if bearing not in counts or type(counts[bearing]) is not int or len(paths) != counts[bearing]:
            raise ValueError(f"{bearing}: incomplete lifecycle; need {counts.get(bearing)} captures for a complete bearing, got {len(paths)}")
    supplied = [train_bearings, val_bearings, stream_bearings]
    if any(value is not None for value in supplied) and not all(value is not None for value in supplied):
        raise ValueError("Provide all three whole-bearing partitions together")
    if all(value is None for value in supplied):
        splits = {
            "train": [name for name in groups if int(name[-1]) <= 3],
            "val": [name for name in groups if name[-1] == "4"],
            "stream": [name for name in groups if name[-1] == "5"],
        }
    else:
        splits = {name: [_bearing_id(value) for value in values]
                  for name, values in zip(("train", "val", "stream"), supplied)}
    selected = [bearing for names in splits.values() for bearing in names]
    if (any(not names for names in splits.values()) or len(selected) != len(set(selected)) or
            set(selected) != set(groups)):
        raise ValueError("All acquired complete bearings must occur in exactly one nonempty disjoint partition")
    rows = {name: [] for name in splits}
    cap_stats = {name: {"raw_max_seconds": None, "clipped_rows": 0} for name in splits}
    audit = {"capture_files": 0, "raw_samples_per_channel": 0,
             "complete_windows": 0, "invalid_windows_dropped": 0,
             "nonfinite_raw_values": 0, "dropped_tail_samples": 0,
             "dropped_tail_samples_units": "time samples per channel", "per_bearing": {}}
    raw_files = []
    for split, bearings in splits.items():
        for bearing in bearings:
            paths = groups[bearing]
            endpoint = (len(paths) - 1) * interval + windows_per_capture * window
            local = {"capture_files": len(paths), "complete_windows": 0,
                     "invalid_windows_dropped": 0, "dropped_tail_samples": 0,
                     "recorded_endpoint_seconds": endpoint}
            for path in paths:
                capture = int(path.stem)
                values = _read_capture(path, expected_capture_samples)
                origin = {**fingerprint(path), "path": path.relative_to(source).as_posix()}
                receipt_path = path.with_suffix(path.suffix + ".source.json")
                if receipt_path.exists():
                    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
                    if receipt.get("sha256") != origin["sha256"] or receipt.get("bytes") != origin["bytes"]:
                        raise ValueError(f"Raw acquisition receipt no longer matches capture: {path}")
                    origin["acquisition_url"] = receipt.get("url")
                    origin["acquisition_receipt_sha256"] = fingerprint(receipt_path)["sha256"]
                raw_files.append(origin)
                audit["capture_files"] += 1
                audit["raw_samples_per_channel"] += values.shape[0]
                audit["nonfinite_raw_values"] += int(np.count_nonzero(~np.isfinite(values)))
                tail = values.shape[0] % window_samples
                audit["dropped_tail_samples"] += tail
                local["dropped_tail_samples"] += tail
                for index in range(windows_per_capture):
                    chunk = values[index * window_samples:(index + 1) * window_samples]
                    audit["complete_windows"] += 1
                    local["complete_windows"] += 1
                    if not np.isfinite(chunk).all():
                        audit["invalid_windows_dropped"] += 1
                        local["invalid_windows_dropped"] += 1
                        continue
                    if target_rate != rate:
                        chunk = resample_signal(chunk, source_rate=rate, target_rate=target_rate)
                    end = (capture - 1) * interval + (index + 1) * window
                    raw_target = float(endpoint - end)
                    stats = cap_stats[split]
                    if stats["raw_max_seconds"] is None or raw_target > stats["raw_max_seconds"]:
                        stats["raw_max_seconds"] = raw_target
                    target = raw_target if max_rul is None else min(raw_target, max_rul)
                    stats["clipped_rows"] += int(target < raw_target)
                    row = {**extract_features(chunk, sample_rate=target_rate),
                           "target": target, "bearing_id": bearing,
                           "condition": int(bearing[7]), "capture_index": capture,
                           "window_index": index, "window_end_seconds": end,
                           "source_file": path.relative_to(source).as_posix()}
                    rows[split].append(row)
            audit["per_bearing"][bearing] = local
    metadata = {
        "source": SOURCE_URL, "capture_count_source": CAPTURE_COUNT_URL,
        "source_files": raw_files,
        "target_unit": "seconds", "target_definition": "seconds to last complete recorded window end; end-of-record proxy",
        "rul_cap": {"max_rul_seconds": max_rul, "population": "retained valid waveform windows",
                    "per_split": {"validation" if name == "val" else name: stats
                                  for name, stats in cap_stats.items()}},
        "endpoint_limitation": "Recorded run-to-failure endpoint, not an exact independently measured failure instant",
        "sampling": {"source_hz": rate, "feature_hz": target_rate,
                     "capture_samples": expected_capture_samples, "channels": 2,
                     "nominal_capture_interval_seconds": interval,
                     "window_seconds": window, "overlap_samples": 0,
                     "window_samples_before_resampling": window_samples,
                     "window_samples_after_resampling": output_samples,
                     "resampling": "native" if target_rate == rate else "symmetric Hann-windowed sinc FIR; cutoff=.45*min(source,target); reflect padding; grid interpolation"},
        "split_bearings": splits,
        "complete_lifecycle_counts": {name: len(paths) for name, paths in groups.items()},
        "completeness_basis": "author published counts" if expected_capture_counts is None else "explicit expected capture counts",
        "ordering": "fixed partition entity order, then acquisition index, then within-capture window",
        "feature_definition": "per-channel RMS, peak-to-peak, central Pearson kurtosis, dominant non-DC analytic-envelope spectrum Hz; degenerate kurtosis/envelope=0",
        "excluded_predictors": ["bearing_id", "condition", "capture_index", "window_index", "window_end_seconds", "source_file", "target", "lifecycle_length"],
        "window_audit": audit,
    }
    return export_dataset(output_dir, dataset="xjtu_sy", task="regression", features=FEATURE_NAMES,
                          train_rows=rows["train"], val_rows=rows["val"], stream_rows=rows["stream"],
                          metadata=metadata, batch_size=batch_size)


def main(argv=None):
    """Local extracted inputs or an explicitly supplied public ZIP download."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--download-url", help="Public ZIP source; stored immutably at --archive")
    parser.add_argument("--archive", type=Path)
    parser.add_argument("--sha256")
    parser.add_argument("--target-sample-rate", type=float)
    parser.add_argument("--max-rul", type=float,
                        help="Positive finite RUL cap in seconds; omitted preserves uncapped targets")
    parser.add_argument("--train-bearings", nargs="+")
    parser.add_argument("--val-bearings", nargs="+")
    parser.add_argument("--stream-bearings", nargs="+")
    parser.add_argument("--batch-size", type=int, default=256)
    args = parser.parse_args(argv)
    if args.download_url:
        if args.archive is None:
            parser.error("--download-url requires --archive")
        from .common import download_file, extract_zip
        archive = download_file(args.download_url, args.archive, expected_sha256=args.sha256)
        if not args.source.exists():
            extract_zip(archive, args.source)
    result = prepare_bearing(args.source, args.output, target_sample_rate=args.target_sample_rate,
                             train_bearings=args.train_bearings, val_bearings=args.val_bearings,
                             stream_bearings=args.stream_bearings, batch_size=args.batch_size,
                             max_rul=args.max_rul)
    print(json.dumps({"dataset": result["dataset"], "splits": result["splits"]}, indent=2))


if __name__ == "__main__":
    main()
