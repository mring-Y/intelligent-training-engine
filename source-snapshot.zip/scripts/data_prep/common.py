"""Immutable source acquisition and Provider-compatible, train-cleaned exports."""

import csv
import hashlib
import json
import math
import os
import stat
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

import numpy as np


def fingerprint(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return {"path": str(path.resolve()), "bytes": path.stat().st_size, "sha256": digest.hexdigest()}


def write_json(path, data):
    with Path(path).open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(data, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")


def download_file(url, path, *, expected_sha256=None, max_bytes=2147483648, timeout=30):
    """Cache bytes only with a matching URL/hash receipt; never overwrite a raw source."""
    path = Path(path)
    if type(max_bytes) is not int or max_bytes < 1 or timeout <= 0:
        raise ValueError("Download byte/time limits must be positive")
    receipt_path = path.with_suffix(path.suffix + ".source.json")
    if path.exists():
        receipt = json.loads(receipt_path.read_text(encoding="utf-8")) if receipt_path.exists() else {}
        actual = fingerprint(path)
        if (receipt.get("url") != url or receipt.get("sha256") != actual["sha256"]
                or actual["bytes"] > max_bytes or
                (expected_sha256 is not None and actual["sha256"] != expected_sha256)):
            raise FileExistsError(f"Unverified or different raw source already exists: {path}")
        return path
    if receipt_path.exists():
        raise FileExistsError(f"A source receipt already exists without its bytes: {receipt_path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_suffix(path.suffix + ".part")
    request = urllib.request.Request(url, headers={"User-Agent": "ITE-public-A-preparation/1.0"})
    created_partial = False
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response, partial.open("xb") as destination:
            created_partial = True
            content_length = response.headers.get("Content-Length")
            if content_length and int(content_length) > max_bytes:
                raise ValueError("Source exceeds configured download byte limit")
            total = 0
            for block in iter(lambda: response.read(1024 * 1024), b""):
                total += len(block)
                if total > max_bytes:
                    raise ValueError("Source exceeds configured download byte limit")
                destination.write(block)
            if content_length is not None and total != int(content_length):
                raise ValueError("Downloaded bytes differ from the declared Content-Length")
            destination.flush()
            os.fsync(destination.fileno())
            final_url, content_type = response.geturl(), response.headers.get("Content-Type")
        actual = fingerprint(partial)
        if not actual["bytes"] or (expected_sha256 and actual["sha256"] != expected_sha256):
            raise ValueError("Empty download or SHA-256 mismatch")
        # The target was checked above; rename does not replace an existing target on Windows.
        if path.exists():
            raise FileExistsError(path)
        partial.rename(path)
        write_json(receipt_path, {**fingerprint(path), "url": url, "resolved_url": final_url,
                                 "content_type": content_type,
                                 "retrieved_utc": datetime.now(timezone.utc).isoformat()})
    except BaseException:
        if created_partial and partial.exists():
            partial.unlink()
        raise
    return path


def extract_zip(archive, destination):
    """Validate the whole archive before extraction, including Windows path hazards."""
    destination = Path(destination)
    with zipfile.ZipFile(archive) as zipped:
        members = zipped.infolist()
        if sum(member.file_size for member in members) > 16 * 1024 ** 3:
            raise ValueError("Archive exceeds extraction size limit")
        seen = set()
        for member in members:
            name = member.filename.replace("\\", "/")
            parts = PurePosixPath(name)
            if (parts.is_absolute() or ".." in parts.parts or ":" in name
                    or stat.S_ISLNK(member.external_attr >> 16)
                    or name.casefold() in seen):
                raise ValueError("Unsafe or duplicate archive member")
            seen.add(name.casefold())
        destination.mkdir(parents=True, exist_ok=False)
        zipped.extractall(destination)
    return destination


def _number(value):
    try:
        parsed = float(value)
    except (ValueError, TypeError, OverflowError):
        return float("nan")
    return parsed if math.isfinite(parsed) else float("nan")


def export_dataset(output_dir, *, dataset, task, features, train_rows, val_rows,
                   stream_rows, metadata, batch_size=256):
    """Fit imputation on train only, export fixed splits and their complete audit."""
    import pyarrow as pa
    import pyarrow.parquet as pq

    output_dir = Path(output_dir)
    if output_dir.exists():
        raise FileExistsError(f"Refusing to overwrite a prepared package: {output_dir}")
    features = list(features)
    forbidden = {"target", "sample_id", "batch_id", "entity_id", "unit_id", "unit_number",
                 "bearing_id", "cycle", "source_batch", "source_row", "source_file"}
    if (not features or len(features) != len(set(features)) or
            any(not isinstance(name, str) or not name or name in forbidden for name in features)):
        raise ValueError("Predictors must be explicit, unique feature columns without labels/metadata")
    if task not in ("regression", "classification", "multiclass") or type(batch_size) is not int or batch_size < 1:
        raise ValueError("Invalid task or stream batch size")
    raw = {"train": list(train_rows), "validation": list(val_rows), "stream": list(stream_rows)}
    rows, quality = {}, {}
    for split, input_rows in raw.items():
        rows[split] = []
        audit = {"input_rows": len(input_rows), "dropped_invalid_targets": 0,
                 "imputed_features": {feature: 0 for feature in features}}
        for row in input_rows:
            target = _number(row.get("target"))
            if not math.isfinite(target):
                audit["dropped_invalid_targets"] += 1
                continue
            if task == "classification" and target not in (0, 1):
                raise ValueError("Binary classification requires 0/1 targets")
            if task == "multiclass" and target != int(target):
                raise ValueError("Multiclass targets must be integer class IDs")
            cleaned = dict(row, target=target)
            for feature in features:
                cleaned[feature] = _number(row.get(feature))
            rows[split].append(cleaned)
        minimum = 1 if split == "stream" else 4
        if len(rows[split]) < minimum:
            raise ValueError(f"{split} has fewer than {minimum} valid target rows")
        quality[split] = audit
    medians = {}
    for feature in features:
        observed = [row[feature] for row in rows["train"] if math.isfinite(row[feature])]
        if not observed:
            raise ValueError(f"No finite training values for feature {feature}")
        median = float(np.median(observed))
        if not math.isfinite(median):
            raise ValueError(f"No finite training median for feature {feature}")
        medians[feature] = median
    next_id = 0
    for split, split_rows in rows.items():
        raw_batches = []
        for index, row in enumerate(split_rows):
            row["sample_id"] = next_id
            next_id += 1
            batch = row.get("batch_id", index // batch_size if split == "stream" else 0)
            if type(batch) not in (int, np.int64, np.int32) or batch < 0:
                raise ValueError("Batch IDs must be nonnegative integers")
            raw_batches.append(int(batch))
            for feature in features:
                if not math.isfinite(row[feature]):
                    row[feature] = medians[feature]
                    quality[split]["imputed_features"][feature] += 1
        # Dropping invalid targets can empty a source batch; preserve order, compact IDs.
        unique = list(dict.fromkeys(raw_batches))
        if unique != sorted(unique) or any(a > b for a, b in zip(raw_batches, raw_batches[1:])):
            raise ValueError("Source batches must be ordered and contiguous")
        dense = {batch: index for index, batch in enumerate(unique)}
        for row, batch in zip(split_rows, raw_batches):
            row["batch_id"] = dense[batch]
    quality["imputation_medians"] = medians
    mapping = {"features": features, "target": "target", "sample_id": "sample_id", "batch": "batch_id"}
    manifest = {"format_version": 1, "dataset": dataset, "task": task, "column_mapping": mapping,
                "metadata": metadata, "quality": quality, "files": {}, "splits": {}}
    # Fail before writing if metadata is not a portable, finite JSON value.
    json.dumps(manifest, allow_nan=False)
    output_dir.mkdir(parents=True, exist_ok=False)
    for split, filename in (("train", "train.csv"), ("validation", "val.csv"),
                            ("stream", "test_stream.parquet")):
        split_rows = rows[split]
        columns = ["sample_id", "batch_id", *features, "target"]
        columns += sorted(set().union(*(set(row) for row in split_rows)) - set(columns))
        if filename.endswith(".csv"):
            with (output_dir / filename).open("x", encoding="utf-8", newline="") as stream:
                writer = csv.DictWriter(stream, fieldnames=columns)
                writer.writeheader()
                writer.writerows(split_rows)
        else:
            table = pa.Table.from_pylist([{column: row.get(column) for column in columns} for row in split_rows])
            pq.write_table(table, output_dir / filename, compression="zstd")
        manifest["files"][split] = {**fingerprint(output_dir / filename), "path": filename}
        manifest["splits"][split] = {"rows": len(split_rows),
                                     "batches": len(set(row["batch_id"] for row in split_rows)),
                                     "sample_id_min": split_rows[0]["sample_id"],
                                     "sample_id_max": split_rows[-1]["sample_id"]}
    write_json(output_dir / "manifest.json", manifest)
    return manifest
